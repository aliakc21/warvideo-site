-- Warvideo Companion
-- =====================================================================
-- Minimal companion addon for the Warvideo macOS app.
--
-- Warvideo records and auto-organizes your World of Warcraft sessions by
-- reading the game's combat log file. WoW only writes that file when combat
-- logging is turned on, and Warvideo needs the *advanced* params (unit HP) to
-- detect bosses and wipe %. This addon does exactly one thing: it makes sure
-- advanced combat logging is enabled and the log is being written — on every
-- login, reload, and zone/instance change.
--
-- That's it. No orb, no overlay, no UI, no SavedVariables. It is intentionally
-- tiny so it can run alongside any other addons without conflicts.
-- =====================================================================

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")   -- login, /reload, every loading screen
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")
f:RegisterEvent("CHALLENGE_MODE_START")
f:RegisterEvent("ENCOUNTER_START")

local announced = false

local function SafeSetCVar(name, value)
    if C_CVar and C_CVar.SetCVar then
        pcall(C_CVar.SetCVar, name, value)
    elseif SetCVar then
        pcall(SetCVar, name, value)
    end
end

local function EnsureLogging()
    -- Advanced combat logging adds the unit current/max HP params Warvideo
    -- uses to read boss HP and wipe percentages. Harmless if already set.
    SafeSetCVar("advancedCombatLogging", "1")

    -- LoggingCombat(true) writes the log to
    -- World of Warcraft/_retail_/Logs/WoWCombatLog.txt, which Warvideo reads.
    -- Re-checked on every event so it self-heals if something turns it off.
    local ok, logging = pcall(LoggingCombat)
    if ok and not logging then
        pcall(LoggingCombat, true)
        if not announced then
            announced = true
            print("|cff58a6ff[Warvideo]|r Combat logging enabled \226\128\148 automatic recording is ready.")
        end
    end
end

f:SetScript("OnEvent", function()
    EnsureLogging()
end)
