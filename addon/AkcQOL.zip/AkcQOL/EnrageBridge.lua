-- =========================================================================
-- ENRAGE: SMART RECORDING & AUTOMATION MODULE
-- =========================================================================
local orb = CreateFrame("Button", "EnrageOrb", UIParent)
orb:SetSize(32, 32)
orb:SetFrameStrata("TOOLTIP")
orb:SetFrameLevel(10000)
orb:SetClampedToScreen(false)
if orb.SetUserPlaced then pcall(orb.SetUserPlaced, orb, false) end
if orb.SetDontSavePosition then pcall(orb.SetDontSavePosition, orb, true) end
if orb.SetToplevel then pcall(orb.SetToplevel, orb, true) end

-- Pixel-locked screen anchor for the status orb.
local function UpdateOrbPosition()
    if not UIParent then return end
    if orb.SetParent then pcall(orb.SetParent, orb, UIParent) end
    if orb.SetScale then pcall(orb.SetScale, orb, 1) end
    if orb.SetSize then pcall(orb.SetSize, orb, 32, 32) end
    if orb.SetFrameStrata then pcall(orb.SetFrameStrata, orb, "TOOLTIP") end
    if orb.SetFrameLevel then pcall(orb.SetFrameLevel, orb, 10000) end
    if orb.SetClampedToScreen then pcall(orb.SetClampedToScreen, orb, false) end
    if orb.SetUserPlaced then pcall(orb.SetUserPlaced, orb, false) end
    if orb.SetDontSavePosition then pcall(orb.SetDontSavePosition, orb, true) end
    if orb.SetToplevel then pcall(orb.SetToplevel, orb, true) end
    orb:ClearAllPoints()
    orb:SetPoint("TOPLEFT", WorldFrame or UIParent, "TOPLEFT", 0, 0)
    if orb.Raise then pcall(orb.Raise, orb) end
end
UpdateOrbPosition()

-- A low-frequency safety check keeps the orb pixel-locked without rebuilding
-- its anchors four times per second when nothing has moved.
C_Timer.NewTicker(2, function()
    if not UIParent then return end
    local point, relativeTo, relativePoint, x, y = orb:GetPoint(1)
    if orb:GetParent() ~= UIParent
        or math.abs((orb:GetScale() or 1) - 1) > 0.001
        or math.abs((orb:GetWidth() or 0) - 32) > 0.1
        or math.abs((orb:GetHeight() or 0) - 32) > 0.1
        or orb:GetFrameStrata() ~= "TOOLTIP"
        or (orb:GetFrameLevel() or 0) ~= 10000
        or point ~= "TOPLEFT"
        or relativeTo ~= (WorldFrame or UIParent)
        or relativePoint ~= "TOPLEFT"
        or math.abs(tonumber(x) or 0) > 0.1
        or math.abs(tonumber(y) or 0) > 0.1
    then
        UpdateOrbPosition()
    end
end)

orb.border = orb:CreateTexture(nil, "BACKGROUND")
orb.border:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.border:SetAllPoints(orb)
orb.border:SetVertexColor(0.86, 0.70, 0.24, 1)

orb.borderMask = orb:CreateMaskTexture()
orb.borderMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.borderMask:SetAllPoints(orb)
if orb.borderMask.SetTexCoord then orb.borderMask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.border:AddMaskTexture(orb.borderMask)

orb.innerShadow = orb:CreateTexture(nil, "BORDER")
orb.innerShadow:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.innerShadow:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.innerShadow:SetSize(26, 26)
orb.innerShadow:SetVertexColor(0.02, 0.018, 0.012, 1)

orb.innerShadowMask = orb:CreateMaskTexture()
orb.innerShadowMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.innerShadowMask:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.innerShadowMask:SetSize(26, 26)
if orb.innerShadowMask.SetTexCoord then orb.innerShadowMask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.innerShadow:AddMaskTexture(orb.innerShadowMask)

orb.fill = orb:CreateTexture(nil, "ARTWORK")
orb.fill:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.fill:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.fill:SetSize(22, 22)
orb.fill:SetVertexColor(0, 0, 0, 1)

orb.mask = orb:CreateMaskTexture()
orb.mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.mask:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.mask:SetSize(22, 22)
if orb.mask.SetTexCoord then orb.mask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.fill:AddMaskTexture(orb.mask)

-- Wipe HP signal overlay. This layer is above the inner fill so external
-- screen capture tools can read the signal without relying on the gold ring.
orb.wipeOverlay = orb:CreateTexture(nil, "OVERLAY", nil, 7)
orb.wipeOverlay:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.wipeOverlay:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.wipeOverlay:SetSize(22, 22)
orb.wipeOverlay:Hide()

orb.wipeMask = orb:CreateMaskTexture()
orb.wipeMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.wipeMask:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.wipeMask:SetSize(22, 22)
if orb.wipeMask.SetTexCoord then orb.wipeMask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.wipeOverlay:AddMaskTexture(orb.wipeMask)

orb:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine("Click to toggle Matrix Tracker.", 1, 1, 1)
    GameTooltip:Show()
end)
orb:SetScript("OnLeave", function(self)
    GameTooltip:Hide()
end)

orb:SetScript("OnClick", function()
    if SlashCmdList["ENRAGE"] then
        SlashCmdList["ENRAGE"]("")
    end
end)

-- Boss HP tracking for wipe percentage.
-- Uses both UNIT_HEALTH event (reliable, fires only on change) AND OnUpdate
-- (fallback) so that whichever path works in WoW 12.0's tainted environment
-- gives us a usable HP reading. lastBossHP only goes down, never back up,
-- so a boss evading and regenerating to 100% before ENCOUNTER_END doesn't
-- erase the wipe progress.
local lastBossHP = 100
local isInEncounter = false
local wipeSignalActive = false

local function SampleLowestBossHP()
    local lowest = 100
    for i = 1, 5 do
        local unit = "boss" .. i
        local ok, pct = pcall(function()
            if not UnitExists(unit) then return nil end
            local h = UnitHealth(unit) or 0
            local m = UnitHealthMax(unit) or 0
            if m <= 0 then return nil end
            return math.floor((h / m) * 100 + 0.5)
        end)
        if ok and pct and pct >= 0 and pct < lowest then
            lowest = pct
        end
    end
    return lowest
end

local bossHPFrame = CreateFrame("Frame")
bossHPFrame:RegisterEvent("UNIT_HEALTH")
bossHPFrame:SetScript("OnEvent", function(_, _, unit)
    if not isInEncounter then return end
    if not unit or not string.match(unit, "^boss%d+$") then return end
    local lowest = SampleLowestBossHP()
    if lowest < lastBossHP then lastBossHP = lowest end
end)

-- OnUpdate fallback, throttled to every 0.5s and idle outside encounters.
bossHPFrame.enrageElapsed = 0
bossHPFrame:SetScript("OnUpdate", function(self, elapsed)
    if not isInEncounter then return end
    self.enrageElapsed = self.enrageElapsed + elapsed
    if self.enrageElapsed < 0.5 then return end
    self.enrageElapsed = 0
    local lowest = SampleLowestBossHP()
    if lowest < lastBossHP then lastBossHP = lowest end
end)

local function ForceUpdateColor()
    if wipeSignalActive then return end -- Don't override wipe HP signal
    local inInstance, instanceType = IsInInstance()
    if inInstance and (instanceType == "party" or instanceType == "raid") then
        orb.fill:SetVertexColor(1, 0, 1, 1) -- Magenta (Recording)
    else
        orb.fill:SetVertexColor(0.16, 0.17, 0.18, 1) -- Anthracite (Stopped)
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("PLAYER_DIFFICULTY_CHANGED")
eventFrame:RegisterEvent("LOADING_SCREEN_DISABLED")
eventFrame:RegisterEvent("CHALLENGE_MODE_START")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
eventFrame:RegisterEvent("DISPLAY_SIZE_CHANGED")
eventFrame:RegisterEvent("UI_SCALE_CHANGED")
eventFrame:RegisterEvent("CVAR_UPDATE")
eventFrame:RegisterEvent("ENCOUNTER_START")
eventFrame:RegisterEvent("ENCOUNTER_END")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ENCOUNTER_START" then
        isInEncounter = true
        lastBossHP = 100
        ForceUpdateColor()
        return
    elseif event == "ENCOUNTER_END" then
        local _, _, _, _, success = ...
        isInEncounter = false
        if success == 0 then
            -- One last sample in case UNIT_HEALTH missed the killing blow
            local lowest = SampleLowestBossHP()
            if lowest < lastBossHP then lastBossHP = lowest end

            -- Wipe: paint BOTH the overlay AND the fill for 5 seconds.
            -- R = bossHP/100 (0.0-1.0), G = 0.87 (~222), B = 0.435 (~111).
            -- The unique G+B combo lets PixelWatcher distinguish this from
            -- magenta/anthracite. We paint both layers as redundancy: the
            -- OVERLAY layer (above the gold border) is the primary signal,
            -- but if it ever fails to draw the BACKGROUND fill still leaks
            -- through wherever the border has alpha holes.
            local hpNorm = math.max(0, math.min(1, lastBossHP / 100))
            orb.wipeOverlay:SetVertexColor(hpNorm, 0.87, 0.435, 1)
            orb.wipeOverlay:Show()
            orb.fill:SetVertexColor(hpNorm, 0.87, 0.435, 1)
            wipeSignalActive = true
            -- Visible confirmation in chat so the user can confirm the event fired.
            print("|cffff8888[AkcQOL]|r Wipe at " .. lastBossHP .. "% boss HP.")
            -- 5 seconds gives the Mac app's 5 FPS poller 25 frames to capture
            C_Timer.After(5, function()
                orb.wipeOverlay:Hide()
                wipeSignalActive = false
                ForceUpdateColor()
            end)
        else
            ForceUpdateColor()
        end
        return
    end
    ForceUpdateColor()
    -- Auto-enable combat logging on every login/reload/instance change
    if event == "PLAYER_ENTERING_WORLD" then
        -- WV: Warvideo advanced combat-log params (boss HP / wipe%) icin
        pcall(function()
            if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar("advancedCombatLogging", "1")
            elseif SetCVar then SetCVar("advancedCombatLogging", "1") end
        end)
        if not LoggingCombat() then
            LoggingCombat(true)
        end
    end
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" or event == "LOADING_SCREEN_DISABLED"
        or event == "DISPLAY_SIZE_CHANGED" or event == "UI_SCALE_CHANGED" or event == "CVAR_UPDATE" then
        UpdateOrbPosition()
        if C_Timer and C_Timer.After then
            C_Timer.After(0.1, UpdateOrbPosition)
            C_Timer.After(0.5, UpdateOrbPosition)
            C_Timer.After(1.5, UpdateOrbPosition)
        end
        if EnrageDB and EnrageDB.global and EnrageDB.global.showOrb == false then
            orb:Hide()
        else
            orb:Show()
        end
    end
end)

C_Timer.NewTicker(10, ForceUpdateColor)
ForceUpdateColor()

-- =========================================================================
-- INSTANCE RESET ANNOUNCER
-- Detects "Reset all instances" and announces to /instance or /party
-- =========================================================================
do
    local resetFrame = CreateFrame("Frame")
    resetFrame:RegisterEvent("CHAT_MSG_SYSTEM")
    resetFrame:SetScript("OnEvent", function(_, event, msg)
        if event ~= "CHAT_MSG_SYSTEM" or not msg then return end
        -- WoW 12.0: msg is a secret/tainted string; all string ops must be
        -- wrapped in pcall because the engine blocks direct access.
        local isReset = false
        pcall(function()
            if string.find(msg, "has been reset", 1, true)
               or string.find(msg, "have been reset", 1, true)
               or string.find(msg, "instances have been reset", 1, true)
               or string.find(msg, "s\196\177f\196\177rland\196\177", 1, true)
               or string.find(msg, "resetlendi", 1, true)
               or string.find(msg, "zur\195\188ckgesetzt", 1, true)
               or string.find(msg, "r\195\169initialis\195\169", 1, true)
            then
                isReset = true
            end
        end)
        if not isReset then return end

        -- Send to appropriate chat channel
        local channel = nil
        if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
            channel = "INSTANCE_CHAT"
        elseif IsInRaid(LE_PARTY_CATEGORY_HOME) then
            channel = "RAID"
        elseif IsInGroup(LE_PARTY_CATEGORY_HOME) then
            channel = "PARTY"
        end

        if channel then
            SendChatMessage("[AkcQOL] Instances have been reset.", channel)
        else
            print("|cff00ccff[AkcQOL]|r Instances have been reset.")
        end
    end)
end

-- Global so other Enrage modules can close log windows too
WV_LOG_FRAMES = {}

-- =========================================================================
-- RAID PROGRESS TRACKER
-- Shows Normal (X/Y) | Heroic (X/Y) | Mythic (X/Y) at top of screen near raid entrances
-- =========================================================================
do
    local DIFF_INFO = {
        [17] = { label = "LFR",     color = {0.50, 0.80, 0.50} },
        [14] = { label = "Normal",  color = {0.30, 1.00, 0.30} },
        [15] = { label = "Heroic",  color = {1.00, 0.60, 0.00} },
        [16] = { label = "Mythic",  color = {0.78, 0.30, 1.00} },
    }
    local DIFF_ORDER = {17, 14, 15, 16}
    local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
    local BAR_TEX  = "Interface\\TargetingFrame\\UI-StatusBar"

    -- Raid entrance coordinates: mapID -> { x, y (0-1 map %), raidName }
    -- Radius 0.015 in map coords is roughly 50 yards in most zones.
    -- Use /rpzone to discover mapID & coords for new entrances
    local RAID_ENTRANCES = {
        -- Midnight
        [2405] = {
            { x = 0.455, y = 0.644, name = "The Voidspire" },
        },
        [2413] = {
            { x = 0.614, y = 0.628, name = "The Dreamrift" },  -- Harandar, Rift of Aln
        },
        -- The War Within
        [2255] = {{ x = 0.47,  y = 0.57,  name = "Nerub-ar Palace" }},  -- Azj-Kahet
        -- Dragonflight
        [2133] = {{ x = 0.49,  y = 0.23,  name = "Aberrus, the Shadowed Crucible" }},  -- Zaralek Cavern
        [2200] = {{ x = 0.56,  y = 0.26,  name = "Amirdrassil, the Dream's Hope" }},   -- Emerald Dream
        [2025] = {{ x = 0.73,  y = 0.56,  name = "Vault of the Incarnates" }},          -- Thaldraszus
    }
    local ENTRANCE_RADIUS = 0.015  -- ~50 yards

    local KNOWN_BOSS_COUNTS = {
        ["The Voidspire"] = 6,
        ["The Dreamrift"] = 3,  -- Darkreach / MQD wing bosses (adjust count as needed)
        ["Nerub-ar Palace"] = 8,
        ["Aberrus, the Shadowed Crucible"] = 9,
        ["Amirdrassil, the Dream's Hope"] = 9,
        ["Vault of the Incarnates"] = 8,
    }

    local TAB_H = 30

    local progressFrame = CreateFrame("Frame", "EnrageRaidProgressFrame", UIParent)
    progressFrame:SetFrameStrata("HIGH")
    progressFrame:SetPoint("TOP", UIParent, "TOP", 0, 0)
    progressFrame:SetSize(600, TAB_H + 4)
    progressFrame:Hide()

    -- No background - tabs float cleanly at the top

    -- Raid name (elegant font)
    local raidNameText = progressFrame:CreateFontString(nil, "OVERLAY")
    raidNameText:SetFont("Fonts\\MORPHEUS.TTF", 15, "")
    raidNameText:SetPoint("LEFT", 10, 0)
    raidNameText:SetTextColor(1, 0.82, 0)
    raidNameText:SetShadowOffset(1, -1)
    raidNameText:SetShadowColor(0, 0, 0, 0.9)

    -- Separator after name
    local sepDot = progressFrame:CreateFontString(nil, "OVERLAY")
    sepDot:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
    sepDot:SetTextColor(0.4, 0.35, 0.15, 0.7)
    sepDot:SetText("|")

    -- Tab buttons (will be created dynamically)
    local tabs = {}
    local raidProgressData = {}  -- [raidName] = { [diffID] = {killed=X, total=Y, bosses={}, instanceIdx=i} }

    local function CreateTab(index)
        local tab = CreateFrame("Frame", nil, progressFrame)
        tab:SetSize(120, TAB_H)
        tab:EnableMouse(true)

        -- Tab bg with bar texture for depth
        local tbg = tab:CreateTexture(nil, "BACKGROUND")
        tbg:SetPoint("TOPLEFT", 1, -1)
        tbg:SetPoint("BOTTOMRIGHT", -1, 1)
        tbg:SetTexture(BAR_TEX)
        tbg:SetVertexColor(0.07, 0.07, 0.10, 0.85)
        tab.bg = tbg

        -- Gold border edges
        local hlTop = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlTop:SetTexture(FLAT_TEX); hlTop:SetVertexColor(0.82, 0.68, 0.18, 1)
        hlTop:SetHeight(2); hlTop:SetPoint("TOPLEFT"); hlTop:SetPoint("TOPRIGHT")
        hlTop:Hide(); tab.hlTop = hlTop

        local hlBot = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlBot:SetTexture(FLAT_TEX); hlBot:SetVertexColor(0.82, 0.68, 0.18, 0.4)
        hlBot:SetHeight(1); hlBot:SetPoint("BOTTOMLEFT"); hlBot:SetPoint("BOTTOMRIGHT")
        hlBot:Hide(); tab.hlBot = hlBot

        local hlLeft = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlLeft:SetTexture(FLAT_TEX); hlLeft:SetVertexColor(0.82, 0.68, 0.18, 0.5)
        hlLeft:SetWidth(1); hlLeft:SetPoint("TOPLEFT"); hlLeft:SetPoint("BOTTOMLEFT")
        hlLeft:Hide(); tab.hlLeft = hlLeft

        local hlRight = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlRight:SetTexture(FLAT_TEX); hlRight:SetVertexColor(0.82, 0.68, 0.18, 0.5)
        hlRight:SetWidth(1); hlRight:SetPoint("TOPRIGHT"); hlRight:SetPoint("BOTTOMRIGHT")
        hlRight:Hide(); tab.hlRight = hlRight

        -- Difficulty name (left)
        local diffLabel = tab:CreateFontString(nil, "OVERLAY")
        diffLabel:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
        diffLabel:SetPoint("LEFT", 10, 0)
        diffLabel:SetShadowOffset(1, -1)
        diffLabel:SetShadowColor(0, 0, 0, 1)
        tab.diffLabel = diffLabel

        -- Count (right)
        local countLabel = tab:CreateFontString(nil, "OVERLAY")
        countLabel:SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
        countLabel:SetPoint("RIGHT", -10, 0)
        countLabel:SetShadowOffset(1, -1)
        countLabel:SetShadowColor(0, 0, 0, 1)
        tab.countLabel = countLabel

        -- Tooltip
        tab.raidName = nil
        tab.diffID = nil
        tab:SetScript("OnEnter", function(self)
            if not self.raidName or not self.diffID then return end
            local data = raidProgressData[self.raidName] and raidProgressData[self.raidName][self.diffID]
            local di = DIFF_INFO[self.diffID]
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM", 0, -4)
            GameTooltip:AddLine(self.raidName, 1, 0.82, 0)
            if di then GameTooltip:AddLine(di.label, di.color[1], di.color[2], di.color[3]) end
            GameTooltip:AddLine(" ")
            if data and data.bosses then
                for _, boss in ipairs(data.bosses) do
                    if boss.killed then
                        GameTooltip:AddDoubleLine("  " .. boss.name, "|TInterface\\RAIDFRAME\\ReadyCheck-Ready:0|t", 0.5, 0.5, 0.5)
                    else
                        GameTooltip:AddDoubleLine("  " .. boss.name, "|TInterface\\RAIDFRAME\\ReadyCheck-NotReady:0|t", 0.9, 0.9, 0.9)
                    end
                end
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(string.format("Progress: %d / %d", data.killed, data.total), 1, 1, 0.6)
            else
                GameTooltip:AddLine("No lockout", 0.5, 0.5, 0.5)
            end
            GameTooltip:Show()
            self.bg:SetVertexColor(0.14, 0.12, 0.08, 0.9)
        end)
        tab:SetScript("OnLeave", function(self)
            GameTooltip:Hide()
            if self.isActive then
                self.bg:SetVertexColor(0.12, 0.10, 0.04, 0.9)
            else
                self.bg:SetVertexColor(0.07, 0.07, 0.10, 0.85)
            end
        end)

        tab:Hide()
        tabs[index] = tab
        return tab
    end

    for i = 1, 4 do CreateTab(i) end

    local function SetTabActive(tab, active)
        tab.isActive = active
        if active then
            tab.hlTop:Show(); tab.hlBot:Show(); tab.hlLeft:Show(); tab.hlRight:Show()
            tab.bg:SetVertexColor(0.12, 0.10, 0.04, 0.9)
        else
            tab.hlTop:Hide(); tab.hlBot:Hide(); tab.hlLeft:Hide(); tab.hlRight:Hide()
            tab.bg:SetVertexColor(0.07, 0.07, 0.10, 0.85)
        end
    end

    local function RefreshRaidProgress()
        raidProgressData = {}

        -- Gather lockout data for all raids (only locked = active lockouts)
        local numSaved = GetNumSavedInstances()
        for i = 1, numSaved do
            local name, _, _, difficultyID, locked, _, _, isRaid, _, _, numEncounters, encounterProgress = GetSavedInstanceInfo(i)
            if isRaid and locked and DIFF_INFO[difficultyID] then
                if not raidProgressData[name] then raidProgressData[name] = {} end
                local bosses = {}
                for j = 1, numEncounters do
                    local bossName, _, isKilled = GetSavedInstanceEncounterInfo(i, j)
                    bosses[j] = { name = bossName or ("Boss " .. j), killed = isKilled }
                end
                raidProgressData[name][difficultyID] = {
                    killed = encounterProgress or 0,
                    total = numEncounters or 0,
                    bosses = bosses,
                    locked = locked,
                }
            end
        end
    end

    -- Detect if player is within ~50 yards of a raid entrance
    local function DetectNearbyRaid()
        -- Not in open world? Don't show
        local _, instanceType = GetInstanceInfo()
        if instanceType ~= "none" then return nil end

        -- Get player map position
        local mapID = C_Map.GetBestMapForUnit("player")
        if not mapID then return nil end

        local entrances = RAID_ENTRANCES[mapID]
        if not entrances then return nil end

        local pos = C_Map.GetPlayerMapPosition(mapID, "player")
        if not pos then return nil end
        local px, py = pos:GetXY()
        if not px or not py then return nil end

        -- Check distance to each entrance on this map
        for _, entrance in ipairs(entrances) do
            local dx = px - entrance.x
            local dy = py - entrance.y
            local dist = math.sqrt(dx * dx + dy * dy)
            if dist <= ENTRANCE_RADIUS then
                return entrance.name
            end
        end

        return nil
    end

    local function UpdateProgressDisplay()
        -- Check toggle
        if EnrageDB and EnrageDB.global and EnrageDB.global.showRaidProgress == false then
            progressFrame:Hide()
            return
        end

        local displayRaid = DetectNearbyRaid()

        if not displayRaid then
            progressFrame:Hide()
            return
        end

        RefreshRaidProgress()

        local raidData = raidProgressData[displayRaid]

        -- If no lockout data for current raid, show empty tabs
        if not raidData then
            raidData = {}
        end

        raidNameText:SetText(displayRaid or "Raid")
        local currentRaidDiff = GetRaidDifficultyID() or 14
        local nameW = raidNameText:GetStringWidth() + 18

        -- Position separator
        sepDot:ClearAllPoints()
        sepDot:SetPoint("LEFT", progressFrame, "LEFT", nameW, 0)
        local sepW = sepDot:GetStringWidth() + 10

        -- Build tabs
        local totalW = nameW + sepW
        for idx, diffID in ipairs(DIFF_ORDER) do
            local tab = tabs[idx]
            local di  = DIFF_INFO[diffID]
            local data = raidData[diffID]
            local killed = data and data.killed or 0
            local total  = data and data.total or 0

            if total == 0 then
                for _, od in ipairs(DIFF_ORDER) do
                    if raidData[od] and raidData[od].total > 0 then total = raidData[od].total; break end
                end
            end
            if total == 0 then total = KNOWN_BOSS_COUNTS[displayRaid] or 0 end

            -- Difficulty name with color
            tab.diffLabel:SetText(di.label)
            tab.diffLabel:SetTextColor(di.color[1], di.color[2], di.color[3])

            -- Progress count
            local countStr = string.format("(%d/%d)", killed, total)
            if killed == total and total > 0 then
                tab.countLabel:SetText("|cff00ff00" .. countStr .. "|r")
            elseif killed > 0 then
                tab.countLabel:SetText("|cffffffff" .. countStr .. "|r")
            else
                tab.countLabel:SetText("|cff555555" .. countStr .. "|r")
            end

            SetTabActive(tab, diffID == currentRaidDiff)
            tab.raidName = displayRaid
            tab.diffID = diffID

            local tabW = math.max(115, tab.diffLabel:GetStringWidth() + tab.countLabel:GetStringWidth() + 32)
            tab:SetSize(tabW, TAB_H)
            tab:ClearAllPoints()
            tab:SetPoint("LEFT", progressFrame, "LEFT", totalW, 0)
            totalW = totalW + tabW + 3
            tab:Show()
        end

        for i = #DIFF_ORDER + 1, #tabs do
            if tabs[i] then tabs[i]:Hide() end
        end

        progressFrame:SetWidth(totalW + 8)
        progressFrame:Show()
    end

    -- Events: refresh lockout data on zone/instance changes
    local rpEventFrame = CreateFrame("Frame")
    rpEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    rpEventFrame:RegisterEvent("UPDATE_INSTANCE_INFO")
    rpEventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    rpEventFrame:SetScript("OnEvent", function()
        C_Timer.After(0.5, function()
            RequestRaidInfo()
            C_Timer.After(0.5, UpdateProgressDisplay)
        end)
    end)

    -- Proximity ticker: check distance to raid entrances every 2s
    C_Timer.After(3, function()
        C_Timer.NewTicker(2, function()
            local mapID = C_Map.GetBestMapForUnit("player") or 0
            if RAID_ENTRANCES[mapID] then
                UpdateProgressDisplay()
            elseif progressFrame:IsShown() then
                progressFrame:Hide()
            end
        end)
    end)

    _G.Enrage_UpdateRaidProgress = UpdateProgressDisplay

    -- /rpzone: shows current zone/subzone text for adding new raid entrances
end

-- =========================================================================
-- MINIMAP ICON
-- =========================================================================
local EnrageMinimapBtn = CreateFrame("Button", "EnrageMinimapBtn", Minimap)
EnrageMinimapBtn:SetSize(33, 33)
EnrageMinimapBtn:SetFrameStrata("MEDIUM")
EnrageMinimapBtn:SetFrameLevel(8)
EnrageMinimapBtn:SetMovable(true)
EnrageMinimapBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
EnrageMinimapBtn:RegisterForDrag("LeftButton")
EnrageMinimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local mmOverlay = EnrageMinimapBtn:CreateTexture(nil, "OVERLAY")
mmOverlay:SetSize(53, 53)
mmOverlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
mmOverlay:SetPoint("TOPLEFT")

local mmIcon = EnrageMinimapBtn:CreateTexture(nil, "BACKGROUND")
mmIcon:SetSize(21, 21)
mmIcon:SetTexture("Interface\\Icons\\Ability_Warrior_InnerRage")
mmIcon:SetPoint("CENTER", EnrageMinimapBtn, "CENTER", 1, 1)

-- Expose icon field for MBB / MinimapButtonButton compatibility
EnrageMinimapBtn.icon = mmIcon

-- Position around minimap using angle (supports circular AND square minimaps)
if not EnrageDB then EnrageDB = {} end
if not EnrageDB.global then EnrageDB.global = {} end

-- Fresh install: every QoL feature starts OFF; the user opts in from settings. Seeded HERE,
-- at file-load — BEFORE the PLAYER_ENTERING_WORLD visibility handlers for the orb/minimap
-- run — so a brand-new user never sees them. Guarded by the fresh-install flag (captured in
-- EnrageBoot.lua before anything touches EnrageDB) plus a one-time sentinel, so EXISTING
-- users are never touched: their saved values, and legitimately-nil values that read as ON,
-- are left exactly as they were. Per-feature defaults for existing users still live in
-- SaveCurrentCharacterData (unchanged), which no-ops here because the fields are already set.
if _G.EnrageQoL_FreshInstall and EnrageDB.global.qolOptInV1 == nil then
    local g = EnrageDB.global
    g.autoSell = false
    g.autoRepair = false
    g.fastLoot = false
    g.autoInsertKeystone = false
    g.autoCinematic = false
    g.showOrb = false
    g.showMinimap = false
    g.showItemLevel = false
    g.showRaidProgress = false
    g.showTalentHelper = false
    g.qolOptInV1 = true
end

if EnrageDB.global.minimapAngle == nil then EnrageDB.global.minimapAngle = 220 end

local function UpdateMinimapBtnPos()
    local angle = math.rad(EnrageDB.global.minimapAngle or 220)
    local radius = 105
    local w, h = Minimap:GetSize()
    -- Detect square vs round minimap (SexyMap, ElvUI etc.)
    local isSquare = false
    if GetMinimapShape then
        local shape = GetMinimapShape()
        if shape and shape ~= "ROUND" then isSquare = true end
    end
    -- Also check if minimap is explicitly square-sized (fallback)
    if not isSquare and w and h and math.abs(w - h) < 2 then
        -- Could be square addon; check if minimap mask is removed
        local hasMaskFunc = Minimap.GetMaskTexture
        if hasMaskFunc then
            local mask = Minimap:GetMaskTexture()
            if mask and type(mask) == "string" and mask:lower():find("square") then
                isSquare = true
            end
        end
    end

    local x, y
    if isSquare then
        -- Clamp to square minimap edges
        local halfW, halfH = w / 2, h / 2
        x = math.cos(angle) * (halfW + 16)
        y = math.sin(angle) * (halfH + 16)
        -- Clamp to square perimeter
        local maxDist = math.max(math.abs(x), math.abs(y))
        local edgeDist = halfW + 6
        if maxDist > 0 then
            local scale = edgeDist / maxDist
            x = x * scale
            y = y * scale
        end
    else
        -- Round minimap (default)
        x = math.cos(angle) * radius
        y = math.sin(angle) * radius
    end
    EnrageMinimapBtn:ClearAllPoints()
    EnrageMinimapBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end
UpdateMinimapBtnPos()

EnrageMinimapBtn:SetScript("OnDragStart", function(self)
    self.isDragging = true
    self:SetScript("OnUpdate", function(self)
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        cx, cy = cx / scale, cy / scale
        local angle = math.deg(math.atan2(cy - my, cx - mx))
        EnrageDB.global.minimapAngle = angle
        UpdateMinimapBtnPos()
    end)
end)

EnrageMinimapBtn:SetScript("OnDragStop", function(self)
    self.isDragging = false
    self:SetScript("OnUpdate", nil)
end)

EnrageMinimapBtn:SetScript("OnClick", function(self, button)
    if button == "LeftButton" then
        SlashCmdList["ENRAGE"]()
    elseif button == "RightButton" then
        -- Right-click opens AkcQOL settings as a clean STANDALONE window (does NOT also open
        -- the matrix behind it). Matches this button's tooltip + the minimap convention.
        if _G.Enrage_ToggleStandaloneSettings then
            _G.Enrage_ToggleStandaloneSettings()
        elseif _G.Enrage_ToggleMatrixSettings then
            _G.Enrage_ToggleMatrixSettings()
        end
    end
end)

EnrageMinimapBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine("Left-Click: Toggle Matrix", 1, 1, 1)
    GameTooltip:AddLine("Right-Click: Settings", 1, 1, 1)
    GameTooltip:AddLine("Drag: Move icon", 0.7, 0.7, 0.7)
    GameTooltip:Show()
end)

EnrageMinimapBtn:SetScript("OnLeave", function()
    GameTooltip:Hide()
end)

-- Respect saved visibility
local mmInitFrame = CreateFrame("Frame")
mmInitFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
mmInitFrame:SetScript("OnEvent", function()
    if EnrageDB and EnrageDB.global and EnrageDB.global.showMinimap == false then
        EnrageMinimapBtn:Hide()
    else
        EnrageMinimapBtn:Show()
    end
    UpdateMinimapBtnPos()
end)

-- Addon Compartment (modern WoW 10.1+ minimap addon list)
function Enrage_OnAddonCompartmentClick(_, button)
    if button == "LeftButton" then
        SlashCmdList["ENRAGE"]()
    else
        SlashCmdList["ENRAGE"]("")
    end
end
function Enrage_OnAddonCompartmentEnter(_, menuButtonFrame)
    GameTooltip:SetOwner(menuButtonFrame, "ANCHOR_LEFT")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine("Left-Click: Toggle Matrix", 1, 1, 1)
    GameTooltip:AddLine("Right-Click: Settings", 1, 1, 1)
    GameTooltip:Show()
end
function Enrage_OnAddonCompartmentLeave()
    GameTooltip:Hide()
end

-- =========================================================================
-- AUTOMATION: AUTO-SELL, AUTO-REPAIR, FAST-LOOT, M+ KEYSTONE & AUTO-SKIP CINEMATICS
-- =========================================================================

local AutoFrame = CreateFrame("Frame")
AutoFrame:RegisterEvent("MERCHANT_SHOW")
AutoFrame:SetScript("OnEvent", function()
    local doSell = true
    local doRepair = true

    if EnrageDB and EnrageDB.global then
        if EnrageDB.global.autoSell == false then doSell = false end
        if EnrageDB.global.autoRepair == false then doRepair = false end
    end

    if doSell then
        local junkItems = {}
        local totalEarned = 0
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local itemInfo = C_Container.GetContainerItemInfo(bag, slot)
                if itemInfo and itemInfo.quality == 0 and itemInfo.hyperlink then
                    local itemPrice = select(11, GetItemInfo(itemInfo.hyperlink)) or 0
                    totalEarned = totalEarned + (itemPrice * itemInfo.stackCount)
                    table.insert(junkItems, { bag = bag, slot = slot })
                end
            end
        end
        if #junkItems > 0 then
            for i, item in ipairs(junkItems) do
                C_Timer.After((i - 1) * 0.15, function()
                    C_Container.UseContainerItem(item.bag, item.slot)
                end)
            end
            if totalEarned > 0 then
                local g = math.floor(totalEarned / 10000)
                local s = math.floor((totalEarned % 10000) / 100)
                local c = totalEarned % 100
                print(string.format("|cFFE5E7EB[AkcQOL]|r Vendor trash sold: %dg %ds %dc", g, s, c))
            end
        end
    end

    if doRepair and CanMerchantRepair() then
        local cost, canRepair = GetRepairAllCost()
        if canRepair and cost > 0 then
            if IsInGuild() and CanGuildBankRepair() and GetGuildBankWithdrawMoney() >= cost then
                RepairAllItems(true)
                print("|cFFE5E7EB[AkcQOL]|r Items repaired using guild bank funds.")
            elseif GetMoney() >= cost then
                RepairAllItems(false)
                local rG = math.floor(cost / 10000)
                local rS = math.floor((cost % 10000) / 100)
                print(string.format("|cFFE5E7EB[AkcQOL]|r Items repaired. Cost: %dg %ds", rG, rS))
            end
        end
    end
end)

local FastLootFrame = CreateFrame("Frame")
FastLootFrame:SetScript("OnEvent", function()
    local numItems = GetNumLootItems()
    if numItems > 0 then
        for i = numItems, 1, -1 do
            LootSlot(i)
        end
    end
end)

function _G.Enrage_ApplyFastLoot()
    if EnrageDB and EnrageDB.global and EnrageDB.global.fastLoot then
        FastLootFrame:RegisterEvent("LOOT_READY")
    else
        FastLootFrame:UnregisterEvent("LOOT_READY")
    end
end

local KEYSTONE_RETRY_INTERVAL = 0.15
local KEYSTONE_RETRY_MAX = 8
local keystoneRetryToken = 0

local KeystoneFrame = CreateFrame("Frame")

local function Enrage_IsAutoKeystoneEnabled()
    return not (EnrageDB and EnrageDB.global and EnrageDB.global.autoInsertKeystone == false)
end

local function Enrage_FindKeystoneInBags()
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then
        return nil, nil
    end
    if not C_Item or not C_Item.IsItemKeystoneByID then
        return nil, nil
    end

    local bagStart = BACKPACK_CONTAINER or 0
    local bagEnd = NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4

    for bag = bagStart, bagEnd do
        local numSlots = C_Container.GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local itemInfo = C_Container.GetContainerItemInfo(bag, slot)
            local itemID = itemInfo and itemInfo.itemID
            if itemID and C_Item.IsItemKeystoneByID(itemID) then
                if C_ChallengeMode and C_ChallengeMode.CanUseKeystoneInCurrentMap and ItemLocation and ItemLocation.CreateFromBagAndSlot then
                    local itemLocation = ItemLocation:CreateFromBagAndSlot(bag, slot)
                    if itemLocation and C_ChallengeMode.CanUseKeystoneInCurrentMap(itemLocation) then
                        return bag, slot
                    end
                else
                    return bag, slot
                end
            end
        end
    end

    return nil, nil
end

local function Enrage_TryAutoInsertKeystone()
    if not Enrage_IsAutoKeystoneEnabled() then return false end
    if C_MythicPlus and C_MythicPlus.GetOwnedKeystoneLevel and not C_MythicPlus.GetOwnedKeystoneLevel() then
        return false
    end
    if not C_ChallengeMode or not C_ChallengeMode.SlotKeystone or not C_ChallengeMode.HasSlottedKeystone then
        return false
    end
    if not C_Container or not C_Container.PickupContainerItem then
        return false
    end
    if C_ChallengeMode.HasSlottedKeystone() then
        return true
    end
    if CursorHasItem and CursorHasItem() then
        return false
    end

    local bag, slot = Enrage_FindKeystoneInBags()
    if not bag or not slot then
        return false
    end

    C_Container.PickupContainerItem(bag, slot)

    if CursorHasItem and CursorHasItem() then
        C_ChallengeMode.SlotKeystone()
        if C_ChallengeMode.HasSlottedKeystone() then
            return true
        end

        if C_Container and C_Container.PickupContainerItem then
            C_Container.PickupContainerItem(bag, slot)
        end
    end

    return false
end

local function Enrage_ScheduleAutoInsertKeystone()
    if not Enrage_IsAutoKeystoneEnabled() then return end

    keystoneRetryToken = keystoneRetryToken + 1
    local token = keystoneRetryToken

    local function Attempt(remaining)
        if token ~= keystoneRetryToken then return end
        if not Enrage_IsAutoKeystoneEnabled() then return end
        if C_ChallengeMode and C_ChallengeMode.HasSlottedKeystone and C_ChallengeMode.HasSlottedKeystone() then
            return
        end

        if Enrage_TryAutoInsertKeystone() then
            return
        end

        if remaining > 0 and C_Timer and C_Timer.After then
            C_Timer.After(KEYSTONE_RETRY_INTERVAL, function()
                Attempt(remaining - 1)
            end)
        end
    end

    Attempt(KEYSTONE_RETRY_MAX)
end

_G.Enrage_TryAutoInsertKeystone = Enrage_TryAutoInsertKeystone
_G.Enrage_ScheduleAutoInsertKeystone = Enrage_ScheduleAutoInsertKeystone

KeystoneFrame:RegisterEvent("CHALLENGE_MODE_KEYSTONE_RECEPTABLE_OPEN")
KeystoneFrame:RegisterEvent("CHALLENGE_MODE_KEYSTONE_SLOTTED")
KeystoneFrame:SetScript("OnEvent", function(_, event)
    if event == "CHALLENGE_MODE_KEYSTONE_RECEPTABLE_OPEN" then
        Enrage_ScheduleAutoInsertKeystone()
    elseif event == "CHALLENGE_MODE_KEYSTONE_SLOTTED" then
        keystoneRetryToken = keystoneRetryToken + 1
    end
end)

local CinematicFrame = CreateFrame("Frame")
CinematicFrame:RegisterEvent("CINEMATIC_START")
CinematicFrame:RegisterEvent("PLAY_MOVIE")
CinematicFrame:SetScript("OnEvent", function(self, event)
    local doSkip = true
    if EnrageDB and EnrageDB.global then
        if EnrageDB.global.autoCinematic == false then doSkip = false end
    end

    if doSkip then
        if event == "CINEMATIC_START" then
            if CanCancelScene and CanCancelScene() then
                CancelScene()
            end
            StopCinematic()
        elseif event == "PLAY_MOVIE" then
            if MovieFrame then
                if MovieFrame.StopMovie then
                    MovieFrame:StopMovie()
                elseif MovieFrame.Stop then
                    MovieFrame:Stop()
                end
            end
            if GameMovieFinished then GameMovieFinished() end
        end
    end
end)

-- =========================================================================
-- LOG SYSTEM: MAIL, TRADE, LOOT
-- =========================================================================
-- Shared visuals are defined here so log windows can use them too.
local WV_FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local WV_FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local WV_LIST_FONT_FACE = "Fonts\\ARIALN.TTF"
local WV_FONT_FLAGS = "OUTLINE"

-- Locale-aware lowercase for common UTF-8 search cases.
local function TRLower(s)
    if not s then return "" end
    s = s:gsub("\195\135", "\195\167")   -- C cedilla upper -> lower
    s = s:gsub("\196\158", "\196\159")   -- G breve upper -> lower
    s = s:gsub("\196\176", "i")          -- dotted I upper -> i
    s = s:gsub("\195\150", "\195\182")   -- O umlaut upper -> lower
    s = s:gsub("\197\158", "\197\159")   -- S cedilla upper -> lower
    s = s:gsub("\195\156", "\195\188")   -- U umlaut upper -> lower
    return s:lower()
end

local function WV_CreateBorder(parent, p1, r1, p2, r2, w, h)
    local b = parent:CreateTexture(nil, "BORDER")
    b:SetTexture(WV_FLAT_TEX)
    -- Glass Slate: single subtle medium grey border
    b:SetVertexColor(0.227, 0.239, 0.267, 1)  -- #3A3D44
    b:SetPoint(p1, parent, r1)
    b:SetPoint(p2, parent, r2)
    if w then b:SetWidth(w) end
    if h then b:SetHeight(h) end
    return b
end

local CHAT_LOG_CHANNELS = {
    { key = "guild",   label = "Guild",   event = "CHAT_MSG_GUILD",         color = {0.25, 1.0, 0.25} },
    { key = "party",   label = "Party",   event = "CHAT_MSG_PARTY",         color = {0.4, 0.6, 1.0} },
    { key = "raid",    label = "Raid",    event = "CHAT_MSG_RAID",          color = {1.0, 0.5, 0.0} },
    { key = "whisper", label = "Whisper", event = "CHAT_MSG_WHISPER",       color = {1.0, 0.5, 1.0} },
    { key = "say",     label = "Say",     event = "CHAT_MSG_SAY",           color = {1.0, 1.0, 1.0} },
    { key = "yell",    label = "Yell",    event = "CHAT_MSG_YELL",          color = {1.0, 0.25, 0.25} },
    -- Officer removed: officer messages are protected by Blizzard and unreadable.
    { key = "instance",label = "Instance",event = "CHAT_MSG_INSTANCE_CHAT", color = {1.0, 0.6, 0.2} },
    { key = "bnet",    label = "Battle.net", event = "CHAT_MSG_BN_WHISPER", color = {0.35, 0.8, 1.0} },
}
local CHAT_LOG_ALL_CHANNEL = { key = "all", label = "All", color = {0.86, 0.88, 0.94} }

local ENRAGE_CHARACTER_LOG_TYPES = {
    mail = true,
    trade = true,
    loot = true,
}

ENRAGE_LOG_LIMITS = ENRAGE_LOG_LIMITS or {
    mail = 500,
    trade = 500,
    loot = 1000,
}
ENRAGE_LOG_BUCKET_SYNCED = ENRAGE_LOG_BUCKET_SYNCED or {}

function Enrage_GetLogLimit(logType)
    return ENRAGE_LOG_LIMITS[logType] or 200
end

local function Enrage_EarlyCleanString(value)
    if value == nil then return nil end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return nil end
    end
    local ok, text = pcall(tostring, value)
    if ok and text and text ~= "" then return text end
    return nil
end

local function Enrage_GetCharFromLogEntry(entry)
    local clean = Enrage_EarlyCleanString(entry)
    if not clean then return nil end
    local ok, charTag = pcall(string.match, clean, "^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d%s+%[([^%]]+)%]")
    if ok then return charTag end
    return nil
end

local function Enrage_StoreLogEntryByChar(logType, entry, insertFirst)
    entry = Enrage_EarlyCleanString(entry)
    if not ENRAGE_CHARACTER_LOG_TYPES[logType] or not entry then return end
    if not EnrageDB or not EnrageDB.global then return end
    if not EnrageDB.global.logsByChar then EnrageDB.global.logsByChar = {} end
    if not EnrageDB.global.logsByChar[logType] then EnrageDB.global.logsByChar[logType] = {} end

    local charTag = Enrage_GetCharFromLogEntry(entry)
    if not charTag or charTag == "" then return end

    local byType = EnrageDB.global.logsByChar[logType]
    if not byType[charTag] then byType[charTag] = {} end
    local list = byType[charTag]

    for i = 1, #list do
        if list[i] == entry then return end
    end

    if insertFirst == false then
        list[#list + 1] = entry
    else
        table.insert(list, 1, entry)
    end
    local limit = Enrage_GetLogLimit(logType)
    while #list > limit do table.remove(list) end
end

function Enrage_SyncLogBuckets(logType)
    if not ENRAGE_CHARACTER_LOG_TYPES[logType] then return end
    if not EnrageDB or not EnrageDB.global or not EnrageDB.global.logs then return end
    local entries = EnrageDB.global.logs[logType]
    if type(entries) ~= "table" then return end
    for _, entry in ipairs(entries) do
        Enrage_StoreLogEntryByChar(logType, entry, false)
    end
end

local function EnsureLogDB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    if not EnrageDB.global.logs then EnrageDB.global.logs = {} end
    if not EnrageDB.global.logs.mail then EnrageDB.global.logs.mail = {} end
    if not EnrageDB.global.logs.trade then EnrageDB.global.logs.trade = {} end
    if not EnrageDB.global.logs.loot then EnrageDB.global.logs.loot = {} end
    if not EnrageDB.global.logsByChar then EnrageDB.global.logsByChar = {} end
    if not EnrageDB.global.logsByCharMigrated then EnrageDB.global.logsByCharMigrated = {} end
    for logType in pairs(ENRAGE_CHARACTER_LOG_TYPES) do
        if not EnrageDB.global.logsByChar[logType] then EnrageDB.global.logsByChar[logType] = {} end
        if not EnrageDB.global.logsByCharMigrated[logType] then
            for _, entry in ipairs(EnrageDB.global.logs[logType] or {}) do
                Enrage_StoreLogEntryByChar(logType, entry, false)
            end
            EnrageDB.global.logsByCharMigrated[logType] = true
        end
        if not ENRAGE_LOG_BUCKET_SYNCED[logType] then
            Enrage_SyncLogBuckets(logType)
            ENRAGE_LOG_BUCKET_SYNCED[logType] = true
        end
    end
    if not EnrageDB.global.logs.chat then EnrageDB.global.logs.chat = {} end
    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
        if not EnrageDB.global.logs.chat[ch.key] then EnrageDB.global.logs.chat[ch.key] = {} end
    end
end

local function AddLogEntry(logType, text)
    text = Enrage_EarlyCleanString(text)
    if not text then return end
    EnsureLogDB()
    local t = EnrageDB.global.logs[logType]
    local name, realm = UnitFullName("player")
    local charTag = (realm and realm ~= "") and (name .. "-" .. realm) or (name or "Unknown")
    local entry = date("%Y-%m-%d %H:%M:%S") .. " [" .. charTag .. "] - " .. text
    table.insert(t, 1, entry)
    Enrage_StoreLogEntryByChar(logType, entry, true)
    local limit = Enrage_GetLogLimit(logType)
    while #t > limit do table.remove(t) end
end

local function Enrage_GetChatChannelInfo(key)
    if key == "all" then return CHAT_LOG_ALL_CHANNEL end
    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
        if ch.key == key then return ch end
    end
    return CHAT_LOG_ALL_CHANNEL
end

-- Chat event -> channel key mapping
local CHAT_EVENT_MAP = {}
for _, ch in ipairs(CHAT_LOG_CHANNELS) do
    CHAT_EVENT_MAP[ch.event] = ch.key
    CHAT_EVENT_MAP[ch.event .. "_LEADER"] = ch.key
end
CHAT_EVENT_MAP["CHAT_MSG_RAID_WARNING"] = "raid"
CHAT_EVENT_MAP["CHAT_MSG_WHISPER_INFORM"] = "whisper"
CHAT_EVENT_MAP["CHAT_MSG_BN_WHISPER"] = "bnet"
CHAT_EVENT_MAP["CHAT_MSG_BN_WHISPER_INFORM"] = "bnet"

-- Safely extract a clean string from a potentially tainted/secret value.
-- Returns a plain Lua string that is guaranteed untainted, or fallback on failure.
local function CleanStr(val, fallback)
    if val == nil then return fallback or "?" end
    local function IsSecret(v)
        if type(issecretvalue) ~= "function" then return false end
        local okSecret, isSecret = pcall(issecretvalue, v)
        return okSecret and isSecret
    end
    if IsSecret(val) then return fallback end

    -- Try 1: direct tostring + byte/char rebuild (works for tainted but not secret)
    local ok1, result1 = pcall(function()
        local s = tostring(val)
        if IsSecret(s) then return nil end
        local len = string.len(s)
        if len == 0 then return fallback or "?" end
        local parts = {}
        for i = 1, len, 200 do
            local hi = i + 199
            if hi > len then hi = len end
            parts[#parts + 1] = string.char(string.byte(s, i, hi))
        end
        return table.concat(parts)
    end)
    if ok1 and result1 and result1 ~= "" and not IsSecret(result1) then return result1 end
    -- Try 2: string.format %s (sometimes works when tostring doesn't)
    local ok2, result2 = pcall(string.format, "%s", val)
    if ok2 and result2 and not IsSecret(result2) then
        local ok3, clean = pcall(function()
            local len = string.len(result2)
            if len == 0 then return fallback or "?" end
            local parts = {}
            for i = 1, len, 200 do
                local hi = i + 199
                if hi > len then hi = len end
                parts[#parts + 1] = string.char(string.byte(result2, i, hi))
            end
            return table.concat(parts)
        end)
        if ok3 and clean and clean ~= "" and not IsSecret(clean) then return clean end
    end
    return fallback or "?"
end

function Enrage_IsProtectedChatPayloadText(text)
    local clean = CleanStr(text, nil)
    if not clean or clean == "" then return false end
    clean = clean:gsub("^%s+", ""):gsub("%s+$", "")
    return clean:match("^|K[^|]+|k$") ~= nil
end

function Enrage_GetProtectedChatMessage(channelKey)
    if channelKey == "officer" then
        return "[Officer message protected by Blizzard]"
    end
    return "[Chat message protected by Blizzard]"
end

function Enrage_ExtractChatLineMessage(lineText, author)
    local line = CleanStr(lineText, nil)
    if not line or line == "" or Enrage_IsProtectedChatPayloadText(line) then return nil end

    line = line:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    local safeAuthor = CleanStr(author, nil)
    if safeAuthor and safeAuthor ~= "" then
        local baseAuthor = safeAuthor:match("^([^-]+)") or safeAuthor
        if line:find(safeAuthor, 1, true) or line:find(baseAuthor, 1, true) then
            local msg = line:match(":%s*(.+)$")
            if msg and msg ~= "" and not Enrage_IsProtectedChatPayloadText(msg) then
                return msg
            end
        end
    end

    return nil
end

function Enrage_NormalizeChatBodyForStorage(channelKey, msg, author, lineID)
    local safeMsg = msg ~= nil and CleanStr(msg, nil) or nil
    if safeMsg and safeMsg ~= "" and not Enrage_IsProtectedChatPayloadText(safeMsg) then
        return safeMsg
    end

    local numericLineID = tonumber(lineID)
    if numericLineID and C_ChatInfo and C_ChatInfo.GetChatLineText then
        local ok, lineText = pcall(C_ChatInfo.GetChatLineText, numericLineID)
        if ok then
            local fromLine = Enrage_ExtractChatLineMessage(lineText, author)
            if fromLine and fromLine ~= "" then return fromLine end
        end
    end

    if safeMsg and Enrage_IsProtectedChatPayloadText(safeMsg) then
        return Enrage_GetProtectedChatMessage(channelKey)
    end

    return safeMsg
end

function Enrage_NormalizeStoredChatBody(channelKey, body)
    local clean = Enrage_UntaintLog and Enrage_UntaintLog(body) or CleanStr(body, "")
    if Enrage_IsProtectedChatPayloadText(clean) then
        return Enrage_GetProtectedChatMessage(channelKey)
    end
    return clean or ""
end

local function GetChatChannelKey(event)
    local safeEvent = CleanStr(event, nil)
    if not safeEvent then return nil, nil end

    if safeEvent == "CHAT_MSG_GUILD" then return "guild", safeEvent end
    if safeEvent == "CHAT_MSG_PARTY" or safeEvent == "CHAT_MSG_PARTY_LEADER" then return "party", safeEvent end
    if safeEvent == "CHAT_MSG_RAID" or safeEvent == "CHAT_MSG_RAID_LEADER" or safeEvent == "CHAT_MSG_RAID_WARNING" then return "raid", safeEvent end
    if safeEvent == "CHAT_MSG_WHISPER" or safeEvent == "CHAT_MSG_WHISPER_INFORM" then return "whisper", safeEvent end
    if safeEvent == "CHAT_MSG_BN_WHISPER" or safeEvent == "CHAT_MSG_BN_WHISPER_INFORM" then return "bnet", safeEvent end
    if safeEvent == "CHAT_MSG_SAY" then return "say", safeEvent end
    if safeEvent == "CHAT_MSG_YELL" then return "yell", safeEvent end
    if safeEvent == "CHAT_MSG_OFFICER" then return "officer", safeEvent end
    if safeEvent == "CHAT_MSG_INSTANCE_CHAT" or safeEvent == "CHAT_MSG_INSTANCE_CHAT_LEADER" then return "instance", safeEvent end

    return nil, safeEvent
end

-- Core function to record a chat event into the DB
local function RecordChatEvent(event, msg, author, targetName, lineID)
    local channelKey, safeEvent = GetChatChannelKey(event)
    if not channelKey then return end

    local safeAuthor = CleanStr(author, "?")
    local safeTarget = CleanStr(targetName, nil)
    local safeMsg = Enrage_NormalizeChatBodyForStorage(channelKey, msg, author, lineID)
    if not safeMsg or safeMsg == "" then return end

    if safeEvent == "CHAT_MSG_WHISPER_INFORM" or safeEvent == "CHAT_MSG_BN_WHISPER_INFORM" then
        if not safeTarget or safeTarget == "" or safeTarget == "?" then
            safeTarget = safeAuthor
        end
        safeAuthor = "To " .. safeTarget
    end

    EnsureLogDB()
    local t = EnrageDB.global.logs.chat[channelKey]
    if not t then return end
    local entry = date("%Y-%m-%d %H:%M:%S") .. " [" .. safeAuthor .. "] " .. safeMsg
    table.insert(t, 1, entry)
    while #t > 500 do table.remove(t) end
end

-- Single event frame for all chat channels
local ChatLogEventFrame = CreateFrame("Frame")
local ALL_CHAT_EVENTS = {
    "CHAT_MSG_GUILD", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_SAY", "CHAT_MSG_YELL",
    "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER",
    "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM",
}
for _, ev in ipairs(ALL_CHAT_EVENTS) do
    ChatLogEventFrame:RegisterEvent(ev)
end
ChatLogEventFrame:SetScript("OnEvent", function(self, event, msg, author, languageName, channelName, targetName, ...)
    local lineID = select(6, ...)
    local ok, err = pcall(RecordChatEvent, event, msg, author, targetName, lineID)
    if not ok then
        if _G.Enrage_RecordLuaError then
            pcall(_G.Enrage_RecordLuaError, "Chat Log Error", CleanStr(err, "ChatLog failed on a secret chat value."), "", "AkcQOL")
        end
    end
end)

local ENRAGE_LOG_NAV = {
    { key = "matrix", label = "Matrix", icon = "Interface\\Icons\\INV_Misc_Map_01",        color = {0.96, 0.62, 0.04} },
    { key = "mail",  label = "Mail",  icon = "Interface\\Icons\\INV_Letter_15",           color = {0.35, 0.68, 1.00} },
    { key = "trade", label = "Trade", icon = "Interface\\Icons\\INV_Misc_Coin_01",        color = {1.00, 0.82, 0.18} },
    { key = "loot",  label = "Loot",  icon = "Interface\\Icons\\INV_Box_01",              color = {0.38, 1.00, 0.42} },
    { key = "chat",  label = "Chat",  icon = "Interface\\Icons\\INV_Misc_Note_06",        color = {1.00, 0.54, 1.00} },
    { key = "lua",   label = "Lua",   icon = "Interface\\Icons\\INV_Misc_Bomb_01",        color = {1.00, 0.38, 0.30} },
}

local ENRAGE_LOG_TITLES = {
    matrix = "Matrix",
    mail = "Mail Log",
    trade = "Trade Log",
    loot = "Loot Log",
    chat = "Chat Log",
    lua = "Lua Errors",
    settings = "Settings",
}

local ENRAGE_LOG_EXPORT_FRAME
local Enrage_ShowLogsWindow

local function Enrage_ColorHex(color)
    local r = math.floor((color[1] or 1) * 255 + 0.5)
    local g = math.floor((color[2] or 1) * 255 + 0.5)
    local b = math.floor((color[3] or 1) * 255 + 0.5)
    return string.format("%02x%02x%02x", r, g, b)
end

local function Enrage_ColorText(color, text)
    return "|cFF" .. Enrage_ColorHex(color) .. tostring(text or "") .. "|r"
end

local function Enrage_GetLogColor(key)
    for _, item in ipairs(ENRAGE_LOG_NAV) do
        if item.key == key then return item.color end
    end
    return {0.96, 0.62, 0.04}
end

local function Enrage_GetPlayerTag()
    local name, realm = UnitFullName("player")
    if name and realm and realm ~= "" then return name .. "-" .. realm end
    return name or "Unknown"
end

local function Enrage_UntaintLog(v)
    if v == nil then return nil end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, v)
        if okSecret and isSecret then return nil end
    end

    local ok, clean = pcall(function()
        local text = tostring(v)
        return string.format("%s", text)
    end)
    if ok and clean and clean ~= "" then return clean end
    return nil
end

local function Enrage_Utf8CharSize(text, index)
    local b1 = text and text:byte(index)
    if not b1 then return 0 end
    if b1 < 0x80 then return 1 end

    local function IsCont(offset)
        local b = text:byte(index + offset)
        return b and b >= 0x80 and b <= 0xBF
    end

    if b1 >= 0xC2 and b1 <= 0xDF and IsCont(1) then return 2 end
    if b1 >= 0xE0 and b1 <= 0xEF and IsCont(1) and IsCont(2) then return 3 end
    if b1 >= 0xF0 and b1 <= 0xF4 and IsCont(1) and IsCont(2) and IsCont(3) then return 4 end
    return 1
end

local function Enrage_TruncateUtf8(text, maxChars)
    local clean = Enrage_UntaintLog(text) or ""
    local len = clean:len()
    local index, chars = 1, 0

    while index <= len do
        if chars >= maxChars then
            return clean:sub(1, index - 1) .. "..."
        end
        local size = Enrage_Utf8CharSize(clean, index)
        if size <= 0 then break end
        index = index + size
        chars = chars + 1
    end

    return clean
end

local function Enrage_CallFrameMethod(frame, method, ...)
    local fn = frame and frame[method]
    if fn then pcall(fn, frame, ...) end
end

local function Enrage_DisableMouseTree(frame)
    if not frame or frame.enrageMouseRestore then return end
    frame.enrageMouseRestore = {}

    local function SaveAndDisable(child)
        if not child then return end

        local entry = { frame = child }
        local shouldRestore = false

        if child.IsMouseEnabled then
            local ok, enabled = pcall(child.IsMouseEnabled, child)
            if ok then
                entry.mouse = enabled
                shouldRestore = shouldRestore or enabled
            end
        elseif child.EnableMouse then
            entry.mouse = true
            shouldRestore = true
        end

        if child.IsMouseClickEnabled then
            local ok, enabled = pcall(child.IsMouseClickEnabled, child)
            if ok then
                entry.click = enabled
                shouldRestore = shouldRestore or enabled
            end
        end

        if child.IsMouseMotionEnabled then
            local ok, enabled = pcall(child.IsMouseMotionEnabled, child)
            if ok then
                entry.motion = enabled
                shouldRestore = shouldRestore or enabled
            end
        end

        if child.IsMouseWheelEnabled then
            local ok, enabled = pcall(child.IsMouseWheelEnabled, child)
            if ok then
                entry.wheel = enabled
                shouldRestore = shouldRestore or enabled
            end
        elseif child.EnableMouseWheel then
            entry.wheel = true
            shouldRestore = true
        end

        if shouldRestore then
            frame.enrageMouseRestore[#frame.enrageMouseRestore + 1] = entry
        end

        Enrage_CallFrameMethod(child, "SetMouseClickEnabled", false)
        Enrage_CallFrameMethod(child, "SetMouseMotionEnabled", false)
        Enrage_CallFrameMethod(child, "EnableMouseWheel", false)
        Enrage_CallFrameMethod(child, "EnableMouse", false)
    end

    local function Walk(parent)
        if not parent or not parent.GetChildren then return end
        local ok, children = pcall(function() return { parent:GetChildren() } end)
        if not ok or type(children) ~= "table" then return end
        for _, child in ipairs(children) do
            SaveAndDisable(child)
            Walk(child)
        end
    end

    SaveAndDisable(frame)
    Walk(frame)
end

local function Enrage_RestoreMouseTree(frame)
    local restore = frame and frame.enrageMouseRestore
    if type(restore) ~= "table" then return end
    for _, entry in ipairs(restore) do
        local child = entry
        local mouse, click, motion, wheel = true, nil, nil, nil
        if type(entry) == "table" and entry.frame then
            child = entry.frame
            mouse = entry.mouse
            click = entry.click
            motion = entry.motion
            wheel = entry.wheel
        end
        if mouse ~= nil then Enrage_CallFrameMethod(child, "EnableMouse", mouse) end
        if wheel ~= nil then Enrage_CallFrameMethod(child, "EnableMouseWheel", wheel) end
        if click ~= nil then Enrage_CallFrameMethod(child, "SetMouseClickEnabled", click) end
        if motion ~= nil then Enrage_CallFrameMethod(child, "SetMouseMotionEnabled", motion) end
    end
    frame.enrageMouseRestore = nil
end

local function Enrage_ParkFrameOffscreen(frame)
    if not frame or frame.enrageSoftHiddenParked then return end
    frame.enrageSoftHiddenParked = true
    frame.enrageRestorePoints = {}

    if frame.GetNumPoints and frame.GetPoint then
        local okCount, count = pcall(frame.GetNumPoints, frame)
        if okCount and count and count > 0 then
            for i = 1, count do
                local okPoint, point, relativeTo, relativePoint, xOfs, yOfs = pcall(frame.GetPoint, frame, i)
                if okPoint and point then
                    frame.enrageRestorePoints[#frame.enrageRestorePoints + 1] = {
                        point = point,
                        relativeTo = relativeTo,
                        relativePoint = relativePoint,
                        xOfs = xOfs,
                        yOfs = yOfs,
                    }
                end
            end
        end
    end

    if frame.IsClampedToScreen then
        local okClamp, clamped = pcall(frame.IsClampedToScreen, frame)
        if okClamp then frame.enrageRestoreClamped = clamped end
    end

    Enrage_CallFrameMethod(frame, "SetClampedToScreen", false)
    Enrage_CallFrameMethod(frame, "ClearAllPoints")
    Enrage_CallFrameMethod(frame, "SetPoint", "TOPLEFT", UIParent, "BOTTOMRIGHT", 4096, 4096)
end

local function Enrage_RestoreFramePosition(frame)
    if not frame or not frame.enrageSoftHiddenParked then return end

    Enrage_CallFrameMethod(frame, "ClearAllPoints")
    local restored = false
    local points = frame.enrageRestorePoints
    if type(points) == "table" then
        for _, p in ipairs(points) do
            if p and p.point then
                local ok = pcall(frame.SetPoint, frame, p.point, p.relativeTo, p.relativePoint, p.xOfs or 0, p.yOfs or 0)
                restored = restored or ok
            end
        end
    end
    if not restored then
        Enrage_CallFrameMethod(frame, "SetPoint", "CENTER", UIParent, "CENTER", 0, 0)
    end

    if frame.enrageRestoreClamped ~= nil then
        Enrage_CallFrameMethod(frame, "SetClampedToScreen", frame.enrageRestoreClamped)
    end

    frame.enrageRestorePoints = nil
    frame.enrageRestoreClamped = nil
    frame.enrageSoftHiddenParked = nil
end

local function Enrage_SafeHideFrame(frame)
    if not frame then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        -- Frame may parent SecureActionButtons, so real Hide()/move is blocked in
        -- combat. Best-effort soft-hide: invisible + mouse off + park offscreen.
        -- Secure teleport buttons are hidden in combat by their own visibility
        -- state driver (see teleportSecureHost), so they don't catch clicks while
        -- the frame is soft-hidden. The real Hide()/restore runs at combat end via
        -- the PLAYER_REGEN_ENABLED handler.
        frame.enrageSoftHidden = true
        Enrage_CallFrameMethod(frame, "SetAlpha", 0)
        Enrage_DisableMouseTree(frame)
        Enrage_ParkFrameOffscreen(frame)
        Enrage_CallFrameMethod(frame, "Hide")
        return
    end
    Enrage_RestoreMouseTree(frame)
    Enrage_RestoreFramePosition(frame)
    frame.enrageSoftHidden = false
    Enrage_CallFrameMethod(frame, "SetAlpha", 1)
    Enrage_CallFrameMethod(frame, "EnableMouse", true)
    Enrage_CallFrameMethod(frame, "Hide")
end

local function Enrage_SafeShowFrame(frame)
    if not frame then return end
    frame.enrageSoftHidden = false
    Enrage_RestoreMouseTree(frame)
    Enrage_RestoreFramePosition(frame)
    Enrage_CallFrameMethod(frame, "SetAlpha", 1)
    Enrage_CallFrameMethod(frame, "EnableMouse", true)
    Enrage_CallFrameMethod(frame, "Show")
end

local function Enrage_IsFrameOpen(frame)
    return frame and frame.IsShown and frame:IsShown() and not frame.enrageSoftHidden
end

function Enrage_ScrollFrameToBottom(scrollFrame)
    if not scrollFrame or not scrollFrame.SetVerticalScroll then return end

    local function Apply()
        if not scrollFrame or not scrollFrame.SetVerticalScroll then return end
        if scrollFrame.UpdateScrollChildRect then
            pcall(scrollFrame.UpdateScrollChildRect, scrollFrame)
        end
        local range = 0
        if scrollFrame.GetVerticalScrollRange then
            range = scrollFrame:GetVerticalScrollRange() or 0
        end
        scrollFrame:SetVerticalScroll(range)
    end

    Apply()
    if C_Timer and C_Timer.After then
        C_Timer.After(0, Apply)
        C_Timer.After(0.05, Apply)
    end
end

local function Enrage_ParseLogEntry(raw)
    local clean = Enrage_UntaintLog(raw) or ""
    local dt, char, text = clean:match("^(%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d)%s+%[([^%]]+)%]%s+%-%s+(.*)$")
    if dt then return dt, char, text end

    dt, text = clean:match("^(%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d)%s+(.+)$")
    if dt then return dt, "", text end

    return "", "", clean
end

local function Enrage_ParseChatLogEntry(raw)
    local clean = Enrage_UntaintLog(raw) or ""
    local dt, author, body = clean:match("^(%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d)%s+%[([^%]]+)%]%s*(.*)$")
    return dt or "", author or "", body or clean, clean
end

local function Enrage_NormalizeChatPerson(author)
    local clean = Enrage_UntaintLog(author) or ""
    clean = clean:gsub("^%s+", ""):gsub("%s+$", "")
    clean = clean:gsub("^To:%s*", ""):gsub("^To%s+", "")
    clean = clean:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    return clean ~= "" and clean or "Unknown"
end

local function Enrage_GetChatNameKeys(name)
    local clean = Enrage_NormalizeChatPerson(name)
    local full = TRLower(clean):gsub("%s+", "")
    local base = full:match("^([^-]+)") or full
    local hasRealm = clean:find("-", 1, true) and true or false
    return full, base, hasRealm
end

local function Enrage_IsOwnChatPerson(name)
    local full, base, hasRealm = Enrage_GetChatNameKeys(name)
    if full == "" or full == "unknown" then return false end

    local playerFull, playerBase = Enrage_GetChatNameKeys(Enrage_GetPlayerTag())
    if full == playerFull or (not hasRealm and base == playerBase) then
        return true
    end

    if type(EnrageDB) == "table" then
        for char, data in pairs(EnrageDB) do
            if type(char) == "string" and type(data) == "table" and char ~= "global" and char ~= "hiddenChars" then
                local charFull, charBase = Enrage_GetChatNameKeys(char)
                if full == charFull or (not hasRealm and base == charBase) then
                    return true
                end
            end
        end
    end

    return false
end

local function Enrage_GetChatConversationPerson(channelKey, author)
    local person = Enrage_NormalizeChatPerson(author)
    if not person or person == "" or person == "Unknown" then return nil end

    -- Whisper lists conversations with other people; public channels list authors.
    -- Own alts are hidden only from whisper conversations, not guild/party/raid/etc.
    if channelKey == "whisper" and Enrage_IsOwnChatPerson(person) then return nil end
    return person
end

local function Enrage_IsLegacyBattleNetWhisperAuthor(author)
    local person = Enrage_NormalizeChatPerson(author)
    if not person or person == "" or person == "Unknown" then return false end
    if Enrage_IsOwnChatPerson(person) then return false end

    -- Older builds stored Battle.net whispers inside Whisper before the chat
    -- event type was persisted. Battle.net names do not carry a realm suffix.
    if person:find("-", 1, true) then return false end
    return true
end

local function Enrage_MigrateLegacyBattleNetWhispers()
    EnsureLogDB()
    local chatDB = EnrageDB and EnrageDB.global and EnrageDB.global.logs and EnrageDB.global.logs.chat
    if not chatDB or EnrageDB.global.chatBattleNetMigrated == 1 then return end

    local whisper = chatDB.whisper or {}
    local bnet = chatDB.bnet or {}
    local kept, moved = {}, {}

    for i = 1, #whisper do
        local _, author = Enrage_ParseChatLogEntry(whisper[i])
        if Enrage_IsLegacyBattleNetWhisperAuthor(author) then
            moved[#moved + 1] = whisper[i]
        else
            kept[#kept + 1] = whisper[i]
        end
    end

    if #moved > 0 then
        chatDB.whisper = kept
        for i = 1, #moved do
            bnet[#bnet + 1] = moved[i]
        end
        chatDB.bnet = bnet
    end

    EnrageDB.global.chatBattleNetMigrated = 1
end

local function Enrage_EnableLogHyperlinks(fontString, ownerFrame)
    if fontString and fontString.SetHyperlinksEnabled then
        pcall(fontString.SetHyperlinksEnabled, fontString, true)
    end
end

local EnrageLogMeasureFrame = CreateFrame("Frame")
EnrageLogMeasureFrame:Hide()
local EnrageLogMeasureText = EnrageLogMeasureFrame:CreateFontString(nil, "OVERLAY")
EnrageLogMeasureText:SetFont("Fonts\\ARIALN.TTF", 12, "")

local function Enrage_StripLogDisplayMarkup(text)
    local clean = Enrage_UntaintLog(text) or ""
    clean = clean:gsub("|c%x%x%x%x%x%x%x%x", "")
    clean = clean:gsub("|r", "")
    clean = clean:gsub("|H[^|]+|h(.-)|h", "%1")
    clean = clean:gsub("|T[^|]+|t", "")
    return clean
end

local function Enrage_IsTooltipLink(link)
    if type(link) ~= "string" then return false end
    return link:match("^item:")
        or link:match("^battlepet:")
        or link:match("^currency:")
        or link:match("^enchant:")
end

local function Enrage_MeasureLogText(text)
    EnrageLogMeasureText:SetText(text or "")
    return EnrageLogMeasureText:GetStringWidth() or 0
end

local function Enrage_ForEachTooltipLink(text, callback)
    local clean = Enrage_UntaintLog(text)
    if not clean or clean == "" then return end

    local pos = 1
    while true do
        local startPos, endPos, link, label = clean:find("|H([^|]+)|h(.-)|h", pos)
        if not startPos then break end
        if Enrage_IsTooltipLink(link) then
            callback(clean, startPos, endPos, link, label or "")
        end
        pos = endPos + 1
    end
end

local function Enrage_CollectLogLinkHotspots(rawText, bodyText)
    local hotspots = {}
    local body = Enrage_UntaintLog(bodyText) or ""

    Enrage_ForEachTooltipLink(body, function(source, startPos, endPos, link, label)
        local labelText = Enrage_StripLogDisplayMarkup(label)
        if labelText ~= "" then
            local prefixText = Enrage_StripLogDisplayMarkup(source:sub(1, startPos - 1))
            hotspots[#hotspots + 1] = {
                link = link,
                x = Enrage_MeasureLogText(prefixText),
                width = math.max(14, Enrage_MeasureLogText(labelText)),
            }
        end
    end)

    if #hotspots > 0 then return hotspots end

    local plainBody = Enrage_StripLogDisplayMarkup(body)
    local searchFrom = 1
    Enrage_ForEachTooltipLink(rawText, function(source, startPos, endPos, link, label)
        local labelText = Enrage_StripLogDisplayMarkup(label)
        if labelText ~= "" and plainBody ~= "" then
            local foundStart, foundEnd = plainBody:find(labelText, searchFrom, true)
            if not foundStart then
                foundStart, foundEnd = plainBody:find(labelText, 1, true)
            end
            if foundStart then
                local prefixText = plainBody:sub(1, foundStart - 1)
                hotspots[#hotspots + 1] = {
                    link = link,
                    x = Enrage_MeasureLogText(prefixText),
                    width = math.max(14, Enrage_MeasureLogText(labelText)),
                }
                searchFrom = (foundEnd or foundStart) + 1
            end
        end
    end)

    return hotspots
end

local function Enrage_GetLogLinkButton(row, index)
    row.linkButtons = row.linkButtons or {}
    local btn = row.linkButtons[index]
    if btn then return btn end

    btn = CreateFrame("Button", nil, row)
    btn:SetFrameLevel(row:GetFrameLevel() + 6)
    btn:EnableMouse(true)
    btn:SetScript("OnEnter", function(self)
        if not self.tooltipLink then return end
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        local ok = pcall(GameTooltip.SetHyperlink, GameTooltip, self.tooltipLink)
        if not ok or GameTooltip:NumLines() == 0 then
            GameTooltip:ClearLines()
            GameTooltip:AddLine(self.tooltipLink, 1, 1, 1)
        end
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    btn:SetScript("OnClick", function(self)
        local owner = self.ownerRow
        local raw = owner and Enrage_UntaintLog(owner.rawText)
        if raw and raw ~= "" then
            Enrage_ShowLogExport(owner.rawTitle or "Log Entry", raw)
        end
    end)

    row.linkButtons[index] = btn
    return btn
end

local function Enrage_UpdateLogLinkHotspots(row, bodyText)
    if not row then return end

    if row.linkButtons then
        for _, btn in ipairs(row.linkButtons) do
            btn:Hide()
        end
    end

    local anchor = row.linkHost or row.body
    if not anchor or not row.rawText then return end

    local hotspots = Enrage_CollectLogLinkHotspots(row.rawText, bodyText or anchor:GetText())
    for i, spot in ipairs(hotspots) do
        local btn = Enrage_GetLogLinkButton(row, i)
        btn.ownerRow = row
        btn.tooltipLink = spot.link
        btn:ClearAllPoints()
        btn:SetPoint("LEFT", anchor, "LEFT", (spot.x or 0) - 2, 0)
        btn:SetSize(math.max(16, (spot.width or 14) + 4), math.max(20, row:GetHeight() or 30))
        btn:Show()
    end
end

local function Enrage_CreateGlassButton(parent, text, width, height, color)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width, height)

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetTexture(WV_FLAT_TEX)
    border:SetVertexColor(color[1], color[2], color[3], 0.55)

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(WV_FLAT_TEX)
    bg:SetVertexColor(0.12, 0.125, 0.14, 0.96)

    local hi = btn:CreateTexture(nil, "ARTWORK")
    hi:SetPoint("TOPLEFT", 1, -1)
    hi:SetPoint("TOPRIGHT", -1, -1)
    hi:SetHeight(1)
    hi:SetTexture(WV_FLAT_TEX)
    hi:SetVertexColor(1, 1, 1, 0.08)

    local label = btn:CreateFontString(nil, "OVERLAY")
    label:SetFont(WV_FONT_FACE, 11, WV_FONT_FLAGS)
    label:SetAllPoints()
    label:SetText(text)

    btn.bg = bg
    btn.border = border
    btn.label = label
    btn:SetScript("OnEnter", function()
        bg:SetVertexColor(0.18, 0.19, 0.22, 0.98)
        border:SetVertexColor(color[1], color[2], color[3], 0.95)
    end)
    btn:SetScript("OnLeave", function()
        bg:SetVertexColor(0.12, 0.125, 0.14, 0.96)
        border:SetVertexColor(color[1], color[2], color[3], 0.55)
    end)
    return btn
end

local function Enrage_CreateLogCheckbox(parent, label, width, checked, onChanged)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width or 140, 24)
    btn.checked = checked and true or false

    local box = btn:CreateTexture(nil, "BACKGROUND")
    box:SetPoint("LEFT", 0, 0)
    box:SetSize(16, 16)
    box:SetTexture(WV_FLAT_TEX)
    box:SetVertexColor(0.07, 0.075, 0.085, 0.95)

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", box, "TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 1, -1)
    border:SetTexture(WV_FLAT_TEX)
    border:SetVertexColor(0.38, 0.4, 0.46, 0.9)

    local check = btn:CreateTexture(nil, "OVERLAY")
    check:SetPoint("CENTER", box, "CENTER", 0, 0)
    check:SetSize(18, 18)
    check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    check:SetVertexColor(1.0, 0.86, 0.24, 1)
    check:Hide()

    local text = btn:CreateFontString(nil, "OVERLAY")
    text:SetFont(WV_FONT_FACE, 11, WV_FONT_FLAGS)
    text:SetPoint("LEFT", box, "RIGHT", 8, 0)
    text:SetText("|cFFE5E7EB" .. label .. "|r")

    function btn:SetChecked(value)
        self.checked = value and true or false
        if self.checked then
            check:Show()
            border:SetVertexColor(0.96, 0.74, 0.18, 1)
        else
            check:Hide()
            border:SetVertexColor(0.38, 0.4, 0.46, 0.9)
        end
    end
    function btn:GetChecked()
        return self.checked
    end
    btn:SetScript("OnClick", function(self)
        self:SetChecked(not self:GetChecked())
        if onChanged then onChanged(self) end
    end)
    btn:SetChecked(btn.checked)
    return btn
end

local function Enrage_ShowLogExport(title, text)
    if not ENRAGE_LOG_EXPORT_FRAME then
        local f = CreateFrame("Frame", "EnrageLogExportFrame", UIParent, "BackdropTemplate")
        f:SetSize(720, 520)
        f:SetPoint("CENTER")
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:EnableMouse(true)
        f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", function(self) self:StartMoving() end)
        f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        f:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        f:SetBackdropColor(0.06, 0.065, 0.075, 0.98)
        f:SetBackdropBorderColor(0.96, 0.62, 0.04, 0.85)

        local titleText = f:CreateFontString(nil, "OVERLAY")
        titleText:SetFont(WV_FONT_FACE, 14, WV_FONT_FLAGS)
        titleText:SetPoint("TOP", 0, -14)
        f.titleText = titleText

        local close = Enrage_CreateGlassButton(f, "|cFFFF4D4DX|r", 24, 22, {1, 0.25, 0.2})
        close:SetPoint("TOPRIGHT", -10, -10)
        close:SetScript("OnClick", function() Enrage_SafeHideFrame(f) end)

        local selectAll = Enrage_CreateGlassButton(f, "|cFFE5E7EBSelect All|r", 88, 22, {0.56, 0.72, 1})
        selectAll:SetPoint("TOPRIGHT", close, "TOPLEFT", -8, 0)

        local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 12, -44)
        scroll:SetPoint("BOTTOMRIGHT", -30, 12)

        local edit = CreateFrame("EditBox", nil, scroll)
        edit:SetMultiLine(true)
        edit:SetAutoFocus(false)
        edit:SetFont("Fonts\\ARIALN.TTF", 12, "")
        edit:SetTextColor(0.92, 0.94, 0.98, 1)
        edit:SetJustifyH("LEFT")
        edit:SetJustifyV("TOP")
        edit:SetWidth(660)
        edit:SetHeight(2200)
        edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        scroll:SetScrollChild(edit)
        f.edit = edit
        f.scroll = scroll

        selectAll:SetScript("OnClick", function()
            edit:SetFocus()
            edit:HighlightText()
        end)

        ENRAGE_LOG_EXPORT_FRAME = f
    end

    ENRAGE_LOG_EXPORT_FRAME.titleText:SetText("|cFFF59E0BAkcQOL|r |cFFE5E7EB" .. tostring(title or "Export") .. "|r")
    ENRAGE_LOG_EXPORT_FRAME.edit:SetText(text or "")
    ENRAGE_LOG_EXPORT_FRAME.edit:SetCursorPosition(0)
    ENRAGE_LOG_EXPORT_FRAME.edit:HighlightText()
    ENRAGE_LOG_EXPORT_FRAME.edit:SetFocus()
    Enrage_SafeShowFrame(ENRAGE_LOG_EXPORT_FRAME)
end

local function Enrage_OpenLogTab(key)
    if key == "matrix" then
        if Enrage_ShowLogsWindow then Enrage_ShowLogsWindow("matrix") end
        return
    end
    if Enrage_ShowLogsWindow then
        Enrage_ShowLogsWindow(key)
        return
    end

    for frameKey, frame in pairs(WV_LOG_FRAMES) do
        if frameKey ~= key and frame and frame.Hide then
            Enrage_SafeHideFrame(frame)
        end
    end

    if key == "lua" then
        if _G.Enrage_ShowErrorLogWindow then _G.Enrage_ShowErrorLogWindow() end
    elseif key == "chat" then
        if Enrage_ShowChatLogWindow then Enrage_ShowChatLogWindow() end
    elseif Enrage_ShowLogWindow then
        Enrage_ShowLogWindow(key)
    end
end

local function Enrage_CreateLogNavRail(parent, activeKey)
    local rail = CreateFrame("Frame", nil, parent)
    rail:SetPoint("TOPLEFT", 0, -1)
    rail:SetPoint("BOTTOMLEFT", 0, 1)
    rail:SetWidth(54)

    local railBg = rail:CreateTexture(nil, "BACKGROUND")
    railBg:SetAllPoints()
    railBg:SetTexture(WV_FLAT_TEX)
    railBg:SetVertexColor(0.015, 0.016, 0.018, 0.96)

    local sep = rail:CreateTexture(nil, "BORDER")
    sep:SetPoint("TOPRIGHT")
    sep:SetPoint("BOTTOMRIGHT")
    sep:SetWidth(1)
    sep:SetTexture(WV_FLAT_TEX)
    sep:SetVertexColor(0.22, 0.23, 0.27, 0.9)

    local y = -36
    for _, item in ipairs(ENRAGE_LOG_NAV) do
        local btn = CreateFrame("Button", nil, rail)
        btn:SetSize(36, 36)
        btn:SetPoint("TOPLEFT", rail, "TOPLEFT", 9, y)
        y = y - 44

        local bg = btn:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture(WV_FLAT_TEX)
        bg:SetVertexColor(0.07, 0.075, 0.085, 0.78)

        local icon = btn:CreateTexture(nil, "ARTWORK")
        icon:SetPoint("CENTER")
        icon:SetSize(30, 30)
        icon:SetTexture(item.icon)

        local marker = btn:CreateTexture(nil, "OVERLAY")
        marker:SetPoint("LEFT", btn, "LEFT", -6, 0)
        marker:SetSize(3, 32)
        marker:SetTexture(WV_FLAT_TEX)
        marker:SetVertexColor(item.color[1], item.color[2], item.color[3], 1)
        marker:SetShown(item.key == activeKey)

        local isActive = item.key == activeKey
        if isActive then
            bg:SetVertexColor(item.color[1] * 0.18, item.color[2] * 0.18, item.color[3] * 0.18, 0.95)
        end

        btn:SetScript("OnClick", function()
            if item.key ~= activeKey then
                Enrage_OpenLogTab(item.key)
            end
        end)
        btn:SetScript("OnEnter", function()
            GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
            GameTooltip:AddLine(Enrage_ColorText(item.color, ENRAGE_LOG_TITLES[item.key] or item.label))
            GameTooltip:Show()
            bg:SetVertexColor(item.color[1] * 0.24, item.color[2] * 0.24, item.color[3] * 0.24, 0.98)
        end)
        btn:SetScript("OnLeave", function()
            GameTooltip:Hide()
            if isActive then
                bg:SetVertexColor(item.color[1] * 0.18, item.color[2] * 0.18, item.color[3] * 0.18, 0.95)
            else
                bg:SetVertexColor(0.07, 0.075, 0.085, 0.78)
            end
        end)
    end

    return rail
end

local ENRAGE_LOGS_FRAME

local function Enrage_MarkLuaErrorsSeenFromLogs()
    if EnrageDB and EnrageDB.global and type(EnrageDB.global.luaErrors) == "table" then
        local db = EnrageDB.global.luaErrors
        db.unreadCount = 0
        if type(db.entries) == "table" then
            for _, entry in ipairs(db.entries) do
                if type(entry) == "table" then entry.unread = false end
            end
        end
    end
    if _G.Enrage_RefreshErrorLogButton then
        pcall(_G.Enrage_RefreshErrorLogButton)
    end
end

local function Enrage_BuildLuaErrorExport(entry)
    if type(entry) ~= "table" then return "" end
    local lines = {}
    local function Add(line) lines[#lines + 1] = line or "" end
    Add("AkcQOL Lua Error Log")
    Add("")
    Add("ID: " .. tostring(entry.id or "-"))
    Add("Type: " .. tostring(entry.kind or "Lua Error"))
    Add("AddOn: " .. tostring(entry.addon or "Unknown"))
    Add("Player: " .. tostring(entry.player or "Unknown"))
    Add("First Seen: " .. tostring(entry.firstSeenText or "Unknown"))
    Add("Last Seen: " .. tostring(entry.lastSeenText or entry.firstSeenText or "Unknown"))
    Add("Count: " .. tostring(entry.count or 1))
    Add("")
    Add("Message:")
    Add(tostring(entry.message or ""))
    if entry.stack and entry.stack ~= "" then
        Add("")
        Add("Stack:")
        Add(tostring(entry.stack))
    end
    return table.concat(lines, "\n")
end

Enrage_ShowLogsWindow = function(initialTab)
    EnsureLogDB()
    initialTab = initialTab or "matrix"
    if _G.Enrage_CloseMatrixPopups then
        pcall(_G.Enrage_CloseMatrixPopups, "logs")
    end
    if initialTab ~= "matrix" and _G.WVTrackerFrame then
        Enrage_SafeHideFrame(_G.WVTrackerFrame)
    end

    if not ENRAGE_LOGS_FRAME then
        local f = CreateFrame("Frame", "EnrageLogsFrame", UIParent, "BackdropTemplate")
        f:SetSize(1280, 720)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetFrameLevel(680)
        f:SetMovable(true)
        f:EnableMouse(true)
        f:SetClampedToScreen(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", function(self) self:StartMoving() end)
        f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        f:SetResizable(true)
        if f.SetResizeBounds then
            f:SetResizeBounds(900, 520, 1700, 980)
        else
            f:SetMinResize(900, 520)
            f:SetMaxResize(1700, 980)
        end
        f:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        f:SetBackdropColor(0.025, 0.026, 0.024, 0.82)
        f:SetBackdropBorderColor(0.96, 0.62, 0.04, 0.52)
        if not EnrageDB.global.mainWindowScale then EnrageDB.global.mainWindowScale = 1.0 end
        f:SetScale(EnrageDB.global.mainWindowScale)
        tinsert(UISpecialFrames, "EnrageLogsFrame")

        local titleBar = CreateFrame("Frame", nil, f)
        titleBar:SetPoint("TOPLEFT", f, "TOPLEFT", 66, 0)
        titleBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
        titleBar:SetHeight(46)
        titleBar:EnableMouse(true)
        titleBar:RegisterForDrag("LeftButton")
        titleBar:SetScript("OnDragStart", function() f:StartMoving() end)
        titleBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

        local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")
        titleBg:SetAllPoints()
        titleBg:SetTexture(WV_FLAT_TEX)
        titleBg:SetVertexColor(0.035, 0.036, 0.033, 0.58)

        local badge = CreateFrame("Frame", nil, f)
        badge:SetSize(180, 34)
        badge:SetPoint("BOTTOM", f, "TOP", 0, -8)
        badge:EnableMouse(true)
        badge:RegisterForDrag("LeftButton")
        badge:SetScript("OnDragStart", function() f:StartMoving() end)
        badge:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
        local badgeBg = badge:CreateTexture(nil, "BACKGROUND")
        badgeBg:SetAllPoints()
        badgeBg:SetTexture(WV_FLAT_TEX)
        badgeBg:SetVertexColor(0.035, 0.036, 0.032, 0.92)
        local badgeLine = badge:CreateTexture(nil, "BORDER")
        badgeLine:SetPoint("BOTTOMLEFT")
        badgeLine:SetPoint("BOTTOMRIGHT")
        badgeLine:SetHeight(1)
        badgeLine:SetTexture(WV_FLAT_TEX)
        badgeLine:SetVertexColor(0.96, 0.62, 0.04, 0.75)
        local badgeText = badge:CreateFontString(nil, "OVERLAY")
        badgeText:SetFont(WV_FONT_FACE, 17, WV_FONT_FLAGS)
        badgeText:SetPoint("CENTER")
        badgeText:SetText("|cFFF59E0BAkcQOL|r")

        local titleText = f:CreateFontString(nil, "OVERLAY")
        titleText:SetFont(WV_FONT_FACE, 18, "OUTLINE")
        titleText:SetPoint("TOP", f, "TOP", 0, -52)
        titleText:SetWidth(520)
        titleText:SetJustifyH("CENTER")
        titleText:SetTextColor(1, 1, 1, 1)
        titleText:SetShadowColor(0, 0, 0, 1)
        titleText:SetShadowOffset(1, -1)
        f.titleText = titleText

        local closeBtn = Enrage_CreateGlassButton(titleBar, "|cFFFF4D4DX|r", 24, 22, {1.0, 0.24, 0.2})
        closeBtn:SetPoint("RIGHT", titleBar, "RIGHT", -10, 0)
        closeBtn:SetScript("OnClick", function() Enrage_SafeHideFrame(f) end)
        f.closeBtn = closeBtn

        -- Top-right "Settings" button removed: settings now live on the bottom-of-rail
        -- gear, opening in this window's right pane (see settingsNav + the "settings" tab).
        local charactersBtn = Enrage_CreateGlassButton(titleBar, "|cFFE5E7EBCharacters|r", 92, 22, {0.96, 0.62, 0.04})
        charactersBtn:SetPoint("RIGHT", closeBtn, "LEFT", -8, 0)
        charactersBtn:SetScript("OnClick", function(self)
            if _G.Enrage_ToggleMatrixCharacters then
                _G.Enrage_ToggleMatrixCharacters(self)
            end
        end)
        f.charactersBtn = charactersBtn

        local matrixBtn = Enrage_CreateGlassButton(titleBar, "|cFFE5E7EBMatrix|r", 76, 22, {0.96, 0.62, 0.04})
        matrixBtn:SetPoint("LEFT", titleBar, "LEFT", 10, 0)
        matrixBtn:SetScript("OnClick", function()
            f:SetActiveTab("matrix")
        end)
        matrixBtn:Hide()
        f.matrixBtn = matrixBtn

        local rail = CreateFrame("Frame", nil, f)
        rail:SetPoint("TOPLEFT", 0, -1)
        rail:SetPoint("BOTTOMLEFT", 0, 1)
        rail:SetWidth(66)
        local railBg = rail:CreateTexture(nil, "BACKGROUND")
        railBg:SetAllPoints()
        railBg:SetTexture(WV_FLAT_TEX)
        railBg:SetVertexColor(0.012, 0.014, 0.010, 0.42)
        local railSep = rail:CreateTexture(nil, "BORDER")
        railSep:SetPoint("TOPRIGHT")
        railSep:SetPoint("BOTTOMRIGHT")
        railSep:SetWidth(1)
        railSep:SetTexture(WV_FLAT_TEX)
        railSep:SetVertexColor(0.10, 0.10, 0.08, 0.92)
        f.navButtons = {}

        local y = -42
        for navIndex, item in ipairs(ENRAGE_LOG_NAV) do
            local btn = CreateFrame("Button", nil, rail)
            btn:SetSize(44, 44)
            btn:SetPoint("TOPLEFT", rail, "TOPLEFT", 11, y)
            y = y - 58

            btn.bg = btn:CreateTexture(nil, "BACKGROUND")
            btn.bg:SetAllPoints()
            btn.bg:SetTexture(WV_FLAT_TEX)
            btn.icon = btn:CreateTexture(nil, "ARTWORK")
            btn.icon:SetPoint("CENTER")
            btn.icon:SetSize(38, 38)
            btn.icon:SetTexture(item.icon)
            btn.marker = btn:CreateTexture(nil, "OVERLAY")
            btn.marker:SetPoint("RIGHT", btn, "LEFT", -7, 0)
            btn.marker:SetSize(5, 42)
            btn.marker:SetTexture(WV_FLAT_TEX)
            btn.marker:SetVertexColor(1.0, 0.85, 0.08, 1)
            if navIndex < #ENRAGE_LOG_NAV then
                btn.sep = rail:CreateTexture(nil, "BORDER")
                btn.sep:SetPoint("TOP", btn, "BOTTOM", 0, -7)
                btn.sep:SetSize(34, 1)
                btn.sep:SetTexture(WV_FLAT_TEX)
                btn.sep:SetVertexColor(0.62, 0.55, 0.12, 0.45)
            end
            btn.key = item.key
            btn.color = item.color
            btn.label = item.label
            btn:SetScript("OnClick", function(self)
                f:SetActiveTab(self.key)
            end)
            btn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(Enrage_ColorText(self.color, ENRAGE_LOG_TITLES[self.key] or self.label))
                GameTooltip:Show()
                self.bg:SetVertexColor(self.color[1] * 0.18, self.color[2] * 0.18, self.color[3] * 0.18, 0.86)
            end)
            btn:SetScript("OnLeave", function(self)
                GameTooltip:Hide()
                f:UpdateNav()
            end)
            f.navButtons[item.key] = btn
        end

        -- Settings gear pinned to the BOTTOM of the rail menu. Opens the settings
        -- panel docked in this window's right pane (the "settings" tab in Refresh).
        do
            local sBtn = CreateFrame("Button", nil, rail)
            sBtn:SetSize(44, 44)
            sBtn:SetPoint("BOTTOMLEFT", rail, "BOTTOMLEFT", 11, 12)
            sBtn.key = "settings"
            sBtn.color = {0.96, 0.62, 0.04}
            sBtn.label = "Settings"
            sBtn.bg = sBtn:CreateTexture(nil, "BACKGROUND")
            sBtn.bg:SetAllPoints()
            sBtn.bg:SetTexture(WV_FLAT_TEX)
            sBtn.icon = sBtn:CreateTexture(nil, "ARTWORK")
            sBtn.icon:SetPoint("CENTER")
            sBtn.icon:SetSize(34, 34)
            sBtn.icon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
            sBtn.marker = sBtn:CreateTexture(nil, "OVERLAY")
            sBtn.marker:SetPoint("RIGHT", sBtn, "LEFT", -7, 0)
            sBtn.marker:SetSize(5, 42)
            sBtn.marker:SetTexture(WV_FLAT_TEX)
            sBtn.marker:SetVertexColor(0.96, 0.62, 0.04, 1)
            local sSep = rail:CreateTexture(nil, "BORDER")
            sSep:SetPoint("BOTTOM", sBtn, "TOP", 0, 7)
            sSep:SetSize(34, 1)
            sSep:SetTexture(WV_FLAT_TEX)
            sSep:SetVertexColor(0.62, 0.55, 0.12, 0.45)
            sBtn:SetScript("OnClick", function(self) f:SetActiveTab(self.key) end)
            sBtn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(Enrage_ColorText(self.color, "Settings"))
                GameTooltip:Show()
                self.bg:SetVertexColor(self.color[1] * 0.18, self.color[2] * 0.18, self.color[3] * 0.18, 0.86)
            end)
            sBtn:SetScript("OnLeave", function()
                GameTooltip:Hide()
                f:UpdateNav()
            end)
            f.navButtons["settings"] = sBtn
        end

        local searchFrame = CreateFrame("Frame", nil, f, "BackdropTemplate")
        searchFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 86, -62)
        searchFrame:SetSize(250, 28)
        searchFrame:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        searchFrame:SetBackdropColor(0.085, 0.088, 0.095, 0.94)
        searchFrame:SetBackdropBorderColor(0.18, 0.19, 0.22, 1)
        f.searchFrame = searchFrame

        local searchLabel = searchFrame:CreateFontString(nil, "OVERLAY")
        searchLabel:SetFont(WV_FONT_FACE, 13, WV_FONT_FLAGS)
        searchLabel:SetPoint("LEFT", 9, 0)
        searchLabel:SetText("|cFF8A8F98Search|r")

        local searchBox = CreateFrame("EditBox", nil, searchFrame)
        searchBox:SetPoint("LEFT", searchLabel, "RIGHT", 8, 0)
        searchBox:SetPoint("RIGHT", searchFrame, "RIGHT", -8, 0)
        searchBox:SetHeight(22)
        searchBox:SetFont("Fonts\\ARIALN.TTF", 12, "")
        searchBox:SetTextColor(0.93, 0.94, 0.98, 1)
        searchBox:SetAutoFocus(false)
        searchBox:EnableMouse(true)
        f.searchBox = searchBox

        local filters = CreateFrame("Frame", nil, f)
        filters:SetPoint("LEFT", searchFrame, "RIGHT", 26, 0)
        filters:SetSize(470, 28)
        f.filters = filters

        f.allCharsCheck = Enrage_CreateLogCheckbox(filters, "All characters", 150, true, function()
            f:Refresh()
        end)
        f.allCharsCheck:SetPoint("LEFT", filters, "LEFT", 0, 0)

        f.todayCheck = Enrage_CreateLogCheckbox(filters, "Only show today", 160, false, function()
            f:Refresh()
        end)
        f.todayCheck:SetPoint("LEFT", f.allCharsCheck, "RIGHT", 18, 0)

        local chatTabs = CreateFrame("Frame", nil, f)
        chatTabs:SetPoint("TOPLEFT", f, "TOPLEFT", 86, -96)
        chatTabs:SetPoint("TOPRIGHT", f, "TOPRIGHT", -24, -96)
        chatTabs:SetHeight(26)
        f.chatTabs = chatTabs
        f.chatTabButtons = {}

        -- "All" channel tab removed; the row starts with the real channels.
        local chatTabItems = {}
        for _, ch in ipairs(CHAT_LOG_CHANNELS) do chatTabItems[#chatTabItems + 1] = ch end
        local tabX = 0
        for _, ch in ipairs(chatTabItems) do
            local tab = CreateFrame("Button", nil, chatTabs)
            local labelW = ch.label:len() * 7 + 18
            tab:SetSize(labelW, 20)
            tab:SetPoint("LEFT", chatTabs, "LEFT", tabX, 0)
            tabX = tabX + labelW + 5
            tab.key = ch.key
            tab.color = ch.color
            tab.bg = tab:CreateTexture(nil, "BACKGROUND")
            tab.bg:SetAllPoints()
            tab.bg:SetTexture(WV_FLAT_TEX)
            tab.border = tab:CreateTexture(nil, "BORDER")
            tab.border:SetPoint("TOPLEFT", -1, 1)
            tab.border:SetPoint("BOTTOMRIGHT", 1, -1)
            tab.border:SetTexture(WV_FLAT_TEX)
            tab.text = tab:CreateFontString(nil, "OVERLAY")
            tab.text:SetFont(WV_FONT_FACE, 10, WV_FONT_FLAGS)
            tab.text:SetAllPoints()
            tab.text:SetText(Enrage_ColorText(ch.color, ch.label))
            tab:SetScript("OnClick", function(self)
                f.activeChannel = self.key
                if self.key ~= "all" then
                    f.activeChatPerson = "all"
                end
                f:UpdateChatTabs()
                f:Refresh()
            end)
            tab:SetScript("OnEnter", function(self)
                self.bg:SetVertexColor(self.color[1] * 0.22, self.color[2] * 0.22, self.color[3] * 0.22, 0.95)
            end)
            tab:SetScript("OnLeave", function()
                f:UpdateChatTabs()
            end)
            f.chatTabButtons[#f.chatTabButtons + 1] = tab
        end

        local chatPeopleLeft = 86
        local chatPeopleWidth = 184
        local chatPeople = CreateFrame("Frame", nil, f, "BackdropTemplate")
        chatPeople:SetPoint("TOPLEFT", f, "TOPLEFT", chatPeopleLeft, -126)
        chatPeople:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", chatPeopleLeft, 56)
        chatPeople:SetWidth(chatPeopleWidth)
        chatPeople:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        chatPeople:SetBackdropColor(0.018, 0.020, 0.024, 0.58)
        chatPeople:SetBackdropBorderColor(1.0, 0.54, 1.0, 0.34)
        f.chatPeople = chatPeople
        f.chatPeopleButtons = {}
        f.chatTableLeft = chatPeopleLeft + chatPeopleWidth + 12

        local personSearchFrame = CreateFrame("Frame", nil, chatPeople, "BackdropTemplate")
        personSearchFrame:SetPoint("TOPLEFT", chatPeople, "TOPLEFT", 6, -6)
        personSearchFrame:SetPoint("TOPRIGHT", chatPeople, "TOPRIGHT", -6, -6)
        personSearchFrame:SetHeight(24)
        personSearchFrame:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        personSearchFrame:SetBackdropColor(0.075, 0.078, 0.088, 0.94)
        personSearchFrame:SetBackdropBorderColor(0.35, 0.22, 0.38, 0.75)

        local personSearchLabel = personSearchFrame:CreateFontString(nil, "OVERLAY")
        personSearchLabel:SetFont(WV_FONT_FACE, 10, WV_FONT_FLAGS)
        personSearchLabel:SetPoint("LEFT", 7, 0)
        personSearchLabel:SetText("|cFF8A8F98Search|r")

        local personSearchBox = CreateFrame("EditBox", nil, personSearchFrame)
        personSearchBox:SetPoint("LEFT", personSearchLabel, "RIGHT", 6, 0)
        personSearchBox:SetPoint("RIGHT", personSearchFrame, "RIGHT", -6, 0)
        personSearchBox:SetHeight(18)
        personSearchBox:SetFont("Fonts\\ARIALN.TTF", 11, "")
        personSearchBox:SetTextColor(0.93, 0.94, 0.98, 1)
        personSearchBox:SetAutoFocus(false)
        personSearchBox:EnableMouse(true)
        f.chatPersonSearchBox = personSearchBox

        local peopleScroll = CreateFrame("ScrollFrame", nil, chatPeople, "UIPanelScrollFrameTemplate")
        peopleScroll:SetPoint("TOPLEFT", chatPeople, "TOPLEFT", 6, -36)
        peopleScroll:SetPoint("BOTTOMRIGHT", chatPeople, "BOTTOMRIGHT", -26, 6)
        f.chatPeopleScroll = peopleScroll

        local peopleContent = CreateFrame("Frame", nil, peopleScroll)
        peopleContent:SetWidth(150)
        peopleContent:SetHeight(1)
        peopleScroll:SetScrollChild(peopleContent)
        f.chatPeopleContent = peopleContent

        local logCharsLeft = 86
        local logCharsWidth = 184
        local logChars = CreateFrame("Frame", nil, f, "BackdropTemplate")
        logChars:SetPoint("TOPLEFT", f, "TOPLEFT", logCharsLeft, -96)
        logChars:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", logCharsLeft, 56)
        logChars:SetWidth(logCharsWidth)
        logChars:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        logChars:SetBackdropColor(0.018, 0.020, 0.024, 0.58)
        logChars:SetBackdropBorderColor(0.35, 0.68, 1.0, 0.34)
        f.logChars = logChars
        f.logCharButtons = {}
        f.logTableLeft = logCharsLeft + logCharsWidth + 12

        local logCharSearchFrame = CreateFrame("Frame", nil, logChars, "BackdropTemplate")
        logCharSearchFrame:SetPoint("TOPLEFT", logChars, "TOPLEFT", 6, -6)
        logCharSearchFrame:SetPoint("TOPRIGHT", logChars, "TOPRIGHT", -6, -6)
        logCharSearchFrame:SetHeight(24)
        logCharSearchFrame:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
        logCharSearchFrame:SetBackdropColor(0.075, 0.078, 0.088, 0.94)
        logCharSearchFrame:SetBackdropBorderColor(0.25, 0.38, 0.55, 0.75)

        local logCharSearchLabel = logCharSearchFrame:CreateFontString(nil, "OVERLAY")
        logCharSearchLabel:SetFont(WV_FONT_FACE, 10, WV_FONT_FLAGS)
        logCharSearchLabel:SetPoint("LEFT", 7, 0)
        logCharSearchLabel:SetText("|cFF8A8F98Search|r")

        local logCharSearchBox = CreateFrame("EditBox", nil, logCharSearchFrame)
        logCharSearchBox:SetPoint("LEFT", logCharSearchLabel, "RIGHT", 6, 0)
        logCharSearchBox:SetPoint("RIGHT", logCharSearchFrame, "RIGHT", -6, 0)
        logCharSearchBox:SetHeight(18)
        logCharSearchBox:SetFont("Fonts\\ARIALN.TTF", 11, "")
        logCharSearchBox:SetTextColor(0.93, 0.94, 0.98, 1)
        logCharSearchBox:SetAutoFocus(false)
        logCharSearchBox:EnableMouse(true)
        f.logCharSearchBox = logCharSearchBox

        local logCharsScroll = CreateFrame("ScrollFrame", nil, logChars, "UIPanelScrollFrameTemplate")
        logCharsScroll:SetPoint("TOPLEFT", logChars, "TOPLEFT", 6, -36)
        logCharsScroll:SetPoint("BOTTOMRIGHT", logChars, "BOTTOMRIGHT", -26, 6)
        f.logCharsScroll = logCharsScroll

        local logCharsContent = CreateFrame("Frame", nil, logCharsScroll)
        logCharsContent:SetWidth(150)
        logCharsContent:SetHeight(1)
        logCharsScroll:SetScrollChild(logCharsContent)
        f.logCharsContent = logCharsContent

        local totalText = f:CreateFontString(nil, "OVERLAY")
        totalText:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
        totalText:SetJustifyH("RIGHT")
        totalText:SetPoint("TOPRIGHT", f, "TOPRIGHT", -22, -58)
        f.totalText = totalText

        local header = CreateFrame("Frame", nil, f)
        header:SetPoint("TOPLEFT", f, "TOPLEFT", 86, -112)
        header:SetPoint("TOPRIGHT", f, "TOPRIGHT", -24, -112)
        header:SetHeight(30)
        f.header = header
        header.bg = header:CreateTexture(nil, "BACKGROUND")
        header.bg:SetAllPoints()
        header.bg:SetTexture(WV_FLAT_TEX)

        local dateHead = header:CreateFontString(nil, "OVERLAY")
        dateHead:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
        dateHead:SetPoint("LEFT", 12, 0)
        dateHead:SetWidth(155)
        dateHead:SetJustifyH("LEFT")
        f.dateHead = dateHead

        local charHead = header:CreateFontString(nil, "OVERLAY")
        charHead:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
        charHead:SetPoint("LEFT", dateHead, "RIGHT", 18, 0)
        charHead:SetWidth(190)
        charHead:SetJustifyH("LEFT")
        f.charHead = charHead

        local entryHead = header:CreateFontString(nil, "OVERLAY")
        entryHead:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
        entryHead:SetPoint("LEFT", charHead, "RIGHT", 18, 0)
        entryHead:SetPoint("RIGHT", header, "RIGHT", -12, 0)
        entryHead:SetJustifyH("LEFT")
        f.entryHead = entryHead

        local tablePanel = CreateFrame("Frame", nil, f)
        tablePanel:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -1)
        tablePanel:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 56)
        tablePanel.bg = tablePanel:CreateTexture(nil, "BACKGROUND")
        tablePanel.bg:SetAllPoints()
        tablePanel.bg:SetTexture(WV_FLAT_TEX)
        tablePanel.bg:SetVertexColor(0.018, 0.020, 0.014, 0.48)
        tablePanel.tint = tablePanel:CreateTexture(nil, "BORDER")
        tablePanel.tint:SetAllPoints()
        tablePanel.tint:SetTexture(WV_FLAT_TEX)
        tablePanel.tint:SetVertexColor(0.96, 0.62, 0.04, 0.035)
        f.tablePanel = tablePanel

        local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", tablePanel, "TOPLEFT", 0, 0)
        scroll:SetPoint("BOTTOMRIGHT", tablePanel, "BOTTOMRIGHT", 0, 0)
        f.scroll = scroll

        local scrollChild = CreateFrame("Frame", nil, scroll)
        scrollChild:SetWidth(1010)
        scrollChild:SetHeight(1)
        scroll:SetScrollChild(scrollChild)
        f.scrollChild = scrollChild
        f.rows = {}

        local resultText = f:CreateFontString(nil, "OVERLAY")
        resultText:SetFont(WV_FONT_FACE, 13, WV_FONT_FLAGS)
        resultText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 86, 17)
        resultText:SetTextColor(0.95, 0.96, 0.98, 1)
        f.resultText = resultText

        local exportBtn = Enrage_CreateGlassButton(f, "|cFFE5E7EBExport Log|r", 128, 30, {0.96, 0.62, 0.04})
        exportBtn:SetPoint("BOTTOM", f, "BOTTOM", 74, 13)
        exportBtn:SetScript("OnClick", function()
            Enrage_ShowLogExport(ENRAGE_LOG_TITLES[f.activeTab] or "Logs", f.currentExportText or "")
        end)
        f.exportBtn = exportBtn

        local clearBtn = Enrage_CreateGlassButton(f, "|cFFE5E7EBClear Log|r", 128, 30, {0.95, 0.38, 0.32})
        clearBtn:SetPoint("RIGHT", exportBtn, "LEFT", -12, 0)
        f.clearBtn = clearBtn

        StaticPopupDialogs["ENRAGE_CLEAR_LOGS_HUB"] = {
            text = "Clear the selected AkcQOL log?",
            button1 = "Yes",
            button2 = "No",
            OnAccept = function()
                if not ENRAGE_LOGS_FRAME then return end
                local key = ENRAGE_LOGS_FRAME.activeTab or "mail"
                EnsureLogDB()
                if key == "chat" then
                    local activeChannel = ENRAGE_LOGS_FRAME.activeChannel or "all"
                    local activePerson = ENRAGE_LOGS_FRAME.activeChatPerson or "all"
                    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
                        if activeChannel == "all" or activeChannel == ch.key then
                            if activePerson == "all" then
                                EnrageDB.global.logs.chat[ch.key] = {}
                            else
                                local filtered = {}
                                local raw = EnrageDB.global.logs.chat[ch.key] or {}
                                for i = 1, #raw do
                                    local _, author = Enrage_ParseChatLogEntry(raw[i])
                                    if Enrage_GetChatConversationPerson(ch.key, author) ~= activePerson then
                                        filtered[#filtered + 1] = raw[i]
                                    end
                                end
                                EnrageDB.global.logs.chat[ch.key] = filtered
                            end
                        end
                    end
                    ENRAGE_LOGS_FRAME.activeChatPerson = "all"
                elseif key == "lua" then
                    if _G.Enrage_ClearErrorLog then
                        pcall(_G.Enrage_ClearErrorLog)
                    elseif EnrageDB.global.luaErrors then
                        EnrageDB.global.luaErrors.entries = {}
                        EnrageDB.global.luaErrors.unreadCount = 0
                    end
                elseif ENRAGE_CHARACTER_LOG_TYPES[key] then
                    local selectedChar = ENRAGE_LOGS_FRAME.activeLogChar or "all"
                    if selectedChar ~= "all" then
                        if EnrageDB.global.logsByChar and EnrageDB.global.logsByChar[key] then
                            EnrageDB.global.logsByChar[key][selectedChar] = {}
                        end
                        local kept = {}
                        for _, entry in ipairs(EnrageDB.global.logs[key] or {}) do
                            if Enrage_GetCharFromLogEntry(Enrage_UntaintLog(entry) or "") ~= selectedChar then
                                kept[#kept + 1] = entry
                            end
                        end
                        EnrageDB.global.logs[key] = kept
                    else
                        EnrageDB.global.logs[key] = {}
                        if EnrageDB.global.logsByChar then
                            EnrageDB.global.logsByChar[key] = {}
                        end
                    end
                    if EnrageDB.global.logsByCharMigrated then
                        EnrageDB.global.logsByCharMigrated[key] = true
                    end
                else
                    EnrageDB.global.logs[key] = {}
                end
                ENRAGE_LOGS_FRAME:Refresh()
            end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            preferredIndex = 3,
        }
        clearBtn:SetScript("OnClick", function()
            StaticPopup_Show("ENRAGE_CLEAR_LOGS_HUB")
        end)

        local resizeGrip = CreateFrame("Button", nil, f)
        resizeGrip:SetSize(18, 18)
        resizeGrip:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -4, 4)
        f.resizeDots = {}
        local gripPos = {{0,0},{5,0},{10,0},{5,5},{10,5},{10,10}}
        for _, pos in ipairs(gripPos) do
            local dot = resizeGrip:CreateTexture(nil, "OVERLAY")
            dot:SetTexture(WV_FLAT_TEX)
            dot:SetSize(2, 2)
            dot:SetPoint("BOTTOMRIGHT", resizeGrip, "BOTTOMRIGHT", -pos[1], pos[2])
            f.resizeDots[#f.resizeDots + 1] = dot
        end
        resizeGrip:SetScript("OnMouseDown", function(_, button)
            if button ~= "LeftButton" then return end
            f.isScaleSizing = true
            f.scaleStartX, f.scaleStartY = GetCursorPosition()
            f.scaleStart = f:GetScale() or 1
            resizeGrip:SetScript("OnUpdate", function()
                if not f.isScaleSizing then return end
                -- Stop reliably even if OnMouseUp was missed (button released off the
                -- grip) — otherwise this keeps rescaling and the window "slides".
                if not IsMouseButtonDown("LeftButton") then
                    f.isScaleSizing = false
                    resizeGrip:SetScript("OnUpdate", nil)
                    return
                end
                local curX, curY = GetCursorPosition()
                local dx = (curX - (f.scaleStartX or curX)) / 520
                local dy = ((f.scaleStartY or curY) - curY) / 520
                local diff
                if dx * dy > 0 then
                    diff = (dx + dy) / 2
                elseif math.abs(dx) > math.abs(dy) then
                    diff = dx
                else
                    diff = dy
                end
                local newScale = (f.scaleStart or 1) + diff
                local frameW = f:GetWidth() or 1280
                local frameH = f:GetHeight() or 720
                local screenW = UIParent:GetWidth() or frameW
                local screenH = UIParent:GetHeight() or frameH
                local maxScale = math.min(1.8, screenW / frameW, screenH / frameH)
                if maxScale < 0.7 then maxScale = 0.7 end
                if newScale < 0.55 then newScale = 0.55 end
                if newScale > maxScale then newScale = maxScale end
                f:SetScale(newScale)
                if _G.EnrageSettingsFrame and Enrage_IsFrameOpen(_G.EnrageSettingsFrame) then
                    -- The settings panel is a CHILD of this window (docked) or of the
                    -- matrix; both already scale, so keep its own scale at 1 and let it
                    -- inherit — exactly like the matrix page, no double-scaling.
                    _G.EnrageSettingsFrame:SetScale(1)
                end
                if _G.EnrageMatrix_FilterMenu and Enrage_IsFrameOpen(_G.EnrageMatrix_FilterMenu) then
                    _G.EnrageMatrix_FilterMenu:SetScale(newScale)
                end
                if EnrageDB and EnrageDB.global then
                    EnrageDB.global.mainWindowScale = newScale
                end
            end)
        end)
        resizeGrip:SetScript("OnMouseUp", function()
            f.isScaleSizing = false
            resizeGrip:SetScript("OnUpdate", nil)
        end)

        function f:UpdateNav()
            for key, btn in pairs(self.navButtons) do
                local active = key == self.activeTab
                btn.marker:SetShown(active)
                if active then
                    btn.bg:SetVertexColor(0.045, 0.043, 0.028, 0.96)
                    btn.icon:SetAlpha(1)
                else
                    btn.bg:SetVertexColor(0.012, 0.014, 0.010, 0.86)
                    btn.icon:SetAlpha(0.86)
                end
            end
        end

        function f:UpdateChatTabs()
            for _, tab in ipairs(self.chatTabButtons) do
                local active = tab.key == self.activeChannel
                if active then
                    tab.bg:SetVertexColor(tab.color[1] * 0.20, tab.color[2] * 0.20, tab.color[3] * 0.20, 1)
                    tab.border:SetVertexColor(tab.color[1], tab.color[2], tab.color[3], 1)
                else
                    tab.bg:SetVertexColor(0.12, 0.12, 0.12, 0.9)
                    tab.border:SetVertexColor(tab.color[1] * 0.4, tab.color[2] * 0.4, tab.color[3] * 0.4, 0.6)
                end
            end
        end

        function f:CollectChatPeople()
            EnsureLogDB()
            Enrage_MigrateLegacyBattleNetWhispers()
            local people, seen = {}, {}
            local activeChannel = self.activeChannel or "all"

            for _, ch in ipairs(CHAT_LOG_CHANNELS) do
                if activeChannel == "all" or activeChannel == ch.key then
                    local raw = EnrageDB.global.logs.chat[ch.key] or {}
                    for i = 1, #raw do
                        local _, author = Enrage_ParseChatLogEntry(raw[i])
                        local person = Enrage_GetChatConversationPerson(ch.key, author)
                        if person and person ~= "" and not seen[person] then
                            seen[person] = true
                            people[#people + 1] = { key = person, label = person }
                        end
                    end
                end
            end

            table.sort(people, function(a, b)
                return TRLower(a.label or a.key or "") < TRLower(b.label or b.key or "")
            end)
            return people
        end

        function f:UpdateChatPeople()
            local frame = self.chatPeople
            if not frame then return end

            local selected = self.activeChatPerson or "all"
            local people = self:CollectChatPeople()
            local searchText = ""
            if self.chatPersonSearchBox and self.chatPersonSearchBox.GetText then
                searchText = TRLower(Enrage_UntaintLog(self.chatPersonSearchBox:GetText()) or "")
            end
            local exists = selected == "all"
            for _, person in ipairs(people) do
                if person.key == selected then exists = true break end
            end
            if not exists then
                self.activeChatPerson = "all"
                selected = "all"
            end

            local items = { { key = "all", label = "All" } }
            for _, person in ipairs(people) do
                local label = person.label or person.key or ""
                if searchText == "" or person.key == selected or TRLower(label):find(searchText, 1, true) then
                    items[#items + 1] = person
                end
            end

            local content = self.chatPeopleContent or frame
            local width = math.max(120, (self.chatPeopleScroll and self.chatPeopleScroll:GetWidth() or frame:GetWidth() or 160) - 4)
            local rowH = 24
            for i, item in ipairs(items) do
                local btn = self.chatPeopleButtons[i]
                if not btn then
                    btn = CreateFrame("Button", nil, content)
                    btn:SetHeight(rowH - 2)
                    btn.bg = btn:CreateTexture(nil, "BACKGROUND")
                    btn.bg:SetAllPoints()
                    btn.bg:SetTexture(WV_FLAT_TEX)
                    btn.border = btn:CreateTexture(nil, "BORDER")
                    btn.border:SetPoint("TOPLEFT", -1, 1)
                    btn.border:SetPoint("BOTTOMRIGHT", 1, -1)
                    btn.border:SetTexture(WV_FLAT_TEX)
                    btn.text = btn:CreateFontString(nil, "OVERLAY")
                    btn.text:SetFont(WV_LIST_FONT_FACE, 10, WV_FONT_FLAGS)
                    btn.text:SetPoint("LEFT", 8, 0)
                    btn.text:SetPoint("RIGHT", btn, "RIGHT", -6, 0)
                    btn.text:SetJustifyH("LEFT")
                    btn:SetScript("OnClick", function(self)
                        f.activeChatPerson = self.personKey or "all"
                        f:UpdateChatTabs()
                        f:Refresh()
                    end)
                    btn:SetScript("OnEnter", function(self)
                        self.bg:SetVertexColor(0.22, 0.18, 0.24, 0.95)
                    end)
                    btn:SetScript("OnLeave", function()
                        f:UpdateChatPeople()
                    end)
                    self.chatPeopleButtons[i] = btn
                end

                local label = item.label or item.key or "Unknown"
                local display = Enrage_TruncateUtf8(label, 20)
                btn.personKey = item.key
                btn:SetSize(width, rowH - 2)
                btn:ClearAllPoints()
                btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * rowH))
                btn:SetPoint("RIGHT", content, "RIGHT", -2, 0)
                local active = item.key == selected
                if active then
                    btn.bg:SetVertexColor(0.20, 0.13, 0.22, 1)
                    btn.border:SetVertexColor(1.0, 0.54, 1.0, 0.95)
                else
                    btn.bg:SetVertexColor(0.10, 0.10, 0.11, 0.85)
                    btn.border:SetVertexColor(0.65, 0.35, 0.65, 0.45)
                end
                btn.text:SetText(item.key == "all" and "|cFFE5E7EBAll|r" or "|cFFFFA6FF" .. display .. "|r")
                btn:Show()
            end

            for i = #items + 1, #self.chatPeopleButtons do
                self.chatPeopleButtons[i]:Hide()
            end

            local height = math.max(1, #items * rowH)
            content:SetWidth(width)
            content:SetHeight(height)
            if self.chatPeopleScroll and self.chatPeopleScroll:GetVerticalScroll() > (self.chatPeopleScroll:GetVerticalScrollRange() or 0) then
                self.chatPeopleScroll:SetVerticalScroll(self.chatPeopleScroll:GetVerticalScrollRange() or 0)
            end
        end

        function f:CollectLogCharacters(key)
            EnsureLogDB()
            if not ENRAGE_CHARACTER_LOG_TYPES[key] then return {} end

            local chars, seen = {}, {}
            local function AddChar(char)
                if char and char ~= "" and not seen[char] then
                    seen[char] = true
                    chars[#chars + 1] = { key = char, label = char }
                end
            end

            local byType = EnrageDB.global.logsByChar and EnrageDB.global.logsByChar[key]
            if type(byType) == "table" then
                for char, entries in pairs(byType) do
                    if type(entries) == "table" and #entries > 0 then
                        AddChar(char)
                    end
                end
            end

            for _, entry in ipairs(EnrageDB.global.logs[key] or {}) do
                AddChar(Enrage_GetCharFromLogEntry(Enrage_UntaintLog(entry) or ""))
            end

            table.sort(chars, function(a, b)
                return TRLower(a.label or a.key or "") < TRLower(b.label or b.key or "")
            end)
            return chars
        end

        function f:UpdateLogCharacters()
            local key = self.activeTab or "mail"
            local frame = self.logChars
            if not frame or not ENRAGE_CHARACTER_LOG_TYPES[key] then return end

            local color = Enrage_GetLogColor(key)
            frame:SetBackdropBorderColor(color[1], color[2], color[3], 0.38)

            local selected = self.activeLogChar or "all"
            local chars = self:CollectLogCharacters(key)
            local searchText = ""
            if self.logCharSearchBox and self.logCharSearchBox.GetText then
                searchText = TRLower(Enrage_UntaintLog(self.logCharSearchBox:GetText()) or "")
            end

            local exists = selected == "all"
            for _, char in ipairs(chars) do
                if char.key == selected then exists = true break end
            end
            if not exists then
                self.activeLogChar = "all"
                selected = "all"
            end

            local items = { { key = "all", label = "All" } }
            for _, char in ipairs(chars) do
                local label = char.label or char.key or ""
                if searchText == "" or char.key == selected or TRLower(label):find(searchText, 1, true) then
                    items[#items + 1] = char
                end
            end

            local content = self.logCharsContent or frame
            local width = math.max(120, (self.logCharsScroll and self.logCharsScroll:GetWidth() or frame:GetWidth() or 160) - 4)
            local rowH = 24
            for i, item in ipairs(items) do
                local btn = self.logCharButtons[i]
                if not btn then
                    btn = CreateFrame("Button", nil, content)
                    btn:SetHeight(rowH - 2)
                    btn.bg = btn:CreateTexture(nil, "BACKGROUND")
                    btn.bg:SetAllPoints()
                    btn.bg:SetTexture(WV_FLAT_TEX)
                    btn.border = btn:CreateTexture(nil, "BORDER")
                    btn.border:SetPoint("TOPLEFT", -1, 1)
                    btn.border:SetPoint("BOTTOMRIGHT", 1, -1)
                    btn.border:SetTexture(WV_FLAT_TEX)
                    btn.text = btn:CreateFontString(nil, "OVERLAY")
                    btn.text:SetFont(WV_LIST_FONT_FACE, 10, WV_FONT_FLAGS)
                    btn.text:SetPoint("LEFT", 8, 0)
                    btn.text:SetPoint("RIGHT", btn, "RIGHT", -6, 0)
                    btn.text:SetJustifyH("LEFT")
                    btn:SetScript("OnClick", function(self)
                        f.activeLogChar = self.logCharKey or "all"
                        if f.allCharsCheck then
                            f.allCharsCheck:SetChecked(f.activeLogChar == "all")
                        end
                        f:Refresh()
                    end)
                    btn:SetScript("OnEnter", function(self)
                        local c = self.color or {0.35, 0.68, 1.0}
                        self.bg:SetVertexColor(c[1] * 0.20, c[2] * 0.20, c[3] * 0.20, 0.95)
                    end)
                    btn:SetScript("OnLeave", function()
                        f:UpdateLogCharacters()
                    end)
                    self.logCharButtons[i] = btn
                end

                local label = item.label or item.key or "Unknown"
                local display = Enrage_TruncateUtf8(label, 20)
                btn.logCharKey = item.key
                btn.color = color
                btn:SetSize(width, rowH - 2)
                btn:ClearAllPoints()
                btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * rowH))
                btn:SetPoint("RIGHT", content, "RIGHT", -2, 0)
                local active = item.key == selected
                if active then
                    btn.bg:SetVertexColor(color[1] * 0.22, color[2] * 0.22, color[3] * 0.22, 1)
                    btn.border:SetVertexColor(color[1], color[2], color[3], 0.95)
                else
                    btn.bg:SetVertexColor(0.10, 0.10, 0.11, 0.85)
                    btn.border:SetVertexColor(color[1] * 0.45, color[2] * 0.45, color[3] * 0.45, 0.45)
                end
                btn.text:SetText(item.key == "all" and "|cFFE5E7EBAll|r" or Enrage_ColorText(color, display))
                btn:Show()
            end

            for i = #items + 1, #self.logCharButtons do
                self.logCharButtons[i]:Hide()
            end

            local height = math.max(1, #items * rowH)
            content:SetWidth(width)
            content:SetHeight(height)
            if self.logCharsScroll and self.logCharsScroll:GetVerticalScroll() > (self.logCharsScroll:GetVerticalScrollRange() or 0) then
                self.logCharsScroll:SetVerticalScroll(self.logCharsScroll:GetVerticalScrollRange() or 0)
            end
        end

        local function GetOrCreateRow(index)
            local row = f.rows[index]
            if row then return row end
            row = CreateFrame("Button", nil, f.scrollChild)
            row:SetHeight(30)
            row.bg = row:CreateTexture(nil, "BACKGROUND")
            row.bg:SetAllPoints()
            row.bg:SetTexture(WV_FLAT_TEX)
            row.left = row:CreateTexture(nil, "BORDER")
            row.left:SetPoint("TOPLEFT")
            row.left:SetPoint("BOTTOMLEFT")
            row.left:SetWidth(3)
            row.left:SetTexture(WV_FLAT_TEX)
            row.date = row:CreateFontString(nil, "OVERLAY")
            row.date:SetFont("Fonts\\ARIALN.TTF", 12, "")
            row.date:SetPoint("LEFT", 12, 0)
            row.date:SetWidth(155)
            row.date:SetJustifyH("LEFT")
            row.date:SetTextColor(0.93, 0.94, 0.98, 1)
            row.char = row:CreateFontString(nil, "OVERLAY")
            row.char:SetFont("Fonts\\ARIALN.TTF", 12, "")
            row.char:SetPoint("LEFT", row.date, "RIGHT", 18, 0)
            row.char:SetWidth(190)
            row.char:SetJustifyH("LEFT")
            row.char:SetTextColor(0.88, 0.9, 0.94, 1)
            row.body = row:CreateFontString(nil, "OVERLAY")
            row.body:SetFont("Fonts\\ARIALN.TTF", 12, "")
            row.body:SetPoint("LEFT", row.char, "RIGHT", 18, 0)
            row.body:SetPoint("RIGHT", row, "RIGHT", -12, 0)
            row.body:SetJustifyH("LEFT")
            row.body:SetWordWrap(false)
            row.body:SetTextColor(0.93, 0.94, 0.98, 1)
            Enrage_EnableLogHyperlinks(row.body, row)
            row.bubble = CreateFrame("Frame", nil, row, "BackdropTemplate")
            row.bubble:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
            row.bubble:EnableMouse(false)
            row.bubble:Hide()
            row.bubbleMeta = row.bubble:CreateFontString(nil, "OVERLAY")
            row.bubbleMeta:SetFont("Fonts\\ARIALN.TTF", 10, "")
            row.bubbleMeta:SetTextColor(0.82, 0.84, 0.88, 0.92)
            row.bubbleMeta:Hide()
            row.bubbleText = row.bubble:CreateFontString(nil, "OVERLAY")
            row.bubbleText:SetFont("Fonts\\ARIALN.TTF", 12, "")
            row.bubbleText:SetTextColor(0.96, 0.97, 1.0, 1)
            row.bubbleText:SetJustifyH("LEFT")
            row.bubbleText:SetJustifyV("TOP")
            row.bubbleText:SetWordWrap(true)
            row.bubbleText:Hide()
            Enrage_EnableLogHyperlinks(row.bubbleText, row)
            row:SetScript("OnEnter", function(self)
                local c = self.color or {0.96, 0.62, 0.04}
                if self.isChatBubble then
                    self.bg:SetVertexColor(c[1] * 0.10, c[2] * 0.10, c[3] * 0.10, 0.22)
                else
                    self.bg:SetVertexColor(c[1] * 0.18, c[2] * 0.18, c[3] * 0.18, 0.72)
                end
            end)
            row:SetScript("OnLeave", function(self)
                GameTooltip:Hide()
                if self.isChatBubble then
                    self.bg:SetVertexColor(0.014, 0.015, 0.012, 0.10)
                elseif self.rowIndex and self.rowIndex % 2 == 0 then
                    self.bg:SetVertexColor(0.055, 0.058, 0.060, 0.48)
                else
                    self.bg:SetVertexColor(0.014, 0.015, 0.012, 0.34)
                end
            end)
            row:SetScript("OnClick", function(self)
                local raw = Enrage_UntaintLog(self.rawText)
                if raw and raw ~= "" then
                    Enrage_ShowLogExport(self.rawTitle or "Log Entry", raw)
                end
            end)
            f.rows[index] = row
            return row
        end

        local function LayoutLogRowColumns(row, hideCharacterColumn)
            if not row or not row.date or not row.char or not row.body then return end

            row.isChatBubble = false
            if row.bubble then row.bubble:Hide() end
            if row.bubbleMeta then row.bubbleMeta:Hide() end
            if row.bubbleText then row.bubbleText:Hide() end
            if row.left then row.left:Show() end
            row.date:Show()
            row.body:Show()
            row.linkHost = row.body
            if hideCharacterColumn then
                row.char:Hide()
            else
                row.char:Show()
            end

            row.body:ClearAllPoints()
            row.body:SetWordWrap(false)
            row.body:SetJustifyH("LEFT")
            row.body:SetTextColor(0.93, 0.94, 0.98, 1)
            if hideCharacterColumn then
                row.body:SetPoint("LEFT", row.date, "RIGHT", 18, 0)
            else
                row.body:SetPoint("LEFT", row.char, "RIGHT", 18, 0)
            end
            row.body:SetPoint("RIGHT", row, "RIGHT", -12, 0)
        end

        local function LayoutChatBubbleRow(row, data, width)
            if not row or not data then return 30 end

            local outgoing = data.isOutgoing and true or false
            local bubbleW = math.max(280, math.min(560, math.floor((width or 720) * 0.46)))
            local bubblePadX = 12
            local metaH = 13
            local bodyText = data.bubbleText or data.bodyText or ""
            local timeText = tostring(data.dateText or ""):match("(%d%d:%d%d:%d%d)$") or tostring(data.dateText or "")
            local authorText = outgoing and "You" or (data.charText ~= "" and data.charText or "Whisper")

            row.isChatBubble = true
            row.bg:SetVertexColor(0.014, 0.015, 0.012, 0.10)
            row.left:Hide()
            row.date:Hide()
            row.char:Hide()
            row.body:Hide()
            row.bubble:Show()
            row.bubbleMeta:Show()
            row.bubbleText:Show()
            row.linkHost = row.bubbleText

            row.bubble:ClearAllPoints()
            row.bubble:SetSize(bubbleW, 34)
            if outgoing then
                row.bubble:SetPoint("TOPRIGHT", row, "TOPRIGHT", -16, -4)
                row.bubble:SetBackdropColor(0.16, 0.105, 0.035, 0.58)
                row.bubble:SetBackdropBorderColor(1.0, 0.72, 0.18, 0.28)
            else
                row.bubble:SetPoint("TOPLEFT", row, "TOPLEFT", 16, -4)
                row.bubble:SetBackdropColor(0.10, 0.055, 0.12, 0.58)
                row.bubble:SetBackdropBorderColor(1.0, 0.54, 1.0, 0.26)
            end

            row.bubbleMeta:ClearAllPoints()
            row.bubbleMeta:SetPoint("TOPLEFT", row.bubble, "TOPLEFT", bubblePadX, -5)
            row.bubbleMeta:SetPoint("RIGHT", row.bubble, "RIGHT", -bubblePadX, 0)
            row.bubbleMeta:SetJustifyH(outgoing and "RIGHT" or "LEFT")
            row.bubbleMeta:SetText(authorText .. " - " .. timeText)

            row.bubbleText:ClearAllPoints()
            row.bubbleText:SetPoint("TOPLEFT", row.bubble, "TOPLEFT", bubblePadX, -(metaH + 8))
            row.bubbleText:SetPoint("RIGHT", row.bubble, "RIGHT", -bubblePadX, 0)
            row.bubbleText:SetWidth(math.max(120, bubbleW - (bubblePadX * 2)))
            row.bubbleText:SetText(bodyText)

            local textH = row.bubbleText:GetStringHeight() or 14
            local bubbleH = math.max(38, math.ceil(textH) + metaH + 16)
            local rowH = bubbleH + 8
            row.bubble:SetHeight(bubbleH)
            row:SetHeight(rowH)
            return rowH
        end

        local function LayoutLogHeaderColumns(frame, hideCharacterColumn)
            if not frame or not frame.dateHead or not frame.charHead or not frame.entryHead or not frame.header then return end

            if hideCharacterColumn then
                frame.charHead:Hide()
            else
                frame.charHead:Show()
            end

            frame.entryHead:ClearAllPoints()
            if hideCharacterColumn then
                frame.entryHead:SetPoint("LEFT", frame.dateHead, "RIGHT", 18, 0)
            else
                frame.entryHead:SetPoint("LEFT", frame.charHead, "RIGHT", 18, 0)
            end
            frame.entryHead:SetPoint("RIGHT", frame.header, "RIGHT", -12, 0)
        end

        function f:BuildRows()
            EnsureLogDB()
            local key = self.activeTab or "mail"
            local query = TRLower(Enrage_UntaintLog(self.searchBox:GetText()) or "")
            local today = date("%Y-%m-%d")
            local rows, exportLines = {}, {}

            if key == "chat" then
                Enrage_MigrateLegacyBattleNetWhispers()
                local activeChannel = self.activeChannel or "all"
                local activePerson = self.activeChatPerson or "all"
                for _, ch in ipairs(CHAT_LOG_CHANNELS) do
                    if activeChannel == "all" or activeChannel == ch.key then
                        local raw = EnrageDB.global.logs.chat[ch.key] or {}
                        local channelInfo = Enrage_GetChatChannelInfo(ch.key)
                        for i = 1, #raw do
                            local dt, author, body, clean = Enrage_ParseChatLogEntry(raw[i])
                            local person = Enrage_GetChatConversationPerson(ch.key, author)
                            if clean and (activePerson == "all" or activePerson == person) and (query == "" or TRLower(clean):find(query, 1, true)) then
                                local bodyText = Enrage_NormalizeStoredChatBody(ch.key, body ~= "" and body or clean)
                                local bubbleText = bodyText
                                local rawText = clean
                                if Enrage_IsProtectedChatPayloadText(body) then
                                    rawText = string.format("%s [%s] %s", dt ~= "" and dt or "-", author ~= "" and author or "-", bodyText)
                                end
                                local rawAuthor = Enrage_UntaintLog(author) or ""
                                rawAuthor = rawAuthor:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
                                local isOutgoing = rawAuthor:match("^%s*To%s+") or rawAuthor:match("^%s*To:%s*")
                                if activeChannel == "all" then
                                    bodyText = Enrage_ColorText(channelInfo.color, "[" .. channelInfo.label .. "]") .. " " .. bodyText
                                end
                                rows[#rows + 1] = {
                                    raw = rawText,
                                    dateText = dt ~= "" and dt or "-",
                                    charText = author ~= "" and author or "-",
                                    bodyText = bodyText,
                                    bubbleText = bubbleText,
                                    isWhisper = ch.key == "whisper" or ch.key == "bnet",
                                    isOutgoing = isOutgoing and true or false,
                                    sourceIndex = i,
                                }
                            end
                        end
                    end
                end
            elseif key == "lua" then
                Enrage_MarkLuaErrorsSeenFromLogs()
                local db = EnrageDB.global.luaErrors or {}
                local entries = db.entries or {}
                for _, entry in ipairs(entries) do
                    if type(entry) == "table" then
                        local detail = Enrage_BuildLuaErrorExport(entry)
                        if query == "" or TRLower(detail):find(query, 1, true) then
                            local msg = tostring(entry.message or "Unknown error")
                            msg = msg:match("([^\r\n]+)") or msg
                            rows[#rows + 1] = {
                                raw = detail,
                                dateText = tostring(entry.lastSeenText or entry.firstSeenText or "-"),
                                charText = tostring(entry.addon or "Unknown"),
                                bodyText = string.format("%s x%d", msg, entry.count or 1),
                            }
                        end
                    end
                end
            else
                local selectedLogChar = self.activeLogChar or "all"
                local showAll = selectedLogChar == "all"
                local onlyToday = self.todayCheck:GetChecked()
                local rawEntries = {}
                local usedByCharBuckets = false
                local function AppendEntries(source)
                    if type(source) ~= "table" then return end
                    for i = 1, #source do
                        rawEntries[#rawEntries + 1] = source[i]
                    end
                end

                if ENRAGE_CHARACTER_LOG_TYPES[key] and EnrageDB.global.logsByChar and EnrageDB.global.logsByChar[key] then
                    local byType = EnrageDB.global.logsByChar[key]
                    usedByCharBuckets = true
                    if showAll then
                        for _, list in pairs(byType) do
                            AppendEntries(list)
                        end
                    else
                        AppendEntries(byType[selectedLogChar])
                    end
                end

                if #rawEntries == 0 then
                    AppendEntries(EnrageDB.global.logs[key] or {})
                end

                local cleanEntries = {}
                local seenEntries = {}
                for i = 1, #rawEntries do
                    local clean = Enrage_UntaintLog(rawEntries[i])
                    if clean and not seenEntries[clean] then
                        seenEntries[clean] = true
                        cleanEntries[#cleanEntries + 1] = clean
                        Enrage_StoreLogEntryByChar(key, clean, false)
                    end
                end
                if not usedByCharBuckets then
                    EnrageDB.global.logs[key] = cleanEntries
                end

                for _, entry in ipairs(cleanEntries) do
                    local dt, char, body = Enrage_ParseLogEntry(entry)
                    local dateOK = not onlyToday or (dt ~= "" and string.sub(dt, 1, 10) == today)
                    local charOK = showAll or char == "" or char == selectedLogChar
                    local searchOK = query == "" or TRLower(entry):find(query, 1, true)
                    if dateOK and charOK and searchOK then
                        rows[#rows + 1] = {
                            raw = entry,
                            dateText = dt ~= "" and dt or "-",
                            charText = char ~= "" and char or "-",
                            bodyText = body ~= "" and body or entry,
                        }
                    end
                end
            end

            if #rows > 1 then
                if key == "chat" then
                    table.sort(rows, function(a, b)
                        local av = a.dateText ~= "-" and a.dateText or a.raw
                        local bv = b.dateText ~= "-" and b.dateText or b.raw
                        if av == bv then
                            return (a.sourceIndex or 0) > (b.sourceIndex or 0)
                        end
                        return av < bv
                    end)
                else
                    table.sort(rows, function(a, b)
                        local av = a.dateText ~= "-" and a.dateText or a.raw
                        local bv = b.dateText ~= "-" and b.dateText or b.raw
                        return av > bv
                    end)
                end
            end

            for _, row in ipairs(rows) do
                exportLines[#exportLines + 1] = row.raw
            end
            return rows, exportLines
        end

        function f:Refresh()
            local key = self.activeTab or "mail"
            local color = Enrage_GetLogColor(key)
            local title = ENRAGE_LOG_TITLES[key] or "Logs"
            self:SetBackdropBorderColor(color[1], color[2], color[3], 0.54)
            self.titleText:SetText(Enrage_ColorText({color[1], color[2], color[3]}, title))
            self.titleText:SetTextColor(1, 1, 1, 1)
            self.header.bg:SetVertexColor(color[1] * 0.12, color[2] * 0.12, color[3] * 0.12, 0.60)
            if self.tablePanel and self.tablePanel.tint then
                self.tablePanel.tint:SetVertexColor(color[1], color[2], color[3], 0.035)
            end
            for _, dot in ipairs(self.resizeDots) do
                dot:SetVertexColor(color[1], color[2], color[3], 0.58)
            end

            -- Leaving the settings tab: undock/hide the shared settings panel.
            if key ~= "settings" and _G.EnrageSettingsFrame and _G.EnrageSettingsFrame:GetParent() == self then
                Enrage_SafeHideFrame(_G.EnrageSettingsFrame)
            end

            -- Settings tab: hide the log table and dock the settings panel in the right pane.
            if key == "settings" then
                if self.searchFrame then self.searchFrame:Hide() end
                if self.filters then self.filters:Hide() end
                if self.chatTabs then self.chatTabs:Hide() end
                if self.chatPeople then self.chatPeople:Hide() end
                if self.logChars then self.logChars:Hide() end
                if self.header then self.header:Hide() end
                if self.tablePanel then self.tablePanel:Hide() end
                if self.scroll then self.scroll:Hide() end
                if self.clearBtn then self.clearBtn:Hide() end
                if self.exportBtn then self.exportBtn:Hide() end
                if self.resultText then self.resultText:Hide() end
                if self.totalText then self.totalText:Hide() end
                if self.charactersBtn then self.charactersBtn:Hide() end
                for _, row in ipairs(self.rows or {}) do row:Hide() end
                self.currentExportText = ""
                if _G.Enrage_DetachMatrixFromMain then
                    _G.Enrage_DetachMatrixFromMain(self)
                end
                local sf = _G.EnrageSettingsFrame
                if sf then
                    sf:SetParent(self)
                    sf:SetScale(1)  -- inherit the window's scale (scales like the matrix page)
                    sf:SetFrameStrata(self:GetFrameStrata())
                    sf:SetFrameLevel(self:GetFrameLevel() + 20)
                    sf:ClearAllPoints()
                    -- Fill the right pane (both corners) so the panel uses the whole
                    -- area instead of a fixed-size popup crammed top-left. Anchoring
                    -- both corners overrides RenderSection's SetSize; the matrix path
                    -- re-applies a single corner so its popup stays compact.
                    sf:SetPoint("TOPLEFT", self, "TOPLEFT", 78, -70)
                    sf:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -14, 40)
                    -- The logs window already shows a title + close button; hide the
                    -- panel's own so there isn't a duplicated/misaligned title.
                    if sf.ownTitle then sf.ownTitle:Hide() end
                    if sf.ownClose then sf.ownClose:Hide() end
                    Enrage_SafeShowFrame(sf)
                end
                self:UpdateNav()
                return
            end

            if key == "matrix" then
                if self.searchFrame then self.searchFrame:Hide() end
                if self.filters then self.filters:Hide() end
                if self.chatTabs then self.chatTabs:Hide() end
                if self.chatPeople then self.chatPeople:Hide() end
                if self.logChars then self.logChars:Hide() end
                if self.header then self.header:Hide() end
                if self.tablePanel then self.tablePanel:Hide() end
                if self.scroll then self.scroll:Hide() end
                if self.clearBtn then self.clearBtn:Hide() end
                if self.exportBtn then self.exportBtn:Hide() end
                if self.resultText then self.resultText:Hide() end
                if self.totalText then self.totalText:Hide() end
                if self.charactersBtn then self.charactersBtn:Show() end
                for _, row in ipairs(self.rows or {}) do row:Hide() end
                self.currentExportText = ""
                if _G.Enrage_AttachMatrixToMain then
                    _G.Enrage_AttachMatrixToMain(self)
                end
                self:UpdateNav()
                return
            end

            if _G.Enrage_DetachMatrixFromMain then
                _G.Enrage_DetachMatrixFromMain(self)
            end
            if _G.EnrageMatrix_FilterMenu then
                Enrage_SafeHideFrame(_G.EnrageMatrix_FilterMenu)
            end
            if self.searchFrame then self.searchFrame:Show() end
            if self.header then self.header:Show() end
            if self.tablePanel then self.tablePanel:Show() end
            if self.scroll then self.scroll:Show() end
            if self.clearBtn then self.clearBtn:Show() end
            if self.exportBtn then self.exportBtn:Show() end
            if self.resultText then self.resultText:Show() end
            if self.totalText then self.totalText:Show() end
            if self.charactersBtn then self.charactersBtn:Hide() end

            local isCharacterLog = ENRAGE_CHARACTER_LOG_TYPES[key] and true or false
            self.filters:SetShown(key ~= "chat" and key ~= "lua")
            self.allCharsCheck:SetShown(not isCharacterLog)
            self.todayCheck:ClearAllPoints()
            if isCharacterLog then
                self.todayCheck:SetPoint("LEFT", self.filters, "LEFT", 0, 0)
            else
                self.todayCheck:SetPoint("LEFT", self.allCharsCheck, "RIGHT", 18, 0)
            end
            self.chatTabs:SetShown(key == "chat")
            self.chatPeople:SetShown(key == "chat")
            self.logChars:SetShown(isCharacterLog)
            self.header:ClearAllPoints()
            LayoutLogHeaderColumns(self, isCharacterLog)
            if key == "chat" then
                self.header:SetPoint("TOPLEFT", self, "TOPLEFT", self.chatTableLeft or 282, -126)
                self.header:SetPoint("TOPRIGHT", self, "TOPRIGHT", -24, -126)
                self.dateHead:SetText("|cFFE5E7EBDate|r")
                self.charHead:SetText("|cFFE5E7EBAuthor|r")
                self.entryHead:SetText("|cFFE5E7EBMessage|r")
                self:UpdateChatTabs()
                self:UpdateChatPeople()
            elseif isCharacterLog then
                self.header:SetPoint("TOPLEFT", self, "TOPLEFT", self.logTableLeft or 282, -96)
                self.header:SetPoint("TOPRIGHT", self, "TOPRIGHT", -24, -96)
                self.dateHead:SetText("|cFFE5E7EBDate|r")
                self.entryHead:SetText("|cFFE5E7EBEntry|r")
                self:UpdateLogCharacters()
            else
                self.header:SetPoint("TOPLEFT", self, "TOPLEFT", 86, -112)
                self.header:SetPoint("TOPRIGHT", self, "TOPRIGHT", -24, -112)
                self.dateHead:SetText("|cFFE5E7EBDate|r")
                self.charHead:SetText(key == "lua" and "|cFFE5E7EBAddOn|r" or "|cFFE5E7EBCharacter|r")
                self.entryHead:SetText(key == "lua" and "|cFFE5E7EBError|r" or "|cFFE5E7EBEntry|r")
            end

            local rows, exportLines = self:BuildRows()
            for _, row in ipairs(self.rows) do row:Hide() end

            local rowHeight = 30
            local width = math.max(480, (self.scroll:GetWidth() or (self:GetWidth() - 126)))
            self.scrollChild:SetWidth(width)

            if #rows == 0 then
                local row = GetOrCreateRow(1)
                row.rowIndex = 1
                row.color = color
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", self.scrollChild, "TOPLEFT", 0, 0)
                row:SetPoint("RIGHT", self.scrollChild, "RIGHT", 0, 0)
                row:SetHeight(rowHeight)
                row.bg:SetVertexColor(0.014, 0.015, 0.012, 0.34)
                row.left:SetVertexColor(color[1], color[2], color[3], 0.8)
                row.date:SetText("-")
                LayoutLogRowColumns(row, isCharacterLog)
                row.char:SetText(isCharacterLog and "" or "-")
                row.body:SetText("|cFF8A8F98No entries.|r")
                row.rawText = nil
                row.rawTitle = nil
                Enrage_UpdateLogLinkHotspots(row, nil)
                row:Show()
                self.scrollChild:SetHeight(rowHeight + 8)
            else
                local yOff = 0
                for i, data in ipairs(rows) do
                    local row = GetOrCreateRow(i)
                    row.rowIndex = i
                    row.color = color
                    row:ClearAllPoints()
                    row:SetPoint("TOPLEFT", self.scrollChild, "TOPLEFT", 0, -yOff)
                    row:SetPoint("RIGHT", self.scrollChild, "RIGHT", 0, 0)
                    row.rawText = data.raw
                    row.rawTitle = title .. " Entry"

                    if key == "chat" and data.isWhisper then
                        local actualH = LayoutChatBubbleRow(row, data, width)
                        Enrage_UpdateLogLinkHotspots(row, data.bubbleText or data.bodyText or "")
                        row:Show()
                        yOff = yOff + actualH
                    else
                        row:SetHeight(rowHeight)
                        if i % 2 == 0 then
                            row.bg:SetVertexColor(0.055, 0.058, 0.060, 0.48)
                        else
                            row.bg:SetVertexColor(0.014, 0.015, 0.012, 0.34)
                        end
                        row.left:SetVertexColor(color[1], color[2], color[3], 0.8)
                        row.date:SetText(data.dateText or "-")
                        LayoutLogRowColumns(row, isCharacterLog)
                        row.char:SetText(isCharacterLog and "" or (data.charText or "-"))
                        row.body:SetText(data.bodyText or "")
                        Enrage_UpdateLogLinkHotspots(row, data.bodyText or "")
                        row:Show()
                        yOff = yOff + rowHeight
                    end
                end
                self.scrollChild:SetHeight(yOff + 8)
            end

            self.currentExportText = table.concat(exportLines, "\n\n")
            self.resultText:SetText(string.format("|cFFE5E7EBCurrent Results:|r %s", Enrage_ColorText(color, #rows)))
            if key == "chat" then
                local channelInfo = Enrage_GetChatChannelInfo(self.activeChannel or "all")
                local person = self.activeChatPerson or "all"
                local personText = person == "all" and "All people" or person
                self.totalText:SetText(string.format("|cFFE5E7EBChannel:|r %s\n|cFFE5E7EBPerson:|r %s\n|cFFE5E7EBShowing:|r %s",
                    Enrage_ColorText(channelInfo.color, channelInfo.label),
                    Enrage_ColorText(color, personText),
                    Enrage_ColorText(color, #rows)
                ))
            elseif isCharacterLog then
                local logChar = self.activeLogChar or "all"
                local charText = logChar == "all" and "All characters" or logChar
                self.totalText:SetText(string.format("|cFFE5E7EBActive:|r %s\n|cFFE5E7EBCharacter:|r %s\n|cFFE5E7EBShowing:|r %s",
                    Enrage_ColorText(color, title),
                    Enrage_ColorText(color, charText),
                    Enrage_ColorText(color, #rows)
                ))
            else
                self.totalText:SetText(string.format("|cFFE5E7EBActive:|r %s\n|cFFE5E7EBShowing:|r %s",
                    Enrage_ColorText(color, title),
                    Enrage_ColorText(color, #rows)
                ))
            end
            if key == "chat" then
                Enrage_ScrollFrameToBottom(self.scroll)
            else
                self.scroll:SetVerticalScroll(0)
            end
            self:UpdateNav()
        end

        function f:SetActiveTab(key)
            self.activeTab = key or "matrix"
            if self.activeTab == "chat" and not self.activeChannel then
                self.activeChannel = "guild"
            end
            if self.activeTab == "chat" and not self.activeChatPerson then
                self.activeChatPerson = "all"
            end
            if ENRAGE_CHARACTER_LOG_TYPES[self.activeTab] and not self.activeLogChar then
                self.activeLogChar = "all"
            end
            self.searchBox:SetText("")
            self:Refresh()
        end

        searchBox:SetScript("OnTextChanged", function() f:Refresh() end)
        searchBox:SetScript("OnEscapePressed", function(self)
            self:SetText("")
            self:ClearFocus()
            f:Refresh()
        end)
        searchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

        personSearchBox:SetScript("OnTextChanged", function()
            f:UpdateChatPeople()
        end)
        personSearchBox:SetScript("OnEscapePressed", function(self)
            self:SetText("")
            self:ClearFocus()
            f:UpdateChatPeople()
        end)
        personSearchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

        logCharSearchBox:SetScript("OnTextChanged", function()
            f:UpdateLogCharacters()
        end)
        logCharSearchBox:SetScript("OnEscapePressed", function(self)
            self:SetText("")
            self:ClearFocus()
            f:UpdateLogCharacters()
        end)
        logCharSearchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

        f:SetScript("OnSizeChanged", function(self, w)
            self.scrollChild:SetWidth(math.max(480, w - 126))
            self:Refresh()
        end)
        f:SetScript("OnShow", function(self)
            self.enrageSoftHidden = false
            self:SetAlpha(1)
            self:EnableMouse(true)
            self:Refresh()
        end)
        f:SetScript("OnHide", function(self)
            self.isScaleSizing = false
            if resizeGrip then resizeGrip:SetScript("OnUpdate", nil) end
            if _G.Enrage_DetachMatrixFromMain then
                _G.Enrage_DetachMatrixFromMain(self)
            end
            if _G.EnrageSettingsFrame then
                Enrage_SafeHideFrame(_G.EnrageSettingsFrame)
            end
            if _G.EnrageMatrix_FilterMenu then
                Enrage_SafeHideFrame(_G.EnrageMatrix_FilterMenu)
            end
        end)

        ENRAGE_LOGS_FRAME = f
    end

    for _, frame in pairs(WV_LOG_FRAMES) do
        Enrage_SafeHideFrame(frame)
    end
    ENRAGE_LOGS_FRAME:SetActiveTab(initialTab)
    Enrage_SafeShowFrame(ENRAGE_LOGS_FRAME)
end
_G.Enrage_ShowLogsWindow = Enrage_ShowLogsWindow

-- =========================================================================
-- ADDON USERS WINDOW
-- Shows who has Enrage addon installed in your group
-- =========================================================================
do
    local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
    local addonUsersFrame = nil

    function Enrage_ShowAddonUsersWindow()
        -- Toggle if already open
        if addonUsersFrame and addonUsersFrame:IsShown() then
            addonUsersFrame:Hide()
            return
        end

        if not addonUsersFrame then
            local f = CreateFrame("Frame", "EnrageAddonUsersFrame", UIParent, "BackdropTemplate")
            f:SetSize(320, 350)
            -- Position to the left of settings panel
            local configFrame = _G["MITConfigFrame"]
            if configFrame and configFrame:IsShown() then
                f:SetPoint("TOPRIGHT", configFrame, "TOPLEFT", -6, 0)
            else
                f:SetPoint("CENTER")
            end
            f:SetFrameStrata("DIALOG")
            f:SetMovable(true)
            f:EnableMouse(true)
            f:RegisterForDrag("LeftButton")
            f:SetScript("OnDragStart", f.StartMoving)
            f:SetScript("OnDragStop", f.StopMovingOrSizing)

            -- Background
            local bg = f:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetTexture(FLAT_TEX)
            bg:SetVertexColor(0.06, 0.06, 0.08, 0.95)

            -- Border
            local brd = f:CreateTexture(nil, "BORDER")
            brd:SetAllPoints()
            brd:SetTexture(FLAT_TEX)
            brd:SetVertexColor(0.3, 0.8, 0.3, 0.4)
            local inner = f:CreateTexture(nil, "ARTWORK")
            inner:SetPoint("TOPLEFT", 1, -1)
            inner:SetPoint("BOTTOMRIGHT", -1, 1)
            inner:SetTexture(FLAT_TEX)
            inner:SetVertexColor(0.06, 0.06, 0.08, 0.95)

            -- Title bar
            local titleBar = f:CreateTexture(nil, "ARTWORK", nil, 1)
            titleBar:SetPoint("TOPLEFT", 2, -2)
            titleBar:SetPoint("TOPRIGHT", -2, -2)
            titleBar:SetHeight(24)
            titleBar:SetTexture(FLAT_TEX)
            titleBar:SetVertexColor(0.1, 0.18, 0.1, 0.9)

            local title = f:CreateFontString(nil, "OVERLAY")
            title:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE")
            title:SetPoint("TOPLEFT", 10, -6)
            title:SetText("|cFF66FF66AkcQOL|r |cFFCCCCCCAddon Users|r")

            -- Close button
            local closeBtn = CreateFrame("Button", nil, f)
            closeBtn:SetSize(18, 18)
            closeBtn:SetPoint("TOPRIGHT", -4, -4)
            closeBtn:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
            closeBtn:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
            closeBtn:SetScript("OnClick", function() Enrage_SafeHideFrame(f) end)

            -- Header row
            local headerY = -32
            local hdrName = f:CreateFontString(nil, "OVERLAY")
            hdrName:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
            hdrName:SetPoint("TOPLEFT", 12, headerY)
            hdrName:SetText("|cFFFFD100Name|r")
            local hdrStatus = f:CreateFontString(nil, "OVERLAY")
            hdrStatus:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
            hdrStatus:SetPoint("TOPRIGHT", -12, headerY)
            hdrStatus:SetText("|cFFFFD100Status|r")

            local headerLine = f:CreateTexture(nil, "ARTWORK", nil, 2)
            headerLine:SetPoint("TOPLEFT", 8, headerY - 14)
            headerLine:SetPoint("TOPRIGHT", -8, headerY - 14)
            headerLine:SetHeight(1)
            headerLine:SetTexture(FLAT_TEX)
            headerLine:SetVertexColor(0.3, 0.3, 0.3, 0.5)

            -- Row pool
            f.rows = {}
            f.contentStartY = headerY - 18

            addonUsersFrame = f
        end

        -- Reposition next to settings panel
        local f = addonUsersFrame
        local configFrame = _G["MITConfigFrame"]
        if configFrame and configFrame:IsShown() then
            f:ClearAllPoints()
            f:SetPoint("TOPRIGHT", configFrame, "TOPLEFT", -6, 0)
        end

        -- Refresh data
        local CLASS_COLORS = RAID_CLASS_COLORS

        -- Collect group members
        local members = {}
        local maxUnit, prefix
        if IsInRaid() then
            maxUnit, prefix = GetNumGroupMembers(), "raid"
        elseif IsInGroup() then
            maxUnit, prefix = 4, "party"
        else
            maxUnit, prefix = 0, "party"
        end

        -- Add self
        local myName = UnitName("player")
        local _, myClass = UnitClass("player")
        table.insert(members, { name = myName, class = myClass, hasAddon = true, isPlayer = true })

        for i = 1, maxUnit do
            local u = prefix .. i
            if UnitExists(u) and not UnitIsUnit(u, "player") then
                local name = UnitName(u)
                local _, cls = UnitClass(u)
                if name and cls then
                    table.insert(members, { name = name, class = cls, hasAddon = false, isPlayer = false })
                end
            end
        end

        -- Sort: addon users first, then alphabetical
        table.sort(members, function(a, b)
            if a.isPlayer then return true end
            if b.isPlayer then return false end
            if a.hasAddon ~= b.hasAddon then return a.hasAddon end
            return a.name < b.name
        end)

        -- Create/reuse rows
        local rowH = 20
        for i, member in ipairs(members) do
            local row = f.rows[i]
            if not row then
                row = CreateFrame("Frame", nil, f)
                row:SetSize(296, rowH)

                local rowBg = row:CreateTexture(nil, "BACKGROUND")
                rowBg:SetAllPoints()
                rowBg:SetTexture(FLAT_TEX)
                row.bg = rowBg

                local nameText = row:CreateFontString(nil, "OVERLAY")
                nameText:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
                nameText:SetPoint("LEFT", 6, 0)
                row.nameText = nameText

                local statusText = row:CreateFontString(nil, "OVERLAY")
                statusText:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
                statusText:SetPoint("RIGHT", -6, 0)
                row.statusText = statusText

                f.rows[i] = row
            end

            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 12, f.contentStartY - (i - 1) * (rowH + 2))

            -- Alternate row colors
            if i % 2 == 0 then
                row.bg:SetVertexColor(0.08, 0.08, 0.10, 0.5)
            else
                row.bg:SetVertexColor(0.05, 0.05, 0.07, 0.3)
            end

            -- Class colored name
            local cc = CLASS_COLORS[member.class]
            local colorHex = cc and cc.colorStr or "ffffffff"
            row.nameText:SetText("|c" .. colorHex .. member.name .. "|r")

            -- Status
            if member.isPlayer then
                row.statusText:SetText("|cFF66FF66YOU|r")
            elseif member.hasAddon then
                row.statusText:SetText("|cFF00FF00|TInterface\\RAIDFRAME\\ReadyCheck-Ready:0|t AkcQOL|r")
            else
                row.statusText:SetText("|cFF888888|TInterface\\RAIDFRAME\\ReadyCheck-NotReady:0|t No Addon|r")
            end

            row:Show()
        end

        -- Hide extra rows
        for i = #members + 1, #f.rows do
            if f.rows[i] then f.rows[i]:Hide() end
        end

        -- Resize frame height
        local contentH = #members * (rowH + 2) + 20
        f:SetHeight(math.max(120, 50 + contentH))

        -- Summary at bottom
        if not f.summary then
            f.summary = f:CreateFontString(nil, "OVERLAY")
            f.summary:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
        end
        local addonCount = 0
        for _, m in ipairs(members) do if m.hasAddon then addonCount = addonCount + 1 end end
        f.summary:ClearAllPoints()
        f.summary:SetPoint("BOTTOMLEFT", 12, 6)
        f.summary:SetText(string.format("|cFF888888%d/%d members have AkcQOL|r", addonCount, #members))

        f:Show()
    end
end

-- =========================================================================
-- LOG SYSTEM (continued)
-- =========================================================================

function Enrage_ShowLogWindow(logType)
    EnsureLogDB()
    local titles = ENRAGE_LOG_TITLES
    local frameKey = "WVLog_" .. logType

    if WV_LOG_FRAMES[logType] then
        if WV_LOG_FRAMES[logType]:IsShown() then
            WV_LOG_FRAMES[logType]:Hide()
        else
            WV_LOG_FRAMES[logType]:Show()
        end
        return
    end

    local color = Enrage_GetLogColor(logType)
    local title = titles[logType] or logType or "Log"
    local f = CreateFrame("Frame", frameKey, UIParent, "BackdropTemplate")
    f:SetSize(1120, 660)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(650)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetResizable(true)
    if f.SetResizeBounds then
        f:SetResizeBounds(760, 430, 1320, 860)
    else
        f:SetMinResize(760, 430)
        f:SetMaxResize(1320, 860)
    end
    f:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
    f:SetBackdropColor(0.035, 0.036, 0.032, 0.88)
    f:SetBackdropBorderColor(color[1], color[2], color[3], 0.55)

    local titleBar = CreateFrame("Frame", nil, f)
    titleBar:SetPoint("TOPLEFT", f, "TOPLEFT", 54, 0)
    titleBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    titleBar:SetHeight(46)
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function() f:StartMoving() end)
    titleBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND", nil, 1)
    titleBg:SetAllPoints()
    titleBg:SetTexture(WV_FLAT_TEX)
    titleBg:SetVertexColor(0.045, 0.046, 0.043, 0.76)

    local titleBadge = CreateFrame("Frame", nil, f)
    titleBadge:SetSize(180, 34)
    titleBadge:SetPoint("BOTTOM", f, "TOP", 0, -8)
    local badgeBg = titleBadge:CreateTexture(nil, "BACKGROUND")
    badgeBg:SetAllPoints()
    badgeBg:SetTexture(WV_FLAT_TEX)
    badgeBg:SetVertexColor(0.035, 0.036, 0.032, 0.92)
    local badgeLine = titleBadge:CreateTexture(nil, "BORDER")
    badgeLine:SetPoint("BOTTOMLEFT")
    badgeLine:SetPoint("BOTTOMRIGHT")
    badgeLine:SetHeight(1)
    badgeLine:SetTexture(WV_FLAT_TEX)
    badgeLine:SetVertexColor(color[1], color[2], color[3], 0.65)
    local badgeText = titleBadge:CreateFontString(nil, "OVERLAY")
    badgeText:SetFont(WV_FONT_FACE, 17, WV_FONT_FLAGS)
    badgeText:SetPoint("CENTER")
    badgeText:SetText("|cFFF59E0BAkcQOL|r")

    local titleText = f:CreateFontString(nil, "OVERLAY")
    titleText:SetFont(WV_FONT_FACE, 15, WV_FONT_FLAGS)
    titleText:SetPoint("TOP", f, "TOP", 27, -18)
    titleText:SetText(Enrage_ColorText(color, title))

    local closeBtn = Enrage_CreateGlassButton(titleBar, "|cFFFF4D4DX|r", 24, 22, {1.0, 0.24, 0.2})
    closeBtn:SetPoint("RIGHT", titleBar, "RIGHT", -10, 0)
    closeBtn:SetScript("OnClick", function() Enrage_SafeHideFrame(f) end)

    Enrage_CreateLogNavRail(f, logType)

    local searchFrame = CreateFrame("Frame", nil, f, "BackdropTemplate")
    searchFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 72, -62)
    searchFrame:SetSize(250, 28)
    searchFrame:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
    searchFrame:SetBackdropColor(0.085, 0.088, 0.095, 0.94)
    searchFrame:SetBackdropBorderColor(0.18, 0.19, 0.22, 1)

    local searchIcon = searchFrame:CreateFontString(nil, "OVERLAY")
    searchIcon:SetFont(WV_FONT_FACE, 13, WV_FONT_FLAGS)
    searchIcon:SetPoint("LEFT", 9, 0)
    searchIcon:SetText("|cFF8A8F98Search|r")

    local searchBox = CreateFrame("EditBox", nil, searchFrame)
    searchBox:SetPoint("LEFT", searchIcon, "RIGHT", 8, 0)
    searchBox:SetPoint("RIGHT", searchFrame, "RIGHT", -8, 0)
    searchBox:SetHeight(22)
    searchBox:SetFont("Fonts\\ARIALN.TTF", 12, "")
    searchBox:SetTextColor(0.93, 0.94, 0.98, 1)
    searchBox:SetAutoFocus(false)
    searchBox:EnableMouse(true)
    f.searchBox = searchBox

    local filters = CreateFrame("Frame", nil, f)
    filters:SetPoint("LEFT", searchFrame, "RIGHT", 26, 0)
    filters:SetSize(470, 28)

    local allChars = Enrage_CreateLogCheckbox(filters, "All characters", 150, true, function()
        if f.RefreshLogContent then f.RefreshLogContent() end
    end)
    allChars:SetPoint("LEFT", filters, "LEFT", 0, 0)
    f.allCharsCheck = allChars

    local todayOnly = Enrage_CreateLogCheckbox(filters, "Only show today", 160, false, function()
        if f.RefreshLogContent then f.RefreshLogContent() end
    end)
    todayOnly:SetPoint("LEFT", allChars, "RIGHT", 18, 0)
    f.todayCheck = todayOnly

    local totalText = f:CreateFontString(nil, "OVERLAY")
    totalText:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
    totalText:SetJustifyH("RIGHT")
    totalText:SetPoint("TOPRIGHT", f, "TOPRIGHT", -22, -58)
    totalText:SetTextColor(0.92, 0.94, 0.98, 1)
    f.totalText = totalText

    local header = CreateFrame("Frame", nil, f)
    header:SetPoint("TOPLEFT", f, "TOPLEFT", 72, -112)
    header:SetPoint("TOPRIGHT", f, "TOPRIGHT", -24, -112)
    header:SetHeight(30)
    local headerBg = header:CreateTexture(nil, "BACKGROUND")
    headerBg:SetAllPoints()
    headerBg:SetTexture(WV_FLAT_TEX)
    headerBg:SetVertexColor(color[1] * 0.14, color[2] * 0.14, color[3] * 0.14, 0.82)

    local dateHead = header:CreateFontString(nil, "OVERLAY")
    dateHead:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
    dateHead:SetPoint("LEFT", 12, 0)
    dateHead:SetWidth(155)
    dateHead:SetJustifyH("LEFT")
    dateHead:SetText("|cFFE5E7EBDate|r")

    local charHead = header:CreateFontString(nil, "OVERLAY")
    charHead:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
    charHead:SetPoint("LEFT", dateHead, "RIGHT", 18, 0)
    charHead:SetWidth(190)
    charHead:SetJustifyH("LEFT")
    charHead:SetText("|cFFE5E7EBCharacter|r")

    local entryHead = header:CreateFontString(nil, "OVERLAY")
    entryHead:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
    entryHead:SetPoint("LEFT", charHead, "RIGHT", 18, 0)
    entryHead:SetPoint("RIGHT", header, "RIGHT", -12, 0)
    entryHead:SetJustifyH("LEFT")
    entryHead:SetText("|cFFE5E7EBEntry|r")

    local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -1)
    scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 56)

    local scrollChild = CreateFrame("Frame", nil, scroll)
    scrollChild:SetWidth(1010)
    scrollChild:SetHeight(1)
    scroll:SetScrollChild(scrollChild)
    f.scrollChild = scrollChild
    f.rows = {}

    local resultText = f:CreateFontString(nil, "OVERLAY")
    resultText:SetFont(WV_FONT_FACE, 13, WV_FONT_FLAGS)
    resultText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 72, 17)
    resultText:SetTextColor(0.95, 0.96, 0.98, 1)
    f.resultText = resultText

    local popupName = "ENRAGE_CLEAR_LOG_" .. logType:upper()
    StaticPopupDialogs[popupName] = {
        text = "Are you sure you want to clear the " .. (titles[logType] or logType) .. "?",
        button1 = "Yes",
        button2 = "No",
        OnAccept = function()
            EnsureLogDB()
            EnrageDB.global.logs[logType] = {}
            if ENRAGE_CHARACTER_LOG_TYPES[logType] and EnrageDB.global.logsByChar then
                EnrageDB.global.logsByChar[logType] = {}
            end
            if EnrageDB.global.logsByCharMigrated then
                EnrageDB.global.logsByCharMigrated[logType] = true
            end
            if f.searchBox then f.searchBox:SetText("") end
            if f.RefreshLogContent then f.RefreshLogContent() end
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }

    local exportBtn = Enrage_CreateGlassButton(f, "|cFFE5E7EBExport Log|r", 128, 30, color)
    exportBtn:SetPoint("BOTTOM", f, "BOTTOM", 74, 13)
    exportBtn:SetScript("OnClick", function()
        Enrage_ShowLogExport(title, f.currentExportText or "")
    end)

    local clearBtn = Enrage_CreateGlassButton(f, "|cFFE5E7EBClear Log|r", 128, 30, {0.95, 0.38, 0.32})
    clearBtn:SetPoint("RIGHT", exportBtn, "LEFT", -12, 0)
    clearBtn:SetScript("OnClick", function()
        StaticPopup_Show(popupName)
    end)

    local function RefreshLogContent()
        EnsureLogDB()
        local showAll = allChars:GetChecked()
        local player = Enrage_GetPlayerTag()
        local rawEntries = {}
        local usedByCharBuckets = false
        local function AppendEntries(source)
            if type(source) ~= "table" then return end
            for i = 1, #source do
                rawEntries[#rawEntries + 1] = source[i]
            end
        end

        if ENRAGE_CHARACTER_LOG_TYPES[logType] and EnrageDB.global.logsByChar and EnrageDB.global.logsByChar[logType] then
            local byType = EnrageDB.global.logsByChar[logType]
            usedByCharBuckets = true
            if showAll then
                for _, list in pairs(byType) do
                    AppendEntries(list)
                end
            else
                AppendEntries(byType[player])
            end
        end

        if #rawEntries == 0 then
            AppendEntries(EnrageDB.global.logs[logType] or {})
        end

        local entries = {}
        local seenEntries = {}
        for i = 1, #rawEntries do
            local clean = Enrage_UntaintLog(rawEntries[i])
            if clean and not seenEntries[clean] then
                seenEntries[clean] = true
                entries[#entries + 1] = clean
                Enrage_StoreLogEntryByChar(logType, clean, false)
            end
        end
        if not usedByCharBuckets then
            EnrageDB.global.logs[logType] = entries
        end
        local query = TRLower(Enrage_UntaintLog(searchBox:GetText()) or "")
        local today = date("%Y-%m-%d")
        local onlyToday = todayOnly:GetChecked()
        local filtered = {}

        for _, entry in ipairs(entries) do
            local dt, char, body = Enrage_ParseLogEntry(entry)
            local dateOK = not onlyToday or (dt ~= "" and string.sub(dt, 1, 10) == today)
            local charOK = showAll or char == "" or char == player
            local searchOK = query == "" or TRLower(entry):find(query, 1, true)
            if dateOK and charOK and searchOK then
                filtered[#filtered + 1] = {
                    raw = entry,
                    dateText = dt,
                    charText = char,
                    bodyText = body,
                }
            end
        end

        if #filtered > 1 then
            table.sort(filtered, function(a, b)
                local av = a.dateText ~= "" and a.dateText or a.raw
                local bv = b.dateText ~= "" and b.dateText or b.raw
                return av > bv
            end)
        end

        for _, row in ipairs(f.rows) do
            row:Hide()
        end

        local exportLines = {}
        local rowHeight = 30
        local width = math.max(480, (scroll:GetWidth() or (f:GetWidth() - 110)))
        scrollChild:SetWidth(width)

        if #filtered == 0 then
            local row = f.rows[1]
            if not row then
                row = CreateFrame("Frame", nil, scrollChild)
                row:SetHeight(rowHeight)
                row.text = row:CreateFontString(nil, "OVERLAY")
                row.text:SetFont(WV_FONT_FACE, 12, WV_FONT_FLAGS)
                row.text:SetPoint("LEFT", 12, 0)
                row.text:SetPoint("RIGHT", row, "RIGHT", -12, 0)
                row.text:SetJustifyH("LEFT")
                f.rows[1] = row
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, 0)
            row:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)
            row:SetHeight(rowHeight)
            row.text:SetText("|cFF8A8F98No entries.|r")
            row.rawText = nil
            Enrage_UpdateLogLinkHotspots(row, nil)
            row:Show()
            scrollChild:SetHeight(rowHeight + 8)
        else
            for i, entry in ipairs(filtered) do
                local row = f.rows[i]
                if not row then
                    row = CreateFrame("Button", nil, scrollChild)
                    row:SetHeight(rowHeight)
                    row.bg = row:CreateTexture(nil, "BACKGROUND")
                    row.bg:SetAllPoints()
                    row.bg:SetTexture(WV_FLAT_TEX)
                    row.left = row:CreateTexture(nil, "BORDER")
                    row.left:SetPoint("TOPLEFT")
                    row.left:SetPoint("BOTTOMLEFT")
                    row.left:SetWidth(3)
                    row.left:SetTexture(WV_FLAT_TEX)
                    row.left:SetVertexColor(color[1], color[2], color[3], 0.8)

                    row.date = row:CreateFontString(nil, "OVERLAY")
                    row.date:SetFont("Fonts\\ARIALN.TTF", 12, "")
                    row.date:SetPoint("LEFT", 12, 0)
                    row.date:SetWidth(155)
                    row.date:SetJustifyH("LEFT")
                    row.date:SetTextColor(0.93, 0.94, 0.98, 1)

                    row.char = row:CreateFontString(nil, "OVERLAY")
                    row.char:SetFont("Fonts\\ARIALN.TTF", 12, "")
                    row.char:SetPoint("LEFT", row.date, "RIGHT", 18, 0)
                    row.char:SetWidth(190)
                    row.char:SetJustifyH("LEFT")
                    row.char:SetTextColor(0.88, 0.9, 0.94, 1)

                    row.body = row:CreateFontString(nil, "OVERLAY")
                    row.body:SetFont("Fonts\\ARIALN.TTF", 12, "")
                    row.body:SetPoint("LEFT", row.char, "RIGHT", 18, 0)
                    row.body:SetPoint("RIGHT", row, "RIGHT", -12, 0)
                    row.body:SetJustifyH("LEFT")
                    row.body:SetWordWrap(false)
                    row.body:SetTextColor(0.93, 0.94, 0.98, 1)
                    Enrage_EnableLogHyperlinks(row.body, row)

                    row:SetScript("OnEnter", function(self)
                        self.bg:SetVertexColor(color[1] * 0.18, color[2] * 0.18, color[3] * 0.18, 0.72)
                    end)
                    row:SetScript("OnLeave", function(self)
                        GameTooltip:Hide()
                        if self.rowIndex and self.rowIndex % 2 == 0 then
                            self.bg:SetVertexColor(0.07, 0.072, 0.078, 0.64)
                        else
                            self.bg:SetVertexColor(0.025, 0.026, 0.028, 0.42)
                        end
                    end)
                    f.rows[i] = row
                end

                row.rowIndex = i
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -((i - 1) * rowHeight))
                row:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)
                row:SetHeight(rowHeight)
                if i % 2 == 0 then
                    row.bg:SetVertexColor(0.07, 0.072, 0.078, 0.64)
                else
                    row.bg:SetVertexColor(0.025, 0.026, 0.028, 0.42)
                end
                row.date:SetText(entry.dateText ~= "" and entry.dateText or "-")
                row.char:SetText(entry.charText ~= "" and entry.charText or "-")
                row.body:SetText(entry.bodyText ~= "" and entry.bodyText or entry.raw)
                row.rawText = entry.raw
                Enrage_UpdateLogLinkHotspots(row, entry.bodyText ~= "" and entry.bodyText or entry.raw)
                row:Show()

                exportLines[#exportLines + 1] = entry.raw
            end
            scrollChild:SetHeight(#filtered * rowHeight + 8)
        end

        local totalStored = #entries
        totalText:SetText(string.format("|cFFE5E7EBTotal Stored:|r %s\n|cFFE5E7EBShowing:|r %s",
            Enrage_ColorText(color, totalStored),
            Enrage_ColorText(color, #filtered)
        ))
        resultText:SetText(string.format("|cFFE5E7EBCurrent Results:|r %s", Enrage_ColorText(color, #filtered)))
        f.currentExportText = table.concat(exportLines, "\n")
        scroll:SetVerticalScroll(0)
    end

    f.RefreshLogContent = RefreshLogContent
    searchBox:SetScript("OnTextChanged", function() RefreshLogContent() end)
    searchBox:SetScript("OnEscapePressed", function(self)
        self:SetText("")
        self:ClearFocus()
        RefreshLogContent()
    end)
    searchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    f:SetScript("OnSizeChanged", function(self, w)
        scrollChild:SetWidth(math.max(480, w - 110))
        if f.RefreshLogContent then f.RefreshLogContent() end
    end)

    local resizeGrip = CreateFrame("Button", nil, f)
    resizeGrip:SetSize(18, 18)
    resizeGrip:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -4, 4)
    local logGripPos = {{0,0},{5,0},{10,0},{5,5},{10,5},{10,10}}
    for _, pos in ipairs(logGripPos) do
        local dot = resizeGrip:CreateTexture(nil, "OVERLAY")
        dot:SetTexture(WV_FLAT_TEX)
        dot:SetVertexColor(color[1], color[2], color[3], 0.58)
        dot:SetSize(2, 2)
        dot:SetPoint("BOTTOMRIGHT", resizeGrip, "BOTTOMRIGHT", -pos[1], pos[2])
    end
    resizeGrip:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" then f:StartSizing("BOTTOMRIGHT") end
    end)
    resizeGrip:SetScript("OnMouseUp", function() f:StopMovingOrSizing() end)

    f:SetScript("OnShow", function() RefreshLogContent() end)

    WV_LOG_FRAMES[logType] = f
    RefreshLogContent()
    f:Show()
end

-- =========================================================================
-- CHAT LOG VIEWER (tabbed per channel)
-- =========================================================================
function Enrage_ShowChatLogWindow()
    EnsureLogDB()
    local frameKey = "WVLog_chat"

    if WV_LOG_FRAMES["chat"] then
        if WV_LOG_FRAMES["chat"]:IsShown() then
            WV_LOG_FRAMES["chat"]:Hide()
        else
            WV_LOG_FRAMES["chat"]:Show()
        end
        return
    end

    local color = Enrage_GetLogColor("chat")
    local f = CreateFrame("Frame", frameKey, UIParent, "BackdropTemplate")
    f:SetSize(1120, 660)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(650)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetResizable(true)
    if f.SetResizeBounds then
        f:SetResizeBounds(760, 430, 1320, 860)
    else
        f:SetMinResize(760, 430)
        f:SetMaxResize(1320, 860)
    end
    f:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
    f:SetBackdropColor(0.035, 0.036, 0.032, 0.88)
    f:SetBackdropBorderColor(color[1], color[2], color[3], 0.55)

    -- Background
    local fBG = f:CreateTexture(nil, "BACKGROUND")
    fBG:SetAllPoints()
    fBG:SetTexture(WV_FLAT_TEX)
    fBG:SetVertexColor(0.035, 0.036, 0.032, 0.72)

    -- Cyan border lines
    WV_CreateBorder(f, "TOPLEFT", "TOPLEFT", "TOPRIGHT", "TOPRIGHT", nil, 1)
    WV_CreateBorder(f, "BOTTOMLEFT", "BOTTOMLEFT", "BOTTOMRIGHT", "BOTTOMRIGHT", nil, 1)
    WV_CreateBorder(f, "TOPLEFT", "TOPLEFT", "BOTTOMLEFT", "BOTTOMLEFT", 1, nil)
    WV_CreateBorder(f, "TOPRIGHT", "TOPRIGHT", "BOTTOMRIGHT", "BOTTOMRIGHT", 1, nil)

    -- Title bar
    local titleBar = CreateFrame("Frame", nil, f)
    titleBar:SetPoint("TOPLEFT", f, "TOPLEFT", 54, 0)
    titleBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
    titleBar:SetHeight(46)
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function() f:StartMoving() end)
    titleBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND", nil, 1)
    titleBg:SetAllPoints()
    titleBg:SetTexture(WV_FLAT_TEX)
    titleBg:SetVertexColor(0.045, 0.046, 0.043, 0.76)

    Enrage_CreateLogNavRail(f, "chat")

    local logTitleSep = f:CreateTexture(nil, "ARTWORK")
    logTitleSep:SetTexture(WV_FLAT_TEX)
    logTitleSep:SetVertexColor(0.3, 0.8, 0.9, 0.6)
    logTitleSep:SetPoint("TOPLEFT", titleBar, "BOTTOMLEFT", 0, 0)
    logTitleSep:SetPoint("TOPRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
    logTitleSep:SetHeight(1)

    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    titleText:SetFont(WV_FONT_FACE, 15, WV_FONT_FLAGS)
    titleText:SetPoint("TOP", f, "TOP", 27, -18)
    titleText:SetText(Enrage_ColorText(color, "Chat Log"))

    local titleBadge = CreateFrame("Frame", nil, f)
    titleBadge:SetSize(180, 34)
    titleBadge:SetPoint("BOTTOM", f, "TOP", 0, -8)
    local badgeBg = titleBadge:CreateTexture(nil, "BACKGROUND")
    badgeBg:SetAllPoints()
    badgeBg:SetTexture(WV_FLAT_TEX)
    badgeBg:SetVertexColor(0.035, 0.036, 0.032, 0.92)
    local badgeLine = titleBadge:CreateTexture(nil, "BORDER")
    badgeLine:SetPoint("BOTTOMLEFT")
    badgeLine:SetPoint("BOTTOMRIGHT")
    badgeLine:SetHeight(1)
    badgeLine:SetTexture(WV_FLAT_TEX)
    badgeLine:SetVertexColor(color[1], color[2], color[3], 0.65)
    local badgeText = titleBadge:CreateFontString(nil, "OVERLAY")
    badgeText:SetFont(WV_FONT_FACE, 17, WV_FONT_FLAGS)
    badgeText:SetPoint("CENTER")
    badgeText:SetText("|cFFF59E0BAkcQOL|r")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar)
    closeBtn:SetSize(24, 24)
    closeBtn:SetPoint("RIGHT", titleBar, "RIGHT", -4, 0)
    local closeTxt = closeBtn:CreateFontString(nil, "OVERLAY")
    closeTxt:SetFont(WV_FONT_FACE, 14, WV_FONT_FLAGS)
    closeTxt:SetAllPoints()
    closeTxt:SetText("|cFFFF4444X|r")
    closeBtn:SetScript("OnClick", function() Enrage_SafeHideFrame(f) end)
    closeBtn:SetScript("OnEnter", function() closeTxt:SetText("|cFFFF0000X|r") end)
    closeBtn:SetScript("OnLeave", function() closeTxt:SetText("|cFFFF4444X|r") end)

    -- Clear button
    local clearBtn = CreateFrame("Button", nil, titleBar)
    clearBtn:SetSize(50, 18)
    clearBtn:SetPoint("RIGHT", closeBtn, "LEFT", -5, 0)
    local clearBtnText = clearBtn:CreateFontString(nil, "OVERLAY")
    clearBtnText:SetFont(WV_FONT_FACE, 11, WV_FONT_FLAGS)
    clearBtnText:SetText("|cFFFF4444Clear|r")
    clearBtnText:SetPoint("CENTER")

    local resultText = f:CreateFontString(nil, "OVERLAY")
    resultText:SetFont(WV_FONT_FACE, 13, WV_FONT_FLAGS)
    resultText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 72, 17)
    resultText:SetTextColor(0.95, 0.96, 0.98, 1)
    f.resultText = resultText

    local exportBtn = Enrage_CreateGlassButton(f, "|cFFE5E7EBExport Chat|r", 128, 30, color)
    exportBtn:SetPoint("BOTTOM", f, "BOTTOM", 27, 13)
    exportBtn:SetScript("OnClick", function()
        Enrage_ShowLogExport("Chat Log", f.currentExportText or "")
    end)

    -- Tab bar (channel tabs)
    local tabBar = CreateFrame("Frame", nil, f)
    tabBar:SetPoint("TOPLEFT", f, "TOPLEFT", 72, -96)
    tabBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", -24, -96)
    tabBar:SetHeight(26)

    local tabBarBg = tabBar:CreateTexture(nil, "BACKGROUND")
    tabBarBg:SetAllPoints()
    tabBarBg:SetTexture(WV_FLAT_TEX)
    tabBarBg:SetVertexColor(0.06, 0.06, 0.06, 1)

    -- Search bar
    local searchBar = CreateFrame("Frame", nil, f, "BackdropTemplate")
    searchBar:SetPoint("TOPLEFT", f, "TOPLEFT", 72, -62)
    searchBar:SetSize(250, 28)
    searchBar:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
    searchBar:SetBackdropColor(0.085, 0.088, 0.095, 0.94)
    searchBar:SetBackdropBorderColor(0.18, 0.19, 0.22, 1)

    local searchBg = searchBar:CreateTexture(nil, "BACKGROUND")
    searchBg:SetAllPoints()
    searchBg:SetTexture(WV_FLAT_TEX)
    searchBg:SetVertexColor(0.085, 0.088, 0.095, 0.94)

    local searchIcon = searchBar:CreateFontString(nil, "OVERLAY")
    searchIcon:SetFont(WV_FONT_FACE, 13, WV_FONT_FLAGS)
    searchIcon:SetPoint("LEFT", 9, 0)
    searchIcon:SetText("|cFF8A8F98Search|r")

    local searchBox = CreateFrame("EditBox", nil, searchBar)
    searchBox:SetPoint("LEFT", searchIcon, "RIGHT", 8, 0)
    searchBox:SetPoint("RIGHT", searchBar, "RIGHT", -8, 0)
    searchBox:SetHeight(22)
    searchBox:SetFont("Fonts\\ARIALN.TTF", 12, "")
    searchBox:SetTextColor(0.93, 0.94, 0.98, 1)
    searchBox:SetAutoFocus(false)
    searchBox:EnableMouse(true)
    f.searchBox = searchBox

    -- Scroll frame
    local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 72, -126)
    scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 56)

    -- Row-based scroll child (individual Frame rows - no EditBox/FontString re-render bugs)
    local scrollChild = CreateFrame("Frame", nil, scroll)
    scrollChild:SetWidth(scroll:GetWidth() or 490)
    scrollChild:SetHeight(1)
    scroll:SetScrollChild(scrollChild)
    f.scrollChild = scrollChild
    f.rows = {}

    local ROW_HEIGHT = 14

    f:SetScript("OnSizeChanged", function(self, w, h)
        local sw = w - 110
        scrollChild:SetWidth(sw)
        if f.RefreshChatContent then f.RefreshChatContent() end
    end)

    -- Current active channel
    f.activeChannel = "guild"

    local function RefreshChatContent()
        local ok, err = pcall(function()
            -- Hide all existing rows
            for _, row in ipairs(f.rows) do
                row:Hide()
            end

            EnsureLogDB()
            Enrage_MigrateLegacyBattleNetWhispers()
            local raw = EnrageDB.global.logs.chat[f.activeChannel] or {}
            local query = searchBox:GetText() or ""

                local display = {}
                for i = 1, #raw do
                    local v = raw[i]
                    if type(v) == "string" and v ~= "" then
                        local dt, author, body, clean = Enrage_ParseChatLogEntry(v)
                        local bodyText = Enrage_NormalizeStoredChatBody(f.activeChannel, body ~= "" and body or clean)
                        local displayText = clean
                        if Enrage_IsProtectedChatPayloadText(body) then
                            displayText = string.format("%s [%s] %s", dt ~= "" and dt or "-", author ~= "" and author or "-", bodyText)
                        end
                        if query == "" or TRLower(displayText):find(TRLower(query), 1, true) then
                            display[#display + 1] = displayText
                        end
                    end
                end

            if #display > 1 then
                table.sort(display, function(a, b) return a < b end)
            end

            f.currentExportText = table.concat(display, "\n")
            if f.resultText then
                f.resultText:SetText(string.format("|cFFE5E7EBCurrent Results:|r %s", Enrage_ColorText(color, #display)))
            end

            if #display == 0 then
                -- Show empty message row
                local row = f.rows[1]
                if not row then
                    row = CreateFrame("Frame", nil, scrollChild)
                    row:SetHeight(ROW_HEIGHT)
                    row.text = row:CreateFontString(nil, "OVERLAY")
                    row.text:SetFont("Fonts\\ARIALN.TTF", 12, "")
                    row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -1)
                    row.text:SetPoint("RIGHT", row, "RIGHT", -2, 0)
                    row.text:SetJustifyH("LEFT")
                    f.rows[1] = row
                end
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, 0)
                row:SetPoint("RIGHT", scrollChild, "RIGHT")
                row.text:SetText("|cFF888888No messages yet.|r")
                row:Show()
                scrollChild:SetHeight(ROW_HEIGHT + 10)
            else
                local yOff = 0
                for i = 1, #display do
                    local row = f.rows[i]
                    if not row then
                        row = CreateFrame("Frame", nil, scrollChild)
                        row.text = row:CreateFontString(nil, "OVERLAY")
                        -- ARIALN supports Turkish and Latin Extended glyphs; no outline keeps rendering clean.
                        row.text:SetFont("Fonts\\ARIALN.TTF", 12, "")
                        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -1)
                        row.text:SetPoint("RIGHT", row, "RIGHT", -2, 0)
                        row.text:SetJustifyH("LEFT")
                        row.text:SetJustifyV("TOP")
                        row.text:SetWordWrap(true)
                        f.rows[i] = row
                    end
                    row:ClearAllPoints()
                    row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -yOff)
                    row:SetPoint("RIGHT", scrollChild, "RIGHT")
                    row.text:SetText(display[i])
                    -- Dynamic row height based on actual rendered text height (handles wrapped multi-line messages)
                    local textH = row.text:GetStringHeight() or ROW_HEIGHT
                    local rowH = math.max(ROW_HEIGHT, math.ceil(textH) + 2)
                    row:SetHeight(rowH)
                    row:Show()
                    yOff = yOff + rowH
                end
                scrollChild:SetHeight(math.max(yOff + 10, 1))
            end
            Enrage_ScrollFrameToBottom(scroll)
        end)
        if not ok then
            for _, row in ipairs(f.rows) do row:Hide() end
            local row = f.rows[1]
            if not row then
                row = CreateFrame("Frame", nil, scrollChild)
                row:SetHeight(ROW_HEIGHT)
                row.text = row:CreateFontString(nil, "OVERLAY")
                row.text:SetFont("Fonts\\ARIALN.TTF", 12, "")
                row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -1)
                row.text:SetPoint("RIGHT", row, "RIGHT", -2, 0)
                row.text:SetJustifyH("LEFT")
                f.rows[1] = row
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, 0)
            row:SetPoint("RIGHT", scrollChild, "RIGHT")
            row.text:SetText("|cFFFF0000Error: " .. tostring(err) .. "|r")
            row:Show()
            scrollChild:SetHeight(100)
        end
    end
    f.RefreshChatContent = RefreshChatContent

    searchBox:SetScript("OnTextChanged", function() RefreshChatContent() end)
    searchBox:SetScript("OnEscapePressed", function(self) self:SetText(""); self:ClearFocus(); RefreshChatContent() end)
    searchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    -- Clear popup
    StaticPopupDialogs["ENRAGE_CLEAR_LOG_CHAT"] = {
        text = "Clear this channel's chat log?",
        button1 = "Yes",
        button2 = "No",
        OnAccept = function()
            EnsureLogDB()
            EnrageDB.global.logs.chat[f.activeChannel] = {}
            if f.rows then
                for _, row in ipairs(f.rows) do row:Hide() end
            end
            if f.searchBox then f.searchBox:SetText("") end
            if f.RefreshChatContent then f.RefreshChatContent() end
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3,
    }
    clearBtn:SetScript("OnClick", function() StaticPopup_Show("ENRAGE_CLEAR_LOG_CHAT") end)

    -- Create channel tab buttons
    local tabs = {}
    local tabX = 4
    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
        local tab = CreateFrame("Button", nil, tabBar)
        local labelW = ch.label:len() * 6 + 12
        tab:SetSize(labelW, 18)
        tab:SetPoint("LEFT", tabBar, "LEFT", tabX, 0)
        tabX = tabX + labelW + 2

        tab.bg = tab:CreateTexture(nil, "BACKGROUND")
        tab.bg:SetAllPoints()
        tab.bg:SetTexture(WV_FLAT_TEX)
        tab.bg:SetVertexColor(0.12, 0.12, 0.12, 0.9)

        tab.border = tab:CreateTexture(nil, "BORDER")
        tab.border:SetPoint("TOPLEFT", -1, 1)
        tab.border:SetPoint("BOTTOMRIGHT", 1, -1)
        tab.border:SetTexture(WV_FLAT_TEX)
        tab.border:SetVertexColor(ch.color[1] * 0.4, ch.color[2] * 0.4, ch.color[3] * 0.4, 0.6)

        tab.inner = tab:CreateTexture(nil, "ARTWORK")
        tab.inner:SetAllPoints()
        tab.inner:SetTexture(WV_FLAT_TEX)
        tab.inner:SetVertexColor(0.12, 0.12, 0.12, 0.9)

        tab.text = tab:CreateFontString(nil, "OVERLAY")
        tab.text:SetFont(WV_FONT_FACE, 9, WV_FONT_FLAGS)
        tab.text:SetAllPoints()
        tab.text:SetText(string.format("|cFF%02x%02x%02x%s|r", ch.color[1]*255, ch.color[2]*255, ch.color[3]*255, ch.label))

        tab.channelKey = ch.key
        tab.color = ch.color

        tab:SetScript("OnClick", function(self)
            f.activeChannel = self.channelKey
            -- Update tab visuals
            for _, t in ipairs(tabs) do
                t.inner:SetVertexColor(0.12, 0.12, 0.12, 0.9)
                t.border:SetVertexColor(t.color[1] * 0.4, t.color[2] * 0.4, t.color[3] * 0.4, 0.6)
            end
            self.inner:SetVertexColor(self.color[1] * 0.2, self.color[2] * 0.2, self.color[3] * 0.2, 1)
            self.border:SetVertexColor(self.color[1], self.color[2], self.color[3], 1)
            searchBox:SetText("")
            RefreshChatContent()
        end)

        tab:SetScript("OnEnter", function(self)
            if f.activeChannel ~= self.channelKey then
                self.inner:SetVertexColor(0.18, 0.18, 0.18, 0.9)
            end
        end)
        tab:SetScript("OnLeave", function(self)
            if f.activeChannel ~= self.channelKey then
                self.inner:SetVertexColor(0.12, 0.12, 0.12, 0.9)
            end
        end)

        tabs[#tabs + 1] = tab
    end

    -- Activate first tab (guild)
    tabs[1].inner:SetVertexColor(tabs[1].color[1] * 0.2, tabs[1].color[2] * 0.2, tabs[1].color[3] * 0.2, 1)
    tabs[1].border:SetVertexColor(tabs[1].color[1], tabs[1].color[2], tabs[1].color[3], 1)

    -- Resize grip
    local resizeGrip = CreateFrame("Button", nil, f)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -3, 3)
    local gripPos = {{0,0},{4,0},{8,0},{4,4},{8,4},{8,8}}
    for _, pos in ipairs(gripPos) do
        local dot = resizeGrip:CreateTexture(nil, "OVERLAY")
        dot:SetTexture(WV_FLAT_TEX)
        dot:SetVertexColor(color[1], color[2], color[3], 0.58)
        dot:SetSize(2, 2)
        dot:SetPoint("BOTTOMRIGHT", resizeGrip, "BOTTOMRIGHT", -pos[1], pos[2])
    end
    resizeGrip:SetScript("OnMouseDown", function(self, button)
        if button == "LeftButton" then f:StartSizing("BOTTOMRIGHT") end
    end)
    resizeGrip:SetScript("OnMouseUp", function() f:StopMovingOrSizing() end)

    f:SetScript("OnShow", function() RefreshChatContent() end)

    WV_LOG_FRAMES["chat"] = f
    f:Show()
end

-- Mail log tracking
local MailLogFrame = CreateFrame("Frame")
MailLogFrame:RegisterEvent("MAIL_SHOW")
MailLogFrame:RegisterEvent("MAIL_INBOX_UPDATE")
MailLogFrame.pendingRead = false
MailLogFrame:SetScript("OnEvent", function(self, event)
    if event == "MAIL_SHOW" then
        AddLogEntry("mail", "Mailbox opened")
        self.pendingRead = true
    elseif event == "MAIL_INBOX_UPDATE" and self.pendingRead then
        self.pendingRead = false
        local numItems = GetInboxNumItems() or 0
        if numItems > 0 then
            for i = 1, numItems do
                local _, _, sender, subject, money, _, daysLeft, qty = GetInboxHeaderInfo(i)
                if sender or subject then
                    local info = (sender or "Unknown") .. " | " .. (subject or "(no subject)")
                    if money and money > 0 then
                        info = info .. " | " .. GetCoinTextureString(money)
                    end
                    if qty and qty > 0 then
                        info = info .. " | Items: " .. qty
                    end
                    AddLogEntry("mail", info)
                end
            end
        end
    end
end)

-- Hook mail take actions and log when items or gold are taken.
hooksecurefunc("TakeInboxMoney", function(index)
    local _, _, sender, _, money = GetInboxHeaderInfo(index)
    if money and money > 0 then
        AddLogEntry("mail", "Took " .. GetCoinTextureString(money) .. " from " .. (sender or "?"))
    end
end)

hooksecurefunc("TakeInboxItem", function(index, attachmentIndex)
    local _, _, sender = GetInboxHeaderInfo(index)
    local name, itemID, texture, count = GetInboxItem(index, attachmentIndex)
    if name then
        local cnt = (count and count > 1) and (count .. "x ") or ""
        AddLogEntry("mail", "Took " .. cnt .. name .. " from " .. (sender or "?"))
    end
end)

if TakeInboxAttachments then
    hooksecurefunc("TakeInboxAttachments", function(index)
        local _, _, sender, _, money = GetInboxHeaderInfo(index)
        local parts = {}
        if money and money > 0 then
            parts[#parts + 1] = GetCoinTextureString(money)
        end
        for ai = 1, ATTACHMENTS_MAX_RECEIVE or 16 do
            local name, _, _, count = GetInboxItem(index, ai)
            if name then
                local cnt = (count and count > 1) and (count .. "x ") or ""
                parts[#parts + 1] = cnt .. name
            end
        end
        if #parts > 0 then
            AddLogEntry("mail", "Took all (" .. table.concat(parts, ", ") .. ") from " .. (sender or "?"))
        end
    end)
end

-- Trade log tracking
local TradeLogFrame = CreateFrame("Frame")
TradeLogFrame:RegisterEvent("TRADE_SHOW")
TradeLogFrame:RegisterEvent("TRADE_ACCEPT_UPDATE")
TradeLogFrame:RegisterEvent("UI_INFO_MESSAGE")
TradeLogFrame.tradingWith = nil
TradeLogFrame.pendingTrade = nil
TradeLogFrame:SetScript("OnEvent", function(self, event, arg1, arg2)
    if event == "TRADE_SHOW" then
        local target = UnitName("NPC") or TradeFrameRecipientNameText and TradeFrameRecipientNameText:GetText() or "Unknown"
        self.tradingWith = target
        self.pendingTrade = nil
        AddLogEntry("trade", "Trade opened with " .. target)
    elseif event == "TRADE_ACCEPT_UPDATE" then
        -- Snapshot current trade contents
        local given = {}
        local received = {}
        for i = 1, 6 do
            local link = GetTradePlayerItemLink(i)
            if link then
                local _, _, numItems = GetTradePlayerItemInfo(i)
                if numItems and numItems > 1 then
                    table.insert(given, link .. " x" .. numItems)
                else
                    table.insert(given, link)
                end
            end
            link = GetTradeTargetItemLink(i)
            if link then
                local _, _, numItems = GetTradeTargetItemInfo(i)
                if numItems and numItems > 1 then
                    table.insert(received, link .. " x" .. numItems)
                else
                    table.insert(received, link)
                end
            end
        end
        self.pendingTrade = {
            given = given,
            received = received,
            givenMoney = GetPlayerTradeMoney() or 0,
            receivedMoney = GetTargetTradeMoney() or 0,
        }
    elseif event == "UI_INFO_MESSAGE" then
        local msg = arg2 or ""
        if msg:find("[Tt]rade") then
            if msg:find("complete") and self.pendingTrade then
                local pt = self.pendingTrade
                -- Build "Received" line (items + gold)
                local recvParts = {}
                for _, item in ipairs(pt.received) do
                    table.insert(recvParts, item)
                end
                if pt.receivedMoney > 0 then
                    table.insert(recvParts, GetCoinTextureString(pt.receivedMoney))
                end
                -- Build "Gave" line (items + gold)
                local gaveParts = {}
                for _, item in ipairs(pt.given) do
                    table.insert(gaveParts, item)
                end
                if pt.givenMoney > 0 then
                    table.insert(gaveParts, GetCoinTextureString(pt.givenMoney))
                end
                -- Insert received first so it appears below gave in newest-first log
                if #recvParts > 0 then
                    AddLogEntry("trade", "  Received: " .. table.concat(recvParts, ", "))
                end
                if #gaveParts > 0 then
                    AddLogEntry("trade", "  Gave: " .. table.concat(gaveParts, ", "))
                end
                self.pendingTrade = nil
            end
            AddLogEntry("trade", msg)
        end
    end
end)

-- Loot log tracking
ENRAGE_RECENT_LOOT_LOGS = ENRAGE_RECENT_LOOT_LOGS or {}

function Enrage_EscapePattern(value)
    value = Enrage_EarlyCleanString(value) or ""
    return value:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
end

function Enrage_IsSelfLootMessage(msg)
    local clean = Enrage_EarlyCleanString(msg)
    if not clean or clean == "" then return false end

    if clean:sub(1, 11) == "You receive" or clean:sub(1, 7) == "You won" or clean:sub(1, 10) == "You create" then
        return true
    end

    local name = UnitName and UnitName("player")
    if name and name ~= "" then
        local escapedName = Enrage_EscapePattern(name)
        if clean:match("^" .. escapedName .. "%s+receives") or clean:match("^" .. escapedName .. "%s+won") then
            return true
        end
    end

    return false
end

function AddLootLogEntry(text)
    text = Enrage_EarlyCleanString(text)
    if not text or text == "" then return end

    local now = (GetTime and GetTime()) or 0
    local recent = ENRAGE_RECENT_LOOT_LOGS[text]
    if recent and (now - recent) < 1.5 then return end
    ENRAGE_RECENT_LOOT_LOGS[text] = now

    AddLogEntry("loot", text)
end

local LootLogFrame = CreateFrame("Frame")
LootLogFrame:RegisterEvent("LOOT_OPENED")
LootLogFrame:RegisterEvent("CHAT_MSG_LOOT")
LootLogFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "LOOT_OPENED" then
        local numLoot = GetNumLootItems() or 0
        if numLoot > 0 then
            for i = 1, numLoot do
                local lootIcon, lootName, lootQuantity, currencyID, lootQuality = GetLootSlotInfo(i)
                if lootName then
                    local entry = lootName
                    if lootQuantity and lootQuantity > 1 then
                        entry = entry .. " x" .. lootQuantity
                    end
                    AddLootLogEntry(entry)
                end
            end
        end
    elseif event == "CHAT_MSG_LOOT" then
        local msg = ...
        if msg and Enrage_IsSelfLootMessage(msg) then
            AddLootLogEntry(msg)
        end
    end
end)

-- =========================================================================
-- QUEST TRACKING: WEEKLY SPARK & HUNT
-- =========================================================================
-- Midnight weekly Spark only (Arcantina 93767, Saltheril's Soiree 93889). Exclude one-time/other quests.
local WV_SPARK_QUEST_IDS = { 93767, 93889 }
-- Spark cap: calculated from weeks since season start (1 per week).
-- Midnight Season 1 first spark quest: week of Feb 18, 2026.
-- First weekly reset (US) = Feb 18 2026 15:00 UTC.
local WV_SPARK_SEASON_START = 1771426800  -- 2026-02-18 15:00:00 UTC

local WV_DELVE_BOUNTY_QUEST_ID = 86371
local WV_NEMESIS_NPC_ID = 252892  -- Nullaeus, Torment's Rise nemesis boss

local function GetDelveBountyCompleted()
    if not C_QuestLog or not C_QuestLog.IsQuestFlaggedCompleted then return false end
    return C_QuestLog.IsQuestFlaggedCompleted(WV_DELVE_BOUNTY_QUEST_ID)
end

-- Nemesis kill tracked via BOSS_KILL/ENCOUNTER_END event (no weekly quest ID exists)
-- Stored in EnrageDB[charName].nemesisCompleted, reset weekly by CheckWeeklyReset()
local function MarkNemesisDone()
    if not EnrageDB then return end
    local name, realm = UnitFullName("player")
    local charName = (realm and realm ~= "") and (name .. "-" .. realm) or (name or "Unknown")
    if not EnrageDB[charName] then return end
    if EnrageDB[charName].nemesisCompleted then return end  -- already tracked
    EnrageDB[charName].nemesisCompleted = true
    print("|cFFFF8000[AkcQOL]|r Nemesis kill tracked.")
end

local NemesisEventFrame = CreateFrame("Frame")
NemesisEventFrame:RegisterEvent("BOSS_KILL")
NemesisEventFrame:RegisterEvent("ENCOUNTER_END")
NemesisEventFrame:RegisterEvent("CHAT_MSG_LOOT")
NemesisEventFrame:SetScript("OnEvent", function(_, event, ...)
    if not EnrageDB then return end

    if event == "BOSS_KILL" then
        local _, rawName = ...
        local bossName = CleanStr(rawName, nil)
        if bossName and (bossName:lower():find("nullaeus")) then
            MarkNemesisDone()
        end

    elseif event == "ENCOUNTER_END" then
        local _, _, _, _, success = ...
        if success == 1 then
            for i = 1, 5 do
                local bossUnit = "boss" .. i
                if UnitExists(bossUnit) then
                    local ok2, guid = pcall(UnitGUID, bossUnit)
                    if ok2 and guid then
                        local ok3, _, _, _, _, _, npcStr = pcall(strsplit, "-", guid)
                        if ok3 and tonumber(npcStr) == WV_NEMESIS_NPC_ID then
                            MarkNemesisDone()
                            return
                        end
                    end
                end
            end
        end

    elseif event == "CHAT_MSG_LOOT" then
        -- Detect "Spoils of Nullaeus" loot (item 254253)
        local lootMsg = CleanStr((...), nil)
        if lootMsg and (lootMsg:find("254253") or lootMsg:lower():find("nullaeus")) then
            MarkNemesisDone()
        end
    end
end)

-- Slash command to manually mark/unmark nemesis for current character
SlashCmdList["ENRAGENEMESIS"] = function(msg)
    if not EnrageDB then return end
    local name, realm = UnitFullName("player")
    local charName = (realm and realm ~= "") and (name .. "-" .. realm) or (name or "Unknown")
    if not EnrageDB[charName] then return end
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "done" then
        EnrageDB[charName].nemesisCompleted = true
        print("|cFFFF8000[AkcQOL]|r Nemesis marked as |cFF00FF00Done|r for " .. charName)
    elseif msg == "reset" then
        EnrageDB[charName].nemesisCompleted = false
        print("|cFFFF8000[AkcQOL]|r Nemesis marked as |cFFFF4444Not Done|r for " .. charName)
    else
        local status = EnrageDB[charName].nemesisCompleted and "|cFF00FF00Done|r" or "|cFFFF4444Not Done|r"
        print("|cFFFF8000[AkcQOL]|r Nemesis status: " .. status)
        print("  |cFF888888/ennm done|r  - mark as completed")
        print("  |cFF888888/ennm reset|r - mark as not done")
    end
end

local function GetWeeklySparkCompleted()
    if not C_QuestLog or not C_QuestLog.IsQuestFlaggedCompleted then return false end
    for _, questID in ipairs(WV_SPARK_QUEST_IDS) do
        if C_QuestLog.IsQuestFlaggedCompleted(questID) then
            return true
        end
    end
    return false
end

-- Spark cap based on weeks since season start (1 spark per week).
-- Also auto-corrects if any character somehow has more.
local function GetGlobalSparkCap()
    local now = GetServerTime and GetServerTime() or time()
    local elapsed = now - WV_SPARK_SEASON_START
    local weeksSinceStart = math.floor(elapsed / (7 * 24 * 3600))
    local cap = math.max(1, weeksSinceStart)  -- each completed week = 1 spark

    -- Safety: if any character has more sparks than calculated cap, use that
    if EnrageDB then
        for k, v in pairs(EnrageDB) do
            if k ~= "version" and k ~= "hiddenChars" and k ~= "global" and type(v) == "table" then
                local c = tonumber(v.sparkTotalEarned or v.sparkCount or 0) or 0
                if c > cap then cap = c end
            end
        end
    end
    return cap
end

-- Midnight Prey: Normal (91095-91124), Hard (91210-91255), Nightmare (91211-91241 step 2, 91256-91269)
local PREY_NORMAL_QUESTS = {}
for qid = 91095, 91124 do PREY_NORMAL_QUESTS[qid] = true end
local PREY_HARD_QUESTS = {}
for qid = 91210, 91242, 2 do PREY_HARD_QUESTS[qid] = true end
for qid = 91243, 91255 do PREY_HARD_QUESTS[qid] = true end
local PREY_NIGHTMARE_QUESTS = {}
for qid = 91211, 91241, 2 do PREY_NIGHTMARE_QUESTS[qid] = true end
for qid = 91256, 91269 do PREY_NIGHTMARE_QUESTS[qid] = true end

local function GetHuntProgress()
    if C_WeeklyRewards and C_WeeklyRewards.GetActivities then
        local ok, activities = pcall(C_WeeklyRewards.GetActivities)
        if ok and activities then
            for _, act in ipairs(activities) do
                if act.type == 4 then
                    local completed = act.progress or 0
                    local threshold = act.threshold or 12
                    return math.min(completed, threshold), threshold
                end
            end
        end
    end
    local n, h, nm = 0, 0, 0
    if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
        for qid in pairs(PREY_NORMAL_QUESTS) do
            if C_QuestLog.IsQuestFlaggedCompleted(qid) then n = n + 1 end
        end
        for qid in pairs(PREY_HARD_QUESTS) do
            if C_QuestLog.IsQuestFlaggedCompleted(qid) then h = h + 1 end
        end
        for qid in pairs(PREY_NIGHTMARE_QUESTS) do
            if C_QuestLog.IsQuestFlaggedCompleted(qid) then nm = nm + 1 end
        end
    end
    local completed = math.min(n, 4) + math.min(h, 4) + math.min(nm, 4)
    return completed, 12
end

-- =========================================================================
-- MATRIX TRACKER & WEEKLY RESET CONTROL
-- =========================================================================

local function CheckWeeklyReset()
    if not EnrageDB then return end
    if not EnrageDB.global then EnrageDB.global = {} end

    local nextReset = C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset and C_DateAndTime.GetSecondsUntilWeeklyReset()
    if not nextReset or nextReset <= 0 then
        return
    end

    local currentTime = GetServerTime()
    local thisWeekReset = currentTime + nextReset
    local lastReset = EnrageDB.global.lastReset

    -- New week = the stored reset timestamp is in the PAST (before current time)
    -- This means the reset we were waiting for has already happened
    if lastReset and lastReset < currentTime then
        print("|cFFE5E7EB[AkcQOL]|r New weekly reset detected. Clearing weekly Matrix data...")
        for charName, data in pairs(EnrageDB) do
            if type(data) == "table" and data.raids then
                data.raids = {}
                if type(data.dungeons) == "table" then
                    for _, dungeonData in pairs(data.dungeons) do
                        if type(dungeonData) == "table" then
                            dungeonData.mplus = 0
                            dungeonData.m0Progress = "0/0"
                            dungeonData.isComplete = false
                        end
                    end
                end
                data.topKeys = {}
                data.sparkQuestCompleted = false
                data.delveBountyCompleted = false
                data.nemesisCompleted = false
            end
        end
    end

    EnrageDB.global.lastReset = thisWeekReset
end

local DBFrame = CreateFrame("Frame")
DBFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
DBFrame:RegisterEvent("PLAYER_LOGOUT")
DBFrame:RegisterEvent("QUEST_LOG_UPDATE")
DBFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")

local function SaveCurrentCharacterData()
    if not EnrageDB then
        EnrageDB = { hiddenChars = {}, global = { autoSell = true, autoRepair = true, fastLoot = false, autoInsertKeystone = true, showOrb = false, autoCinematic = true, showRaidProgress = false, showMinimap = false, showTalentHelper = false, showItemLevel = false, showHUD = false } }
    end

    CheckWeeklyReset()

    if not EnrageDB.hiddenChars then EnrageDB.hiddenChars = {} end
    -- Prune inspect cache older than 7 days
    if EnrageDB.inspectCache then
        local cutoff = time() - (7 * 86400)
        for k, v in pairs(EnrageDB.inspectCache) do
            if not v.time or v.time < cutoff then
                EnrageDB.inspectCache[k] = nil
            end
        end
    end
    if not EnrageDB.global then EnrageDB.global = { autoSell = true, autoRepair = true, fastLoot = false, autoInsertKeystone = true, showOrb = false, autoCinematic = true } end
    -- Migrate old autoLoot key to fastLoot
    if EnrageDB.global.autoLoot ~= nil then
        if EnrageDB.global.fastLoot == nil then EnrageDB.global.fastLoot = EnrageDB.global.autoLoot end
        EnrageDB.global.autoLoot = nil
    end
    -- Per-feature defaults for EXISTING users (fresh installs are seeded OFF earlier, at
    -- file-load — see the EnrageQoL_FreshInstall block near the EnrageDB.global creation).
    -- These "== nil then <historical default>" lines preserve prior behavior for users
    -- upgrading from a build that never saved the field, so nothing flips ON->OFF for them;
    -- on a fresh install the fields are already set above, so these all no-op.
    if EnrageDB.global.showOrb == nil then EnrageDB.global.showOrb = false end
    if EnrageDB.global.autoCinematic == nil then EnrageDB.global.autoCinematic = true end
    if EnrageDB.global.showRaidProgress == nil then EnrageDB.global.showRaidProgress = true end
    if EnrageDB.global.showItemLevel == nil then EnrageDB.global.showItemLevel = true end
    if EnrageDB.global.fastLoot == nil then EnrageDB.global.fastLoot = false end
    if EnrageDB.global.autoInsertKeystone == nil then EnrageDB.global.autoInsertKeystone = true end
    if _G.Enrage_ApplyFastLoot then _G.Enrage_ApplyFastLoot() end

    local name, realm = UnitFullName("player")
    local charName = (realm and realm ~= "") and (name .. "-" .. realm) or name
    local _, classFileName = UnitClass("player")
    local classColor = RAID_CLASS_COLORS[classFileName] and RAID_CLASS_COLORS[classFileName].colorStr or "ffffffff"

    -- Merge legacy name-only records into Name-Realm records and remove duplicates.
    if name and (realm and realm ~= "") and EnrageDB[name] and type(EnrageDB[name]) == "table" then
        local old = EnrageDB[name]
        if not EnrageDB[charName] then
            EnrageDB[charName] = { color = classColor, raids = {}, dungeons = {}, topKeys = {} }
        end
        local cur = EnrageDB[charName]
        if old.raids and next(old.raids) then
            for k, v in pairs(old.raids) do cur.raids[k] = v end
        end
        if old.dungeons and next(old.dungeons) then
            for k, v in pairs(old.dungeons) do
                if not cur.dungeons[k] or (type(v.mplus) == "number" and (not cur.dungeons[k].mplus or v.mplus > cur.dungeons[k].mplus)) then
                    cur.dungeons[k] = v
                end
            end
        end
        if old.topKeys and #old.topKeys > 0 and (#(cur.topKeys or {}) == 0 or #old.topKeys > #(cur.topKeys or {})) then
            cur.topKeys = old.topKeys
        end
        EnrageDB[name] = nil
    end

    if not EnrageDB[charName] then
        EnrageDB[charName] = { color = classColor, raids = {}, dungeons = {}, topKeys = {} }
    end
    if not EnrageDB[charName].dungeons then EnrageDB[charName].dungeons = {} end
    if not EnrageDB[charName].raids then EnrageDB[charName].raids = {} end
    if not EnrageDB[charName].topKeys then EnrageDB[charName].topKeys = {} end
    EnrageDB[charName].color = classColor
    EnrageDB[charName].level = UnitLevel("player")
    local _, equippedILvl = GetAverageItemLevel()
    EnrageDB[charName].ilvl = tonumber(string.format("%.2f", equippedILvl or 0))
    EnrageDB[charName].rating = C_ChallengeMode.GetOverallDungeonScore() or 0

    local sparkDone = GetWeeklySparkCompleted()
    EnrageDB[charName].sparkQuestCompleted = sparkDone

    EnrageDB[charName].delveBountyCompleted = GetDelveBountyCompleted()
    -- nemesisCompleted is tracked via BOSS_KILL event, don't overwrite here

    -- Spark of Radiance: track TOTAL earned (not just current bag count)
    local sparkNow = GetItemCount(232875, true) or 0
    local prevCount = EnrageDB[charName].sparkCount or 0
    local totalEarned = EnrageDB[charName].sparkTotalEarned or prevCount
    -- If bag count increased since last save, we earned new sparks
    if sparkNow > prevCount then
        totalEarned = totalEarned + (sparkNow - prevCount)
    end
    -- Safety: total can never be less than what's in bags right now
    if totalEarned < sparkNow then totalEarned = sparkNow end
    EnrageDB[charName].sparkCount = sparkNow
    EnrageDB[charName].sparkTotalEarned = totalEarned

    local huntFulfilled, huntRequired = GetHuntProgress()
    EnrageDB[charName].huntProgress = string.format("%d/%d", huntFulfilled, huntRequired)

    -- Coffer Key Shards (currency 3310, weekly cap 600)
    pcall(function()
        local info = C_CurrencyInfo.GetCurrencyInfo(3310)
        if info then
            EnrageDB[charName].cofferShards = info.quantity or 0
            EnrageDB[charName].cofferShardsMax = info.maxQuantity or 600
            EnrageDB[charName].cofferShardsWeekly = info.totalEarned or 0
            -- Try to get weekly earned amount
            if info.quantityEarnedThisWeek ~= nil then
                EnrageDB[charName].cofferShardsWeekly = info.quantityEarnedThisWeek
            end
            if info.maxWeeklyQuantity and info.maxWeeklyQuantity > 0 then
                EnrageDB[charName].cofferShardsWeeklyCap = info.maxWeeklyQuantity
            else
                EnrageDB[charName].cofferShardsWeeklyCap = 600
            end
        end
    end)

    -- Restored Coffer Key (currency 3028)
    pcall(function()
        local keyInfo = C_CurrencyInfo.GetCurrencyInfo(3028)
        if keyInfo then
            EnrageDB[charName].restoredCofferKeys = keyInfo.quantity or 0
        end
    end)

    -- Mythic+ Keystone in bags (retry with delays - map info may not be cached yet)
    -- Hardcoded fallback map for when API hasn't cached names yet
    local KEYSTONE_MAP_NAMES = {
        [239] = "Seat of the Triumvirate",
        [161] = "Skyreach",
        [560] = "Maisara Caverns",
        [557] = "Windrunner Spire",
        [556] = "Pit of Saron",
        [402] = "Algeth'ar Academy",
        [558] = "Magisters' Terrace",
        [559] = "Nexus-Point Xenas",
    }
    local function SaveKeystoneInfo()
        pcall(function()
            local mapID = C_MythicPlus.GetOwnedKeystoneChallengeMapID()
            if mapID then
                local level = C_MythicPlus.GetOwnedKeystoneLevel()
                -- Method 1: Hardcoded (most reliable, instant)
                local mapName = KEYSTONE_MAP_NAMES[mapID]
                -- Method 2: API
                if not mapName then
                    mapName = C_ChallengeMode.GetMapUIInfo(mapID)
                end
                -- Method 3: Scan bags for "Keystone: Dungeon Name"
                if not mapName or mapName == "" then
                    for bag = 0, 4 do
                        for slot = 1, C_Container.GetContainerNumSlots(bag) do
                            local info = C_Container.GetContainerItemInfo(bag, slot)
                            if info and info.itemName then
                                local dn = info.itemName:match("^Keystone: (.+)$")
                                    or info.itemName:match("^Anahtar Ta")
                                if dn then mapName = dn break end
                            end
                        end
                        if mapName and mapName ~= "" then break end
                    end
                end
                EnrageDB[charName].keystoneLevel = level or 0
                EnrageDB[charName].keystoneDungeon = mapName or ("Map" .. mapID)
                EnrageDB[charName].keystoneMapID = mapID
            else
                EnrageDB[charName].keystoneLevel = 0
                EnrageDB[charName].keystoneDungeon = nil
                EnrageDB[charName].keystoneMapID = nil
            end
        end)
    end
    SaveKeystoneInfo()
    C_Timer.After(3, SaveKeystoneInfo)
    C_Timer.After(8, SaveKeystoneInfo)
    C_Timer.After(15, SaveKeystoneInfo)

    local midnightDungeons = {
        ["Algeth'ar Academy"] = true,
        ["Magisters' Terrace"] = true,
        ["Maisara Caverns"] = true,
        ["Nexus-Point Xenas"] = true,
        ["Pit of Saron"] = true,
        ["Seat of the Triumvirate"] = true,
        ["Skyreach"] = true,
        ["Windrunner Spire"] = true,
    }
    local DUNGEON_MAP_IDS = {
        ["Algeth'ar Academy"] = 402,
        ["Magisters' Terrace"] = 558,
        ["Maisara Caverns"] = 560,
        ["Nexus-Point Xenas"] = 559,
        ["Pit of Saron"] = 556,
        ["Seat of the Triumvirate"] = 239,
        ["Skyreach"] = 161,
        ["Windrunner Spire"] = 557,
    }

    local function SaveDungeonBestLevel(mapName, level)
        if not mapName or not midnightDungeons[mapName] or type(level) ~= "number" or level <= 0 then return end
        local d = EnrageDB[charName].dungeons[mapName]
        if not d then return end
        if level > (d.mplusBest or 0) then
            d.mplusBest = level
        end
    end

    local function ReadBestLevelFromTables(...)
        local bestLevel = 0
        for i = 1, select("#", ...) do
            local info = select(i, ...)
            if type(info) == "table" then
                local level = info.level or info.bestRunLevel or info.keyLevel or info.mythicLevel or info.challengeLevel
                if type(level) == "number" and level > bestLevel then
                    bestLevel = level
                end
            end
        end
        return bestLevel
    end

    for dName in pairs(midnightDungeons) do
        if not EnrageDB[charName].dungeons[dName] then
            EnrageDB[charName].dungeons[dName] = { m0Progress = "0/0", isComplete = false, mplus = 0, mplusBest = 0 }
        end
    end
    -- Remove old/non-season dungeons from saved data
    for dName in pairs(EnrageDB[charName].dungeons) do
        if not midnightDungeons[dName] then
            EnrageDB[charName].dungeons[dName] = nil
        end
    end
    -- Reset M0 progress before re-scanning (M0 lockouts are daily now)
    for dName in pairs(midnightDungeons) do
        if EnrageDB[charName].dungeons[dName] then
            EnrageDB[charName].dungeons[dName].m0Progress = "0/0"
            EnrageDB[charName].dungeons[dName].isComplete = false
        end
    end

    -- Clear old raid data before re-scanning (weekly reset = no lockouts = should show empty)
    EnrageDB[charName].raids = {}

    -- Collect all raid lockouts per raid name, then combine
    local raidLockouts = {}  -- [name] = { {diff, killed, total}, ... }
    for i = 1, GetNumSavedInstances() do
        local name, _, _, difficultyID, locked, _, _, isRaid, _, difficultyName, numEncounters, encounterProgress = GetSavedInstanceInfo(i)
        if locked then
            if isRaid then
                local diffShort = (difficultyID == 16) and "M" or (difficultyID == 15) and "H" or (difficultyID == 14) and "N" or "LFR"
                local diffOrder = (difficultyID == 16) and 4 or (difficultyID == 15) and 3 or (difficultyID == 14) and 2 or 1
                if not raidLockouts[name] then raidLockouts[name] = {} end
                table.insert(raidLockouts[name], {
                    diff = diffShort,
                    order = diffOrder,
                    killed = encounterProgress or 0,
                    total = numEncounters or 0,
                })
            elseif difficultyID == 23 or difficultyName == "Mythic" then
                if midnightDungeons[name] then
                    EnrageDB[charName].dungeons[name].m0Progress = string.format("%d/%d", encounterProgress or 0, numEncounters or 0)
                    EnrageDB[charName].dungeons[name].isComplete = (encounterProgress == numEncounters and numEncounters > 0)
                end
            end
        end
    end

    -- Store structured raid data per difficulty
    for raidName, lockouts in pairs(raidLockouts) do
        local raidEntry = {}
        for _, info in ipairs(lockouts) do
            raidEntry[info.diff] = { killed = info.killed, total = info.total }
        end
        EnrageDB[charName].raids[raidName] = raidEntry
    end

    -- This week's keys (for weekly mplus + vault display)
    local runHistory = C_MythicPlus.GetRunHistory(false, true)
    if runHistory then
        table.sort(runHistory, function(a, b) return a.level > b.level end)
        for i, run in ipairs(runHistory) do
            local mapName = C_ChallengeMode.GetMapUIInfo(run.mapChallengeModeID)
            if mapName then
                if midnightDungeons[mapName] then
                    if run.level > EnrageDB[charName].dungeons[mapName].mplus then
                        EnrageDB[charName].dungeons[mapName].mplus = run.level
                    end
                    SaveDungeonBestLevel(mapName, run.level)
                end
                if i <= 8 then
                    local color = run.level >= 10 and "|cFFB794F6" or "|cff0070DD"
                    EnrageDB[charName].topKeys[i] = string.format("%s+%d|r %s", color, run.level, mapName)
                end
            end
        end
    end

    -- All-time best keys (includes previous weeks, never resets)
    local allTimeHistory = C_MythicPlus.GetRunHistory(true, true)
    if allTimeHistory then
        for _, run in ipairs(allTimeHistory) do
            local mapName = C_ChallengeMode.GetMapUIInfo(run.mapChallengeModeID)
            if mapName and midnightDungeons[mapName] and EnrageDB[charName].dungeons[mapName] then
                SaveDungeonBestLevel(mapName, run.level)
            end
        end
    end

    if C_MythicPlus then
        for mapName, mapID in pairs(DUNGEON_MAP_IDS) do
            if C_MythicPlus.GetSeasonBestForMap then
                local ok, a, b, c, d = pcall(C_MythicPlus.GetSeasonBestForMap, mapID)
                if ok then
                    SaveDungeonBestLevel(mapName, ReadBestLevelFromTables(a, b, c, d))
                end
            end
            if C_MythicPlus.GetMapScoreInfo then
                local ok, scoreInfo = pcall(C_MythicPlus.GetMapScoreInfo, mapID)
                if ok and type(scoreInfo) == "table" then
                    SaveDungeonBestLevel(mapName, scoreInfo.bestRunLevel or scoreInfo.level or 0)
                end
            end
        end
    end

    -- Remove legacy name-only keys when a Name-Realm version exists.
    local toRemove = {}
    for key in pairs(EnrageDB) do
        if key ~= "version" and key ~= "hiddenChars" and key ~= "global" and type(key) == "string" and not key:find("-", 1, true) then
            for other in pairs(EnrageDB) do
                if other ~= key and type(other) == "string" and other:find("-", 1, true) and other:match("^" .. key:gsub("%-", "%%-") .. "%-") then
                    toRemove[key] = true
                    break
                end
            end
        end
    end
    for key in pairs(toRemove) do EnrageDB[key] = nil end

    -- One-time migration: clear nemesisCompleted set by old quest-based tracking (quest 93525 is one-time, not weekly)
    if not EnrageDB.global.nemesisMigrated then
        for k, v in pairs(EnrageDB) do
            if type(v) == "table" and v.nemesisCompleted then
                v.nemesisCompleted = false
            end
        end
        EnrageDB.global.nemesisMigrated = true
    end
end

DBFrame:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGOUT" then
        SaveCurrentCharacterData()
        return
    end
    if event == "PLAYER_ENTERING_WORLD" then
        RequestRaidInfo()
        C_MythicPlus.RequestRewards()
        C_MythicPlus.RequestMapInfo()
        C_Timer.After(2, SaveCurrentCharacterData)
    elseif event == "QUEST_LOG_UPDATE" and WVTrackerFrame and WVTrackerFrame:IsShown() then
        C_Timer.After(0.5, function()
            SaveCurrentCharacterData()
            if UpdateTrackerInfo then UpdateTrackerInfo() end
        end)
    elseif event == "CHALLENGE_MODE_COMPLETED" then
        C_MythicPlus.RequestRewards()
        C_MythicPlus.RequestMapInfo()
        C_Timer.After(1, function()
            SaveCurrentCharacterData()
            if UpdateTrackerInfo and WVTrackerFrame and WVTrackerFrame:IsShown() then UpdateTrackerInfo() end
        end)
        C_Timer.After(5, function()
            SaveCurrentCharacterData()
            if UpdateTrackerInfo and WVTrackerFrame and WVTrackerFrame:IsShown() then UpdateTrackerInfo() end
        end)
    end
end)

-- =========================================================================
-- TRACKER UI (WITH SCALE RESIZE GRIP)
-- =========================================================================

-- Shared visual constants are declared earlier (used by logs + tracker).

local MATRIX_THEME = {
    frameBg = {0.047, 0.055, 0.073, 0.94},
    titleBg = {0.031, 0.036, 0.050, 0.96},
    border = {0.227, 0.239, 0.267, 1.0},
    rowBase = {1, 1, 1, 0.018},
    rowAlt = {1, 1, 1, 0.050},
    rowLine = {0, 0, 0, 0.20},
    headerBg = {0.055, 0.064, 0.086, 0.90},
    text = {
        primary = "FFE5E7EB",
        muted = "FF8A8C90",
        faint = "FF565B66",
    },
    status = {
        done = { hex = "34D399", color = {0.204, 0.827, 0.600}, bgAlpha = 0.13 },
        warn = { hex = "F59E0B", color = {0.960, 0.620, 0.040}, bgAlpha = 0.13 },
        bad = { hex = "F87171", color = {0.973, 0.443, 0.443}, bgAlpha = 0.11 },
        neutral = { hex = "9CA3AF", color = {0.612, 0.639, 0.686}, bgAlpha = 0.08 },
        purple = { hex = "B794F6", color = {0.718, 0.580, 0.965}, bgAlpha = 0.13 },
        blue = { hex = "60A5FA", color = {0.376, 0.647, 0.980}, bgAlpha = 0.12 },
    },
    sections = {
        charInfo = { label = "CHARACTER INFO", hex = "F59E0B", color = {0.960, 0.620, 0.040} },
        raids = { label = "RAIDS", hex = "34D399", color = {0.204, 0.827, 0.600} },
        dungeons = { label = "DUNGEONS", hex = "60A5FA", color = {0.376, 0.647, 0.980} },
        vault = { label = "WEEKLY VAULT (TOP 8 KEYS)", hex = "B794F6", color = {0.718, 0.580, 0.965} },
    },
}

local TrackerFrame = CreateFrame("Frame", "WVTrackerFrame", UIParent)
TrackerFrame:SetSize(600, 450)
TrackerFrame:SetPoint("CENTER")
TrackerFrame:Hide()
TrackerFrame:SetMovable(true)
TrackerFrame:EnableMouse(true)
TrackerFrame:RegisterForDrag("LeftButton")
TrackerFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
TrackerFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
TrackerFrame:SetClampedToScreen(true)
TrackerFrame:SetFrameStrata("HIGH")
TrackerFrame:SetResizable(true)
if TrackerFrame.SetResizeBounds then
    TrackerFrame:SetResizeBounds(500, 200)
else
    TrackerFrame:SetMinResize(500, 200)
end

-- Body: deep translucent command-board surface.
local TrackerBG = TrackerFrame:CreateTexture(nil, "BACKGROUND")
TrackerBG:SetAllPoints()
TrackerBG:SetTexture(WV_FLAT_TEX)
TrackerBG:SetVertexColor(MATRIX_THEME.frameBg[1], MATRIX_THEME.frameBg[2], MATRIX_THEME.frameBg[3], MATRIX_THEME.frameBg[4])

-- Cyan border lines
WV_CreateBorder(TrackerFrame, "TOPLEFT", "TOPLEFT", "TOPRIGHT", "TOPRIGHT", nil, 1)
WV_CreateBorder(TrackerFrame, "BOTTOMLEFT", "BOTTOMLEFT", "BOTTOMRIGHT", "BOTTOMRIGHT", nil, 1)
WV_CreateBorder(TrackerFrame, "TOPLEFT", "TOPLEFT", "BOTTOMLEFT", "BOTTOMLEFT", 1, nil)
WV_CreateBorder(TrackerFrame, "TOPRIGHT", "TOPRIGHT", "BOTTOMRIGHT", "BOTTOMRIGHT", 1, nil)

-- Title bar
local TitleBar = CreateFrame("Frame", nil, TrackerFrame)
TitleBar:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 0, 0)
TitleBar:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", 0, 0)
TitleBar:SetHeight(30)
TitleBar:EnableMouse(true)
TitleBar:RegisterForDrag("LeftButton")
TitleBar:SetScript("OnDragStart", function() TrackerFrame:StartMoving() end)
TitleBar:SetScript("OnDragStop", function() TrackerFrame:StopMovingOrSizing() end)

-- Title bar: darker than body, with one restrained amber accent line.
local TitleBG = TitleBar:CreateTexture(nil, "BACKGROUND", nil, 1)
TitleBG:SetAllPoints()
TitleBG:SetTexture(WV_FLAT_TEX)
TitleBG:SetVertexColor(MATRIX_THEME.titleBg[1], MATRIX_THEME.titleBg[2], MATRIX_THEME.titleBg[3], MATRIX_THEME.titleBg[4])

-- Light theme: hide top highlights (white-on-white invisible)
local TitleTopHL = TitleBar:CreateTexture(nil, "ARTWORK")
TitleTopHL:Hide()
local TitleTopHL2 = TitleBar:CreateTexture(nil, "ARTWORK")
TitleTopHL2:Hide()

-- Title separator: single amber accent.
local titleSep = TrackerFrame:CreateTexture(nil, "ARTWORK")
titleSep:SetTexture(WV_FLAT_TEX)
titleSep:SetVertexColor(0.96, 0.62, 0.04, 0.70)
titleSep:SetPoint("TOPLEFT", TitleBar, "BOTTOMLEFT", 0, 0)
titleSep:SetPoint("TOPRIGHT", TitleBar, "BOTTOMRIGHT", 0, 0)
titleSep:SetHeight(1)

-- Hide drop shadow (clean theme, no extra layers)
local titleDropShadow = TrackerFrame:CreateTexture(nil, "ARTWORK")
titleDropShadow:Hide()

local TitleText = TitleBar:CreateFontString(nil, "OVERLAY")
TitleText:SetFont(WV_FONT_FACE, 14, "")
TitleText:SetPoint("LEFT", 10, 0)
TitleText:SetText("|cFFF59E0BAkcQOL|r |cFFE5E7EBMatrix|r")

-- Stat priority display on title bar (between title and buttons)
local MatrixStatText = TitleBar:CreateFontString(nil, "OVERLAY")
MatrixStatText:SetFont(WV_FONT_FACE, 12, "")
MatrixStatText:SetPoint("LEFT", TitleText, "RIGHT", 30, 0)
MatrixStatText:SetJustifyH("LEFT")
MatrixStatText:SetWordWrap(false)
MatrixStatText:SetNonSpaceWrap(false)

function _G.EnrageMatrix_UpdateStatDisplay(specID)
    if not MatrixStatText then return end
    if not specID then
        local specIndex = GetSpecialization()
        specID = specIndex and GetSpecializationInfo(specIndex) or nil
    end
    if not specID or not EnrageStatPriority or not EnrageStatPriority[specID] then
        MatrixStatText:SetText("")
        return
    end
    local stats = EnrageStatPriority[specID]
    local _, className = UnitClass("player")
    local specName = ""
    local specNames = {
        [71]="Arms",[72]="Fury",[73]="Protection",
        [65]="Holy",[66]="Protection",[70]="Retribution",
        [253]="BM",[254]="MM",[255]="Survival",
        [259]="Assassin",[260]="Outlaw",[261]="Subtlety",
        [256]="Disc",[257]="Holy",[258]="Shadow",
        [250]="Blood",[251]="Frost",[252]="Unholy",
        [262]="Elemental",[263]="Enhance",[264]="Resto",
        [62]="Arcane",[63]="Fire",[64]="Frost",
        [265]="Affli",[266]="Demo",[267]="Destro",
        [268]="BrM",[269]="WW",[270]="MW",
        [102]="Balance",[103]="Feral",[104]="Guardian",[105]="Resto",
        [577]="Havoc",[581]="Veng",
        [1467]="Deva",[1468]="Pres",[1473]="Aug",
    }
    specName = specNames[specID] or "?"
    local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
    local cc = classColor and classColor.colorStr or "FFFFFFFF"
    local stText = "|c" .. cc .. specName .. "|r |cFF66FF66ST|r |cFFCCCCCC" .. stats.st .. "|r  |cFFFF6666AoE|r |cFFCCCCCC" .. stats.aoe .. "|r"
    MatrixStatText:SetText(stText)
end

-- Update stat display on load and spec change
local matrixStatFrame = CreateFrame("Frame")
matrixStatFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
matrixStatFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
matrixStatFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_SPECIALIZATION_CHANGED" and arg1 ~= "player" then return end
    C_Timer.After(0.5, function() _G.EnrageMatrix_UpdateStatDisplay() end)
end)

-- Custom close button (red X)
local Enrage_CloseMatrixPopups
local CloseBtn = CreateFrame("Button", nil, TitleBar)
CloseBtn:SetSize(24, 24)
CloseBtn:SetPoint("RIGHT", TitleBar, "RIGHT", -4, 0)
local CloseTxt = CloseBtn:CreateFontString(nil, "OVERLAY")
CloseTxt:SetFont(WV_FONT_FACE, 14, WV_FONT_FLAGS)
CloseTxt:SetAllPoints()
CloseTxt:SetText("|cFFFF4444X|r")
CloseBtn:SetScript("OnClick", function()
    if Enrage_CloseMatrixPopups then Enrage_CloseMatrixPopups() end
    Enrage_SafeHideFrame(TrackerFrame)
end)
CloseBtn:SetScript("OnEnter", function() CloseTxt:SetText("|cFFFF0000X|r") end)
CloseBtn:SetScript("OnLeave", function() CloseTxt:SetText("|cFFFF4444X|r") end)

-- Settings button removed — settings now open from the bottom-left gear
-- (see GearBtn below). Toggle logic lives in _G.Enrage_ToggleMatrixSettings.

local LogsBtn = CreateFrame("Button", nil, TitleBar)
LogsBtn:SetPoint("RIGHT", CloseBtn, "LEFT", -8, 0)
LogsBtn:SetSize(58, 20)
local LogsBtnBg = LogsBtn:CreateTexture(nil, "BACKGROUND")
LogsBtnBg:SetAllPoints()
LogsBtnBg:SetTexture(WV_FLAT_TEX)
LogsBtnBg:SetVertexColor(0.227, 0.239, 0.267, 1)
local LogsBtnInner = LogsBtn:CreateTexture(nil, "ARTWORK")
LogsBtnInner:SetPoint("TOPLEFT", 1, -1)
LogsBtnInner:SetPoint("BOTTOMRIGHT", -1, 1)
LogsBtnInner:SetTexture(WV_FLAT_TEX)
LogsBtnInner:SetGradient("VERTICAL",
    CreateColor(0.090, 0.098, 0.118, 1),
    CreateColor(0.130, 0.141, 0.165, 1))
local LogsBtnTopHL = LogsBtn:CreateTexture(nil, "OVERLAY")
LogsBtnTopHL:SetPoint("TOPLEFT", 1, -1)
LogsBtnTopHL:SetPoint("TOPRIGHT", -1, -1)
LogsBtnTopHL:SetHeight(1)
LogsBtnTopHL:SetTexture(WV_FLAT_TEX)
LogsBtnTopHL:SetVertexColor(1, 1, 1, 0.07)
local LogsBtnText = LogsBtn:CreateFontString(nil, "OVERLAY")
LogsBtnText:SetFont(WV_FONT_FACE, 11, "")
LogsBtnText:SetAllPoints()
LogsBtnText:SetText("|cFFE5E7EBLogs|r")
LogsBtn:SetScript("OnEnter", function()
    LogsBtnInner:SetGradient("VERTICAL",
        CreateColor(0.130, 0.141, 0.165, 1),
        CreateColor(0.180, 0.196, 0.227, 1))
    LogsBtnBg:SetVertexColor(0.96, 0.62, 0.04, 0.7)
end)
LogsBtn:SetScript("OnLeave", function()
    LogsBtnInner:SetGradient("VERTICAL",
        CreateColor(0.090, 0.098, 0.118, 1),
        CreateColor(0.130, 0.141, 0.165, 1))
    LogsBtnBg:SetVertexColor(0.227, 0.239, 0.267, 1)
end)
LogsBtn:SetScript("OnClick", function()
    if Enrage_IsFrameOpen(ENRAGE_LOGS_FRAME) then
        Enrage_SafeHideFrame(ENRAGE_LOGS_FRAME)
    elseif Enrage_ShowLogsWindow then
        Enrage_ShowLogsWindow("mail")
    end
end)
LogsBtn:Hide()

local ErrorAlertBtn = CreateFrame("Button", nil, TitleBar)
ErrorAlertBtn:SetSize(48, 16)
ErrorAlertBtn:SetPoint("RIGHT", LogsBtn, "LEFT", -5, 0)
ErrorAlertBtn:SetFrameLevel(TitleBar:GetFrameLevel() + 20)
local ErrorAlertBg = ErrorAlertBtn:CreateTexture(nil, "BACKGROUND")
ErrorAlertBg:SetAllPoints()
ErrorAlertBg:SetTexture(WV_FLAT_TEX)
ErrorAlertBg:SetVertexColor(0.19, 0.055, 0.045, 0.98)
local ErrorAlertBorder = ErrorAlertBtn:CreateTexture(nil, "BORDER")
ErrorAlertBorder:SetPoint("TOPLEFT", -1, 1)
ErrorAlertBorder:SetPoint("BOTTOMRIGHT", 1, -1)
ErrorAlertBorder:SetTexture(WV_FLAT_TEX)
ErrorAlertBorder:SetVertexColor(1.0, 0.25, 0.2, 0.8)
local ErrorAlertText = ErrorAlertBtn:CreateFontString(nil, "OVERLAY")
ErrorAlertText:SetFont(WV_FONT_FACE, 9, "OUTLINE")
ErrorAlertText:SetAllPoints()
ErrorAlertText:SetText("|cFFFF7A7ALua|r")
ErrorAlertBtn:SetScript("OnClick", function()
    if Enrage_ShowLogsWindow then
        Enrage_ShowLogsWindow("lua")
    elseif _G.Enrage_ShowErrorLogWindow then
        _G.Enrage_ShowErrorLogWindow()
    end
end)
ErrorAlertBtn:SetScript("OnEnter", function(self)
    ErrorAlertBg:SetVertexColor(0.28, 0.075, 0.06, 0.98)
    ErrorAlertBorder:SetVertexColor(1.0, 0.35, 0.3, 1)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:AddLine("|cFFFF7A7ALua Errors|r")
    GameTooltip:AddLine("Click to open Logs > Lua.", 1, 1, 1)
    GameTooltip:Show()
end)
ErrorAlertBtn:SetScript("OnLeave", function()
    ErrorAlertBg:SetVertexColor(0.19, 0.055, 0.045, 0.98)
    ErrorAlertBorder:SetVertexColor(1.0, 0.25, 0.2, 0.8)
    GameTooltip:Hide()
end)
ErrorAlertBtn:Hide()

-- =========================================================================
-- SETTINGS PANEL
-- =========================================================================
do  -- settings panel scope: keeps the new sub-menu locals out of the top-level local budget
local SettingsFrame = CreateFrame("Frame", "EnrageSettingsFrame", TrackerFrame, "BackdropTemplate")
SettingsFrame:SetSize(648, 470)
-- Temp anchor; re-anchored to the bottom-left gear once it exists (see GearBtn).
SettingsFrame:SetPoint("BOTTOMLEFT", TrackerFrame, "BOTTOMLEFT", 5, 30)
SettingsFrame:SetFrameStrata("TOOLTIP")
SettingsFrame:EnableMouse(true)
SettingsFrame:SetClampedToScreen(true)
SettingsFrame:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
})
SettingsFrame:SetBackdropColor(0.025, 0.026, 0.024, 0.82)
SettingsFrame:SetBackdropBorderColor(0.227, 0.239, 0.267, 1)
SettingsFrame:Hide()

local SettingsTitle = SettingsFrame:CreateFontString(nil, "OVERLAY")
SettingsTitle:SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
SettingsTitle:SetPoint("TOP", 0, -12)
SettingsTitle:SetText("|cFFF59E0BAkcQOL|r |cFFE5E7EBSettings|r")

local SettingsCloseBtn = CreateFrame("Button", nil, SettingsFrame, "UIPanelCloseButton")
SettingsCloseBtn:SetPoint("TOPRIGHT", -2, -2)
SettingsCloseBtn:SetScript("OnClick", function()
    Enrage_SafeHideFrame(SettingsFrame)
end)
-- Exposed so the logs-window dock can hide them (the host window has its own title
-- and close), while the standalone matrix popup keeps them. Avoids a double title.
SettingsFrame.ownTitle = SettingsTitle
SettingsFrame.ownClose = SettingsCloseBtn

-- The settings panel is ONE AceConfig tree filling the whole frame (the old native
-- left sub-menu / nav buttons were retired).
local contentPane = CreateFrame("Frame", nil, SettingsFrame)
contentPane:SetPoint("TOPLEFT", SettingsFrame, "TOPLEFT", 8, -36)
contentPane:SetPoint("BOTTOMRIGHT", SettingsFrame, "BOTTOMRIGHT", -8, 10)

local activeSection = "auto"

-- Native QoL toggles exposed as AceConfig groups so the whole settings panel is one
-- tree (merged into EnrageRaidCD by Config.lua's BuildOptions). Closures capture this
-- file's side-effect helpers (UpdateOrbPosition is a chunk upvalue; EnrageOrb /
-- EnrageMinimapBtn / EnrageDB / Enrage_* are globals) that Config.lua cannot reach.
do
    local function qoToggle(key, label, order, onSet, desc)
        return {
            name = label, desc = desc, type = "toggle", order = order, width = "full",
            get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global[key]) or false end,
            set = function(_, v)
                if EnrageDB and EnrageDB.global then EnrageDB.global[key] = v end
                if onSet then onSet(v) end
            end,
        }
    end
    _G.EnrageQoLSettingsGroups = {
        qolAutomation = {
            name = "Automation", type = "group", order = -30,
            args = {
                autoSell           = qoToggle("autoSell", "Auto Sell Grey Items", 1, nil, "Automatically sells all poor-quality (grey) items whenever you open a merchant, and prints the gold earned."),
                autoRepair         = qoToggle("autoRepair", "Auto Repair", 2, nil, "Automatically repairs your gear at any repair merchant — uses guild bank funds first if available, otherwise your own gold."),
                fastLoot           = qoToggle("fastLoot", "Fast Loot", 3, function() if _G.Enrage_ApplyFastLoot then _G.Enrage_ApplyFastLoot() end end, "Automatically loots every item the moment loot drops, so you never have to click to loot."),
                autoInsertKeystone = qoToggle("autoInsertKeystone", "Auto Insert M+ Keystone", 4, function(v) if v and _G.Enrage_ScheduleAutoInsertKeystone then _G.Enrage_ScheduleAutoInsertKeystone() end end, "Automatically places your Mythic+ keystone into the font when you open it."),
                autoCinematic      = qoToggle("autoCinematic", "Skip Cinematics", 5, nil, "Automatically skips in-game cinematics and movies as they begin."),
                hideProfessionOutfit = qoToggle("hideProfessionOutfit", "Hide Profession Outfit", 6, function() if _G.Enrage_ApplyProfessionAppearance then _G.Enrage_ApplyProfessionAppearance() end end, "Removes the cosmetic profession outfit the game puts on you at login and whenever you start a profession, so you never wear the profession transmog. Applies out of combat (a buff gained during combat is removed the moment you leave combat); fishing gear is removed when you stop fishing. Account-wide."),
                dynamicFPS = {
                    name = "Dynamic FPS (instances)", desc = "Automatically lowers graphics-heavy settings (particles, shadows, reflections, water, weather, lights, LOD...) when you enter a raid / dungeon / arena / battleground, then restores your normal graphics in the open world. |cff00ff00No /reload needed|r -- it takes effect immediately (and applies the instant you zone into an instance). In the open world it does nothing on purpose, so you won't see a change while standing in town: type |cffffd100/fps on|r to preview it anywhere, |cffffd100/fps auto|r to go back. Fully reversible and reload-safe -- your own settings are captured and restored. |cffffd100/fps|r = auto / on / off / reset / status.",
                    type = "toggle", order = 7, width = "full",
                    get = function()
                        local d = EnrageDB and EnrageDB.global and EnrageDB.global.dynFPS
                        return d ~= nil and d.mode ~= nil and d.mode ~= "off"
                    end,
                    set = function(_, v)
                        if not (EnrageDB and EnrageDB.global) then return end
                        EnrageDB.global.dynFPS = EnrageDB.global.dynFPS or {}
                        EnrageDB.global.dynFPS.mode = v and "auto" or "off"
                        if _G.Enrage_ApplyDynamicFPS then _G.Enrage_ApplyDynamicFPS() end
                    end,
                },
            },
        },
        qolDisplay = {
            name = "Display", type = "group", order = -20,
            args = {
                showOrb          = qoToggle("showOrb", "Show Power Orb (Warvideo)", 1, function(v)
                    if v then UpdateOrbPosition(); if EnrageOrb then EnrageOrb:Show() end
                    elseif EnrageOrb then EnrageOrb:Hide() end
                end, "Shows a small fixed status orb pinned to the top-left corner (Warvideo-style; it colour-codes recording / wipe state). Click it to toggle the main matrix window."),
                showMinimap      = qoToggle("showMinimap", "Show Minimap Button", 2, function(v)
                    if EnrageMinimapBtn then if v then EnrageMinimapBtn:Show() else EnrageMinimapBtn:Hide() end end
                end, "Shows the AkcQOL minimap button: left-click toggles the matrix, right-click opens settings, drag to move it. The /akc and /akcsettings commands work without it."),
                showItemLevel    = qoToggle("showItemLevel", "Show Item Levels", 3, function() if _G.Enrage_ToggleItemLevel then _G.Enrage_ToggleItemLevel() end end, "Paints item-level numbers on items in the character sheet, bags, bank (Account/Warband), the loot window and the equipment flyout. Equipped slots also show red G/E warnings for missing gems/enchants."),
                showRaidProgress = qoToggle("showRaidProgress", "Show Raid Progress", 4, nil, "Near a raid, shows a top-of-screen panel of this week's boss kills per difficulty (from your saved lockouts). Hover a difficulty tab for its per-boss list."),
            },
        },
        qolHud = {
            name = "HUD & Info", type = "group", order = -10,
            args = {
                hudDesc = {
                    name = "A small floating panel showing your spec/loadout, lowest durability and loot spec. Drag it anywhere on screen.",
                    type = "description", order = 0.1, fontSize = "medium",
                },
                hudPreview = {
                    name = "Preview HUD (8 Seconds)",
                    desc = "Temporarily bring the HUD to the front so you can see it and where it sits — even while \"Show HUD Info\" is off.",
                    type = "execute", order = 0.3, width = "full",
                    func = function() if _G.Enrage_PreviewHUD then _G.Enrage_PreviewHUD() end end,
                },
                hudResetPos = {
                    name = "Reset HUD Position (Center)",
                    desc = "Move the HUD back to the center of the screen.",
                    type = "execute", order = 0.4, width = "full",
                    func = function() if _G.Enrage_ResetHUDPosition then _G.Enrage_ResetHUDPosition() end end,
                },
                showTalentHelper = qoToggle("showTalentHelper", "Talent Helper", 1, nil, "Adds M+ and Raid build side panels to the talent window (WarcraftLogs builds, switchable to Archon). One click loads a build into your talents; if it can't be applied directly it falls back to a copy-paste popup."),
                showHUD          = qoToggle("showHUD", "Show HUD Info", 2, function() if _G.Enrage_ApplyHUDVisibility then _G.Enrage_ApplyHUDVisibility() end end, "Shows a small draggable panel with your spec and active loadout, the currently loaded talent build name (when one is loaded), your lowest gear durability and your loot spec."),
                hudScale = {
                    name = "HUD Info Scale", type = "range", order = 10, width = "full",
                    min = 0.5, max = 2.0, step = 0.1, isPercent = true,
                    get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global.hudScale) or 1.0 end,
                    set = function(_, v)
                        local cur = (EnrageDB and EnrageDB.global and EnrageDB.global.hudScale) or 1.0
                        if _G.Enrage_SetHUDScale then _G.Enrage_SetHUDScale(v - cur) end
                    end,
                },
                restoreDefaults = {
                    name = "Restore Defaults", type = "execute", order = 100, width = "full",
                    confirm = true,
                    confirmText = "Reset all HUD & Info settings to defaults?",
                    func = function()
                        if _G.Enrage_ResetHUDDefaults then _G.Enrage_ResetHUDDefaults() end
                        LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                    end,
                },
            },
        },
    }
end

-- =====================================================================
-- BLIZZARD DAMAGE METER VISIBILITY CONTROL
-- Fades Blizzard's built-in damage meter windows (DamageMeterSessionWindow1..3)
-- by ALPHA — mouseover- and combat-driven. Alpha is non-protected, so this is
-- combat-safe (no taint) and never touches the meter's Edit Mode shown-state.
-- Exposed as the "Damage Meter" group in the unified settings tree.
-- =====================================================================
do
    local METER_WINDOWS = { "DamageMeterSessionWindow1", "DamageMeterSessionWindow2", "DamageMeterSessionWindow3" }

    local function DmgMeterDB()
        local g = EnrageDB and EnrageDB.global
        if not g then return nil end
        g.dmgMeter = g.dmgMeter or {}
        local d = g.dmgMeter
        if d.enabled == nil then d.enabled = false end
        if d.mouseoverMode == nil then d.mouseoverMode = "show" end
        if d.combatMode == nil then d.combatMode = "show" end
        if d.minAlpha == nil then d.minAlpha = 0 end
        if d.maxAlpha == nil then d.maxAlpha = 1 end
        return d
    end

    -- The per-ability "detail" popup is DamageMeterSessionWindowN.SourceWindow — a CHILD
    -- of its session window that sits OUTSIDE the parent's rect. So while the mouse is on
    -- the popup the parent's IsMouseOver is false, and the old per-window logic faded both
    -- (the child inherits the parent's alpha). Fix: treat the whole meter as ONE hover
    -- group. The cluster is "hovered" if the mouse is over any session window, over any
    -- descendant of one (the popup child), or over any DamageMeter* frame. A short linger
    -- avoids flicker as the cursor crosses the gap to the detached popup. Driving the
    -- session windows alone keeps every child popup in sync (alpha inherits down).
    -- True if the cursor is anywhere on the meter cluster: over a session window, over a
    -- descendant of one (the detail popup is a child living outside the parent's rect), or
    -- over any DamageMeterSession* frame. Helpers are inlined to keep this scope's local
    -- count low (Lua 5.1's 200-register cap). The OnUpdate/this closure get their own
    -- register space, so locals INSIDE them are free.
    local hoverLinger = 0
    local function ClusterHovered()
        for _, name in ipairs(METER_WINDOWS) do
            local w = _G[name]
            if w and w.IsShown and w:IsShown() and w.IsMouseOver and w:IsMouseOver() then
                return true
            end
        end
        local foci = (GetMouseFoci and GetMouseFoci())                  -- 11.x/12.x: list, [1]=topmost
            or (GetMouseFocus and { GetMouseFocus() }) or nil           -- legacy single-frame fallback
        if foci then
            for _, focus in ipairs(foci) do
                local fn = focus and focus.GetName and focus:GetName()
                if type(fn) == "string" and fn:find("DamageMeterSession", 1, true) then return true end
                local node, depth = focus, 0                            -- walk up to a session window
                while node and depth < 60 do
                    for _, name in ipairs(METER_WINDOWS) do
                        if node == _G[name] then return true end
                    end
                    node = node.GetParent and node:GetParent() or nil
                    depth = depth + 1
                end
            end
        end
        return false
    end

    -- Driver always runs; the body is gated on `enabled`. This makes it engage
    -- reliably no matter when the Blizzard meter addon loads or the layout settles,
    -- and it re-applies our target every frame so Blizzard's own alpha can't win.
    local driver = CreateFrame("Frame")
    driver:SetScript("OnUpdate", function(_, elapsed)
        local d = DmgMeterDB()
        if not d or not d.enabled then return end
        local hovered = ClusterHovered()
        if hovered then
            hoverLinger = 0.30                                          -- linger so meter<->popup hops don't flicker
        elseif hoverLinger > 0 then
            hoverLinger = hoverLinger - elapsed
        end
        local effHover = hovered or hoverLinger > 0
        local target
        local inCombat = InCombatLockdown and InCombatLockdown()
        if inCombat and d.combatMode == "show" then
            target = d.maxAlpha
        elseif inCombat and d.combatMode == "hide" then
            target = d.minAlpha
        elseif d.mouseoverMode == "hide" then
            target = effHover and d.minAlpha or d.maxAlpha
        elseif d.mouseoverMode == "show" then
            target = effHover and d.maxAlpha or d.minAlpha
        else
            target = d.maxAlpha
        end
        local speed = elapsed * 6
        if speed > 1 then speed = 1 end
        for _, name in ipairs(METER_WINDOWS) do
            local win = _G[name]
            if win and win.IsShown and win:IsShown() then
                local cur = win:GetAlpha() or 1
                local na = cur + (target - cur) * speed
                if math.abs(na - target) < 0.01 then na = target end
                win:SetAlpha(na)
            end
        end
    end)

    function _G.Enrage_RefreshDamageMeter()
        local d = DmgMeterDB()
        if not d or d.enabled then return end
        -- Disabled: hand the windows back to Blizzard at full opacity.
        for _, name in ipairs(METER_WINDOWS) do
            local win = _G[name]
            if win and win.SetAlpha then win:SetAlpha(1) end
        end
    end

    local function refresh() if _G.Enrage_RefreshDamageMeter then _G.Enrage_RefreshDamageMeter() end end

    if _G.EnrageQoLSettingsGroups then
        _G.EnrageQoLSettingsGroups.qolDamageMeter = {
            name = "Damage Meter", type = "group", order = -5,
            args = {
                desc = {
                    name = "Control the visibility of Blizzard's built-in Damage Meter windows (DPS / HPS). Uses an opacity fade, so it is safe in combat. For best results set the meter's Edit Mode visibility to \"Always Visible\".",
                    type = "description", order = 0, fontSize = "medium",
                },
                enabled = {
                    name = "Control Damage Meter Visibility", type = "toggle", order = 1, width = "full",
                    get = function() local d = DmgMeterDB(); return d and d.enabled end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.enabled = v end; refresh() end,
                },
                mouseoverMode = {
                    name = "On Mouseover", type = "select", order = 2,
                    values = { off = "No change", show = "Show on mouseover", hide = "Hide on mouseover" },
                    get = function() local d = DmgMeterDB(); return (d and d.mouseoverMode) or "show" end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.mouseoverMode = v end; refresh() end,
                },
                combatMode = {
                    name = "In Combat", type = "select", order = 3,
                    values = { none = "No change", show = "Always show in combat", hide = "Hide in combat" },
                    get = function() local d = DmgMeterDB(); return (d and d.combatMode) or "show" end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.combatMode = v end; refresh() end,
                },
                minAlpha = {
                    name = "Hidden Opacity", type = "range", order = 4,
                    min = 0, max = 1, step = 0.05, isPercent = true,
                    get = function() local d = DmgMeterDB(); return (d and d.minAlpha) or 0 end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.minAlpha = v end; refresh() end,
                },
                maxAlpha = {
                    name = "Shown Opacity", type = "range", order = 5,
                    min = 0, max = 1, step = 0.05, isPercent = true,
                    get = function() local d = DmgMeterDB(); return (d and d.maxAlpha) or 1 end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.maxAlpha = v end; refresh() end,
                },
                restoreDefaults = {
                    name = "Restore Defaults", type = "execute", order = 100, width = "full",
                    confirm = true,
                    confirmText = "Reset all Damage Meter settings to defaults?",
                    func = function()
                        if EnrageDB and EnrageDB.global then EnrageDB.global.dmgMeter = nil end
                        DmgMeterDB() -- re-inits defaults
                        refresh()
                        LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                    end,
                },
            },
        }
    end

    refresh()
end
local RenderSection

-- =====================================================================
-- Raid CD options embed: the old ESC > Options > AddOns "Enrage" panel
-- (AceConfig "EnrageRaidCD") now lives here, inside the matrix gear panel.
-- The options table itself is untouched; only its host frame changes, so
-- the full Raid CD config keeps working with zero regression.
-- =====================================================================
-- One table holds all embed state + methods, so the whole feature adds just a
-- single local to this settings `do` scope (released at scope end -> zero cost
-- to the persistent main-chunk local budget; Lua 5.1 caps a chunk at 200).
local raidcd = { host = CreateFrame("Frame", nil, contentPane) }
raidcd.host:SetAllPoints(contentPane)
raidcd.host:Hide()

raidcd.fallback = raidcd.host:CreateFontString(nil, "OVERLAY")
raidcd.fallback:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE")
raidcd.fallback:SetPoint("TOPLEFT", 6, -10)
raidcd.fallback:SetPoint("RIGHT", raidcd.host, "RIGHT", -6, 0)
raidcd.fallback:SetJustifyH("LEFT")
raidcd.fallback:SetText("|cFFE5E7EBSettings are loading. If this stays empty, type|r |cFFF59E0B/akcsettings|r |cFFE5E7EBonce.|r")
raidcd.fallback:Hide()

function raidcd.Available()
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not (reg and reg.GetOptionsTable) then return false end
    local ok, tbl = pcall(reg.GetOptionsTable, reg, "EnrageRaidCD")
    return ok and tbl and true or false
end

function raidcd.Ensure()
    if raidcd.embed then return raidcd.embed end
    local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
    if not AceGUI then return nil end
    local ok, g = pcall(function()
        local grp = AceGUI:Create("BlizOptionsGroup")
        if not grp then error("no widget") end
        grp:SetTitle("")
        grp:SetUserData("appName", "EnrageRaidCD")
        grp.frame:SetParent(raidcd.host)
        grp.frame:ClearAllPoints()
        grp.frame:SetAllPoints(raidcd.host)
        grp.frame:Hide()
        return grp
    end)
    if ok and g then raidcd.embed = g end
    return raidcd.embed
end

function raidcd.Hide()
    if raidcd.embed then
        pcall(function() raidcd.embed:ReleaseChildren() end)
        if raidcd.embed.frame then raidcd.embed.frame:Hide() end
    end
    raidcd.host:Hide()
end

function raidcd.Show()
    local g = raidcd.Ensure()
    local ACD = LibStub and LibStub("AceConfigDialog-3.0", true)
    if not (g and ACD) then return false end
    raidcd.host:Show()
    g.frame:Show()
    -- Defer one frame so the resized host reports its final size before AceGUI
    -- lays the options tree out (anchored frames update next frame).
    local function feed()
        if not raidcd.host:IsShown() then return end
        local opened = pcall(ACD.Open, ACD, "EnrageRaidCD", g)
        if opened then raidcd.fallback:Hide() else raidcd.fallback:Show() end
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(0, feed)
    else
        feed()
    end
    return true
end

function _G.Enrage_RefreshErrorLogButton()
    local count = 0
    local unread = 0
    if _G.Enrage_GetLuaErrorCount then
        count = _G.Enrage_GetLuaErrorCount() or 0
    end
    if _G.Enrage_GetUnreadLuaErrorCount then
        unread = _G.Enrage_GetUnreadLuaErrorCount() or 0
    else
        unread = count
    end
    if ErrorAlertBtn and ErrorAlertText then
        if unread > 0 then
            local alertLabel = unread > 99 and "Lua 99+" or ("Lua " .. unread)
            ErrorAlertBtn:SetWidth(unread > 99 and 56 or 48)
            ErrorAlertText:SetText("|cFFFFB4B4" .. alertLabel .. "|r")
            ErrorAlertBtn:Show()
        else
            ErrorAlertBtn:Hide()
        end
    end
end
SettingsFrame:HookScript("OnShow", _G.Enrage_RefreshErrorLogButton)
_G.Enrage_RefreshErrorLogButton()

-- Unified renderer: the whole settings panel is one AceConfig tree now. Retire the
-- native checkbox/sub-menu/HUD-scale widgets and always show the AceConfig panel
-- (which contains the QoL groups + the original Raid CD groups in one tree).
RenderSection = function(key)
    activeSection = key
    if raidcd.Available() then
        raidcd.fallback:Hide()
        raidcd.Show()
    else
        raidcd.Hide()
        raidcd.fallback:Show()
    end
end

SettingsFrame:HookScript("OnShow", function() RenderSection(activeSection) end)
SettingsFrame:HookScript("OnHide", function() raidcd.Hide() end)
RenderSection("auto")

-- Open the unified settings panel directly on a given section. Settings entry
-- points (/akcsettings, the minimap button, the tracker anchor's gear) route here
-- so all settings land in this one in-matrix window.
function _G.Enrage_OpenMatrixSettingsSection(key)
    if Enrage_CloseMatrixPopups then Enrage_CloseMatrixPopups("settings") end
    -- Re-dock to the matrix gear (the logs window may have embedded it elsewhere).
    -- The matrix host must be visible or the panel would sit on a hidden parent.
    if Enrage_SafeShowFrame then Enrage_SafeShowFrame(TrackerFrame) end
    SettingsFrame:SetParent(TrackerFrame)
    SettingsFrame:SetScale(1)  -- inherit the matrix scale (no double-scaling)
    SettingsFrame:SetFrameStrata(TrackerFrame:GetFrameStrata())
    SettingsFrame:SetFrameLevel(TrackerFrame:GetFrameLevel() + 30)
    SettingsFrame:ClearAllPoints()
    if _G.EnrageMatrixGearBtn then
        SettingsFrame:SetPoint("BOTTOMLEFT", _G.EnrageMatrixGearBtn, "TOPLEFT", 0, 6)
    else
        SettingsFrame:SetPoint("BOTTOMLEFT", TrackerFrame, "BOTTOMLEFT", 5, 30)
    end
    SettingsTitle:Show()
    SettingsCloseBtn:Show()
    if Enrage_SafeShowFrame then
        Enrage_SafeShowFrame(SettingsFrame)
    else
        SettingsFrame:Show()
    end
    RenderSection(key or activeSection)
end
end  -- settings panel scope

-- Unified settings toggle — shared by the bottom-left gear button and /akcsettings.
function _G.Enrage_ToggleMatrixSettings()
    local f = _G.EnrageSettingsFrame
    -- If the panel is currently embedded in the logs window, /akcsettings should MOVE it
    -- back to the matrix rather than just toggle it off.
    local dockedElsewhere = f and f:GetParent() ~= TrackerFrame
    if Enrage_IsFrameOpen(f) and not dockedElsewhere then
        Enrage_SafeHideFrame(f)
    else
        if Enrage_CloseMatrixPopups then Enrage_CloseMatrixPopups("settings") end
        -- Re-dock to the matrix gear (the logs window may have embedded it elsewhere).
        -- The matrix host must be visible or the panel would sit on a hidden parent.
        if Enrage_SafeShowFrame then Enrage_SafeShowFrame(TrackerFrame) end
        if f then
            f:SetParent(TrackerFrame)
            f:SetScale(1)  -- inherit the matrix scale (no double-scaling)
            f:SetFrameStrata(TrackerFrame:GetFrameStrata())
            f:SetFrameLevel(TrackerFrame:GetFrameLevel() + 30)
            f:ClearAllPoints()
            if _G.EnrageMatrixGearBtn then
                f:SetPoint("BOTTOMLEFT", _G.EnrageMatrixGearBtn, "TOPLEFT", 0, 6)
            else
                f:SetPoint("BOTTOMLEFT", TrackerFrame, "BOTTOMLEFT", 5, 30)
            end
            -- Standalone popup: restore the panel's own title + close button.
            if f.ownTitle then f.ownTitle:Show() end
            if f.ownClose then f.ownClose:Show() end
        end
        Enrage_SafeShowFrame(f)
    end
end

-- Open the settings as a STANDALONE centered window — used by the minimap button so it does
-- NOT also pop the matrix open behind it (which looked like two stacked windows).
function _G.Enrage_ToggleStandaloneSettings()
    local f = _G.EnrageSettingsFrame
    if not f then return end
    if Enrage_IsFrameOpen(f) then
        Enrage_SafeHideFrame(f)
        return
    end
    f:SetParent(UIParent)
    f:SetScale(1)
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetFrameLevel(200)
    f:ClearAllPoints()
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
    if f.ownTitle then f.ownTitle:Show() end
    if f.ownClose then f.ownClose:Show() end
    Enrage_SafeShowFrame(f)
    if f.Raise then f:Raise() end
end

SLASH_ENRAGESETTINGS1 = "/akcsettings"
SlashCmdList["ENRAGESETTINGS"] = function()
    _G.Enrage_ToggleStandaloneSettings()
end

-- Characters filter button, matching Settings.
local FilterBtn = CreateFrame("Button", nil, TitleBar)
FilterBtn:SetPoint("RIGHT", LogsBtn, "LEFT", -5, 0)
FilterBtn:SetSize(85, 20)
ErrorAlertBtn:ClearAllPoints()
ErrorAlertBtn:SetPoint("RIGHT", FilterBtn, "LEFT", -6, 0)
local FilterBtnBg = FilterBtn:CreateTexture(nil, "BACKGROUND")
FilterBtnBg:SetAllPoints()
FilterBtnBg:SetTexture(WV_FLAT_TEX)
FilterBtnBg:SetVertexColor(0.227, 0.239, 0.267, 1)
local FilterBtnInner = FilterBtn:CreateTexture(nil, "ARTWORK")
FilterBtnInner:SetPoint("TOPLEFT", 1, -1)
FilterBtnInner:SetPoint("BOTTOMRIGHT", -1, 1)
FilterBtnInner:SetTexture(WV_FLAT_TEX)
FilterBtnInner:SetGradient("VERTICAL",
    CreateColor(0.090, 0.098, 0.118, 1),
    CreateColor(0.130, 0.141, 0.165, 1))
local FilterBtnTopHL = FilterBtn:CreateTexture(nil, "OVERLAY")
FilterBtnTopHL:SetPoint("TOPLEFT", 1, -1)
FilterBtnTopHL:SetPoint("TOPRIGHT", -1, -1)
FilterBtnTopHL:SetHeight(1)
FilterBtnTopHL:SetTexture(WV_FLAT_TEX)
FilterBtnTopHL:SetVertexColor(1, 1, 1, 0.07)
local FilterBtnText = FilterBtn:CreateFontString(nil, "OVERLAY")
FilterBtnText:SetFont(WV_FONT_FACE, 11, "")
FilterBtnText:SetAllPoints()
FilterBtnText:SetText("|cFFE5E7EBCharacters|r")
FilterBtn:SetScript("OnEnter", function()
    FilterBtnInner:SetGradient("VERTICAL",
        CreateColor(0.130, 0.141, 0.165, 1),
        CreateColor(0.180, 0.196, 0.227, 1))
    FilterBtnBg:SetVertexColor(0.96, 0.62, 0.04, 0.7)
end)
FilterBtn:SetScript("OnLeave", function()
    FilterBtnInner:SetGradient("VERTICAL",
        CreateColor(0.090, 0.098, 0.118, 1),
        CreateColor(0.130, 0.141, 0.165, 1))
    FilterBtnBg:SetVertexColor(0.227, 0.239, 0.267, 1)
end)

-- Bound stat text to not overlap buttons (must be set after FilterBtn is created)
MatrixStatText:SetPoint("RIGHT", ErrorAlertBtn, "LEFT", -8, 0)


-- =========================================================================
-- RESIZE GRIP (PANEL SCALE)
-- =========================================================================
local ResizeGrip = CreateFrame("Button", nil, TrackerFrame)
ResizeGrip:SetSize(24, 24)
ResizeGrip:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 2)
ResizeGrip:SetFrameLevel(TrackerFrame:GetFrameLevel() + 10)
-- 3 diagonal grip lines with shadow (embedded in bottom-right corner)
local gripLines = {}
for j = 0, 2 do
    local shadow = ResizeGrip:CreateTexture(nil, "OVERLAY", nil, 0)
    shadow:SetTexture(WV_FLAT_TEX)
    shadow:SetVertexColor(0, 0, 0, 0.6)
    shadow:SetSize(2, (3 - j) * 6)
    shadow:SetPoint("BOTTOMRIGHT", -(j * 6 + 1), 1)
    local line = ResizeGrip:CreateTexture(nil, "OVERLAY", nil, 1)
    line:SetTexture(WV_FLAT_TEX)
    line:SetVertexColor(1.0, 0.50, 0.00, 1.0)  -- bright Enrage orange (clearly visible grip)
    line:SetSize(2, (3 - j) * 6)
    line:SetPoint("BOTTOMRIGHT", -(j * 6 + 2), 2)
    gripLines[#gripLines + 1] = line
end
-- Hover highlight
ResizeGrip:SetScript("OnEnter", function()
    for _, ln in ipairs(gripLines) do ln:SetVertexColor(0.75, 0.72, 0.80, 1.0) end
end)
ResizeGrip:SetScript("OnLeave", function()
    for _, ln in ipairs(gripLines) do ln:SetVertexColor(0.55, 0.52, 0.60, 0.9) end
end)

if not EnrageDB then EnrageDB = {} end
if not EnrageDB.global then EnrageDB.global = {} end
if not EnrageDB.global.panelScale then EnrageDB.global.panelScale = 1.0 end

TrackerFrame:SetScale(EnrageDB.global.panelScale)

local isSizing = false
local startCursorX, startCursorY
local startScale

ResizeGrip:SetScript("OnMouseDown", function(self, button)
    if button == "LeftButton" then
        isSizing = true
        startCursorX, startCursorY = GetCursorPosition()
        startScale = TrackerFrame:GetScale()
        self:SetScript("OnUpdate", function()
            if isSizing then
                -- Stop if the button was released off the grip (avoids a stuck
                -- rescale that makes the window "slide" while you drag it).
                if not IsMouseButtonDown("LeftButton") then
                    isSizing = false
                    ResizeGrip:SetScript("OnUpdate", nil)
                    return
                end
                local currentX, currentY = GetCursorPosition()
                local diff = (currentX - startCursorX) / 400
                local newScale = startScale + diff

                if newScale < 0.6 then newScale = 0.6 end
                if newScale > 2.0 then newScale = 2.0 end

                -- Clamp scale so the frame doesn't exceed screen bounds
                local screenW = UIParent:GetWidth()
                local screenH = UIParent:GetHeight()
                local frameW = TrackerFrame:GetWidth()
                local frameH = TrackerFrame:GetHeight()
                if frameW > 0 and frameH > 0 then
                    local maxScaleW = screenW / frameW
                    local maxScaleH = screenH / frameH
                    local maxScale = math.min(maxScaleW, maxScaleH)
                    if newScale > maxScale then newScale = maxScale end
                end

                TrackerFrame:SetScale(newScale)
                EnrageDB.global.panelScale = newScale
            end
        end)
    end
end)

ResizeGrip:SetScript("OnMouseUp", function(self, button)
    isSizing = false
    self:SetScript("OnUpdate", nil)
end)

local FilterMenu = CreateFrame("Frame", nil, TrackerFrame)
FilterMenu:SetPoint("TOPRIGHT", FilterBtn, "BOTTOMRIGHT", 0, -5)
FilterMenu:SetWidth(300)
FilterMenu:SetFrameStrata("TOOLTIP")
FilterMenu:Hide()

-- Background matching the main tracker.
local FilterMenuBG = FilterMenu:CreateTexture(nil, "BACKGROUND")
FilterMenuBG:SetAllPoints()
FilterMenuBG:SetTexture(WV_FLAT_TEX)
FilterMenuBG:SetVertexColor(0.106, 0.114, 0.133, 0.94)  -- popup needs more opacity for readability

-- Cyan border lines
WV_CreateBorder(FilterMenu, "TOPLEFT", "TOPLEFT", "TOPRIGHT", "TOPRIGHT", nil, 1)
WV_CreateBorder(FilterMenu, "BOTTOMLEFT", "BOTTOMLEFT", "BOTTOMRIGHT", "BOTTOMRIGHT", nil, 1)
WV_CreateBorder(FilterMenu, "TOPLEFT", "TOPLEFT", "BOTTOMLEFT", "BOTTOMLEFT", 1, nil)
WV_CreateBorder(FilterMenu, "TOPRIGHT", "TOPRIGHT", "BOTTOMRIGHT", "BOTTOMRIGHT", 1, nil)

FilterMenu.items = {}

local function UpdateTrackerInfo() end

-- Get sorted character list respecting custom order
local function GetOrderedChars(charList)
    local order = EnrageDB.global.charOrder or {}
    -- Build a position map from saved order
    local posMap = {}
    for i, name in ipairs(order) do
        posMap[name] = i
    end
    -- Sort: chars with a saved position come first (in that order),
    -- then any new chars alphabetically at the end
    table.sort(charList, function(a, b)
        local pa, pb = posMap[a], posMap[b]
        if pa and pb then return pa < pb end
        if pa then return true end
        if pb then return false end
        return a < b
    end)
    return charList
end

-- Save the current order from a list
local function SaveCharOrder(charList)
    EnrageDB.global.charOrder = {}
    for i, name in ipairs(charList) do
        EnrageDB.global.charOrder[i] = name
    end
end

-- Rebuild the FilterMenu content
local function RebuildFilterMenu()
    for _, item in ipairs(FilterMenu.items) do item:Hide() end

    local allChars = {}
    for cName, _ in pairs(EnrageDB) do
        if cName ~= "version" and cName ~= "hiddenChars" and cName ~= "global" and cName:find("-", 1, true) then
            table.insert(allChars, cName)
        end
    end
    GetOrderedChars(allChars)

    local mY = -10
    for i, cName in ipairs(allChars) do
        local row = FilterMenu.items[i]
        if not row then
            row = CreateFrame("Frame", nil, FilterMenu)
            row:SetHeight(24)

            row.cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            row.cb:SetSize(22, 22)
            row.cb:SetPoint("LEFT", 10, 0)

            row.text = row:CreateFontString(nil, "OVERLAY")
            row.text:SetFont(WV_FONT_FACE, 11, WV_FONT_FLAGS)
            row.text:SetPoint("LEFT", row.cb, "RIGHT", 4, 0)
            row.text:SetWidth(175)
            row.text:SetJustifyH("LEFT")

            -- Move up button
            row.upBtn = CreateFrame("Button", nil, row)
            row.upBtn:SetSize(16, 20)
            row.upBtn:SetPoint("RIGHT", row, "RIGHT", -16, 0)
            row.upBtn.text = row.upBtn:CreateFontString(nil, "OVERLAY")
            row.upBtn.text:SetFont(WV_FONT_FACE, 16, "OUTLINE")
            row.upBtn.text:SetPoint("CENTER", 0, 0)
            row.upBtn.text:SetText("|cFF4DE6FF+|r")
            row.upBtn:SetScript("OnEnter", function(self) self.text:SetText("|cFFFFFFFF+|r") end)
            row.upBtn:SetScript("OnLeave", function(self) self.text:SetText("|cFF4DE6FF+|r") end)

            -- Move down button
            row.downBtn = CreateFrame("Button", nil, row)
            row.downBtn:SetSize(16, 20)
            row.downBtn:SetPoint("LEFT", row.upBtn, "RIGHT", 0, 0)
            row.downBtn.text = row.downBtn:CreateFontString(nil, "OVERLAY")
            row.downBtn.text:SetFont(WV_FONT_FACE, 16, "OUTLINE")
            row.downBtn.text:SetPoint("CENTER", 0, 0)
            row.downBtn.text:SetText("|cFF4DE6FF-|r")
            row.downBtn:SetScript("OnEnter", function(self) self.text:SetText("|cFFFFFFFF-|r") end)
            row.downBtn:SetScript("OnLeave", function(self) self.text:SetText("|cFF4DE6FF-|r") end)

            FilterMenu.items[i] = row
        end

        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", FilterMenu, "TOPLEFT", 0, mY)
        row:SetPoint("TOPRIGHT", FilterMenu, "TOPRIGHT", 0, mY)

        local cColor = (EnrageDB[cName] and EnrageDB[cName].color) or "ffffffff"
        row.text:SetText(string.format("|c%s%s|r", cColor, cName))
        row.cb:SetChecked(not EnrageDB.hiddenChars[cName])

        row.cb:SetScript("OnClick", function(self)
            EnrageDB.hiddenChars[cName] = not self:GetChecked()
            UpdateTrackerInfo()
        end)

        -- Up button
        local idx = i
        row.upBtn:SetScript("OnClick", function()
            if idx <= 1 then return end
            allChars[idx], allChars[idx - 1] = allChars[idx - 1], allChars[idx]
            SaveCharOrder(allChars)
            RebuildFilterMenu()
            UpdateTrackerInfo()
        end)
        row.upBtn:SetAlpha(i > 1 and 1 or 0.3)

        -- Down button
        row.downBtn:SetScript("OnClick", function()
            if idx >= #allChars then return end
            allChars[idx], allChars[idx + 1] = allChars[idx + 1], allChars[idx]
            SaveCharOrder(allChars)
            RebuildFilterMenu()
            UpdateTrackerInfo()
        end)
        row.downBtn:SetAlpha(i < #allChars and 1 or 0.3)

        row:Show()
        mY = mY - 24
    end
    FilterMenu:SetHeight(math.abs(mY) + 10)
end

Enrage_CloseMatrixPopups = function(except)
    if except ~= "characters" then
        Enrage_SafeHideFrame(FilterMenu)
    end
    if except ~= "settings" then
        Enrage_SafeHideFrame(_G.EnrageSettingsFrame)
    end
    if except ~= "logs" and ENRAGE_LOGS_FRAME then
        Enrage_SafeHideFrame(ENRAGE_LOGS_FRAME)
    end
    if except ~= "export" and ENRAGE_LOG_EXPORT_FRAME then
        Enrage_SafeHideFrame(ENRAGE_LOG_EXPORT_FRAME)
    end
    if _G.Enrage_HideTeleportPopup then
        pcall(_G.Enrage_HideTeleportPopup)
    end
end
_G.Enrage_CloseMatrixPopups = Enrage_CloseMatrixPopups

FilterBtn:SetScript("OnClick", function()
    if Enrage_IsFrameOpen(FilterMenu) then
        Enrage_SafeHideFrame(FilterMenu)
    else
        Enrage_CloseMatrixPopups("characters")
        RebuildFilterMenu()
        Enrage_SafeShowFrame(FilterMenu)
    end
end)

-- Allow closing with Escape key
tinsert(UISpecialFrames, "WVTrackerFrame")

-- Close FilterMenu when main panel is hidden (close button, /wv toggle, Escape, etc.)
TrackerFrame:SetScript("OnHide", function()
    if TrackerFrame.enrageEmbeddedHost then
        if not TrackerFrame.enrageDetaching then
            local host = TrackerFrame.enrageEmbeddedHost
            C_Timer.After(0, function()
                if host and host.IsShown and host:IsShown() and host.activeTab == "matrix" then
                    Enrage_SafeShowFrame(TrackerFrame)
                end
            end)
        end
        return
    end
    Enrage_CloseMatrixPopups()
end)

-- (Matrix bottom-left settings gear removed per request. Settings is reached from
-- the logs-window rail gear and /akcsettings; the popup falls back to the matrix
-- bottom-left anchor since _G.EnrageMatrixGearBtn is now nil.)

local SCROLLBAR_WIDTH = 12
local ScrollFrame = CreateFrame("ScrollFrame", nil, TrackerFrame)
ScrollFrame:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 2, -31)
ScrollFrame:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -(SCROLLBAR_WIDTH + 6), 4)
ScrollFrame:EnableMouse(true)
ScrollFrame:RegisterForDrag("LeftButton")
ScrollFrame:SetScript("OnDragStart", function() TrackerFrame:StartMoving() end)
ScrollFrame:SetScript("OnDragStop", function() TrackerFrame:StopMovingOrSizing() end)
ScrollFrame:EnableMouseWheel(true)

-- Scrollbar: thin track and thumb.
local scrollTrack = CreateFrame("Frame", nil, TrackerFrame)
scrollTrack:SetWidth(SCROLLBAR_WIDTH)
scrollTrack:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", -2, -32)
scrollTrack:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 5)
local scrollTrackBg = scrollTrack:CreateTexture(nil, "BACKGROUND")
scrollTrackBg:SetAllPoints()
scrollTrackBg:SetTexture(WV_FLAT_TEX)
scrollTrackBg:SetVertexColor(0.015, 0.018, 0.026, 0.55)

local scrollThumb = CreateFrame("Button", nil, scrollTrack)
scrollThumb:SetWidth(SCROLLBAR_WIDTH)
scrollThumb:SetHeight(40)  -- will be recalculated
scrollThumb:SetPoint("TOP", scrollTrack, "TOP", 0, 0)
local thumbTex = scrollThumb:CreateTexture(nil, "ARTWORK")
thumbTex:SetAllPoints()
thumbTex:SetTexture(WV_FLAT_TEX)
thumbTex:SetVertexColor(0.30, 0.34, 0.42, 0.92)

-- Thumb hover/drag visuals
scrollThumb:SetScript("OnEnter", function() thumbTex:SetVertexColor(0.42, 0.48, 0.58, 1) end)
scrollThumb:SetScript("OnLeave", function()
    if not scrollThumb.isDragging then thumbTex:SetVertexColor(0.30, 0.34, 0.42, 0.92) end
end)

-- Update thumb size & position based on scroll state
local function UpdateScrollbar()
    local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
    local trackH = scrollTrack:GetHeight()
    if trackH <= 0 then trackH = 1 end

    if maxScroll <= 0 then
        scrollThumb:Hide()
        return
    end
    scrollThumb:Show()

    -- Thumb height = visible fraction of total content
    local visibleH = ScrollFrame:GetHeight()
    local contentH = visibleH + maxScroll
    local thumbH = math.max(20, math.floor((visibleH / contentH) * trackH))
    scrollThumb:SetHeight(thumbH)

    -- Thumb position
    local scrollPos = ScrollFrame:GetVerticalScroll()
    local scrollFrac = scrollPos / maxScroll
    local travel = trackH - thumbH
    local thumbY = -math.floor(scrollFrac * travel)
    scrollThumb:ClearAllPoints()
    scrollThumb:SetPoint("TOP", scrollTrack, "TOP", 0, thumbY)
end

-- Mouse wheel scroll
ScrollFrame:SetScript("OnMouseWheel", function(self, delta)
    local current = self:GetVerticalScroll()
    local maxScroll = self:GetVerticalScrollRange() or 0
    local new = current - (delta * 30)
    if new < 0 then new = 0 end
    if new > maxScroll then new = maxScroll end
    self:SetVerticalScroll(new)
    UpdateScrollbar()
end)

-- Also allow mouse wheel on the scrollbar track itself
scrollTrack:EnableMouseWheel(true)
scrollTrack:SetScript("OnMouseWheel", function(_, delta)
    local current = ScrollFrame:GetVerticalScroll()
    local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
    local new = current - (delta * 30)
    if new < 0 then new = 0 end
    if new > maxScroll then new = maxScroll end
    ScrollFrame:SetVerticalScroll(new)
    UpdateScrollbar()
end)

-- Thumb dragging
scrollThumb:SetMovable(true)
scrollThumb:EnableMouse(true)
scrollThumb:RegisterForDrag("LeftButton")
scrollThumb:SetScript("OnDragStart", function(self)
    self.isDragging = true
    thumbTex:SetVertexColor(0.96, 0.62, 0.04, 1)
    local _, _, _, _, startY = self:GetPoint()
    self.dragStartY = startY
    self.dragStartCursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
    self:SetScript("OnUpdate", function(button)
        if not button.isDragging then return end
        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local deltaY = button.dragStartCursorY - cursorY
        local trackH = scrollTrack:GetHeight()
        local thumbH = button:GetHeight()
        local travel = trackH - thumbH
        if travel <= 0 then return end

        local newThumbY = button.dragStartY - deltaY
        if newThumbY > 0 then newThumbY = 0 end
        if newThumbY < -travel then newThumbY = -travel end

        local scrollFrac = (-newThumbY) / travel
        local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
        ScrollFrame:SetVerticalScroll(scrollFrac * maxScroll)

        button:ClearAllPoints()
        button:SetPoint("TOP", scrollTrack, "TOP", 0, newThumbY)
    end)
end)
scrollThumb:SetScript("OnDragStop", function(self)
    self.isDragging = false
    self:SetScript("OnUpdate", nil)
    thumbTex:SetVertexColor(0.30, 0.34, 0.42, 0.92)
end)

-- Click on track to jump scroll position
scrollTrack:EnableMouse(true)
scrollTrack:SetScript("OnMouseDown", function(self, button)
    if button ~= "LeftButton" then return end
    local _, cursorY = GetCursorPosition()
    cursorY = cursorY / UIParent:GetEffectiveScale()
    local trackTop = self:GetTop()
    if not trackTop then return end
    local clickOffset = trackTop - cursorY
    local trackH = self:GetHeight()
    local thumbH = scrollThumb:GetHeight()
    local travel = trackH - thumbH
    if travel <= 0 then return end
    -- Center thumb on click position
    local thumbCenter = clickOffset - thumbH / 2
    if thumbCenter < 0 then thumbCenter = 0 end
    if thumbCenter > travel then thumbCenter = travel end
    local scrollFrac = thumbCenter / travel
    local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
    ScrollFrame:SetVerticalScroll(scrollFrac * maxScroll)
    UpdateScrollbar()
end)

-- The ticker is lightweight and skips all work while Matrix is hidden.
C_Timer.NewTicker(0.5, function()
    if TrackerFrame:IsShown() then
        UpdateScrollbar()
    end
end)

local ContentFrame = CreateFrame("Frame", nil, ScrollFrame)
ContentFrame:SetSize(750, 800)
ScrollFrame:SetScrollChild(ContentFrame)

ContentFrame.fsList = {}
ContentFrame.rectList = {}

local function Enrage_RestoreStandaloneMatrixLayout()
    TrackerFrame:SetParent(UIParent)
    TrackerFrame:ClearAllPoints()
    TrackerFrame:SetPoint("CENTER")
    TrackerFrame:SetSize(600, 450)
    TrackerFrame:SetScale((EnrageDB and EnrageDB.global and EnrageDB.global.panelScale) or 1.0)
    TrackerFrame:SetMovable(true)
    TrackerFrame:SetResizable(true)
    TrackerFrame:RegisterForDrag("LeftButton")
    TrackerFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    TrackerFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    TitleBar:Show()
    titleSep:Show()
    ResizeGrip:Show()

    ScrollFrame:ClearAllPoints()
    ScrollFrame:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 2, -31)
    ScrollFrame:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -(SCROLLBAR_WIDTH + 6), 4)
    ScrollFrame:RegisterForDrag("LeftButton")
    ScrollFrame:SetScript("OnDragStart", function() TrackerFrame:StartMoving() end)
    ScrollFrame:SetScript("OnDragStop", function() TrackerFrame:StopMovingOrSizing() end)

    scrollTrack:ClearAllPoints()
    scrollTrack:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", -2, -32)
    scrollTrack:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 5)
end

function _G.Enrage_AttachMatrixToMain(host)
    if not host or not TrackerFrame then return end
    TrackerFrame.enrageEmbeddedHost = host
    TrackerFrame:SetParent(host)
    TrackerFrame:ClearAllPoints()
    TrackerFrame:SetPoint("TOPLEFT", host, "TOPLEFT", 74, -50)
    TrackerFrame:SetPoint("BOTTOMRIGHT", host, "BOTTOMRIGHT", -14, 12)
    TrackerFrame:SetScale(1)
    TrackerFrame:SetFrameStrata(host:GetFrameStrata())
    TrackerFrame:SetFrameLevel(host:GetFrameLevel() + 4)
    TrackerFrame:SetMovable(false)
    TrackerFrame:SetResizable(false)
    pcall(TrackerFrame.RegisterForDrag, TrackerFrame)
    TrackerFrame:SetScript("OnDragStart", nil)
    TrackerFrame:SetScript("OnDragStop", nil)

    TitleBar:Hide()
    titleSep:Hide()
    ResizeGrip:Hide()

    ScrollFrame:ClearAllPoints()
    ScrollFrame:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 2, -2)
    ScrollFrame:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -(SCROLLBAR_WIDTH + 6), 4)
    pcall(ScrollFrame.RegisterForDrag, ScrollFrame)
    ScrollFrame:SetScript("OnDragStart", nil)
    ScrollFrame:SetScript("OnDragStop", nil)

    scrollTrack:ClearAllPoints()
    scrollTrack:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", -2, -3)
    scrollTrack:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 5)

    RequestRaidInfo()
    C_MythicPlus.RequestRewards()
    C_MythicPlus.RequestMapInfo()
    Enrage_SafeShowFrame(TrackerFrame)
    C_Timer.After(0.1, function()
        if TrackerFrame.enrageEmbeddedHost == host and UpdateTrackerInfo then
            UpdateTrackerInfo()
        end
    end)
end

function _G.Enrage_DetachMatrixFromMain(host)
    if not TrackerFrame or not TrackerFrame.enrageEmbeddedHost then return end
    if host and TrackerFrame.enrageEmbeddedHost ~= host then return end
    TrackerFrame.enrageDetaching = true
    Enrage_SafeHideFrame(TrackerFrame)
    TrackerFrame.enrageEmbeddedHost = nil
    TrackerFrame.enrageDetaching = nil
    Enrage_RestoreStandaloneMatrixLayout()
end

function _G.Enrage_ToggleMatrixCharacters(anchor)
    if not FilterMenu or not anchor then return end
    if Enrage_IsFrameOpen(FilterMenu) then
        Enrage_SafeHideFrame(FilterMenu)
        return
    end
    if _G.EnrageSettingsFrame then Enrage_SafeHideFrame(_G.EnrageSettingsFrame) end
    RebuildFilterMenu()
    FilterMenu:SetParent(UIParent)
    FilterMenu:SetFrameStrata("TOOLTIP")
    FilterMenu:SetFrameLevel(1000)
    FilterMenu:SetScale((ENRAGE_LOGS_FRAME and ENRAGE_LOGS_FRAME.GetScale and ENRAGE_LOGS_FRAME:GetScale()) or 1)
    if FilterMenu.SetToplevel then FilterMenu:SetToplevel(true) end
    FilterMenu:ClearAllPoints()
    FilterMenu:SetPoint("TOPRIGHT", anchor, "BOTTOMRIGHT", 0, -6)
    Enrage_SafeShowFrame(FilterMenu)
    if FilterMenu.Raise then FilterMenu:Raise() end
end

_G.EnrageMatrix_FilterMenu = FilterMenu

local function GetDungeonBanner(dName)
    if not EnrageDB.global.bannerCache then EnrageDB.global.bannerCache = {} end
    if EnrageDB.global.bannerCache[dName] then
        return EnrageDB.global.bannerCache[dName]
    end

    for i = 1, 2500 do
        local name, _, _, buttonImage = EJ_GetInstanceInfo(i)
        if name and buttonImage then
            EnrageDB.global.bannerCache[name] = buttonImage
        end
    end

    return EnrageDB.global.bannerCache[dName] or 134400
end

-- Dungeon teleport (Hero's Path) support
-- WoW uses unique spell names per dungeon (e.g. "Path of the Skies" for Skyreach)
-- We scan the player's spellbook and match by spell description containing the dungeon name
local dungeonTeleportCache = nil  -- nil = not yet scanned, table = scanned

local DUNGEON_TELEPORT_FALLBACKS = {
    ["Algeth'ar Academy"] = { name = "Path of the Draconic Diploma", id = 393273 },
    ["Magisters' Terrace"] = { name = "Path of Devoted Magistry", id = 1254572 },
    ["Maisara Caverns"] = { name = "Path of Cavernous Depths", id = 1254559 },
    ["Nexus-Point Xenas"] = { name = "Path of the Fractured Core", id = 1254563 },
    ["Pit of Saron"] = { name = "Path of Unyielding Blight", id = 1254555 },
    ["Seat of the Triumvirate"] = { name = "Path of Dark Dereliction", id = 1254551 },
    ["Skyreach"] = { name = "Path of the Skies", id = 159898 },
    ["Windrunner Spire"] = { name = "Path of the Windrunners", id = 1254400 },
}

local function Enrage_GetTeleportSpellBanks()
    local banks = {}
    if Enum and Enum.SpellBookSpellBank then
        if Enum.SpellBookSpellBank.Player then
            banks[#banks + 1] = Enum.SpellBookSpellBank.Player
        end
        if Enum.SpellBookSpellBank.General then
            banks[#banks + 1] = Enum.SpellBookSpellBank.General
        end
    end
    return banks
end

local function Enrage_SpellIDMatches(a, b)
    local numA = tonumber(a)
    local numB = tonumber(b)
    return numA and numB and numA == numB
end

local function Enrage_SpellBookContainsCurrentCharSpell(spellID)
    if not spellID or not C_SpellBook or not C_SpellBook.GetSpellBookItemInfo then return false end

    for _, bank in ipairs(Enrage_GetTeleportSpellBanks()) do
        for slot = 1, 5000 do
            local ok, info = pcall(C_SpellBook.GetSpellBookItemInfo, slot, bank)
            if not ok or not info then break end
            if Enrage_SpellIDMatches(info.spellID, spellID) then
                return true
            end
        end
    end

    return false
end

local function Enrage_IsKnownTeleportSpell(spellID)
    if not spellID then return false end

    if C_SpellBook and C_SpellBook.FindSpellBookSlotForSpell then
        local ok, slot = pcall(C_SpellBook.FindSpellBookSlotForSpell, spellID)
        if ok and tonumber(slot or 0) > 0 then return true end
    end

    if type(IsPlayerSpell) == "function" then
        local ok, known = pcall(IsPlayerSpell, spellID)
        if ok and known then return true end
    end

    if type(IsSpellKnownOrOverridesKnown) == "function" then
        local ok, known = pcall(IsSpellKnownOrOverridesKnown, spellID)
        if ok and known then return true end
    end

    if type(IsSpellKnown) == "function" then
        local ok, known = pcall(IsSpellKnown, spellID)
        if ok and known then return true end
    end

    if C_SpellBook then
        for _, bank in ipairs(Enrage_GetTeleportSpellBanks()) do
            if C_SpellBook.IsSpellKnown then
                local ok, known = pcall(C_SpellBook.IsSpellKnown, spellID, bank)
                if ok and known then return true end
            end
        end
    end

    return Enrage_SpellBookContainsCurrentCharSpell(spellID)
end

local function BuildDungeonTeleportCache()
    dungeonTeleportCache = {}

    -- Saved discoveries are only a name cache; icon visibility must come from this character.

    -- 1) Scan spellbook to discover currently known teleport spells.
    local found = {}
    for _, bank in ipairs(Enrage_GetTeleportSpellBanks()) do
        local i = 1
        while i < 5000 do
            local ok, info = pcall(C_SpellBook.GetSpellBookItemInfo, i, bank)
            if not ok or not info then break end
            if info.spellID then
                local ok2, desc = pcall(C_Spell.GetSpellDescription, info.spellID)
                if ok2 and desc and desc ~= "" then
                    local descLower = desc:lower()
                    if descLower:find("teleport") and descLower:find("entrance") then
                        local spellInfo = C_Spell.GetSpellInfo(info.spellID)
                        if spellInfo and spellInfo.name then
                            found[#found + 1] = {
                                desc = descLower,
                                name = spellInfo.name,
                                id = info.spellID,
                            }
                        end
                    end
                end
            end
            i = i + 1
        end
    end

    -- 2) Match found spells to dungeon names and save to DB.
    local DUNGEON_NAMES = {
        "Algeth'ar Academy", "Magisters' Terrace", "Maisara Caverns",
        "Nexus-Point Xenas", "Pit of Saron", "Seat of the Triumvirate",
        "Skyreach", "Windrunner Spire",
    }
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    if not EnrageDB.global.dungeonTeleports then EnrageDB.global.dungeonTeleports = {} end

    for dName, fallback in pairs(DUNGEON_TELEPORT_FALLBACKS) do
        if not dungeonTeleportCache[dName] and Enrage_IsKnownTeleportSpell(fallback.id) then
            dungeonTeleportCache[dName] = { name = fallback.name, id = fallback.id, known = true }
            EnrageDB.global.dungeonTeleports[dName] = { name = fallback.name, id = fallback.id }
        end
    end

    for _, spell in ipairs(found) do
        for _, dName in ipairs(DUNGEON_NAMES) do
            if spell.desc:find(dName:lower(), 1, true) then
                dungeonTeleportCache[dName] = { name = spell.name, id = spell.id, known = true }
                EnrageDB.global.dungeonTeleports[dName] = { name = spell.name, id = spell.id }  -- persist across characters
            end
        end
    end
end

local function GetDungeonTeleportSpell(dungeonName)
    if not dungeonTeleportCache then
        BuildDungeonTeleportCache()
    end
    local record = dungeonTeleportCache[dungeonName]
    if type(record) == "string" then record = { name = record } end
    if type(record) ~= "table" then return false end
    if not record.known then return false end

    local spellName = record.name
    local spellID = record.id
    if spellID then
        local spellInfo = C_Spell.GetSpellInfo(spellID)
        if spellInfo and spellInfo.name and spellInfo.name ~= "" then
            spellName = spellInfo.name
        end
    end
    if not spellName or spellName == "" then return false end

    return spellName, spellID
end

function Enrage_FormatTeleportCooldown(seconds)
    seconds = math.max(0, math.ceil(tonumber(seconds) or 0))
    if seconds >= 3600 then
        return string.format("%dh %02dm", math.floor(seconds / 3600), math.floor((seconds % 3600) / 60))
    elseif seconds >= 60 then
        return string.format("%dm %02ds", math.floor(seconds / 60), seconds % 60)
    end
    return string.format("%ds", seconds)
end

function Enrage_GetTeleportCooldownRemaining(spellID, spellName)
    local spell = spellID or spellName
    if not spell then return 0 end

    local startTime, duration, isEnabled, modRate
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok, cdInfo = pcall(C_Spell.GetSpellCooldown, spell)
        if ok and type(cdInfo) == "table" then
            startTime = tonumber(cdInfo.startTime or cdInfo.start or 0) or 0
            duration = tonumber(cdInfo.duration or 0) or 0
            isEnabled = cdInfo.isEnabled
            modRate = tonumber(cdInfo.modRate or 1) or 1
        end
    end

    if (not duration or duration <= 0) and type(GetSpellCooldown) == "function" then
        local ok, s, d, e, m = pcall(GetSpellCooldown, spell)
        if ok then
            startTime = tonumber(s or 0) or 0
            duration = tonumber(d or 0) or 0
            isEnabled = e
            modRate = tonumber(m or 1) or 1
        end
    end

    if isEnabled == false or isEnabled == 0 then return 0 end
    if not startTime or not duration or startTime <= 0 or duration <= 2 then return 0 end

    local now = type(GetTime) == "function" and GetTime() or 0
    local remaining = duration - ((now - startTime) * (modRate > 0 and modRate or 1))
    return remaining > 1 and remaining or 0
end

function Enrage_ApplyTeleportButtonState(btn)
    if not btn then return end

    local remaining = Enrage_GetTeleportCooldownRemaining(btn.spellID, btn.spellDisplayName)
    btn.teleportCooldownRemaining = remaining
    btn.teleportOnCooldown = remaining > 0

    if btn.teleportOnCooldown then
        if type(InCombatLockdown) ~= "function" or not InCombatLockdown() then
            btn:SetAttribute("type", nil)
            btn:SetAttribute("type1", nil)
            btn:SetAttribute("spell", nil)
            btn:SetAttribute("spell1", nil)
        end
        if btn.portalIcon then
            if btn.portalIcon.SetDesaturated then pcall(btn.portalIcon.SetDesaturated, btn.portalIcon, true) end
            btn.portalIcon:SetVertexColor(0.72, 0.72, 0.72, 1)
            btn.portalIcon:SetAlpha(0.45)
        end
        if btn.cooldownText then
            btn.cooldownText:SetText(Enrage_FormatTeleportCooldown(remaining))
            btn.cooldownText:Show()
        end
    else
        if type(InCombatLockdown) ~= "function" or not InCombatLockdown() then
            local tpCastSpell = btn.spellID or btn.spellDisplayName
            btn:SetAttribute("type", "spell")
            btn:SetAttribute("type1", "spell")
            btn:SetAttribute("spell", tpCastSpell)
            btn:SetAttribute("spell1", tpCastSpell)
        end
        if btn.portalIcon then
            if btn.portalIcon.SetDesaturated then pcall(btn.portalIcon.SetDesaturated, btn.portalIcon, false) end
            btn.portalIcon:SetVertexColor(1, 1, 1, 1)
            btn.portalIcon:SetAlpha(0.85)
        end
        if btn.cooldownText then
            btn.cooldownText:SetText("")
            btn.cooldownText:Hide()
        end
    end
end

-- Clear teleport cache on spec/spell changes (new spells may become available)
local tpCacheFrame = CreateFrame("Frame")
tpCacheFrame:RegisterEvent("SPELLS_CHANGED")
tpCacheFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
tpCacheFrame:SetScript("OnEvent", function() dungeonTeleportCache = nil end)

-- Direct secure teleport buttons. These are only created/updated out of combat.
-- They live under this dedicated host whose visibility is driven by a SECURE state
-- driver, so the secure framework (not addon code) hides them in combat. That is
-- the only way to neutralise SecureActionButtons in combat: it removes the invisible
-- right-click trap left behind when the matrix is closed mid-combat (a frame that
-- parents SecureActionButtons cannot be Hidden/moved by addon code in combat) and
-- lets the matrix soft-hide cleanly. Teleports are unusable in combat anyway.
local teleportSecureHost = CreateFrame("Frame", "EnrageTeleportSecureHost", ContentFrame)
teleportSecureHost:SetAllPoints(ContentFrame)
-- Register the secure visibility driver only out of combat (a /reload mid-combat
-- would have its SetAttribute on the secure manager blocked). Retried from the
-- combat-end handler so a combat-time reload still self-heals next time combat ends.
local function Enrage_EnsureTeleportDriver()
    if teleportSecureHost.enrageDriverSet then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    if type(RegisterStateDriver) == "function"
        and pcall(RegisterStateDriver, teleportSecureHost, "visibility", "[combat] hide; show") then
        teleportSecureHost.enrageDriverSet = true
    end
end
Enrage_EnsureTeleportDriver()

local teleportBtnPool = {}
local teleportBtnCount = 0

local function Enrage_CloseMatrixAfterTeleport()
    if GameTooltip then GameTooltip:Hide() end
    if FilterMenu then Enrage_SafeHideFrame(FilterMenu) end
    if _G.EnrageSettingsFrame then Enrage_SafeHideFrame(_G.EnrageSettingsFrame) end

    if ENRAGE_LOGS_FRAME and Enrage_IsFrameOpen(ENRAGE_LOGS_FRAME) then
        Enrage_SafeHideFrame(ENRAGE_LOGS_FRAME)
    end

    if TrackerFrame and Enrage_IsFrameOpen(TrackerFrame) then
        Enrage_SafeHideFrame(TrackerFrame)
    end
end

local function GetOrCreateTeleportBtn(parent)
    teleportBtnCount = teleportBtnCount + 1
    local btn = teleportBtnPool[teleportBtnCount]
    if not btn then
        btn = CreateFrame("Button", "EnrageTeleportBtn" .. teleportBtnCount, parent, "SecureActionButtonTemplate")
        btn:SetAttribute("type", "spell")
        btn:SetAttribute("type1", "spell")
        btn:SetAttribute("useOnKeyDown", false)
        btn:SetAttribute("pressAndHoldAction", false)
        btn:RegisterForClicks("AnyUp", "AnyDown")
        btn:EnableMouse(true)

        btn:SetHighlightTexture("Interface\\Buttons\\WHITE8X8")
        btn:GetHighlightTexture():SetVertexColor(0.2, 0.7, 1.0, 0.12)

        -- Small teleport indicator icon (positioned dynamically after dungeon name)
        btn.portalIcon = btn:CreateTexture(nil, "OVERLAY")
        btn.portalIcon:SetSize(14, 14)
        btn.portalIcon:SetAtlas("Taxi_Frame_Green")
        btn.portalIcon:SetAlpha(0.85)

        btn.cooldownText = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        btn.cooldownText:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
        btn.cooldownText:SetTextColor(1.0, 0.82, 0.24, 1)
        btn.cooldownText:SetShadowOffset(1, -1)
        btn.cooldownText:SetShadowColor(0, 0, 0, 1)
        btn.cooldownText:SetJustifyH("LEFT")
        btn.cooldownText:SetWidth(64)
        btn.cooldownText:Hide()

        btn:SetScript("OnEnter", function(self)
            Enrage_ApplyTeleportButtonState(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine("Teleport", 0.33, 0.87, 1)
            GameTooltip:AddLine(self.spellDisplayName or "", 0.7, 0.7, 0.7)
            if self.teleportOnCooldown then
                GameTooltip:AddLine("Cooldown: " .. Enrage_FormatTeleportCooldown(self.teleportCooldownRemaining or 0), 1, 0.82, 0.24)
            else
                GameTooltip:AddLine("Click to teleport", 0.5, 0.5, 0.5)
            end
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        btn:SetScript("PostClick", function(self)
            if self.teleportOnCooldown then return end
            if C_Timer and C_Timer.After then
                C_Timer.After(0.6, Enrage_CloseMatrixAfterTeleport)
            else
                Enrage_CloseMatrixAfterTeleport()
            end
        end)
        teleportBtnPool[teleportBtnCount] = btn
    end
    return btn
end

C_Timer.NewTicker(1, function()
    if not TrackerFrame:IsShown() then return end
    for i = 1, teleportBtnCount do
        local button = teleportBtnPool[i]
        if button and button:IsShown() then
            Enrage_ApplyTeleportButtonState(button)
        end
    end
end)

local function HideAllTeleportBtns()
    for i = 1, teleportBtnCount do
        if teleportBtnPool[i] then teleportBtnPool[i]:Hide() end
    end
    teleportBtnCount = 0
end

UpdateTrackerInfo = function()
    SaveCurrentCharacterData()
    HideAllTeleportBtns()  -- reset teleport buttons for re-layout

    -- (CC/Interrupt/RaidCDs removed)

    for _, fs in ipairs(ContentFrame.fsList) do fs:Hide() end
    for _, rect in ipairs(ContentFrame.rectList) do rect:Hide() end
    local fsIdx, rectIdx = 1, 1

    local function DrawText(txt, x, y, w, align, font)
        local fs = ContentFrame.fsList[fsIdx]
        if not fs then
            fs = ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            ContentFrame.fsList[fsIdx] = fs
        end
        fsIdx = fsIdx + 1
        fs:SetFontObject(font or "GameFontHighlightSmall")
        fs:SetTextColor(0.898, 0.906, 0.922, 1)  -- light text on dark theme
        fs:SetWordWrap(false)  -- prevent multi-line overflow (truncate instead of wrap)
        fs:SetNonSpaceWrap(false)
        fs:SetText(txt)
        fs:ClearAllPoints()
        fs:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", x, y)
        if w then fs:SetWidth(w) end
        fs:SetJustifyH(align)
        fs:Show()
    end

    local function DrawRect(x, y, w, h, r, g, b, a, layer)
        local rect = ContentFrame.rectList[rectIdx]
        if not rect then
            rect = ContentFrame:CreateTexture(nil, layer or "BACKGROUND")
            ContentFrame.rectList[rectIdx] = rect
        end
        rectIdx = rectIdx + 1
        rect:SetDrawLayer(layer or "BACKGROUND")
        rect:SetColorTexture(r, g, b, a)
        rect:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", x, y)
        rect:SetSize(w, h)
        rect:Show()
        return rect
    end

    if not EnrageDB then return end

    -- Show only Name-Realm character records; legacy name-only records are hidden.
    local function hasRealmKey(key)
        return key and key:find("-", 1, true)
    end

    local visibleChars = {}
    local allRaids, allDungeons = {}, {}
    local maxKeys = 0

    for char, data in pairs(EnrageDB) do
        if char ~= "version" and char ~= "hiddenChars" and char ~= "global" and hasRealmKey(char) then
            if not EnrageDB.hiddenChars[char] then
                table.insert(visibleChars, char)
                for rName, _ in pairs(data.raids) do allRaids[rName] = true end
                for dName, _ in pairs(data.dungeons) do allDungeons[dName] = true end
                if #data.topKeys > maxKeys then maxKeys = #data.topKeys end
            end
        end
    end
    GetOrderedChars(visibleChars)

    local raidList, dungeonList = {}, {}
    for k in pairs(allRaids) do table.insert(raidList, k) end
    for k in pairs(allDungeons) do table.insert(dungeonList, k) end
    table.sort(raidList)
    table.sort(dungeonList)

    -- Left-side category/dungeon column.
    local nameW = 260
    -- Minimum per-character width; large enough for Name-Realm labels.
    local minCharColW = TrackerFrame.enrageEmbeddedHost and 112 or 140
    local calculatedGridW = nameW + (#visibleChars * minCharColW)
    -- Wider base width keeps the Matrix readable when many characters are visible.
    local embeddedVisibleW = TrackerFrame.enrageEmbeddedHost and math.max(760, math.floor((ScrollFrame:GetWidth() or 760) - 2)) or 760
    local gridW = math.max(embeddedVisibleW, calculatedGridW)
    local colW = (gridW - nameW) / math.max(1, #visibleChars)

    -- Dynamic width: ContentFrame (gridW) fits exactly within ScrollFrame visible area
    -- Combat-safe: skip resize during combat (secure children = SetWidth blocked).
    -- PLAYER_REGEN_ENABLED handler refreshes frame after combat ends.
    if not InCombatLockdown() then
        if not TrackerFrame.enrageEmbeddedHost then
            TrackerFrame:SetWidth(gridW + SCROLLBAR_WIDTH + 8)
        end
        ContentFrame:SetWidth(gridW)
    end

    local startY = 0
    local currentY = startY
    local colBgs = {}
    local vLines = {}

    -- Section collapse state; needed before the column header creates its toggles.
    if not EnrageDB.global.sectionCollapsed then EnrageDB.global.sectionCollapsed = {} end
    local secCol = EnrageDB.global.sectionCollapsed

    -- CHARACTER INFO visibility settings
    if not EnrageDB.global.charInfoVisible then
        EnrageDB.global.charInfoVisible = { level = true, ilvl = true, rating = true, spark = true, sparkRadiance = true, hunt = true, cofferShards = true, keystone = true, delveBounty = true, nemesis = true }
    end
    local civ = EnrageDB.global.charInfoVisible

    -- Reusable section toggle buttons (created once, repositioned each redraw)
    if not ContentFrame.sectionToggles then ContentFrame.sectionToggles = {} end
    for _, btn in pairs(ContentFrame.sectionToggles) do btn:Hide() end
    if ContentFrame.charInfoSettingsBtn then ContentFrame.charInfoSettingsBtn:Hide() end

    local function GetSectionToggle(key)
        if ContentFrame.sectionToggles[key] then return ContentFrame.sectionToggles[key] end
        local btn = CreateFrame("Button", nil, ContentFrame)
        btn:EnableMouse(true)
        btn.hl = btn:CreateTexture(nil, "HIGHLIGHT")
        btn.hl:SetAllPoints()
        btn.hl:SetTexture(WV_FLAT_TEX)
        btn.hl:SetVertexColor(1, 1, 1, 0.06)
        btn:SetScript("OnClick", function(self, mouseBtn)
            if mouseBtn == "RightButton" and self.onRightClick then
                self.onRightClick()
            else
                secCol[key] = not secCol[key]
                EnrageDB.global.sectionCollapsed = secCol
                UpdateTrackerInfo()
            end
        end)
        btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        ContentFrame.sectionToggles[key] = btn
        return btn
    end

    local headerH = 34

    local function DrawDataRow(y, h, alt)
        local c = alt and MATRIX_THEME.rowAlt or MATRIX_THEME.rowBase
        DrawRect(0, y, gridW, h, c[1], c[2], c[3], c[4], "ARTWORK")
        DrawRect(0, y - h + 1, gridW, 1, MATRIX_THEME.rowLine[1], MATRIX_THEME.rowLine[2], MATRIX_THEME.rowLine[3], MATRIX_THEME.rowLine[4], "OVERLAY")
    end

    local function DrawStatusChip(label, x, y, w, statusKey)
        local status = MATRIX_THEME.status[statusKey or "neutral"] or MATRIX_THEME.status.neutral
        local maxW = math.max(24, w - 12)
        local chipW = math.min(maxW, math.max(46, (#label * 6) + 18))
        local chipX = x + math.floor((w - chipW) / 2)
        DrawRect(chipX, y - 3, chipW, 18, status.color[1], status.color[2], status.color[3], status.bgAlpha or 0.12, "ARTWORK")
        DrawRect(chipX, y - 3, 2, 18, status.color[1], status.color[2], status.color[3], 0.78, "OVERLAY")
        DrawText("|cFF" .. status.hex .. label .. "|r", chipX, y - 6, chipW, "CENTER")
    end

    local function DrawDash(x, y, w)
        DrawText("|c" .. MATRIX_THEME.text.faint .. "-|r", x, y, w, "CENTER")
    end

    local function DrawSectionHeader(key, y, section, labelX, labelW)
        labelX = labelX or 14
        labelW = labelW or (nameW - labelX - 8)
        DrawRect(0, y, gridW, headerH, MATRIX_THEME.headerBg[1], MATRIX_THEME.headerBg[2], MATRIX_THEME.headerBg[3], MATRIX_THEME.headerBg[4], "ARTWORK")
        DrawRect(0, y, gridW, headerH, section.color[1], section.color[2], section.color[3], 0.045, "ARTWORK")
        DrawRect(0, y, gridW, 1, section.color[1], section.color[2], section.color[3], 0.68, "OVERLAY")
        DrawRect(0, y, 3, headerH, section.color[1], section.color[2], section.color[3], 0.90, "OVERLAY")
        DrawRect(nameW, y - 4, 1, headerH - 8, 1, 1, 1, 0.045, "OVERLAY")
        local lA = secCol[key] and ">" or "v"
        local rA = secCol[key] and "<" or "v"
        DrawText("|cFF" .. section.hex .. lA .. "  " .. section.label .. "  " .. rA .. "|r", labelX, y - 10, labelW, "LEFT", "GameFontNormal")
    end

    local function DrawSectionEnd(yTop, yBottom, section)
        local secH = math.abs(yTop - yBottom)
        DrawRect(0, yBottom, gridW, 1, section.color[1], section.color[2], section.color[3], 0.48, "OVERLAY")
        DrawRect(0, yTop, 3, secH, section.color[1], section.color[2], section.color[3], 0.78, "OVERLAY")
        DrawRect(gridW - 1, yTop, 1, secH, section.color[1], section.color[2], section.color[3], 0.22, "OVERLAY")
    end

    -- CHARACTER INFO header

    DrawSectionHeader("charInfo", startY, MATRIX_THEME.sections.charInfo, 34, nameW - 42)

    -- Vertical column separators are intentionally omitted; section wraps and alt rows provide structure.

    local headerTextY = currentY - 6
    for i, char in ipairs(visibleChars) do
        local cColor = EnrageDB[char].color or "ffffffff"
        local baseName, realm = char:match("^(.-)%-(.+)$")
        if not baseName then
            baseName, realm = char, nil
        end
        DrawText(string.format("|c%s%s|r", cColor, baseName), nameW + ((i-1)*colW), headerTextY, colW, "CENTER", "GameFontNormal")
        if realm then
            DrawText(string.format("|cFF8A8C90%s|r", realm), nameW + ((i-1)*colW), headerTextY - 11, colW, "CENTER", "GameFontHighlightSmall")
        end
    end

    -- Settings gear button: icon-only, without a visible border/background.
    if not ContentFrame.charInfoSettingsBtn then
        local sb = CreateFrame("Button", nil, ContentFrame)
        sb:EnableMouse(true)
        sb:SetSize(20, 20)
        sb.bg = sb:CreateTexture(nil, "BACKGROUND")
        sb.bg:SetAllPoints()
        sb.bg:SetTexture(WV_FLAT_TEX)
        sb.bg:SetVertexColor(0, 0, 0, 0)  -- invisible bg (no border, just icon)
        -- Gear icon fills the button area with an amber tint.
        sb.icon = sb:CreateTexture(nil, "ARTWORK")
        sb.icon:SetTexture("Interface\\Buttons\\UI-OptionsButton")
        sb.icon:SetVertexColor(1.0, 0.78, 0.20, 1)
        sb.icon:SetAllPoints()
        sb.text = sb:CreateFontString(nil, "OVERLAY")
        sb.text:Hide()
        sb:SetScript("OnEnter", function(self)
            self.bg:SetVertexColor(0.20, 0.22, 0.28, 0.98)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Toggle visible rows")
            GameTooltip:Show()
        end)
        sb:SetScript("OnLeave", function(self)
            self.bg:SetVertexColor(0, 0, 0, 0)
            GameTooltip:Hide()
        end)
        sb:SetScript("OnClick", function()
            if ContentFrame.charInfoPopup and ContentFrame.charInfoPopup:IsShown() then
                ContentFrame.charInfoPopup:Hide()
                return
            end
            if not ContentFrame.charInfoPopup then
                local popup = CreateFrame("Frame", nil, TrackerFrame, "BackdropTemplate")
                popup:SetSize(180, 186)
                popup:SetFrameStrata("TOOLTIP")
                popup:EnableMouse(true)        -- block clicks from passing through to elements behind
                popup:SetToplevel(true)         -- ensure popup stays on top
                popup:SetBackdrop({
                    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                    tile = true, tileSize = 16, edgeSize = 16,
                    insets = { left = 4, right = 4, top = 4, bottom = 4 }
                })
                popup:SetBackdropColor(0.1, 0.1, 0.1, 0.98)
                popup:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)

                local rows = {
                    { key = "level", label = "Level" },
                    { key = "ilvl", label = "Item Level" },
                    { key = "rating", label = "Mythic+ Score" },
                    { key = "spark", label = "Weekly Spark" },
                    { key = "sparkRadiance", label = "Spark of Radiance" },
                    { key = "hunt", label = "Hunt" },
                    { key = "cofferShards", label = "Coffer Key Shards" },
                    { key = "keystone", label = "Mythic+ Keystone" },
                    { key = "delveBounty", label = "Delve Bounty" },
                    { key = "nemesis", label = "Nemesis" },
                }
                local py = -8
                for _, row in ipairs(rows) do
                    local cb = CreateFrame("CheckButton", nil, popup, "UICheckButtonTemplate")
                    cb:SetSize(22, 22)
                    cb:SetPoint("TOPLEFT", 8, py)
                    cb:SetChecked(civ[row.key] ~= false)
                    local lbl = cb:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                    lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
                    lbl:SetText(row.label)
                    cb:SetScript("OnClick", function(self)
                        EnrageDB.global.charInfoVisible[row.key] = self:GetChecked() and true or false
                        UpdateTrackerInfo()
                    end)
                    py = py - 26
                end
                popup:SetHeight(math.abs(py) + 8)
                ContentFrame.charInfoPopup = popup
            end
            ContentFrame.charInfoPopup:ClearAllPoints()
            ContentFrame.charInfoPopup:SetPoint("TOPLEFT", ContentFrame.charInfoSettingsBtn, "BOTTOMLEFT", 0, -2)
            ContentFrame.charInfoPopup:Show()
        end)
        ContentFrame.charInfoSettingsBtn = sb
    end
    -- Gear button: leftmost position, vertically centered in the 34px header.
    ContentFrame.charInfoSettingsBtn:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 6, startY - 7)
    ContentFrame.charInfoSettingsBtn:SetFrameLevel(ContentFrame:GetFrameLevel() + 8)
    ContentFrame.charInfoSettingsBtn:Show()

    -- Collapse toggle starts AFTER gear (so gear click doesn't trigger toggle)
    local ciToggle = GetSectionToggle("charInfo")
    ciToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 28, startY)
    ciToggle:SetSize(nameW - 30, headerH)
    ciToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
    ciToggle:Show()

    -- Move past the column header; bottom shadow is already drawn.
    currentY = currentY - (headerH + 6)

    local isAltRow = false

    if not secCol.charInfo then
    -- Level
    if civ.level ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Level", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local val = EnrageDB[char].level or "-"
            if val == "-" then
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            else
                DrawText(tostring(val), nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            end
        end
        currentY = currentY - 24
    end

    -- Item Level
    if civ.ilvl ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Item Level", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local val = EnrageDB[char] and EnrageDB[char].ilvl
            local text = (val and val > 0) and string.format("|cff00FF00%.2f|r", val) or (val == 0 and "0" or "-")
            DrawText(text, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
        end
        currentY = currentY - 24
    end

    -- Mythic+ Score
    if civ.rating ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Mythic+ Score", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local val = EnrageDB[char] and EnrageDB[char].rating
            local text = "-"
            if val and val > 0 then
                local colorObj = C_ChallengeMode.GetDungeonScoreRarityColor(val)
                if colorObj then
                    text = colorObj:WrapTextInColorCode(val)
                else
                    text = string.format("|cffFF8000%d|r", val)
                end
            elseif val == 0 then
                text = "0"
            end
            if text == "-" then
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            else
                DrawText(text, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            end
        end
        currentY = currentY - 24
    end

    -- Weekly Spark
    if civ.spark ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Weekly Spark", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local completed = EnrageDB[char] and EnrageDB[char].sparkQuestCompleted
            DrawStatusChip(completed and "Done" or "Not Done", nameW + ((i-1)*colW), currentY, colW, completed and "done" or "bad")
        end
        currentY = currentY - 24
    end

    -- Spark of Radiance (item count / global cap)
    if civ.sparkRadiance ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        local sparkCap = GetGlobalSparkCap()
        DrawText("Spark of Radiance", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local d = EnrageDB[char]
            local total = d and (d.sparkTotalEarned or d.sparkCount) or 0
            local sparkColor = (total >= sparkCap) and "|cff00FF00" or "|cffFFFF00"
            DrawText(sparkColor .. total .. "/" .. sparkCap .. "|r", nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
        end
        currentY = currentY - 24
    end

    -- Hunt (weekly progress)
    if civ.hunt ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Hunt", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local progress = (EnrageDB[char] and EnrageDB[char].huntProgress) or "-"
            local pNum, pMax = progress:match("(%d+)/(%d+)")
            local text = (pNum and pMax and pNum == pMax) and "|cff00FF00" .. progress .. "|r" or progress
            if progress == "-" then
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            else
                DrawText(text, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            end
        end
        currentY = currentY - 24
    end

    -- Coffer Key Shards (weekly 600 cap)
    if civ.cofferShards ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Coffer Key Shards", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local weekly = EnrageDB[char] and EnrageDB[char].cofferShardsWeekly or 0
            local cap = EnrageDB[char] and EnrageDB[char].cofferShardsWeeklyCap or 600
            local shardColor = (weekly >= cap) and "|cff00FF00" or "|cffFFFF00"
            DrawText(shardColor .. weekly .. "/" .. cap .. "|r", nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
        end
        currentY = currentY - 24

        -- Restored Coffer Keys
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Restored Coffer Keys", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local keys = EnrageDB[char] and EnrageDB[char].restoredCofferKeys or 0
            if keys > 0 then
                DrawStatusChip(tostring(keys), nameW + ((i-1)*colW), currentY, colW, "done")
            else
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            end
        end
        currentY = currentY - 24
    end

    -- Mythic+ Keystone
    if civ.keystone ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Mythic+ Key", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local level = EnrageDB[char] and EnrageDB[char].keystoneLevel or 0
            local dungeon = EnrageDB[char] and EnrageDB[char].keystoneDungeon
            if dungeon and level > 0 then
                -- Shorten dungeon name to fit
                local short = dungeon:gsub("'", ""):sub(1, 10)
                local keyColor = level >= 10 and "|cFFB794F6" or level >= 7 and "|cff0070DD" or "|cff1EFF00"
                DrawText(keyColor .. "+" .. level .. "|r " .. short, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            else
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            end
        end
        currentY = currentY - 24
    end

    -- Delve Bounty
    if civ.delveBounty ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Delve Bounty", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local completed = EnrageDB[char] and EnrageDB[char].delveBountyCompleted
            DrawStatusChip(completed and "Done" or "Open", nameW + ((i-1)*colW), currentY, colW, completed and "done" or "bad")
        end
        currentY = currentY - 24
    end

    -- Nemesis
    if civ.nemesis ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText("Nemesis", 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local completed = EnrageDB[char] and EnrageDB[char].nemesisCompleted
            DrawStatusChip(completed and "Done" or "Not Done", nameW + ((i-1)*colW), currentY, colW, completed and "done" or "bad")
        end
        currentY = currentY - 24
    end
    end -- charInfo collapsed
    DrawSectionEnd(startY, currentY, MATRIX_THEME.sections.charInfo)
    currentY = currentY - 8  -- gap between CHARACTER INFO and next section

    if #raidList > 0 then
        isAltRow = false
        local raidsStartY = currentY  -- save for full wrap
        DrawSectionHeader("raids", currentY, MATRIX_THEME.sections.raids, 16, nameW - 24)

        local raidToggle = GetSectionToggle("raids")
        raidToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        raidToggle:SetSize(gridW, 34)
        raidToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        raidToggle:Show()

        local DIFF_ORDER = { "LFR", "N", "H", "M" }
        local CELL_PAD = 12
        local BOX_GAP = 2

        if not secCol.raids then
        -- Draw LFR/N/H/M headers, vertically centered in the 34px header.
        local DIFF_HDR_COLORS = { LFR = "888888", N = "66FF66", H = "FF9933", M = "FF4D4D" }
        for i = 1, #visibleChars do
            local cellX = nameW + ((i-1) * colW)
            local boxW = math.floor((colW - CELL_PAD - BOX_GAP * 3) / 4)
            if boxW < 10 then boxW = 10 end
            local totalBoxW = boxW * 4 + BOX_GAP * 3
            local boxStartX = cellX + math.floor((colW - totalBoxW) / 2)
            for di, diff in ipairs(DIFF_ORDER) do
                local bx = boxStartX + (di - 1) * (boxW + BOX_GAP)
                local hdrColor = DIFF_HDR_COLORS[diff] or "AAAAAA"
                DrawText("|cFF" .. hdrColor .. diff .. "|r", bx, currentY - 11, boxW, "CENTER", "GameFontNormal")
            end
        end
        end -- raids header details

        currentY = currentY - 34

        if not secCol.raids then
        local DIFF_COLORS = {
            LFR = { border = {0.5, 0.5, 0.5}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
            N   = { border = {0.4, 1.0, 0.4}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
            H   = { border = {1.0, 0.6, 0.2}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
            M   = { border = {1.0, 0.3, 0.3}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
        }

        for _, itemName in ipairs(raidList) do
            DrawDataRow(currentY, 24, isAltRow)
            isAltRow = not isAltRow

            DrawText(itemName, 10, currentY - 6, nameW - 10, "LEFT")
            for i, char in ipairs(visibleChars) do
                local raidData = EnrageDB[char] and EnrageDB[char].raids and EnrageDB[char].raids[itemName]
                local cellX = nameW + ((i-1) * colW)

                if type(raidData) == "table" then
                    -- Draw difficulty boxes: up to 4 boxes side by side
                    local boxW = math.floor((colW - CELL_PAD - BOX_GAP * 3) / 4)
                    if boxW < 10 then boxW = 10 end
                    local totalBoxW = boxW * 4 + BOX_GAP * 3
                    local boxStartX = cellX + math.floor((colW - totalBoxW) / 2)

                    for di, diff in ipairs(DIFF_ORDER) do
                        local info = raidData[diff]
                        local bx = boxStartX + (di - 1) * (boxW + BOX_GAP)
                        local dc = DIFF_COLORS[diff]

                        -- Box vertically centered in 24px row (3px gap top + 18 box + 3px bottom)
                        local boxY = currentY - 3
                        local textY = currentY - 8  -- text vertically centered within 18px box
                        if info and info.killed > 0 then
                            local isFull = (info.killed == info.total and info.total > 0)
                            local bgColor = isFull and dc.full or dc.partial

                            DrawRect(bx, boxY, boxW, 18, bgColor[1], bgColor[2], bgColor[3], 0.62, "ARTWORK")
                            DrawRect(bx, boxY, boxW, 1, dc.border[1], dc.border[2], dc.border[3], 0.6, "OVERLAY")
                            DrawRect(bx, boxY - 17, boxW, 1, dc.border[1], dc.border[2], dc.border[3], 0.6, "OVERLAY")
                            local label = string.format("%d/%d", info.killed, info.total)
                            DrawText("|cFFFFFFFF" .. label .. "|r", bx, textY, boxW, "CENTER")
                        elseif info then
                            -- Lock exists but no kills; dim like an uninstanced row.
                            DrawRect(bx, boxY, boxW, 18, dc.empty[1], dc.empty[2], dc.empty[3], 0.42, "ARTWORK")
                            DrawText("|cFF555555" .. string.format("%d/%d", info.killed, info.total) .. "|r", bx, textY, boxW, "CENTER")
                        else
                            -- No instance lock for this difficulty
                            DrawRect(bx, boxY, boxW, 18, dc.empty[1], dc.empty[2], dc.empty[3], 0.42, "ARTWORK")
                            DrawText("|cFF555555" .. diff .. "|r", bx, textY, boxW, "CENTER")
                        end
                    end
                elseif type(raidData) == "string" then
                    -- Legacy string format fallback
                    DrawText(raidData, cellX, currentY - 6, colW, "CENTER")
                else
                    DrawDash(cellX, currentY - 6, colW)
                end
            end
            currentY = currentY - 24
        end
        end -- raids collapsed
        DrawSectionEnd(raidsStartY, currentY, MATRIX_THEME.sections.raids)
        currentY = currentY - 8  -- gap before next section
    end -- raidList

    if #dungeonList > 0 then
        isAltRow = false
        local dungStartY = currentY
        DrawSectionHeader("dungeons", currentY, MATRIX_THEME.sections.dungeons, 16, nameW - 24)

        local dungToggle = GetSectionToggle("dungeons")
        dungToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        dungToggle:SetSize(gridW, 34)
        dungToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        dungToggle:Show()
        currentY = currentY - 34

        if not secCol.dungeons then
        for _, itemName in ipairs(dungeonList) do
            DrawDataRow(currentY, 36, isAltRow)
            isAltRow = not isAltRow

            local bannerTexture = GetDungeonBanner(itemName)
            local bannerFormatted = string.format("|T%s:32:86:0:0|t", tostring(bannerTexture))
            DrawRect(6, currentY - 3, nameW - 14, 30, 0, 0, 0, 0.14, "ARTWORK")
            DrawText(bannerFormatted, 12, currentY - 2, 86, "CENTER")

            DrawText(itemName, 104, currentY - 12, nameW - 132, "LEFT")

            -- Direct teleport button on dungeon name area (only when this character knows the portal).
            local tpSpell, tpSpellID = GetDungeonTeleportSpell(itemName)
            if tpSpell and not InCombatLockdown() then
                local tpRemaining = Enrage_GetTeleportCooldownRemaining(tpSpellID, tpSpell)
                local tpBtn = GetOrCreateTeleportBtn(teleportSecureHost)
                tpBtn:SetSize(nameW - 10, 34)
                tpBtn:ClearAllPoints()
                tpBtn:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 4, currentY - 1)
                tpBtn.dungeonName = itemName
                tpBtn.spellDisplayName = tpSpell
                tpBtn.spellID = tpSpellID
                tpBtn.teleportCooldownRemaining = tpRemaining
                tpBtn:SetFrameLevel(ContentFrame:GetFrameLevel() + 10)
                local nameFs = ContentFrame.fsList[fsIdx - 1]  -- last drawn FontString = dungeon name
                if nameFs and tpBtn.portalIcon then
                    local textW = nameFs:GetStringWidth() or 80
                    local iconX = 100 + textW + 4
                    if tpRemaining > 0 then
                        iconX = math.min(iconX, nameW - 74)
                    end
                    tpBtn.portalIcon:ClearAllPoints()
                    tpBtn.portalIcon:SetPoint("LEFT", tpBtn, "LEFT", iconX, 4)
                    if tpBtn.cooldownText then
                        tpBtn.cooldownText:ClearAllPoints()
                        tpBtn.cooldownText:SetPoint("LEFT", tpBtn.portalIcon, "RIGHT", 4, 0)
                    end
                end
                Enrage_ApplyTeleportButtonState(tpBtn)
                tpBtn:Show()
            end

            for i, char in ipairs(visibleChars) do
                local d = EnrageDB[char] and EnrageDB[char].dungeons and EnrageDB[char].dungeons[itemName]
                local val = "|c" .. MATRIX_THEME.text.faint .. "-|r"

                if d then
                    local best = math.max(d.mplusBest or 0, d.mplus or 0)
                    local bestStr = "|c" .. MATRIX_THEME.text.faint .. "-|r"
                    if best > 0 then
                        local bColor = best >= 10 and "A335EE" or (best >= 7 and "0070DD" or "C0C0C0")
                        bestStr = string.format("|cff%s+%d|r", bColor, best)
                    end

                    local m0Str = "|c" .. MATRIX_THEME.text.faint .. "-|r"
                    if d.m0Progress ~= "0/0" then
                        local m0Color = d.isComplete and "00FF00" or "FF0000"
                        m0Str = string.format("|cff%s%s|r", m0Color, d.m0Progress)
                    end

                    val = bestStr .. "  " .. m0Str
                end

                DrawText(val, nameW + ((i-1)*colW), currentY - 12, colW, "CENTER")
            end
            currentY = currentY - 36
        end
        end -- dungeons collapsed
        DrawSectionEnd(dungStartY, currentY, MATRIX_THEME.sections.dungeons)
        currentY = currentY - 8  -- gap before next section
    end -- dungeonList

    if maxKeys > 0 then
        isAltRow = false
        local vaultStartY = currentY
        DrawSectionHeader("vault", currentY, MATRIX_THEME.sections.vault, 16, nameW - 24)

        local vaultToggle = GetSectionToggle("vault")
        vaultToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        vaultToggle:SetSize(gridW, 34)
        vaultToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        vaultToggle:Show()
        currentY = currentY - 34

        if not secCol.vault then
        for k = 1, maxKeys do
            DrawDataRow(currentY, 24, isAltRow)
            isAltRow = not isAltRow

            DrawText("Key #" .. k, 10, currentY - 6, nameW - 10, "LEFT")
            for i, char in ipairs(visibleChars) do
                local val = (EnrageDB[char] and EnrageDB[char].topKeys and EnrageDB[char].topKeys[k]) or "-"
                if val == "-" then
                    DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
                else
                    DrawText(val, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
                end
            end
            currentY = currentY - 24
        end
        end -- vault collapsed
        DrawSectionEnd(vaultStartY, currentY, MATRIX_THEME.sections.vault)
    end -- maxKeys

    local totalHeight = math.abs(currentY - startY)
    for _, bg in ipairs(colBgs) do bg:SetHeight(totalHeight) end
    for _, line in ipairs(vLines) do line:SetHeight(totalHeight) end

    -- Class-color column lines are intentionally omitted; section wraps provide enough structure.
    -- Combat-safe height update (secure children block SetHeight during combat)
    if not InCombatLockdown() then
        ContentFrame:SetHeight(totalHeight)
        local frameHeight = math.max(220, math.min(800, totalHeight + 36))
        if not TrackerFrame.enrageEmbeddedHost then
            TrackerFrame:SetHeight(frameHeight)
        end
    end
end

-- Refresh tracker after combat ends (in case it was opened during combat with skipped resize)
local combatEndFrame = CreateFrame("Frame")
combatEndFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
combatEndFrame:SetScript("OnEvent", function()
    Enrage_EnsureTeleportDriver()  -- self-heal if a combat-time /reload skipped it
    for _, frame in ipairs({ WVTrackerFrame, FilterMenu, EnrageSettingsFrame, ENRAGE_LOGS_FRAME, ENRAGE_LOG_EXPORT_FRAME }) do
        if frame and frame.enrageSoftHidden then
            Enrage_SafeHideFrame(frame)
        end
    end
    if WVTrackerFrame and Enrage_IsFrameOpen(WVTrackerFrame) then
        UpdateTrackerInfo()
    end
end)

SLASH_ENRAGE1 = "/akc"
SlashCmdList["ENRAGE"] = function()
    if ENRAGE_LOGS_FRAME and Enrage_IsFrameOpen(ENRAGE_LOGS_FRAME) then
        Enrage_SafeHideFrame(ENRAGE_LOGS_FRAME)
    elseif Enrage_IsFrameOpen(WVTrackerFrame) then
        Enrage_CloseMatrixPopups()
        Enrage_SafeHideFrame(WVTrackerFrame)
    elseif Enrage_ShowLogsWindow then
        Enrage_ShowLogsWindow("matrix")
    else
        RequestRaidInfo()
        C_MythicPlus.RequestRewards()
        C_MythicPlus.RequestMapInfo()
        C_Timer.After(0.5, function()
            UpdateTrackerInfo()
            Enrage_SafeShowFrame(WVTrackerFrame)
        end)
    end
end
