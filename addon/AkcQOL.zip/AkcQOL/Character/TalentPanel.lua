
local L = AkcQOL_L
local Theme = AkcQOL_Theme

local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local FONT_FACE = "Fonts\\FRIZQT__.TTF"

local FONT_FLAGS = "OUTLINE"

local PANEL_WIDTH = 190
local ROW_HEIGHT = 22
local HEADER_HEIGHT = 56
local ICON_SIZE = 16
local PLACEHOLDER_DUNGEON_ICON = 236222

-- Boss order per Season 2 dungeon (Encounter Journal order). pct = enemy
-- forces reached at that boss on the common route; nil until route data for
-- the season is available (the tooltip then lists the order only).
_G.AKCQOL_DUNGEON_ROUTE_DATA = {
    ["Altar of Fangs"] = {
        { boss = "Rav'i" },
        { boss = "The Writhing Coil" },
        { boss = "Zul'jan" },
    },
    ["Murder Row"] = {
        { boss = "Kystia Manaheart" },
        { boss = "Zaen Bladesorrow" },
        { boss = "Xathuux the Annihilator" },
        { boss = "Lithiel Cinderfury" },
    },
    ["Den of Nalorakk"] = {
        { boss = "The Hoardmonger" },
        { boss = "Sentinel of Winter" },
        { boss = "Nalorakk" },
    },
    ["The Blinding Vale"] = {
        { boss = "Lightblossom Trinity" },
        { boss = "Ikuzz the Light Hunter" },
        { boss = "Lightwarden Ruia" },
        { boss = "Ziekket" },
    },
    ["Voidscar Arena"] = {
        { boss = "Taz'Rah" },
        { boss = "Atroxus" },
        { boss = "Charonus" },
    },
    ["Kings' Rest"] = {
        { boss = "The Golden Serpent" },
        { boss = "Mchimba the Embalmer" },
        { boss = "The Council of Tribes" },
        { boss = "Dazar, The First King" },
    },
    ["Temple of Sethraliss"] = {
        { boss = "Adderis and Aspix" },
        { boss = "Merektha" },
        { boss = "Galvazzt" },
        { boss = "Avatar of Sethraliss" },
    },
    ["Ruby Life Pools"] = {
        { boss = "Melidrussa Chillworn" },
        { boss = "Kokia Blazehoof" },
        { boss = "Kyrakka and Erkhart Stormvein" },
    },
}
local lastLoadedKey = nil
local lastLoadTime = 0
local pendingLoadKey = nil
local pendingLoadString = nil
local lastLoadedString = nil

local smoothPos = { lx = nil, ly = nil, rx = nil, ry = nil }
local LERP_FACTOR = 0.30
local SNAP_DISTANCE = 40   -- past this the panel lands instead of easing

local MPLUS_COLOR = { 0.4, 0.85, 1.0 }
local RAID_COLOR = { 0.95, 0.55, 0.1 }

local DATA_SOURCES = {
    {
        key      = "wcl",
        label    = "WarcraftLogs",
        short    = "WCL",
        color    = { 0.95, 0.78, 0.20 },
        subtitle = function() return L["WarcraftLogs Top 100"] end,
        getBuilds = function(specID)
            return specID and AkcQOLWCLBuilds and AkcQOLWCLBuilds[specID] or nil
        end,
    },
    -- Archon kaynagi 2026-08-27'de kaldirildi: archon.gg bot korumasina gecti
    -- (her URL HTTP 403, ana sayfa dahil), veri tazelenemiyor. Eski veriyi
    -- guncelmis gibi gostermek yaniltici. Koruma kalkarsa buraya geri eklenir;
    -- cekici araclar/talent-guncelle/guncelle_archon.py'de duruyor.
}

local function GetSourceByKey(key)
    for _, src in ipairs(DATA_SOURCES) do
        if src.key == key then return src end
    end
    return DATA_SOURCES[1]
end

local SPEC_NAMES = {
    [71] = "Arms", [72] = "Fury", [73] = "Protection",
    [65] = "Holy", [66] = "Protection", [70] = "Retribution",
    [253] = "Beast Mastery", [254] = "Marksmanship", [255] = "Survival",
    [259] = "Assassination", [260] = "Outlaw", [261] = "Subtlety",
    [256] = "Discipline", [257] = "Holy", [258] = "Shadow",
    [250] = "Blood", [251] = "Frost", [252] = "Unholy",
    [262] = "Elemental", [263] = "Enhancement", [264] = "Restoration",
    [62] = "Arcane", [63] = "Fire", [64] = "Frost",
    [265] = "Affliction", [266] = "Demonology", [267] = "Destruction",
    [268] = "Brewmaster", [269] = "Windwalker", [270] = "Mistweaver",
    [102] = "Balance", [103] = "Feral", [104] = "Guardian", [105] = "Restoration",
    [577] = "Havoc", [581] = "Vengeance",
    [1467] = "Devastation", [1468] = "Preservation", [1473] = "Augmentation",
}

local leftPanel = nil
local rightPanel = nil
local leftRows = {}
local rightRows = {}
local trackedTalentFrame = nil

local function GetPlayerClassAndSpec()
    local _, className = UnitClass("player")
    local specIndex = GetSpecialization()
    local specID = specIndex and GetSpecializationInfo(specIndex) or nil
    return className, specID
end


-- Sekmenin GORUNEN adi spec'e gore degisir. Anahtar (src.short) DEGISMEZ --
-- kayitli ayarlar ve HUD ona bagli. Yalnizca ekranda yazan sey degisiyor.
local SPEC_SEKME_ADI = {
    [103] = "FERAL",          -- Feral Druid: ilk 100'de en cok kullanilan build
}

local function SourceDisplayShort(src)
    -- Sekmede her spec KENDI adini gorur (kullanici istegi 2026-08-28):
    -- Feral'de FERAL, Guardian'da GUARDIAN, Arcane'de ARCANE...
    -- SPEC_SEKME_ADI ozel adlar icindir ve ayni zamanda SourceSubtitle'a
    -- "bu spec'te veri en-cok-kullanilan kuralıyla secildi" bilgisini verir.
    local _, specID = GetPlayerClassAndSpec()
    if specID and SPEC_SEKME_ADI[specID] then
        return SPEC_SEKME_ADI[specID]
    end
    local ad = specID and SPEC_NAMES[specID]
    if ad then
        return string.upper(ad)
    end
    return (src and src.short) or "WCL"
end

-- Alt yazi: HER spec icin ayni kural (2026-08-28) -- ilk 100 icinde EN COK
-- KULLANILAN build. Top-1 donemi kapandi; kural yine spec'e gore ayrisacaksa
-- burasi ve guncelle.py'deki adaylari_sec birlikte degismeli.
local function SourceSubtitle()
    return L["WarcraftLogs Top 100 (most used)"]
end

-- DATA_SOURCES yukarida tanimlandigi icin oradaki closure bu fonksiyonlari
-- goremezdi; alt yaziyi burada, hazir olduktan sonra baglıyoruz.
for _, _src in ipairs(DATA_SOURCES) do
    _src.subtitle = SourceSubtitle
end

local function GetBuildSourceKey(buildKey)
    local prefix = tostring(buildKey or ""):match("^([^:]+):")
    if not prefix then return nil end
    local lowerPrefix = string.lower(prefix)
    for _, source in ipairs(DATA_SOURCES) do
        if lowerPrefix == string.lower(source.key or "")
            or lowerPrefix == string.lower(source.short or "")
            or lowerPrefix == string.lower(source.label or "") then
            return source.key
        end
    end
    return nil
end

local function GetBuildKindFromKey(buildKey)
    local lowerKey = string.lower(tostring(buildKey or ""))
    if lowerKey == "" then return nil end

    if lowerKey:find("all dungeons", 1, true) or lowerKey:find("mplus", 1, true) or lowerKey:find("m+", 1, true) then
        return "mplus"
    end
    for _, dungeonName in ipairs(AkcQOLWCLDungeonList or {}) do
        if lowerKey:find(string.lower(dungeonName), 1, true) then
            return "mplus"
        end
    end

    if lowerKey:find("all bosses", 1, true) or lowerKey:find("raid", 1, true) then
        return "raid"
    end
    for _, bossName in ipairs(AkcQOLWCLBossList or {}) do
        if bossName:sub(1, 3) ~= "---" and lowerKey:find(string.lower(bossName), 1, true) then
            return "raid"
        end
    end

    return nil
end

local function SaveTalentPanelSourceForBuild(buildKey)
    if not AkcQOLDB or not AkcQOLDB.global then return end
    local sourceKey = GetBuildSourceKey(buildKey)
    local kind = GetBuildKindFromKey(buildKey)
    if not sourceKey or not kind then return end
    if not AkcQOLDB.global.talentPanelSources then AkcQOLDB.global.talentPanelSources = {} end
    AkcQOLDB.global.talentPanelSources[kind] = sourceKey
end

local function PersistLastLoadedBuildKey(buildKey, specID, importString)
    buildKey = tostring(buildKey or "")
    if buildKey == "" then return end
    lastLoadedKey = buildKey
    -- The build's own string is remembered too, so every button carrying the
    -- same string can be shown as active -- not just the one that was clicked.
    if type(importString) == "string" and importString ~= "" then
        lastLoadedString = importString
    end
    _G.AkcQOL_LastLoadedBuild = buildKey
    if AkcQOLDB and AkcQOLDB.global then
        if not specID then
            local _, currentSpecID = GetPlayerClassAndSpec()
            specID = currentSpecID
        end
        AkcQOLDB.global.lastLoadedBuild = buildKey
        AkcQOLDB.global.lastLoadedBuildSpec = specID
        -- Never blank the saved string: a key-only persist (the login path
        -- does exactly that) would otherwise erase what the siblings need.
        if lastLoadedString and lastLoadedString ~= "" then
            AkcQOLDB.global.lastLoadedBuildStr = lastLoadedString
        end
        SaveTalentPanelSourceForBuild(buildKey)
    end
end

local function ClearLastLoadedBuildKey()
    lastLoadedKey = nil
    lastLoadedString = nil
    _G.AkcQOL_LastLoadedBuild = nil
    if AkcQOLDB and AkcQOLDB.global then
        AkcQOLDB.global.lastLoadedBuild = nil
        AkcQOLDB.global.lastLoadedBuildSpec = nil
        AkcQOLDB.global.lastLoadedBuildStr = nil
    end
end

local function GetCurrentTalentString()
    local str = ""
    pcall(function()
        local configID = C_ClassTalents.GetActiveConfigID()
        if configID then
            str = C_Traits.GenerateImportString(configID) or ""
        end
    end)
    return str
end

local function RestoreLastLoadedBuildKey()
    local _, specID = GetPlayerClassAndSpec()

    -- Read the saved string first and on its own. It used to be read only as a
    -- side effect of looking the key up in the DB, and at login the key is
    -- already known from a global, so that branch never ran.
    if not lastLoadedString and AkcQOLDB and AkcQOLDB.global then
        local savedSpec = AkcQOLDB.global.lastLoadedBuildSpec
        if not savedSpec or tonumber(savedSpec) == tonumber(specID) then
            lastLoadedString = AkcQOLDB.global.lastLoadedBuildStr
        end
    end

    local key = lastLoadedKey

    if (not key or key == "") and _G.AkcQOL_LastLoadedBuild then
        key = _G.AkcQOL_LastLoadedBuild
    end

    if (not key or key == "") and AkcQOLDB and AkcQOLDB.global then
        local savedSpec = AkcQOLDB.global.lastLoadedBuildSpec
        if not savedSpec or tonumber(savedSpec) == tonumber(specID) then
            key = AkcQOLDB.global.lastLoadedBuild
            if not lastLoadedString then
                lastLoadedString = AkcQOLDB.global.lastLoadedBuildStr
            end
        end
    end

    key = tostring(key or "")
    if key ~= "" then
        PersistLastLoadedBuildKey(key, specID)
    end
    return key
end

local talentAlertFrame = nil
local lastTalentAlertKey = nil
local ignoredTalentAlertKey = nil
local talentAlertSessionMuted = false
local talentAlertPendingCombat = false

local TALENT_PROFILE_INFO = {
    mplus = {
        label = L["Dungeon"],
        color = MPLUS_COLOR,
        targetText = "M+ Dungeon",
        bodyText = L["You are in a dungeon, but current talents do not match AkcQOL M+ Dungeon builds."],
    },
    raid = {
        label = L["Raid"],
        color = RAID_COLOR,
        targetText = "Raid",
        bodyText = L["You are in a raid, but current talents do not match AkcQOL Raid builds."],
    },
}

local function NormalizeTalentImportString(value)
    value = tostring(value or "")
    value = value:gsub("%s+", "")
    return value
end

local function TalentStringsMatch(a, b)
    local left = NormalizeTalentImportString(a)
    local right = NormalizeTalentImportString(b)
    return left ~= "" and right ~= "" and left == right
end

local loadoutSignatureCache = {}
local sawImportExportMixin = false

-- The loadout parser lives in Blizzard_PlayerSpells, which is load-on-demand:
-- early in a session it is simply not there yet. Asking again every time is
-- what makes the difference -- LoadAddOn costs nothing once the addon is
-- loaded, while giving up after a single attempt left the panel unable to
-- recognise any build for the rest of the session.
local function GetImportExportMixin()
    local mixin = _G.ClassTalentImportExportMixin
    if not mixin then
        if C_AddOns and C_AddOns.LoadAddOn then
            pcall(C_AddOns.LoadAddOn, "Blizzard_PlayerSpells")
        end
        mixin = _G.ClassTalentImportExportMixin
    end
    if mixin and not sawImportExportMixin then
        -- First time it is available: anything decided before this point was
        -- decided without a parser, so throw that away and repaint.
        sawImportExportMixin = true
        wipe(loadoutSignatureCache)
        if RefreshAllPanels then C_Timer.After(0, RefreshAllPanels) end
    end
    return mixin
end

local function GetSignatureContext()
    local specID, treeID
    pcall(function()
        specID = PlayerUtil and PlayerUtil.GetCurrentSpecID and PlayerUtil.GetCurrentSpecID() or nil
        treeID = specID and C_ClassTalents.GetTraitTreeForSpec(specID) or nil
    end)
    if not specID or not treeID then return nil, nil end
    return specID, treeID
end

local function SignatureField(value)
    if value == nil then return "-" end
    return tostring(value)
end

local maxRankCache = {}

-- A node written at full rank may be encoded either way: implicitly, with
-- isPartiallyRanked false, or explicitly as "partially ranked" at exactly its
-- maximum. Blizzard's own reader resolves it as
--   ranksPurchased = isPartiallyRanked and partialRanksPurchased or maxRanks
-- so the same resolution is needed here, otherwise a guide's string and the
-- game's own export of the SAME talents produce different signatures.
local function GetNodeMaxRanks(treeID, nodeID)
    local perTree = maxRankCache[treeID]
    if not perTree then
        perTree = {}
        maxRankCache[treeID] = perTree
    end
    local cached = perTree[nodeID]
    if cached ~= nil then return cached end

    local configID = C_ClassTalents and C_ClassTalents.GetActiveConfigID and C_ClassTalents.GetActiveConfigID()
    if not configID then return nil end

    local ok, info = pcall(C_Traits.GetNodeInfo, configID, nodeID)
    if not (ok and type(info) == "table" and type(info.maxRanks) == "number") then
        -- Not remembered: a miss here means the config was not ready, and one
        -- side of a comparison resolving a full-rank node to a number while the
        -- other falls back to a placeholder would break the match for good.
        return nil
    end
    perTree[nodeID] = info.maxRanks
    return info.maxRanks
end

local function ComputeLoadoutSignature(normalized, specID, treeID)
    local mixin = GetImportExportMixin()
    if not mixin or not ExportUtil or not ExportUtil.MakeImportDataStream then return nil end

    local ok, signature = pcall(function()
        local stream = ExportUtil.MakeImportDataStream(normalized)
        if not stream then return nil end

        local headerValid, _, streamSpecID = mixin:ReadLoadoutHeader(stream)
        if not headerValid or streamSpecID ~= specID then return nil end

        local content = mixin:ReadLoadoutContent(stream, treeID)
        if type(content) ~= "table" then return nil end

        local nodeIDs = C_Traits.GetTreeNodes(treeID)
        local parts = {}
        for i, entry in ipairs(content) do
            local nodeID = nodeIDs and nodeIDs[i] or i
            local ranks
            if not entry.isNodeSelected then
                ranks = 0
            elseif entry.isNodeGranted then
                ranks = "g"
            elseif entry.isPartiallyRanked then
                ranks = entry.partialRanksPurchased
            else
                ranks = GetNodeMaxRanks(treeID, nodeID) or "max"
            end
            -- Non-choice nodes come back with selection 1; flattening them to 0
            -- keeps two spellings of the same node comparable.
            local choice = entry.isChoiceNode and entry.choiceNodeSelection or 0
            parts[#parts + 1] = nodeID .. ":" .. SignatureField(ranks) .. ":" .. SignatureField(choice)
        end
        if #parts == 0 then return nil end
        return table.concat(parts, "|")
    end)

    if not ok then return nil end
    return signature
end

-- Declared before GetKnownLoadoutSignature so the live loadout shares the
-- same memo: it used to be re-parsed from scratch for every button on every
-- repaint, dozens of full bit-stream walks per refresh.
local GetKnownLoadoutSignature

local function GetLoadoutSignature(importString)
    local normalized = NormalizeTalentImportString(importString)
    if normalized == "" then return nil end
    local specID, treeID = GetSignatureContext()
    if not specID then return nil end
    return GetKnownLoadoutSignature(normalized, specID, treeID)
end

function GetKnownLoadoutSignature(normalized, specID, treeID)
    -- specID belongs in the key: GetTraitTreeForSpec hands back the same
    -- class-wide tree for every spec, so treeID alone cannot tell them apart.
    local key = specID .. "#" .. treeID .. "#" .. normalized
    local cached = loadoutSignatureCache[key]
    if cached then return cached end
    -- Only successes are remembered. A failure here usually means the parser
    -- was not loaded yet, and remembering that would freeze the panel into
    -- never recognising this build again.
    local sig = ComputeLoadoutSignature(normalized, specID, treeID)
    if sig then loadoutSignatureCache[key] = sig end
    return sig
end

local function AddTalentImportValue(set, value)
    if type(value) == "string" then
        local normalized = NormalizeTalentImportString(value)
        if normalized ~= "" then
            set[normalized] = true
            return 1
        end
    elseif type(value) == "table" then
        local count = 0
        for _, child in pairs(value) do
            count = count + AddTalentImportValue(set, child)
        end
        return count
    end
    return 0
end

local function BuildKnownTalentSet(kind)
    local _, specID = GetPlayerClassAndSpec()
    local set, count = {}, 0
    for _, source in ipairs(DATA_SOURCES) do
        local builds = source.getBuilds(specID)
        if type(builds) == "table" then
            if kind == "mplus" then
                count = count + AddTalentImportValue(set, builds.mplus)
            elseif kind == "raid" then
                count = count + AddTalentImportValue(set, builds.raid)
                count = count + AddTalentImportValue(set, builds.bosses)
            end
        end
    end
    return set, count
end

local function GetBossNameForIndex(bossIdx)
    local count = 0
    for _, bossName in ipairs(AkcQOLWCLBossList or {}) do
        if bossName:sub(1, 3) ~= "---" then
            count = count + 1
            if count == bossIdx then return bossName end
        end
    end
    return nil
end

local function GetBossIndexForListPosition(list, idx)
    local bossIdx = 0
    for li = 1, idx do
        if not list[li] or list[li]:sub(1, 3) ~= "---" then
            bossIdx = bossIdx + 1
        end
    end
    return bossIdx
end

local function FindKnownBuildKeyByImport(kind, importString)
    local current = NormalizeTalentImportString(importString)
    if current == "" then return nil end

    local _, specID = GetPlayerClassAndSpec()
    local diffMap = { nm = "normal", hc = "heroic", mt = "mythic" }

    local sigSpecID, sigTreeID = GetSignatureContext()
    local currentSig = sigSpecID and ComputeLoadoutSignature(current, sigSpecID, sigTreeID) or nil

    local function Matches(value)
        if TalentStringsMatch(value, current) then return true end
        if not currentSig or type(value) ~= "string" then return false end
        local normalized = NormalizeTalentImportString(value)
        if normalized == "" then return false end
        return GetKnownLoadoutSignature(normalized, sigSpecID, sigTreeID) == currentSig
    end

    for _, source in ipairs(DATA_SOURCES) do
        local builds = source.getBuilds(specID)
        if type(builds) == "table" then
            local prefix = source.short or source.label or source.key

            if (not kind or kind == "mplus") and Matches(builds.mplus) then
                return prefix .. ":All Dungeons"
            end

            if not kind or kind == "raid" then
                if Matches(builds.raid) then
                    return prefix .. ":All Bosses"
                end
                if type(builds.bosses) == "table" then
                    for index, bossData in pairs(builds.bosses) do
                        local bossName = GetBossNameForIndex(index)
                        if bossName then
                            -- Fixed order: with pairs() the same string on
                            -- N/H/M returned an arbitrary one of the three.
                            for _, diff in ipairs({ "mt", "hc", "nm" }) do
                                local fullKey = diffMap[diff]
                                local candidate = type(bossData) == "table" and (bossData[fullKey] or bossData[diff]) or bossData
                                if Matches(candidate) then
                                    return prefix .. ":" .. bossName .. ":" .. diff
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return nil
end

local function ReconcileLastLoadedBuildFromCurrentTalents(kind, keepWhenUnknown)
    local current = NormalizeTalentImportString(GetCurrentTalentString())
    if current == "" then
        return keepWhenUnknown and RestoreLastLoadedBuildKey() or nil
    end

    local matchedKey = FindKnownBuildKeyByImport(kind, current)
    if matchedKey then
        local _, specID = GetPlayerClassAndSpec()
        PersistLastLoadedBuildKey(matchedKey, specID)
        return matchedKey
    end

    -- TRAIT_CONFIG_UPDATED fires during login, and it arrives with
    -- keepWhenUnknown = false. If the loadout parser is not up yet, "no match"
    -- only means "cannot tell yet" -- forgetting the build on the strength of
    -- that wiped the saved key every single login, which is why nothing was
    -- ever lit afterwards. A miss now only counts when the machinery could
    -- actually read the current loadout.
    local sigSpecID, sigTreeID = GetSignatureContext()
    local canDecide = sigSpecID ~= nil
        and GetImportExportMixin() ~= nil
        and ComputeLoadoutSignature(current, sigSpecID, sigTreeID) ~= nil

    if keepWhenUnknown or not canDecide then
        return RestoreLastLoadedBuildKey()
    end

    ClearLastLoadedBuildKey()
    return nil
end

local function CurrentTalentMatchesKnownBuild(kind)

    local current = NormalizeTalentImportString(GetCurrentTalentString())
    if current == "" then return true end

    local known, count = BuildKnownTalentSet(kind)
    if count == 0 then return true end
    if known[current] == true then return true end

    local currentSig = GetLoadoutSignature(current)
    if not currentSig then return false end
    local specID, treeID = GetSignatureContext()
    if not specID then return false end
    for knownString in pairs(known) do
        if GetKnownLoadoutSignature(knownString, specID, treeID) == currentSig then
            return true
        end
    end
    return false
end

local function GetExpectedTalentProfile()
    local inInstance, instanceType = IsInInstance()
    if not inInstance then return nil, instanceType end
    if instanceType == "party" then return "mplus", instanceType end
    if instanceType == "raid" then return "raid", instanceType end
    return nil, instanceType
end

local function CreateTalentAlertButton(parent, text, width)
    local button = CreateFrame("Button", nil, parent, "BackdropTemplate")
    button:SetSize(width or 120, 26)
    button:SetNormalFontObject(GameFontHighlightSmall)
    button:SetHighlightFontObject(GameFontHighlightSmall)
    button:SetDisabledFontObject(GameFontDisableSmall)
    button:SetText(text)
    Theme.SkinButton(button)
    local fs = button.GetFontString and button:GetFontString()
    if fs then
        local _, fsSize, fsFlags = fs:GetFont()
        Theme.SetFont(fs, fsSize or 11, fsFlags)
        if fs.SetTextColor then
            fs:SetTextColor(Theme.rgba(Theme.colors.text))
        end
    end
    return button
end

local function EnsureTalentAlertFrame()
    if talentAlertFrame then return talentAlertFrame end

    local frame = CreateFrame("Frame", "AkcQOLTalentProfileAlert", UIParent, "BackdropTemplate")
    frame:SetSize(450, 122)
    frame:SetPoint("TOP", UIParent, "TOP", 0, -300)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    Theme.ApplyBackdrop(frame, "window", { accentBorder = true })
    frame:Hide()

    local title = frame:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(title, 15, FONT_FLAGS, true)
    title:SetPoint("TOP", frame, "TOP", 0, -12)
    title:SetText(L["Talent Profile Warning"])
    title:SetTextColor(Theme.rgba(Theme.colors.warn))
    frame.title = title

    local close = CreateFrame("Button", nil, frame)
    close:SetSize(22, 22)
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -8)
    close:SetHitRectInsets(-2, -2, -2, -2)
    close.bg = close:CreateTexture(nil, "BACKGROUND")
    close.bg:SetTexture(FLAT_TEX)
    close.bg:SetAllPoints()
    close.bg:SetVertexColor(0.22, 0.05, 0.05, 0)
    close.text = close:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(close.text, 13, FONT_FLAGS, true)
    close.text:SetAllPoints()
    close.text:SetJustifyH("CENTER")
    close.text:SetJustifyV("MIDDLE")
    close.text:SetTextColor(Theme.rgba(Theme.colors.bad))
    close.text:SetText("X")
    close:SetScript("OnClick", function()
        ignoredTalentAlertKey = lastTalentAlertKey
        frame:Hide()
    end)
    close:SetScript("OnEnter", function(self)
        self.bg:SetVertexColor(0.34, 0.06, 0.06, 0.92)
        self.text:SetTextColor(1.00, 0.52, 0.48, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(L["Close this warning"], 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    close:SetScript("OnLeave", function(self)
        self.bg:SetVertexColor(0.22, 0.05, 0.05, 0)
        self.text:SetTextColor(Theme.rgba(Theme.colors.bad))
        GameTooltip:Hide()
    end)
    frame.close = close

    local body = frame:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(body, 12, "")
    body:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -42)
    body:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -42)
    body:SetJustifyH("CENTER")
    body:SetTextColor(Theme.rgba(Theme.colors.text))
    frame.body = body

    local open = CreateTalentAlertButton(frame, L["Open Builds"], 120)
    open:SetPoint("BOTTOM", frame, "BOTTOM", -128, 14)
    open:SetScript("OnClick", function()
        frame:Hide()
        if PlayerSpellsUtil and PlayerSpellsUtil.OpenToClassTalents then
            pcall(PlayerSpellsUtil.OpenToClassTalents)
        elseif PlayerSpellsFrame and ShowUIPanel then
            pcall(ShowUIPanel, PlayerSpellsFrame)
        elseif ToggleTalentFrame then
            pcall(ToggleTalentFrame)
        end
        C_Timer.After(0.5, function()
            if SlashCmdList and SlashCmdList["WVBUILDS"] and (not leftPanel or not leftPanel:IsShown()) then
                SlashCmdList["WVBUILDS"]()
            end
        end)
    end)
    frame.open = open

    local ignore = CreateTalentAlertButton(frame, L["Ignore"], 80)
    ignore:SetPoint("LEFT", open, "RIGHT", 8, 0)
    ignore:SetScript("OnClick", function()
        ignoredTalentAlertKey = lastTalentAlertKey
        frame:Hide()
    end)
    frame.ignore = ignore

    local mute = CreateTalentAlertButton(frame, L["Don't warn this session"], 160)
    mute:SetPoint("LEFT", ignore, "RIGHT", 8, 0)
    mute:SetScript("OnClick", function()
        talentAlertSessionMuted = true
        frame:Hide()
    end)
    frame.mute = mute

    talentAlertFrame = frame
    return frame
end

local function ShowTalentAlert(kind, instanceType)
    local info = TALENT_PROFILE_INFO[kind]
    if not info then return end

    local _, specID = GetPlayerClassAndSpec()
    local current = NormalizeTalentImportString(GetCurrentTalentString())
    local alertKey = tostring(kind) .. ":" .. tostring(instanceType or "") .. ":" .. tostring(specID or "") .. ":" .. current
    lastTalentAlertKey = alertKey
    if ignoredTalentAlertKey == alertKey then return end

    local frame = EnsureTalentAlertFrame()
    local color = info.color or { 1, 0.82, 0.2 }
    frame:SetBackdropBorderColor(color[1], color[2], color[3], 0.92)
    frame.title:SetText(string.format(L["%s Talent Warning"], info.label))
    frame.body:SetText(info.bodyText)
    frame:Show()
end

local function CheckTalentProfile(force)

    if not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.talentWarning == true) then
        if talentAlertFrame then talentAlertFrame:Hide() end
        return
    end
    if talentAlertSessionMuted then
        if talentAlertFrame then talentAlertFrame:Hide() end
        return
    end

    local expected, instanceType = GetExpectedTalentProfile()
    if not expected then
        if talentAlertFrame then talentAlertFrame:Hide() end
        return
    end

    if CurrentTalentMatchesKnownBuild(expected) then
        if talentAlertFrame then talentAlertFrame:Hide() end
        lastTalentAlertKey = nil
        return
    end

    local _, specID = GetPlayerClassAndSpec()
    local current = NormalizeTalentImportString(GetCurrentTalentString())
    local key = tostring(expected) .. ":" .. tostring(instanceType or "") .. ":" .. tostring(specID or "") .. ":" .. current
    if not force and (lastTalentAlertKey == key or ignoredTalentAlertKey == key) then return end

    if InCombatLockdown() or UnitAffectingCombat("player") or (IsEncounterInProgress and IsEncounterInProgress()) then
        talentAlertPendingCombat = true
        return
    end
    ShowTalentAlert(expected, instanceType)
end

_G.AkcQOL_CheckTalentProfile = CheckTalentProfile

local function ScheduleTalentProfileCheck(force, delay)
    C_Timer.After(delay or 1.0, function()
        CheckTalentProfile(force)
    end)
end

local originalTalentScale = nil
local appliedTalentScale = nil
local pendingTalentScale = nil

local talentCombatFrame = CreateFrame("Frame")
talentCombatFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
talentCombatFrame:SetScript("OnEvent", function()
    if pendingTalentScale and trackedTalentFrame then
        trackedTalentFrame:SetScale(pendingTalentScale)
        appliedTalentScale = pendingTalentScale
        pendingTalentScale = nil
    end
    if talentAlertPendingCombat then
        talentAlertPendingCombat = false
        ScheduleTalentProfileCheck(false, 1.5)
    end
end)

local function SafeSetTalentScale(scale)
    if InCombatLockdown() then
        pendingTalentScale = scale
    else
        trackedTalentFrame:SetScale(scale)
        appliedTalentScale = scale
        pendingTalentScale = nil
    end
end

local function ShowCopyPopup(importString)
    local popup = _G["WVT_ImportPopup"]
    if not popup then
        popup = CreateFrame("Frame", "WVT_ImportPopup", UIParent, "BackdropTemplate")
        popup:SetSize(420, 110)
        popup:SetPoint("CENTER")
        popup:SetFrameStrata("FULLSCREEN_DIALOG")
        Theme.ApplyWindow(popup)

        local title = popup:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(title, 11, FONT_FLAGS, true)
        title:SetPoint("TOP", 0, -14)
        title:SetText(Theme.Accent(L["Ctrl+C to copy"]) .. " |cFF888888\226\134\146 " .. L["Loadouts"] .. " \226\134\146 " .. L["Import"] .. " \226\134\146 Ctrl+V|r")
        Theme.StyleTitle(title)

        popup.editBox = CreateFrame("EditBox", nil, popup, "BackdropTemplate")
        popup.editBox:SetSize(370, 22)
        popup.editBox:SetPoint("CENTER", 0, -5)
        popup.editBox:SetAutoFocus(true)
        Theme.SetFont(popup.editBox, 10, FONT_FLAGS)
        popup.editBox:SetTextInsets(6, 6, 0, 0)
        Theme.ApplyBackdrop(popup.editBox, "inset")
        popup.editBox:SetScript("OnEscapePressed", function() popup:Hide() end)
        popup.editBox:SetScript("OnEnterPressed", function() popup:Hide() end)

        local hint = popup:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(hint, 10, FONT_FLAGS)
        hint:SetPoint("BOTTOM", 0, 14)
        hint:SetText("|cFF555555" .. L["Press ESC to close"] .. "|r")

        local closeBtn = CreateFrame("Button", nil, popup, "UIPanelCloseButton")
        closeBtn:SetPoint("TOPRIGHT", -2, -2)
    end

    popup.editBox:SetText(importString)
    popup.editBox:HighlightText()
    popup:Show()
    C_Timer.After(15, function() if popup:IsShown() then popup:Hide() end end)
end

local function GetTalentsFrame()
    if not PlayerSpellsFrame then return nil end
    return PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
end

local function ImportTalentBuild(importString, buildKey)
    if not importString or importString == "" then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Talent import string is empty."])
        return
    end

    if InCombatLockdown() then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Cannot load talent builds while in combat."])
        return
    end

    local talentsFrame = GetTalentsFrame()
    if not talentsFrame then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Open the talent window before loading a build."])
        return
    end

    local configID = C_ClassTalents.GetActiveConfigID()
    if not configID then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Could not read the active talent config."])
        return
    end

    local specID = PlayerUtil.GetCurrentSpecID()
    local treeID = C_ClassTalents.GetTraitTreeForSpec(specID)
    if not treeID then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Could not read the current talent tree."])
        return
    end

    local importStream = ExportUtil.MakeImportDataStream(importString)
    if not importStream then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Could not parse the talent import string."])
        ShowCopyPopup(importString)
        return
    end

    local headerValid, _, streamSpecID, _
    local ok1 = pcall(function()
        headerValid, _, streamSpecID, _ = talentsFrame:ReadLoadoutHeader(importStream)
    end)

    if not ok1 or not headerValid then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Invalid talent import string."])
        ShowCopyPopup(importString)
        return
    end

    if streamSpecID ~= specID then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["This build is for a different spec. Expected %s, got %s."], tostring(specID), tostring(streamSpecID or "?")))
        return
    end

    -- The game refuses a commit that would change nothing, which the old code
    -- reported as a failure. Clicking a boss whose build matches what you are
    -- already running should simply move the selection there.
    if TalentStringsMatch(importString, GetCurrentTalentString()) then
        PersistLastLoadedBuildKey(buildKey, nil, importString)
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["This build is already active: %s."], tostring(buildKey or L["Build"])))
        C_Timer.After(0.1, RefreshAllPanels)
        return
    end

    local loadoutContent
    local ok2 = pcall(function()
        loadoutContent = talentsFrame:ReadLoadoutContent(importStream, treeID)
    end)

    if not ok2 or not loadoutContent then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Could not read talent build content."])
        ShowCopyPopup(importString)
        return
    end

    local loadoutEntryInfo
    local ok3 = pcall(function()
        loadoutEntryInfo = talentsFrame:ConvertToImportLoadoutEntryInfo(configID, treeID, loadoutContent)
    end)

    if not ok3 or not loadoutEntryInfo then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Could not convert talent build."])
        ShowCopyPopup(importString)
        return
    end

    local nodeOrder = {}
    pcall(function()
        for _, nodeID in pairs(C_Traits.GetTreeNodes(treeID)) do
            local nodeInfo = C_Traits.GetNodeInfo(configID, nodeID)
            if nodeInfo then
                if nodeInfo.subTreeID then
                    nodeOrder[nodeID] = 1e9 + nodeInfo.posY * 10000 + nodeInfo.posX
                elseif nodeInfo.isVisible then
                    nodeOrder[nodeID] = nodeInfo.posY * 10000 + nodeInfo.posX
                end
            end
        end
    end)

    table.sort(loadoutEntryInfo, function(a, b)
        return (nodeOrder[a.nodeID] or 3e9) < (nodeOrder[b.nodeID] or 3e9)
    end)

    pcall(function()
        if C_ClassTalents.GetStarterBuildActive() then
            C_ClassTalents.SetStarterBuildActive(false)
        end
    end)

    C_Traits.ResetTree(configID, treeID)

    local errorCount = 0
    for _, entry in ipairs(loadoutEntryInfo) do
        local nodeInfo = C_Traits.GetNodeInfo(configID, entry.nodeID)
        if nodeInfo then
            local result = true
            if nodeInfo.type == Enum.TraitNodeType.Single or nodeInfo.type == Enum.TraitNodeType.Tiered then
                for rank = 1, (entry.ranksPurchased or 1) do
                    result = C_Traits.PurchaseRank(configID, entry.nodeID)
                    if not result then break end
                end
            else
                result = C_Traits.SetSelection(configID, entry.nodeID, entry.selectionEntryID)
            end
            if not result then errorCount = errorCount + 1 end
        end
    end

    pendingLoadKey = buildKey
    pendingLoadString = importString
    lastLoadTime = GetTime()

    local commitOk, commitStarted = pcall(C_ClassTalents.CommitConfig, configID)
    if not commitOk or commitStarted == false then
        pendingLoadKey = nil
        -- A refused commit usually means the tree already looks like the
        -- requested build; that is a no-op, not an error.
        if TalentStringsMatch(importString, GetCurrentTalentString()) then
            PersistLastLoadedBuildKey(buildKey, nil, importString)
            print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["This build is already active: %s."], tostring(buildKey or L["Build"])))
        else
            print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["Could not commit talent build: %s."], tostring(buildKey or L["Build"])))
        end
        C_Timer.After(0.5, RefreshAllPanels)
        return
    end

    if errorCount > 0 then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["Build load started: %s (%d node(s) skipped)."], tostring(buildKey or L["Build"]), errorCount))
    else
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["Build load started: %s."], tostring(buildKey or L["Build"])))
    end

    C_Timer.After(0.5, RefreshAllPanels)
    C_Timer.After(2.0, RefreshAllPanels)
    C_Timer.After(4.0, RefreshAllPanels)
end

-- The remembered key ("WCL:All Dungeons", "Archon:<boss>:mt", ...) is turned
-- back into the build string it points at. Learning the string from the row
-- while it is drawn was not enough: the row only exists on the tab that
-- happens to be open, so a build loaded from WarcraftLogs left the Archon tab
-- with nothing to compare against (and a key restored from a previous session
-- had no string at all).
local DIFF_SUFFIX_TO_FIELD = { nm = "normal", hc = "heroic", mt = "mythic" }

local function ResolveStringForKey(key)
    if type(key) ~= "string" or key == "" then return nil end

    local sourceShort, rest = key:match("^([^:]+):(.+)$")
    if not sourceShort or not rest then return nil end

    local source
    for _, src in ipairs(DATA_SOURCES) do
        if (src.short or src.key) == sourceShort then source = src break end
    end
    if not source then return nil end

    local _, specID = GetPlayerClassAndSpec()
    local builds = specID and source.getBuilds(specID)
    if type(builds) ~= "table" then return nil end

    if rest == "All Dungeons" then return builds.mplus end
    if rest == "All Bosses" then return builds.raid end

    local bossName, diff = rest:match("^(.+):([^:]+)$")
    if not bossName then return nil end
    local field = DIFF_SUFFIX_TO_FIELD[diff] or diff
    if type(builds.bosses) ~= "table" then return nil end

    for index, bossData in pairs(builds.bosses) do
        if GetBossNameForIndex(index) == bossName then
            if type(bossData) == "table" then
                return bossData[field] or bossData[diff]
            end
            return bossData
        end
    end
    return nil
end

local function ActiveBuildString()
    if lastLoadedString and lastLoadedString ~= "" then return lastLoadedString end
    if not lastLoadedKey then return nil end
    local resolved = ResolveStringForKey(lastLoadedKey)
    if type(resolved) == "string" and resolved ~= "" then
        lastLoadedString = resolved
        if AkcQOLDB and AkcQOLDB.global then
            AkcQOLDB.global.lastLoadedBuildStr = resolved
        end
        return resolved
    end
    return nil
end

-- Two builds can spell the same talents with different strings (WarcraftLogs
-- and Archon serialise them differently, and loading one makes the game
-- report whichever known build it recognises). So the comparison is on the
-- talents themselves: a signature computed from each import string.
local function ActiveBuildSignature()
    local activeStr = ActiveBuildString()
    if not activeStr then return nil end
    local specID, treeID = GetSignatureContext()
    if not specID then return nil end
    local normalized = NormalizeTalentImportString(activeStr)
    if normalized == "" then return nil end
    return GetKnownLoadoutSignature(normalized, specID, treeID), specID, treeID
end

local function IsActiveBuild(candidateStr, currentTalent, key)
    if key and lastLoadedKey == key then return true end
    if not candidateStr or candidateStr == "" then return false end

    local activeStr = ActiveBuildString()
    if activeStr and TalentStringsMatch(candidateStr, activeStr) then return true end

    local activeSig, sigSpecID, sigTreeID = ActiveBuildSignature()
    if activeSig then
        local normalized = NormalizeTalentImportString(candidateStr)
        if normalized ~= "" and GetKnownLoadoutSignature(normalized, sigSpecID, sigTreeID) == activeSig then
            return true
        end
    end
    if TalentStringsMatch(candidateStr, currentTalent) then return true end

    local currentSig = GetLoadoutSignature(currentTalent)
    if not currentSig then return false end
    local specID, treeID = GetSignatureContext()
    if not specID then return false end
    local normalized = NormalizeTalentImportString(candidateStr)
    if normalized == "" then return false end
    return GetKnownLoadoutSignature(normalized, specID, treeID) == currentSig
end

local bossPortraitCache = {}      -- normalized boss name -> { display = n } | { icon = tex }
local bossEncounterIndex = nil    -- normalized boss name -> journalEncounterID
local bossIndexScanAt = 0
local bossPortraitRetriesLeft = 3
local bossPortraitRepaintQueued = false
local MAX_EJ_ENCOUNTER_ID = 4000
local BOSS_INDEX_RETRY = 5

local BOSS_ICON_TEXCOORD = { 0.25, 0.75, 0, 0.95 }
local BOSS_FALLBACK_ICON = "Interface/EncounterJournal/UI-EJ-BOSS-Default"

-- WarcraftLogs writes the curly apostrophe (U+2019) where the client's own
-- database uses a plain one, so "Nek'zali" and "Nek’zali" never matched.
local function NormalizeBossName(name)
    if type(name) ~= "string" or name == "" then return nil end
    name = name:gsub("\226\128\153", "'")
    name = name:lower()
    name = name:gsub("[%p]", " ")
    name = name:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then return nil end
    return name
end

-- EJ_GetEncounterInfo(encounterID) is a plain database lookup: no selected
-- tier, no selected instance, no journal addon, no event. (Blizzard's own
-- world-map boss pins read portraits exactly this way.) So the index is built
-- straight from encounter IDs and never touches the player's journal.
local function BuildBossEncounterIndex()
    local index = {}
    if type(EJ_GetEncounterInfo) ~= "function" then return index end
    for encounterID = 1, MAX_EJ_ENCOUNTER_ID do
        local ok, name = pcall(EJ_GetEncounterInfo, encounterID)
        if ok and type(name) == "string" and name ~= "" then
            local key = NormalizeBossName(name)
            if key and index[key] == nil then
                index[key] = encounterID
                -- "Boss, Title of Something" is also stored under "boss".
                local short = NormalizeBossName(name:match("^([^,]+)") or "")
                if short and short ~= key and index[short] == nil then
                    index[short] = encounterID
                end
            end
        end
    end
    return index
end

local function QueueBossPortraitRepaint()
    if bossPortraitRepaintQueued or bossPortraitRetriesLeft <= 0 then return end
    if not C_Timer or not C_Timer.After then return end
    bossPortraitRepaintQueued = true
    bossPortraitRetriesLeft = bossPortraitRetriesLeft - 1
    C_Timer.After(BOSS_INDEX_RETRY + 1, function()
        bossPortraitRepaintQueued = false
        if type(RefreshAllPanels) == "function" then pcall(RefreshAllPanels) end
    end)
end

-- Returns displayID, iconTexture -- either may be nil.
local function GetBossPortrait(bossName)
    local key = NormalizeBossName(bossName)
    if not key then return nil, nil end

    local cached = bossPortraitCache[key]
    if cached then return cached.display, cached.icon end

    local now = (GetTime and GetTime()) or 0
    if bossEncounterIndex == nil or next(bossEncounterIndex) == nil then
        if bossEncounterIndex == nil or (now - bossIndexScanAt) >= BOSS_INDEX_RETRY then
            bossIndexScanAt = now
            bossEncounterIndex = BuildBossEncounterIndex()
            if next(bossEncounterIndex) == nil then QueueBossPortraitRepaint() end
        end
    end

    local encounterID = bossEncounterIndex and bossEncounterIndex[key]
    if not encounterID and bossEncounterIndex then
        for indexKey, id in pairs(bossEncounterIndex) do
            if #key >= 5 and (indexKey:find(key, 1, true) or key:find(indexKey, 1, true)) then
                encounterID = id
                break
            end
        end
    end
    if not encounterID or type(EJ_GetCreatureInfo) ~= "function" then return nil, nil end

    for c = 1, 9 do
        local ok, _, _, _, displayInfo, iconImage = pcall(EJ_GetCreatureInfo, c, encounterID)
        if not ok then break end
        if (displayInfo and displayInfo ~= 0) or (iconImage and iconImage ~= 0) then
            local entry = {
                display = (displayInfo and displayInfo ~= 0) and displayInfo or nil,
                icon = (iconImage and iconImage ~= 0) and iconImage or nil,
            }
            bossPortraitCache[key] = entry
            return entry.display, entry.icon
        end
    end
    return nil, nil
end

-- SetPortraitTextureFromCreatureDisplayID fills in asynchronously; Blizzard's
-- own consumers repaint on PORTRAITS_UPDATED, so do the same (once).
do
    local f = CreateFrame("Frame")
    f:RegisterEvent("PORTRAITS_UPDATED")
    f:SetScript("OnEvent", function()
        if type(RefreshAllPanels) == "function" then pcall(RefreshAllPanels) end
    end)
end

-- TEMP DIAG (remove before release): /akcbuildmatch
SLASH_AKCBUILDMATCH1 = "/akcbuildmatch"
SlashCmdList["AKCBUILDMATCH"] = function()
    local function say(fmt, ...) print("|cff8c5cffAkc|r|cffffffffQOL|r " .. string.format(fmt, ...)) end
    local _, specID = GetPlayerClassAndSpec()
    local current = GetCurrentTalentString()
    local sigSpecID, sigTreeID = GetSignatureContext()
    local currentSig = sigSpecID and ComputeLoadoutSignature(NormalizeTalentImportString(current), sigSpecID, sigTreeID) or nil

    local resolved = ActiveBuildString()
    say("ayristirici=%s (Blizzard_PlayerSpells=%s) tree=%s",
        _G.ClassTalentImportExportMixin and "VAR" or "YOK",
        (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("Blizzard_PlayerSpells")) and "yuklu" or "degil",
        tostring(sigTreeID))
    say("spec=%s key=%s str=%s cozulen=%s current=%d sig=%s", tostring(specID), tostring(lastLoadedKey),
        lastLoadedString and (#lastLoadedString .. " ch") or "yok",
        resolved and (#resolved .. " ch") or "yok",
        #tostring(current or ""), currentSig and "var" or "YOK")

    local function Head(str)
        if type(str) ~= "string" or str == "" then return "-" end
        return str:sub(1, 10) .. ".." .. #str
    end

    for _, source in ipairs(DATA_SOURCES) do
        local builds = source.getBuilds(specID)
        if type(builds) ~= "table" then
            say("%s: veri yok", source.short)
        else
            local function Report(label, str)
                if type(str) ~= "string" or str == "" then return end
                local sameStr = resolved and TalentStringsMatch(str, resolved) or false
                local activeSig, aSpec, aTree = ActiveBuildSignature()
                local sameBuild = false
                if activeSig then
                    sameBuild = GetKnownLoadoutSignature(NormalizeTalentImportString(str), aSpec, aTree) == activeSig
                end
                local sigOk = false
                if currentSig then
                    sigOk = GetKnownLoadoutSignature(NormalizeTalentImportString(str), sigSpecID, sigTreeID) == currentSig
                end
                say("  %-8s %-18s %s dizeAyni=%s ayniBuild=%s sigAyni=%s", source.short, label, Head(str),
                    tostring(sameStr), tostring(sameBuild), tostring(sigOk))
            end
            Report("mplus", builds.mplus)
            Report("raid", builds.raid)
            if type(builds.bosses) == "table" then
                for i = 1, 3 do
                    local b = builds.bosses[i]
                    if type(b) == "table" then
                        Report("boss" .. i .. ".mythic", b.mythic)
                    end
                end
            end
        end
    end
end

local function CreateWCLSidePanel(panelName, titleStr, titleColor, sourceSettingKey)
    local panel = CreateFrame("Frame", panelName, UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, 700)
    panel:SetFrameStrata("HIGH")
    panel:SetFrameLevel(100)
    -- No engine clamp: this frame's position is rewritten by
    -- UpdateLeftPanelPosition/UpdateRightPanelPosition on every frame, and the
    -- clamp would shove it back inside between two of those writes -- the two
    -- then fight and the panel visibly jumps. The bounds are applied in that
    -- maths instead.
    panel:EnableMouse(true)
    panel.sourceSettingKey = sourceSettingKey

    Theme.ApplyWindow(panel)

    panel.dataSource = "wcl"
    panel.tabs = {}

    local headerBg = panel:CreateTexture(nil, "BORDER")
    headerBg:SetTexture(FLAT_TEX)
    headerBg:SetVertexColor(Theme.colors.header[1], Theme.colors.header[2], Theme.colors.header[3], 0.85)
    headerBg:SetPoint("TOPLEFT", 1, -3)
    headerBg:SetPoint("TOPRIGHT", -1, -3)
    headerBg:SetHeight(HEADER_HEIGHT - 4)

    local headerSep = panel:CreateTexture(nil, "ARTWORK")
    headerSep:SetTexture(FLAT_TEX)
    headerSep:SetVertexColor(Theme.rgba(Theme.colors.border))
    headerSep:SetPoint("TOPLEFT", 4, -(HEADER_HEIGHT - 1))
    headerSep:SetPoint("TOPRIGHT", -4, -(HEADER_HEIGHT - 1))
    headerSep:SetHeight(1)

    local titleText = panel:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(titleText, 15, "", true)
    titleText:SetPoint("TOP", panel, "TOP", 0, -8)
    titleText:SetJustifyH("CENTER")
    titleText:SetText(titleStr)

    local tabBar = CreateFrame("Frame", nil, panel)
    tabBar:SetPoint("TOP", titleText, "BOTTOM", 0, -7)
    tabBar:SetHeight(22)

    local tabGap = 18

    local function StyleTab(tab, isActive)
        local s = tab.source.color
        if isActive then
            tab.label:SetTextColor(math.min(1, s[1]*1.15), math.min(1, s[2]*1.15), math.min(1, s[3]*1.15), 1)
            tab.underline:SetVertexColor(s[1], s[2], s[3], 1.0)
            tab.underline:Show()
        else
            tab.label:SetTextColor(0.58, 0.58, 0.64, 1)
            tab.underline:Hide()
        end
    end

    local prevTab, totalW = nil, 0
    for idx, src in ipairs(DATA_SOURCES) do
        local tab = CreateFrame("Button", nil, tabBar)
        tab.source = src
        tab:SetHeight(22)

        tab.label = tab:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(tab.label, 15, "", true)
        tab.label:SetPoint("CENTER", 0, 1)
        tab.label:SetText(SourceDisplayShort(src))

        local lw = math.max(28, math.ceil(tab.label:GetStringWidth()) + 8)
        tab:SetWidth(lw)

        tab.underline = tab:CreateTexture(nil, "OVERLAY")
        tab.underline:SetTexture(FLAT_TEX)
        tab.underline:SetHeight(2)
        tab.underline:SetPoint("BOTTOMLEFT", tab.label, "BOTTOMLEFT", -1, -3)
        tab.underline:SetPoint("BOTTOMRIGHT", tab.label, "BOTTOMRIGHT", 1, -3)

        if prevTab then
            tab:SetPoint("LEFT", prevTab, "RIGHT", tabGap, 0)
            totalW = totalW + tabGap + lw
        else
            tab:SetPoint("LEFT", 0, 0)
            totalW = lw
        end
        prevTab = tab

        tab:SetScript("OnEnter", function(self)
            if panel.dataSource ~= self.source.key then
                local c = self.source.color
                self.label:SetTextColor(c[1]*0.95, c[2]*0.95, c[3]*0.95, 1)
                self.underline:SetVertexColor(c[1], c[2], c[3], 0.4)
                self.underline:Show()
            end
        end)
        tab:SetScript("OnLeave", function(self)
            StyleTab(self, panel.dataSource == self.source.key)
        end)
        tab:SetScript("OnClick", function(self)
            if panel.dataSource == self.source.key then return end
            if panel.SetDataSourceKey then
                panel:SetDataSourceKey(self.source.key, true)
            end
            if _G.WVT_RefreshBuilds then _G.WVT_RefreshBuilds() end
        end)

        StyleTab(tab, idx == 1)
        panel.tabs[idx] = tab
    end
    tabBar:SetWidth(totalW)
    panel.tabBar = tabBar

    -- Spec degisince sekme adi ("WCL" <-> "FERAL") ve genisligi yenilenmeli.
    -- Sekmeler panel kurulurken bir kez yaratiliyor; bu yuzden ad statik
    -- kalirsa spec degistiginde eski ad ekranda kalir.
    function panel:RefreshTabLabels()
        local w, prev = 0, nil
        for _, tab in ipairs(self.tabs or {}) do
            tab.label:SetText(SourceDisplayShort(tab.source))
            local lw = math.max(28, math.ceil(tab.label:GetStringWidth()) + 8)
            tab:SetWidth(lw)
            tab:ClearAllPoints()
            if prev then
                tab:SetPoint("LEFT", prev, "RIGHT", tabGap, 0)
                w = w + tabGap + lw
            else
                tab:SetPoint("LEFT", 0, 0)
                w = lw
            end
            prev = tab
        end
        if self.tabBar then self.tabBar:SetWidth(w) end
    end

    function panel:SetDataSourceKey(sourceKey, shouldSave)
        local source = GetSourceByKey(sourceKey or "wcl")
        self.dataSource = source.key
        for _, tab in ipairs(self.tabs or {}) do
            StyleTab(tab, self.dataSource == tab.source.key)
        end
        if self.subLabel then

            self.subLabel:SetText("|cFF888888\194\183 " .. SourceDisplayShort(source) .. "|r")
        end
        if shouldSave and AkcQOLDB and AkcQOLDB.global and self.sourceSettingKey then
            if not AkcQOLDB.global.talentPanelSources then AkcQOLDB.global.talentPanelSources = {} end
            AkcQOLDB.global.talentPanelSources[self.sourceSettingKey] = source.key
        end
    end

    local scrollArea = CreateFrame("Frame", nil, panel)
    scrollArea:SetPoint("TOPLEFT", 6, -HEADER_HEIGHT)
    scrollArea:SetPoint("BOTTOMRIGHT", -6, 6)
    scrollArea:EnableMouseWheel(true)
    scrollArea:SetClipsChildren(true)
    panel.scrollArea = scrollArea

    local rows = {}
    for i = 1, 14 do

        local row = CreateFrame("Button", nil, scrollArea, "BackdropTemplate")
        row:SetHeight(ROW_HEIGHT)
        row:SetPoint("TOPLEFT", 0, -((i - 1) * (ROW_HEIGHT + 1)))
        row:SetPoint("TOPRIGHT", 0, -((i - 1) * (ROW_HEIGHT + 1)))

        row:SetBackdrop({
            bgFile = FLAT_TEX,
            edgeFile = FLAT_TEX,
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        row:SetBackdropColor(Theme.rgba(Theme.colors.rowBg))
        row:SetBackdropBorderColor(Theme.rgba(Theme.colors.border))

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(ICON_SIZE, ICON_SIZE)
        icon:SetPoint("LEFT", 4, 0)
        icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

        local iconBg = row:CreateTexture(nil, "BACKGROUND")
        iconBg:SetSize(ICON_SIZE, ICON_SIZE)
        iconBg:SetPoint("CENTER", icon, "CENTER", 0, 0)
        iconBg:SetTexture(FLAT_TEX)
        iconBg:SetVertexColor(Theme.rgba(Theme.colors.panelBg))

        local loadIcon = row:CreateTexture(nil, "OVERLAY")
        loadIcon:SetSize(12, 12)
        loadIcon:SetPoint("RIGHT", -7, 0)
        if pcall(loadIcon.SetAtlas, loadIcon, "common-icon-forwardarrow", false) then
            loadIcon:SetRotation(-1.5708)
        else

            loadIcon:SetTexture("Interface\\Buttons\\Arrow-Down-Up")
            loadIcon:SetTexCoord(0, 1, 0, 0.5)
        end

        local nameText = row:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(nameText, 11, "")
        nameText:SetPoint("LEFT", icon, "RIGHT", 5, 0)
        nameText:SetPoint("RIGHT", loadIcon, "LEFT", -4, 0)
        nameText:SetJustifyH("LEFT")
        nameText:SetJustifyV("MIDDLE")
        nameText:SetWordWrap(false)

        local function CreateDiffBtn(parent)
            local btn = CreateFrame("Button", nil, parent)
            btn:SetSize(18, 16)

            local border = btn:CreateTexture(nil, "BACKGROUND")
            border:SetAllPoints()
            border:SetTexture(FLAT_TEX)
            border:SetVertexColor(Theme.rgba(Theme.colors.border))
            btn.border = border

            local bg = btn:CreateTexture(nil, "ARTWORK")
            bg:SetPoint("TOPLEFT", 1, -1)
            bg:SetPoint("BOTTOMRIGHT", -1, 1)
            bg:SetTexture(FLAT_TEX)
            bg:SetVertexColor(Theme.rgba(Theme.colors.panelBg))
            btn.bg = bg

            local text = btn:CreateFontString(nil, "OVERLAY")
            Theme.SetFont(text, 10, "")
            text:SetPoint("CENTER", 0, 0)
            btn.label = text

            btn:SetScript("OnEnter", function(self)
                if self:IsEnabled() then
                    bg:SetVertexColor(Theme.rgba(Theme.colors.rowHover))
                    border:SetVertexColor(Theme.rgba(Theme.colors.borderLight))
                end
            end)
            btn:SetScript("OnLeave", function(self)

                local rb = self.__restBg
                local rbd = self.__restBorder
                if rb then bg:SetVertexColor(rb[1], rb[2], rb[3], rb[4]) end
                if rbd then border:SetVertexColor(rbd[1], rbd[2], rbd[3], rbd[4]) end
            end)

            btn:Hide()
            return btn
        end

        local PILL_W = 18
        local PILL_GAP = 2

        local mtBtn = CreateDiffBtn(row)
        mtBtn:SetPoint("RIGHT", -6, 0)

        local hcBtn = CreateDiffBtn(row)
        hcBtn:SetPoint("RIGHT", mtBtn, "LEFT", -PILL_GAP, 0)

        local nmBtn = CreateDiffBtn(row)
        nmBtn:SetPoint("RIGHT", hcBtn, "LEFT", -PILL_GAP, 0)

        nmBtn:SetWidth(PILL_W); hcBtn:SetWidth(PILL_W); mtBtn:SetWidth(PILL_W)

        row:EnableMouse(true)
        row:SetScript("OnEnter", function(self)
            self:SetBackdropColor(Theme.rgba(Theme.colors.rowHover))
            self:SetBackdropBorderColor(Theme.rgba(Theme.colors.borderLight))
        end)
        row:SetScript("OnLeave", function(self)
            self:SetBackdropColor(Theme.rgba(Theme.colors.rowBg))
            self:SetBackdropBorderColor(Theme.rgba(Theme.colors.border))
            GameTooltip:Hide()
        end)

        rows[i] = {
            frame = row,
            icon = icon,
            iconBg = iconBg,
            nameText = nameText,
            loadIcon = loadIcon,
            nmBtn = nmBtn,
            hcBtn = hcBtn,
            mtBtn = mtBtn,
        }
    end

    panel:Hide()
    return panel, rows
end

local DIFF_KEY_MAP = { nm = "normal", hc = "heroic", mt = "mythic" }
local function ResolveDifficultyStr(data, diff)
    if type(data) == "table" then
        local fullKey = DIFF_KEY_MAP[diff] or diff
        return data[fullKey] or data[diff] or ""
    elseif type(data) == "string" then
        return data
    end
    return ""
end

local DIFF_LABELS = { nm = "N", hc = "H", mt = "M" }
local DIFF_COLORS = {
    nm = { 0.35, 0.85, 0.45 },
    hc = { 0.35, 0.60, 1.00 },
    mt = { 0.66, 0.45, 1.00 },
}

local function SetupDiffBtn(btn, importStr, currentTalent, buildKey, diff)
    local str = ResolveDifficultyStr(importStr, diff)
    local key = buildKey .. ":" .. diff
    local c = DIFF_COLORS[diff] or { 1, 1, 1 }
    local letter = DIFF_LABELS[diff] or diff
    local restBg, restBorder
    if str ~= "" then
        if IsActiveBuild(str, currentTalent, key) then

            if btn.label then
                btn.label:SetText("|cFF101014" .. letter .. "|r")
            end
            restBg = { c[1], c[2], c[3], 0.95 }
            restBorder = { c[1], c[2], c[3], 1.0 }
        else

            if btn.label then
                btn.label:SetText(string.format("|cFF%02x%02x%02x%s|r", c[1]*255, c[2]*255, c[3]*255, letter))
            end
            restBg = { Theme.colors.panelBg[1], Theme.colors.panelBg[2], Theme.colors.panelBg[3], Theme.colors.panelBg[4] }
            restBorder = { c[1]*0.55, c[2]*0.55, c[3]*0.55, 0.9 }
        end
        btn:Enable()
        btn:SetScript("OnClick", function()
            ImportTalentBuild(str, key)
        end)
    else

        if btn.label then btn.label:SetText("|cFF555560" .. letter .. "|r") end
        restBg = { Theme.colors.insetBg[1], Theme.colors.insetBg[2], Theme.colors.insetBg[3], Theme.colors.insetBg[4] }
        restBorder = { Theme.colors.border[1], Theme.colors.border[2], Theme.colors.border[3], Theme.colors.border[4] }
        btn:Disable()
    end

    btn.__restBg = restBg
    btn.__restBorder = restBorder
    if btn.bg then btn.bg:SetVertexColor(restBg[1], restBg[2], restBg[3], restBg[4]) end
    if btn.border then btn.border:SetVertexColor(restBorder[1], restBorder[2], restBorder[3], restBorder[4]) end
    btn:Show()
end

local function ClampInt(v, lo, hi)
    v = math.floor(v + 0.5)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

local function FitPanelRows(panel)
    local rows = panel and panel.rowObjects
    local n = (panel and panel.shownRowCount) or 0
    if not rows or n <= 0 then return end
    local areaH = (panel.scrollArea and panel.scrollArea:GetHeight()) or 0
    if areaH <= 0 then return end

    local rowH = math.floor((areaH - (n - 1)) / n)
    if rowH < 22 then rowH = 22 end
    if rowH > 46 then rowH = 46 end

    local isRaid   = (panel.sourceSettingKey == "raid")
    local iconSize = isRaid and ClampInt(rowH - 6, 18, 42) or ClampInt(rowH - 10, 16, 32)
    local nameFont = isRaid and ClampInt(rowH * 0.30, 12, 15) or ClampInt(rowH * 0.40, 11, 16)
    local pillH    = ClampInt(rowH * 0.32, 13, 19)
    local pillW    = ClampInt(pillH + 6, 20, 26)
    local pillFont = ClampInt(pillH * 0.62, 10, 13)
    local loadSize = ClampInt(rowH * 0.42, 12, 20)

    local nameW    = math.max(40, PANEL_WIDTH - iconSize - 22)

    for i = 1, n do
        local r = rows[i]
        if r and r.frame then
            r.frame:ClearAllPoints()
            r.frame:SetPoint("TOPLEFT", 0, -((i - 1) * (rowH + 1)))
            r.frame:SetPoint("TOPRIGHT", 0, -((i - 1) * (rowH + 1)))
            r.frame:SetHeight(rowH)

            if r.icon then r.icon:SetSize(iconSize, iconSize) end
            if r.iconBg then r.iconBg:SetSize(iconSize, iconSize) end
            if r.nameText then
                Theme.SetFont(r.nameText, nameFont, "")
                if isRaid then r.nameText:SetWidth(nameW) end
            end
            if r.loadIcon then r.loadIcon:SetSize(loadSize, loadSize) end
            for _, pill in ipairs({ r.nmBtn, r.hcBtn, r.mtBtn }) do
                if pill then
                    pill:SetSize(pillW, pillH)
                    if pill.label then Theme.SetFont(pill.label, pillFont, "") end
                end
            end
        end
    end
end

local STACK_ICON = 236682
local function SetRowIcon(r, fileID, coords)
    if fileID then
        r.icon:SetTexture(fileID)
        if coords then
            r.icon:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
        else
            r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        end
        r.icon:Show()
        r.iconBg:Hide()
    else

        r.icon:Hide()
        r.iconBg:Show()
    end
end

local function SetupRowLoad(r, importStr, currentTalent, key, srcColor)
    r.nmBtn:Hide(); r.hcBtn:Hide(); r.mtBtn:Hide()
    r.loadIcon:Show()

    r.nameText:SetPoint("RIGHT", r.loadIcon, "LEFT", -4, 0)
    if importStr ~= "" then
        if IsActiveBuild(importStr, currentTalent, key) then
            r.loadIcon:SetVertexColor(0.35, 0.85, 0.44, 1.0)
        else

            local c = srcColor or { 0.55, 0.36, 1.0 }
            r.loadIcon:SetVertexColor(c[1], c[2], c[3], 1.0)
        end
        r.frame:Enable()
        r.frame:SetScript("OnClick", function()
            ImportTalentBuild(importStr, key)
        end)
    else

        r.loadIcon:SetVertexColor(0.30, 0.30, 0.36, 0.7)
        r.frame:Disable()
        r.frame:SetScript("OnClick", nil)
    end
end

local function RefreshSidePanel(panel, rows, encounterList, buildType, color, scrollOffset)
    if not panel or not panel:IsShown() then return end

    local _, specID = GetPlayerClassAndSpec()
    local _, className = UnitClass("player")

    if panel.specLabel then
        local specName = specID and SPEC_NAMES[specID] or "?"
        local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
        local colorStr = classColor and classColor.colorStr or "FFFFFFFF"
        panel.specLabel:SetText("|c" .. colorStr .. specName .. "|r")
    end

    local activeSource = GetSourceByKey(panel.dataSource or "wcl")
    local sourceLabel = activeSource.short
    local wclBuilds = activeSource.getBuilds(specID) or {}
    local importStr = wclBuilds[buildType] or ""
    local currentTalent = GetCurrentTalentString()
    local isRaid = (buildType == "raid")

    local srcColor  = activeSource.color
    local restBg    = { srcColor[1], srcColor[2], srcColor[3], 0.12 }
    local hoverBg   = { srcColor[1], srcColor[2], srcColor[3], 0.26 }
    local sumBg     = { srcColor[1], srcColor[2], srcColor[3], 0.34 }
    local srcBorder = { srcColor[1] * 0.85, srcColor[2] * 0.85, srcColor[3] * 0.85, 0.95 }

    local allLabel = isRaid and "All Bosses" or "All Dungeons"
    local allKey = sourceLabel .. ":" .. allLabel

    if rows[1] then
        local r = rows[1]
        r.frame:ClearAllPoints()
        r.frame:SetPoint("TOPLEFT", 0, 0)
        r.frame:SetPoint("TOPRIGHT", 0, 0)
        r.frame:Show()

        r.frame:SetBackdropColor(sumBg[1], sumBg[2], sumBg[3], sumBg[4])
        r.frame:SetBackdropBorderColor(srcBorder[1], srcBorder[2], srcBorder[3], srcBorder[4])
        SetRowIcon(r, STACK_ICON)
        r.nameText:SetText(string.format("|cFF%02x%02x%02x%s|r", color[1]*255, color[2]*255, color[3]*255, L[allLabel]))

        if isRaid then

            r.loadIcon:Hide()

            r.nameText:ClearAllPoints()
            r.nameText:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 6, -1)
            r.nameText:SetJustifyH("LEFT")
            r.nmBtn:ClearAllPoints()
            r.nmBtn:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 6, 1)
            r.hcBtn:ClearAllPoints()
            r.hcBtn:SetPoint("LEFT", r.nmBtn, "RIGHT", 3, 0)
            r.mtBtn:ClearAllPoints()
            r.mtBtn:SetPoint("LEFT", r.hcBtn, "RIGHT", 3, 0)
            SetupDiffBtn(r.nmBtn, importStr, currentTalent, allKey, "nm")
            SetupDiffBtn(r.hcBtn, importStr, currentTalent, allKey, "hc")
            SetupDiffBtn(r.mtBtn, importStr, currentTalent, allKey, "mt")

            r.frame:SetScript("OnClick", nil)
        else

            SetupRowLoad(r, importStr, currentTalent, allKey, srcColor)
        end

        r.frame:SetScript("OnEnter", function(self)

            self:SetBackdropColor(sumBg[1], sumBg[2], sumBg[3], math.min(1, sumBg[4] + 0.1))
            self:SetBackdropBorderColor(srcBorder[1], srcBorder[2], srcBorder[3], 1)
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:AddLine(L[allLabel], color[1], color[2], color[3])
            GameTooltip:AddLine(type(activeSource.subtitle) == "function" and activeSource.subtitle() or activeSource.subtitle, 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        r.frame:SetScript("OnLeave", function(self)

            self:SetBackdropColor(sumBg[1], sumBg[2], sumBg[3], sumBg[4])
            self:SetBackdropBorderColor(srcBorder[1], srcBorder[2], srcBorder[3], srcBorder[4])
            GameTooltip:Hide()
        end)
    end

    local list = encounterList or {}
    for i = 2, 14 do
        local r = rows[i]
        local idx = (i - 1) + (scrollOffset or 0)
        if idx <= #list then
            local encounterName = list[idx]
            r.frame:ClearAllPoints()
            r.frame:SetPoint("TOPLEFT", 0, -((i - 1) * (ROW_HEIGHT + 1)))
            r.frame:SetPoint("TOPRIGHT", 0, -((i - 1) * (ROW_HEIGHT + 1)))
            r.frame:Show()

            local isSeparator = encounterName:sub(1, 3) == "---"
            if isSeparator then

                local raidName = encounterName:sub(4)

                r.nameText:ClearAllPoints()
                r.nameText:SetPoint("LEFT", r.frame, "LEFT", 6, 0)
                r.nameText:SetPoint("RIGHT", r.frame, "RIGHT", -6, 0)
                r.nameText:SetText("|cFFFFD100" .. raidName .. "|r")
                r.loadIcon:Hide()
                r.nmBtn:Hide(); r.hcBtn:Hide(); r.mtBtn:Hide()
                SetRowIcon(r, nil); r.icon:Hide(); r.iconBg:Hide()
                r.frame:Disable()
                r.frame:SetBackdropColor(Theme.rgba(Theme.colors.header))
                r.frame:SetBackdropBorderColor(Theme.rgba(Theme.colors.border))
                r.frame:SetScript("OnClick", nil)
                r.frame:SetScript("OnEnter", nil)
                r.frame:SetScript("OnLeave", nil)
            else

            r.frame:SetBackdropColor(restBg[1], restBg[2], restBg[3], restBg[4])
            r.frame:SetBackdropBorderColor(Theme.rgba(Theme.colors.border))

            r.nameText:SetPoint("LEFT", r.icon, "RIGHT", 5, 0)
            r.nameText:SetText("|cFFDCDCDC" .. encounterName .. "|r")

            if isRaid then

                local bossDisplay, bossIcon = GetBossPortrait(encounterName)
                if bossDisplay and SetPortraitTextureFromCreatureDisplayID then
                    r.icon:SetTexCoord(0, 1, 0, 1)
                    pcall(SetPortraitTextureFromCreatureDisplayID, r.icon, bossDisplay)
                    r.icon:Show()
                    r.iconBg:Hide()
                else
                    SetRowIcon(r, bossIcon or BOSS_FALLBACK_ICON, BOSS_ICON_TEXCOORD)
                end
                r.loadIcon:Hide()

                r.nameText:ClearAllPoints()
                r.nameText:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 6, -1)
                r.nameText:SetJustifyH("LEFT")
                r.nmBtn:ClearAllPoints()
                r.nmBtn:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 6, 1)
                r.hcBtn:ClearAllPoints()
                r.hcBtn:SetPoint("LEFT", r.nmBtn, "RIGHT", 3, 0)
                r.mtBtn:ClearAllPoints()
                r.mtBtn:SetPoint("LEFT", r.hcBtn, "RIGHT", 3, 0)

                local bossIdx = GetBossIndexForListPosition(list, idx)
                local bossData = nil
                if wclBuilds.bosses then
                    bossData = wclBuilds.bosses[bossIdx]
                end

                local rowData = bossData or importStr
                local bossKey = sourceLabel .. ":" .. encounterName

                SetupDiffBtn(r.nmBtn, rowData, currentTalent, bossKey, "nm")
                SetupDiffBtn(r.hcBtn, rowData, currentTalent, bossKey, "hc")
                SetupDiffBtn(r.mtBtn, rowData, currentTalent, bossKey, "mt")
                r.frame:SetScript("OnClick", nil)
            else

                SetRowIcon(r, _G.AkcQOL_GetDungeonIcon and _G.AkcQOL_GetDungeonIcon(encounterName) or PLACEHOLDER_DUNGEON_ICON)
                local rowKey = sourceLabel .. ":" .. encounterName
                SetupRowLoad(r, importStr, currentTalent, rowKey, srcColor)
            end

            r.frame:SetScript("OnEnter", function(self)
                self:SetBackdropColor(hoverBg[1], hoverBg[2], hoverBg[3], hoverBg[4])
                self:SetBackdropBorderColor(srcBorder[1], srcBorder[2], srcBorder[3], srcBorder[4])
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(encounterName, color[1], color[2], color[3])
                GameTooltip:AddLine(type(activeSource.subtitle) == "function" and activeSource.subtitle() or activeSource.subtitle, 0.7, 0.7, 0.7)

                local routeData = not isRaid and _G.AKCQOL_DUNGEON_ROUTE_DATA[encounterName]
                if routeData then
                    GameTooltip:AddLine(" ")
                    local hasPct = routeData[1] and type(routeData[1].pct) == "number"
                    GameTooltip:AddLine(hasPct and L["Route - Enemy Forces"] or L["Bosses"], 1, 0.82, 0)
                    local prevPct = 0
                    for bi, bossInfo in ipairs(routeData) do
                        local label = string.format("|cFFCCCCCC%d.|r %s", bi, bossInfo.boss)
                        if type(bossInfo.pct) == "number" then
                            local segment = bossInfo.pct - prevPct
                            local pctColor
                            if bossInfo.pct >= 100 then
                                pctColor = "|cFF00FF00"
                            elseif bossInfo.pct >= 50 then
                                pctColor = "|cFFFFFF00"
                            else
                                pctColor = "|cFFFF8800"
                            end
                            local segText = segment > 0 and string.format("  (+%.0f%%)", segment) or ""
                            GameTooltip:AddDoubleLine(label,
                                string.format("%s%.1f%%%s|r", pctColor, bossInfo.pct, "|cFF888888" .. segText .. "|r"),
                                1, 1, 1, 1, 1, 1)
                            prevPct = bossInfo.pct
                        else
                            GameTooltip:AddLine(label, 1, 1, 1)
                        end
                    end
                end
                GameTooltip:Show()
            end)
            r.frame:SetScript("OnLeave", function(self)
                self:SetBackdropColor(restBg[1], restBg[2], restBg[3], restBg[4])
                self:SetBackdropBorderColor(Theme.rgba(Theme.colors.border))
                GameTooltip:Hide()
            end)
            end
        else
            r.frame:Hide()
        end
    end
    panel.rowObjects = rows
    panel.shownRowCount = math.min(14, #(encounterList or {}) + 1)
    FitPanelRows(panel)
end

local function UpdateLeftPanelPosition()
    if not leftPanel or not leftPanel:IsShown() then return end
    if not trackedTalentFrame or not trackedTalentFrame:IsShown() then
        leftPanel:Hide()
        return
    end

    local panelScale = leftPanel:GetEffectiveScale()
    local scale = trackedTalentFrame:GetEffectiveScale()
    local ratio = scale / panelScale
    local left = trackedTalentFrame:GetLeft()
    local top = trackedTalentFrame:GetTop()
    local bottom = trackedTalentFrame:GetBottom()
    if not left or not top or not bottom then return end

    local targetX = (left * ratio) - PANEL_WIDTH - 2
    if targetX < 0 then targetX = 0 end
    local targetY = top * ratio
    local panelH = (top - bottom) * ratio

    if smoothPos.lx then
        local dx = targetX - smoothPos.lx
        local dy = targetY - smoothPos.ly
        if math.abs(dx) < 0.5 and math.abs(dy) < 0.5 then
            smoothPos.lx = targetX
            smoothPos.ly = targetY
        elseif math.abs(dx) > SNAP_DISTANCE or math.abs(dy) > SNAP_DISTANCE then
            -- Far behind: the window was dragged quickly or the target moved in
            -- one step. Easing across that distance is what reads as the panel
            -- flying across the screen, so it simply lands there.
            smoothPos.lx = targetX
            smoothPos.ly = targetY
        else
            smoothPos.lx = smoothPos.lx + dx * LERP_FACTOR
            smoothPos.ly = smoothPos.ly + dy * LERP_FACTOR
        end
    else
        smoothPos.lx = targetX
        smoothPos.ly = targetY
    end

    leftPanel:ClearAllPoints()
    leftPanel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", smoothPos.lx, smoothPos.ly)
    leftPanel:SetHeight(panelH)
    if leftPanel.lastFitH ~= panelH then
        leftPanel.lastFitH = panelH
        FitPanelRows(leftPanel)
    end
end

local function UpdateRightPanelPosition()
    if not rightPanel or not rightPanel:IsShown() then return end
    if not trackedTalentFrame or not trackedTalentFrame:IsShown() then
        rightPanel:Hide()
        return
    end

    local panelScale = rightPanel:GetEffectiveScale()
    local scale = trackedTalentFrame:GetEffectiveScale()
    local ratio = scale / panelScale
    local right = trackedTalentFrame:GetRight()
    local top = trackedTalentFrame:GetTop()
    local bottom = trackedTalentFrame:GetBottom()
    if not right or not top or not bottom then return end

    local targetX = (right * ratio) + 2
    local screenW = GetScreenWidth()
    if targetX + PANEL_WIDTH > screenW then targetX = screenW - PANEL_WIDTH end
    local targetY = top * ratio
    local panelH = (top - bottom) * ratio

    if smoothPos.rx then
        local dx = targetX - smoothPos.rx
        local dy = targetY - smoothPos.ry
        if math.abs(dx) < 0.5 and math.abs(dy) < 0.5 then
            smoothPos.rx = targetX
            smoothPos.ry = targetY
        elseif math.abs(dx) > SNAP_DISTANCE or math.abs(dy) > SNAP_DISTANCE then
            smoothPos.rx = targetX
            smoothPos.ry = targetY
        else
            smoothPos.rx = smoothPos.rx + dx * LERP_FACTOR
            smoothPos.ry = smoothPos.ry + dy * LERP_FACTOR
        end
    else
        smoothPos.rx = targetX
        smoothPos.ry = targetY
    end

    rightPanel:ClearAllPoints()
    rightPanel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", smoothPos.rx, smoothPos.ry)
    rightPanel:SetHeight(panelH)
    if rightPanel.lastFitH ~= panelH then
        rightPanel.lastFitH = panelH
        FitPanelRows(rightPanel)
    end
end

local function UpdateAllPositions()
    if not trackedTalentFrame or not trackedTalentFrame:IsShown() then
        if originalTalentScale and trackedTalentFrame then
            SafeSetTalentScale(originalTalentScale)
            originalTalentScale = nil
            appliedTalentScale = nil
        end
        if leftPanel then leftPanel:Hide() end
        if rightPanel then rightPanel:Hide() end
        return
    end

    if not originalTalentScale then
        originalTalentScale = trackedTalentFrame:GetScale()
    end

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.talentAutoScale == false then

        if appliedTalentScale and math.abs(originalTalentScale - appliedTalentScale) > 0.01 then
            SafeSetTalentScale(originalTalentScale)
        end
    else
        local screenW = GetScreenWidth()
        local tfNativeW = trackedTalentFrame:GetWidth()
        local panelNeeded = PANEL_WIDTH + 4

        local maxScaleThatFits = (screenW - 2 * panelNeeded) / tfNativeW
        local targetScale = originalTalentScale
        if maxScaleThatFits < originalTalentScale then
            targetScale = maxScaleThatFits
            if targetScale < 0.5 then targetScale = 0.5 end
        end

        if not appliedTalentScale or math.abs(targetScale - appliedTalentScale) > 0.01 then
            SafeSetTalentScale(targetScale)
        end
    end

    UpdateLeftPanelPosition()
    UpdateRightPanelPosition()
end

function RefreshAllPanels()
    if leftPanel and leftPanel.RefreshTabLabels then leftPanel:RefreshTabLabels() end
    if rightPanel and rightPanel.RefreshTabLabels then rightPanel:RefreshTabLabels() end
    if leftPanel and leftPanel:IsShown() then
        RefreshSidePanel(leftPanel, leftRows, AkcQOLWCLDungeonList, "mplus", MPLUS_COLOR, 0)
    end
    if rightPanel and rightPanel:IsShown() then
        RefreshSidePanel(rightPanel, rightRows, AkcQOLWCLBossList, "raid", RAID_COLOR, 0)
    end
    CheckTalentProfile(true)
end

_G.WVT_RefreshBuilds = RefreshAllPanels

local function CreatePanels()
    if not leftPanel then
        leftPanel, leftRows = CreateWCLSidePanel(
            "AkcQOLMPlusPanel",
            "|cFF66D9FF" .. L["M+ Dungeons"] .. "|r",
            MPLUS_COLOR,
            "mplus"
        )

    end

    if not rightPanel then
        rightPanel, rightRows = CreateWCLSidePanel(
            "AkcQOLRaidPanel",
            "|cFFFF8800" .. L["Raid Bosses"] .. "|r",
            RAID_COLOR,
            "raid"
        )

    end
end

local function GetSavedPanelSource(kind)
    if AkcQOLDB and AkcQOLDB.global and type(AkcQOLDB.global.talentPanelSources) == "table" then
        local saved = AkcQOLDB.global.talentPanelSources[kind]
        if saved then return GetSourceByKey(saved).key end
    end

    local buildKey = RestoreLastLoadedBuildKey()
    if GetBuildKindFromKey(buildKey) == kind then
        return GetBuildSourceKey(buildKey)
    end

    return nil
end

local function RestorePanelDataSources()
    if leftPanel and leftPanel.SetDataSourceKey then
        leftPanel:SetDataSourceKey(GetSavedPanelSource("mplus") or leftPanel.dataSource or "wcl", false)
    end
    if rightPanel and rightPanel.SetDataSourceKey then
        rightPanel:SetDataSourceKey(GetSavedPanelSource("raid") or rightPanel.dataSource or "wcl", false)
    end
end

local function ShowPanels(talentFrame)
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showTalentHelper == false then return end

    RestoreLastLoadedBuildKey()

    CreatePanels()
    RestorePanelDataSources()
    ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
    trackedTalentFrame = talentFrame

    smoothPos.lx = nil; smoothPos.ly = nil
    smoothPos.rx = nil; smoothPos.ry = nil

    leftPanel:Show()
    rightPanel:Show()

    UpdateAllPositions()
    RefreshAllPanels()

    -- Every frame, not every 0.05s: the work is a handful of SetPoints, and
    -- at 20 Hz the panel visibly stepped along behind a dragged window.
    leftPanel:SetScript("OnUpdate", function()
        UpdateAllPositions()
    end)
end

local function HidePanels()
    if originalTalentScale and trackedTalentFrame then
        SafeSetTalentScale(originalTalentScale)
        originalTalentScale = nil
        appliedTalentScale = nil
    end
    if leftPanel then leftPanel:Hide() end
    if rightPanel then rightPanel:Hide() end
    trackedTalentFrame = nil
end

local hooked = false

local function IsTalentTabVisible()
    if PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
        local tf = PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
        if tf and tf:IsShown() then return true end
    end
    if ClassTalentFrame and ClassTalentFrame:IsShown() then
        return true
    end
    return false
end

local function GetVisibleTalentFrame()
    if PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
        local tf = PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
        if tf and tf:IsShown() then return PlayerSpellsFrame end
    end
    if ClassTalentFrame and ClassTalentFrame:IsShown() then
        return ClassTalentFrame
    end
    return nil
end

local function OnTalentVisibilityChanged()
    if IsTalentTabVisible() then
        local frame = GetVisibleTalentFrame()
        if frame then ShowPanels(frame) end
    else
        HidePanels()
    end
end

local function TryHookAll()
    if hooked then return end

    if PlayerSpellsFrame then
        hooked = true
        local talentsFrame = PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
        if talentsFrame then
            talentsFrame:HookScript("OnShow", function()
                C_Timer.After(0.1, function() OnTalentVisibilityChanged() end)
            end)
            talentsFrame:HookScript("OnHide", function()
                HidePanels()
            end)
        end

        PlayerSpellsFrame:HookScript("OnHide", function()
            HidePanels()
        end)

        if IsTalentTabVisible() then
            C_Timer.After(0.1, function() OnTalentVisibilityChanged() end)
        end
    end

    if ClassTalentFrame and not hooked then
        hooked = true
        ClassTalentFrame:HookScript("OnShow", function()
            C_Timer.After(0.1, function() OnTalentVisibilityChanged() end)
        end)
        ClassTalentFrame:HookScript("OnHide", function()
            HidePanels()
        end)
    end
end

local evtFrame = CreateFrame("Frame")
evtFrame:RegisterEvent("ADDON_LOADED")
evtFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
evtFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
evtFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
-- Trait data is not readable until this fires on a fresh login (on a reload it
-- is ready immediately) -- which is exactly why the panel came up blank after
-- logging out and back in, but looked fine after /reload.
evtFrame:RegisterEvent("TRAIT_CONFIG_LIST_UPDATED")
evtFrame:RegisterEvent("ACTIVE_COMBAT_CONFIG_CHANGED")
evtFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
evtFrame:RegisterEvent("ZONE_CHANGED")
evtFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
evtFrame:RegisterEvent("CHALLENGE_MODE_START")
evtFrame:RegisterEvent("ENCOUNTER_START")
evtFrame:RegisterUnitEvent("UNIT_SPELLCAST_INTERRUPTED", "player")
evtFrame:RegisterUnitEvent("UNIT_SPELLCAST_FAILED_QUIET", "player")

evtFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == "Blizzard_PlayerSpells" or arg1 == "Blizzard_ClassTalentUI" then
            C_Timer.After(0.2, TryHookAll)
            C_Timer.After(1.0, TryHookAll)
            -- The loadout parser arrived with it, so builds that could not be
            -- recognised a moment ago can be now.
            C_Timer.After(0.3, function()
                ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
                RefreshAllPanels()
            end)
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        RestoreLastLoadedBuildKey()
        C_Timer.After(1.0, TryHookAll)
        C_Timer.After(1.5, function()
            ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            RestorePanelDataSources()
            RefreshAllPanels()
        end)
        C_Timer.After(3.0, function()
            ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            RestorePanelDataSources()
            RefreshAllPanels()
        end)
        ScheduleTalentProfileCheck(true, 2.0)
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        if arg1 == "player" then
            -- This also fires during login and on some zone-ins with no actual
            -- change. Forgetting the build there wiped the saved key, spec and
            -- string from disk on every single login.
            local _, specID = GetPlayerClassAndSpec()
            local savedSpec = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.lastLoadedBuildSpec
            wipe(loadoutSignatureCache)
            if specID and savedSpec and tonumber(savedSpec) ~= tonumber(specID) then
                ClearLastLoadedBuildKey()
            else
                ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            end
            RefreshAllPanels()
            ScheduleTalentProfileCheck(true, 1.0)
        end
    elseif event == "TRAIT_CONFIG_LIST_UPDATED" then
        wipe(loadoutSignatureCache)
        C_Timer.After(0.2, function()
            ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            RefreshAllPanels()
        end)
    elseif event == "TRAIT_CONFIG_UPDATED" then
        C_Timer.After(0.3, function()
            if pendingLoadKey and (GetTime() - lastLoadTime) < 15 then

                PersistLastLoadedBuildKey(pendingLoadKey, nil, pendingLoadString)
                pendingLoadKey = nil
                pendingLoadString = nil
            else
                pendingLoadKey = nil

                ReconcileLastLoadedBuildFromCurrentTalents(nil, false)
            end

            RestorePanelDataSources()
            RefreshAllPanels()
            CheckTalentProfile(true)
        end)
    elseif event == "ACTIVE_COMBAT_CONFIG_CHANGED" then

        if not (pendingLoadKey and (GetTime() - lastLoadTime) < 10) then
            local recentAkcQOLLoadKey = nil
            if (GetTime() - lastLoadTime) < 10 then
                recentAkcQOLLoadKey = lastLoadedKey or _G.AkcQOL_LastLoadedBuild
            end
            if recentAkcQOLLoadKey and recentAkcQOLLoadKey ~= "" then
                PersistLastLoadedBuildKey(recentAkcQOLLoadKey)
            else
                ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            end
        end
        C_Timer.After(0.3, function()
            RestorePanelDataSources()
            RefreshAllPanels()
            CheckTalentProfile(true)
        end)
    elseif event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS"
        or event == "CHALLENGE_MODE_START" or event == "ENCOUNTER_START" then
        ScheduleTalentProfileCheck(false, 2.0)
    elseif event == "UNIT_SPELLCAST_INTERRUPTED" or event == "UNIT_SPELLCAST_FAILED_QUIET" then
        if arg1 == "player" and pendingLoadKey and (GetTime() - lastLoadTime) < 10 then
            pendingLoadKey = nil

            ClearLastLoadedBuildKey()
            print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Talent load was cancelled."])
            RefreshAllPanels()
            C_Timer.After(0.5, function()
                if not pendingLoadKey then
                    ReconcileLastLoadedBuildFromCurrentTalents(nil, false)
                    RefreshAllPanels()
                end
            end)
        end
    end
end)

SLASH_WVBUILDS1 = "/akctalent"
SlashCmdList["WVBUILDS"] = function()
    CreatePanels()
    if leftPanel:IsShown() then
        HidePanels()
        return
    end
    if PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
        ShowPanels(PlayerSpellsFrame)
    elseif ClassTalentFrame and ClassTalentFrame:IsShown() then
        ShowPanels(ClassTalentFrame)
    else

        if PlayerSpellsUtil and PlayerSpellsUtil.OpenToClassTalents then
            pcall(PlayerSpellsUtil.OpenToClassTalents)
        elseif PlayerSpellsFrame and ShowUIPanel then
            pcall(ShowUIPanel, PlayerSpellsFrame)
        elseif ToggleTalentFrame then
            pcall(ToggleTalentFrame)
        end
    end
end


do
    local timerNotches = {}
    local lastTimerBar = nil
    local activeMplus = false

    local function CreateNotch(parent)
        local n = {}
        n.glow = parent:CreateTexture(nil, "OVERLAY", nil, 5)
        n.glow:SetTexture(FLAT_TEX)
        n.line = parent:CreateTexture(nil, "OVERLAY", nil, 6)
        n.line:SetTexture(FLAT_TEX)
        n.label = parent:CreateFontString(nil, "OVERLAY", nil, 7)
        n.label:SetFont(FONT_FACE, 8, FONT_FLAGS)
        return n
    end

    local function ShowNotch(n, bar, xPos, barH, r, g, b, labelText)
        n.line:SetSize(1, barH)
        n.line:ClearAllPoints()
        n.line:SetPoint("CENTER", bar, "LEFT", xPos, 0)
        n.line:SetVertexColor(r, g, b, 1)
        n.line:Show()
        n.glow:SetSize(5, barH)
        n.glow:ClearAllPoints()
        n.glow:SetPoint("CENTER", bar, "LEFT", xPos, 0)
        n.glow:SetVertexColor(r, g, b, 0.25)
        n.glow:Show()
        n.label:SetText(string.format("|cFF%02x%02x%02x%s|r",
            math.floor(r * 255), math.floor(g * 255), math.floor(b * 255), labelText))
        n.label:ClearAllPoints()
        n.label:SetPoint("TOP", n.line, "BOTTOM", 0, -1)
        n.label:Show()
    end

    local function HideNotch(n)
        if n.line then n.line:Hide() end
        if n.glow then n.glow:Hide() end
        if n.label then n.label:Hide() end
    end

    local function HideAll()
        for _, n in pairs(timerNotches) do HideNotch(n) end
    end

    local function CollectStatusBars(frame, out, depth)
        if not frame or depth > 10 then return end
        for _, kid in pairs({ frame:GetChildren() }) do
            if kid:IsObjectType("StatusBar") and kid:IsShown() then
                local _, mx = kid:GetMinMaxValues()
                if mx and mx > 0 then out[#out + 1] = kid end
            end
            CollectStatusBars(kid, out, depth + 1)
        end
    end

    local function FindTimerBar()
        local allBars = {}
        if ScenarioBlocksFrame then CollectStatusBars(ScenarioBlocksFrame, allBars, 0) end
        if #allBars == 0 and ObjectiveTrackerFrame then CollectStatusBars(ObjectiveTrackerFrame, allBars, 0) end
        if #allBars == 0 then return nil end

        for _, bar in ipairs(allBars) do
            local _, mx = bar:GetMinMaxValues()
            if mx and mx >= 300 and mx <= 3600 then
                return bar
            end
        end

        table.sort(allBars, function(a, b)
            local _, ay = a:GetCenter(); local _, by = b:GetCenter()
            return (ay or 0) > (by or 0)
        end)
        return allBars[1]
    end

    local function FormatTime(sec)
        local m = math.floor(sec / 60)
        local s = math.floor(sec % 60)
        return string.format("%d:%02d", m, s)
    end

    local function GetMplusTime()
        if not C_ChallengeMode then return nil, nil end
        local mapID = C_ChallengeMode.GetActiveChallengeMapID()
        if not mapID then return nil, nil end
        local _, _, timeLimit = C_ChallengeMode.GetMapUIInfo(mapID)
        if not timeLimit or timeLimit <= 0 then return nil, nil end

        local elapsed = 0
        if GetWorldElapsedTimers and GetWorldElapsedTime then
            local timers = { GetWorldElapsedTimers() }
            for _, timerID in ipairs(timers) do
                if timerID and timerID > 0 then
                    local _, e = GetWorldElapsedTime(timerID)
                    if e and e > 0 then elapsed = e; break end
                end
            end
        end

        local remaining = math.max(0, timeLimit - elapsed)
        return timeLimit, remaining
    end

    local function UpdateNotches()
        HideAll()

        if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showTalentHelper == false then return end
        if not activeMplus then return end
        local bar = FindTimerBar()
        if not bar then return end

        if lastTimerBar and lastTimerBar ~= bar then timerNotches = {} end
        lastTimerBar = bar

        local barW = bar:GetWidth()
        local barH = bar:GetHeight()
        if barW <= 0 or barH <= 0 then return end

        local timeLimit, remaining = GetMplusTime()
        if not timeLimit then return end

        local thresholds = {
            { pct = 0.40, r = 0.2, g = 1.0, b = 0.3 },
            { pct = 0.20, r = 0.4, g = 0.7, b = 1.0 },
        }

        for ti, th in ipairs(thresholds) do
            if not timerNotches[ti] then
                timerNotches[ti] = CreateNotch(bar)
            end
            local cutoff = timeLimit * th.pct
            local buffer = math.max(0, remaining - cutoff)
            ShowNotch(timerNotches[ti], bar, th.pct * barW, barH,
                th.r, th.g, th.b, FormatTime(buffer))
        end
    end

    local refreshTicker = nil
    local function StopTicker()
        if refreshTicker then refreshTicker:Cancel(); refreshTicker = nil end
    end
    local function StartTicker()
        if refreshTicker then return end

        refreshTicker = C_Timer.NewTicker(1, function()
            if activeMplus then UpdateNotches() else StopTicker() end
        end)
    end

    local function CheckDungeon()
        local _, _, difficultyID = GetInstanceInfo()
        if difficultyID == 8 then
            activeMplus = true
            C_Timer.After(0.5, UpdateNotches)
            StartTicker()
        else
            activeMplus = false
            HideAll()
            StopTicker()
        end
    end

    local events = CreateFrame("Frame")
    events:RegisterEvent("CHALLENGE_MODE_START")
    events:RegisterEvent("CHALLENGE_MODE_COMPLETED")
    events:RegisterEvent("CHALLENGE_MODE_RESET")
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
    events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    events:SetScript("OnEvent", function(_, event)
        if event == "CHALLENGE_MODE_COMPLETED" or event == "CHALLENGE_MODE_RESET" then
            activeMplus = false
            HideAll()
            StopTicker()
            return
        end
        C_Timer.After(0.5, CheckDungeon)
    end)
end
