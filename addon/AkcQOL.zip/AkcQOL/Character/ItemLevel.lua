
local L = AkcQOL_L

local FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"
local FONT_SIZE = 12

local enabled = true

local optArrow, optGemEnchant, optDecimals = true, true, true

local function RefreshOptions()
    local o = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.itemLevel
    if type(o) == "table" then
        optArrow = o.arrow ~= false
        optGemEnchant = o.gemEnchant ~= false
        optDecimals = o.decimals ~= false
    else
        optArrow, optGemEnchant, optDecimals = true, true, true
    end
end

local CACHED_PRIMARY_STAT = nil
local CACHED_CLASS_ID = nil
local CACHED_SPEC_ID = nil

local function RefreshPlayerCache()

    local specIndex = GetSpecialization()
    if specIndex then
        local sid, _, _, _, _, primaryStat = GetSpecializationInfo(specIndex)
        CACHED_SPEC_ID = sid
        if primaryStat == 1 then CACHED_PRIMARY_STAT = "STR"
        elseif primaryStat == 2 then CACHED_PRIMARY_STAT = "AGI"
        elseif primaryStat == 4 then CACHED_PRIMARY_STAT = "INT"
        end
    end

    local _, _, classID = UnitClass("player")
    CACHED_CLASS_ID = classID

    if not CACHED_PRIMARY_STAT then
        local _, className = UnitClass("player")
        if className == "WARRIOR" or className == "PALADIN" or className == "DEATHKNIGHT" then
            CACHED_PRIMARY_STAT = "STR"
        elseif className == "HUNTER" or className == "ROGUE" or className == "MONK"
            or className == "DEMONHUNTER" or className == "EVOKER" then
            CACHED_PRIMARY_STAT = "AGI"
        else
            CACHED_PRIMARY_STAT = "INT"
        end
    end
end

local playerCacheFrame = CreateFrame("Frame")
playerCacheFrame:RegisterEvent("PLAYER_LOGIN")
playerCacheFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
playerCacheFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
playerCacheFrame:SetScript("OnEvent", function()

    C_Timer.After(0.5, function()
        pcall(RefreshPlayerCache)
    end)
end)

local function IsEquipment(itemID)
    if not itemID then return false end
    local _, _, _, _, _, classID = C_Item.GetItemInfoInstant(itemID)
    return classID == Enum.ItemClass.Weapon or classID == Enum.ItemClass.Armor
end

local CLASS_ARMOR_TYPE = {
    [1]  = 4,
    [2]  = 4,
    [3]  = 3,
    [4]  = 2,
    [5]  = 1,
    [6]  = 4,
    [7]  = 3,
    [8]  = 1,
    [9]  = 1,
    [10] = 2,
    [11] = 2,
    [12] = 2,
    [13] = 3,
}

local function IsWearableArmorType(itemID)
    if not itemID then return true end
    local _, _, _, equipLoc, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)

    if equipLoc == "INVTYPE_CLOAK" then return true end

    if classID ~= Enum.ItemClass.Armor then return true end
    if subclassID < 1 or subclassID > 4 then return true end

    if not CACHED_CLASS_ID then return true end
    local expectedType = CLASS_ARMOR_TYPE[CACHED_CLASS_ID]
    if not expectedType then return true end
    return subclassID == expectedType
end

local SPEC_WEAPON_TYPES = {

    [253] = { [2]=true, [3]=true, [18]=true },
    [254] = { [2]=true, [3]=true, [18]=true },
    [255] = { [6]=true, [10]=true },

    [62]  = { [7]=true, [10]=true, [15]=true, [20]=true },
    [63]  = { [7]=true, [10]=true, [15]=true, [20]=true },
    [64]  = { [7]=true, [10]=true, [15]=true, [20]=true },
    [258] = { [4]=true, [10]=true, [15]=true, [20]=true },
    [256] = { [4]=true, [10]=true, [15]=true, [20]=true },
    [257] = { [4]=true, [10]=true, [15]=true, [20]=true },
    [265] = { [7]=true, [10]=true, [15]=true, [20]=true },
    [266] = { [7]=true, [10]=true, [15]=true, [20]=true },
    [267] = { [7]=true, [10]=true, [15]=true, [20]=true },
    [262] = { [4]=true, [10]=true, [15]=true, [20]=true },
    [264] = { [4]=true, [10]=true, [15]=true, [20]=true },
    [102] = { [4]=true, [10]=true, [15]=true, [6]=true },
    [105] = { [4]=true, [10]=true, [15]=true, [6]=true },

    [577] = { [0]=true, [7]=true, [9]=true, [13]=true, [15]=true },
    [581] = { [0]=true, [7]=true, [9]=true, [13]=true, [15]=true },

    [259] = { [0]=true, [7]=true, [4]=true, [13]=true, [15]=true },
    [260] = { [0]=true, [7]=true, [4]=true, [13]=true, [15]=true },
    [261] = { [0]=true, [7]=true, [4]=true, [13]=true, [15]=true },

    [73]  = { [0]=true, [4]=true, [7]=true, [13]=true, [15]=true },
    [66]  = { [0]=true, [4]=true, [7]=true, [13]=true },

    [268] = { [0]=true, [4]=true, [6]=true, [7]=true, [10]=true, [13]=true },

    [269] = { [0]=true, [4]=true, [6]=true, [7]=true, [10]=true, [13]=true },

    [270] = { [4]=true, [6]=true, [10]=true },
}

local function IsWearableWeaponForSpec(itemID)
    if not itemID then return true end
    local _, _, _, _, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
    if classID ~= Enum.ItemClass.Weapon then return true end

    if not CACHED_SPEC_ID then return true end
    local allowed = SPEC_WEAPON_TYPES[CACHED_SPEC_ID]
    if not allowed then return true end
    return allowed[subclassID] or false
end

local STR_PATTERNS, AGI_PATTERNS, INT_PATTERNS
do
    local function build(globalName, fallback)
        local t = {}
        local localized = _G[globalName]
        if type(localized) == "string" and localized ~= "" then
            t[#t + 1] = localized
        end
        if fallback ~= localized then
            t[#t + 1] = fallback
        end
        return t
    end
    STR_PATTERNS = build("ITEM_MOD_STRENGTH_SHORT", "Strength")
    AGI_PATTERNS = build("ITEM_MOD_AGILITY_SHORT", "Agility")
    INT_PATTERNS = build("ITEM_MOD_INTELLECT_SHORT", "Intellect")
end

local function MatchesAnyStat(txt, patterns)
    for _, p in ipairs(patterns) do
        if txt:find(p, 1, true) then return true end
    end
    return false
end

local primaryStatCache = {}

local function HasMatchingPrimaryStat(itemLink)
    if not itemLink then return true end

    local entry = primaryStatCache[itemLink]
    if not entry then

        local ok, tooltipData = pcall(C_TooltipInfo.GetHyperlink, itemLink)
        if not ok or not tooltipData or not tooltipData.lines then return true end
        pcall(TooltipUtil.SurfaceArgs, tooltipData)

        local hasStr, hasAgi, hasInt = false, false, false
        for _, line in ipairs(tooltipData.lines) do
            pcall(TooltipUtil.SurfaceArgs, line)
            local txt = line.leftText or ""

            if txt:find("%+%d") then
                local isStr = MatchesAnyStat(txt, STR_PATTERNS)
                local isAgi = MatchesAnyStat(txt, AGI_PATTERNS)
                local isInt = MatchesAnyStat(txt, INT_PATTERNS)

                local count = (isStr and 1 or 0) + (isAgi and 1 or 0) + (isInt and 1 or 0)
                if count == 1 then
                    hasStr = hasStr or isStr
                    hasAgi = hasAgi or isAgi
                    hasInt = hasInt or isInt
                end
            end
        end

        entry = { STR = hasStr, AGI = hasAgi, INT = hasInt }
        primaryStatCache[itemLink] = entry
    end

    if not (entry.STR or entry.AGI or entry.INT) then return true end

    local playerPrimary = CACHED_PRIMARY_STAT
    if not playerPrimary then

        return true
    end

    return entry[playerPrimary] == true
end

local ENCHANTABLE_SLOTS = {
    [1]  = true,
    [3]  = true,
    [5]  = true,
    [7]  = true,
    [8]  = true,
    [11] = true,
    [12] = true,
    [16] = true,
    [17] = "weapon_only",
}

local GEM_SOCKET_LINE = Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.GemSocket

local function ItemHasEmptyGemSlots(itemLink, slotID, unit)
    if not itemLink then return false end

    local tooltipData
    if slotID and unit then
        local ok, td = pcall(C_TooltipInfo.GetInventoryItem, unit, slotID)
        if ok then tooltipData = td end
    end
    if not tooltipData then

        local ok, td = pcall(C_TooltipInfo.GetHyperlink, itemLink)
        if ok then tooltipData = td end
    end
    if not tooltipData or not tooltipData.lines then return false end
    pcall(TooltipUtil.SurfaceArgs, tooltipData)
    for _, line in ipairs(tooltipData.lines) do
        pcall(TooltipUtil.SurfaceArgs, line)

        if GEM_SOCKET_LINE and line.type == GEM_SOCKET_LINE then
            if not line.gemIcon then
                return true
            end
        else
            local txt = line.leftText or ""

            if txt == (EMPTY_SOCKET_PRISMATIC or "") or
               txt == (EMPTY_SOCKET_RED or "") or
               txt == (EMPTY_SOCKET_BLUE or "") or
               txt == (EMPTY_SOCKET_YELLOW or "") or
               txt == (EMPTY_SOCKET_META or "") or
               txt == (EMPTY_SOCKET_NO_COLOR or "") then
                return true
            end
        end
    end
    return false
end

local function ItemIsMissingEnchant(itemLink, slotID)
    if not itemLink or not slotID then return false end
    local slotFlag = ENCHANTABLE_SLOTS[slotID]
    if not slotFlag then return false end

    if slotFlag == "weapon_only" then
        local _, _, _, equipLoc = C_Item.GetItemInfoInstant(itemLink)
        if not equipLoc or (equipLoc ~= "INVTYPE_WEAPON" and equipLoc ~= "INVTYPE_WEAPONOFFHAND") then
            return false
        end
    end

    local enchantID = itemLink:match("item:%d+:(%d+)")
    if not enchantID or tonumber(enchantID) == 0 then
        return true
    end
    return false
end

local EQUIP_LOC_TO_SLOT = {
    INVTYPE_HEAD           = { 1 },
    INVTYPE_NECK           = { 2 },
    INVTYPE_SHOULDER       = { 3 },
    INVTYPE_CHEST          = { 5 },
    INVTYPE_ROBE           = { 5 },
    INVTYPE_WAIST          = { 6 },
    INVTYPE_LEGS           = { 7 },
    INVTYPE_FEET           = { 8 },
    INVTYPE_WRIST          = { 9 },
    INVTYPE_HAND           = { 10 },
    INVTYPE_FINGER         = { 11, 12 },
    INVTYPE_TRINKET        = { 13, 14 },
    INVTYPE_CLOAK          = { 15 },
    INVTYPE_WEAPON         = { 16, 17 },
    INVTYPE_2HWEAPON       = { 16 },
    INVTYPE_WEAPONMAINHAND = { 16 },
    INVTYPE_WEAPONOFFHAND  = { 17 },
    INVTYPE_SHIELD         = { 17 },
    INVTYPE_HOLDABLE       = { 17 },
    INVTYPE_RANGED         = { 16 },
    INVTYPE_RANGEDRIGHT    = { 16 },
}

local function HasEquipped2H()
    local mhLink = GetInventoryItemLink("player", 16)
    if not mhLink then return false end
    local _, _, _, equipLoc = C_Item.GetItemInfoInstant(mhLink)
    return equipLoc == "INVTYPE_2HWEAPON"
end

local function GetEquippedIlvlForItem(itemLink)
    if not itemLink then return nil end
    local _, _, _, equipLoc = C_Item.GetItemInfoInstant(itemLink)
    if not equipLoc or equipLoc == "" then return nil end
    local slots = EQUIP_LOC_TO_SLOT[equipLoc]
    if not slots then return nil end

    local has2H = HasEquipped2H()
    if has2H then

        if equipLoc == "INVTYPE_WEAPON" then
            local mhLink = GetInventoryItemLink("player", 16)
            if mhLink then
                return C_Item.GetDetailedItemLevelInfo(mhLink)
            end
            return nil
        end

        if equipLoc == "INVTYPE_WEAPONOFFHAND" or equipLoc == "INVTYPE_SHIELD"
           or equipLoc == "INVTYPE_HOLDABLE" then
            local mhLink = GetInventoryItemLink("player", 16)
            if mhLink then
                return C_Item.GetDetailedItemLevelInfo(mhLink)
            end
            return nil
        end
    end

    local isWeapon = (equipLoc == "INVTYPE_WEAPON")

    local lowestIlvl = nil
    for _, slotID in ipairs(slots) do
        local equippedLink = GetInventoryItemLink("player", slotID)
        if equippedLink then

            if isWeapon then
                local _, _, _, eqLoc = C_Item.GetItemInfoInstant(equippedLink)
                if eqLoc ~= "INVTYPE_WEAPON" and eqLoc ~= "INVTYPE_WEAPONMAINHAND"
                   and eqLoc ~= "INVTYPE_WEAPONOFFHAND" and eqLoc ~= "INVTYPE_2HWEAPON" then

                else
                    local eIlvl = C_Item.GetDetailedItemLevelInfo(equippedLink)
                    if eIlvl then
                        if not lowestIlvl or eIlvl < lowestIlvl then
                            lowestIlvl = eIlvl
                        end
                    end
                end
            else
                local eIlvl = C_Item.GetDetailedItemLevelInfo(equippedLink)
                if eIlvl then
                    if not lowestIlvl or eIlvl < lowestIlvl then
                        lowestIlvl = eIlvl
                    end
                end
            end
        else

            local equippedID = GetInventoryItemID("player", slotID)
            if equippedID then

                return nil
            end

            if isWeapon and slotID == 17 then

            else
                return 0
            end
        end
    end
    return lowestIlvl
end

local preparedButtons = setmetatable({}, { __mode = "k" })

local function PrepareButton(button)
    if button.__akcqolILvl then return end
    preparedButtons[button] = true
    local overlay = CreateFrame("Frame", nil, button)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(button:GetFrameLevel() + 1)
    overlay:EnableMouse(false)

    local text = overlay:CreateFontString(nil, "OVERLAY")
    text:SetFont(FONT_FACE, FONT_SIZE, FONT_FLAGS)
    text:SetPoint("BOTTOM", overlay, "BOTTOM", 0, 2)

    local warn = overlay:CreateFontString(nil, "OVERLAY")
    warn:SetFont(FONT_FACE, 22, FONT_FLAGS)
    warn:SetPoint("TOP", overlay, "TOP", 0, -1)

    local arrow = overlay:CreateTexture(nil, "OVERLAY")
    arrow:SetSize(12, 12)
    arrow:SetPoint("TOPLEFT", overlay, "TOPLEFT", -2, 2)
    arrow:SetAtlas("poi-door-arrow-up")
    arrow:SetVertexColor(0.2, 1, 0.2, 1)
    arrow:Hide()

    button.__akcqolILvlOverlay = overlay
    button.__akcqolILvl = text
    button.__akcqolWarn = warn
    button.__akcqolUpgrade = arrow
end

local function CleanButton(button)

    button.__akcqolGen = (button.__akcqolGen or 0) + 1
    if button.__akcqolILvl then
        button.__akcqolILvl:Hide()
    end
    if button.__akcqolWarn then
        button.__akcqolWarn:Hide()
    end
    if button.__akcqolUpgrade then
        button.__akcqolUpgrade:Hide()
    end
end

local function ShowLevel(button, level, quality, itemLink, slotID, unit)
    PrepareButton(button)
    local r, g, b = 1, 1, 1
    if quality and C_Item.GetItemQualityColor then
        r, g, b = C_Item.GetItemQualityColor(quality)
    end
    button.__akcqolILvl:SetText(level)
    button.__akcqolILvl:SetTextColor(r, g, b)
    button.__akcqolILvl:Show()
    button.__akcqolILvlOverlay:SetFrameLevel(button:GetFrameLevel() + 1)

    if button.__akcqolWarn and slotID and optGemEnchant then
        local warnings = {}
        if ItemHasEmptyGemSlots(itemLink, slotID, unit) then
            table.insert(warnings, "|cffFF0000" .. L["G"] .. "|r")
        end
        if ItemIsMissingEnchant(itemLink, slotID) then
            table.insert(warnings, "|cffFF0000" .. L["E"] .. "|r")
        end
        if #warnings > 0 then
            button.__akcqolWarn:SetText(table.concat(warnings, " "))

            button.__akcqolWarn:ClearAllPoints()
            if slotID == 16 or slotID == 17 then

                button.__akcqolWarn:SetPoint("BOTTOM", button.__akcqolILvlOverlay, "TOP", 0, 1)
            elseif slotID == 1 or slotID == 2 or slotID == 3 or slotID == 4 or slotID == 5 or slotID == 9 or slotID == 15 or slotID == 18 or slotID == 19 then

                button.__akcqolWarn:SetPoint("LEFT", button.__akcqolILvlOverlay, "RIGHT", 2, 0)
            else

                button.__akcqolWarn:SetPoint("RIGHT", button.__akcqolILvlOverlay, "LEFT", -2, 0)
            end
            button.__akcqolWarn:Show()
        else
            button.__akcqolWarn:Hide()
        end
    elseif button.__akcqolWarn then
        button.__akcqolWarn:Hide()
    end
end

local function UpdateFromItem(button, item, slotID, unit)
    if not item or item:IsItemEmpty() then
        CleanButton(button)
        return
    end

    button.__akcqolGen = (button.__akcqolGen or 0) + 1
    local gen = button.__akcqolGen
    item:ContinueOnItemLoad(function()
        if button.__akcqolGen ~= gen then return end
        if not enabled then CleanButton(button) return end
        local itemID = item:GetItemID()
        if not IsEquipment(itemID) then CleanButton(button) return end
        local level = item:GetCurrentItemLevel()
        local quality = item:GetItemQuality()
        local itemLink = item:GetItemLink()
        if level and level > 0 then
            ShowLevel(button, level, quality, itemLink, slotID, unit)
        else
            CleanButton(button)
        end
    end)
end

local function UpdateFromLocation(button, itemLocation, slotID, unit)
    if not enabled then CleanButton(button) return end
    if not itemLocation or not C_Item.DoesItemExist(itemLocation) then
        CleanButton(button)
        return
    end
    local item = Item:CreateFromItemLocation(itemLocation)
    UpdateFromItem(button, item, slotID, unit)
end

local function UpdateFromLink(button, link, slotID, unit)
    if not enabled then CleanButton(button) return end
    if not link then CleanButton(button) return end
    local item = Item:CreateFromItemLink(link)
    UpdateFromItem(button, item, slotID, unit)
end

if _G.PaperDollItemSlotButton_Update then
    hooksecurefunc("PaperDollItemSlotButton_Update", function(button)
        if not enabled then CleanButton(button) return end
        local slotID = button:GetID()
        if slotID and slotID > 0 then
            local itemLocation = ItemLocation:CreateFromEquipmentSlot(slotID)
            UpdateFromLocation(button, itemLocation, slotID, "player")
        else
            CleanButton(button)
        end
    end)
end

local CACHED_EQUIPPED_ILVL = nil
local applyingIlvlText = false

local ilvlCacheFrame = CreateFrame("Frame")
ilvlCacheFrame:RegisterEvent("PLAYER_LOGIN")
ilvlCacheFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
ilvlCacheFrame:RegisterEvent("PLAYER_AVG_ITEM_LEVEL_UPDATE")
ilvlCacheFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_EQUIPMENT_CHANGED" then
        wipe(primaryStatCache)
    end

    C_Timer.After(0.3, function()
        local ok, _, equipped = pcall(GetAverageItemLevel)
        if ok and equipped and equipped > 0 then
            CACHED_EQUIPPED_ILVL = string.format("%.2f", equipped)

            if enabled and optDecimals and CharacterFrame and CharacterFrame:IsShown()
               and CharacterStatsPane and CharacterStatsPane.ItemLevelFrame
               and CharacterStatsPane.ItemLevelFrame.Value then
                applyingIlvlText = true
                pcall(CharacterStatsPane.ItemLevelFrame.Value.SetText,
                      CharacterStatsPane.ItemLevelFrame.Value, CACHED_EQUIPPED_ILVL)
                applyingIlvlText = false
            end
        end
    end)
end)

do
    local hooked = false

    local function HookIlvlText()
        if hooked then return end
        if not (CharacterStatsPane and CharacterStatsPane.ItemLevelFrame) then return end
        local valText = CharacterStatsPane.ItemLevelFrame.Value
        if not valText then return end

        local ok = pcall(function()
            hooksecurefunc(valText, "SetText", function(self, text)
                if applyingIlvlText then return end
                if not enabled then return end
                if not optDecimals then return end

                if type(text) == "string" and text:find(".", 1, true) then return end
                if not CACHED_EQUIPPED_ILVL then return end
                applyingIlvlText = true
                self:SetText(CACHED_EQUIPPED_ILVL)
                applyingIlvlText = false
            end)
        end)
        if ok then hooked = true end
    end

    if CharacterFrame then
        CharacterFrame:HookScript("OnShow", function()
            HookIlvlText()
        end)
    end
end

local function UpdateContainerButton(button, bagID, slotIndex)
    if not enabled then CleanButton(button) return end
    if not bagID or not slotIndex then CleanButton(button) return end
    local itemLocation = ItemLocation:CreateFromBagAndSlot(bagID, slotIndex)
    if not itemLocation or not C_Item.DoesItemExist(itemLocation) then
        CleanButton(button)
        return
    end
    local item = Item:CreateFromItemLocation(itemLocation)
    if not item or item:IsItemEmpty() then
        CleanButton(button)
        return
    end

    button.__akcqolGen = (button.__akcqolGen or 0) + 1
    local gen = button.__akcqolGen
    item:ContinueOnItemLoad(function()
        if button.__akcqolGen ~= gen then return end
        if not enabled then CleanButton(button) return end
        local itemID = item:GetItemID()
        if not IsEquipment(itemID) then CleanButton(button) return end
        local level = item:GetCurrentItemLevel()
        local quality = item:GetItemQuality()
        local itemLink = item:GetItemLink()
        if level and level > 0 then
            ShowLevel(button, level, quality, itemLink)

            PrepareButton(button)
            local equippedIlvl = GetEquippedIlvlForItem(itemLink)
            if optArrow and equippedIlvl and level > equippedIlvl and IsWearableArmorType(itemID) and IsWearableWeaponForSpec(itemID) and HasMatchingPrimaryStat(itemLink) then
                button.__akcqolUpgrade:Show()
            elseif button.__akcqolUpgrade then
                button.__akcqolUpgrade:Hide()
            end
        else
            CleanButton(button)
        end
    end)
end

if ContainerFrameCombinedBags and ContainerFrameCombinedBags.UpdateItems then
    hooksecurefunc(ContainerFrameCombinedBags, "UpdateItems", function(self)
        for _, itemButton in self:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end)
end

if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
    for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
        hooksecurefunc(frame, "UpdateItems", function(self)
            for _, itemButton in self:EnumerateValidItems() do
                UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
            end
        end)
    end
end

if _G.ContainerFrame_Update then
    hooksecurefunc("ContainerFrame_Update", function(container)

        local bagID = container:GetID()
        local name = container:GetName()
        for i = 1, container.size or 0 do
            local button = _G[name .. "Item" .. i]
            if button then
                UpdateContainerButton(button, bagID, i)
            end
        end
    end)
end

local function HookBankPanel(panel)
    if not panel then return end
    if panel.UpdateItems then
        hooksecurefunc(panel, "UpdateItems", function(self)

            for itemButton in self:EnumerateValidItems() do
                local bagID = itemButton.GetBankTabID and itemButton:GetBankTabID()
                local slotIndex = itemButton.GetContainerSlotID and itemButton:GetContainerSlotID()
                if bagID and slotIndex then
                    UpdateContainerButton(itemButton, bagID, slotIndex)
                end
            end
        end)
    end
    local function hookRefresh(methodName)
        if panel[methodName] then
            hooksecurefunc(panel, methodName, function(self)

                for itemButton in self:EnumerateValidItems() do
                    local bagID = itemButton.GetBankTabID and itemButton:GetBankTabID()
                    local slotIndex = itemButton.GetContainerSlotID and itemButton:GetContainerSlotID()
                    if bagID and slotIndex then
                        UpdateContainerButton(itemButton, bagID, slotIndex)
                    end
                end
            end)
        end
    end
    hookRefresh("GenerateItemSlotsForSelectedTab")
    hookRefresh("RefreshAllItemsForSelectedTab")
end

HookBankPanel(_G.BankPanel)
HookBankPanel(_G.AccountBankPanel)

if LootFrame and LootFrame.ScrollBox then
    local function HandleLootSlot(frame)
        local button = frame.Item or frame
        if not button then return end
        CleanButton(button)
        if not enabled then return end
        local data = frame.GetElementData and frame:GetElementData()
        if not (data and data.slotIndex) then return end
        local link = GetLootSlotLink(data.slotIndex)
        if link then
            UpdateFromLink(button, link)
        end
    end
    LootFrame.ScrollBox:RegisterCallback("OnUpdate", function()
        LootFrame.ScrollBox:ForEachFrame(HandleLootSlot)
    end)
elseif _G.LootFrame_UpdateButton then
    hooksecurefunc("LootFrame_UpdateButton", function(index)
        local button = _G["LootButton" .. index]
        if not button then return end
        CleanButton(button)
        if not enabled then return end
        if button.slot then
            local link = GetLootSlotLink(button.slot)
            if link then
                UpdateFromLink(button, link)
            end
        end
    end)
end

local UnpackLocation = _G.EquipmentManager_UnpackLocation or (C_EquipmentSet and C_EquipmentSet.UnpackLocation)

if _G.EquipmentFlyout_UpdateItems and UnpackLocation then
    hooksecurefunc("EquipmentFlyout_UpdateItems", function()

        local flyout = _G.EquipmentFlyoutFrame
        if not flyout or not flyout.buttons then return end
        for _, button in ipairs(flyout.buttons) do
            if button:IsShown() and button.location and button.location ~= 0xFFFFFFFF then
                local ok, player, bank, bags, voidStorage, slot, bag = pcall(UnpackLocation, button.location)
                if ok and bag and slot and bags then
                    local itemLocation = ItemLocation:CreateFromBagAndSlot(bag, slot)
                    UpdateFromLocation(button, itemLocation)
                elseif ok and player and slot then
                    local itemLocation = ItemLocation:CreateFromEquipmentSlot(slot)
                    UpdateFromLocation(button, itemLocation)
                else
                    CleanButton(button)
                end
            end
        end
    end)
end

local CHARACTER_SLOT_BUTTONS = {
    "CharacterHeadSlot", "CharacterNeckSlot", "CharacterShoulderSlot",
    "CharacterShirtSlot", "CharacterChestSlot", "CharacterWaistSlot",
    "CharacterLegsSlot", "CharacterFeetSlot", "CharacterWristSlot",
    "CharacterHandsSlot", "CharacterFinger0Slot", "CharacterFinger1Slot",
    "CharacterTrinket0Slot", "CharacterTrinket1Slot", "CharacterBackSlot",
    "CharacterMainHandSlot", "CharacterSecondaryHandSlot", false,
    "CharacterTabardSlot",
}

local function RefreshVisibleOverlays()
    if not enabled then return end
    if CharacterFrame and CharacterFrame:IsShown() then
        for slotID, slotName in ipairs(CHARACTER_SLOT_BUTTONS) do
            local btn = slotName and _G[slotName]
            if btn then
                UpdateFromLocation(btn, ItemLocation:CreateFromEquipmentSlot(slotID), slotID, "player")
            end
        end
    end
    if ContainerFrameCombinedBags and ContainerFrameCombinedBags:IsShown()
       and ContainerFrameCombinedBags.EnumerateValidItems then
        for _, itemButton in ContainerFrameCombinedBags:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end
    if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
        for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
            if frame:IsShown() and frame.EnumerateValidItems then
                for _, itemButton in frame:EnumerateValidItems() do
                    UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
                end
            end
        end
    end
end

function AkcQOLItemLevel_SetEnabled(isEnabled)
    enabled = isEnabled
    if not isEnabled then

        for button in pairs(preparedButtons) do
            CleanButton(button)
        end
    else
        RefreshVisibleOverlays()
    end
end

function AkcQOLItemLevel_ApplyOptions()
    RefreshOptions()

    for button in pairs(preparedButtons) do
        if not optArrow and button.__akcqolUpgrade then button.__akcqolUpgrade:Hide() end
        if not optGemEnchant and button.__akcqolWarn then button.__akcqolWarn:Hide() end
    end
    if enabled then
        RefreshVisibleOverlays()

        if optDecimals and CACHED_EQUIPPED_ILVL
           and CharacterFrame and CharacterFrame:IsShown()
           and CharacterStatsPane and CharacterStatsPane.ItemLevelFrame
           and CharacterStatsPane.ItemLevelFrame.Value then
            applyingIlvlText = true
            pcall(CharacterStatsPane.ItemLevelFrame.Value.SetText,
                  CharacterStatsPane.ItemLevelFrame.Value, CACHED_EQUIPPED_ILVL)
            applyingIlvlText = false
        end
    end
end

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:SetScript("OnEvent", function(self, event)
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    if AkcQOLDB.global.showItemLevel == nil then
        AkcQOLDB.global.showItemLevel = true
    end
    enabled = AkcQOLDB.global.showItemLevel ~= false
    RefreshOptions()
    self:UnregisterAllEvents()
end)

_G.AkcQOL_ToggleItemLevel = function()
    if not AkcQOLDB or not AkcQOLDB.global then return end
    AkcQOLItemLevel_SetEnabled(AkcQOLDB.global.showItemLevel ~= false)
end
