local _, addon = ...

addon.RaidCDData = {
    -- Death Knight
    [55233]  = { name = "Vampiric Blood",      class = "DEATHKNIGHT", spec = 250,  baseCD = 90,  duration = 10, trackByDefault = false },
    [51052]  = { name = "Anti-Magic Zone",      class = "DEATHKNIGHT", spec = 0,    baseCD = 120, duration = 8,  trackByDefault = true },

    -- Demon Hunter
    [196718] = { name = "Darkness",             class = "DEMONHUNTER", spec = 577,  baseCD = 300, duration = 8,  trackByDefault = true },

    -- Druid
    [740]    = { name = "Tranquility",          class = "DRUID",       spec = 105,  baseCD = 120, duration = 8,  trackByDefault = true },
    [29166]  = { name = "Innervate",            class = "DRUID",       spec = 105,  baseCD = 180, duration = 10, trackByDefault = false },
    [22812]  = { name = "Barkskin",             class = "DRUID",       spec = 0,    baseCD = 45,  duration = 12, trackByDefault = false },
    [102342] = { name = "Ironbark",             class = "DRUID",       spec = 105,  baseCD = 90,  duration = 12, trackByDefault = true },
    [33891]  = { name = "Incarnation: Tree of Life", class = "DRUID", spec = 105,  baseCD = 180, duration = 30, trackByDefault = false },
    [106898] = { name = "Stampeding Roar",      class = "DRUID",       spec = 0,    baseCD = 120, duration = 8,  trackByDefault = false },

    -- Evoker
    [363534] = { name = "Rewind",               class = "EVOKER",      spec = 1468, baseCD = 240, duration = 0,  trackByDefault = true },
    [370537] = { name = "Stasis",               class = "EVOKER",      spec = 0,    baseCD = 90,  duration = 0,  trackByDefault = false },
    [370984] = { name = "Emerald Communion",     class = "EVOKER",      spec = 1468, baseCD = 180, duration = 5,  trackByDefault = false },

    -- Mage
    [235450] = { name = "Prismatic Barrier",    class = "MAGE",        spec = 62,   baseCD = 30,  duration = 60, trackByDefault = false },
    [45438]  = { name = "Ice Block",            class = "MAGE",        spec = 0,    baseCD = 180, duration = 10, trackByDefault = false },

    -- Monk
    [115310] = { name = "Revival",              class = "MONK",        spec = 270,  baseCD = 180, duration = 0,  trackByDefault = true },
    [325197] = { name = "Invoke Chi-Ji",        class = "MONK",        spec = 270,  baseCD = 120, duration = 25, trackByDefault = false },
    [116849] = { name = "Life Cocoon",          class = "MONK",        spec = 270,  baseCD = 120, duration = 12, trackByDefault = true },
    [322118] = { name = "Invoke Yu'lon",        class = "MONK",        spec = 270,  baseCD = 180, duration = 25, trackByDefault = false },

    -- Paladin
    [31821]  = { name = "Aura Mastery",         class = "PALADIN",     spec = 65,   baseCD = 120, duration = 8,  trackByDefault = true },
    [31884]  = { name = "Avenging Wrath",       class = "PALADIN",     spec = 65,   baseCD = 120, duration = 20, trackByDefault = false },
    [31850]  = { name = "Ardent Defender",      class = "PALADIN",     spec = 66,   baseCD = 90,  duration = 8,  trackByDefault = false },
    [642]    = { name = "Divine Shield",        class = "PALADIN",     spec = 0,    baseCD = 300, duration = 8,  trackByDefault = false },
    [633]    = { name = "Lay on Hands",         class = "PALADIN",     spec = 0,    baseCD = 600, duration = 0,  trackByDefault = true },
    [6940]   = { name = "Blessing of Sacrifice", class = "PALADIN",   spec = 0,    baseCD = 60,  duration = 12, trackByDefault = false },
    [1022]   = { name = "Blessing of Protection", class = "PALADIN",  spec = 0,    baseCD = 300, duration = 10, trackByDefault = false },

    -- Priest
    [64843]  = { name = "Divine Hymn",          class = "PRIEST",      spec = 257,  baseCD = 180, duration = 8,  trackByDefault = true },
    [47788]  = { name = "Guardian Spirit",      class = "PRIEST",      spec = 257,  baseCD = 240, duration = 10, trackByDefault = false },
    [200183] = { name = "Apotheosis",           class = "PRIEST",      spec = 257,  baseCD = 120, duration = 20, trackByDefault = false },
    [62618]  = { name = "Power Word: Barrier",  class = "PRIEST",      spec = 256,  baseCD = 180, duration = 10, trackByDefault = true },
    [33206]  = { name = "Pain Suppression",     class = "PRIEST",      spec = 256,  baseCD = 180, duration = 8,  trackByDefault = false },
    [47536]  = { name = "Rapture",              class = "PRIEST",      spec = 256,  baseCD = 90,  duration = 8,  trackByDefault = false },
    [15286]  = { name = "Vampiric Embrace",     class = "PRIEST",      spec = 258,  baseCD = 120, duration = 15, trackByDefault = false },

    -- Shaman
    [98008]  = { name = "Spirit Link Totem",    class = "SHAMAN",      spec = 264,  baseCD = 180, duration = 6,  trackByDefault = true },
    [108280] = { name = "Healing Tide Totem",   class = "SHAMAN",      spec = 264,  baseCD = 180, duration = 10, trackByDefault = true },
    [114052] = { name = "Ascendance",           class = "SHAMAN",      spec = 264,  baseCD = 180, duration = 15, trackByDefault = false },
    [192077] = { name = "Wind Rush Totem",      class = "SHAMAN",      spec = 0,    baseCD = 120, duration = 15, trackByDefault = false },

    -- Warlock
    [29893]  = { name = "Soulstone",            class = "WARLOCK",     spec = 0,    baseCD = 600, duration = 0,  trackByDefault = true },

    -- Warrior
    [97462]  = { name = "Rallying Cry",         class = "WARRIOR",     spec = 0,    baseCD = 180, duration = 10, trackByDefault = true,
                  specCD = { [72] = 60 } },  -- Fury: 60s (spec passive)
}

addon.SpellsByClass = {}
addon.SpellsBySpec  = {}

for spellID, info in pairs(addon.RaidCDData) do
    if not addon.SpellsByClass[info.class] then
        addon.SpellsByClass[info.class] = {}
    end
    table.insert(addon.SpellsByClass[info.class], spellID)

    if info.spec ~= 0 then
        if not addon.SpellsBySpec[info.spec] then
            addon.SpellsBySpec[info.spec] = {}
        end
        table.insert(addon.SpellsBySpec[info.spec], spellID)
    end
end

addon.ClassOrder = {
    "DEATHKNIGHT", "DEMONHUNTER", "DRUID", "EVOKER",
    "HUNTER", "MAGE", "MONK", "PALADIN",
    "PRIEST", "ROGUE", "SHAMAN", "WARLOCK", "WARRIOR",
}

addon.ClassNames = {}
for _, classToken in ipairs(addon.ClassOrder) do
    addon.ClassNames[classToken] = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[classToken] or classToken
end
