local _, addon = ...

local WHITE_TEX = "Interface\\Buttons\\WHITE8X8"
local SOFT_DOT_MASK = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local CURSOR_SEGMENTS = 72
local PLAYER_RING_SEGMENTS = 48
local TWO_PI = math.pi * 2

-- Animation tuning
local PLAYER_SPIN_SPEED = 0.7   -- radians/sec
local CURSOR_SPIN_SPEED = 0.9   -- radians/sec
local PULSE_SPEED = 3.4         -- breathing frequency
local PULSE_SCALE = 0.07        -- +/- scale amplitude for the player marker
local TRAIL_MAX = 18
local TRAIL_LIFE = 0.42         -- seconds an echo stays visible

local playerFrame
local playerContent
local cursorFrame
local trailFrame
local eventFrame
local trailEchoes = {}
local initialized = false
local previewActive = false
local previewToken = 0

local function Clamp(value, fallback, minimum, maximum)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value < minimum then return minimum end
    if value > maximum then return maximum end
    return value
end

local function EnsureColor(color, defaults)
    if type(color) ~= "table" then color = {} end
    color.r = Clamp(color.r, defaults.r, 0, 1)
    color.g = Clamp(color.g, defaults.g, 0, 1)
    color.b = Clamp(color.b, defaults.b, 0, 1)
    color.a = Clamp(color.a, defaults.a, 0, 1)
    return color
end

local function EnsureDB()
    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    if not profile then return nil end

    profile.personalLocator = profile.personalLocator or {}
    local db = profile.personalLocator

    db.player = db.player or {}
    local player = db.player
    if player.enabled == nil then player.enabled = false end
    if player.combatOnly == nil then player.combatOnly = false end
    if player.style ~= "crosshair" and player.style ~= "brackets"
        and player.style ~= "beacon" and player.style ~= "ring" then
        player.style = "crosshair"
    end
    if player.classColor == nil then player.classColor = false end
    if player.pulse == nil then player.pulse = false end
    if player.spin == nil then player.spin = false end
    player.size = Clamp(player.size, 52, 20, 160)
    player.thickness = Clamp(player.thickness, 3, 1, 12)
    player.outline = Clamp(player.outline, 2, 0, 6)
    player.gap = Clamp(player.gap, 8, 0, 40)
    player.offsetX = Clamp(player.offsetX, 0, -500, 500)
    player.offsetY = Clamp(player.offsetY, -11, -500, 500)
    player.color = EnsureColor(player.color, { r = 0.20, g = 1.00, b = 0.35, a = 0.95 })

    db.cursor = db.cursor or {}
    local cursor = db.cursor
    if cursor.enabled == nil then cursor.enabled = false end
    if cursor.combatOnly == nil then cursor.combatOnly = false end
    if cursor.dot == nil then cursor.dot = false end
    if cursor.pulse == nil then cursor.pulse = false end
    if cursor.classColor == nil then cursor.classColor = false end
    if cursor.spin == nil then cursor.spin = false end
    if cursor.trail == nil then cursor.trail = false end
    if cursor.crosshair == nil then cursor.crosshair = false end
    cursor.size = Clamp(cursor.size, 52, 24, 160)
    cursor.thickness = Clamp(cursor.thickness, 3, 1, 12)
    cursor.outline = Clamp(cursor.outline, 2, 0, 6)
    cursor.color = EnsureColor(cursor.color, { r = 1.00, g = 0.82, b = 0.20, a = 0.95 })

    return db
end

-- Resolve the on-screen color, honoring the optional class-color override. The
-- configured alpha is always kept so transparency stays user-controlled.
local function ResolveColor(cfg)
    if cfg.classColor then
        local ok, _, class = pcall(UnitClass, "player")
        if ok and class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class] then
            local cc = RAID_CLASS_COLORS[class]
            return { r = cc.r, g = cc.g, b = cc.b, a = (cfg.color and cfg.color.a) or 0.95 }
        end
    end
    return cfg.color
end

local function IsPlayerInCombat()
    if type(UnitAffectingCombat) == "function" then
        local ok, value = pcall(UnitAffectingCombat, "player")
        if ok and value == true then return true end
    end
    if type(InCombatLockdown) == "function" then
        local ok, value = pcall(InCombatLockdown)
        if ok and value == true then return true end
    end
    return false
end

-- =====================================================================
-- Player marker
-- =====================================================================

local function CreateMarkerPair(parent)
    local shadow = parent:CreateTexture(nil, "BACKGROUND")
    shadow:SetTexture(WHITE_TEX)
    shadow:SetVertexColor(0, 0, 0, 0.88)

    local line = parent:CreateTexture(nil, "ARTWORK")
    line:SetTexture(WHITE_TEX)

    return { shadow = shadow, line = line }
end

-- Anchor a texture to the player content frame, rotating its position vector
-- around the center by `angle` (used by the optional spin animation).
local function PlacePlayerElement(tex, bx, by, brot, angle)
    local x, y = bx, by
    if angle and angle ~= 0 then
        local c, s = math.cos(angle), math.sin(angle)
        x = bx * c - by * s
        y = bx * s + by * c
    end
    tex:ClearAllPoints()
    tex:SetPoint("CENTER", playerContent, "CENTER", x, y)
    tex:SetRotation((brot or 0) + (angle or 0))
end

local function RecordSpin(list, tex, bx, by, brot)
    if not list then return end
    list[#list + 1] = { tex = tex, bx = bx, by = by, brot = brot or 0 }
end

local function SetMarkerPair(pair, width, height, x, y, rotation, color, outline, spinList)
    pair.shadow:SetSize(width + (outline * 2), height + (outline * 2))
    pair.line:SetSize(width, height)
    pair.line:SetVertexColor(color.r, color.g, color.b, color.a)
    pair.shadow:SetAlpha(math.min(1, color.a + 0.05))
    PlacePlayerElement(pair.shadow, x, y, rotation, 0)
    PlacePlayerElement(pair.line, x, y, rotation, 0)
    pair.shadow:SetShown(outline > 0)
    pair.line:Show()
    if outline > 0 then RecordSpin(spinList, pair.shadow, x, y, rotation) end
    RecordSpin(spinList, pair.line, x, y, rotation)
end

local function EnsurePlayerRing()
    if playerFrame.ringSegments then return end
    playerFrame.ringSegments = {}
    for i = 1, PLAYER_RING_SEGMENTS do
        playerFrame.ringSegments[i] = CreateMarkerPair(playerContent)
    end
end

local function HidePlayerElements()
    if not playerFrame then return end
    for _, pair in ipairs(playerFrame.markerPairs) do
        pair.shadow:Hide()
        pair.line:Hide()
    end
    if playerFrame.ringSegments then
        for _, seg in ipairs(playerFrame.ringSegments) do
            seg.shadow:Hide()
            seg.line:Hide()
        end
    end
    playerFrame.beaconText:Hide()
    playerFrame.beaconShadow:Hide()
end

local function LayoutPlayerMarker()
    local db = EnsureDB()
    if not db or not playerFrame then return end
    local cfg = db.player
    local size = cfg.size
    local thickness = cfg.thickness
    local outline = cfg.outline
    local gap = math.min(cfg.gap, (size / 2) - 2)
    local color = ResolveColor(cfg)

    playerFrame.spinList = {}
    playerFrame:ClearAllPoints()
    playerFrame:SetPoint("CENTER", UIParent, "CENTER", cfg.offsetX, cfg.offsetY)
    playerFrame:SetSize(math.max(200, size * 2), math.max(200, size * 2))
    playerContent:SetSize(math.max(200, size * 2), math.max(200, size * 2))
    HidePlayerElements()

    local spin = playerFrame.spinList

    if cfg.style == "brackets" then
        local extent = size / 2
        local arm = math.max(6, size * 0.28)
        local halfArm = arm / 2

        SetMarkerPair(playerFrame.markerPairs[1], arm, thickness, -extent + halfArm, extent, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[2], thickness, arm, -extent, extent - halfArm, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[3], arm, thickness, extent - halfArm, extent, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[4], thickness, arm, extent, extent - halfArm, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[5], arm, thickness, -extent + halfArm, -extent, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[6], thickness, arm, -extent, -extent + halfArm, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[7], arm, thickness, extent - halfArm, -extent, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[8], thickness, arm, extent, -extent + halfArm, 0, color, outline, spin)
    elseif cfg.style == "ring" then
        EnsurePlayerRing()
        local radius = math.max(8, (size / 2) - (thickness / 2))
        local arcLength = TWO_PI * radius / PLAYER_RING_SEGMENTS
        local segmentSize = math.max(thickness, arcLength * 1.4)
        for i = 1, PLAYER_RING_SEGMENTS do
            local angle = TWO_PI * (i - 1) / PLAYER_RING_SEGMENTS
            local x = math.cos(angle) * radius
            local y = math.sin(angle) * radius
            local seg = playerFrame.ringSegments[i]
            seg.shadow:SetSize(segmentSize + outline * 2, segmentSize + outline * 2)
            seg.line:SetSize(segmentSize, segmentSize)
            seg.shadow:SetVertexColor(0, 0, 0, math.min(1, color.a + 0.05))
            seg.line:SetVertexColor(color.r, color.g, color.b, color.a)
            PlacePlayerElement(seg.shadow, x, y, 0, 0)
            PlacePlayerElement(seg.line, x, y, 0, 0)
            seg.shadow:SetShown(outline > 0)
            seg.line:Show()
            if outline > 0 then RecordSpin(spin, seg.shadow, x, y, 0) end
            RecordSpin(spin, seg.line, x, y, 0)
        end
    elseif cfg.style == "beacon" then
        local stemHeight = math.max(12, size * 0.55)
        local arrowSize = math.max(10, size * 0.32)
        -- nil spinList: the directional beacon should never rotate.
        SetMarkerPair(playerFrame.markerPairs[1], thickness, stemHeight, 0, gap + (stemHeight / 2) + arrowSize, 0, color, outline, nil)

        playerFrame.beaconText:SetFont("Fonts\\FRIZQT__.TTF", arrowSize, "THICKOUTLINE")
        playerFrame.beaconText:SetTextColor(color.r, color.g, color.b, color.a)
        playerFrame.beaconText:ClearAllPoints()
        playerFrame.beaconText:SetPoint("CENTER", playerContent, "CENTER", 0, gap + arrowSize * 0.42)
        playerFrame.beaconText:Show()

        playerFrame.beaconShadow:SetFont("Fonts\\FRIZQT__.TTF", arrowSize + math.max(2, outline), "THICKOUTLINE")
        playerFrame.beaconShadow:SetTextColor(0, 0, 0, math.min(1, color.a + 0.05))
        playerFrame.beaconShadow:ClearAllPoints()
        playerFrame.beaconShadow:SetPoint("CENTER", playerFrame.beaconText, "CENTER", 0, -1)
        playerFrame.beaconShadow:SetShown(outline > 0)
    else
        local arm = math.max(4, (size / 2) - gap)
        local center = gap + (arm / 2)
        SetMarkerPair(playerFrame.markerPairs[1], arm, thickness, -center, 0, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[2], arm, thickness, center, 0, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[3], thickness, arm, 0, center, 0, color, outline, spin)
        SetMarkerPair(playerFrame.markerPairs[4], thickness, arm, 0, -center, 0, color, outline, spin)
    end
end

local function RotatePlayer(angle)
    if not playerFrame or not playerFrame.spinList then return end
    local list = playerFrame.spinList
    for i = 1, #list do
        local e = list[i]
        PlacePlayerElement(e.tex, e.bx, e.by, e.brot, angle)
    end
end

local function PlayerOnUpdate(self, elapsed)
    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    local cfg = profile and profile.personalLocator and profile.personalLocator.player
    if not cfg then return end

    if cfg.spin then
        self.spinAngle = ((self.spinAngle or 0) + (elapsed or 0) * PLAYER_SPIN_SPEED) % TWO_PI
        RotatePlayer(self.spinAngle)
    end

    if cfg.pulse and playerContent then
        self.pulseT = (self.pulseT or 0) + (elapsed or 0)
        local wave = math.sin(self.pulseT * PULSE_SPEED)
        playerContent:SetScale(1 + wave * PULSE_SCALE)
        playerContent:SetAlpha(0.82 + wave * 0.18)
    end
end

local function CreatePlayerFrame()
    if playerFrame then return playerFrame end

    playerFrame = CreateFrame("Frame", "EnragePersonalLocatorPlayerFrame", UIParent)
    playerFrame:SetFrameStrata("HIGH")
    playerFrame:SetFrameLevel(50)
    playerFrame:EnableMouse(false)

    playerContent = CreateFrame("Frame", nil, playerFrame)
    playerContent:SetPoint("CENTER", playerFrame, "CENTER")
    playerContent:SetSize(200, 200)
    playerContent:EnableMouse(false)
    playerFrame.content = playerContent

    playerFrame.markerPairs = {}
    for i = 1, 8 do
        playerFrame.markerPairs[i] = CreateMarkerPair(playerContent)
    end
    playerFrame.spinList = {}

    playerFrame.beaconShadow = playerContent:CreateFontString(nil, "BACKGROUND", "GameFontNormal")
    playerFrame.beaconShadow:SetText("▼")
    playerFrame.beaconText = playerContent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    playerFrame.beaconText:SetText("▼")
    playerFrame:Hide()
    return playerFrame
end

-- =====================================================================
-- Cursor trail (fading soft-dot echoes left at previous cursor positions)
-- =====================================================================

local function EnsureTrailFrame()
    if trailFrame then return end
    trailFrame = CreateFrame("Frame", "EnragePersonalLocatorTrailFrame", UIParent)
    trailFrame:SetFrameStrata("TOOLTIP")
    trailFrame:SetFrameLevel(78)
    trailFrame:SetAllPoints(UIParent)
    trailFrame:EnableMouse(false)
end

local function AcquireEcho()
    for i = 1, #trailEchoes do
        if not trailEchoes[i].active then return trailEchoes[i] end
    end
    if #trailEchoes >= TRAIL_MAX then
        local oldest = trailEchoes[1]
        for i = 2, #trailEchoes do
            if trailEchoes[i].life < oldest.life then oldest = trailEchoes[i] end
        end
        return oldest
    end
    EnsureTrailFrame()
    local tex = trailFrame:CreateTexture(nil, "ARTWORK")
    tex:SetTexture(WHITE_TEX)
    tex:SetBlendMode("ADD")
    local mask = trailFrame:CreateMaskTexture()
    mask:SetTexture(SOFT_DOT_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    tex:AddMaskTexture(mask)
    local echo = { tex = tex, mask = mask, active = false, life = 0, maxLife = TRAIL_LIFE, size = 8 }
    trailEchoes[#trailEchoes + 1] = echo
    return echo
end

local function SpawnEcho(x, y, size, color)
    local echo = AcquireEcho()
    echo.active = true
    echo.life = TRAIL_LIFE
    echo.maxLife = TRAIL_LIFE
    echo.size = size
    echo.tex:SetVertexColor(color.r, color.g, color.b, color.a)
    echo.tex:SetSize(size, size)
    echo.tex:ClearAllPoints()
    echo.tex:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y)
    echo.mask:ClearAllPoints()
    echo.mask:SetAllPoints(echo.tex)
    echo.tex:Show()
end

local function UpdateEchoes(elapsed)
    for i = 1, #trailEchoes do
        local e = trailEchoes[i]
        if e.active then
            e.life = e.life - (elapsed or 0)
            if e.life <= 0 then
                e.active = false
                e.tex:Hide()
            else
                local f = e.life / e.maxLife
                e.tex:SetAlpha(f * 0.7)
                local s = e.size * (0.45 + 0.55 * f)
                e.tex:SetSize(s, s)
                e.mask:SetAllPoints(e.tex)
            end
        end
    end
end

local function HideAllEchoes()
    for i = 1, #trailEchoes do
        local e = trailEchoes[i]
        e.active = false
        e.life = 0
        if e.tex then e.tex:Hide() end
    end
end

-- =====================================================================
-- Cursor ring
-- =====================================================================

local function CreateCursorFrame()
    if cursorFrame then return cursorFrame end

    cursorFrame = CreateFrame("Frame", "EnragePersonalLocatorCursorFrame", UIParent)
    cursorFrame:SetFrameStrata("TOOLTIP")
    cursorFrame:SetFrameLevel(80)
    cursorFrame:SetSize(180, 180)
    cursorFrame:EnableMouse(false)
    cursorFrame.outlineSegments = {}
    cursorFrame.ringSegments = {}
    cursorFrame.spinList = {}

    for i = 1, CURSOR_SEGMENTS do
        local outline = cursorFrame:CreateTexture(nil, "BACKGROUND")
        outline:SetTexture(WHITE_TEX)
        outline:SetVertexColor(0, 0, 0, 0.90)
        cursorFrame.outlineSegments[i] = outline

        local segment = cursorFrame:CreateTexture(nil, "ARTWORK")
        segment:SetTexture(WHITE_TEX)
        segment:SetBlendMode("ADD")
        cursorFrame.ringSegments[i] = segment
    end

    -- Optional precision crosshair through the cursor center (built lazily).
    cursorFrame.crossPool = {}

    cursorFrame.dotShadow = cursorFrame:CreateFontString(nil, "BACKGROUND", "GameFontNormal")
    cursorFrame.dotShadow:SetText("●")
    cursorFrame.dotShadow:SetPoint("CENTER", cursorFrame, "CENTER", 1, -1)
    cursorFrame.dot = cursorFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    cursorFrame.dot:SetText("●")
    cursorFrame.dot:SetPoint("CENTER")
    cursorFrame:Hide()
    return cursorFrame
end

local function PlaceCursorElement(tex, bx, by, angle)
    local x, y = bx, by
    if angle and angle ~= 0 then
        local c, s = math.cos(angle), math.sin(angle)
        x = bx * c - by * s
        y = bx * s + by * c
    end
    tex:ClearAllPoints()
    tex:SetPoint("CENTER", cursorFrame, "CENTER", x, y)
end

local function LayoutCursorRing()
    local db = EnsureDB()
    if not db or not cursorFrame then return end
    local cfg = db.cursor
    local radius = math.max(6, (cfg.size / 2) - (cfg.thickness / 2))
    local arcLength = TWO_PI * radius / CURSOR_SEGMENTS
    local segmentSize = math.max(cfg.thickness, arcLength * 1.35)
    local outline = cfg.outline
    local color = ResolveColor(cfg)

    cursorFrame.spinList = {}
    cursorFrame:SetSize(cfg.size + 20, cfg.size + 20)
    for i = 1, CURSOR_SEGMENTS do
        local angle = TWO_PI * (i - 1) / CURSOR_SEGMENTS
        local x = math.cos(angle) * radius
        local y = math.sin(angle) * radius
        local background = cursorFrame.outlineSegments[i]
        local segment = cursorFrame.ringSegments[i]

        background:SetSize(segmentSize + outline * 2, segmentSize + outline * 2)
        segment:SetSize(segmentSize, segmentSize)
        PlaceCursorElement(background, x, y, 0)
        PlaceCursorElement(segment, x, y, 0)
        background:SetVertexColor(0, 0, 0, math.min(1, color.a + 0.05))
        segment:SetVertexColor(color.r, color.g, color.b, color.a)
        background:SetShown(outline > 0)
        segment:Show()
        cursorFrame.spinList[#cursorFrame.spinList + 1] = { tex = background, bx = x, by = y }
        cursorFrame.spinList[#cursorFrame.spinList + 1] = { tex = segment, bx = x, by = y }
    end

    -- Precision crosshair lines through the cursor.
    local showCross = cfg.crosshair
    local arm = math.max(8, cfg.size * 0.5)
    local thickness = cfg.thickness
    local gap = math.max(2, cfg.size * 0.12)
    local crossArm = math.max(4, (arm - gap))
    local crossOffset = gap + (crossArm / 2)
    local crossPairs = {
        { crossArm, thickness, -crossOffset, 0 },
        { crossArm, thickness, crossOffset, 0 },
        { thickness, crossArm, 0, crossOffset },
        { thickness, crossArm, 0, -crossOffset },
    }
    if showCross then
        cursorFrame.crossPool = cursorFrame.crossPool or {}
        for idx, spec in ipairs(crossPairs) do
            local pair = cursorFrame.crossPool[idx]
            if not pair then
                pair = CreateMarkerPair(cursorFrame)
                cursorFrame.crossPool[idx] = pair
            end
            local w, h, cx, cy = spec[1], spec[2], spec[3], spec[4]
            pair.shadow:SetSize(w + outline * 2, h + outline * 2)
            pair.line:SetSize(w, h)
            PlaceCursorElement(pair.shadow, cx, cy, 0)
            PlaceCursorElement(pair.line, cx, cy, 0)
            pair.shadow:SetVertexColor(0, 0, 0, math.min(1, color.a + 0.05))
            pair.line:SetVertexColor(color.r, color.g, color.b, color.a)
            pair.shadow:SetShown(outline > 0)
            pair.line:Show()
        end
    elseif cursorFrame.crossPool then
        for _, pair in ipairs(cursorFrame.crossPool) do
            pair.shadow:Hide()
            pair.line:Hide()
        end
    end

    local dotSize = math.max(9, cfg.thickness * 3.2)
    cursorFrame.dot:SetFont("Fonts\\FRIZQT__.TTF", dotSize, "THICKOUTLINE")
    cursorFrame.dot:SetTextColor(color.r, color.g, color.b, color.a)
    cursorFrame.dotShadow:SetFont("Fonts\\FRIZQT__.TTF", dotSize + math.max(2, outline), "THICKOUTLINE")
    cursorFrame.dotShadow:SetTextColor(0, 0, 0, math.min(1, color.a + 0.05))
    cursorFrame.dot:SetShown(cfg.dot)
    cursorFrame.dotShadow:SetShown(cfg.dot)
end

local function RotateCursor(angle)
    if not cursorFrame or not cursorFrame.spinList then return end
    local list = cursorFrame.spinList
    for i = 1, #list do
        local e = list[i]
        PlaceCursorElement(e.tex, e.bx, e.by, angle)
    end
end

local function CursorOnUpdate(self, elapsed)
    local x, y = GetCursorPosition()
    local scale = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
    if not scale or scale <= 0 then scale = 1 end
    x, y = x / scale, y / scale

    local prevX, prevY = self.lastX, self.lastY
    local moved = (not prevX) or math.abs(x - prevX) > 0.05 or math.abs(y - prevY) > 0.05
    if moved then
        self.lastX, self.lastY = x, y
        self:ClearAllPoints()
        self:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y)
    end

    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    local cfg = profile and profile.personalLocator and profile.personalLocator.cursor

    -- Fading motion trail
    if cfg and cfg.trail then
        if moved and prevX then
            local dx, dy = x - prevX, y - prevY
            self.trailDist = (self.trailDist or 0) + math.sqrt(dx * dx + dy * dy)
            local step = math.max(6, cfg.size * 0.16)
            if self.trailDist >= step then
                self.trailDist = 0
                local color = ResolveColor(cfg)
                SpawnEcho(prevX, prevY, math.max(6, cfg.size * 0.22), color)
            end
        end
    end
    UpdateEchoes(elapsed)

    -- Spin
    if cfg and cfg.spin then
        self.spinAngle = ((self.spinAngle or 0) + (elapsed or 0) * CURSOR_SPIN_SPEED) % TWO_PI
        RotateCursor(self.spinAngle)
    end

    -- Soft alpha pulse
    if cfg and cfg.pulse then
        self.pulseElapsed = (self.pulseElapsed or 0) + (elapsed or 0)
        self:SetAlpha(0.78 + (math.sin(self.pulseElapsed * 4.5) * 0.18))
    elseif self:GetAlpha() ~= 1 then
        self:SetAlpha(1)
    end
end

-- =====================================================================
-- Visibility / lifecycle
-- =====================================================================

local function RefreshVisibility()
    local db = EnsureDB()
    if not db then return end
    CreatePlayerFrame()
    CreateCursorFrame()

    local inCombat = IsPlayerInCombat()
    local showPlayer = previewActive or (db.player.enabled and (not db.player.combatOnly or inCombat))
    local showCursor = previewActive or (db.cursor.enabled and (not db.cursor.combatOnly or inCombat))

    playerFrame:SetShown(showPlayer)
    local playerAnimated = showPlayer and (db.player.spin or db.player.pulse)
    playerFrame:SetScript("OnUpdate", playerAnimated and PlayerOnUpdate or nil)
    if not playerAnimated then
        playerFrame.spinAngle = 0
        playerFrame.pulseT = 0
        if playerContent then
            playerContent:SetScale(1)
            playerContent:SetAlpha(1)
        end
    end

    cursorFrame:SetShown(showCursor)
    cursorFrame:SetScript("OnUpdate", showCursor and CursorOnUpdate or nil)
    if not showCursor then
        cursorFrame.lastX, cursorFrame.lastY = nil, nil
        cursorFrame.pulseElapsed = 0
        cursorFrame.spinAngle = 0
        cursorFrame.trailDist = 0
        cursorFrame:SetAlpha(1)
        HideAllEchoes()
    elseif not db.cursor.trail then
        HideAllEchoes()
    end
end

function addon:RefreshPersonalLocator()
    CreatePlayerFrame()
    CreateCursorFrame()
    LayoutPlayerMarker()
    LayoutCursorRing()
    RefreshVisibility()
end

function addon:PreviewPersonalLocator()
    previewToken = previewToken + 1
    local token = previewToken
    previewActive = true
    addon:RefreshPersonalLocator()

    if C_Timer and C_Timer.After then
        C_Timer.After(8, function()
            if token ~= previewToken then return end
            previewActive = false
            addon:RefreshPersonalLocator()
        end)
    end
end

function addon:InitializePersonalLocator()
    EnsureDB()
    CreatePlayerFrame()
    CreateCursorFrame()

    if not initialized then
        initialized = true
        eventFrame = CreateFrame("Frame", "EnragePersonalLocatorEventFrame")
        eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
        eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
        eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        eventFrame:RegisterEvent("DISPLAY_SIZE_CHANGED")
        eventFrame:RegisterEvent("UI_SCALE_CHANGED")
        eventFrame:SetScript("OnEvent", function()
            addon:RefreshPersonalLocator()
        end)
    end

    addon:RefreshPersonalLocator()
end

function addon:DisablePersonalLocator()
    previewActive = false
    previewToken = previewToken + 1
    if playerFrame then
        playerFrame:SetScript("OnUpdate", nil)
        playerFrame:Hide()
    end
    if cursorFrame then
        cursorFrame:SetScript("OnUpdate", nil)
        cursorFrame:Hide()
    end
    HideAllEchoes()
end
