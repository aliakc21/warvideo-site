local ADDON_NAME, addon = ...

local PI_SPELL_ID = 10060
local PI_SPELL_NAME = "Power Infusion"
local DEFAULT_MESSAGE = "you have pi"

local eventFrame
local alertFrame
local pollTicker
local hadPI = false
local lastAlertTime = 0
local hideToken = 0
local checkToken = 0
local ADDON_MEDIA_PATH = "Interface\\AddOns\\" .. (ADDON_NAME or "AkcQOL") .. "\\Media\\"

local PI_SOUND_STYLE_ORDER = {
    "arcane",
    "double",
    "urgent",
    "bell",
    "alarm",
    "crystal",
    "triple",
    "surge",
    "focus",
    "deepbell",
    "cleanalert",
    "fastalarm",
    "sweep",
    "catmeow",
    "catplead",
    "dogbark",
    "prairiebark",
    "rooster",
    "goat",
    "duck",
    "moo",
}

local PI_SOUND_STYLES = {
    arcane = {
        label = "Arcane Chime",
        file = ADDON_MEDIA_PATH .. "pi-arcane.ogg",
    },
    double = {
        label = "Double Ping",
        file = ADDON_MEDIA_PATH .. "pi-double.ogg",
    },
    urgent = {
        label = "Urgent Pulse",
        file = ADDON_MEDIA_PATH .. "pi-urgent.ogg",
    },
    bell = {
        label = "Bright Bell",
        file = ADDON_MEDIA_PATH .. "pi-bell.ogg",
    },
    alarm = {
        label = "Short Alarm",
        file = ADDON_MEDIA_PATH .. "pi-alarm.ogg",
    },
    crystal = {
        label = "Crystal Ping",
        file = ADDON_MEDIA_PATH .. "pi-crystal.ogg",
    },
    triple = {
        label = "Triple Ping",
        file = ADDON_MEDIA_PATH .. "pi-triple.ogg",
    },
    surge = {
        label = "Power Surge",
        file = ADDON_MEDIA_PATH .. "pi-surge.ogg",
    },
    focus = {
        label = "Focus Pop",
        file = ADDON_MEDIA_PATH .. "pi-focus.ogg",
    },
    deepbell = {
        label = "Deep Bell",
        file = ADDON_MEDIA_PATH .. "pi-deepbell.ogg",
    },
    cleanalert = {
        label = "Clean Alert",
        file = ADDON_MEDIA_PATH .. "pi-cleanalert.ogg",
    },
    fastalarm = {
        label = "Fast Alarm",
        file = ADDON_MEDIA_PATH .. "pi-fastalarm.ogg",
    },
    sweep = {
        label = "Magic Sweep",
        file = ADDON_MEDIA_PATH .. "pi-sweep.ogg",
    },
    catmeow = {
        label = "Cat Meow",
        file = ADDON_MEDIA_PATH .. "pi-cat-meow.ogg",
    },
    catplead = {
        label = "Pleading Cat",
        file = ADDON_MEDIA_PATH .. "pi-cat-plead.ogg",
    },
    dogbark = {
        label = "Dog Bark",
        file = ADDON_MEDIA_PATH .. "pi-dog-bark.ogg",
    },
    prairiebark = {
        label = "Prairie Bark",
        file = ADDON_MEDIA_PATH .. "pi-prairie-bark.ogg",
    },
    rooster = {
        label = "Rooster",
        file = ADDON_MEDIA_PATH .. "pi-rooster.ogg",
    },
    goat = {
        label = "Goat",
        file = ADDON_MEDIA_PATH .. "pi-goat.ogg",
    },
    duck = {
        label = "Duck",
        file = ADDON_MEDIA_PATH .. "pi-duck.ogg",
    },
    moo = {
        label = "Moo",
        file = ADDON_MEDIA_PATH .. "pi-moo.ogg",
    },
}

local DEFAULT_SOUND_STYLE = "arcane"
local DEFAULT_SOUND_VOLUME = 100

local function IsSecret(value)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        if ok and isSecret == true then return true end
    end
    return type(value) == "nil"
end

local function SafeString(value)
    if IsSecret(value) then return nil end
    local ok, text = pcall(tostring, value)
    if ok and type(text) == "string" and text ~= "" then return text end
    return nil
end

local function SafeNumber(value)
    if IsSecret(value) or type(value) ~= "number" then return nil end
    return value
end

local function NormalizeSoundStyle(style)
    if PI_SOUND_STYLES[style or ""] then
        return style
    end
    return DEFAULT_SOUND_STYLE
end

local function NormalizeSoundVolume(volume)
    volume = tonumber(volume) or DEFAULT_SOUND_VOLUME
    if volume <= 25 then return 25 end
    if volume <= 50 then return 50 end
    if volume <= 75 then return 75 end
    return 100
end

local function GetPISpellName()
    if C_Spell and C_Spell.GetSpellName then
        local ok, name = pcall(C_Spell.GetSpellName, PI_SPELL_ID)
        if ok then
            name = SafeString(name)
            if name then return name end
        end
    end

    if GetSpellInfo then
        local ok, name = pcall(GetSpellInfo, PI_SPELL_ID)
        if ok then
            name = SafeString(name)
            if name then return name end
        end
    end

    return PI_SPELL_NAME
end

local function AuraIsPowerInfusion(aura)
    if type(aura) ~= "table" then return false end

    local spellID = aura.spellId
    if IsSecret(spellID) then spellID = aura.spellID end
    spellID = SafeNumber(spellID)
    if spellID == PI_SPELL_ID then return true end

    local auraName = SafeString(aura.name)
    if not auraName then return false end

    local localizedName = GetPISpellName()
    return auraName == PI_SPELL_NAME or auraName == localizedName
end

local function IsPowerInfusionSpell(spellID, spellName)
    spellID = SafeNumber(spellID)
    if spellID == PI_SPELL_ID then return true end

    spellName = SafeString(spellName)
    if not spellName then return false end

    local localizedName = GetPISpellName()
    return spellName == PI_SPELL_NAME or spellName == localizedName
end

local function GetDB()
    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    if not profile then return nil end

    profile.piAlert = profile.piAlert or {}
    local db = profile.piAlert
    if db.enabled == nil then db.enabled = false end
    if db.screen == nil then db.screen = false end
    if db.sound == nil then db.sound = false end
    db.soundStyle = NormalizeSoundStyle(db.soundStyle)
    db.soundVolume = NormalizeSoundVolume(db.soundVolume)
    if db.message == nil or db.message == "" then db.message = DEFAULT_MESSAGE end
    if db.throttle == nil then db.throttle = 2 end
    return db
end

local function HasPowerInfusion()
    local piName = GetPISpellName()

    -- Retail's direct spell-ID lookup is both the cheapest and the most
    -- reliable path. When the API call succeeds, nil definitively means that
    -- the player does not currently have PI, so avoid scanning every aura.
    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok, aura = pcall(C_UnitAuras.GetPlayerAuraBySpellID, PI_SPELL_ID)
        if ok then
            return type(aura) == "table"
        end
    end

    if AuraUtil and AuraUtil.FindAuraBySpellID then
        local ok, name = pcall(AuraUtil.FindAuraBySpellID, PI_SPELL_ID, "player", "HELPFUL")
        if ok then
            return not IsSecret(name)
        end
    end

    if AuraUtil and AuraUtil.FindAuraByName then
        local ok, name, _, _, _, _, _, _, _, spellID = pcall(AuraUtil.FindAuraByName, piName, "player", "HELPFUL")
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end

        ok, name, _, _, _, _, _, _, _, spellID = pcall(AuraUtil.FindAuraByName, PI_SPELL_NAME, "player", "HELPFUL")
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end
    end

    if C_UnitAuras and C_UnitAuras.GetBuffDataByIndex then
        for i = 1, 80 do
            local ok, aura = pcall(C_UnitAuras.GetBuffDataByIndex, "player", i)
            if not ok or not aura then break end
            if AuraIsPowerInfusion(aura) then return true end
        end
    end

    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 200 do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not aura then break end
            if AuraIsPowerInfusion(aura) then return true end
        end
    end

    if UnitBuff then
        local ok, name, _, _, _, _, _, _, _, _, spellID = pcall(UnitBuff, "player", piName)
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end

        for i = 1, 200 do
            ok, name, _, _, _, _, _, _, _, _, spellID = pcall(UnitBuff, "player", i)
            if not ok or IsSecret(name) then break end
            if SafeNumber(spellID) == PI_SPELL_ID then return true end

            local auraName = SafeString(name)
            if auraName == PI_SPELL_NAME or auraName == piName then return true end
        end
    end

    return false
end

local function EnsureAlertFrame()
    if alertFrame then return alertFrame end

    local frame = CreateFrame("Frame", "EnragePIAlertFrame", UIParent)
    frame:SetSize(420, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 145)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(20)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(0.72, 0.45, 1, 1)
    frame.text:SetText("YOU HAVE PI")

    alertFrame = frame
    return alertFrame
end

local function ShowScreenAlert(message)
    local frame = EnsureAlertFrame()
    frame.text:SetText(string.upper(message or DEFAULT_MESSAGE))
    frame:SetAlpha(1)
    frame:Show()

    hideToken = hideToken + 1
    local token = hideToken
    C_Timer.After(1.8, function()
        if hideToken ~= token or not alertFrame then return end
        alertFrame:Hide()
    end)
end

local function GetSoundFileName(soundFile)
    soundFile = SafeString(soundFile)
    if not soundFile then return nil end

    local startIndex = 1
    for i = 1, #soundFile do
        local byte = soundFile:byte(i)
        if byte == 47 or byte == 92 then
            startIndex = i + 1
        end
    end

    return soundFile:sub(startIndex)
end

local function GetSoundFile(style, volume)
    local entry = PI_SOUND_STYLES[NormalizeSoundStyle(style)]
    if not entry or not entry.file then return nil end

    local level = NormalizeSoundVolume(volume)
    if level == 100 then
        return entry.file
    end

    return ADDON_MEDIA_PATH .. "Volume" .. level .. "\\" .. GetSoundFileName(entry.file)
end

function addon:GetPIAlertSoundOptions()
    local values = {}
    for _, key in ipairs(PI_SOUND_STYLE_ORDER) do
        local entry = PI_SOUND_STYLES[key]
        if entry then
            values[key] = entry.label or key
        end
    end
    return values
end

function addon:GetPIAlertSoundOrder()
    return PI_SOUND_STYLE_ORDER
end

local function PlayAlertSound(style, volume)
    if not PlaySoundFile then return end

    local soundFile = GetSoundFile(style, volume)
    if soundFile then
        local ok, willPlay = pcall(PlaySoundFile, soundFile, "Master")
        if not ok or willPlay == false then
            pcall(PlaySoundFile, soundFile)
        end
    end
end

local function FireAlert(force, forceSound)
    local db = GetDB()
    if not db or (not force and not db.enabled) then return end

    local now = GetTime and GetTime() or 0
    if not force and now - lastAlertTime < (db.throttle or 2) then return end
    lastAlertTime = now

    local message = db.message or DEFAULT_MESSAGE
    if not force then
        print("|cff00ccffEnrage:|r |cffff66ff" .. string.upper(message) .. "|r")
    end

    if db.sound or forceSound then
        PlayAlertSound(db.soundStyle, db.soundVolume)
    end

    if db.screen then
        ShowScreenAlert(message)
        if UIErrorsFrame and UIErrorsFrame.AddMessage then
            UIErrorsFrame:AddMessage(string.upper(message), 0.72, 0.45, 1, 1)
        end
    end

end

local function CheckPIState(silent)
    local hasPI = HasPowerInfusion()
    if hasPI and not hadPI and not silent then
        FireAlert(false)
    end
    hadPI = hasPI
end

function addon:HandlePICombatLogEvent(subevent, destGUID, spellID, spellName)
    subevent = SafeString(subevent)
    if subevent ~= "SPELL_AURA_APPLIED" and subevent ~= "SPELL_AURA_REFRESH" then return end

    local playerGUID = UnitGUID and SafeString(UnitGUID("player"))
    if not playerGUID or SafeString(destGUID) ~= playerGUID then return end
    if not IsPowerInfusionSpell(spellID, spellName) then return end

    if not hadPI then
        FireAlert(false)
    else
        local now = GetTime and GetTime() or 0
        local db = GetDB()
        if db and now - lastAlertTime >= (db.throttle or 2) and subevent == "SPELL_AURA_APPLIED" then
            FireAlert(false)
        end
    end

    hadPI = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0.2, function() CheckPIState(true) end)
    end
end

local function QueuePIStateCheck(silent)
    checkToken = checkToken + 1
    local token = checkToken

    CheckPIState(silent)
    if not C_Timer or not C_Timer.After then return end

    C_Timer.After(0.05, function()
        if token == checkToken then CheckPIState(silent) end
    end)
    C_Timer.After(0.25, function()
        if token == checkToken then CheckPIState(silent) end
    end)
end

function addon:InitializePIAlert()
    local db = GetDB()
    if not db or not db.enabled then return end

    if not eventFrame then
        eventFrame = CreateFrame("Frame", "EnragePIAlertEventFrame")
        eventFrame:SetScript("OnEvent", function(_, event, unit)
            if event == "UNIT_AURA" then
                if unit == "player" or unit == nil then QueuePIStateCheck(false) end
            elseif event == "PLAYER_ENTERING_WORLD" then
                C_Timer.After(1, function() QueuePIStateCheck(true) end)
            elseif event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
                QueuePIStateCheck(true)
            end
        end)
    end

    EnsureAlertFrame()

    eventFrame:UnregisterAllEvents()
    eventFrame:RegisterEvent("UNIT_AURA")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")

    if pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
    end
    -- UNIT_AURA and CLEU provide the immediate alert. This is only a safety
    -- fallback for restricted/tainted event windows.
    pollTicker = C_Timer.NewTicker(0.5, function()
        CheckPIState(false)
    end)

    QueuePIStateCheck(true)
end

function addon:DisablePIAlert()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
        eventFrame:SetScript("OnUpdate", nil)
    end
    if pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
    end
    if alertFrame then
        alertFrame:Hide()
    end
end

function addon:TestPIAlert()
    FireAlert(true, true)
end

function addon:TestPIAlertSound()
    local db = GetDB()
    PlayAlertSound(db and db.soundStyle, db and db.soundVolume)
    print("|cff00ccffEnrage:|r PI sound test played.")
end
