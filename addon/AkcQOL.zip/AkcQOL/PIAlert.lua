local ADDON_NAME, addon = ...

local PI_SPELL_ID = 10060
local PI_SPELL_NAME = "Power Infusion"
local DEFAULT_MESSAGE = "you have pi"

local eventFrame
local alertFrame
local pollTicker
local hadPI = false
local lastAlertTime = 0
local hideToken = 0
local checkToken = 0

-- WoW built-in alert sounds (SoundKit). Built at load: any candidate whose
-- SOUNDKIT constant is missing on this client is skipped, so there are never any
-- broken options. (Replaces the old bundled .ogg sound files.)
local PI_SOUND_CANDIDATES = {
    { key = "raidwarning", label = "Raid Warning",   kit = "RAID_WARNING", id = 8959 },
    { key = "readycheck",  label = "Ready Check",     kit = "READY_CHECK" },
    { key = "alarm",       label = "Alarm Clock",     kit = "ALARM_CLOCK_WARNING_3" },
    { key = "bosswarn",    label = "Boss Warning",    kit = "UI_RAID_BOSS_WHISPER_WARNING" },
    { key = "questdone",   label = "Quest Complete",  kit = "IG_QUEST_LIST_COMPLETE" },
    { key = "ping",        label = "Map Ping",        kit = "MAP_PING" },
    { key = "whisper",     label = "Whisper",         kit = "TELL_MESSAGE" },
    { key = "queue",       label = "Queue Pop",       kit = "PVP_THROUGH_QUEUE" },
    { key = "auction",     label = "Auction Bell",    kit = "AUCTION_WINDOW_OPEN" },
    { key = "invite",      label = "Group Invite",    kit = "IG_PLAYER_INVITE_A" },
    { key = "levelup",     label = "Level Up",        kit = "LEVELUP" },
}

local PI_SOUND_STYLE_ORDER = {}
local PI_SOUND_STYLES = {}
for _, c in ipairs(PI_SOUND_CANDIDATES) do
    local id = (type(SOUNDKIT) == "table" and SOUNDKIT[c.kit]) or c.id
    if type(id) == "number" then
        PI_SOUND_STYLES[c.key] = { label = c.label, soundId = id }
        PI_SOUND_STYLE_ORDER[#PI_SOUND_STYLE_ORDER + 1] = c.key
    end
end

-- Categorized structure for the native submenu picker (mirrors WoW's Cooldown Manager menu):
-- an ordered list of { label = <category>, entries = { { key=, name= }, ... } }. The 11 built-in
-- alert sounds are the first "Alerts" category; CooldownViewer categories are appended lazily.
local PI_SOUND_MENU = { { label = "Alerts", entries = {} } }
for _, key in ipairs(PI_SOUND_STYLE_ORDER) do
    local e = PI_SOUND_STYLES[key]
    PI_SOUND_MENU[1].entries[#PI_SOUND_MENU[1].entries + 1] = { key = key, name = e.label }
end

-- WoW's built-in Cooldown Manager exposes ALL its categorized "Sound Alert" sounds as a
-- global table (CooldownViewerSoundData), shipped in the load-on-demand Blizzard_CooldownViewer
-- addon. We layer every one of them onto our list so the PI/Pet sound dropdown offers the same
-- sounds the game's own alert picker does. Keys are "cdm<soundKitID>" (stable across sessions);
-- the list is built lazily the first time a sound dropdown is opened. (Text-to-Speech lives in a
-- separate Blizzard path, not in this table, so it is intentionally not included.)
local CDM_CATEGORY_ORDER = { "Instruments", "Animals", "Impacts", "War3", "War2", "Devices" }
local CDM_CATEGORY_LABEL = {
    Instruments = "Instruments", Animals = "Animals", Impacts = "Impacts",
    War3 = "Warcraft 3", War2 = "Warcraft 2", Devices = "Devices",
}
local cdmSoundsBuilt = false
local function EnsureCDMSounds()
    if cdmSoundsBuilt then return end
    if C_AddOns and C_AddOns.LoadAddOn then
        pcall(C_AddOns.LoadAddOn, "Blizzard_CooldownViewer")
    end
    local data = rawget(_G, "CooldownViewerSoundData")
    if type(data) ~= "table" then return end  -- not loaded yet; retry next time a dropdown opens
    cdmSoundsBuilt = true
    for _, cat in ipairs(CDM_CATEGORY_ORDER) do
        local entries = data[cat]
        if type(entries) == "table" then
            local catLabel = CDM_CATEGORY_LABEL[cat] or cat
            local menuCat = { label = catLabel, entries = {} }
            for _, e in ipairs(entries) do
                local id, text = e.soundKitID, e.text
                if type(id) == "number" and type(text) == "string" and text ~= "" then
                    local key = "cdm" .. id
                    if not PI_SOUND_STYLES[key] then
                        PI_SOUND_STYLES[key] = { label = catLabel .. ": " .. text, soundId = id }
                        PI_SOUND_STYLE_ORDER[#PI_SOUND_STYLE_ORDER + 1] = key
                    end
                    menuCat.entries[#menuCat.entries + 1] = { key = key, name = text }
                end
            end
            if #menuCat.entries > 0 then
                PI_SOUND_MENU[#PI_SOUND_MENU + 1] = menuCat
            end
        end
    end
end

local function IsCDMSoundKey(style)
    return type(style) == "string" and style:match("^cdm%d+$") ~= nil
end

local DEFAULT_SOUND_STYLE = "raidwarning"
local DEFAULT_SOUND_VOLUME = 100

local function IsSecret(value)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        if ok and isSecret == true then return true end
    end
    return type(value) == "nil"
end

-- Strict: true ONLY for an actual secret value, NOT for nil. (IsSecret() conflates the two,
-- which is wrong when we need to tell "buff absent" (nil) from "buff present but secret".)
local function IsSecretStrict(value)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        return ok and isSecret == true
    end
    return false
end

local function SafeString(value)
    if IsSecret(value) then return nil end
    local ok, text = pcall(tostring, value)
    if ok and type(text) == "string" and text ~= "" then return text end
    return nil
end

local function SafeNumber(value)
    if IsSecret(value) or type(value) ~= "number" then return nil end
    return value
end

local function NormalizeSoundStyle(style)
    if PI_SOUND_STYLES[style or ""] or IsCDMSoundKey(style) then
        return style
    end
    return DEFAULT_SOUND_STYLE
end

local function NormalizeSoundVolume(volume)
    volume = tonumber(volume) or DEFAULT_SOUND_VOLUME
    if volume < 0 then volume = 0 elseif volume > 100 then volume = 100 end
    return math.floor(volume + 0.5)
end

local function GetPISpellName()
    if C_Spell and C_Spell.GetSpellName then
        local ok, name = pcall(C_Spell.GetSpellName, PI_SPELL_ID)
        if ok then
            name = SafeString(name)
            if name then return name end
        end
    end

    if GetSpellInfo then
        local ok, name = pcall(GetSpellInfo, PI_SPELL_ID)
        if ok then
            name = SafeString(name)
            if name then return name end
        end
    end

    return PI_SPELL_NAME
end

local function AuraIsPowerInfusion(aura)
    if type(aura) ~= "table" then return false end

    local spellID = aura.spellId
    if IsSecret(spellID) then spellID = aura.spellID end
    spellID = SafeNumber(spellID)
    if spellID == PI_SPELL_ID then return true end

    local auraName = SafeString(aura.name)
    if not auraName then return false end

    local localizedName = GetPISpellName()
    return auraName == PI_SPELL_NAME or auraName == localizedName
end

local function GetDB()
    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    if not profile then return nil end

    profile.piAlert = profile.piAlert or {}
    local db = profile.piAlert
    if db.enabled == nil then db.enabled = false end
    if db.screen == nil then db.screen = false end
    if db.sound == nil then db.sound = false end
    db.soundStyle = NormalizeSoundStyle(db.soundStyle)
    db.soundVolume = NormalizeSoundVolume(db.soundVolume)
    if db.message == nil or db.message == "" then db.message = DEFAULT_MESSAGE end
    if db.throttle == nil then db.throttle = 2 end
    return db
end

local function HasPowerInfusion()
    local piName = GetPISpellName()

    -- Direct spell-ID lookup is the cheapest and the only combat-safe aura read in 12.0
    -- (Midnight). PRESENCE is readable in combat — GetPlayerAuraBySpellID returns a real
    -- table when the buff is present, nil when not — but the table's FIELDS (name, spellId,
    -- duration, ...) are secret in combat. So test EXISTENCE only and never read a field.
    -- IsSecretStrict distinguishes a real table (present) from nil (absent) from a secret
    -- value (restricted -> fall through), and is checked before any comparison so a secret
    -- result can never crash the line.
    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok, aura = pcall(C_UnitAuras.GetPlayerAuraBySpellID, PI_SPELL_ID)
        if ok and not IsSecretStrict(aura) then
            return aura ~= nil
        end
    end

    -- Beyond this point the scans read aura name/spellId, which are SECRET in combat (they
    -- would silently fail or crash). They exist only as an out-of-combat fallback for clients
    -- without the modern API, so never run them while in combat.
    if InCombatLockdown and InCombatLockdown() then return false end

    if AuraUtil and AuraUtil.FindAuraBySpellID then
        local ok, name = pcall(AuraUtil.FindAuraBySpellID, PI_SPELL_ID, "player", "HELPFUL")
        if ok then
            return not IsSecret(name)
        end
    end

    if AuraUtil and AuraUtil.FindAuraByName then
        local ok, name, _, _, _, _, _, _, _, spellID = pcall(AuraUtil.FindAuraByName, piName, "player", "HELPFUL")
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end

        ok, name, _, _, _, _, _, _, _, spellID = pcall(AuraUtil.FindAuraByName, PI_SPELL_NAME, "player", "HELPFUL")
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end
    end

    if C_UnitAuras and C_UnitAuras.GetBuffDataByIndex then
        for i = 1, 80 do
            local ok, aura = pcall(C_UnitAuras.GetBuffDataByIndex, "player", i)
            if not ok or not aura then break end
            if AuraIsPowerInfusion(aura) then return true end
        end
    end

    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 200 do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not aura then break end
            if AuraIsPowerInfusion(aura) then return true end
        end
    end

    if UnitBuff then
        local ok, name, _, _, _, _, _, _, _, _, spellID = pcall(UnitBuff, "player", piName)
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end

        for i = 1, 200 do
            ok, name, _, _, _, _, _, _, _, _, spellID = pcall(UnitBuff, "player", i)
            if not ok or IsSecret(name) then break end
            if SafeNumber(spellID) == PI_SPELL_ID then return true end

            local auraName = SafeString(name)
            if auraName == PI_SPELL_NAME or auraName == piName then return true end
        end
    end

    return false
end

local function EnsureAlertFrame()
    if alertFrame then return alertFrame end

    local frame = CreateFrame("Frame", "EnragePIAlertFrame", UIParent)
    frame:SetSize(420, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 145)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(20)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(0.72, 0.45, 1, 1)
    frame.text:SetText("YOU HAVE PI")

    alertFrame = frame
    return alertFrame
end

local function ShowScreenAlert(message)
    local frame = EnsureAlertFrame()
    frame.text:SetText(string.upper(message or DEFAULT_MESSAGE))
    frame:SetAlpha(1)
    frame:Show()

    hideToken = hideToken + 1
    local token = hideToken
    C_Timer.After(1.8, function()
        if hideToken ~= token or not alertFrame then return end
        alertFrame:Hide()
    end)
end

function addon:GetPIAlertSoundOptions()
    EnsureCDMSounds()
    local values = {}
    for _, key in ipairs(PI_SOUND_STYLE_ORDER) do
        local entry = PI_SOUND_STYLES[key]
        if entry then
            values[key] = entry.label or key
        end
    end
    return values
end

function addon:GetPIAlertSoundOrder()
    EnsureCDMSounds()
    return PI_SOUND_STYLE_ORDER
end

-- PlaySound has no per-call volume, so to let an alert be LOUDER than the player's current
-- setting we briefly raise the Master volume CVar (BOOST-ONLY — never lower it), play the
-- sound, then restore it. 100 = the system's maximum volume. A token guards overlapping
-- alerts so the restore never clobbers a newer one, and the real baseline is saved only once
-- per boost window. All CVar reads/writes are pcall + secret guarded.
local CVOL = "Sound_MasterVolume"
local volRestoreToken = 0
local volBaseline  -- the value to restore to (captured at the first boost in a window)
local function ReadCVarNumber(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVar and C_CVar.GetCVar(name)) or (GetCVar and GetCVar(name))
        if v ~= nil and not (issecretvalue and issecretvalue(v)) then out = tonumber(v) end
    end)
    return out
end
local function WriteCVarNumber(name, value)
    pcall(function()
        if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar(name, tostring(value))
        elseif SetCVar then SetCVar(name, tostring(value)) end
    end)
end

local function PlayAtVolume(soundId, volume)
    if type(soundId) ~= "number" then return end
    local target = NormalizeSoundVolume(volume) / 100  -- 0..1
    local cur = ReadCVarNumber(CVOL)
    local boosted = false
    if cur ~= nil and target > cur + 0.001 then
        if volBaseline == nil then
            volBaseline = cur  -- remember the player's real volume once
            -- Persist it too: a /reload or crash inside the 2s window below would otherwise
            -- strand Master volume at the boosted value. Reclaimed on next login (see below).
            if EnrageDB and EnrageDB.global then EnrageDB.global.volRestorePending = cur end
        end
        WriteCVarNumber(CVOL, target)
        boosted = true
    end
    local ok, willPlay = pcall(PlaySound, soundId, "Master")
    if not ok or willPlay == false then
        pcall(PlaySound, soundId)
    end
    if boosted and C_Timer and C_Timer.After then
        volRestoreToken = volRestoreToken + 1
        local token = volRestoreToken
        C_Timer.After(2.0, function()
            if token ~= volRestoreToken then return end  -- a newer alert now owns the restore
            local restore = volBaseline
            volBaseline = nil
            if EnrageDB and EnrageDB.global then EnrageDB.global.volRestorePending = nil end
            if restore ~= nil then WriteCVarNumber(CVOL, restore) end
        end)
    end
end

-- On login, reclaim a Master volume that a prior session left boosted (a /reload or crash
-- inside the boost window above). Runs once, independent of PI/Pet being enabled. The local
-- frame handle lives only in this do-block, so no persistent top-level local is added.
do
    local f = CreateFrame and CreateFrame("Frame")
    if f then
        f:RegisterEvent("PLAYER_ENTERING_WORLD")
        f:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            if EnrageDB and EnrageDB.global and EnrageDB.global.volRestorePending ~= nil then
                local pend = tonumber(EnrageDB.global.volRestorePending)
                EnrageDB.global.volRestorePending = nil
                if pend then WriteCVarNumber(CVOL, pend) end
            end
        end)
    end
end

local function PlayAlertSound(style, volume)
    if not PlaySound then return end
    local key = NormalizeSoundStyle(style)
    local entry = PI_SOUND_STYLES[key]
    local soundId = entry and entry.soundId
    if type(soundId) ~= "number" and type(key) == "string" then
        -- A Cooldown Manager sound is selected but its table isn't built yet (Blizzard's
        -- addon is load-on-demand); the key itself carries the SoundKit ID, so play it.
        local id = key:match("^cdm(%d+)$")
        if id then soundId = tonumber(id) end
    end
    if type(soundId) ~= "number" then return end
    PlayAtVolume(soundId, volume)
end

-- Public: play a SoundKit sound by its style key. Shared so other features
-- (e.g. the Pet Health Alert) reuse the exact same sound list + playback.
function addon:PlayAlertSoundStyle(style, volume)
    return PlayAlertSound(style, volume)
end

-- Display label for a sound key (the picker button uses it to show the current selection).
function addon:GetSoundLabel(style)
    EnsureCDMSounds()
    local entry = PI_SOUND_STYLES[NormalizeSoundStyle(style)]
    return (entry and entry.label) or tostring(style)
end

-- Open WoW's native categorized "Sound Alert" menu — the same nested-submenu picker the
-- built-in Cooldown Manager uses (Alerts / Instruments / Animals / Impacts / Warcraft 3 / 2 /
-- Devices, each a submenu). getCurrent() returns the saved key; onSelect(key) stores it.
-- Picking a sound previews it and keeps the menu open so you can audition several. Returns
-- false if the native menu API is unavailable (caller may fall back). Shared by PI + Pet.
function addon:OpenSoundAlertMenu(getCurrent, onSelect, getVolume)
    EnsureCDMSounds()
    if not (MenuUtil and MenuUtil.CreateContextMenu) then return false end
    local ok = pcall(MenuUtil.CreateContextMenu, UIParent, function(_owner, root)
        root:CreateTitle("Sound Alert")
        for _, cat in ipairs(PI_SOUND_MENU) do
            local sub = root:CreateButton(cat.label)
            for _, item in ipairs(cat.entries) do
                local key = item.key
                sub:CreateRadio(item.name,
                    function() return getCurrent() == key end,
                    function()
                        onSelect(key)
                        PlayAlertSound(key, getVolume and getVolume() or nil)  -- preview at the set volume
                        return MenuResponse and MenuResponse.Refresh or nil
                    end)
            end
        end
    end)
    return ok
end

local function FireAlert(force, forceSound)
    local db = GetDB()
    if not db or (not force and not db.enabled) then return end

    local now = GetTime and GetTime() or 0
    if not force and now - lastAlertTime < (db.throttle or 2) then return end
    lastAlertTime = now

    local message = db.message or DEFAULT_MESSAGE
    if not force then
        print("|cff00ccffAkcQOL:|r |cffff66ff" .. string.upper(message) .. "|r")
    end

    if db.sound or forceSound then
        PlayAlertSound(db.soundStyle, db.soundVolume)
    end

    if db.screen then
        ShowScreenAlert(message)
        if UIErrorsFrame and UIErrorsFrame.AddMessage then
            UIErrorsFrame:AddMessage(string.upper(message), 0.72, 0.45, 1, 1)
        end
    end

end

local function CheckPIState(silent)
    local hasPI = HasPowerInfusion()
    if hasPI and not hadPI and not silent then
        FireAlert(false)
    end
    hadPI = hasPI
end


local function QueuePIStateCheck(silent)
    checkToken = checkToken + 1
    local token = checkToken

    CheckPIState(silent)
    if not C_Timer or not C_Timer.After then return end

    C_Timer.After(0.05, function()
        if token == checkToken then CheckPIState(silent) end
    end)
    C_Timer.After(0.25, function()
        if token == checkToken then CheckPIState(silent) end
    end)
end

function addon:InitializePIAlert()
    local db = GetDB()
    if not db or not db.enabled then return end

    if not eventFrame then
        eventFrame = CreateFrame("Frame", "EnragePIAlertEventFrame")
        eventFrame:SetScript("OnEvent", function(_, event, unit, _castGUID, spellID)
            if event == "UNIT_AURA" then
                if unit == "player" or unit == nil then QueuePIStateCheck(false) end
            elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
                -- Layer 2 (combat-safe): your OWN spellcasts are NOT secret in 12.0, so a
                -- self-cast Power Infusion is detected here even when the aura read is secret
                -- in combat. FireAlert's throttle dedupes against the UNIT_AURA path.
                if unit == "player" and SafeNumber(spellID) == PI_SPELL_ID then
                    FireAlert(false)
                    hadPI = true
                end
            elseif event == "PLAYER_ENTERING_WORLD" then
                C_Timer.After(1, function() QueuePIStateCheck(true) end)
            elseif event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
                QueuePIStateCheck(true)
            end
        end)
    end

    EnsureAlertFrame()

    eventFrame:UnregisterAllEvents()
    -- Player-filtered UNIT_AURA: we only care about OUR auras, so this avoids being woken for
    -- every nameplate/target/raid-member aura tick in a dense raid (pure overhead the handler
    -- would discard anyway). Falls back to the global form if the unit-filtered call is rejected.
    if not pcall(eventFrame.RegisterUnitEvent, eventFrame, "UNIT_AURA", "player") then
        eventFrame:RegisterEvent("UNIT_AURA")
    end
    -- Player-filtered so we only get our own casts (Layer 2 for self-cast PI).
    pcall(eventFrame.RegisterUnitEvent, eventFrame, "UNIT_SPELLCAST_SUCCEEDED", "player")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")

    if pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
    end
    -- UNIT_AURA + UNIT_SPELLCAST_SUCCEEDED provide the immediate alert; this 0.5s poll is a
    -- safety net (re-checks aura presence) for any missed event window, in or out of combat.
    pollTicker = C_Timer.NewTicker(0.5, function()
        CheckPIState(false)
    end)

    QueuePIStateCheck(true)
end

function addon:DisablePIAlert()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
        eventFrame:SetScript("OnUpdate", nil)
    end
    if pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
    end
    if alertFrame then
        alertFrame:Hide()
    end
end

function addon:TestPIAlert()
    FireAlert(true, true)
end

function addon:TestPIAlertSound()
    local db = GetDB()
    PlayAlertSound(db and db.soundStyle, db and db.soundVolume)
    print("|cff00ccffAkcQOL:|r PI sound test played.")
end
