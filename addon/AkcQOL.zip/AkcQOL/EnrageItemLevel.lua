-- =========================================================================
-- ENRAGE ITEM LEVEL OVERLAY
-- Shows item level on equipment items across the UI
-- =========================================================================

local FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"
local FONT_SIZE = 12

local enabled = true

-- Cache player state at safe times (login, spec change). Hook chains read cache only,
-- with no API calls inside hooksecurefunc to avoid taint propagation to Blizzard UI.
local CACHED_PRIMARY_STAT = nil  -- "STR" / "AGI" / "INT"
local CACHED_CLASS_ID = nil      -- numeric class ID (1-13)
local CACHED_SPEC_ID = nil       -- numeric spec ID (e.g. 71, 254, etc.)

local function RefreshPlayerCache()
    -- Spec ID + primary stat
    local specIndex = GetSpecialization()
    if specIndex then
        local sid, _, _, _, _, primaryStat = GetSpecializationInfo(specIndex)
        CACHED_SPEC_ID = sid
        if primaryStat == 1 then CACHED_PRIMARY_STAT = "STR"
        elseif primaryStat == 2 then CACHED_PRIMARY_STAT = "AGI"
        elseif primaryStat == 4 then CACHED_PRIMARY_STAT = "INT"
        end
    end

    -- Class ID
    local _, _, classID = UnitClass("player")
    CACHED_CLASS_ID = classID

    -- Fallback for primary stat
    if not CACHED_PRIMARY_STAT then
        local _, className = UnitClass("player")
        if className == "WARRIOR" or className == "PALADIN" or className == "DEATHKNIGHT" then
            CACHED_PRIMARY_STAT = "STR"
        elseif className == "HUNTER" or className == "ROGUE" or className == "MONK"
            or className == "DEMONHUNTER" or className == "EVOKER" then
            CACHED_PRIMARY_STAT = "AGI"
        else
            CACHED_PRIMARY_STAT = "INT"
        end
    end
end

local playerCacheFrame = CreateFrame("Frame")
playerCacheFrame:RegisterEvent("PLAYER_LOGIN")
playerCacheFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
playerCacheFrame:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
playerCacheFrame:SetScript("OnEvent", function()
    -- Defer so spec API is fully ready
    C_Timer.After(0.5, function()
        pcall(RefreshPlayerCache)
    end)
end)

-- ---------------------------------------------------------------------------
-- Core helpers
-- ---------------------------------------------------------------------------

local function IsEquipment(itemID)
    if not itemID then return false end
    local _, _, _, _, _, classID = C_Item.GetItemInfoInstant(itemID)
    return classID == Enum.ItemClass.Weapon or classID == Enum.ItemClass.Armor
end

-- Map class ID to the armor subclass the class should wear
-- Armor subclasses: 1=Cloth, 2=Leather, 3=Mail, 4=Plate
local CLASS_ARMOR_TYPE = {
    [1]  = 4, -- Warrior -> Plate
    [2]  = 4, -- Paladin -> Plate
    [3]  = 3, -- Hunter -> Mail
    [4]  = 2, -- Rogue -> Leather
    [5]  = 1, -- Priest -> Cloth
    [6]  = 4, -- Death Knight -> Plate
    [7]  = 3, -- Shaman -> Mail
    [8]  = 1, -- Mage -> Cloth
    [9]  = 1, -- Warlock -> Cloth
    [10] = 2, -- Monk -> Leather
    [11] = 2, -- Druid -> Leather
    [12] = 2, -- Demon Hunter -> Leather
    [13] = 3, -- Evoker -> Mail
}

local function IsWearableArmorType(itemID)
    if not itemID then return true end
    local _, _, _, equipLoc, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
    -- Cloaks are classified as Cloth but wearable by all classes; skip armor check.
    if equipLoc == "INVTYPE_CLOAK" then return true end
    -- Only filter actual armor pieces (Cloth=1, Leather=2, Mail=3, Plate=4)
    if classID ~= Enum.ItemClass.Armor then return true end
    if subclassID < 1 or subclassID > 4 then return true end
    -- Use cached class ID (no API call inside hooksecurefunc chain)
    if not CACHED_CLASS_ID then return true end
    local expectedType = CLASS_ARMOR_TYPE[CACHED_CLASS_ID]
    if not expectedType then return true end
    return subclassID == expectedType
end

-- Weapon subclass IDs:
-- 0=1H Axe, 1=2H Axe, 2=1H Bow(!), 3=Gun, 4=1H Mace, 5=2H Mace,
-- 6=Polearm, 7=1H Sword, 8=2H Sword, 9=Warglaive, 10=Staff,
-- 13=Fist Weapon, 14=Misc, 15=Dagger, 16=Thrown, 18=Crossbow, 20=Wand

-- Spec-based weapon type restrictions
-- Maps specID to a set of allowed weapon subclass IDs
-- Only specs with clear restrictions are listed; unlisted specs allow all
local SPEC_WEAPON_TYPES = {
    -- Hunter: BM/MM use ranged (Bow=2, Gun=3, Crossbow=18), Survival uses polearms/staves
    [253] = { [2]=true, [3]=true, [18]=true },              -- Beast Mastery
    [254] = { [2]=true, [3]=true, [18]=true },              -- Marksmanship
    [255] = { [6]=true, [10]=true },                        -- Survival (Polearm, Staff)
    -- Caster DPS: staves, daggers, swords, wands, off-hands
    [62]  = { [7]=true, [10]=true, [15]=true, [20]=true },  -- Arcane Mage
    [63]  = { [7]=true, [10]=true, [15]=true, [20]=true },  -- Fire Mage
    [64]  = { [7]=true, [10]=true, [15]=true, [20]=true },  -- Frost Mage
    [258] = { [4]=true, [10]=true, [15]=true, [20]=true },  -- Shadow Priest
    [256] = { [4]=true, [10]=true, [15]=true, [20]=true },  -- Discipline Priest
    [257] = { [4]=true, [10]=true, [15]=true, [20]=true },  -- Holy Priest
    [265] = { [7]=true, [10]=true, [15]=true, [20]=true },  -- Affliction Warlock
    [266] = { [7]=true, [10]=true, [15]=true, [20]=true },  -- Demonology Warlock
    [267] = { [7]=true, [10]=true, [15]=true, [20]=true },  -- Destruction Warlock
    [262] = { [4]=true, [10]=true, [15]=true, [20]=true },  -- Elemental Shaman
    [264] = { [4]=true, [10]=true, [15]=true, [20]=true },  -- Restoration Shaman
    [102] = { [4]=true, [10]=true, [15]=true, [6]=true },   -- Balance Druid
    [105] = { [4]=true, [10]=true, [15]=true, [6]=true },   -- Restoration Druid
    -- Melee: generally all melee weapons are fine, but some specs have clear preferences
    -- DH: warglaives, 1H swords, 1H axes, fist weapons
    [577] = { [0]=true, [7]=true, [9]=true, [13]=true, [15]=true },  -- Havoc DH
    [581] = { [0]=true, [7]=true, [9]=true, [13]=true, [15]=true },  -- Vengeance DH
    -- Rogue: daggers, 1H swords, 1H maces, 1H axes, fist
    [259] = { [0]=true, [7]=true, [4]=true, [13]=true, [15]=true },  -- Assassination (daggers preferred)
    [260] = { [0]=true, [7]=true, [4]=true, [13]=true, [15]=true },  -- Outlaw
    [261] = { [0]=true, [7]=true, [4]=true, [13]=true, [15]=true },  -- Subtlety (daggers preferred)
    -- Tank specs that use 1H + Shield (no 2H weapons)
    [73]  = { [0]=true, [4]=true, [7]=true, [13]=true, [15]=true },  -- Protection Warrior (1H only)
    [66]  = { [0]=true, [4]=true, [7]=true, [13]=true },             -- Protection Paladin (1H only)
    -- Brewmaster Monk: staves, polearms, 1H weapons, fist
    [268] = { [0]=true, [4]=true, [6]=true, [7]=true, [10]=true, [13]=true },  -- Brewmaster
    -- Windwalker Monk: similar
    [269] = { [0]=true, [4]=true, [6]=true, [7]=true, [10]=true, [13]=true },  -- Windwalker
    -- Mistweaver Monk: staves, polearms, 1H
    [270] = { [4]=true, [6]=true, [10]=true },                       -- Mistweaver
}

local function IsWearableWeaponForSpec(itemID)
    if not itemID then return true end
    local _, _, _, _, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
    if classID ~= Enum.ItemClass.Weapon then return true end  -- Not a weapon, skip
    -- Use cached spec ID (no API call inside hooksecurefunc chain)
    if not CACHED_SPEC_ID then return true end
    local allowed = SPEC_WEAPON_TYPES[CACHED_SPEC_ID]
    if not allowed then return true end  -- No restriction for this spec
    return allowed[subclassID] or false
end

-- Check if item's primary stat matches the player's primary stat
-- Uses tooltip parsing since GetItemStats was removed in Midnight
local function HasMatchingPrimaryStat(itemLink)
    if not itemLink then return true end

    -- Parse tooltip lines to detect primary stat
    local ok, tooltipData = pcall(C_TooltipInfo.GetHyperlink, itemLink)
    if not ok or not tooltipData or not tooltipData.lines then return true end
    pcall(TooltipUtil.SurfaceArgs, tooltipData)

    local hasStr, hasAgi, hasInt = false, false, false
    -- Localized stat names (works for all clients)
    local STR_PATTERNS = { "Strength", "Guc", "Force", "St\195\164rke" }
    local AGI_PATTERNS = { "Agility", "Cevik", "Agilit\195\169", "Beweglichkeit" }
    local INT_PATTERNS = { "Intellect", "Zeka", "Intelligence", "Intelligenz" }

    for _, line in ipairs(tooltipData.lines) do
        pcall(TooltipUtil.SurfaceArgs, line)
        local txt = line.leftText or ""
        -- Look for "+XX Stat" pattern (fixed primary stat lines)
        -- Skip lines with "or" (flex stat: "Agility or Strength or Intellect")
        if txt:find("%+%d") and not txt:find(" or ") and not txt:find(" veya ") and not txt:find(" ou ") and not txt:find(" oder ") then
            for _, p in ipairs(STR_PATTERNS) do
                if txt:find(p) then hasStr = true; break end
            end
            for _, p in ipairs(AGI_PATTERNS) do
                if txt:find(p) then hasAgi = true; break end
            end
            for _, p in ipairs(INT_PATTERNS) do
                if txt:find(p) then hasInt = true; break end
            end
        end
    end

    -- If no single fixed stat is found, the item is flex/no-primary and is always OK.
    if not hasStr and not hasAgi and not hasInt then return true end

    -- Use cached primary stat, with no API calls in secure hooks.
    local playerPrimary = CACHED_PRIMARY_STAT
    if not playerPrimary then
        -- Cache not ready yet: assume match to avoid false negatives.
        return true
    end

    if playerPrimary == "STR" and hasStr then return true end
    if playerPrimary == "AGI" and hasAgi then return true end
    if playerPrimary == "INT" and hasInt then return true end

    return false
end

-- ---------------------------------------------------------------------------
-- Gem / Enchant detection
-- ---------------------------------------------------------------------------

-- Slots that can be enchanted in Midnight (retail 12.x)
-- Head, Shoulder, Chest, Feet, Finger0, Finger1, MainHand, SecondaryHand
local ENCHANTABLE_SLOTS = {
    [1]  = true,  -- Head
    [3]  = true,  -- Shoulder
    [5]  = true,  -- Chest
    [7]  = true,  -- Legs
    [8]  = true,  -- Feet
    [11] = true,  -- Finger0
    [12] = true,  -- Finger1
    [16] = true,  -- MainHand
    [17] = "weapon_only",  -- SecondaryHand: only if a weapon is equipped (not shield/off-hand/holdable)
}

local function ItemHasEmptyGemSlots(itemLink, slotID, unit)
    if not itemLink then return false end
    -- Use tooltip from equipped slot (most reliable for socket detection)
    local tooltipData
    if slotID and unit then
        local ok, td = pcall(C_TooltipInfo.GetInventoryItem, unit, slotID)
        if ok then tooltipData = td end
    end
    if not tooltipData then
        -- Fallback: parse from hyperlink
        local ok, td = pcall(C_TooltipInfo.GetHyperlink, itemLink)
        if ok then tooltipData = td end
    end
    if not tooltipData or not tooltipData.lines then return false end
    pcall(TooltipUtil.SurfaceArgs, tooltipData)
    for _, line in ipairs(tooltipData.lines) do
        pcall(TooltipUtil.SurfaceArgs, line)
        local txt = line.leftText or ""
        -- Check for empty socket text (localized global strings)
        if txt == (EMPTY_SOCKET_PRISMATIC or "") or
           txt == (EMPTY_SOCKET_RED or "") or
           txt == (EMPTY_SOCKET_BLUE or "") or
           txt == (EMPTY_SOCKET_YELLOW or "") or
           txt == (EMPTY_SOCKET_META or "") or
           txt == (EMPTY_SOCKET_NO_COLOR or "") then
            return true
        end
    end
    return false
end

local function ItemIsMissingEnchant(itemLink, slotID)
    if not itemLink or not slotID then return false end
    local slotFlag = ENCHANTABLE_SLOTS[slotID]
    if not slotFlag then return false end
    -- Slot 17 (SecondaryHand): only check enchant if a WEAPON is equipped (not shield/off-hand/holdable)
    if slotFlag == "weapon_only" then
        local _, _, _, equipLoc = C_Item.GetItemInfoInstant(itemLink)
        if not equipLoc or (equipLoc ~= "INVTYPE_WEAPON" and equipLoc ~= "INVTYPE_WEAPONOFFHAND") then
            return false  -- Shield, off-hand frill, holdable: no enchant needed.
        end
    end
    -- Item links: |Hitem:itemID:enchantID:gem1:gem2:gem3:...
    -- If enchantID is 0 or empty, no enchant applied
    local enchantID = itemLink:match("item:%d+:(%d+)")
    if not enchantID or tonumber(enchantID) == 0 then
        return true
    end
    return false
end

-- Map item equip locations to equipment slot IDs
local EQUIP_LOC_TO_SLOT = {
    INVTYPE_HEAD           = { 1 },
    INVTYPE_NECK           = { 2 },
    INVTYPE_SHOULDER       = { 3 },
    INVTYPE_CHEST          = { 5 },
    INVTYPE_ROBE           = { 5 },
    INVTYPE_WAIST          = { 6 },
    INVTYPE_LEGS           = { 7 },
    INVTYPE_FEET           = { 8 },
    INVTYPE_WRIST          = { 9 },
    INVTYPE_HAND           = { 10 },
    INVTYPE_FINGER         = { 11, 12 },
    INVTYPE_TRINKET        = { 13, 14 },
    INVTYPE_CLOAK          = { 15 },
    INVTYPE_WEAPON         = { 16, 17 },
    INVTYPE_2HWEAPON       = { 16 },
    INVTYPE_WEAPONMAINHAND = { 16 },
    INVTYPE_WEAPONOFFHAND  = { 17 },
    INVTYPE_SHIELD         = { 17 },
    INVTYPE_HOLDABLE       = { 17 },
    INVTYPE_RANGED         = { 16 },
    INVTYPE_RANGEDRIGHT    = { 16 },
}

-- Check if the player has a 2H weapon equipped in main hand
local function HasEquipped2H()
    local mhLink = GetInventoryItemLink("player", 16)
    if not mhLink then return false end
    local _, _, _, equipLoc = C_Item.GetItemInfoInstant(mhLink)
    return equipLoc == "INVTYPE_2HWEAPON"
end

-- Get the lowest equipped ilvl for the slots this item could go in
local function GetEquippedIlvlForItem(itemLink)
    if not itemLink then return nil end
    local _, _, _, equipLoc = C_Item.GetItemInfoInstant(itemLink)
    if not equipLoc or equipLoc == "" then return nil end
    local slots = EQUIP_LOC_TO_SLOT[equipLoc]
    if not slots then return nil end

    -- When a 2H weapon is equipped, off-hand slot is empty but that's not an upgrade.
    -- For 1H weapons/off-hands, compare against the 2H weapon's ilvl instead.
    local has2H = HasEquipped2H()
    if has2H then
        -- Bag item is a 1H weapon; compare against 2H main hand ilvl.
        if equipLoc == "INVTYPE_WEAPON" then
            local mhLink = GetInventoryItemLink("player", 16)
            if mhLink then
                return C_Item.GetDetailedItemLevelInfo(mhLink)
            end
            return nil
        end
        -- Bag item is off-hand/shield/holdable; compare against 2H main hand ilvl.
        -- (replacing 2H with 1H+OH means the OH must also be considered)
        if equipLoc == "INVTYPE_WEAPONOFFHAND" or equipLoc == "INVTYPE_SHIELD"
           or equipLoc == "INVTYPE_HOLDABLE" then
            local mhLink = GetInventoryItemLink("player", 16)
            if mhLink then
                return C_Item.GetDetailedItemLevelInfo(mhLink)
            end
            return nil
        end
    end

    -- For 1H weapons (INVTYPE_WEAPON): only compare against equipped WEAPONS in slots 16/17,
    -- Skip shields/off-hands/holdables; a weapon is not an upgrade over a shield.
    local isWeapon = (equipLoc == "INVTYPE_WEAPON")

    local lowestIlvl = nil
    for _, slotID in ipairs(slots) do
        local equippedLink = GetInventoryItemLink("player", slotID)
        if equippedLink then
            -- If bag item is a weapon, only compare against weapons in that slot
            if isWeapon then
                local _, _, _, eqLoc = C_Item.GetItemInfoInstant(equippedLink)
                if eqLoc ~= "INVTYPE_WEAPON" and eqLoc ~= "INVTYPE_WEAPONMAINHAND"
                   and eqLoc ~= "INVTYPE_WEAPONOFFHAND" and eqLoc ~= "INVTYPE_2HWEAPON" then
                    -- Equipped item in this slot is not a weapon, so skip it.
                    -- Don't count this slot at all for weapon upgrade comparison
                else
                    local eIlvl = C_Item.GetDetailedItemLevelInfo(equippedLink)
                    if eIlvl then
                        if not lowestIlvl or eIlvl < lowestIlvl then
                            lowestIlvl = eIlvl
                        end
                    end
                end
            else
                local eIlvl = C_Item.GetDetailedItemLevelInfo(equippedLink)
                if eIlvl then
                    if not lowestIlvl or eIlvl < lowestIlvl then
                        lowestIlvl = eIlvl
                    end
                end
            end
        else
            -- Check if something is actually equipped but link not cached yet
            local equippedID = GetInventoryItemID("player", slotID)
            if equippedID then
                -- Item exists but link not cached, skip comparison
                return nil
            end
            -- Empty slot: for weapons, empty off-hand with shield means don't count it
            if isWeapon and slotID == 17 then
                -- Off-hand is empty for a shield user; don't treat it as an upgrade slot.
            else
                return 0  -- Truly empty slot, definitely an upgrade
            end
        end
    end
    return lowestIlvl
end

local function PrepareButton(button)
    if button.__enrageILvl then return end
    local overlay = CreateFrame("Frame", nil, button)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(button:GetFrameLevel() + 1)
    overlay:EnableMouse(false)  -- Don't intercept mouse events (tooltip must work)

    local text = overlay:CreateFontString(nil, "OVERLAY")
    text:SetFont(FONT_FACE, FONT_SIZE, FONT_FLAGS)
    text:SetPoint("BOTTOM", overlay, "BOTTOM", 0, 2)

    local warn = overlay:CreateFontString(nil, "OVERLAY")
    warn:SetFont(FONT_FACE, 22, FONT_FLAGS)
    warn:SetPoint("TOP", overlay, "TOP", 0, -1)

    local arrow = overlay:CreateTexture(nil, "OVERLAY")
    arrow:SetSize(12, 12)
    arrow:SetPoint("TOPLEFT", overlay, "TOPLEFT", -2, 2)
    arrow:SetAtlas("poi-door-arrow-up")
    arrow:SetVertexColor(0.2, 1, 0.2, 1)
    arrow:Hide()

    button.__enrageILvlOverlay = overlay
    button.__enrageILvl = text
    button.__enrageWarn = warn
    button.__enrageUpgrade = arrow
end

local function CleanButton(button)
    if button.__enrageILvl then
        button.__enrageILvl:Hide()
    end
    if button.__enrageWarn then
        button.__enrageWarn:Hide()
    end
    if button.__enrageUpgrade then
        button.__enrageUpgrade:Hide()
    end
end

local function ShowLevel(button, level, quality, itemLink, slotID, unit)
    PrepareButton(button)
    local r, g, b = 1, 1, 1
    if quality and C_Item.GetItemQualityColor then
        r, g, b = C_Item.GetItemQualityColor(quality)
    end
    button.__enrageILvl:SetText(level)
    button.__enrageILvl:SetTextColor(r, g, b)
    button.__enrageILvl:Show()
    button.__enrageILvlOverlay:SetFrameLevel(button:GetFrameLevel() + 1)

    -- Gem/Enchant warnings (character + inspect only)
    if button.__enrageWarn and slotID then
        local warnings = {}
        if ItemHasEmptyGemSlots(itemLink, slotID, unit) then
            table.insert(warnings, "|cffFF0000G|r")  -- Red G for missing gem
        end
        if ItemIsMissingEnchant(itemLink, slotID) then
            table.insert(warnings, "|cffFF0000E|r")  -- Red E for missing enchant
        end
        if #warnings > 0 then
            button.__enrageWarn:SetText(table.concat(warnings, " "))
            -- Reposition based on slot side
            button.__enrageWarn:ClearAllPoints()
            if slotID == 16 or slotID == 17 then
                -- Weapons: show above the icon
                button.__enrageWarn:SetPoint("BOTTOM", button.__enrageILvlOverlay, "TOP", 0, 1)
            elseif slotID == 1 or slotID == 2 or slotID == 3 or slotID == 4 or slotID == 5 or slotID == 9 or slotID == 15 or slotID == 18 or slotID == 19 then
                -- Left column slots: show to the right of icon
                button.__enrageWarn:SetPoint("LEFT", button.__enrageILvlOverlay, "RIGHT", 2, 0)
            else
                -- Right column slots (6,7,8,10,11,12,13,14): show to the left of icon
                button.__enrageWarn:SetPoint("RIGHT", button.__enrageILvlOverlay, "LEFT", -2, 0)
            end
            button.__enrageWarn:Show()
        else
            button.__enrageWarn:Hide()
        end
    elseif button.__enrageWarn then
        button.__enrageWarn:Hide()
    end
end

-- Update from an Item mixin object
local function UpdateFromItem(button, item, slotID, unit)
    if not item or item:IsItemEmpty() then
        CleanButton(button)
        return
    end
    item:ContinueOnItemLoad(function()
        if not enabled then CleanButton(button) return end
        local itemID = item:GetItemID()
        if not IsEquipment(itemID) then CleanButton(button) return end
        local level = item:GetCurrentItemLevel()
        local quality = item:GetItemQuality()
        local itemLink = item:GetItemLink()
        if level and level > 0 then
            ShowLevel(button, level, quality, itemLink, slotID, unit)
        else
            CleanButton(button)
        end
    end)
end

-- Update from an ItemLocation (with optional slotID for gem/enchant checks)
local function UpdateFromLocation(button, itemLocation, slotID, unit)
    if not enabled then CleanButton(button) return end
    if not itemLocation or not C_Item.DoesItemExist(itemLocation) then
        CleanButton(button)
        return
    end
    local item = Item:CreateFromItemLocation(itemLocation)
    UpdateFromItem(button, item, slotID, unit)
end

-- Update from an item link string (with optional slotID for gem/enchant checks)
local function UpdateFromLink(button, link, slotID, unit)
    if not enabled then CleanButton(button) return end
    if not link then CleanButton(button) return end
    local item = Item:CreateFromItemLink(link)
    UpdateFromItem(button, item, slotID, unit)
end

-- ---------------------------------------------------------------------------
-- Hook 1: Character Panel
-- ---------------------------------------------------------------------------

hooksecurefunc("PaperDollItemSlotButton_Update", function(button)
    if not enabled then CleanButton(button) return end
    local slotID = button:GetID()
    if slotID and slotID > 0 then
        local itemLocation = ItemLocation:CreateFromEquipmentSlot(slotID)
        UpdateFromLocation(button, itemLocation, slotID, "player")
    else
        CleanButton(button)
    end
end)

-- ---------------------------------------------------------------------------
-- Hook 1.5: Own character panel (C key) - decimal ilvl overlay
-- Architecture:
--   * Cache the equipped ilvl via events (no API calls during secure chains).
--   * hooksecurefunc post-hook reads cache only (no taint propagation).
--   * Replacing SetText (old approach) broke character frame in combat.
-- ---------------------------------------------------------------------------
local CACHED_EQUIPPED_ILVL = nil  -- decimal string, e.g. "266.81"

local ilvlCacheFrame = CreateFrame("Frame")
ilvlCacheFrame:RegisterEvent("PLAYER_LOGIN")
ilvlCacheFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
ilvlCacheFrame:RegisterEvent("PLAYER_AVG_ITEM_LEVEL_UPDATE")
ilvlCacheFrame:SetScript("OnEvent", function()
    -- Defer outside combat-secure context
    C_Timer.After(0.3, function()
        local ok, _, equipped = pcall(GetAverageItemLevel)
        if ok and equipped and equipped > 0 then
            CACHED_EQUIPPED_ILVL = string.format("%.2f", equipped)
        end
    end)
end)

do
    local hooked = false
    local applying = false  -- recursion guard

    local function HookIlvlText()
        if hooked then return end
        if not (CharacterStatsPane and CharacterStatsPane.ItemLevelFrame) then return end
        local valText = CharacterStatsPane.ItemLevelFrame.Value
        if not valText then return end

        local ok = pcall(function()
            hooksecurefunc(valText, "SetText", function(self, text)
                if applying then return end
                if not enabled then return end  -- respects "Show Item Levels" setting
                -- Skip if text already has decimal (already formatted by us)
                if type(text) == "string" and text:find("%.", 1, true) then return end
                if not CACHED_EQUIPPED_ILVL then return end
                applying = true
                self:SetText(CACHED_EQUIPPED_ILVL)
                applying = false
            end)
        end)
        if ok then hooked = true end
    end

    if CharacterFrame then
        CharacterFrame:HookScript("OnShow", function()
            HookIlvlText()
        end)
    end
end

-- ---------------------------------------------------------------------------
-- Hook 2: Bags (Combined + Individual Container Frames)
-- ---------------------------------------------------------------------------

local function UpdateContainerButton(button, bagID, slotIndex)
    if not enabled then CleanButton(button) return end
    if not bagID or not slotIndex then CleanButton(button) return end
    local itemLocation = ItemLocation:CreateFromBagAndSlot(bagID, slotIndex)
    if not itemLocation or not C_Item.DoesItemExist(itemLocation) then
        CleanButton(button)
        return
    end
    local item = Item:CreateFromItemLocation(itemLocation)
    if not item or item:IsItemEmpty() then
        CleanButton(button)
        return
    end
    item:ContinueOnItemLoad(function()
        if not enabled then CleanButton(button) return end
        local itemID = item:GetItemID()
        if not IsEquipment(itemID) then CleanButton(button) return end
        local level = item:GetCurrentItemLevel()
        local quality = item:GetItemQuality()
        local itemLink = item:GetItemLink()
        if level and level > 0 then
            ShowLevel(button, level, quality, itemLink)
            -- Check if this is an upgrade over equipped gear
            PrepareButton(button)
            local equippedIlvl = GetEquippedIlvlForItem(itemLink)
            if equippedIlvl and level > equippedIlvl and IsWearableArmorType(itemID) and IsWearableWeaponForSpec(itemID) and HasMatchingPrimaryStat(itemLink) then
                button.__enrageUpgrade:Show()
            elseif button.__enrageUpgrade then
                button.__enrageUpgrade:Hide()
            end
        else
            CleanButton(button)
        end
    end)
end

-- Combined bags view (default in retail 11.x)
if ContainerFrameCombinedBags and ContainerFrameCombinedBags.UpdateItems then
    hooksecurefunc(ContainerFrameCombinedBags, "UpdateItems", function(self)
        for _, itemButton in self:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end)
end

-- Individual container frames (non-combined view, bank bags)
if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
    for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
        hooksecurefunc(frame, "UpdateItems", function(self)
            for _, itemButton in self:EnumerateValidItems() do
                UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
            end
        end)
    end
end

-- Fallback for ContainerFrame_Update (older API / bank)
if _G.ContainerFrame_Update then
    hooksecurefunc("ContainerFrame_Update", function(container)
        if not enabled then return end
        local bagID = container:GetID()
        local name = container:GetName()
        for i = 1, container.size or 0 do
            local button = _G[name .. "Item" .. i]
            if button then
                UpdateContainerButton(button, bagID, i)
            end
        end
    end)
end

-- ---------------------------------------------------------------------------
-- Hook 4: Bank Panels (Account Bank, Warband Bank)
-- ---------------------------------------------------------------------------

local function HookBankPanel(panel)
    if not panel then return end
    if panel.UpdateItems then
        hooksecurefunc(panel, "UpdateItems", function(self)
            if not enabled then return end
            for itemButton in self:EnumerateValidItems() do
                local bagID = itemButton.GetBankTabID and itemButton:GetBankTabID()
                local slotIndex = itemButton.GetContainerSlotID and itemButton:GetContainerSlotID()
                if bagID and slotIndex then
                    UpdateContainerButton(itemButton, bagID, slotIndex)
                end
            end
        end)
    end
    local function hookRefresh(methodName)
        if panel[methodName] then
            hooksecurefunc(panel, methodName, function(self)
                if not enabled then return end
                for itemButton in self:EnumerateValidItems() do
                    local bagID = itemButton.GetBankTabID and itemButton:GetBankTabID()
                    local slotIndex = itemButton.GetContainerSlotID and itemButton:GetContainerSlotID()
                    if bagID and slotIndex then
                        UpdateContainerButton(itemButton, bagID, slotIndex)
                    end
                end
            end)
        end
    end
    hookRefresh("GenerateItemSlotsForSelectedTab")
    hookRefresh("RefreshAllItemsForSelectedTab")
end

HookBankPanel(_G.BankPanel)
HookBankPanel(_G.AccountBankPanel)

-- ---------------------------------------------------------------------------
-- Hook 5: Loot Frame
-- ---------------------------------------------------------------------------

if LootFrame and LootFrame.ScrollBox then
    local function HandleLootSlot(frame)
        local button = frame.Item or frame
        if not button then return end
        CleanButton(button)
        if not enabled then return end
        local data = frame.GetElementData and frame:GetElementData()
        if not (data and data.slotIndex) then return end
        local link = GetLootSlotLink(data.slotIndex)
        if link then
            UpdateFromLink(button, link)
        end
    end
    LootFrame.ScrollBox:RegisterCallback("OnUpdate", function()
        LootFrame.ScrollBox:ForEachFrame(HandleLootSlot)
    end)
elseif _G.LootFrame_UpdateButton then
    hooksecurefunc("LootFrame_UpdateButton", function(index)
        local button = _G["LootButton" .. index]
        if not button then return end
        CleanButton(button)
        if not enabled then return end
        if button.slot then
            local link = GetLootSlotLink(button.slot)
            if link then
                UpdateFromLink(button, link)
            end
        end
    end)
end

-- ---------------------------------------------------------------------------
-- Hook 6: Equipment Flyout
-- ---------------------------------------------------------------------------

local UnpackLocation = _G.EquipmentManager_UnpackLocation or (C_EquipmentSet and C_EquipmentSet.UnpackLocation)

if _G.EquipmentFlyout_UpdateItems and UnpackLocation then
    hooksecurefunc("EquipmentFlyout_UpdateItems", function()
        if not enabled then return end
        local flyout = _G.EquipmentFlyoutFrame
        if not flyout or not flyout.buttons then return end
        for _, button in ipairs(flyout.buttons) do
            if button:IsShown() and button.location and button.location ~= 0xFFFFFFFF then
                local ok, player, bank, bags, voidStorage, slot, bag = pcall(UnpackLocation, button.location)
                if ok and bag and slot and bags then
                    local itemLocation = ItemLocation:CreateFromBagAndSlot(bag, slot)
                    UpdateFromLocation(button, itemLocation)
                elseif ok and player and slot then
                    local itemLocation = ItemLocation:CreateFromEquipmentSlot(slot)
                    UpdateFromLocation(button, itemLocation)
                else
                    CleanButton(button)
                end
            end
        end
    end)
end

-- ---------------------------------------------------------------------------
-- Toggle system
-- ---------------------------------------------------------------------------

function EnrageItemLevel_SetEnabled(isEnabled)
    enabled = isEnabled
    -- Clean all visible overlays if disabled
    if not isEnabled then
        -- Character panel slots
        for slotID = 1, 19 do
            local slotName = ({
                "CharacterHeadSlot", "CharacterNeckSlot", "CharacterShoulderSlot",
                "CharacterShirtSlot", "CharacterChestSlot", "CharacterWaistSlot",
                "CharacterLegsSlot", "CharacterFeetSlot", "CharacterWristSlot",
                "CharacterHandsSlot", "CharacterFinger0Slot", "CharacterFinger1Slot",
                "CharacterTrinket0Slot", "CharacterTrinket1Slot", "CharacterBackSlot",
                "CharacterMainHandSlot", "CharacterSecondaryHandSlot", "CharacterTabardSlot",
                nil, -- 19 = ranged (classic only)
            })[slotID]
            if slotName then
                local btn = _G[slotName]
                if btn then CleanButton(btn) end
            end
        end
    end
end

-- ---------------------------------------------------------------------------
-- Initialization
-- ---------------------------------------------------------------------------

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:SetScript("OnEvent", function(self, event)
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    if EnrageDB.global.showItemLevel == nil then
        EnrageDB.global.showItemLevel = true  -- existing users keep prior behavior; fresh installs are seeded OFF at file-load
    end
    enabled = EnrageDB.global.showItemLevel ~= false
    self:UnregisterAllEvents()
end)

_G.Enrage_ToggleItemLevel = function()
    if not EnrageDB or not EnrageDB.global then return end
    enabled = EnrageDB.global.showItemLevel ~= false
end
