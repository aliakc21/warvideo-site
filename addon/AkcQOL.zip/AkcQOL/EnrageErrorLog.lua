-- =========================================================================
-- ENRAGE: LUA ERROR LOG
-- Catches UI errors quietly, stores them in EnrageDB, and exposes a copyable
-- in-game viewer. This keeps the footprint small instead of embedding the
-- full BugSack/BugGrabber stack.
-- =========================================================================

local ADDON_NAME = ...

local MAX_ERROR_LOG = 200
local ROW_COUNT = 13
local ERROR_RATE_LIMIT = 10
local ERROR_THROTTLE_SECONDS = 5
local SOUND_COOLDOWN = 0.25
local SOUND_BURST_COUNT = 5
local SOUND_BURST_INTERVAL = 0.18
local LUA_ERROR_SOUND_FALLBACK = 8959
local LUA_ERROR_SOUND_FILE = "Interface\\AddOns\\" .. (ADDON_NAME or "Enrageplus") .. "\\Media\\lua-error.ogg"

local WHITE_TEX = "Interface\\Buttons\\WHITE8x8"
local FONT_FACE = "Fonts\\FRIZQT__.TTF"

local errorFrame
local selectedIndex = 1
local captureWindowStart = 0
local captureWindowCount = 0
local throttledUntil = 0
local throttleNoticePending = false
local handlingError = false
local bugGrabberMirrorRegistered = false
local bugGrabberCallbackOwner = {}
local lastSyncedBugGrabberSession = nil
local nativeEventsRegistered = false
local lastSoundAt = 0

_G.EnragePlus = _G.EnragePlus or {}

local function EnsureDB()
    if type(EnrageDB) ~= "table" then EnrageDB = {} end
    if type(EnrageDB.global) ~= "table" then EnrageDB.global = {} end
    if type(EnrageDB.global.luaErrors) ~= "table" then EnrageDB.global.luaErrors = {} end

    local db = EnrageDB.global.luaErrors
    if type(db.entries) ~= "table" then db.entries = {} end
    if type(db.nextID) ~= "number" then db.nextID = 1 end
    if db.enabled == nil then db.enabled = true end
    if db.suppressPopups == nil then db.suppressPopups = true end
    if db.soundEnabled == nil then db.soundEnabled = true end
    if type(db.unreadCount) ~= "number" then db.unreadCount = 0 end
    if type(db.maxEntries) ~= "number" then db.maxEntries = MAX_ERROR_LOG end
    return db
end

local function GetLuaErrorSoundID()
    if type(SOUNDKIT) == "table" then
        return SOUNDKIT.RAID_WARNING
            or SOUNDKIT.UI_RAID_BOSS_WHISPER_WARNING
            or SOUNDKIT.READY_CHECK
            or LUA_ERROR_SOUND_FALLBACK
    end
    return LUA_ERROR_SOUND_FALLBACK
end

local function PlayBuiltInLuaWarning()
    local soundID = GetLuaErrorSoundID()
    if not soundID or type(PlaySound) ~= "function" then return end

    local ok = pcall(PlaySound, soundID, "Master")
    if not ok then
        pcall(PlaySound, soundID)
    end
end

local function PlayCustomLuaErrorSound()
    if type(PlaySoundFile) ~= "function" then return end

    local ok, played = pcall(PlaySoundFile, LUA_ERROR_SOUND_FILE, "Master")
    if not (ok and played) then
        pcall(PlaySoundFile, LUA_ERROR_SOUND_FILE)
    end
end

local function PlayLuaErrorSoundPulse()
    PlayCustomLuaErrorSound()
    PlayBuiltInLuaWarning()
end

local function PlayLuaErrorSound(force)
    local db = EnsureDB()
    if not force and db.soundEnabled == false then return end

    if not force and type(GetTime) == "function" then
        local now = GetTime()
        if now - lastSoundAt < SOUND_COOLDOWN then return end
        lastSoundAt = now
    end

    PlayLuaErrorSoundPulse()

    if C_Timer and type(C_Timer.After) == "function" then
        for i = 2, SOUND_BURST_COUNT do
            C_Timer.After((i - 1) * SOUND_BURST_INTERVAL, PlayLuaErrorSoundPulse)
        end
    else
        for _ = 2, SOUND_BURST_COUNT do
            PlayLuaErrorSoundPulse()
        end
    end
end

local function GetTimestamp()
    if type(time) == "function" then
        local ok, value = pcall(time)
        if ok and value then return value end
    end
    return 0
end

local function FormatTimestamp(ts)
    if ts and ts > 0 and type(date) == "function" then
        local ok, value = pcall(date, "%Y-%m-%d %H:%M:%S", ts)
        if ok and value then return value end
    end
    return "Unknown"
end

local function GetPlayerTag()
    local name = "Unknown"
    if type(UnitNameUnmodified) == "function" then
        name = UnitNameUnmodified("player") or name
    elseif type(UnitName) == "function" then
        name = UnitName("player") or name
    end

    local realm = ""
    if type(GetNormalizedRealmName) == "function" then
        realm = GetNormalizedRealmName() or ""
    elseif type(GetRealmName) == "function" then
        realm = GetRealmName() or ""
    end

    if realm ~= "" then
        return name .. "-" .. realm
    end
    return name
end

local function FirstLine(text)
    text = tostring(text or "")
    local line = text:match("([^\r\n]+)") or text
    if line == "" then line = "Unknown error" end
    return line
end

local function TrimForList(text, limit)
    text = FirstLine(text)
    limit = limit or 80
    if #text > limit then
        return string.sub(text, 1, limit - 3) .. "..."
    end
    return text
end

local function StripColorCodes(text)
    text = tostring(text or "")
    text = text:gsub("|c%x%x%x%x%x%x%x%x", "")
    text = text:gsub("|r", "")
    text = text:gsub("|H.-|h(.-)|h", "%1")
    text = text:gsub("|T.-|t", "")
    text = text:gsub("||", "|")
    return text
end

local function ExtractAddonFromPath(text, skipOwnAddon)
    text = tostring(text or ""):gsub("\\", "/")
    for addon in text:gmatch("AddOns/([^/%s:\r\n]+)") do
        if not skipOwnAddon or addon ~= ADDON_NAME then
            return addon
        end
    end
    return nil
end

local function GuessAddon(message, stack)
    -- Prefer the actual error message. The handler stack often starts inside
    -- EnrageErrorLog, which would otherwise make external errors look ours.
    local addon = ExtractAddonFromPath(message, false)
    if addon then return addon end
    addon = ExtractAddonFromPath(stack, true)
    if addon then return addon end
    return "Unknown"
end

local function GetDebugStack()
    if type(debugstack) ~= "function" then return "" end

    if type(GetCallstackHeight) == "function" and type(GetErrorCallstackHeight) == "function" then
        local ok, stack = pcall(function()
            local currentStackHeight = GetCallstackHeight()
            local errorCallStackHeight = GetErrorCallstackHeight()
            if currentStackHeight and errorCallStackHeight then
                local debugStackLevel = currentStackHeight - (errorCallStackHeight - 1)
                return debugstack(debugStackLevel, 20, 20)
            end
            return nil
        end)
        if ok and stack then return tostring(stack) end
    end

    local ok, stack = pcall(debugstack, 4, 20, 20)
    if ok and stack then return tostring(stack) end
    return ""
end

local function RefreshStoredAddonGuesses()
    local db = EnsureDB()
    if db.addonGuessVersion == 2 then return end

    for _, entry in ipairs(db.entries) do
        if type(entry) == "table" then
            entry.addon = GuessAddon(entry.message, entry.stack)
        end
    end

    db.addonGuessVersion = 2
end

local function IsRateLimited()
    if type(GetTime) ~= "function" then return false end

    local now = GetTime()
    if now < throttledUntil then
        return true
    end

    if now - captureWindowStart > 1 then
        captureWindowStart = now
        captureWindowCount = 0
        throttleNoticePending = false
    end

    captureWindowCount = captureWindowCount + 1
    if captureWindowCount > ERROR_RATE_LIMIT then
        throttledUntil = now + ERROR_THROTTLE_SECONDS
        throttleNoticePending = true
        return true
    end

    return false
end

local function TrimStoredEntries(entries, maxEntries)
    maxEntries = maxEntries or MAX_ERROR_LOG
    while #entries > maxEntries do
        table.remove(entries)
    end
end

local function RefreshErrorButton()
    if type(_G.Enrage_RefreshErrorLogButton) == "function" then
        pcall(_G.Enrage_RefreshErrorLogButton)
    end
end

local function RefreshViewer()
    if errorFrame and errorFrame:IsShown() and type(errorFrame.Refresh) == "function" then
        errorFrame:Refresh()
    end
end

local function IsViewerShown()
    return errorFrame and errorFrame:IsShown()
end

local function MarkErrorsSeen()
    local db = EnsureDB()
    if db.unreadCount and db.unreadCount > 0 then
        db.unreadCount = 0
        RefreshErrorButton()
    end
end

local function GetExternalBugGrabber()
    local bg = _G.BugGrabber
    if type(bg) == "table"
        and type(bg.GetDB) == "function"
        and type(bg.GetSessionId) == "function"
    then
        return bg
    end
    return nil
end

local function FindEntryByErrorKey(entries, kind, message, addon)
    for i, entry in ipairs(entries) do
        if entry.kind == kind
            and entry.message == message
            and entry.addon == addon
        then
            return entry, i
        end
    end
    return nil
end

local function MoveEntryToTop(entries, index)
    if not index or index <= 1 then return end
    local entry = table.remove(entries, index)
    if entry then
        table.insert(entries, 1, entry)
    end
end

local function AddEntry(kind, message, stack, addonName, force)
    if handlingError and not force then return end

    handlingError = true
    local shouldPlaySound = false
    local ok = pcall(function()
        local db = EnsureDB()
        if db.enabled == false then return end

        if not force and IsRateLimited() then
            if throttleNoticePending then
                throttleNoticePending = false
                AddEntry(
                    "Throttle",
                    "Too many Lua errors at once. Enrage paused error capture for a few seconds.",
                    "",
                    ADDON_NAME or "Enrageplus",
                    true
                )
            end
            return
        end

        local entries = db.entries
        local cleanKind = kind or "Lua Error"
        local cleanMessage = tostring(message or "Unknown error")
        local cleanStack = tostring(stack or "")
        local cleanAddon = addonName or GuessAddon(cleanMessage, cleanStack)
        local now = GetTimestamp()
        local existing, existingIndex = FindEntryByErrorKey(entries, cleanKind, cleanMessage, cleanAddon)

        if existing then
            existing.count = (existing.count or 1) + 1
            existing.lastSeen = now
            existing.lastSeenText = FormatTimestamp(now)
            existing.stack = cleanStack
            if not IsViewerShown() then
                MoveEntryToTop(entries, existingIndex)
                selectedIndex = 1
            end
            return
        end

        local entry = {
            id = db.nextID,
            kind = cleanKind,
            message = cleanMessage,
            stack = cleanStack,
            addon = cleanAddon,
            player = GetPlayerTag(),
            firstSeen = now,
            firstSeenText = FormatTimestamp(now),
            lastSeen = now,
            lastSeenText = FormatTimestamp(now),
            count = 1,
            unread = true,
            soundPlayed = true,
        }

        db.nextID = db.nextID + 1
        table.insert(entries, 1, entry)
        TrimStoredEntries(entries, db.maxEntries)
        selectedIndex = 1
        if not IsViewerShown() then
            db.unreadCount = (db.unreadCount or 0) + 1
        end
        shouldPlaySound = true
    end)

    handlingError = false

    if ok then
        if shouldPlaySound then
            PlayLuaErrorSound(false)
        end
        RefreshErrorButton()
        RefreshViewer()
    end
end

local function HandleLuaError(err)
    local ok = pcall(function()
        local message = tostring(err or "Unknown Lua error")
        local stack = GetDebugStack()
        AddEntry("Lua Error", message, stack, GuessAddon(message, stack), false)
    end)
    if not ok then
        -- The handler must never throw back into the game's error path.
    end
end

local function SuppressBlizzardErrorUI()
    local db = EnsureDB()
    if db.suppressPopups == false then return end

    if UIParent and type(UIParent.UnregisterEvent) == "function" then
        pcall(UIParent.UnregisterEvent, UIParent, "ADDON_ACTION_BLOCKED")
        pcall(UIParent.UnregisterEvent, UIParent, "ADDON_ACTION_FORBIDDEN")
    end

    if ScriptErrorsFrame and type(ScriptErrorsFrame.UnregisterEvent) == "function" then
        pcall(ScriptErrorsFrame.UnregisterEvent, ScriptErrorsFrame, "LUA_WARNING")
        pcall(ScriptErrorsFrame.UnregisterEvent, ScriptErrorsFrame, "LUA_ERROR")
    end

    if ScriptErrorsFrame and type(ScriptErrorsFrame.Hide) == "function" then
        pcall(ScriptErrorsFrame.Hide, ScriptErrorsFrame)
    end
end

local function InstallErrorHandler()
    if GetExternalBugGrabber() then return end

    if type(seterrorhandler) == "function" then
        pcall(seterrorhandler, HandleLuaError)
    end
    SuppressBlizzardErrorUI()
end

local function RecordProtectedAction(event, addonName, functionName)
    addonName = tostring(addonName or "Unknown")
    functionName = tostring(functionName or "Unknown")

    local kind = "Blocked Action"
    if event == "ADDON_ACTION_FORBIDDEN" then
        kind = "Forbidden Action"
    end

    local message = string.format("AddOn '%s' tried to call protected function '%s'.", addonName, functionName)
    AddEntry(kind, message, GetDebugStack(), addonName, false)
end

local function RecordLuaWarning(...)
    local parts = {}
    for i = 1, select("#", ...) do
        parts[#parts + 1] = tostring(select(i, ...))
    end
    local message = table.concat(parts, " ")
    if message == "" then message = "Lua warning" end
    AddEntry("Lua Warning", message, GetDebugStack(), GuessAddon(message, ""), false)
end

local function GuessBugGrabberKind(message)
    message = tostring(message or "")
    if message:match("^LUA_WARNING:") then
        return "Lua Warning"
    end
    if message:find("ADDON_ACTION_BLOCKED", 1, true) then
        return "Blocked Action"
    end
    if message:find("ADDON_ACTION_FORBIDDEN", 1, true) then
        return "Forbidden Action"
    end
    return "Lua Error"
end

local function GetBugGrabberSourceKey(err, sessionID)
    return "BugGrabber:"
        .. tostring(sessionID or err.session or "?")
        .. ":"
        .. tostring(err.message or "")
end

local function FindEntryBySourceKey(entries, sourceKey)
    if not sourceKey then return nil end
    for i, entry in ipairs(entries) do
        if entry.sourceKey == sourceKey then
            return entry, i
        end
    end
    return nil
end

local function MirrorBugGrabberError(err, sessionID, silent)
    if type(err) ~= "table" then return end

    local db = EnsureDB()
    if db.enabled == false then return end

    local message = tostring(err.message or "Unknown BugGrabber error")
    local stack = tostring(err.stack or "")
    if err.locals and err.locals ~= "" then
        stack = stack .. "\n\nLocals:\n" .. tostring(err.locals)
    end

    local sourceKey = GetBugGrabberSourceKey(err, sessionID)
    local now = tonumber(err.time) or GetTimestamp()
    local entries = db.entries
    local existing = FindEntryBySourceKey(entries, sourceKey)
    local isNewEntry = false

    if existing then
        existing.kind = GuessBugGrabberKind(message)
        existing.message = message
        existing.stack = stack
        existing.addon = GuessAddon(message, stack)
        existing.lastSeen = now
        existing.lastSeenText = FormatTimestamp(now)
        existing.count = tonumber(err.counter) or existing.count or 1
    else
        local isUnread = not silent
        local entry = {
            id = db.nextID,
            kind = GuessBugGrabberKind(message),
            message = message,
            stack = stack,
            addon = GuessAddon(message, stack),
            player = GetPlayerTag(),
            firstSeen = now,
            firstSeenText = FormatTimestamp(now),
            lastSeen = now,
            lastSeenText = FormatTimestamp(now),
            count = tonumber(err.counter) or 1,
            source = "BugGrabber",
            sourceKey = sourceKey,
            unread = isUnread,
            soundPlayed = isUnread,
        }

        db.nextID = db.nextID + 1
        table.insert(entries, 1, entry)
        TrimStoredEntries(entries, db.maxEntries)
        selectedIndex = 1
        isNewEntry = true
    end

    if not silent and isNewEntry then
        if not IsViewerShown() then
            db.unreadCount = (db.unreadCount or 0) + 1
        end
        PlayLuaErrorSound(false)
    end
    RefreshErrorButton()
    RefreshViewer()
end

local function SyncBugGrabberSession(bg)
    if not bg then return end

    local okSession, sessionID = pcall(function()
        return bg:GetSessionId()
    end)
    if not okSession or not sessionID or lastSyncedBugGrabberSession == sessionID then return end
    lastSyncedBugGrabberSession = sessionID

    local okDB, bugDB = pcall(function()
        return bg:GetDB()
    end)
    if not okDB or type(bugDB) ~= "table" then return end

    for _, err in ipairs(bugDB) do
        if type(err) == "table" and err.session == sessionID then
            MirrorBugGrabberError(err, sessionID, true)
        end
    end
end

local function EnableBugGrabberMirror(bg)
    if not bg then return false end

    if not bugGrabberMirrorRegistered and EventRegistry and type(EventRegistry.RegisterCallback) == "function" then
        EventRegistry:RegisterCallback("BugGrabber.BugGrabbed", function(_, tableID)
            local activeBG = GetExternalBugGrabber()
            if not activeBG then return end

            local ok, err = pcall(function()
                if type(activeBG.GetErrorByID) == "function" then
                    return activeBG:GetErrorByID(tableID)
                end
                return nil
            end)
            if ok and err then
                local sessionID
                pcall(function() sessionID = activeBG:GetSessionId() end)
                MirrorBugGrabberError(err, sessionID)
            end
        end, bugGrabberCallbackOwner)

        bugGrabberMirrorRegistered = true

        if type(EventRegistry.TriggerEvent) == "function" then
            pcall(EventRegistry.TriggerEvent, EventRegistry, "BugGrabber.DisplayRegistered")
        end
    end

    SyncBugGrabberSession(bg)
    return true
end

local function CreateTextButton(parent, text, width, height, color)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width, height)

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(WHITE_TEX)
    bg:SetVertexColor(0.12, 0.13, 0.15, 0.96)

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetTexture(WHITE_TEX)
    border:SetVertexColor(color[1], color[2], color[3], 0.55)

    local label = btn:CreateFontString(nil, "OVERLAY")
    label:SetFont(FONT_FACE, 10, "OUTLINE")
    label:SetAllPoints()
    label:SetText(text)

    btn.bg = bg
    btn.border = border
    btn.label = label
    btn:SetScript("OnEnter", function()
        bg:SetVertexColor(0.18, 0.19, 0.22, 0.98)
        border:SetVertexColor(color[1], color[2], color[3], 0.9)
    end)
    btn:SetScript("OnLeave", function()
        bg:SetVertexColor(0.12, 0.13, 0.15, 0.96)
        border:SetVertexColor(color[1], color[2], color[3], 0.55)
    end)
    return btn
end

local function BuildDetailText(entry)
    if not entry then
        return "No Lua errors captured yet."
    end

    local lines = {}
    local function Add(line)
        lines[#lines + 1] = line or ""
    end

    Add("Enrage Lua Error Log")
    Add("")
    Add("ID: " .. tostring(entry.id or "-"))
    Add("Type: " .. tostring(entry.kind or "Lua Error"))
    Add("AddOn: " .. tostring(entry.addon or "Unknown"))
    Add("Player: " .. tostring(entry.player or "Unknown"))
    Add("First Seen: " .. tostring(entry.firstSeenText or "Unknown"))
    Add("Last Seen: " .. tostring(entry.lastSeenText or entry.firstSeenText or "Unknown"))
    Add("Count: " .. tostring(entry.count or 1))
    if entry.source then
        Add("Source: " .. tostring(entry.source))
    end
    Add("")
    Add("Message:")
    Add(StripColorCodes(entry.message or ""))

    if entry.stack and entry.stack ~= "" then
        Add("")
        Add("Stack:")
        Add(StripColorCodes(entry.stack))
    end

    return table.concat(lines, "\n")
end

function _G.EnragePlus:FormatError(err)
    if type(err) ~= "table" then
        return tostring(err or "Unknown error")
    end

    local stack = tostring(err.stack or "")
    if err.locals and err.locals ~= "" then
        stack = stack .. "\n\nLocals:\n" .. tostring(err.locals)
    end

    return BuildDetailText({
        id = tostring(err):gsub("^table: ", ""),
        kind = GuessBugGrabberKind(err.message),
        addon = GuessAddon(err.message, stack),
        player = GetPlayerTag(),
        firstSeenText = FormatTimestamp(tonumber(err.time) or GetTimestamp()),
        lastSeenText = FormatTimestamp(tonumber(err.time) or GetTimestamp()),
        count = tonumber(err.counter) or 1,
        source = "BugGrabber",
        message = tostring(err.message or "Unknown error"),
        stack = stack,
    })
end

local function EnsureViewer()
    if errorFrame then return errorFrame end

    local f = CreateFrame("Frame", "EnrageErrorLogFrame", UIParent, "BackdropTemplate")
    f:SetSize(760, 500)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(700)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdrop({
        bgFile = WHITE_TEX,
        edgeFile = WHITE_TEX,
        edgeSize = 1,
    })
    f:SetBackdropColor(0.06, 0.065, 0.08, 0.96)
    f:SetBackdropBorderColor(0.95, 0.38, 0.32, 0.85)
    f:Hide()

    local titleBar = CreateFrame("Frame", nil, f)
    titleBar:SetPoint("TOPLEFT", 1, -1)
    titleBar:SetPoint("TOPRIGHT", -1, -1)
    titleBar:SetHeight(34)

    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")
    titleBg:SetAllPoints()
    titleBg:SetTexture(WHITE_TEX)
    titleBg:SetVertexColor(0.11, 0.12, 0.15, 0.96)

    local title = titleBar:CreateFontString(nil, "OVERLAY")
    title:SetFont(FONT_FACE, 14, "OUTLINE")
    title:SetPoint("LEFT", 12, 0)
    title:SetText("|cFFF59E0BEnrage|r |cFFE5E7EBLua Errors|r")

    local countText = titleBar:CreateFontString(nil, "OVERLAY")
    countText:SetFont(FONT_FACE, 10, "OUTLINE")
    countText:SetPoint("LEFT", title, "RIGHT", 12, -1)
    countText:SetTextColor(0.8, 0.85, 0.92, 1)
    f.countText = countText

    local close = CreateTextButton(titleBar, "|cFFFF4D4DX|r", 24, 22, {1.0, 0.24, 0.2})
    close:SetPoint("RIGHT", -8, 0)
    close:SetFrameLevel(titleBar:GetFrameLevel() + 10)
    close.label:SetFont(FONT_FACE, 13, "OUTLINE")
    close:SetScript("OnClick", function() f:Hide() end)

    local clear = CreateTextButton(titleBar, "|cFFFF7A7AClear|r", 58, 20, {0.95, 0.38, 0.32})
    clear:SetPoint("RIGHT", close, "LEFT", -6, 0)
    clear:SetScript("OnClick", function()
        local db = EnsureDB()
        db.entries = {}
        db.nextID = 1
        db.unreadCount = 0
        selectedIndex = 1
        RefreshErrorButton()
        f:Refresh()
    end)

    local selectAll = CreateTextButton(titleBar, "|cFFE5E7EBSelect All|r", 78, 20, {0.56, 0.72, 1.0})
    selectAll:SetPoint("RIGHT", clear, "LEFT", -6, 0)
    selectAll:SetScript("OnClick", function()
        if f.detailEdit then
            f.detailEdit:SetFocus()
            f.detailEdit:HighlightText()
        end
    end)

    local soundToggle = CreateTextButton(titleBar, "|cFF7CFF8ASound On|r", 78, 20, {0.49, 1.0, 0.54})
    soundToggle:SetPoint("RIGHT", selectAll, "LEFT", -6, 0)

    local function UpdateSoundToggle()
        local db = EnsureDB()
        if db.soundEnabled == false then
            soundToggle.label:SetText("|cFF9CA3AFSound Off|r")
        else
            soundToggle.label:SetText("|cFF7CFF8ASound On|r")
        end
    end

    soundToggle:SetScript("OnClick", function()
        local db = EnsureDB()
        db.soundEnabled = not (db.soundEnabled == true)
        UpdateSoundToggle()
    end)
    f.UpdateSoundToggle = UpdateSoundToggle

    local testSound = CreateTextButton(titleBar, "|cFFE5E7EBTest|r", 44, 20, {0.96, 0.62, 0.04})
    testSound:SetPoint("RIGHT", soundToggle, "LEFT", -6, 0)
    testSound:SetScript("OnClick", function()
        PlayLuaErrorSound(true)
    end)

    local newer = CreateTextButton(titleBar, "|cFFE5E7EB>|r", 24, 20, {0.56, 0.72, 1.0})
    newer:SetPoint("RIGHT", testSound, "LEFT", -6, 0)
    newer.label:SetFont(FONT_FACE, 13, "OUTLINE")
    newer:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("|cFFE5E7EBNewer Error|r")
        GameTooltip:Show()
    end)
    newer:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    newer:SetScript("OnClick", function()
        if selectedIndex > 1 then
            selectedIndex = selectedIndex - 1
            f:Refresh()
        end
    end)

    local older = CreateTextButton(titleBar, "|cFFFFC38A<|r", 24, 20, {0.74, 0.42, 0.22})
    older:SetPoint("RIGHT", newer, "LEFT", -6, 0)
    older.label:SetFont(FONT_FACE, 13, "OUTLINE")
    older:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("|cFFE5E7EBOlder Error|r")
        GameTooltip:Show()
    end)
    older:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    older:SetScript("OnClick", function()
        local db = EnsureDB()
        if selectedIndex < #db.entries then
            selectedIndex = selectedIndex + 1
            f:Refresh()
        end
    end)

    local list = CreateFrame("Frame", nil, f, "BackdropTemplate")
    list:SetPoint("TOPLEFT", 10, -44)
    list:SetPoint("BOTTOMLEFT", 10, 10)
    list:SetWidth(270)
    list:SetBackdrop({
        bgFile = WHITE_TEX,
        edgeFile = WHITE_TEX,
        edgeSize = 1,
    })
    list:SetBackdropColor(0.08, 0.085, 0.1, 0.92)
    list:SetBackdropBorderColor(0.18, 0.2, 0.24, 1)

    f.rows = {}
    for i = 1, ROW_COUNT do
        local row = CreateFrame("Button", nil, list)
        row:SetHeight(32)
        row:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 34)
        row:SetPoint("RIGHT", -6, 0)

        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture(WHITE_TEX)
        bg:SetVertexColor(0.11, 0.115, 0.13, 0.86)
        row.bg = bg

        local marker = row:CreateTexture(nil, "BORDER")
        marker:SetPoint("TOPLEFT")
        marker:SetPoint("BOTTOMLEFT")
        marker:SetWidth(3)
        marker:SetTexture(WHITE_TEX)
        marker:SetVertexColor(0.35, 0.4, 0.48, 1)
        row.marker = marker

        local main = row:CreateFontString(nil, "OVERLAY")
        main:SetFont(FONT_FACE, 10, "OUTLINE")
        main:SetPoint("TOPLEFT", 8, -3)
        main:SetPoint("RIGHT", -6, 0)
        main:SetJustifyH("LEFT")
        main:SetTextColor(0.92, 0.94, 0.98, 1)
        row.main = main

        local meta = row:CreateFontString(nil, "OVERLAY")
        meta:SetFont(FONT_FACE, 9, "")
        meta:SetPoint("BOTTOMLEFT", 8, 4)
        meta:SetPoint("RIGHT", -6, 0)
        meta:SetJustifyH("LEFT")
        meta:SetTextColor(0.62, 0.66, 0.72, 1)
        row.meta = meta

        row:SetScript("OnClick", function(self)
            if self.entryIndex then
                selectedIndex = self.entryIndex
                local db = EnsureDB()
                local entry = db.entries and db.entries[selectedIndex]
                if entry then entry.unread = false end
                f:Refresh()
            end
        end)
        row:SetScript("OnEnter", function(self)
            if self.entryIndex ~= selectedIndex then
                self.bg:SetVertexColor(0.15, 0.16, 0.19, 0.9)
            end
        end)
        row:SetScript("OnLeave", function(self)
            if self.entryIndex ~= selectedIndex then
                local db = EnsureDB()
                local entry = db.entries and db.entries[self.entryIndex]
                if entry and entry.unread then
                    self.bg:SetVertexColor(0.075, 0.11, 0.17, 0.92)
                else
                    self.bg:SetVertexColor(0.11, 0.115, 0.13, 0.86)
                end
            end
        end)

        f.rows[i] = row
    end

    local detail = CreateFrame("Frame", nil, f, "BackdropTemplate")
    detail:SetPoint("TOPLEFT", list, "TOPRIGHT", 10, 0)
    detail:SetPoint("BOTTOMRIGHT", -10, 10)
    detail:SetBackdrop({
        bgFile = WHITE_TEX,
        edgeFile = WHITE_TEX,
        edgeSize = 1,
    })
    detail:SetBackdropColor(0.075, 0.08, 0.095, 0.94)
    detail:SetBackdropBorderColor(0.18, 0.2, 0.24, 1)

    local scroll = CreateFrame("ScrollFrame", "EnrageErrorLogDetailScroll", detail, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -8)
    scroll:SetPoint("BOTTOMRIGHT", -28, 8)

    local edit = CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFont(FONT_FACE, 11, "")
    edit:SetTextColor(0.9, 0.92, 0.96, 1)
    edit:SetJustifyH("LEFT")
    edit:SetJustifyV("TOP")
    edit:SetWidth(430)
    edit:SetHeight(2200)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scroll:SetScrollChild(edit)
    f.detailEdit = edit
    f.detailScroll = scroll

    function f:Refresh()
        local db = EnsureDB()
        local entries = db.entries
        if selectedIndex < 1 then selectedIndex = 1 end
        if selectedIndex > #entries then selectedIndex = math.max(1, #entries) end
        local selected = entries[selectedIndex]
        if selected and selected.unread then
            selected.unread = false
        end

        if self.countText then
            self.countText:SetText(string.format("|cFF9CA3AF%d stored|r", #entries))
        end

        for i, row in ipairs(self.rows) do
            local entry = entries[i]
            if entry then
                row.entryIndex = i
                row.main:SetText(TrimForList(StripColorCodes(entry.message), 43))
                row.meta:SetText(string.format("%s - %s x%d", tostring(entry.kind or "Lua Error"), tostring(entry.addon or "Unknown"), entry.count or 1))
                row:Show()

                if i == selectedIndex then
                    row.bg:SetVertexColor(0.22, 0.15, 0.11, 0.94)
                    row.marker:SetVertexColor(0.96, 0.62, 0.04, 1)
                elseif entry.unread then
                    row.bg:SetVertexColor(0.075, 0.11, 0.17, 0.92)
                    row.marker:SetVertexColor(0.28, 0.60, 1.0, 1)
                elseif entry.kind == "Throttle" then
                    row.bg:SetVertexColor(0.14, 0.11, 0.07, 0.9)
                    row.marker:SetVertexColor(0.96, 0.62, 0.04, 0.8)
                else
                    row.bg:SetVertexColor(0.11, 0.115, 0.13, 0.86)
                    row.marker:SetVertexColor(0.95, 0.38, 0.32, 0.75)
                end
            else
                row.entryIndex = nil
                row:Hide()
            end
        end

        self.detailEdit:SetText(BuildDetailText(selected))
        self.detailEdit:ClearFocus()
        self.detailScroll:SetVerticalScroll(0)
        if self.UpdateSoundToggle then
            self.UpdateSoundToggle()
        end
    end

    errorFrame = f
    return f
end

local function ShowViewer()
    RefreshStoredAddonGuesses()
    local f = EnsureViewer()
    MarkErrorsSeen()
    f:Refresh()
    f:Show()
end

local function ToggleViewer()
    RefreshStoredAddonGuesses()
    local f = EnsureViewer()
    if f:IsShown() then
        f:Hide()
    else
        MarkErrorsSeen()
        f:Refresh()
        f:Show()
    end
end

local function ClearLog()
    local db = EnsureDB()
    db.entries = {}
    db.nextID = 1
    db.unreadCount = 0
    selectedIndex = 1
    RefreshErrorButton()
    RefreshViewer()
end

_G.Enrage_ShowErrorLogWindow = ShowViewer
_G.Enrage_ToggleErrorLogWindow = ToggleViewer
_G.Enrage_ClearErrorLog = ClearLog
_G.Enrage_GetLuaErrorCount = function()
    local db = EnsureDB()
    return #db.entries
end
_G.Enrage_GetUnreadLuaErrorCount = function()
    local db = EnsureDB()
    return db.unreadCount or 0
end
_G.Enrage_RecordLuaError = function(kind, message, stack, addonName)
    AddEntry(kind or "Lua Error", message, stack, addonName, true)
end

SLASH_ENRAGEERRORLOG1 = "/enbugs"
SLASH_ENRAGEERRORLOG2 = "/enerrors"
SLASH_ENRAGEERRORLOG3 = "/enerr"
SlashCmdList["ENRAGEERRORLOG"] = function(msg)
    msg = tostring(msg or ""):lower()
    if msg == "clear" then
        ClearLog()
        print("|cFFE5E7EB[Enrage]|r Lua error log cleared.")
    else
        ToggleViewer()
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("ADDON_LOADED")

local function RegisterNativeCaptureEvents()
    if nativeEventsRegistered then return end
    eventFrame:RegisterEvent("ADDON_ACTION_BLOCKED")
    eventFrame:RegisterEvent("ADDON_ACTION_FORBIDDEN")
    pcall(eventFrame.RegisterEvent, eventFrame, "LUA_WARNING")
    nativeEventsRegistered = true
end

local function UnregisterNativeCaptureEvents()
    if not nativeEventsRegistered then return end
    eventFrame:UnregisterEvent("ADDON_ACTION_BLOCKED")
    eventFrame:UnregisterEvent("ADDON_ACTION_FORBIDDEN")
    pcall(eventFrame.UnregisterEvent, eventFrame, "LUA_WARNING")
    nativeEventsRegistered = false
end

local function ApplyCaptureMode()
    local bg = GetExternalBugGrabber()
    if bg then
        UnregisterNativeCaptureEvents()
        EnableBugGrabberMirror(bg)
    else
        RegisterNativeCaptureEvents()
        InstallErrorHandler()
    end
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        ApplyCaptureMode()
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(1, ApplyCaptureMode)
            C_Timer.After(5, ApplyCaptureMode)
        end
    elseif event == "ADDON_LOADED" then
        ApplyCaptureMode()
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        RecordProtectedAction(event, ...)
    elseif event == "LUA_WARNING" then
        RecordLuaWarning(...)
    end
end)

ApplyCaptureMode()
