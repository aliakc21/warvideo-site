
local L = AkcQOL_L

local orb = CreateFrame("Button", "AkcQOLOrb", UIParent)
orb:SetSize(32, 32)
orb:SetFrameStrata("TOOLTIP")
orb:SetFrameLevel(10000)
orb:SetClampedToScreen(false)
if orb.SetUserPlaced then pcall(orb.SetUserPlaced, orb, false) end
if orb.SetDontSavePosition then pcall(orb.SetDontSavePosition, orb, true) end
if orb.SetToplevel then pcall(orb.SetToplevel, orb, true) end

local function UpdateOrbPosition()
    if not UIParent then return end
    if orb.SetParent then pcall(orb.SetParent, orb, UIParent) end
    if orb.SetScale then pcall(orb.SetScale, orb, 1) end
    if orb.SetSize then pcall(orb.SetSize, orb, 32, 32) end
    if orb.SetFrameStrata then pcall(orb.SetFrameStrata, orb, "TOOLTIP") end
    if orb.SetFrameLevel then pcall(orb.SetFrameLevel, orb, 10000) end
    if orb.SetClampedToScreen then pcall(orb.SetClampedToScreen, orb, false) end
    if orb.SetUserPlaced then pcall(orb.SetUserPlaced, orb, false) end
    if orb.SetDontSavePosition then pcall(orb.SetDontSavePosition, orb, true) end
    if orb.SetToplevel then pcall(orb.SetToplevel, orb, true) end
    orb:ClearAllPoints()
    orb:SetPoint("TOPLEFT", WorldFrame or UIParent, "TOPLEFT", 0, 0)
    if orb.Raise then pcall(orb.Raise, orb) end
end
UpdateOrbPosition()

orb:Hide()

C_Timer.NewTicker(2, function()
    if not UIParent then return end

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showOrb == false then return end
    local point, relativeTo, relativePoint, x, y = orb:GetPoint(1)
    if orb:GetParent() ~= UIParent
        or math.abs((orb:GetScale() or 1) - 1) > 0.001
        or math.abs((orb:GetWidth() or 0) - 32) > 0.1
        or math.abs((orb:GetHeight() or 0) - 32) > 0.1
        or orb:GetFrameStrata() ~= "TOOLTIP"
        or (orb:GetFrameLevel() or 0) ~= 10000
        or point ~= "TOPLEFT"
        or relativeTo ~= (WorldFrame or UIParent)
        or relativePoint ~= "TOPLEFT"
        or math.abs(tonumber(x) or 0) > 0.1
        or math.abs(tonumber(y) or 0) > 0.1
    then
        UpdateOrbPosition()
    end
end)

orb.border = orb:CreateTexture(nil, "BACKGROUND")
orb.border:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.border:SetAllPoints(orb)
orb.border:SetVertexColor(0.86, 0.70, 0.24, 1)

orb.borderMask = orb:CreateMaskTexture()
orb.borderMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.borderMask:SetAllPoints(orb)
if orb.borderMask.SetTexCoord then orb.borderMask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.border:AddMaskTexture(orb.borderMask)

orb.innerShadow = orb:CreateTexture(nil, "BORDER")
orb.innerShadow:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.innerShadow:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.innerShadow:SetSize(26, 26)
orb.innerShadow:SetVertexColor(0.02, 0.018, 0.012, 1)

orb.innerShadowMask = orb:CreateMaskTexture()
orb.innerShadowMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.innerShadowMask:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.innerShadowMask:SetSize(26, 26)
if orb.innerShadowMask.SetTexCoord then orb.innerShadowMask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.innerShadow:AddMaskTexture(orb.innerShadowMask)

orb.fill = orb:CreateTexture(nil, "ARTWORK")
orb.fill:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.fill:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.fill:SetSize(22, 22)
orb.fill:SetVertexColor(0, 0, 0, 1)

orb.mask = orb:CreateMaskTexture()
orb.mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.mask:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.mask:SetSize(22, 22)
if orb.mask.SetTexCoord then orb.mask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.fill:AddMaskTexture(orb.mask)

orb.wipeOverlay = orb:CreateTexture(nil, "OVERLAY", nil, 7)
orb.wipeOverlay:SetTexture("Interface\\Buttons\\WHITE8X8")
orb.wipeOverlay:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.wipeOverlay:SetSize(22, 22)
orb.wipeOverlay:Hide()

orb.wipeMask = orb:CreateMaskTexture()
orb.wipeMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
orb.wipeMask:SetPoint("CENTER", orb, "CENTER", 0, 0)
orb.wipeMask:SetSize(22, 22)
if orb.wipeMask.SetTexCoord then orb.wipeMask:SetTexCoord(0.055, 0.945, 0.055, 0.945) end
orb.wipeOverlay:AddMaskTexture(orb.wipeMask)

orb:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine(L["Click to toggle the Matrix account overview window."], 1, 1, 1)
    GameTooltip:Show()
end)
orb:SetScript("OnLeave", function(self)
    GameTooltip:Hide()
end)

orb:SetScript("OnClick", function()
    if SlashCmdList["AKCQOL"] then
        SlashCmdList["AKCQOL"]("")
    end
end)

local lastBossHP = 100
local isInEncounter = false
local wipeSignalActive = false
local bossHPSampled = false

local function SampleLowestBossHP()
    local lowest = 100
    for i = 1, 5 do
        local unit = "boss" .. i
        local ok, pct = pcall(function()
            if not UnitExists(unit) then return nil end
            local h = UnitHealth(unit) or 0
            local m = UnitHealthMax(unit) or 0
            if m <= 0 then return nil end
            return math.floor((h / m) * 100 + 0.5)
        end)
        if ok and pct and pct >= 0 then
            bossHPSampled = true
            if pct < lowest then lowest = pct end
        end
    end
    return lowest
end

local bossHPFrame = CreateFrame("Frame")
bossHPFrame:RegisterEvent("UNIT_HEALTH")
bossHPFrame:SetScript("OnEvent", function(_, _, unit)
    if not isInEncounter then return end
    if not unit or not string.match(unit, "^boss%d+$") then return end
    local lowest = SampleLowestBossHP()
    if lowest < lastBossHP then lastBossHP = lowest end
end)

bossHPFrame.akcqolElapsed = 0
bossHPFrame:SetScript("OnUpdate", function(self, elapsed)
    if not isInEncounter then return end
    self.akcqolElapsed = self.akcqolElapsed + elapsed
    if self.akcqolElapsed < 0.5 then return end
    self.akcqolElapsed = 0
    local lowest = SampleLowestBossHP()
    if lowest < lastBossHP then lastBossHP = lowest end
end)

local function ForceUpdateColor()
    if wipeSignalActive then return end
    local inInstance, instanceType = IsInInstance()
    if inInstance and (instanceType == "party" or instanceType == "raid") then
        orb.fill:SetVertexColor(1, 0, 1, 1)
    else
        orb.fill:SetVertexColor(0.16, 0.17, 0.18, 1)
    end
end

local akcqolForcedLog = false
local function ApplyWarvideoLogging()
    local on = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.warvideoLogging == true
    if not on then
        if akcqolForcedLog and LoggingCombat and LoggingCombat() then
            LoggingCombat(false)
        end
        akcqolForcedLog = false
        return
    end
    local inInstance, instanceType = IsInInstance()
    local want = inInstance and (instanceType == "raid" or instanceType == "party" or instanceType == "scenario")
    if want then
        pcall(function()
            if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar("advancedCombatLogging", "1")
            elseif SetCVar then SetCVar("advancedCombatLogging", "1") end
        end)
        if LoggingCombat and not LoggingCombat() then
            LoggingCombat(true)
            akcqolForcedLog = true
        end
    elseif akcqolForcedLog then
        if LoggingCombat and LoggingCombat() then LoggingCombat(false) end
        akcqolForcedLog = false
    end
end
_G.AkcQOL_ApplyWarvideoLogging = ApplyWarvideoLogging

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("PLAYER_DIFFICULTY_CHANGED")
eventFrame:RegisterEvent("LOADING_SCREEN_DISABLED")
eventFrame:RegisterEvent("CHALLENGE_MODE_START")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
eventFrame:RegisterEvent("DISPLAY_SIZE_CHANGED")
eventFrame:RegisterEvent("UI_SCALE_CHANGED")
eventFrame:RegisterEvent("CVAR_UPDATE")
eventFrame:RegisterEvent("ENCOUNTER_START")
eventFrame:RegisterEvent("ENCOUNTER_END")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ENCOUNTER_START" then
        isInEncounter = true
        lastBossHP = 100
        bossHPSampled = false
        ForceUpdateColor()
        return
    elseif event == "ENCOUNTER_END" then
        local _, _, _, _, success = ...
        isInEncounter = false
        if success == 0 then

            local lowest = SampleLowestBossHP()
            if lowest < lastBossHP then lastBossHP = lowest end

            local hpNorm = math.max(0, math.min(1, lastBossHP / 100))
            orb.wipeOverlay:SetVertexColor(hpNorm, 0.87, 0.435, 1)
            orb.wipeOverlay:Show()
            orb.fill:SetVertexColor(hpNorm, 0.87, 0.435, 1)
            wipeSignalActive = true

            if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.wipeChatPrint then
                if bossHPSampled then
                    print(string.format(L["|cff8c5cffAkc|r|cffffffffQOL|r: Wipe at %d%% boss HP."], lastBossHP))
                end

            end

            C_Timer.After(5, function()
                orb.wipeOverlay:Hide()
                wipeSignalActive = false
                ForceUpdateColor()
            end)
        else
            ForceUpdateColor()
        end
        return
    end
    ForceUpdateColor()

    if event == "PLAYER_ENTERING_WORLD" then
        ApplyWarvideoLogging()
    end
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" or event == "LOADING_SCREEN_DISABLED"
        or event == "DISPLAY_SIZE_CHANGED" or event == "UI_SCALE_CHANGED" or event == "CVAR_UPDATE" then
        UpdateOrbPosition()
        if C_Timer and C_Timer.After then
            C_Timer.After(0.1, UpdateOrbPosition)
            C_Timer.After(0.5, UpdateOrbPosition)
            C_Timer.After(1.5, UpdateOrbPosition)
        end
        if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showOrb == false then
            orb:Hide()
        else
            orb:Show()
        end
    end
end)

C_Timer.NewTicker(10, function()

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showOrb == false then return end
    ForceUpdateColor()
end)
ForceUpdateColor()

do
    local resetFrame = CreateFrame("Frame")
    local lastResetAnnounce = 0
    resetFrame:RegisterEvent("CHAT_MSG_SYSTEM")
    resetFrame:SetScript("OnEvent", function(_, event, msg)
        if event ~= "CHAT_MSG_SYSTEM" or not msg then return end

        if not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.announceInstanceReset) then return end

        local isReset = false
        pcall(function()
            if string.find(msg, "has been reset", 1, true)
               or string.find(msg, "have been reset", 1, true)
               or string.find(msg, "instances have been reset", 1, true)
               or string.find(msg, "s\196\177f\196\177rland\196\177", 1, true)
               or string.find(msg, "resetlendi", 1, true)
               or string.find(msg, "zur\195\188ckgesetzt", 1, true)
               or string.find(msg, "r\195\169initialis\195\169", 1, true)
            then
                isReset = true
            end
        end)
        if not isReset then return end

        local now = GetTime and GetTime() or 0
        if now - lastResetAnnounce < 5 then return end
        lastResetAnnounce = now

        local channel = nil
        if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
            channel = "INSTANCE_CHAT"
        elseif IsInRaid(LE_PARTY_CATEGORY_HOME) then
            channel = "RAID"
        elseif IsInGroup(LE_PARTY_CATEGORY_HOME) then
            channel = "PARTY"
        end

        if channel then
            SendChatMessage(L["[AkcQOL] Instances have been reset."], channel)
        else
            print(L["|cff8c5cffAkc|r|cffffffffQOL|r: Instances have been reset."])
        end
    end)
end

WV_LOG_FRAMES = {}

do
    local DIFF_INFO = {
        [17] = { label = "LFR",     color = {0.50, 0.80, 0.50} },
        [14] = { label = "Normal",  color = {0.30, 1.00, 0.30} },
        [15] = { label = "Heroic",  color = {1.00, 0.60, 0.00} },
        [16] = { label = "Mythic",  color = {0.78, 0.30, 1.00} },
    }
    local DIFF_ORDER = {17, 14, 15, 16}
    local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
    local BAR_TEX  = "Interface\\TargetingFrame\\UI-StatusBar"

    local RAID_ENTRANCES = {

        [2405] = {
            { x = 0.455, y = 0.644, name = "The Voidspire" },
        },
        [2413] = {
            { x = 0.614, y = 0.628, name = "The Dreamrift" },
        },

        [2255] = {{ x = 0.47,  y = 0.57,  name = "Nerub-ar Palace" }},

        [2133] = {{ x = 0.49,  y = 0.23,  name = "Aberrus, the Shadowed Crucible" }},
        [2200] = {{ x = 0.56,  y = 0.26,  name = "Amirdrassil, the Dream's Hope" }},
        [2025] = {{ x = 0.73,  y = 0.56,  name = "Vault of the Incarnates" }},
    }
    local ENTRANCE_RADIUS = 0.015

    local KNOWN_BOSS_COUNTS = {
        ["The Voidspire"] = 6,
        ["The Dreamrift"] = 3,
        ["Nerub-ar Palace"] = 8,
        ["Aberrus, the Shadowed Crucible"] = 9,
        ["Amirdrassil, the Dream's Hope"] = 9,
        ["Vault of the Incarnates"] = 8,
    }

    local TAB_H = 30

    local progressFrame = CreateFrame("Frame", "AkcQOLRaidProgressFrame", UIParent)
    progressFrame:SetFrameStrata("HIGH")
    progressFrame:SetPoint("TOP", UIParent, "TOP", 0, 0)
    progressFrame:SetSize(600, TAB_H + 4)
    progressFrame:Hide()

    local raidNameText = progressFrame:CreateFontString(nil, "OVERLAY")
    raidNameText:SetFont("Fonts\\MORPHEUS.TTF", 15, "")
    raidNameText:SetPoint("LEFT", 10, 0)
    raidNameText:SetTextColor(1, 0.82, 0)
    raidNameText:SetShadowOffset(1, -1)
    raidNameText:SetShadowColor(0, 0, 0, 0.9)

    local sepDot = progressFrame:CreateFontString(nil, "OVERLAY")
    AkcQOL_Theme.SetFont(sepDot, 10, "OUTLINE")
    sepDot:SetTextColor(0.4, 0.35, 0.15, 0.7)
    sepDot:SetText("|")

    local tabs = {}
    local raidProgressData = {}

    local function CreateTab(index)
        local tab = CreateFrame("Frame", nil, progressFrame)
        tab:SetSize(120, TAB_H)
        tab:EnableMouse(true)

        local tbg = tab:CreateTexture(nil, "BACKGROUND")
        tbg:SetPoint("TOPLEFT", 1, -1)
        tbg:SetPoint("BOTTOMRIGHT", -1, 1)
        tbg:SetTexture(BAR_TEX)
        tbg:SetVertexColor(0.07, 0.07, 0.10, 0.85)
        tab.bg = tbg

        local hlTop = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlTop:SetTexture(FLAT_TEX); hlTop:SetVertexColor(0.82, 0.68, 0.18, 1)
        hlTop:SetHeight(2); hlTop:SetPoint("TOPLEFT"); hlTop:SetPoint("TOPRIGHT")
        hlTop:Hide(); tab.hlTop = hlTop

        local hlBot = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlBot:SetTexture(FLAT_TEX); hlBot:SetVertexColor(0.82, 0.68, 0.18, 0.4)
        hlBot:SetHeight(1); hlBot:SetPoint("BOTTOMLEFT"); hlBot:SetPoint("BOTTOMRIGHT")
        hlBot:Hide(); tab.hlBot = hlBot

        local hlLeft = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlLeft:SetTexture(FLAT_TEX); hlLeft:SetVertexColor(0.82, 0.68, 0.18, 0.5)
        hlLeft:SetWidth(1); hlLeft:SetPoint("TOPLEFT"); hlLeft:SetPoint("BOTTOMLEFT")
        hlLeft:Hide(); tab.hlLeft = hlLeft

        local hlRight = tab:CreateTexture(nil, "ARTWORK", nil, 2)
        hlRight:SetTexture(FLAT_TEX); hlRight:SetVertexColor(0.82, 0.68, 0.18, 0.5)
        hlRight:SetWidth(1); hlRight:SetPoint("TOPRIGHT"); hlRight:SetPoint("BOTTOMRIGHT")
        hlRight:Hide(); tab.hlRight = hlRight

        local diffLabel = tab:CreateFontString(nil, "OVERLAY")
        AkcQOL_Theme.SetFont(diffLabel, 11, "OUTLINE")
        diffLabel:SetPoint("LEFT", 10, 0)
        diffLabel:SetShadowOffset(1, -1)
        diffLabel:SetShadowColor(0, 0, 0, 1)
        tab.diffLabel = diffLabel

        local countLabel = tab:CreateFontString(nil, "OVERLAY")
        AkcQOL_Theme.SetFont(countLabel, 13, "OUTLINE")
        countLabel:SetPoint("RIGHT", -10, 0)
        countLabel:SetShadowOffset(1, -1)
        countLabel:SetShadowColor(0, 0, 0, 1)
        tab.countLabel = countLabel

        tab.raidName = nil
        tab.diffID = nil
        tab:SetScript("OnEnter", function(self)
            if not self.raidName or not self.diffID then return end
            local data = raidProgressData[self.raidName] and raidProgressData[self.raidName][self.diffID]
            local di = DIFF_INFO[self.diffID]
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM", 0, -4)
            GameTooltip:AddLine(self.raidName, 1, 0.82, 0)
            if di then GameTooltip:AddLine(di.label, di.color[1], di.color[2], di.color[3]) end
            GameTooltip:AddLine(" ")
            if data and data.bosses then
                for _, boss in ipairs(data.bosses) do
                    if boss.killed then
                        GameTooltip:AddDoubleLine("  " .. boss.name, "|TInterface\\RAIDFRAME\\ReadyCheck-Ready:0|t", 0.5, 0.5, 0.5)
                    else
                        GameTooltip:AddDoubleLine("  " .. boss.name, "|TInterface\\RAIDFRAME\\ReadyCheck-NotReady:0|t", 0.9, 0.9, 0.9)
                    end
                end
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(string.format(L["Progress: %d / %d"], data.killed, data.total), 1, 1, 0.6)
            else
                GameTooltip:AddLine(L["No lockout"], 0.5, 0.5, 0.5)
            end
            GameTooltip:Show()
            self.bg:SetVertexColor(0.14, 0.12, 0.08, 0.9)
        end)
        tab:SetScript("OnLeave", function(self)
            GameTooltip:Hide()
            if self.isActive then
                self.bg:SetVertexColor(0.12, 0.10, 0.04, 0.9)
            else
                self.bg:SetVertexColor(0.07, 0.07, 0.10, 0.85)
            end
        end)

        tab:Hide()
        tabs[index] = tab
        return tab
    end

    for i = 1, 4 do CreateTab(i) end

    local function SetTabActive(tab, active)
        tab.isActive = active
        if active then
            tab.hlTop:Show(); tab.hlBot:Show(); tab.hlLeft:Show(); tab.hlRight:Show()
            tab.bg:SetVertexColor(0.12, 0.10, 0.04, 0.9)
        else
            tab.hlTop:Hide(); tab.hlBot:Hide(); tab.hlLeft:Hide(); tab.hlRight:Hide()
            tab.bg:SetVertexColor(0.07, 0.07, 0.10, 0.85)
        end
    end

    local function RefreshRaidProgress()
        raidProgressData = {}

        local numSaved = GetNumSavedInstances()
        for i = 1, numSaved do
            local name, _, _, difficultyID, locked, _, _, isRaid, _, _, numEncounters, encounterProgress = GetSavedInstanceInfo(i)
            if isRaid and locked and DIFF_INFO[difficultyID] then
                if not raidProgressData[name] then raidProgressData[name] = {} end
                local bosses = {}
                for j = 1, numEncounters do
                    local bossName, _, isKilled = GetSavedInstanceEncounterInfo(i, j)
                    bosses[j] = { name = bossName or ("Boss " .. j), killed = isKilled }
                end
                raidProgressData[name][difficultyID] = {
                    killed = encounterProgress or 0,
                    total = numEncounters or 0,
                    bosses = bosses,
                    locked = locked,
                }
            end
        end
    end

    local function DetectNearbyRaid()

        local _, instanceType = GetInstanceInfo()
        if instanceType ~= "none" then return nil end

        local mapID = C_Map.GetBestMapForUnit("player")
        if not mapID then return nil end

        local entrances = RAID_ENTRANCES[mapID]
        if not entrances then return nil end

        local pos = C_Map.GetPlayerMapPosition(mapID, "player")
        if not pos then return nil end
        local px, py = pos:GetXY()
        if not px or not py then return nil end

        for _, entrance in ipairs(entrances) do
            local dx = px - entrance.x
            local dy = py - entrance.y
            local dist = math.sqrt(dx * dx + dy * dy)
            if dist <= ENTRANCE_RADIUS then
                return entrance.name
            end
        end

        return nil
    end

    local function UpdateProgressDisplay()

        if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showRaidProgress == false then
            progressFrame:Hide()
            return
        end

        local displayRaid = DetectNearbyRaid()

        if not displayRaid then
            progressFrame:Hide()
            return
        end

        RefreshRaidProgress()

        local raidData = raidProgressData[displayRaid]

        if not raidData then
            raidData = {}
        end

        raidNameText:SetText(displayRaid or "Raid")
        local currentRaidDiff = GetRaidDifficultyID() or 14
        local nameW = raidNameText:GetStringWidth() + 18

        sepDot:ClearAllPoints()
        sepDot:SetPoint("LEFT", progressFrame, "LEFT", nameW, 0)
        local sepW = sepDot:GetStringWidth() + 10

        local totalW = nameW + sepW
        for idx, diffID in ipairs(DIFF_ORDER) do
            local tab = tabs[idx]
            local di  = DIFF_INFO[diffID]
            local data = raidData[diffID]
            local killed = data and data.killed or 0
            local total  = data and data.total or 0

            if total == 0 then
                for _, od in ipairs(DIFF_ORDER) do
                    if raidData[od] and raidData[od].total > 0 then total = raidData[od].total; break end
                end
            end
            if total == 0 then total = KNOWN_BOSS_COUNTS[displayRaid] or 0 end

            tab.diffLabel:SetText(di.label)
            tab.diffLabel:SetTextColor(di.color[1], di.color[2], di.color[3])

            local countStr = string.format("(%d/%d)", killed, total)
            if killed == total and total > 0 then
                tab.countLabel:SetText("|cff00ff00" .. countStr .. "|r")
            elseif killed > 0 then
                tab.countLabel:SetText("|cffffffff" .. countStr .. "|r")
            else
                tab.countLabel:SetText("|cff555555" .. countStr .. "|r")
            end

            SetTabActive(tab, diffID == currentRaidDiff)
            tab.raidName = displayRaid
            tab.diffID = diffID

            local tabW = math.max(115, tab.diffLabel:GetStringWidth() + tab.countLabel:GetStringWidth() + 32)
            tab:SetSize(tabW, TAB_H)
            tab:ClearAllPoints()
            tab:SetPoint("LEFT", progressFrame, "LEFT", totalW, 0)
            totalW = totalW + tabW + 3
            tab:Show()
        end

        for i = #DIFF_ORDER + 1, #tabs do
            if tabs[i] then tabs[i]:Hide() end
        end

        progressFrame:SetWidth(totalW + 8)
        progressFrame:Show()
    end

    local rpEventFrame = CreateFrame("Frame")
    rpEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    rpEventFrame:RegisterEvent("UPDATE_INSTANCE_INFO")
    rpEventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    rpEventFrame:SetScript("OnEvent", function()
        C_Timer.After(0.5, function()
            RequestRaidInfo()
            C_Timer.After(0.5, UpdateProgressDisplay)
        end)
    end)

    C_Timer.After(3, function()
        C_Timer.NewTicker(2, function()

            if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showRaidProgress == false then
                if progressFrame:IsShown() then progressFrame:Hide() end
                return
            end
            local mapID = C_Map.GetBestMapForUnit("player") or 0
            if RAID_ENTRANCES[mapID] then
                UpdateProgressDisplay()
            elseif progressFrame:IsShown() then
                progressFrame:Hide()
            end
        end)
    end)

    
end

local AkcQOLMinimapBtn = CreateFrame("Button", "AkcQOLMinimapBtn", Minimap)
AkcQOLMinimapBtn:SetSize(33, 33)
AkcQOLMinimapBtn:SetFrameStrata("MEDIUM")
AkcQOLMinimapBtn:SetFrameLevel(8)
AkcQOLMinimapBtn:SetMovable(true)
AkcQOLMinimapBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
AkcQOLMinimapBtn:RegisterForDrag("LeftButton")
AkcQOLMinimapBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local mmOverlay = AkcQOLMinimapBtn:CreateTexture(nil, "OVERLAY")
mmOverlay:SetSize(53, 53)
mmOverlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
mmOverlay:SetPoint("TOPLEFT")

local mmIcon = AkcQOLMinimapBtn:CreateTexture(nil, "BACKGROUND")
mmIcon:SetSize(21, 21)

mmIcon:SetTexture(AkcQOL_Theme.iconPath)
mmIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
mmIcon:SetPoint("CENTER", AkcQOLMinimapBtn, "CENTER", 1, 1)

AkcQOLMinimapBtn:Hide()

AkcQOLMinimapBtn.icon = mmIcon

if not AkcQOLDB then AkcQOLDB = {} end
if not AkcQOLDB.global then AkcQOLDB.global = {} end

if _G.AkcQOLQoL_FreshInstall and AkcQOLDB.global.qolOptInV1 == nil then
    local g = AkcQOLDB.global
    g.autoSell = false
    g.autoRepair = false
    g.fastLoot = false
    g.autoInsertKeystone = false
    g.autoCinematic = false
    g.showOrb = false
    g.showMinimap = true
    g.showItemLevel = false
    g.showRaidProgress = false
    g.showTalentHelper = false
    g.qolOptInV1 = true
end

if AkcQOLDB.global.minimapAngle == nil then AkcQOLDB.global.minimapAngle = 220 end

local function UpdateMinimapBtnPos()
    local angle = math.rad(AkcQOLDB.global.minimapAngle or 220)
    local radius = 105
    local w, h = Minimap:GetSize()

    local isSquare = false
    if GetMinimapShape then
        local shape = GetMinimapShape()
        if shape and shape ~= "ROUND" then isSquare = true end
    end

    if not isSquare and w and h and math.abs(w - h) < 2 then

        local hasMaskFunc = Minimap.GetMaskTexture
        if hasMaskFunc then
            local mask = Minimap:GetMaskTexture()
            if mask and type(mask) == "string" and mask:lower():find("square") then
                isSquare = true
            end
        end
    end

    local x, y
    if isSquare then

        local halfW, halfH = w / 2, h / 2
        x = math.cos(angle) * (halfW + 16)
        y = math.sin(angle) * (halfH + 16)

        local maxDist = math.max(math.abs(x), math.abs(y))
        local edgeDist = halfW + 6
        if maxDist > 0 then
            local scale = edgeDist / maxDist
            x = x * scale
            y = y * scale
        end
    else

        x = math.cos(angle) * radius
        y = math.sin(angle) * radius
    end
    AkcQOLMinimapBtn:ClearAllPoints()
    AkcQOLMinimapBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end
UpdateMinimapBtnPos()

AkcQOLMinimapBtn:SetScript("OnDragStart", function(self)
    self.isDragging = true
    self:SetScript("OnUpdate", function(self)
        local mx, my = Minimap:GetCenter()
        local cx, cy = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        cx, cy = cx / scale, cy / scale
        local angle = math.deg(math.atan2(cy - my, cx - mx))
        AkcQOLDB.global.minimapAngle = angle
        UpdateMinimapBtnPos()
    end)
end)

AkcQOLMinimapBtn:SetScript("OnDragStop", function(self)
    self.isDragging = false
    self:SetScript("OnUpdate", nil)
end)

AkcQOLMinimapBtn:SetScript("OnClick", function(self, button)
    if button == "LeftButton" then
        SlashCmdList["AKCQOL"]()
    elseif button == "RightButton" then

        if AkcQOL_ShowLogsWindow then AkcQOL_ShowLogsWindow("settings") end
    end
end)

AkcQOLMinimapBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine(L["Left-Click: Toggle Matrix (account overview)"], 1, 1, 1)
    GameTooltip:AddLine(L["Right-Click: Settings"], 1, 1, 1)
    GameTooltip:AddLine(L["Drag: Move icon"], 0.7, 0.7, 0.7)
    GameTooltip:Show()
end)

AkcQOLMinimapBtn:SetScript("OnLeave", function()
    GameTooltip:Hide()
end)

local mmInitFrame = CreateFrame("Frame")
mmInitFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
mmInitFrame:SetScript("OnEvent", function()
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showMinimap == false then
        AkcQOLMinimapBtn:Hide()
    else
        AkcQOLMinimapBtn:Show()
    end
    UpdateMinimapBtnPos()
end)

local AkcQOLBarBtn = CreateFrame("CheckButton", "AkcQOLBarBtn", UIParent, "UICheckButtonTemplate")
AkcQOLBarBtn:SetSize(24, 24)
AkcQOLBarBtn:SetFrameStrata("MEDIUM")
AkcQOLBarBtn:SetFrameLevel(20)
AkcQOLBarBtn:SetMovable(true)
AkcQOLBarBtn:SetClampedToScreen(true)
AkcQOLBarBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
AkcQOLBarBtn:RegisterForDrag("LeftButton")
if AkcQOLBarBtn.text then AkcQOLBarBtn.text:Hide() end
if AkcQOLBarBtn.Text then AkcQOLBarBtn.Text:Hide() end

local function PositionBarBtn()
    AkcQOLBarBtn:ClearAllPoints()
    local p = AkcQOLDB.global.actionBarBtnPos
    if p and p.x and p.y then
        AkcQOLBarBtn:SetPoint("CENTER", UIParent, "BOTTOMLEFT", p.x, p.y)
    else
        local anchor = _G.ActionButton1 or _G.MainMenuBar
        if anchor then
            AkcQOLBarBtn:SetPoint("RIGHT", anchor, "LEFT", -1, 0)
        else
            AkcQOLBarBtn:SetPoint("BOTTOM", UIParent, "BOTTOM", -280, 24)
        end
    end
end

AkcQOLBarBtn:SetScript("OnDragStart", function(self) self:StartMoving() end)
AkcQOLBarBtn:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local cx, cy = self:GetCenter()
    if cx and cy then
        AkcQOLDB.global.actionBarBtnPos = { x = cx, y = cy }
    end
    PositionBarBtn()
end)

local function UpdateBarBtnState()
    local on = _G.AkcQOL_IsActionBarMouseoverEnabled and _G.AkcQOL_IsActionBarMouseoverEnabled()
    AkcQOLBarBtn:SetChecked(on and true or false)
end

local function UpdateBarBtnAlpha(hovering)
    AkcQOLBarBtn:SetAlpha(hovering and 1 or 0)
end

AkcQOLBarBtn:SetScript("OnClick", function(self, button)
    if button == "LeftButton" then
        if _G.AkcQOL_ToggleActionBarMouseover then _G.AkcQOL_ToggleActionBarMouseover() end
        UpdateBarBtnState()
        UpdateBarBtnAlpha(self:IsMouseOver())
        if self:IsMouseOver() then self:GetScript("OnEnter")(self) end
    else
        UpdateBarBtnState()
        if AkcQOL_ShowLogsWindow then AkcQOL_ShowLogsWindow("settings") end
    end
end)

AkcQOLBarBtn:SetScript("OnEnter", function(self)
    UpdateBarBtnAlpha(true)
    local on = _G.AkcQOL_IsActionBarMouseoverEnabled and _G.AkcQOL_IsActionBarMouseoverEnabled()
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine(L["Action Bar Mouseover:"] .. " " .. (on and "|cFF59D97B" .. L["On"] .. "|r" or "|cFFF25850" .. L["Off"] .. "|r"), 1, 1, 1)
    GameTooltip:AddLine(L["Left-Click: Toggle Action Bar Mouseover"], 1, 1, 1)
    GameTooltip:AddLine(L["Right-Click: Settings"], 1, 1, 1)
    GameTooltip:AddLine(L["Drag: Move icon"], 0.7, 0.7, 0.7)
    GameTooltip:Show()
end)
AkcQOLBarBtn:SetScript("OnLeave", function()
    GameTooltip:Hide()
    UpdateBarBtnAlpha(false)
end)

function _G.AkcQOL_ApplyBarButton()
    PositionBarBtn()
    UpdateBarBtnState()
    UpdateBarBtnAlpha(AkcQOLBarBtn:IsMouseOver())
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showActionBarButton == true then
        AkcQOLBarBtn:Show()
    else
        AkcQOLBarBtn:Hide()
    end
end

AkcQOLBarBtn:Hide()
mmInitFrame:HookScript("OnEvent", function()
    _G.AkcQOL_ApplyBarButton()
end)

function AkcQOL_OnAddonCompartmentClick(_, button)
    if button == "LeftButton" then
        SlashCmdList["AKCQOL"]()
    else

        SlashCmdList["AKCQOL"]("settings")
    end
end
function AkcQOL_OnAddonCompartmentEnter(_, menuButtonFrame)
    GameTooltip:SetOwner(menuButtonFrame, "ANCHOR_LEFT")
    GameTooltip:AddLine("|cFFE5E7EBAkcQOL|r")
    GameTooltip:AddLine(L["Left-Click: Toggle Matrix (account overview)"], 1, 1, 1)
    GameTooltip:AddLine(L["Right-Click: Settings"], 1, 1, 1)
    GameTooltip:Show()
end
function AkcQOL_OnAddonCompartmentLeave()
    GameTooltip:Hide()
end

local AutoFrame = CreateFrame("Frame")
AutoFrame:RegisterEvent("MERCHANT_SHOW")
AutoFrame:SetScript("OnEvent", function()
    local doSell = true
    local doRepair = true

    if AkcQOLDB and AkcQOLDB.global then
        if AkcQOLDB.global.autoSell == false then doSell = false end
        if AkcQOLDB.global.autoRepair == false then doRepair = false end
    end

    if doSell then
        local junkItems = {}
        local totalEarned = 0
        local getItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local itemInfo = C_Container.GetContainerItemInfo(bag, slot)
                if itemInfo and itemInfo.quality == 0 and itemInfo.hyperlink and not itemInfo.hasNoValue then
                    local itemPrice = (getItemInfo and select(11, getItemInfo(itemInfo.hyperlink))) or 0
                    totalEarned = totalEarned + (itemPrice * itemInfo.stackCount)
                    table.insert(junkItems, { bag = bag, slot = slot, itemID = itemInfo.itemID })
                end
            end
        end
        if #junkItems > 0 then
            if C_MerchantFrame and C_MerchantFrame.SellAllJunkItems then
                C_MerchantFrame.SellAllJunkItems()
            else
                for i, item in ipairs(junkItems) do
                    C_Timer.After((i - 1) * 0.15, function()

                        if not (MerchantFrame and MerchantFrame:IsShown()) then return end
                        local info = C_Container.GetContainerItemInfo(item.bag, item.slot)
                        if info and info.quality == 0 and info.itemID == item.itemID then
                            C_Container.UseContainerItem(item.bag, item.slot)
                        end
                    end)
                end
            end
            if totalEarned > 0 then
                local g = math.floor(totalEarned / 10000)
                local s = math.floor((totalEarned % 10000) / 100)
                local c = totalEarned % 100
                print(string.format(L["|cff8c5cffAkc|r|cffffffffQOL|r: Vendor trash sold: %dg %ds %dc"], g, s, c))
            end
        end
    end

    if doRepair and CanMerchantRepair() then
        local cost, canRepair = GetRepairAllCost()
        if canRepair and cost > 0 then

            local withdraw = GetGuildBankWithdrawMoney()
            if IsInGuild() and CanGuildBankRepair() and (withdraw == -1 or withdraw >= cost) then
                RepairAllItems(true)
                print(L["|cff8c5cffAkc|r|cffffffffQOL|r: Items repaired using guild bank funds."])
            elseif GetMoney() >= cost then
                RepairAllItems(false)
                local rG = math.floor(cost / 10000)
                local rS = math.floor((cost % 10000) / 100)
                print(string.format(L["|cff8c5cffAkc|r|cffffffffQOL|r: Items repaired. Cost: %dg %ds"], rG, rS))
            end
        end
    end
end)

local FastLootFrame = CreateFrame("Frame")
FastLootFrame:SetScript("OnEvent", function(self)

    local now = GetTime and GetTime() or 0
    if now - (self.akcqolLastLoot or -1) < 0.3 then return end
    self.akcqolLastLoot = now
    local numItems = GetNumLootItems()
    if numItems > 0 then
        for i = numItems, 1, -1 do
            LootSlot(i)
        end
    end
end)

function _G.AkcQOL_ApplyFastLoot()
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.fastLoot then
        FastLootFrame:RegisterEvent("LOOT_READY")
    else
        FastLootFrame:UnregisterEvent("LOOT_READY")
    end
end

local KEYSTONE_RETRY_INTERVAL = 0.15
local KEYSTONE_RETRY_MAX = 8
local keystoneRetryToken = 0

local KeystoneFrame = CreateFrame("Frame")

local function AkcQOL_IsAutoKeystoneEnabled()
    return not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.autoInsertKeystone == false)
end

local function AkcQOL_FindKeystoneInBags()
    if not C_Container or not C_Container.GetContainerNumSlots or not C_Container.GetContainerItemInfo then
        return nil, nil
    end
    if not C_Item or not C_Item.IsItemKeystoneByID then
        return nil, nil
    end

    local bagStart = BACKPACK_CONTAINER or 0
    local bagEnd = NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4

    for bag = bagStart, bagEnd do
        local numSlots = C_Container.GetContainerNumSlots(bag) or 0
        for slot = 1, numSlots do
            local itemInfo = C_Container.GetContainerItemInfo(bag, slot)
            local itemID = itemInfo and itemInfo.itemID
            if itemID and C_Item.IsItemKeystoneByID(itemID) then
                if C_ChallengeMode and C_ChallengeMode.CanUseKeystoneInCurrentMap and ItemLocation and ItemLocation.CreateFromBagAndSlot then
                    local itemLocation = ItemLocation:CreateFromBagAndSlot(bag, slot)
                    if itemLocation and C_ChallengeMode.CanUseKeystoneInCurrentMap(itemLocation) then
                        return bag, slot
                    end
                else
                    return bag, slot
                end
            end
        end
    end

    return nil, nil
end

local function AkcQOL_TryAutoInsertKeystone()
    if not AkcQOL_IsAutoKeystoneEnabled() then return false end
    if C_MythicPlus and C_MythicPlus.GetOwnedKeystoneLevel and not C_MythicPlus.GetOwnedKeystoneLevel() then
        return false
    end
    if not C_ChallengeMode or not C_ChallengeMode.SlotKeystone or not C_ChallengeMode.HasSlottedKeystone then
        return false
    end
    if not C_Container or not C_Container.PickupContainerItem then
        return false
    end
    if C_ChallengeMode.HasSlottedKeystone() then
        return true
    end
    if CursorHasItem and CursorHasItem() then
        return false
    end

    local bag, slot = AkcQOL_FindKeystoneInBags()
    if not bag or not slot then
        return false
    end

    C_Container.PickupContainerItem(bag, slot)

    if CursorHasItem and CursorHasItem() then
        C_ChallengeMode.SlotKeystone()
        if C_ChallengeMode.HasSlottedKeystone() then
            return true
        end

        if C_Container and C_Container.PickupContainerItem then
            C_Container.PickupContainerItem(bag, slot)
        end
    end

    return false
end

local function AkcQOL_ScheduleAutoInsertKeystone()
    if not AkcQOL_IsAutoKeystoneEnabled() then return end

    keystoneRetryToken = keystoneRetryToken + 1
    local token = keystoneRetryToken

    local function Attempt(remaining)
        if token ~= keystoneRetryToken then return end
        if not AkcQOL_IsAutoKeystoneEnabled() then return end
        if C_ChallengeMode and C_ChallengeMode.HasSlottedKeystone and C_ChallengeMode.HasSlottedKeystone() then
            return
        end

        if AkcQOL_TryAutoInsertKeystone() then
            return
        end

        if remaining > 0 and C_Timer and C_Timer.After then
            C_Timer.After(KEYSTONE_RETRY_INTERVAL, function()
                Attempt(remaining - 1)
            end)
        end
    end

    Attempt(KEYSTONE_RETRY_MAX)
end

_G.AkcQOL_TryAutoInsertKeystone = AkcQOL_TryAutoInsertKeystone
_G.AkcQOL_ScheduleAutoInsertKeystone = AkcQOL_ScheduleAutoInsertKeystone

KeystoneFrame:RegisterEvent("CHALLENGE_MODE_KEYSTONE_RECEPTABLE_OPEN")
KeystoneFrame:RegisterEvent("CHALLENGE_MODE_KEYSTONE_SLOTTED")
KeystoneFrame:SetScript("OnEvent", function(_, event)
    if event == "CHALLENGE_MODE_KEYSTONE_RECEPTABLE_OPEN" then
        AkcQOL_ScheduleAutoInsertKeystone()
    elseif event == "CHALLENGE_MODE_KEYSTONE_SLOTTED" then
        keystoneRetryToken = keystoneRetryToken + 1
    end
end)

local CinematicFrame = CreateFrame("Frame")
CinematicFrame:RegisterEvent("CINEMATIC_START")
CinematicFrame:RegisterEvent("PLAY_MOVIE")
CinematicFrame:SetScript("OnEvent", function(self, event)
    local doSkip = true
    if AkcQOLDB and AkcQOLDB.global then
        if AkcQOLDB.global.autoCinematic == false then doSkip = false end
    end

    if doSkip then
        if event == "CINEMATIC_START" then
            if CanCancelScene and CanCancelScene() then
                CancelScene()
            end
            StopCinematic()
        elseif event == "PLAY_MOVIE" then
            if MovieFrame then
                if MovieFrame.StopMovie then
                    MovieFrame:StopMovie()
                elseif MovieFrame.Stop then
                    MovieFrame:Stop()
                end
            end
            if GameMovieFinished then GameMovieFinished() end
        end
    end
end)

local WV_FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local WV_FONT_FLAGS = ""

local function TRLower(s)
    if not s then return "" end
    s = s:gsub("\195\135", "\195\167")
    s = s:gsub("\196\158", "\196\159")
    s = s:gsub("\196\176", "i")
    s = s:gsub("\195\150", "\195\182")
    s = s:gsub("\197\158", "\197\159")
    s = s:gsub("\195\156", "\195\188")
    return s:lower()
end

local function WV_CreateBorder(parent, p1, r1, p2, r2, w, h)
    local Theme = AkcQOL_Theme
    local b = parent:CreateTexture(nil, "BORDER")
    b:SetTexture(WV_FLAT_TEX)

    b:SetVertexColor(Theme.rgba(Theme.colors.border))
    b:SetPoint(p1, parent, r1)
    b:SetPoint(p2, parent, r2)
    if w then b:SetWidth(w) end
    if h then b:SetHeight(h) end
    return b
end

local CHAT_LOG_CHANNELS = {
    { key = "guild",   label = "Guild",   event = "CHAT_MSG_GUILD",         color = {0.25, 1.0, 0.25} },
    { key = "party",   label = "Party",   event = "CHAT_MSG_PARTY",         color = {0.4, 0.6, 1.0} },
    { key = "raid",    label = "Raid",    event = "CHAT_MSG_RAID",          color = {1.0, 0.5, 0.0} },
    { key = "whisper", label = "Whisper", event = "CHAT_MSG_WHISPER",       color = {1.0, 0.5, 1.0} },
    { key = "say",     label = "Say",     event = "CHAT_MSG_SAY",           color = {1.0, 1.0, 1.0} },
    { key = "yell",    label = "Yell",    event = "CHAT_MSG_YELL",          color = {1.0, 0.25, 0.25} },

    { key = "instance",label = "Instance",event = "CHAT_MSG_INSTANCE_CHAT", color = {1.0, 0.6, 0.2} },
    { key = "bnet",    label = "Battle.net", event = "CHAT_MSG_BN_WHISPER", color = {0.35, 0.8, 1.0} },
}
local CHAT_LOG_ALL_CHANNEL = { key = "all", label = "All", color = {0.86, 0.88, 0.94} }
local CHAT_LOG_KEEP = 300

local AKCQOL_CHARACTER_LOG_TYPES = {
    mail = true,
    trade = true,
    loot = true,
}

AKCQOL_LOG_LIMITS = AKCQOL_LOG_LIMITS or {
    mail = 500,
    trade = 500,
    loot = 1000,
}
AKCQOL_LOG_BUCKET_SYNCED = AKCQOL_LOG_BUCKET_SYNCED or {}

function AkcQOL_GetLogLimit(logType)
    return AKCQOL_LOG_LIMITS[logType] or 200
end

local function AkcQOL_EarlyCleanString(value)
    if value == nil then return nil end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return nil end
    end
    local ok, text = pcall(tostring, value)
    if ok and text and text ~= "" then return text end
    return nil
end

local function AkcQOL_GetCharFromLogEntry(entry)
    local clean = AkcQOL_EarlyCleanString(entry)
    if not clean then return nil end
    local ok, charTag = pcall(string.match, clean, "^%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d%s+%[([^%]]+)%]")
    if ok then return charTag end
    return nil
end

local function AkcQOL_StoreLogEntryByChar(logType, entry, insertFirst)
    entry = AkcQOL_EarlyCleanString(entry)
    if not AKCQOL_CHARACTER_LOG_TYPES[logType] or not entry then return end
    if not AkcQOLDB or not AkcQOLDB.global then return end
    if not AkcQOLDB.global.logsByChar then AkcQOLDB.global.logsByChar = {} end
    if not AkcQOLDB.global.logsByChar[logType] then AkcQOLDB.global.logsByChar[logType] = {} end

    local charTag = AkcQOL_GetCharFromLogEntry(entry)
    if not charTag or charTag == "" then return end

    local byType = AkcQOLDB.global.logsByChar[logType]
    if not byType[charTag] then byType[charTag] = {} end
    local list = byType[charTag]

    for i = 1, #list do
        if list[i] == entry then return end
    end

    if insertFirst == false then
        list[#list + 1] = entry
    else
        table.insert(list, 1, entry)
    end
    local limit = AkcQOL_GetLogLimit(logType)
    while #list > limit do table.remove(list) end
end

function AkcQOL_SyncLogBuckets(logType)
    if not AKCQOL_CHARACTER_LOG_TYPES[logType] then return end
    if not AkcQOLDB or not AkcQOLDB.global or not AkcQOLDB.global.logs then return end
    local entries = AkcQOLDB.global.logs[logType]
    if type(entries) ~= "table" then return end
    for _, entry in ipairs(entries) do
        AkcQOL_StoreLogEntryByChar(logType, entry, false)
    end
end

local function EnsureLogDB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    if not AkcQOLDB.global.logs then AkcQOLDB.global.logs = {} end
    if not AkcQOLDB.global.logs.mail then AkcQOLDB.global.logs.mail = {} end
    if not AkcQOLDB.global.logs.trade then AkcQOLDB.global.logs.trade = {} end
    if not AkcQOLDB.global.logs.loot then AkcQOLDB.global.logs.loot = {} end
    if not AkcQOLDB.global.logsByChar then AkcQOLDB.global.logsByChar = {} end
    if not AkcQOLDB.global.logsByCharMigrated then AkcQOLDB.global.logsByCharMigrated = {} end
    for logType in pairs(AKCQOL_CHARACTER_LOG_TYPES) do
        if not AkcQOLDB.global.logsByChar[logType] then AkcQOLDB.global.logsByChar[logType] = {} end
        if not AkcQOLDB.global.logsByCharMigrated[logType] then
            for _, entry in ipairs(AkcQOLDB.global.logs[logType] or {}) do
                AkcQOL_StoreLogEntryByChar(logType, entry, false)
            end
            AkcQOLDB.global.logsByCharMigrated[logType] = true
        end
        if not AKCQOL_LOG_BUCKET_SYNCED[logType] then
            AkcQOL_SyncLogBuckets(logType)
            AKCQOL_LOG_BUCKET_SYNCED[logType] = true
        end
    end
    if not AkcQOLDB.global.logs.chat then AkcQOLDB.global.logs.chat = {} end
    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
        if not AkcQOLDB.global.logs.chat[ch.key] then AkcQOLDB.global.logs.chat[ch.key] = {} end
        local chList = AkcQOLDB.global.logs.chat[ch.key]
        while #chList > CHAT_LOG_KEEP do table.remove(chList) end
    end
end

local function AddLogEntry(logType, text)
    text = AkcQOL_EarlyCleanString(text)
    if not text then return end
    EnsureLogDB()
    local t = AkcQOLDB.global.logs[logType]
    local name, realm = UnitFullName("player")
    local charTag = (realm and realm ~= "") and (name .. "-" .. realm) or (name or "Unknown")
    local entry = date("%Y-%m-%d %H:%M:%S") .. " [" .. charTag .. "] - " .. text
    table.insert(t, 1, entry)
    AkcQOL_StoreLogEntryByChar(logType, entry, true)
    local limit = AkcQOL_GetLogLimit(logType)
    while #t > limit do table.remove(t) end
end

local function AkcQOL_GetChatChannelInfo(key)
    if key == "all" then return CHAT_LOG_ALL_CHANNEL end
    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
        if ch.key == key then return ch end
    end
    return CHAT_LOG_ALL_CHANNEL
end

local CHAT_EVENT_MAP = {}
for _, ch in ipairs(CHAT_LOG_CHANNELS) do
    CHAT_EVENT_MAP[ch.event] = ch.key
    CHAT_EVENT_MAP[ch.event .. "_LEADER"] = ch.key
end
CHAT_EVENT_MAP["CHAT_MSG_RAID_WARNING"] = "raid"
CHAT_EVENT_MAP["CHAT_MSG_WHISPER_INFORM"] = "whisper"
CHAT_EVENT_MAP["CHAT_MSG_BN_WHISPER"] = "bnet"
CHAT_EVENT_MAP["CHAT_MSG_BN_WHISPER_INFORM"] = "bnet"

local function CleanStr(val, fallback)
    if val == nil then return fallback or "?" end
    local function IsSecret(v)
        if type(issecretvalue) ~= "function" then return false end
        local okSecret, isSecret = pcall(issecretvalue, v)
        return okSecret and isSecret
    end
    if IsSecret(val) then return fallback end

    local ok1, result1 = pcall(function()
        local s = tostring(val)
        if IsSecret(s) then return nil end
        local len = string.len(s)
        if len == 0 then return fallback or "?" end
        local parts = {}
        for i = 1, len, 200 do
            local hi = i + 199
            if hi > len then hi = len end
            parts[#parts + 1] = string.char(string.byte(s, i, hi))
        end
        return table.concat(parts)
    end)
    if ok1 and result1 and result1 ~= "" and not IsSecret(result1) then return result1 end

    local ok2, result2 = pcall(string.format, "%s", val)
    if ok2 and result2 and not IsSecret(result2) then
        local ok3, clean = pcall(function()
            local len = string.len(result2)
            if len == 0 then return fallback or "?" end
            local parts = {}
            for i = 1, len, 200 do
                local hi = i + 199
                if hi > len then hi = len end
                parts[#parts + 1] = string.char(string.byte(result2, i, hi))
            end
            return table.concat(parts)
        end)
        if ok3 and clean and clean ~= "" and not IsSecret(clean) then return clean end
    end
    return fallback or "?"
end

function AkcQOL_IsProtectedChatPayloadText(text)
    local clean = CleanStr(text, nil)
    if not clean or clean == "" then return false end
    clean = clean:gsub("^%s+", ""):gsub("%s+$", "")
    return clean:match("^|K[^|]+|k$") ~= nil
end

function AkcQOL_GetProtectedChatMessage(channelKey)
    if channelKey == "officer" then
        return "[Officer message protected by Blizzard]"
    end
    return "[Chat message protected by Blizzard]"
end

function AkcQOL_ExtractChatLineMessage(lineText, author)
    local line = CleanStr(lineText, nil)
    if not line or line == "" or AkcQOL_IsProtectedChatPayloadText(line) then return nil end

    line = line:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    local safeAuthor = CleanStr(author, nil)
    if safeAuthor and safeAuthor ~= "" then
        local baseAuthor = safeAuthor:match("^([^-]+)") or safeAuthor
        if line:find(safeAuthor, 1, true) or line:find(baseAuthor, 1, true) then
            local msg = line:match(":%s*(.+)$")
            if msg and msg ~= "" and not AkcQOL_IsProtectedChatPayloadText(msg) then
                return msg
            end
        end
    end

    return nil
end

function AkcQOL_NormalizeChatBodyForStorage(channelKey, msg, author, lineID)
    local safeMsg = msg ~= nil and CleanStr(msg, nil) or nil
    if safeMsg and safeMsg ~= "" and not AkcQOL_IsProtectedChatPayloadText(safeMsg) then
        return safeMsg
    end

    local numericLineID = tonumber(lineID)
    if numericLineID and C_ChatInfo and C_ChatInfo.GetChatLineText then
        local ok, lineText = pcall(C_ChatInfo.GetChatLineText, numericLineID)
        if ok then
            local fromLine = AkcQOL_ExtractChatLineMessage(lineText, author)
            if fromLine and fromLine ~= "" then return fromLine end
        end
    end

    if safeMsg and AkcQOL_IsProtectedChatPayloadText(safeMsg) then
        return AkcQOL_GetProtectedChatMessage(channelKey)
    end

    return safeMsg
end

function AkcQOL_NormalizeStoredChatBody(channelKey, body)
    local clean = AkcQOL_UntaintLog and AkcQOL_UntaintLog(body) or CleanStr(body, "")
    if AkcQOL_IsProtectedChatPayloadText(clean) then
        return AkcQOL_GetProtectedChatMessage(channelKey)
    end
    return clean or ""
end

local function GetChatChannelKey(event)
    local safeEvent = CleanStr(event, nil)
    if not safeEvent then return nil, nil end

    if safeEvent == "CHAT_MSG_GUILD" then return "guild", safeEvent end
    if safeEvent == "CHAT_MSG_PARTY" or safeEvent == "CHAT_MSG_PARTY_LEADER" then return "party", safeEvent end
    if safeEvent == "CHAT_MSG_RAID" or safeEvent == "CHAT_MSG_RAID_LEADER" or safeEvent == "CHAT_MSG_RAID_WARNING" then return "raid", safeEvent end
    if safeEvent == "CHAT_MSG_WHISPER" or safeEvent == "CHAT_MSG_WHISPER_INFORM" then return "whisper", safeEvent end
    if safeEvent == "CHAT_MSG_BN_WHISPER" or safeEvent == "CHAT_MSG_BN_WHISPER_INFORM" then return "bnet", safeEvent end
    if safeEvent == "CHAT_MSG_SAY" then return "say", safeEvent end
    if safeEvent == "CHAT_MSG_YELL" then return "yell", safeEvent end
    if safeEvent == "CHAT_MSG_OFFICER" then return "officer", safeEvent end
    if safeEvent == "CHAT_MSG_INSTANCE_CHAT" or safeEvent == "CHAT_MSG_INSTANCE_CHAT_LEADER" then return "instance", safeEvent end

    return nil, safeEvent
end

local function RecordChatEvent(event, msg, author, targetName, lineID)
    local channelKey, safeEvent = GetChatChannelKey(event)
    if not channelKey then return end

    local safeAuthor = CleanStr(author, "?")
    local safeTarget = CleanStr(targetName, nil)
    local safeMsg = AkcQOL_NormalizeChatBodyForStorage(channelKey, msg, author, lineID)
    if not safeMsg or safeMsg == "" then return end

    if safeEvent == "CHAT_MSG_WHISPER_INFORM" or safeEvent == "CHAT_MSG_BN_WHISPER_INFORM" then
        if not safeTarget or safeTarget == "" or safeTarget == "?" then
            safeTarget = safeAuthor
        end
        safeAuthor = "To " .. safeTarget
    end

    EnsureLogDB()
    local t = AkcQOLDB.global.logs.chat[channelKey]
    if not t then return end
    local entry = date("%Y-%m-%d %H:%M:%S") .. " [" .. safeAuthor .. "] " .. safeMsg
    table.insert(t, 1, entry)
    while #t > CHAT_LOG_KEEP do table.remove(t) end
end

local ChatLogEventFrame = CreateFrame("Frame")
local ALL_CHAT_EVENTS = {
    "CHAT_MSG_GUILD", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_SAY", "CHAT_MSG_YELL",
    "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER",
    "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM",
}
for _, ev in ipairs(ALL_CHAT_EVENTS) do
    ChatLogEventFrame:RegisterEvent(ev)
end
ChatLogEventFrame:SetScript("OnEvent", function(self, event, msg, author, languageName, channelName, targetName, ...)

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logChat == false then return end
    local lineID = select(6, ...)
    local ok, err = pcall(RecordChatEvent, event, msg, author, targetName, lineID)
    if not ok then
        if _G.AkcQOL_RecordLuaError then
            pcall(_G.AkcQOL_RecordLuaError, "Chat Log Error", CleanStr(err, "ChatLog failed on a secret chat value."), "", "AkcQOL")
        end
    end
end)

local AKCQOL_LOG_NAV = {
    { key = "matrix", label = L["Matrix"], icon = "Interface\\Icons\\INV_Misc_Map_01",        color = {0.96, 0.62, 0.04} },
    { key = "mail",  label = L["Mail"],  icon = "Interface\\Icons\\INV_Letter_15",           color = {0.35, 0.68, 1.00} },
    { key = "trade", label = L["Trade"], icon = "Interface\\Icons\\INV_Misc_Coin_01",        color = {1.00, 0.82, 0.18} },
    { key = "loot",  label = L["Loot"],  icon = "Interface\\Icons\\INV_Box_01",              color = {0.38, 1.00, 0.42} },
    { key = "chat",  label = L["Chat"],  icon = "Interface\\Icons\\INV_Misc_Note_06",        color = {1.00, 0.54, 1.00} },
    { key = "lua",   label = L["Lua"],   icon = "Interface\\Icons\\INV_Misc_Bomb_01",        color = {1.00, 0.38, 0.30} },
}

local AKCQOL_LOG_TITLES = {
    matrix = L["Matrix"],
    mail = L["Mail Log"],
    trade = L["Trade Log"],
    loot = L["Loot Log"],
    chat = L["Chat Log"],
    lua = L["Lua Errors"],
    settings = L["Settings"],
}

local AKCQOL_LOG_EXPORT_FRAME
local AkcQOL_ShowLogsWindow
local AkcQOL_ShowLogExport

local function AkcQOL_ColorHex(color)
    local r = math.floor((color[1] or 1) * 255 + 0.5)
    local g = math.floor((color[2] or 1) * 255 + 0.5)
    local b = math.floor((color[3] or 1) * 255 + 0.5)
    return string.format("%02x%02x%02x", r, g, b)
end

local function AkcQOL_ColorText(color, text)
    return "|cFF" .. AkcQOL_ColorHex(color) .. tostring(text or "") .. "|r"
end

local function AkcQOL_GetLogColor(key)
    for _, item in ipairs(AKCQOL_LOG_NAV) do
        if item.key == key then return item.color end
    end
    return {0.96, 0.62, 0.04}
end

local function AkcQOL_GetPlayerTag()
    local name, realm = UnitFullName("player")
    if name and realm and realm ~= "" then return name .. "-" .. realm end
    return name or "Unknown"
end

local function AkcQOL_UntaintLog(v)
    if v == nil then return nil end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, v)
        if okSecret and isSecret then return nil end
    end

    local ok, clean = pcall(function()
        local text = tostring(v)
        return string.format("%s", text)
    end)
    if ok and clean and clean ~= "" then return clean end
    return nil
end

local function AkcQOL_Utf8CharSize(text, index)
    local b1 = text and text:byte(index)
    if not b1 then return 0 end
    if b1 < 0x80 then return 1 end

    local function IsCont(offset)
        local b = text:byte(index + offset)
        return b and b >= 0x80 and b <= 0xBF
    end

    if b1 >= 0xC2 and b1 <= 0xDF and IsCont(1) then return 2 end
    if b1 >= 0xE0 and b1 <= 0xEF and IsCont(1) and IsCont(2) then return 3 end
    if b1 >= 0xF0 and b1 <= 0xF4 and IsCont(1) and IsCont(2) and IsCont(3) then return 4 end
    return 1
end

local function AkcQOL_TruncateUtf8(text, maxChars)
    local clean = AkcQOL_UntaintLog(text) or ""
    local len = clean:len()
    local index, chars = 1, 0

    while index <= len do
        if chars >= maxChars then
            return clean:sub(1, index - 1) .. "..."
        end
        local size = AkcQOL_Utf8CharSize(clean, index)
        if size <= 0 then break end
        index = index + size
        chars = chars + 1
    end

    return clean
end

local function AkcQOL_CallFrameMethod(frame, method, ...)
    local fn = frame and frame[method]
    if fn then pcall(fn, frame, ...) end
end

local function AkcQOL_DisableMouseTree(frame)
    if not frame or frame.akcqolMouseRestore then return end
    frame.akcqolMouseRestore = {}

    local function SaveAndDisable(child)
        if not child then return end

        local entry = { frame = child }
        local shouldRestore = false

        if child.IsMouseEnabled then
            local ok, enabled = pcall(child.IsMouseEnabled, child)
            if ok then
                entry.mouse = enabled
                shouldRestore = shouldRestore or enabled
            end
        elseif child.EnableMouse then
            entry.mouse = true
            shouldRestore = true
        end

        if child.IsMouseClickEnabled then
            local ok, enabled = pcall(child.IsMouseClickEnabled, child)
            if ok then
                entry.click = enabled
                shouldRestore = shouldRestore or enabled
            end
        end

        if child.IsMouseMotionEnabled then
            local ok, enabled = pcall(child.IsMouseMotionEnabled, child)
            if ok then
                entry.motion = enabled
                shouldRestore = shouldRestore or enabled
            end
        end

        if child.IsMouseWheelEnabled then
            local ok, enabled = pcall(child.IsMouseWheelEnabled, child)
            if ok then
                entry.wheel = enabled
                shouldRestore = shouldRestore or enabled
            end
        elseif child.EnableMouseWheel then
            entry.wheel = true
            shouldRestore = true
        end

        if shouldRestore then
            frame.akcqolMouseRestore[#frame.akcqolMouseRestore + 1] = entry
        end

        AkcQOL_CallFrameMethod(child, "SetMouseClickEnabled", false)
        AkcQOL_CallFrameMethod(child, "SetMouseMotionEnabled", false)
        AkcQOL_CallFrameMethod(child, "EnableMouseWheel", false)
        AkcQOL_CallFrameMethod(child, "EnableMouse", false)
    end

    local function Walk(parent)
        if not parent or not parent.GetChildren then return end
        local ok, children = pcall(function() return { parent:GetChildren() } end)
        if not ok or type(children) ~= "table" then return end
        for _, child in ipairs(children) do
            SaveAndDisable(child)
            Walk(child)
        end
    end

    SaveAndDisable(frame)
    Walk(frame)
end

local function AkcQOL_RestoreMouseTree(frame)
    local restore = frame and frame.akcqolMouseRestore
    if type(restore) ~= "table" then return end
    for _, entry in ipairs(restore) do
        local child = entry
        local mouse, click, motion, wheel = true, nil, nil, nil
        if type(entry) == "table" and entry.frame then
            child = entry.frame
            mouse = entry.mouse
            click = entry.click
            motion = entry.motion
            wheel = entry.wheel
        end
        if mouse ~= nil then AkcQOL_CallFrameMethod(child, "EnableMouse", mouse) end
        if wheel ~= nil then AkcQOL_CallFrameMethod(child, "EnableMouseWheel", wheel) end
        if click ~= nil then AkcQOL_CallFrameMethod(child, "SetMouseClickEnabled", click) end
        if motion ~= nil then AkcQOL_CallFrameMethod(child, "SetMouseMotionEnabled", motion) end
    end
    frame.akcqolMouseRestore = nil
end

local function AkcQOL_ParkFrameOffscreen(frame)
    if not frame or frame.akcqolSoftHiddenParked then return end
    frame.akcqolSoftHiddenParked = true
    frame.akcqolRestorePoints = {}

    if frame.GetNumPoints and frame.GetPoint then
        local okCount, count = pcall(frame.GetNumPoints, frame)
        if okCount and count and count > 0 then
            for i = 1, count do
                local okPoint, point, relativeTo, relativePoint, xOfs, yOfs = pcall(frame.GetPoint, frame, i)
                if okPoint and point then
                    frame.akcqolRestorePoints[#frame.akcqolRestorePoints + 1] = {
                        point = point,
                        relativeTo = relativeTo,
                        relativePoint = relativePoint,
                        xOfs = xOfs,
                        yOfs = yOfs,
                    }
                end
            end
        end
    end

    if frame.IsClampedToScreen then
        local okClamp, clamped = pcall(frame.IsClampedToScreen, frame)
        if okClamp then frame.akcqolRestoreClamped = clamped end
    end

    AkcQOL_CallFrameMethod(frame, "SetClampedToScreen", false)
    AkcQOL_CallFrameMethod(frame, "ClearAllPoints")
    AkcQOL_CallFrameMethod(frame, "SetPoint", "TOPLEFT", UIParent, "BOTTOMRIGHT", 4096, 4096)
end

local function AkcQOL_RestoreFramePosition(frame)
    if not frame or not frame.akcqolSoftHiddenParked then return end

    AkcQOL_CallFrameMethod(frame, "ClearAllPoints")
    local restored = false
    local points = frame.akcqolRestorePoints
    if type(points) == "table" then
        for _, p in ipairs(points) do
            if p and p.point then
                local ok = pcall(frame.SetPoint, frame, p.point, p.relativeTo, p.relativePoint, p.xOfs or 0, p.yOfs or 0)
                restored = restored or ok
            end
        end
    end
    if not restored then
        AkcQOL_CallFrameMethod(frame, "SetPoint", "CENTER", UIParent, "CENTER", 0, 0)
    end

    if frame.akcqolRestoreClamped ~= nil then
        AkcQOL_CallFrameMethod(frame, "SetClampedToScreen", frame.akcqolRestoreClamped)
    end

    frame.akcqolRestorePoints = nil
    frame.akcqolRestoreClamped = nil
    frame.akcqolSoftHiddenParked = nil
end

local function AkcQOL_SafeHideFrame(frame)
    if not frame then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then

        frame.akcqolSoftHidden = true
        AkcQOL_CallFrameMethod(frame, "SetAlpha", 0)
        AkcQOL_DisableMouseTree(frame)
        AkcQOL_ParkFrameOffscreen(frame)
        AkcQOL_CallFrameMethod(frame, "Hide")
        return
    end
    AkcQOL_RestoreMouseTree(frame)
    AkcQOL_RestoreFramePosition(frame)
    frame.akcqolSoftHidden = false
    AkcQOL_CallFrameMethod(frame, "SetAlpha", 1)
    AkcQOL_CallFrameMethod(frame, "EnableMouse", true)
    AkcQOL_CallFrameMethod(frame, "Hide")
end

local function AkcQOL_SafeShowFrame(frame)
    if not frame then return end
    frame.akcqolSoftHidden = false
    AkcQOL_RestoreMouseTree(frame)
    AkcQOL_RestoreFramePosition(frame)
    AkcQOL_CallFrameMethod(frame, "SetAlpha", 1)
    AkcQOL_CallFrameMethod(frame, "EnableMouse", true)
    AkcQOL_CallFrameMethod(frame, "Show")
end

local function AkcQOL_IsFrameOpen(frame)
    return frame and frame.IsShown and frame:IsShown() and not frame.akcqolSoftHidden
end

function AkcQOL_ScrollFrameToBottom(scrollFrame)
    if not scrollFrame or not scrollFrame.SetVerticalScroll then return end

    local function Apply()
        if not scrollFrame or not scrollFrame.SetVerticalScroll then return end
        if scrollFrame.UpdateScrollChildRect then
            pcall(scrollFrame.UpdateScrollChildRect, scrollFrame)
        end
        local range = 0
        if scrollFrame.GetVerticalScrollRange then
            range = scrollFrame:GetVerticalScrollRange() or 0
        end
        scrollFrame:SetVerticalScroll(range)
    end

    Apply()
    if C_Timer and C_Timer.After then
        C_Timer.After(0, Apply)
        C_Timer.After(0.05, Apply)
    end
end

local function AkcQOL_ParseLogEntry(raw)
    local clean = AkcQOL_UntaintLog(raw) or ""
    local dt, char, text = clean:match("^(%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d)%s+%[([^%]]+)%]%s+%-%s+(.*)$")
    if dt then return dt, char, text end

    dt, text = clean:match("^(%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d)%s+(.+)$")
    if dt then return dt, "", text end

    return "", "", clean
end

local function AkcQOL_ParseChatLogEntry(raw)
    local clean = AkcQOL_UntaintLog(raw) or ""
    local dt, author, body = clean:match("^(%d%d%d%d%-%d%d%-%d%d %d%d:%d%d:%d%d)%s+%[([^%]]+)%]%s*(.*)$")
    return dt or "", author or "", body or clean, clean
end

local function AkcQOL_NormalizeChatPerson(author)
    local clean = AkcQOL_UntaintLog(author) or ""
    clean = clean:gsub("^%s+", ""):gsub("%s+$", "")
    clean = clean:gsub("^To:%s*", ""):gsub("^To%s+", "")
    clean = clean:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    return clean ~= "" and clean or "Unknown"
end

local function AkcQOL_GetChatNameKeys(name)
    local clean = AkcQOL_NormalizeChatPerson(name)
    local full = TRLower(clean):gsub("%s+", "")
    local base = full:match("^([^-]+)") or full
    local hasRealm = clean:find("-", 1, true) and true or false
    return full, base, hasRealm
end

local function AkcQOL_IsOwnChatPerson(name)
    local full, base, hasRealm = AkcQOL_GetChatNameKeys(name)
    if full == "" or full == "unknown" then return false end

    local playerFull, playerBase = AkcQOL_GetChatNameKeys(AkcQOL_GetPlayerTag())
    if full == playerFull or (not hasRealm and base == playerBase) then
        return true
    end

    if type(AkcQOLDB) == "table" then
        for char, data in pairs(AkcQOLDB) do
            if type(char) == "string" and type(data) == "table" and char ~= "global" and char ~= "hiddenChars" then
                local charFull, charBase = AkcQOL_GetChatNameKeys(char)
                if full == charFull or (not hasRealm and base == charBase) then
                    return true
                end
            end
        end
    end

    return false
end

local function AkcQOL_GetChatConversationPerson(channelKey, author)
    local person = AkcQOL_NormalizeChatPerson(author)
    if not person or person == "" or person == "Unknown" then return nil end

    if channelKey == "whisper" and AkcQOL_IsOwnChatPerson(person) then return nil end
    return person
end

local function AkcQOL_IsLegacyBattleNetWhisperAuthor(author)
    local person = AkcQOL_NormalizeChatPerson(author)
    if not person or person == "" or person == "Unknown" then return false end
    if AkcQOL_IsOwnChatPerson(person) then return false end

    if person:find("-", 1, true) then return false end
    return true
end

local function AkcQOL_MigrateLegacyBattleNetWhispers()
    EnsureLogDB()
    local chatDB = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logs and AkcQOLDB.global.logs.chat
    if not chatDB or AkcQOLDB.global.chatBattleNetMigrated == 1 then return end

    local whisper = chatDB.whisper or {}
    local bnet = chatDB.bnet or {}
    local kept, moved = {}, {}

    for i = 1, #whisper do
        local _, author = AkcQOL_ParseChatLogEntry(whisper[i])
        if AkcQOL_IsLegacyBattleNetWhisperAuthor(author) then
            moved[#moved + 1] = whisper[i]
        else
            kept[#kept + 1] = whisper[i]
        end
    end

    if #moved > 0 then
        chatDB.whisper = kept
        for i = 1, #moved do
            bnet[#bnet + 1] = moved[i]
        end
        chatDB.bnet = bnet
    end

    AkcQOLDB.global.chatBattleNetMigrated = 1
end

local function AkcQOL_EnableLogHyperlinks(fontString, ownerFrame)
    if fontString and fontString.SetHyperlinksEnabled then
        pcall(fontString.SetHyperlinksEnabled, fontString, true)
    end
end

local AkcQOLLogMeasureFrame = CreateFrame("Frame")
AkcQOLLogMeasureFrame:Hide()
local AkcQOLLogMeasureText = AkcQOLLogMeasureFrame:CreateFontString(nil, "OVERLAY")

AkcQOL_Theme.SetFont(AkcQOLLogMeasureText, 12, "")

local function AkcQOL_StripLogDisplayMarkup(text)
    local clean = AkcQOL_UntaintLog(text) or ""
    clean = clean:gsub("|c%x%x%x%x%x%x%x%x", "")
    clean = clean:gsub("|r", "")
    clean = clean:gsub("|H[^|]+|h(.-)|h", "%1")
    clean = clean:gsub("|T[^|]+|t", "")
    return clean
end

local function AkcQOL_IsTooltipLink(link)
    if type(link) ~= "string" then return false end
    return link:match("^item:")
        or link:match("^battlepet:")
        or link:match("^currency:")
        or link:match("^enchant:")
end

local function AkcQOL_MeasureLogText(text)
    AkcQOLLogMeasureText:SetText(text or "")
    return AkcQOLLogMeasureText:GetStringWidth() or 0
end

local function AkcQOL_ForEachTooltipLink(text, callback)
    local clean = AkcQOL_UntaintLog(text)
    if not clean or clean == "" then return end

    local pos = 1
    while true do
        local startPos, endPos, link, label = clean:find("|H([^|]+)|h(.-)|h", pos)
        if not startPos then break end
        if AkcQOL_IsTooltipLink(link) then
            callback(clean, startPos, endPos, link, label or "")
        end
        pos = endPos + 1
    end
end

local function AkcQOL_CollectLogLinkHotspots(rawText, bodyText)
    local hotspots = {}
    local body = AkcQOL_UntaintLog(bodyText) or ""

    AkcQOL_ForEachTooltipLink(body, function(source, startPos, endPos, link, label)
        local labelText = AkcQOL_StripLogDisplayMarkup(label)
        if labelText ~= "" then
            local prefixText = AkcQOL_StripLogDisplayMarkup(source:sub(1, startPos - 1))
            hotspots[#hotspots + 1] = {
                link = link,
                x = AkcQOL_MeasureLogText(prefixText),
                width = math.max(14, AkcQOL_MeasureLogText(labelText)),
            }
        end
    end)

    if #hotspots > 0 then return hotspots end

    local plainBody = AkcQOL_StripLogDisplayMarkup(body)
    local searchFrom = 1
    AkcQOL_ForEachTooltipLink(rawText, function(source, startPos, endPos, link, label)
        local labelText = AkcQOL_StripLogDisplayMarkup(label)
        if labelText ~= "" and plainBody ~= "" then
            local foundStart, foundEnd = plainBody:find(labelText, searchFrom, true)
            if not foundStart then
                foundStart, foundEnd = plainBody:find(labelText, 1, true)
            end
            if foundStart then
                local prefixText = plainBody:sub(1, foundStart - 1)
                hotspots[#hotspots + 1] = {
                    link = link,
                    x = AkcQOL_MeasureLogText(prefixText),
                    width = math.max(14, AkcQOL_MeasureLogText(labelText)),
                }
                searchFrom = (foundEnd or foundStart) + 1
            end
        end
    end)

    return hotspots
end

local function AkcQOL_GetLogLinkButton(row, index)
    row.linkButtons = row.linkButtons or {}
    local btn = row.linkButtons[index]
    if btn then return btn end

    btn = CreateFrame("Button", nil, row)
    btn:SetFrameLevel(row:GetFrameLevel() + 6)
    btn:EnableMouse(true)
    btn:SetScript("OnEnter", function(self)
        if not self.tooltipLink then return end
        GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
        local ok = pcall(GameTooltip.SetHyperlink, GameTooltip, self.tooltipLink)
        if not ok or GameTooltip:NumLines() == 0 then
            GameTooltip:ClearLines()
            GameTooltip:AddLine(self.tooltipLink, 1, 1, 1)
        end
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    btn:SetScript("OnClick", function(self)
        local owner = self.ownerRow
        local raw = owner and AkcQOL_UntaintLog(owner.rawText)
        if raw and raw ~= "" then
            AkcQOL_ShowLogExport(owner.rawTitle or "Log Entry", raw)
        end
    end)

    row.linkButtons[index] = btn
    return btn
end

local function AkcQOL_UpdateLogLinkHotspots(row, bodyText)
    if not row then return end

    if row.linkButtons then
        for _, btn in ipairs(row.linkButtons) do
            btn:Hide()
        end
    end

    local anchor = row.linkHost or row.body
    if not anchor or not row.rawText then return end

    local hotspots = AkcQOL_CollectLogLinkHotspots(row.rawText, bodyText or anchor:GetText())
    for i, spot in ipairs(hotspots) do
        local btn = AkcQOL_GetLogLinkButton(row, i)
        btn.ownerRow = row
        btn.tooltipLink = spot.link
        btn:ClearAllPoints()
        btn:SetPoint("LEFT", anchor, "LEFT", (spot.x or 0) - 2, 0)
        btn:SetSize(math.max(16, (spot.width or 14) + 4), math.max(20, row:GetHeight() or 30))
        btn:Show()
    end
end

local function AkcQOL_CreateGlassButton(parent, text, width, height, color)
    local Theme = AkcQOL_Theme
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width, height)

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetTexture(WV_FLAT_TEX)
    border:SetVertexColor(color[1], color[2], color[3], 0.55)

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(WV_FLAT_TEX)
    bg:SetVertexColor(Theme.rgba(Theme.colors.panelBg))

    local hi = btn:CreateTexture(nil, "ARTWORK")
    hi:SetPoint("TOPLEFT", 1, -1)
    hi:SetPoint("TOPRIGHT", -1, -1)
    hi:SetHeight(1)
    hi:SetTexture(WV_FLAT_TEX)
    hi:SetVertexColor(1, 1, 1, 0.08)

    local label = btn:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(label, 11, WV_FONT_FLAGS)
    label:SetAllPoints()
    label:SetText(text)

    btn.bg = bg
    btn.border = border
    btn.label = label
    btn:SetScript("OnEnter", function()
        bg:SetVertexColor(Theme.rgba(Theme.colors.rowHover))
        border:SetVertexColor(color[1], color[2], color[3], 0.95)
    end)
    btn:SetScript("OnLeave", function()
        bg:SetVertexColor(Theme.rgba(Theme.colors.panelBg))
        border:SetVertexColor(color[1], color[2], color[3], 0.55)
    end)
    return btn
end

local function AkcQOL_CreateLogCheckbox(parent, label, width, checked, onChanged)
    local Theme = AkcQOL_Theme
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width or 140, 24)
    btn.checked = checked and true or false

    local box = btn:CreateTexture(nil, "BACKGROUND")
    box:SetPoint("LEFT", 0, 0)
    box:SetSize(16, 16)
    box:SetTexture(WV_FLAT_TEX)
    box:SetVertexColor(Theme.rgba(Theme.colors.insetBg))

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", box, "TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", box, "BOTTOMRIGHT", 1, -1)
    border:SetTexture(WV_FLAT_TEX)
    border:SetVertexColor(Theme.rgba(Theme.colors.border))

    local check = btn:CreateTexture(nil, "OVERLAY")
    check:SetPoint("CENTER", box, "CENTER", 0, 0)
    check:SetSize(18, 18)
    check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    check:SetVertexColor(Theme.rgba(Theme.colors.accent))
    check:Hide()

    local text = btn:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(text, 11, WV_FONT_FLAGS)
    text:SetPoint("LEFT", box, "RIGHT", 8, 0)
    text:SetText("|cFFE5E7EB" .. label .. "|r")

    function btn:SetChecked(value)
        self.checked = value and true or false
        if self.checked then
            check:Show()
            border:SetVertexColor(Theme.rgba(Theme.colors.borderLight))
        else
            check:Hide()
            border:SetVertexColor(Theme.rgba(Theme.colors.border))
        end
    end
    function btn:GetChecked()
        return self.checked
    end
    btn:SetScript("OnClick", function(self)
        self:SetChecked(not self:GetChecked())
        if onChanged then onChanged(self) end
    end)
    btn:SetChecked(btn.checked)
    return btn
end

AkcQOL_ShowLogExport = function(title, text)
    local Theme = AkcQOL_Theme
    if not AKCQOL_LOG_EXPORT_FRAME then
        local f = CreateFrame("Frame", "AkcQOLLogExportFrame", UIParent, "BackdropTemplate")
        f:SetSize(720, 520)
        f:SetPoint("CENTER")
        f:SetFrameStrata("FULLSCREEN_DIALOG")
        f:EnableMouse(true)
        f:SetMovable(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", function(self) self:StartMoving() end)
        f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        Theme.ApplyWindow(f)

        local titleText = f:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(titleText, 14, WV_FONT_FLAGS, true)
        titleText:SetPoint("TOP", 0, -14)
        f.titleText = titleText

        local close = AkcQOL_CreateGlassButton(f, "|cFFFF4D4DX|r", 24, 22, {1, 0.25, 0.2})
        close:SetPoint("TOPRIGHT", -10, -10)
        close:SetScript("OnClick", function() AkcQOL_SafeHideFrame(f) end)

        local selectAll = AkcQOL_CreateGlassButton(f, "|cFFE5E7EB" .. L["Select All"] .. "|r", 88, 22, Theme.colors.accent)
        selectAll:SetPoint("TOPRIGHT", close, "TOPLEFT", -8, 0)

        local editInset = CreateFrame("Frame", nil, f, "BackdropTemplate")
        editInset:SetPoint("TOPLEFT", 10, -42)
        editInset:SetPoint("BOTTOMRIGHT", -8, 10)
        Theme.ApplyBackdrop(editInset, "inset")

        local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 12, -44)
        scroll:SetPoint("BOTTOMRIGHT", -30, 12)

        local edit = CreateFrame("EditBox", nil, scroll)
        edit:SetMultiLine(true)
        edit:SetAutoFocus(false)
        Theme.SetFont(edit, 12, "")
        edit:SetTextColor(0.92, 0.94, 0.98, 1)
        edit:SetJustifyH("LEFT")
        edit:SetJustifyV("TOP")
        edit:SetWidth(660)
        edit:SetHeight(2200)
        edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        scroll:SetScrollChild(edit)
        f.edit = edit
        f.scroll = scroll

        selectAll:SetScript("OnClick", function()
            edit:SetFocus()
            edit:HighlightText()
        end)

        AKCQOL_LOG_EXPORT_FRAME = f
    end

    AKCQOL_LOG_EXPORT_FRAME.titleText:SetText(Theme.Accent("AkcQOL") .. " |cFFE5E7EB" .. tostring(title or "Export") .. "|r")
    AKCQOL_LOG_EXPORT_FRAME.edit:SetText(text or "")
    AKCQOL_LOG_EXPORT_FRAME.edit:SetCursorPosition(0)
    AKCQOL_LOG_EXPORT_FRAME.edit:HighlightText()
    AKCQOL_LOG_EXPORT_FRAME.edit:SetFocus()
    AkcQOL_SafeShowFrame(AKCQOL_LOG_EXPORT_FRAME)
end


local AKCQOL_LOGS_FRAME

local function AkcQOL_MarkLuaErrorsSeenFromLogs()
    if AkcQOLDB and AkcQOLDB.global and type(AkcQOLDB.global.luaErrors) == "table" then
        local db = AkcQOLDB.global.luaErrors
        db.unreadCount = 0
        if type(db.entries) == "table" then
            for _, entry in ipairs(db.entries) do
                if type(entry) == "table" then entry.unread = false end
            end
        end
    end
    if _G.AkcQOL_RefreshErrorLogButton then
        pcall(_G.AkcQOL_RefreshErrorLogButton)
    end
end

local function AkcQOL_BuildLuaErrorExport(entry)
    if type(entry) ~= "table" then return "" end
    local lines = {}
    local function Add(line) lines[#lines + 1] = line or "" end
    Add("AkcQOL Lua Error Log")
    Add("")
    Add("ID: " .. tostring(entry.id or "-"))
    Add("Type: " .. tostring(entry.kind or "Lua Error"))
    Add("AddOn: " .. tostring(entry.addon or "Unknown"))
    Add("Player: " .. tostring(entry.player or "Unknown"))
    Add("First Seen: " .. tostring(entry.firstSeenText or "Unknown"))
    Add("Last Seen: " .. tostring(entry.lastSeenText or entry.firstSeenText or "Unknown"))
    Add("Count: " .. tostring(entry.count or 1))
    Add("")
    Add("Message:")
    Add(tostring(entry.message or ""))
    if entry.stack and entry.stack ~= "" then
        Add("")
        Add("Stack:")
        Add(tostring(entry.stack))
    end
    return table.concat(lines, "\n")
end

AkcQOL_ShowLogsWindow = function(initialTab)
    local Theme = AkcQOL_Theme
    EnsureLogDB()
    initialTab = initialTab or "matrix"
    if _G.AkcQOL_CloseMatrixPopups then
        pcall(_G.AkcQOL_CloseMatrixPopups, "logs")
    end
    if initialTab ~= "matrix" and _G.WVTrackerFrame then
        AkcQOL_SafeHideFrame(_G.WVTrackerFrame)
    end

    if not AKCQOL_LOGS_FRAME then
        local f = CreateFrame("Frame", "AkcQOLLogsFrame", UIParent, "BackdropTemplate")
        f:SetSize(1280, 720)
        f:SetPoint("CENTER")
        f:SetFrameStrata("DIALOG")
        f:SetFrameLevel(680)
        f:SetMovable(true)
        f:EnableMouse(true)
        f:SetClampedToScreen(true)
        f:RegisterForDrag("LeftButton")
        f:SetScript("OnDragStart", function(self) self:StartMoving() end)
        f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
        f:SetResizable(true)
        if f.SetResizeBounds then
            f:SetResizeBounds(900, 520, 1700, 980)
        else
            f:SetMinResize(900, 520)
            f:SetMaxResize(1700, 980)
        end

        Theme.ApplyWindow(f)
        if not AkcQOLDB.global.mainWindowScale then AkcQOLDB.global.mainWindowScale = 1.0 end
        f:SetScale(AkcQOLDB.global.mainWindowScale)
        tinsert(UISpecialFrames, "AkcQOLLogsFrame")

        local titleBar = CreateFrame("Frame", nil, f)
        titleBar:SetPoint("TOPLEFT", f, "TOPLEFT", 66, 0)
        titleBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
        titleBar:SetHeight(46)
        titleBar:EnableMouse(true)
        titleBar:RegisterForDrag("LeftButton")
        titleBar:SetScript("OnDragStart", function() f:StartMoving() end)
        titleBar:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

        local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")
        titleBg:SetAllPoints()
        titleBg:SetTexture(WV_FLAT_TEX)

        local hc = Theme.colors.header
        titleBg:SetVertexColor(hc[1], hc[2], hc[3], 0.58)

        local badge = CreateFrame("Frame", nil, f)
        badge:SetSize(180, 34)
        badge:SetPoint("BOTTOM", f, "TOP", 0, -8)
        badge:EnableMouse(true)
        badge:RegisterForDrag("LeftButton")
        badge:SetScript("OnDragStart", function() f:StartMoving() end)
        badge:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)
        local badgeBg = badge:CreateTexture(nil, "BACKGROUND")
        badgeBg:SetAllPoints()
        badgeBg:SetTexture(WV_FLAT_TEX)
        badgeBg:SetVertexColor(hc[1], hc[2], hc[3], 0.92)
        local badgeLine = badge:CreateTexture(nil, "BORDER")
        badgeLine:SetPoint("BOTTOMLEFT")
        badgeLine:SetPoint("BOTTOMRIGHT")
        badgeLine:SetHeight(1)
        badgeLine:SetTexture(WV_FLAT_TEX)
        local ac = Theme.colors.accent
        badgeLine:SetVertexColor(ac[1], ac[2], ac[3], 0.75)
        local badgeText = badge:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(badgeText, 17, WV_FONT_FLAGS, true)
        badgeText:SetPoint("CENTER")
        badgeText:SetText(Theme.Accent("AkcQOL"))

        local titleText = f:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(titleText, 18, "", true)
        titleText:SetPoint("TOP", f, "TOP", 0, -52)
        titleText:SetWidth(520)
        titleText:SetJustifyH("CENTER")
        titleText:SetTextColor(1, 1, 1, 1)
        titleText:SetShadowColor(0, 0, 0, 1)
        titleText:SetShadowOffset(1, -1)
        f.titleText = titleText

        local closeBtn = AkcQOL_CreateGlassButton(titleBar, "|cFFFF4D4DX|r", 24, 22, {1.0, 0.24, 0.2})
        closeBtn:SetPoint("RIGHT", titleBar, "RIGHT", -10, 0)
        closeBtn:SetScript("OnClick", function() AkcQOL_SafeHideFrame(f) end)
        f.closeBtn = closeBtn

        local charactersBtn = AkcQOL_CreateGlassButton(titleBar, "|cFFE5E7EB" .. L["Characters"] .. "|r", 92, 22, Theme.colors.accent)
        charactersBtn:SetPoint("RIGHT", closeBtn, "LEFT", -8, 0)
        charactersBtn:SetScript("OnClick", function(self)
            if _G.AkcQOL_ToggleMatrixCharacters then
                _G.AkcQOL_ToggleMatrixCharacters(self)
            end
        end)
        f.charactersBtn = charactersBtn

        local matrixBtn = AkcQOL_CreateGlassButton(titleBar, "|cFFE5E7EB" .. L["Matrix"] .. "|r", 76, 22, Theme.colors.accent)
        matrixBtn:SetPoint("LEFT", titleBar, "LEFT", 10, 0)
        matrixBtn:SetScript("OnClick", function()
            f:SetActiveTab("matrix")
        end)
        matrixBtn:Hide()
        f.matrixBtn = matrixBtn

        local rail = CreateFrame("Frame", nil, f)
        rail:SetPoint("TOPLEFT", 0, -1)
        rail:SetPoint("BOTTOMLEFT", 0, 1)
        rail:SetWidth(66)
        local railBg = rail:CreateTexture(nil, "BACKGROUND")
        railBg:SetAllPoints()
        railBg:SetTexture(WV_FLAT_TEX)
        local pc = Theme.colors.panelBg
        railBg:SetVertexColor(pc[1], pc[2], pc[3], 0.60)
        local railSep = rail:CreateTexture(nil, "BORDER")
        railSep:SetPoint("TOPRIGHT")
        railSep:SetPoint("BOTTOMRIGHT")
        railSep:SetWidth(1)
        railSep:SetTexture(WV_FLAT_TEX)
        railSep:SetVertexColor(Theme.rgba(Theme.colors.border))
        f.navButtons = {}

        local y = -42
        for navIndex, item in ipairs(AKCQOL_LOG_NAV) do
            local btn = CreateFrame("Button", nil, rail)
            btn:SetSize(44, 44)
            btn:SetPoint("TOPLEFT", rail, "TOPLEFT", 11, y)
            y = y - 58

            btn.bg = btn:CreateTexture(nil, "BACKGROUND")
            btn.bg:SetAllPoints()
            btn.bg:SetTexture(WV_FLAT_TEX)
            btn.icon = btn:CreateTexture(nil, "ARTWORK")
            btn.icon:SetPoint("CENTER")
            btn.icon:SetSize(38, 38)
            btn.icon:SetTexture(item.icon)
            btn.marker = btn:CreateTexture(nil, "OVERLAY")
            btn.marker:SetPoint("RIGHT", btn, "LEFT", -7, 0)
            btn.marker:SetSize(5, 42)
            btn.marker:SetTexture(WV_FLAT_TEX)
            btn.marker:SetVertexColor(Theme.rgba(Theme.colors.accent))
            if navIndex < #AKCQOL_LOG_NAV then
                btn.sep = rail:CreateTexture(nil, "BORDER")
                btn.sep:SetPoint("TOP", btn, "BOTTOM", 0, -7)
                btn.sep:SetSize(34, 1)
                btn.sep:SetTexture(WV_FLAT_TEX)
                btn.sep:SetVertexColor(Theme.rgba(Theme.colors.border))
            end
            btn.key = item.key
            btn.color = item.color
            btn.label = item.label
            btn:SetScript("OnClick", function(self)
                f:SetActiveTab(self.key)
            end)
            btn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(AkcQOL_ColorText(self.color, AKCQOL_LOG_TITLES[self.key] or self.label))
                GameTooltip:Show()
                self.bg:SetVertexColor(self.color[1] * 0.18, self.color[2] * 0.18, self.color[3] * 0.18, 0.86)
            end)
            btn:SetScript("OnLeave", function(self)
                GameTooltip:Hide()
                f:UpdateNav()
            end)
            f.navButtons[item.key] = btn
        end

        do
            local sBtn = CreateFrame("Button", nil, rail)
            sBtn:SetSize(44, 44)
            sBtn:SetPoint("BOTTOMLEFT", rail, "BOTTOMLEFT", 11, 12)
            sBtn.key = "settings"
            sBtn.color = Theme.colors.accent
            sBtn.label = "Settings"
            sBtn.bg = sBtn:CreateTexture(nil, "BACKGROUND")
            sBtn.bg:SetAllPoints()
            sBtn.bg:SetTexture(WV_FLAT_TEX)
            sBtn.icon = sBtn:CreateTexture(nil, "ARTWORK")
            sBtn.icon:SetPoint("CENTER")
            sBtn.icon:SetSize(34, 34)
            sBtn.icon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
            sBtn.marker = sBtn:CreateTexture(nil, "OVERLAY")
            sBtn.marker:SetPoint("RIGHT", sBtn, "LEFT", -7, 0)
            sBtn.marker:SetSize(5, 42)
            sBtn.marker:SetTexture(WV_FLAT_TEX)
            sBtn.marker:SetVertexColor(Theme.rgba(Theme.colors.accent))
            local sSep = rail:CreateTexture(nil, "BORDER")
            sSep:SetPoint("BOTTOM", sBtn, "TOP", 0, 7)
            sSep:SetSize(34, 1)
            sSep:SetTexture(WV_FLAT_TEX)
            sSep:SetVertexColor(Theme.rgba(Theme.colors.border))
            sBtn:SetScript("OnClick", function(self) f:SetActiveTab(self.key) end)
            sBtn:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(AkcQOL_ColorText(self.color, "Settings"))
                GameTooltip:Show()
                self.bg:SetVertexColor(self.color[1] * 0.18, self.color[2] * 0.18, self.color[3] * 0.18, 0.86)
            end)
            sBtn:SetScript("OnLeave", function()
                GameTooltip:Hide()
                f:UpdateNav()
            end)
            f.navButtons["settings"] = sBtn
        end

        local searchFrame = CreateFrame("Frame", nil, f, "BackdropTemplate")
        searchFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 86, -62)
        searchFrame:SetSize(250, 28)
        Theme.ApplyBackdrop(searchFrame, "inset")
        f.searchFrame = searchFrame

        local searchLabel = searchFrame:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(searchLabel, 13, WV_FONT_FLAGS)
        searchLabel:SetPoint("LEFT", 9, 0)
        searchLabel:SetText("|cFF8A8F98Search|r")

        local searchBox = CreateFrame("EditBox", nil, searchFrame)
        searchBox:SetPoint("LEFT", searchLabel, "RIGHT", 8, 0)
        searchBox:SetPoint("RIGHT", searchFrame, "RIGHT", -8, 0)
        searchBox:SetHeight(22)
        Theme.SetFont(searchBox, 12, "")
        searchBox:SetTextColor(0.93, 0.94, 0.98, 1)
        searchBox:SetAutoFocus(false)
        searchBox:EnableMouse(true)
        f.searchBox = searchBox

        local filters = CreateFrame("Frame", nil, f)
        filters:SetPoint("LEFT", searchFrame, "RIGHT", 26, 0)
        filters:SetSize(470, 28)
        f.filters = filters

        f.allCharsCheck = AkcQOL_CreateLogCheckbox(filters, L["All characters"], 150, true, function()
            f:Refresh()
        end)
        f.allCharsCheck:SetPoint("LEFT", filters, "LEFT", 0, 0)

        f.todayCheck = AkcQOL_CreateLogCheckbox(filters, L["Only show today"], 160, false, function()
            f:Refresh()
        end)
        f.todayCheck:SetPoint("LEFT", f.allCharsCheck, "RIGHT", 18, 0)

        local chatTabs = CreateFrame("Frame", nil, f)
        chatTabs:SetPoint("TOPLEFT", f, "TOPLEFT", 86, -96)
        chatTabs:SetPoint("TOPRIGHT", f, "TOPRIGHT", -24, -96)
        chatTabs:SetHeight(26)
        f.chatTabs = chatTabs
        f.chatTabButtons = {}

        local chatTabItems = {}
        for _, ch in ipairs(CHAT_LOG_CHANNELS) do chatTabItems[#chatTabItems + 1] = ch end
        local tabX = 0
        for _, ch in ipairs(chatTabItems) do
            local tab = CreateFrame("Button", nil, chatTabs)
            local labelW = ch.label:len() * 7 + 18
            tab:SetSize(labelW, 20)
            tab:SetPoint("LEFT", chatTabs, "LEFT", tabX, 0)
            tabX = tabX + labelW + 5
            tab.key = ch.key
            tab.color = ch.color
            tab.bg = tab:CreateTexture(nil, "BACKGROUND")
            tab.bg:SetAllPoints()
            tab.bg:SetTexture(WV_FLAT_TEX)
            tab.border = tab:CreateTexture(nil, "BORDER")
            tab.border:SetPoint("TOPLEFT", -1, 1)
            tab.border:SetPoint("BOTTOMRIGHT", 1, -1)
            tab.border:SetTexture(WV_FLAT_TEX)
            tab.text = tab:CreateFontString(nil, "OVERLAY")
            Theme.SetFont(tab.text, 10, WV_FONT_FLAGS)
            tab.text:SetAllPoints()
            tab.text:SetText(AkcQOL_ColorText(ch.color, ch.label))
            tab:SetScript("OnClick", function(self)
                f.activeChannel = self.key
                if self.key ~= "all" then
                    f.activeChatPerson = "all"
                end
                f:UpdateChatTabs()
                f:Refresh()
            end)
            tab:SetScript("OnEnter", function(self)
                self.bg:SetVertexColor(self.color[1] * 0.22, self.color[2] * 0.22, self.color[3] * 0.22, 0.95)
            end)
            tab:SetScript("OnLeave", function()
                f:UpdateChatTabs()
            end)
            f.chatTabButtons[#f.chatTabButtons + 1] = tab
        end

        local chatPeopleLeft = 86
        local chatPeopleWidth = 184
        local chatPeople = CreateFrame("Frame", nil, f, "BackdropTemplate")
        chatPeople:SetPoint("TOPLEFT", f, "TOPLEFT", chatPeopleLeft, -126)
        chatPeople:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", chatPeopleLeft, 56)
        chatPeople:SetWidth(chatPeopleWidth)
        Theme.ApplyBackdrop(chatPeople, "panel")

        chatPeople:SetBackdropBorderColor(1.0, 0.54, 1.0, 0.34)
        f.chatPeople = chatPeople
        f.chatPeopleButtons = {}
        f.chatTableLeft = chatPeopleLeft + chatPeopleWidth + 12

        local personSearchFrame = CreateFrame("Frame", nil, chatPeople, "BackdropTemplate")
        personSearchFrame:SetPoint("TOPLEFT", chatPeople, "TOPLEFT", 6, -6)
        personSearchFrame:SetPoint("TOPRIGHT", chatPeople, "TOPRIGHT", -6, -6)
        personSearchFrame:SetHeight(24)
        Theme.ApplyBackdrop(personSearchFrame, "inset")

        local personSearchLabel = personSearchFrame:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(personSearchLabel, 10, WV_FONT_FLAGS)
        personSearchLabel:SetPoint("LEFT", 7, 0)
        personSearchLabel:SetText("|cFF8A8F98Search|r")

        local personSearchBox = CreateFrame("EditBox", nil, personSearchFrame)
        personSearchBox:SetPoint("LEFT", personSearchLabel, "RIGHT", 6, 0)
        personSearchBox:SetPoint("RIGHT", personSearchFrame, "RIGHT", -6, 0)
        personSearchBox:SetHeight(18)
        Theme.SetFont(personSearchBox, 11, "")
        personSearchBox:SetTextColor(0.93, 0.94, 0.98, 1)
        personSearchBox:SetAutoFocus(false)
        personSearchBox:EnableMouse(true)
        f.chatPersonSearchBox = personSearchBox

        local peopleScroll = CreateFrame("ScrollFrame", nil, chatPeople, "UIPanelScrollFrameTemplate")
        peopleScroll:SetPoint("TOPLEFT", chatPeople, "TOPLEFT", 6, -36)
        peopleScroll:SetPoint("BOTTOMRIGHT", chatPeople, "BOTTOMRIGHT", -26, 6)
        f.chatPeopleScroll = peopleScroll

        local peopleContent = CreateFrame("Frame", nil, peopleScroll)
        peopleContent:SetWidth(150)
        peopleContent:SetHeight(1)
        peopleScroll:SetScrollChild(peopleContent)
        f.chatPeopleContent = peopleContent

        local logCharsLeft = 86
        local logCharsWidth = 184
        local logChars = CreateFrame("Frame", nil, f, "BackdropTemplate")
        logChars:SetPoint("TOPLEFT", f, "TOPLEFT", logCharsLeft, -96)
        logChars:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", logCharsLeft, 56)
        logChars:SetWidth(logCharsWidth)
        Theme.ApplyBackdrop(logChars, "panel")

        logChars:SetBackdropBorderColor(0.35, 0.68, 1.0, 0.34)
        f.logChars = logChars
        f.logCharButtons = {}
        f.logTableLeft = logCharsLeft + logCharsWidth + 12

        local logCharSearchFrame = CreateFrame("Frame", nil, logChars, "BackdropTemplate")
        logCharSearchFrame:SetPoint("TOPLEFT", logChars, "TOPLEFT", 6, -6)
        logCharSearchFrame:SetPoint("TOPRIGHT", logChars, "TOPRIGHT", -6, -6)
        logCharSearchFrame:SetHeight(24)
        Theme.ApplyBackdrop(logCharSearchFrame, "inset")

        local logCharSearchLabel = logCharSearchFrame:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(logCharSearchLabel, 10, WV_FONT_FLAGS)
        logCharSearchLabel:SetPoint("LEFT", 7, 0)
        logCharSearchLabel:SetText("|cFF8A8F98Search|r")

        local logCharSearchBox = CreateFrame("EditBox", nil, logCharSearchFrame)
        logCharSearchBox:SetPoint("LEFT", logCharSearchLabel, "RIGHT", 6, 0)
        logCharSearchBox:SetPoint("RIGHT", logCharSearchFrame, "RIGHT", -6, 0)
        logCharSearchBox:SetHeight(18)
        Theme.SetFont(logCharSearchBox, 11, "")
        logCharSearchBox:SetTextColor(0.93, 0.94, 0.98, 1)
        logCharSearchBox:SetAutoFocus(false)
        logCharSearchBox:EnableMouse(true)
        f.logCharSearchBox = logCharSearchBox

        local logCharsScroll = CreateFrame("ScrollFrame", nil, logChars, "UIPanelScrollFrameTemplate")
        logCharsScroll:SetPoint("TOPLEFT", logChars, "TOPLEFT", 6, -36)
        logCharsScroll:SetPoint("BOTTOMRIGHT", logChars, "BOTTOMRIGHT", -26, 6)
        f.logCharsScroll = logCharsScroll

        local logCharsContent = CreateFrame("Frame", nil, logCharsScroll)
        logCharsContent:SetWidth(150)
        logCharsContent:SetHeight(1)
        logCharsScroll:SetScrollChild(logCharsContent)
        f.logCharsContent = logCharsContent

        local totalText = f:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(totalText, 12, WV_FONT_FLAGS)
        totalText:SetJustifyH("RIGHT")
        totalText:SetPoint("TOPRIGHT", f, "TOPRIGHT", -22, -58)
        f.totalText = totalText

        local header = CreateFrame("Frame", nil, f)
        header:SetPoint("TOPLEFT", f, "TOPLEFT", 86, -112)
        header:SetPoint("TOPRIGHT", f, "TOPRIGHT", -24, -112)
        header:SetHeight(30)
        f.header = header
        header.bg = header:CreateTexture(nil, "BACKGROUND")
        header.bg:SetAllPoints()
        header.bg:SetTexture(WV_FLAT_TEX)

        local dateHead = header:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(dateHead, 12, WV_FONT_FLAGS, true)
        dateHead:SetPoint("LEFT", 12, 0)
        dateHead:SetWidth(155)
        dateHead:SetJustifyH("LEFT")
        f.dateHead = dateHead

        local charHead = header:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(charHead, 12, WV_FONT_FLAGS, true)
        charHead:SetPoint("LEFT", dateHead, "RIGHT", 18, 0)
        charHead:SetWidth(190)
        charHead:SetJustifyH("LEFT")
        f.charHead = charHead

        local entryHead = header:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(entryHead, 12, WV_FONT_FLAGS, true)
        entryHead:SetPoint("LEFT", charHead, "RIGHT", 18, 0)
        entryHead:SetPoint("RIGHT", header, "RIGHT", -12, 0)
        entryHead:SetJustifyH("LEFT")
        f.entryHead = entryHead

        local tablePanel = CreateFrame("Frame", nil, f)
        tablePanel:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -1)
        tablePanel:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 56)
        tablePanel.bg = tablePanel:CreateTexture(nil, "BACKGROUND")
        tablePanel.bg:SetAllPoints()
        tablePanel.bg:SetTexture(WV_FLAT_TEX)
        local ic = Theme.colors.insetBg
        tablePanel.bg:SetVertexColor(ic[1], ic[2], ic[3], 0.48)
        tablePanel.tint = tablePanel:CreateTexture(nil, "BORDER")
        tablePanel.tint:SetAllPoints()
        tablePanel.tint:SetTexture(WV_FLAT_TEX)
        tablePanel.tint:SetVertexColor(0.96, 0.62, 0.04, 0.035)
        f.tablePanel = tablePanel

        local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", tablePanel, "TOPLEFT", 0, 0)
        scroll:SetPoint("BOTTOMRIGHT", tablePanel, "BOTTOMRIGHT", 0, 0)
        f.scroll = scroll

        local scrollChild = CreateFrame("Frame", nil, scroll)
        scrollChild:SetWidth(1010)
        scrollChild:SetHeight(1)
        scroll:SetScrollChild(scrollChild)
        f.scrollChild = scrollChild
        f.rows = {}

        local resultText = f:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(resultText, 13, WV_FONT_FLAGS)
        resultText:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 86, 17)
        resultText:SetTextColor(0.95, 0.96, 0.98, 1)
        f.resultText = resultText

        local exportBtn = AkcQOL_CreateGlassButton(f, "|cFFE5E7EB" .. L["Export Log"] .. "|r", 128, 30, Theme.colors.accent)
        exportBtn:SetPoint("BOTTOM", f, "BOTTOM", 74, 13)
        exportBtn:SetScript("OnClick", function()
            AkcQOL_ShowLogExport(AKCQOL_LOG_TITLES[f.activeTab] or "Logs", f.currentExportText or "")
        end)
        f.exportBtn = exportBtn

        local clearBtn = AkcQOL_CreateGlassButton(f, "|cFFE5E7EB" .. L["Clear Log"] .. "|r", 128, 30, {0.95, 0.38, 0.32})
        clearBtn:SetPoint("RIGHT", exportBtn, "LEFT", -12, 0)
        f.clearBtn = clearBtn

        StaticPopupDialogs["AKCQOL_CLEAR_LOGS_HUB"] = {
            text = L["Clear the selected AkcQOL log?"],
            button1 = YES,
            button2 = NO,
            OnAccept = function()
                if not AKCQOL_LOGS_FRAME then return end
                local key = AKCQOL_LOGS_FRAME.activeTab or "mail"
                EnsureLogDB()
                if key == "chat" then
                    local activeChannel = AKCQOL_LOGS_FRAME.activeChannel or "all"
                    local activePerson = AKCQOL_LOGS_FRAME.activeChatPerson or "all"
                    for _, ch in ipairs(CHAT_LOG_CHANNELS) do
                        if activeChannel == "all" or activeChannel == ch.key then
                            if activePerson == "all" then
                                AkcQOLDB.global.logs.chat[ch.key] = {}
                            else
                                local filtered = {}
                                local raw = AkcQOLDB.global.logs.chat[ch.key] or {}
                                for i = 1, #raw do
                                    local _, author = AkcQOL_ParseChatLogEntry(raw[i])
                                    if AkcQOL_GetChatConversationPerson(ch.key, author) ~= activePerson then
                                        filtered[#filtered + 1] = raw[i]
                                    end
                                end
                                AkcQOLDB.global.logs.chat[ch.key] = filtered
                            end
                        end
                    end
                    AKCQOL_LOGS_FRAME.activeChatPerson = "all"
                elseif key == "lua" then
                    if _G.AkcQOL_ClearErrorLog then
                        pcall(_G.AkcQOL_ClearErrorLog)
                    elseif AkcQOLDB.global.luaErrors then
                        AkcQOLDB.global.luaErrors.entries = {}
                        AkcQOLDB.global.luaErrors.unreadCount = 0
                    end
                elseif AKCQOL_CHARACTER_LOG_TYPES[key] then
                    local selectedChar = AKCQOL_LOGS_FRAME.activeLogChar or "all"
                    if selectedChar ~= "all" then
                        if AkcQOLDB.global.logsByChar and AkcQOLDB.global.logsByChar[key] then
                            AkcQOLDB.global.logsByChar[key][selectedChar] = {}
                        end
                        local kept = {}
                        for _, entry in ipairs(AkcQOLDB.global.logs[key] or {}) do
                            if AkcQOL_GetCharFromLogEntry(AkcQOL_UntaintLog(entry) or "") ~= selectedChar then
                                kept[#kept + 1] = entry
                            end
                        end
                        AkcQOLDB.global.logs[key] = kept
                    else
                        AkcQOLDB.global.logs[key] = {}
                        if AkcQOLDB.global.logsByChar then
                            AkcQOLDB.global.logsByChar[key] = {}
                        end
                    end
                    if AkcQOLDB.global.logsByCharMigrated then
                        AkcQOLDB.global.logsByCharMigrated[key] = true
                    end
                else
                    AkcQOLDB.global.logs[key] = {}
                end
                AKCQOL_LOGS_FRAME:Refresh()
            end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            preferredIndex = 3,
        }
        clearBtn:SetScript("OnClick", function()
            StaticPopup_Show("AKCQOL_CLEAR_LOGS_HUB")
        end)

        local resizeGrip = CreateFrame("Button", nil, f)
        resizeGrip:SetSize(18, 18)
        resizeGrip:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -4, 4)
        f.resizeDots = {}
        local gripPos = {{0,0},{5,0},{10,0},{5,5},{10,5},{10,10}}
        for _, pos in ipairs(gripPos) do
            local dot = resizeGrip:CreateTexture(nil, "OVERLAY")
            dot:SetTexture(WV_FLAT_TEX)
            dot:SetSize(2, 2)
            dot:SetPoint("BOTTOMRIGHT", resizeGrip, "BOTTOMRIGHT", -pos[1], pos[2])
            f.resizeDots[#f.resizeDots + 1] = dot
        end
        resizeGrip:SetScript("OnMouseDown", function(_, button)
            if button ~= "LeftButton" then return end
            f.isScaleSizing = true
            f.scaleStartX, f.scaleStartY = GetCursorPosition()
            f.scaleStart = f:GetScale() or 1
            resizeGrip:SetScript("OnUpdate", function()
                if not f.isScaleSizing then return end

                if not IsMouseButtonDown("LeftButton") then
                    f.isScaleSizing = false
                    resizeGrip:SetScript("OnUpdate", nil)
                    return
                end
                local curX, curY = GetCursorPosition()
                local dx = (curX - (f.scaleStartX or curX)) / 520
                local dy = ((f.scaleStartY or curY) - curY) / 520
                local diff
                if dx * dy > 0 then
                    diff = (dx + dy) / 2
                elseif math.abs(dx) > math.abs(dy) then
                    diff = dx
                else
                    diff = dy
                end
                local newScale = (f.scaleStart or 1) + diff
                local frameW = f:GetWidth() or 1280
                local frameH = f:GetHeight() or 720
                local screenW = UIParent:GetWidth() or frameW
                local screenH = UIParent:GetHeight() or frameH
                local maxScale = math.min(1.8, screenW / frameW, screenH / frameH)
                if maxScale < 0.7 then maxScale = 0.7 end
                if newScale < 0.55 then newScale = 0.55 end
                if newScale > maxScale then newScale = maxScale end
                f:SetScale(newScale)
                if _G.AkcQOLSettingsFrame and AkcQOL_IsFrameOpen(_G.AkcQOLSettingsFrame) then

                    _G.AkcQOLSettingsFrame:SetScale(1)
                end
                if _G.AkcQOLMatrix_FilterMenu and AkcQOL_IsFrameOpen(_G.AkcQOLMatrix_FilterMenu) then
                    _G.AkcQOLMatrix_FilterMenu:SetScale(newScale)
                end
                if AkcQOLDB and AkcQOLDB.global then
                    AkcQOLDB.global.mainWindowScale = newScale
                end
            end)
        end)
        resizeGrip:SetScript("OnMouseUp", function()
            f.isScaleSizing = false
            resizeGrip:SetScript("OnUpdate", nil)
        end)

        function f:UpdateNav()
            local c = Theme.colors
            for key, btn in pairs(self.navButtons) do
                local active = key == self.activeTab
                btn.marker:SetShown(active)
                if active then
                    btn.bg:SetVertexColor(c.rowHover[1], c.rowHover[2], c.rowHover[3], c.rowHover[4])
                    btn.icon:SetAlpha(1)
                else
                    btn.bg:SetVertexColor(c.insetBg[1], c.insetBg[2], c.insetBg[3], 0.86)
                    btn.icon:SetAlpha(0.86)
                end
            end
        end

        function f:UpdateChatTabs()
            for _, tab in ipairs(self.chatTabButtons) do
                local active = tab.key == self.activeChannel
                if active then
                    tab.bg:SetVertexColor(tab.color[1] * 0.20, tab.color[2] * 0.20, tab.color[3] * 0.20, 1)
                    tab.border:SetVertexColor(tab.color[1], tab.color[2], tab.color[3], 1)
                else
                    local pb = Theme.colors.panelBg
                    tab.bg:SetVertexColor(pb[1], pb[2], pb[3], 0.9)
                    tab.border:SetVertexColor(tab.color[1] * 0.4, tab.color[2] * 0.4, tab.color[3] * 0.4, 0.6)
                end
            end
        end

        function f:CollectChatPeople()
            EnsureLogDB()
            AkcQOL_MigrateLegacyBattleNetWhispers()
            local people, seen = {}, {}
            local activeChannel = self.activeChannel or "all"

            for _, ch in ipairs(CHAT_LOG_CHANNELS) do
                if activeChannel == "all" or activeChannel == ch.key then
                    local raw = AkcQOLDB.global.logs.chat[ch.key] or {}
                    for i = 1, #raw do
                        local _, author = AkcQOL_ParseChatLogEntry(raw[i])
                        local person = AkcQOL_GetChatConversationPerson(ch.key, author)
                        if person and person ~= "" and not seen[person] then
                            seen[person] = true
                            people[#people + 1] = { key = person, label = person }
                        end
                    end
                end
            end

            table.sort(people, function(a, b)
                return TRLower(a.label or a.key or "") < TRLower(b.label or b.key or "")
            end)
            return people
        end

        function f:UpdateChatPeople()
            local frame = self.chatPeople
            if not frame then return end

            local selected = self.activeChatPerson or "all"
            local people = self:CollectChatPeople()
            local searchText = ""
            if self.chatPersonSearchBox and self.chatPersonSearchBox.GetText then
                searchText = TRLower(AkcQOL_UntaintLog(self.chatPersonSearchBox:GetText()) or "")
            end
            local exists = selected == "all"
            for _, person in ipairs(people) do
                if person.key == selected then exists = true break end
            end
            if not exists then
                self.activeChatPerson = "all"
                selected = "all"
            end

            local items = { { key = "all", label = "All" } }
            for _, person in ipairs(people) do
                local label = person.label or person.key or ""
                if searchText == "" or person.key == selected or TRLower(label):find(searchText, 1, true) then
                    items[#items + 1] = person
                end
            end

            local content = self.chatPeopleContent or frame
            local width = math.max(120, (self.chatPeopleScroll and self.chatPeopleScroll:GetWidth() or frame:GetWidth() or 160) - 4)
            local rowH = 24
            for i, item in ipairs(items) do
                local btn = self.chatPeopleButtons[i]
                if not btn then
                    btn = CreateFrame("Button", nil, content)
                    btn:SetHeight(rowH - 2)
                    btn.bg = btn:CreateTexture(nil, "BACKGROUND")
                    btn.bg:SetAllPoints()
                    btn.bg:SetTexture(WV_FLAT_TEX)
                    btn.border = btn:CreateTexture(nil, "BORDER")
                    btn.border:SetPoint("TOPLEFT", -1, 1)
                    btn.border:SetPoint("BOTTOMRIGHT", 1, -1)
                    btn.border:SetTexture(WV_FLAT_TEX)
                    btn.text = btn:CreateFontString(nil, "OVERLAY")
                    Theme.SetFont(btn.text, 10, WV_FONT_FLAGS)
                    btn.text:SetPoint("LEFT", 8, 0)
                    btn.text:SetPoint("RIGHT", btn, "RIGHT", -6, 0)
                    btn.text:SetJustifyH("LEFT")
                    btn:SetScript("OnClick", function(self)
                        f.activeChatPerson = self.personKey or "all"
                        f:UpdateChatTabs()
                        f:Refresh()
                    end)
                    btn:SetScript("OnEnter", function(self)
                        self.bg:SetVertexColor(0.22, 0.18, 0.24, 0.95)
                    end)
                    btn:SetScript("OnLeave", function(self)

                        if (self.personKey or "all") == (f.activeChatPerson or "all") then
                            self.bg:SetVertexColor(0.20, 0.13, 0.22, 1)
                        else
                            self.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                        end
                    end)
                    self.chatPeopleButtons[i] = btn
                end

                local label = item.label or item.key or "Unknown"
                local display = AkcQOL_TruncateUtf8(label, 20)
                btn.personKey = item.key
                btn:SetSize(width, rowH - 2)
                btn:ClearAllPoints()
                btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * rowH))
                btn:SetPoint("RIGHT", content, "RIGHT", -2, 0)
                local active = item.key == selected
                if active then
                    btn.bg:SetVertexColor(0.20, 0.13, 0.22, 1)
                    btn.border:SetVertexColor(1.0, 0.54, 1.0, 0.95)
                else
                    btn.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                    btn.border:SetVertexColor(0.65, 0.35, 0.65, 0.45)
                end
                btn.text:SetText(item.key == "all" and "|cFFE5E7EBAll|r" or "|cFFFFA6FF" .. display .. "|r")
                btn:Show()
            end

            for i = #items + 1, #self.chatPeopleButtons do
                self.chatPeopleButtons[i]:Hide()
            end

            local height = math.max(1, #items * rowH)
            content:SetWidth(width)
            content:SetHeight(height)
            if self.chatPeopleScroll and self.chatPeopleScroll:GetVerticalScroll() > (self.chatPeopleScroll:GetVerticalScrollRange() or 0) then
                self.chatPeopleScroll:SetVerticalScroll(self.chatPeopleScroll:GetVerticalScrollRange() or 0)
            end
        end

        function f:CollectLogCharacters(key)
            EnsureLogDB()
            if not AKCQOL_CHARACTER_LOG_TYPES[key] then return {} end

            local chars, seen = {}, {}
            local function AddChar(char)
                if char and char ~= "" and not seen[char] then
                    seen[char] = true
                    chars[#chars + 1] = { key = char, label = char }
                end
            end

            local byType = AkcQOLDB.global.logsByChar and AkcQOLDB.global.logsByChar[key]
            if type(byType) == "table" then
                for char, entries in pairs(byType) do
                    if type(entries) == "table" and #entries > 0 then
                        AddChar(char)
                    end
                end
            end

            for _, entry in ipairs(AkcQOLDB.global.logs[key] or {}) do
                AddChar(AkcQOL_GetCharFromLogEntry(AkcQOL_UntaintLog(entry) or ""))
            end

            table.sort(chars, function(a, b)
                return TRLower(a.label or a.key or "") < TRLower(b.label or b.key or "")
            end)
            return chars
        end

        function f:UpdateLogCharacters()
            local key = self.activeTab or "mail"
            local frame = self.logChars
            if not frame or not AKCQOL_CHARACTER_LOG_TYPES[key] then return end

            local color = AkcQOL_GetLogColor(key)
            frame:SetBackdropBorderColor(color[1], color[2], color[3], 0.38)

            local selected = self.activeLogChar or "all"
            local chars = self:CollectLogCharacters(key)
            local searchText = ""
            if self.logCharSearchBox and self.logCharSearchBox.GetText then
                searchText = TRLower(AkcQOL_UntaintLog(self.logCharSearchBox:GetText()) or "")
            end

            local exists = selected == "all"
            for _, char in ipairs(chars) do
                if char.key == selected then exists = true break end
            end
            if not exists then
                self.activeLogChar = "all"
                selected = "all"
            end

            local items = { { key = "all", label = "All" } }
            for _, char in ipairs(chars) do
                local label = char.label or char.key or ""
                if searchText == "" or char.key == selected or TRLower(label):find(searchText, 1, true) then
                    items[#items + 1] = char
                end
            end

            local content = self.logCharsContent or frame
            local width = math.max(120, (self.logCharsScroll and self.logCharsScroll:GetWidth() or frame:GetWidth() or 160) - 4)
            local rowH = 24
            for i, item in ipairs(items) do
                local btn = self.logCharButtons[i]
                if not btn then
                    btn = CreateFrame("Button", nil, content)
                    btn:SetHeight(rowH - 2)
                    btn.bg = btn:CreateTexture(nil, "BACKGROUND")
                    btn.bg:SetAllPoints()
                    btn.bg:SetTexture(WV_FLAT_TEX)
                    btn.border = btn:CreateTexture(nil, "BORDER")
                    btn.border:SetPoint("TOPLEFT", -1, 1)
                    btn.border:SetPoint("BOTTOMRIGHT", 1, -1)
                    btn.border:SetTexture(WV_FLAT_TEX)
                    btn.text = btn:CreateFontString(nil, "OVERLAY")
                    Theme.SetFont(btn.text, 10, WV_FONT_FLAGS)
                    btn.text:SetPoint("LEFT", 8, 0)
                    btn.text:SetPoint("RIGHT", btn, "RIGHT", -6, 0)
                    btn.text:SetJustifyH("LEFT")
                    btn:SetScript("OnClick", function(self)
                        f.activeLogChar = self.logCharKey or "all"
                        if f.allCharsCheck then
                            f.allCharsCheck:SetChecked(f.activeLogChar == "all")
                        end
                        f:Refresh()
                    end)
                    btn:SetScript("OnEnter", function(self)
                        local c = self.color or {0.35, 0.68, 1.0}
                        self.bg:SetVertexColor(c[1] * 0.20, c[2] * 0.20, c[3] * 0.20, 0.95)
                    end)
                    btn:SetScript("OnLeave", function(self)

                        local c = self.color or {0.35, 0.68, 1.0}
                        if (self.logCharKey or "all") == (f.activeLogChar or "all") then
                            self.bg:SetVertexColor(c[1] * 0.22, c[2] * 0.22, c[3] * 0.22, 1)
                        else
                            self.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                        end
                    end)
                    self.logCharButtons[i] = btn
                end

                local label = item.label or item.key or "Unknown"
                local display = AkcQOL_TruncateUtf8(label, 20)
                btn.logCharKey = item.key
                btn.color = color
                btn:SetSize(width, rowH - 2)
                btn:ClearAllPoints()
                btn:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * rowH))
                btn:SetPoint("RIGHT", content, "RIGHT", -2, 0)
                local active = item.key == selected
                if active then
                    btn.bg:SetVertexColor(color[1] * 0.22, color[2] * 0.22, color[3] * 0.22, 1)
                    btn.border:SetVertexColor(color[1], color[2], color[3], 0.95)
                else
                    btn.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                    btn.border:SetVertexColor(color[1] * 0.45, color[2] * 0.45, color[3] * 0.45, 0.45)
                end
                btn.text:SetText(item.key == "all" and "|cFFE5E7EBAll|r" or AkcQOL_ColorText(color, display))
                btn:Show()
            end

            for i = #items + 1, #self.logCharButtons do
                self.logCharButtons[i]:Hide()
            end

            local height = math.max(1, #items * rowH)
            content:SetWidth(width)
            content:SetHeight(height)
            if self.logCharsScroll and self.logCharsScroll:GetVerticalScroll() > (self.logCharsScroll:GetVerticalScrollRange() or 0) then
                self.logCharsScroll:SetVerticalScroll(self.logCharsScroll:GetVerticalScrollRange() or 0)
            end
        end

        local function GetOrCreateRow(index)
            local row = f.rows[index]
            if row then return row end
            row = CreateFrame("Button", nil, f.scrollChild)
            row:SetHeight(30)
            row.bg = row:CreateTexture(nil, "BACKGROUND")
            row.bg:SetAllPoints()
            row.bg:SetTexture(WV_FLAT_TEX)
            row.left = row:CreateTexture(nil, "BORDER")
            row.left:SetPoint("TOPLEFT")
            row.left:SetPoint("BOTTOMLEFT")
            row.left:SetWidth(3)
            row.left:SetTexture(WV_FLAT_TEX)
            row.date = row:CreateFontString(nil, "OVERLAY")
            Theme.SetFont(row.date, 12, "")
            row.date:SetPoint("LEFT", 12, 0)
            row.date:SetWidth(155)
            row.date:SetJustifyH("LEFT")
            row.date:SetTextColor(0.93, 0.94, 0.98, 1)
            row.char = row:CreateFontString(nil, "OVERLAY")
            Theme.SetFont(row.char, 12, "")
            row.char:SetPoint("LEFT", row.date, "RIGHT", 18, 0)
            row.char:SetWidth(190)
            row.char:SetJustifyH("LEFT")
            row.char:SetTextColor(0.88, 0.9, 0.94, 1)
            row.body = row:CreateFontString(nil, "OVERLAY")

            Theme.SetFont(row.body, 12, "")
            row.body:SetPoint("LEFT", row.char, "RIGHT", 18, 0)
            row.body:SetPoint("RIGHT", row, "RIGHT", -12, 0)
            row.body:SetJustifyH("LEFT")
            row.body:SetWordWrap(false)
            row.body:SetTextColor(0.93, 0.94, 0.98, 1)
            AkcQOL_EnableLogHyperlinks(row.body, row)
            row.bubble = CreateFrame("Frame", nil, row, "BackdropTemplate")
            row.bubble:SetBackdrop({ bgFile = WV_FLAT_TEX, edgeFile = WV_FLAT_TEX, edgeSize = 1 })
            row.bubble:EnableMouse(false)
            row.bubble:Hide()
            row.bubbleMeta = row.bubble:CreateFontString(nil, "OVERLAY")
            Theme.SetFont(row.bubbleMeta, 10, "")
            row.bubbleMeta:SetTextColor(0.82, 0.84, 0.88, 0.92)
            row.bubbleMeta:Hide()
            row.bubbleText = row.bubble:CreateFontString(nil, "OVERLAY")

            Theme.SetFont(row.bubbleText, 12, "")
            row.bubbleText:SetTextColor(0.96, 0.97, 1.0, 1)
            row.bubbleText:SetJustifyH("LEFT")
            row.bubbleText:SetJustifyV("TOP")
            row.bubbleText:SetWordWrap(true)
            row.bubbleText:Hide()
            AkcQOL_EnableLogHyperlinks(row.bubbleText, row)
            row:SetScript("OnEnter", function(self)
                local c = self.color or {0.96, 0.62, 0.04}
                if self.isChatBubble then
                    self.bg:SetVertexColor(c[1] * 0.10, c[2] * 0.10, c[3] * 0.10, 0.22)
                else
                    self.bg:SetVertexColor(Theme.rgba(Theme.colors.rowHover))
                end
            end)
            row:SetScript("OnLeave", function(self)
                GameTooltip:Hide()
                if self.isChatBubble then
                    self.bg:SetVertexColor(0.014, 0.015, 0.012, 0.10)
                elseif self.rowIndex and self.rowIndex % 2 == 0 then
                    self.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                else
                    self.bg:SetVertexColor(0.014, 0.015, 0.012, 0.34)
                end
            end)
            row:SetScript("OnClick", function(self)
                local raw = AkcQOL_UntaintLog(self.rawText)
                if raw and raw ~= "" then
                    AkcQOL_ShowLogExport(self.rawTitle or "Log Entry", raw)
                end
            end)
            f.rows[index] = row
            return row
        end

        local function LayoutLogRowColumns(row, hideCharacterColumn)
            if not row or not row.date or not row.char or not row.body then return end

            row.isChatBubble = false
            if row.bubble then row.bubble:Hide() end
            if row.bubbleMeta then row.bubbleMeta:Hide() end
            if row.bubbleText then row.bubbleText:Hide() end
            if row.left then row.left:Show() end
            row.date:Show()
            row.body:Show()
            row.linkHost = row.body
            if hideCharacterColumn then
                row.char:Hide()
            else
                row.char:Show()
            end

            row.body:ClearAllPoints()
            row.body:SetWordWrap(false)
            row.body:SetJustifyH("LEFT")
            row.body:SetTextColor(0.93, 0.94, 0.98, 1)
            if hideCharacterColumn then
                row.body:SetPoint("LEFT", row.date, "RIGHT", 18, 0)
            else
                row.body:SetPoint("LEFT", row.char, "RIGHT", 18, 0)
            end
            row.body:SetPoint("RIGHT", row, "RIGHT", -12, 0)
        end

        local function LayoutChatBubbleRow(row, data, width)
            if not row or not data then return 30 end

            local outgoing = data.isOutgoing and true or false
            local bubbleW = math.max(280, math.min(560, math.floor((width or 720) * 0.46)))
            local bubblePadX = 12
            local metaH = 13
            local bodyText = data.bubbleText or data.bodyText or ""
            local timeText = tostring(data.dateText or ""):match("(%d%d:%d%d:%d%d)$") or tostring(data.dateText or "")
            local authorText = outgoing and "You" or (data.charText ~= "" and data.charText or "Whisper")

            row.isChatBubble = true
            row.bg:SetVertexColor(0.014, 0.015, 0.012, 0.10)
            row.left:Hide()
            row.date:Hide()
            row.char:Hide()
            row.body:Hide()
            row.bubble:Show()
            row.bubbleMeta:Show()
            row.bubbleText:Show()
            row.linkHost = row.bubbleText

            row.bubble:ClearAllPoints()
            row.bubble:SetSize(bubbleW, 34)
            if outgoing then
                row.bubble:SetPoint("TOPRIGHT", row, "TOPRIGHT", -16, -4)
                row.bubble:SetBackdropColor(0.16, 0.105, 0.035, 0.58)
                row.bubble:SetBackdropBorderColor(1.0, 0.72, 0.18, 0.28)
            else
                row.bubble:SetPoint("TOPLEFT", row, "TOPLEFT", 16, -4)
                row.bubble:SetBackdropColor(0.10, 0.055, 0.12, 0.58)
                row.bubble:SetBackdropBorderColor(1.0, 0.54, 1.0, 0.26)
            end

            row.bubbleMeta:ClearAllPoints()
            row.bubbleMeta:SetPoint("TOPLEFT", row.bubble, "TOPLEFT", bubblePadX, -5)
            row.bubbleMeta:SetPoint("RIGHT", row.bubble, "RIGHT", -bubblePadX, 0)
            row.bubbleMeta:SetJustifyH(outgoing and "RIGHT" or "LEFT")
            row.bubbleMeta:SetText(authorText .. " - " .. timeText)

            row.bubbleText:ClearAllPoints()
            row.bubbleText:SetPoint("TOPLEFT", row.bubble, "TOPLEFT", bubblePadX, -(metaH + 8))
            row.bubbleText:SetPoint("RIGHT", row.bubble, "RIGHT", -bubblePadX, 0)
            row.bubbleText:SetWidth(math.max(120, bubbleW - (bubblePadX * 2)))
            row.bubbleText:SetText(bodyText)

            local textH = row.bubbleText:GetStringHeight() or 14
            local bubbleH = math.max(38, math.ceil(textH) + metaH + 16)
            local rowH = bubbleH + 8
            row.bubble:SetHeight(bubbleH)
            row:SetHeight(rowH)
            return rowH
        end

        local function LayoutLogHeaderColumns(frame, hideCharacterColumn)
            if not frame or not frame.dateHead or not frame.charHead or not frame.entryHead or not frame.header then return end

            if hideCharacterColumn then
                frame.charHead:Hide()
            else
                frame.charHead:Show()
            end

            frame.entryHead:ClearAllPoints()
            if hideCharacterColumn then
                frame.entryHead:SetPoint("LEFT", frame.dateHead, "RIGHT", 18, 0)
            else
                frame.entryHead:SetPoint("LEFT", frame.charHead, "RIGHT", 18, 0)
            end
            frame.entryHead:SetPoint("RIGHT", frame.header, "RIGHT", -12, 0)
        end

        function f:BuildRows()
            EnsureLogDB()
            local key = self.activeTab or "mail"
            local query = TRLower(AkcQOL_UntaintLog(self.searchBox:GetText()) or "")
            local today = date("%Y-%m-%d")
            local recentCutoff = date("%Y-%m-%d", time() - 2 * 86400)
            local rows, exportLines = {}, {}

            if key == "chat" then
                AkcQOL_MigrateLegacyBattleNetWhispers()
                local activeChannel = self.activeChannel or "all"
                local activePerson = self.activeChatPerson or "all"
                for _, ch in ipairs(CHAT_LOG_CHANNELS) do
                    if activeChannel == "all" or activeChannel == ch.key then
                        local raw = AkcQOLDB.global.logs.chat[ch.key] or {}
                        local channelInfo = AkcQOL_GetChatChannelInfo(ch.key)
                        for i = 1, #raw do
                            local dt, author, body, clean = AkcQOL_ParseChatLogEntry(raw[i])
                            local person = AkcQOL_GetChatConversationPerson(ch.key, author)
                            local recentOK = activeChannel ~= "all" or dt == "" or string.sub(dt, 1, 10) >= recentCutoff
                            if clean and recentOK and (activePerson == "all" or activePerson == person) and (query == "" or TRLower(clean):find(query, 1, true)) then
                                local bodyText = AkcQOL_NormalizeStoredChatBody(ch.key, body ~= "" and body or clean)
                                local bubbleText = bodyText
                                local rawText = clean
                                if AkcQOL_IsProtectedChatPayloadText(body) then
                                    rawText = string.format("%s [%s] %s", dt ~= "" and dt or "-", author ~= "" and author or "-", bodyText)
                                end
                                local rawAuthor = AkcQOL_UntaintLog(author) or ""
                                rawAuthor = rawAuthor:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
                                local isOutgoing = rawAuthor:match("^%s*To%s+") or rawAuthor:match("^%s*To:%s*")
                                if activeChannel == "all" then
                                    bodyText = AkcQOL_ColorText(channelInfo.color, "[" .. channelInfo.label .. "]") .. " " .. bodyText
                                end
                                rows[#rows + 1] = {
                                    raw = rawText,
                                    dateText = dt ~= "" and dt or "-",
                                    charText = author ~= "" and author or "-",
                                    bodyText = bodyText,
                                    bubbleText = bubbleText,
                                    isWhisper = ch.key == "whisper" or ch.key == "bnet",
                                    isOutgoing = isOutgoing and true or false,
                                    sourceIndex = i,
                                }
                            end
                        end
                    end
                end
            elseif key == "lua" then
                AkcQOL_MarkLuaErrorsSeenFromLogs()
                local db = AkcQOLDB.global.luaErrors or {}
                local entries = db.entries or {}
                for _, entry in ipairs(entries) do
                    if type(entry) == "table" then
                        local detail = AkcQOL_BuildLuaErrorExport(entry)
                        if query == "" or TRLower(detail):find(query, 1, true) then
                            local msg = tostring(entry.message or "Unknown error")
                            msg = msg:match("([^\r\n]+)") or msg
                            rows[#rows + 1] = {
                                raw = detail,
                                dateText = tostring(entry.lastSeenText or entry.firstSeenText or "-"),
                                charText = tostring(entry.addon or "Unknown"),
                                bodyText = string.format("%s x%d", msg, entry.count or 1),
                            }
                        end
                    end
                end
            else
                local selectedLogChar = self.activeLogChar or "all"
                local showAll = selectedLogChar == "all"
                local onlyToday = self.todayCheck:GetChecked()
                local rawEntries = {}
                local usedByCharBuckets = false
                local function AppendEntries(source)
                    if type(source) ~= "table" then return end
                    for i = 1, #source do
                        rawEntries[#rawEntries + 1] = source[i]
                    end
                end

                if AKCQOL_CHARACTER_LOG_TYPES[key] and AkcQOLDB.global.logsByChar and AkcQOLDB.global.logsByChar[key] then
                    local byType = AkcQOLDB.global.logsByChar[key]
                    usedByCharBuckets = true
                    if showAll then
                        for _, list in pairs(byType) do
                            AppendEntries(list)
                        end
                    else
                        AppendEntries(byType[selectedLogChar])
                    end
                end

                if #rawEntries == 0 then
                    AppendEntries(AkcQOLDB.global.logs[key] or {})
                end

                local cleanEntries = {}
                local seenEntries = {}
                for i = 1, #rawEntries do
                    local clean = AkcQOL_UntaintLog(rawEntries[i])
                    if clean and not seenEntries[clean] then
                        seenEntries[clean] = true
                        cleanEntries[#cleanEntries + 1] = clean

                    end
                end
                if not usedByCharBuckets then
                    AkcQOLDB.global.logs[key] = cleanEntries
                end

                for _, entry in ipairs(cleanEntries) do
                    local dt, char, body = AkcQOL_ParseLogEntry(entry)
                    local dateOK = not onlyToday or (dt ~= "" and string.sub(dt, 1, 10) == today)
                    local recentOK = not showAll or dt == "" or string.sub(dt, 1, 10) >= recentCutoff
                    local charOK = showAll or char == "" or char == selectedLogChar
                    local searchOK = query == "" or TRLower(entry):find(query, 1, true)
                    if dateOK and recentOK and charOK and searchOK then
                        rows[#rows + 1] = {
                            raw = entry,
                            dateText = dt ~= "" and dt or "-",
                            charText = char ~= "" and char or "-",
                            bodyText = body ~= "" and body or entry,
                        }
                    end
                end
            end

            if #rows > 1 then
                table.sort(rows, function(a, b)
                    local av = a.dateText ~= "-" and a.dateText or a.raw
                    local bv = b.dateText ~= "-" and b.dateText or b.raw
                    if av == bv then
                        return (a.sourceIndex or 0) > (b.sourceIndex or 0)
                    end
                    return av < bv
                end)
            end

            for _, row in ipairs(rows) do
                exportLines[#exportLines + 1] = row.raw
            end
            return rows, exportLines
        end

        function f:Refresh()
            local key = self.activeTab or "mail"
            local color = AkcQOL_GetLogColor(key)
            local title = AKCQOL_LOG_TITLES[key] or "Logs"
            self:SetBackdropBorderColor(color[1], color[2], color[3], 0.54)
            self.titleText:SetText(AkcQOL_ColorText({color[1], color[2], color[3]}, title))
            self.titleText:SetTextColor(1, 1, 1, 1)
            self.header.bg:SetVertexColor(color[1] * 0.12, color[2] * 0.12, color[3] * 0.12, 0.60)
            if self.tablePanel and self.tablePanel.tint then
                self.tablePanel.tint:SetVertexColor(color[1], color[2], color[3], 0.035)
            end
            for _, dot in ipairs(self.resizeDots) do
                dot:SetVertexColor(color[1], color[2], color[3], 0.58)
            end

            if key ~= "settings" and _G.AkcQOLSettingsFrame and _G.AkcQOLSettingsFrame:GetParent() == self then
                AkcQOL_SafeHideFrame(_G.AkcQOLSettingsFrame)
            end

            if key == "settings" then
                if self.searchFrame then self.searchFrame:Hide() end
                if self.filters then self.filters:Hide() end
                if self.chatTabs then self.chatTabs:Hide() end
                if self.chatPeople then self.chatPeople:Hide() end
                if self.logChars then self.logChars:Hide() end
                if self.header then self.header:Hide() end
                if self.tablePanel then self.tablePanel:Hide() end
                if self.scroll then self.scroll:Hide() end
                if self.clearBtn then self.clearBtn:Hide() end
                if self.exportBtn then self.exportBtn:Hide() end
                if self.resultText then self.resultText:Hide() end
                if self.totalText then self.totalText:Hide() end
                if self.charactersBtn then self.charactersBtn:Hide() end
                for _, row in ipairs(self.rows or {}) do row:Hide() end
                self.currentExportText = ""
                if _G.AkcQOL_DetachMatrixFromMain then
                    _G.AkcQOL_DetachMatrixFromMain(self)
                end
                local sf = _G.AkcQOLSettingsFrame
                if sf then
                    sf:SetParent(self)
                    sf:SetScale(1)
                    sf:SetFrameStrata(self:GetFrameStrata())
                    sf:SetFrameLevel(self:GetFrameLevel() + 20)
                    sf:ClearAllPoints()

                    sf:SetPoint("TOPLEFT", self, "TOPLEFT", 78, -70)
                    sf:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -14, 40)

                    if sf.ownTitle then sf.ownTitle:Hide() end
                    if sf.ownClose then sf.ownClose:Hide() end
                    AkcQOL_SafeShowFrame(sf)
                end
                self:UpdateNav()
                return
            end

            if key == "matrix" then
                if self.searchFrame then self.searchFrame:Hide() end
                if self.filters then self.filters:Hide() end
                if self.chatTabs then self.chatTabs:Hide() end
                if self.chatPeople then self.chatPeople:Hide() end
                if self.logChars then self.logChars:Hide() end
                if self.header then self.header:Hide() end
                if self.tablePanel then self.tablePanel:Hide() end
                if self.scroll then self.scroll:Hide() end
                if self.clearBtn then self.clearBtn:Hide() end
                if self.exportBtn then self.exportBtn:Hide() end
                if self.resultText then self.resultText:Hide() end
                if self.totalText then self.totalText:Hide() end
                if self.charactersBtn then self.charactersBtn:Show() end
                for _, row in ipairs(self.rows or {}) do row:Hide() end
                self.currentExportText = ""
                if _G.AkcQOL_AttachMatrixToMain then
                    _G.AkcQOL_AttachMatrixToMain(self)
                end
                self:UpdateNav()
                return
            end

            if _G.AkcQOL_DetachMatrixFromMain then
                _G.AkcQOL_DetachMatrixFromMain(self)
            end
            if _G.AkcQOLMatrix_FilterMenu then
                AkcQOL_SafeHideFrame(_G.AkcQOLMatrix_FilterMenu)
            end
            if self.searchFrame then self.searchFrame:Show() end
            if self.header then self.header:Show() end
            if self.tablePanel then self.tablePanel:Show() end
            if self.scroll then self.scroll:Show() end
            if self.clearBtn then self.clearBtn:Show() end
            if self.exportBtn then self.exportBtn:Show() end
            if self.resultText then self.resultText:Show() end
            if self.totalText then self.totalText:Show() end
            if self.charactersBtn then self.charactersBtn:Hide() end

            local isCharacterLog = AKCQOL_CHARACTER_LOG_TYPES[key] and true or false
            self.filters:SetShown(key ~= "chat" and key ~= "lua")
            self.allCharsCheck:SetShown(not isCharacterLog)
            self.todayCheck:ClearAllPoints()
            if isCharacterLog then
                self.todayCheck:SetPoint("LEFT", self.filters, "LEFT", 0, 0)
            else
                self.todayCheck:SetPoint("LEFT", self.allCharsCheck, "RIGHT", 18, 0)
            end
            self.chatTabs:SetShown(key == "chat")
            self.chatPeople:SetShown(key == "chat")
            self.logChars:SetShown(isCharacterLog)
            self.header:ClearAllPoints()
            LayoutLogHeaderColumns(self, isCharacterLog)
            if key == "chat" then
                self.header:SetPoint("TOPLEFT", self, "TOPLEFT", self.chatTableLeft or 282, -126)
                self.header:SetPoint("TOPRIGHT", self, "TOPRIGHT", -24, -126)
                self.dateHead:SetText("|cFFE5E7EBDate|r")
                self.charHead:SetText("|cFFE5E7EBAuthor|r")
                self.entryHead:SetText("|cFFE5E7EBMessage|r")
                self:UpdateChatTabs()
                self:UpdateChatPeople()
            elseif isCharacterLog then
                self.header:SetPoint("TOPLEFT", self, "TOPLEFT", self.logTableLeft or 282, -96)
                self.header:SetPoint("TOPRIGHT", self, "TOPRIGHT", -24, -96)
                self.dateHead:SetText("|cFFE5E7EBDate|r")
                self.entryHead:SetText("|cFFE5E7EBEntry|r")
                self:UpdateLogCharacters()
            else
                self.header:SetPoint("TOPLEFT", self, "TOPLEFT", 86, -112)
                self.header:SetPoint("TOPRIGHT", self, "TOPRIGHT", -24, -112)
                self.dateHead:SetText("|cFFE5E7EBDate|r")
                self.charHead:SetText(key == "lua" and "|cFFE5E7EBAddOn|r" or "|cFFE5E7EBCharacter|r")
                self.entryHead:SetText(key == "lua" and "|cFFE5E7EBError|r" or "|cFFE5E7EBEntry|r")
            end

            local rows, exportLines = self:BuildRows()
            for _, row in ipairs(self.rows) do row:Hide() end

            local rowHeight = 30
            local width = math.max(480, (self.scroll:GetWidth() or (self:GetWidth() - 126)))
            self.scrollChild:SetWidth(width)

            if #rows == 0 then
                local row = GetOrCreateRow(1)
                row.rowIndex = 1
                row.color = color
                row:ClearAllPoints()
                row:SetPoint("TOPLEFT", self.scrollChild, "TOPLEFT", 0, 0)
                row:SetPoint("RIGHT", self.scrollChild, "RIGHT", 0, 0)
                row:SetHeight(rowHeight)
                row.bg:SetVertexColor(0.014, 0.015, 0.012, 0.34)
                row.left:SetVertexColor(color[1], color[2], color[3], 0.8)
                row.date:SetText("-")
                LayoutLogRowColumns(row, isCharacterLog)
                row.char:SetText(isCharacterLog and "" or "-")
                row.body:SetText("|cFF8A8F98No entries.|r")
                row.rawText = nil
                row.rawTitle = nil
                AkcQOL_UpdateLogLinkHotspots(row, nil)
                row:Show()
                self.scrollChild:SetHeight(rowHeight + 8)
            else
                local yOff = 0
                for i, data in ipairs(rows) do
                    local row = GetOrCreateRow(i)
                    row.rowIndex = i
                    row.color = color
                    row:ClearAllPoints()
                    row:SetPoint("TOPLEFT", self.scrollChild, "TOPLEFT", 0, -yOff)
                    row:SetPoint("RIGHT", self.scrollChild, "RIGHT", 0, 0)
                    row.rawText = data.raw
                    row.rawTitle = title .. " Entry"

                    if key == "chat" and data.isWhisper then
                        local actualH = LayoutChatBubbleRow(row, data, width)
                        AkcQOL_UpdateLogLinkHotspots(row, data.bubbleText or data.bodyText or "")
                        row:Show()
                        yOff = yOff + actualH
                    else
                        row:SetHeight(rowHeight)
                        if i % 2 == 0 then
                            row.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                        else
                            row.bg:SetVertexColor(0.014, 0.015, 0.012, 0.34)
                        end
                        row.left:SetVertexColor(color[1], color[2], color[3], 0.8)
                        row.date:SetText(data.dateText or "-")
                        LayoutLogRowColumns(row, isCharacterLog)
                        row.char:SetText(isCharacterLog and "" or (data.charText or "-"))
                        row.body:SetText(data.bodyText or "")
                        AkcQOL_UpdateLogLinkHotspots(row, data.bodyText or "")
                        row:Show()
                        yOff = yOff + rowHeight
                    end
                end
                self.scrollChild:SetHeight(yOff + 8)
            end

            self.currentExportText = table.concat(exportLines, "\n\n")
            self.resultText:SetText(string.format(L["|cFFE5E7EBCurrent Results:|r %s"], AkcQOL_ColorText(color, #rows)))
            if key == "chat" then
                local channelInfo = AkcQOL_GetChatChannelInfo(self.activeChannel or "all")
                local person = self.activeChatPerson or "all"
                local personText = person == "all" and L["All people"] or person
                self.totalText:SetText(string.format(L["|cFFE5E7EBChannel:|r %s\n|cFFE5E7EBPerson:|r %s\n|cFFE5E7EBShowing:|r %s"],
                    AkcQOL_ColorText(channelInfo.color, channelInfo.label),
                    AkcQOL_ColorText(color, personText),
                    AkcQOL_ColorText(color, #rows)
                ))
            elseif isCharacterLog then
                local logChar = self.activeLogChar or "all"
                local charText = logChar == "all" and L["All characters"] or logChar
                self.totalText:SetText(string.format(L["|cFFE5E7EBActive:|r %s\n|cFFE5E7EBCharacter:|r %s\n|cFFE5E7EBShowing:|r %s"],
                    AkcQOL_ColorText(color, title),
                    AkcQOL_ColorText(color, charText),
                    AkcQOL_ColorText(color, #rows)
                ))
            else
                self.totalText:SetText(string.format(L["|cFFE5E7EBActive:|r %s\n|cFFE5E7EBShowing:|r %s"],
                    AkcQOL_ColorText(color, title),
                    AkcQOL_ColorText(color, #rows)
                ))
            end
            if key == "chat" or key == "mail" or key == "trade" or key == "loot" then
                AkcQOL_ScrollFrameToBottom(self.scroll)
            else
                self.scroll:SetVerticalScroll(0)
            end
            self:UpdateNav()
        end

        function f:SetActiveTab(key)
            self.activeTab = key or "matrix"
            if self.activeTab == "chat" and not self.activeChannel then
                self.activeChannel = "guild"
            end
            if self.activeTab == "chat" and not self.activeChatPerson then
                self.activeChatPerson = "all"
            end
            if AKCQOL_CHARACTER_LOG_TYPES[self.activeTab] and not self.activeLogChar then
                self.activeLogChar = "all"
            end
            self.searchBox:SetText("")
            self:Refresh()
        end

        searchBox:SetScript("OnTextChanged", function(_, userInput)

            if not userInput then return end
            if f.searchTimer then f.searchTimer:Cancel() end
            f.searchTimer = C_Timer.NewTimer(0.2, function()
                f.searchTimer = nil
                f:Refresh()
            end)
        end)
        searchBox:SetScript("OnEscapePressed", function(self)
            self:SetText("")
            self:ClearFocus()
            f:Refresh()
        end)
        searchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

        personSearchBox:SetScript("OnTextChanged", function()
            f:UpdateChatPeople()
        end)
        personSearchBox:SetScript("OnEscapePressed", function(self)
            self:SetText("")
            self:ClearFocus()
            f:UpdateChatPeople()
        end)
        personSearchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

        logCharSearchBox:SetScript("OnTextChanged", function()
            f:UpdateLogCharacters()
        end)
        logCharSearchBox:SetScript("OnEscapePressed", function(self)
            self:SetText("")
            self:ClearFocus()
            f:UpdateLogCharacters()
        end)
        logCharSearchBox:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

        f:SetScript("OnSizeChanged", function(self, w)
            self.scrollChild:SetWidth(math.max(480, w - 126))
            self:Refresh()
        end)
        f:SetScript("OnShow", function(self)
            self.akcqolSoftHidden = false
            self:SetAlpha(1)
            self:EnableMouse(true)
            self:Refresh()
        end)
        f:SetScript("OnHide", function(self)
            self.isScaleSizing = false
            if resizeGrip then resizeGrip:SetScript("OnUpdate", nil) end
            if _G.AkcQOL_DetachMatrixFromMain then
                _G.AkcQOL_DetachMatrixFromMain(self)
            end
            if _G.AkcQOLSettingsFrame then
                AkcQOL_SafeHideFrame(_G.AkcQOLSettingsFrame)
            end
            if _G.AkcQOLMatrix_FilterMenu then
                AkcQOL_SafeHideFrame(_G.AkcQOLMatrix_FilterMenu)
            end
        end)

        AKCQOL_LOGS_FRAME = f
    end

    for _, frame in pairs(WV_LOG_FRAMES) do
        AkcQOL_SafeHideFrame(frame)
    end
    AKCQOL_LOGS_FRAME:SetActiveTab(initialTab)
    AkcQOL_SafeShowFrame(AKCQOL_LOGS_FRAME)
end
_G.AkcQOL_ShowLogsWindow = AkcQOL_ShowLogsWindow


local MailLogFrame = CreateFrame("Frame")
MailLogFrame:RegisterEvent("MAIL_SHOW")
MailLogFrame:RegisterEvent("MAIL_INBOX_UPDATE")
MailLogFrame.pendingRead = false
MailLogFrame.seenMail = {}
MailLogFrame:SetScript("OnEvent", function(self, event)

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logMailTradeLoot == false then return end
    if event == "MAIL_SHOW" then
        local now = GetTime and GetTime() or 0
        if now - (self.lastOpenLog or -300) >= 300 then
            self.lastOpenLog = now
            AddLogEntry("mail", "Mailbox opened")
        end
        self.pendingRead = true
    elseif event == "MAIL_INBOX_UPDATE" and self.pendingRead then
        self.pendingRead = false
        local numItems = GetInboxNumItems() or 0
        if numItems > 0 then
            for i = 1, numItems do
                local _, _, sender, subject, money, _, daysLeft, qty = GetInboxHeaderInfo(i)
                if sender or subject then
                    local dedupKey = (sender or "?") .. "|" .. (subject or "") .. "|" .. tostring(money or 0) .. "|" .. tostring(qty or 0)
                    if not self.seenMail[dedupKey] then
                        self.seenMail[dedupKey] = true
                        local info = (sender or "Unknown") .. " | " .. (subject or "(no subject)")
                        if money and money > 0 then
                            info = info .. " | " .. GetCoinTextureString(money)
                        end
                        if qty and qty > 0 then
                            info = info .. " | Items: " .. qty

                            if GetInboxItemLink then
                                for ai = 1, ATTACHMENTS_MAX_RECEIVE or 16 do
                                    local link = GetInboxItemLink(i, ai)
                                    if type(link) == "string" then
                                        info = info .. " " .. link
                                    end
                                end
                            end
                        end
                        AddLogEntry("mail", info)
                    end
                end
            end
        end
    end
end)

hooksecurefunc("TakeInboxMoney", function(index)
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logMailTradeLoot == false then return end
    local _, _, sender, _, money = GetInboxHeaderInfo(index)
    if money and money > 0 then
        AddLogEntry("mail", "Took " .. GetCoinTextureString(money) .. " from " .. (sender or "?"))
    end
end)

hooksecurefunc("TakeInboxItem", function(index, attachmentIndex)
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logMailTradeLoot == false then return end
    local _, _, sender = GetInboxHeaderInfo(index)
    local name, itemID, texture, count = GetInboxItem(index, attachmentIndex)
    if name then

        local link = GetInboxItemLink and GetInboxItemLink(index, attachmentIndex)
        local display = (type(link) == "string" and link) or name
        local cnt = (count and count > 1) and (count .. "x ") or ""
        AddLogEntry("mail", "Took " .. cnt .. display .. " from " .. (sender or "?"))
    end
end)

if TakeInboxAttachments then
    hooksecurefunc("TakeInboxAttachments", function(index)
        if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logMailTradeLoot == false then return end
        local _, _, sender, _, money = GetInboxHeaderInfo(index)
        local parts = {}
        if money and money > 0 then
            parts[#parts + 1] = GetCoinTextureString(money)
        end
        for ai = 1, ATTACHMENTS_MAX_RECEIVE or 16 do
            local name, _, _, count = GetInboxItem(index, ai)
            if name then
                local link = GetInboxItemLink and GetInboxItemLink(index, ai)
                local display = (type(link) == "string" and link) or name
                local cnt = (count and count > 1) and (count .. "x ") or ""
                parts[#parts + 1] = cnt .. display
            end
        end
        if #parts > 0 then
            AddLogEntry("mail", "Took all (" .. table.concat(parts, ", ") .. ") from " .. (sender or "?"))
        end
    end)
end

local TradeLogFrame = CreateFrame("Frame")
TradeLogFrame:RegisterEvent("TRADE_SHOW")
TradeLogFrame:RegisterEvent("TRADE_ACCEPT_UPDATE")
TradeLogFrame:RegisterEvent("UI_INFO_MESSAGE")
TradeLogFrame.tradingWith = nil
TradeLogFrame.pendingTrade = nil
TradeLogFrame:SetScript("OnEvent", function(self, event, arg1, arg2)

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logMailTradeLoot == false then return end
    if event == "TRADE_SHOW" then
        local target = UnitName("NPC") or TradeFrameRecipientNameText and TradeFrameRecipientNameText:GetText() or "Unknown"
        self.tradingWith = target
        self.pendingTrade = nil
        AddLogEntry("trade", "Trade opened with " .. target)
    elseif event == "TRADE_ACCEPT_UPDATE" then

        local given = {}
        local received = {}
        for i = 1, 6 do
            local link = GetTradePlayerItemLink(i)
            if link then
                local _, _, numItems = GetTradePlayerItemInfo(i)
                if numItems and numItems > 1 then
                    table.insert(given, link .. " x" .. numItems)
                else
                    table.insert(given, link)
                end
            end
            link = GetTradeTargetItemLink(i)
            if link then
                local _, _, numItems = GetTradeTargetItemInfo(i)
                if numItems and numItems > 1 then
                    table.insert(received, link .. " x" .. numItems)
                else
                    table.insert(received, link)
                end
            end
        end
        self.pendingTrade = {
            given = given,
            received = received,
            givenMoney = GetPlayerTradeMoney() or 0,
            receivedMoney = GetTargetTradeMoney() or 0,
        }
    elseif event == "UI_INFO_MESSAGE" then
        local msg = arg2 or ""

        local isComplete = (ERR_TRADE_COMPLETE and msg == ERR_TRADE_COMPLETE)
            or (msg:find("[Tt]rade") and msg:find("complete")) and true or false
        local isTradeMsg = isComplete
            or (ERR_TRADE_CANCELLED and msg == ERR_TRADE_CANCELLED)
            or msg:find("[Tt]rade") and true or false
        if isTradeMsg then
            if isComplete and self.pendingTrade then
                local pt = self.pendingTrade

                local recvParts = {}
                for _, item in ipairs(pt.received) do
                    table.insert(recvParts, item)
                end
                if pt.receivedMoney > 0 then
                    table.insert(recvParts, GetCoinTextureString(pt.receivedMoney))
                end

                local gaveParts = {}
                for _, item in ipairs(pt.given) do
                    table.insert(gaveParts, item)
                end
                if pt.givenMoney > 0 then
                    table.insert(gaveParts, GetCoinTextureString(pt.givenMoney))
                end

                if #recvParts > 0 then
                    AddLogEntry("trade", "  Received: " .. table.concat(recvParts, ", "))
                end
                if #gaveParts > 0 then
                    AddLogEntry("trade", "  Gave: " .. table.concat(gaveParts, ", "))
                end
                self.pendingTrade = nil
            end
            AddLogEntry("trade", msg)
        end
    end
end)

AKCQOL_RECENT_LOOT_LOGS = AKCQOL_RECENT_LOOT_LOGS or {}

function AkcQOL_EscapePattern(value)
    value = AkcQOL_EarlyCleanString(value) or ""
    return value:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
end

do

    local selfLootPatterns
    local function BuildSelfLootPatterns()
        selfLootPatterns = {}
        local sources = {
            "LOOT_ITEM_SELF", "LOOT_ITEM_SELF_MULTIPLE",
            "LOOT_ITEM_PUSHED_SELF", "LOOT_ITEM_PUSHED_SELF_MULTIPLE",
            "LOOT_ITEM_CREATED_SELF", "LOOT_ITEM_CREATED_SELF_MULTIPLE",
            "LOOT_ITEM_BONUS_ROLL_SELF", "LOOT_ROLL_YOU_WON",
            "YOU_LOOT_MONEY", "LOOT_MONEY_SPLIT",
        }
        for _, gname in ipairs(sources) do
            local fmt = _G[gname]
            if type(fmt) == "string" and fmt ~= "" then

                fmt = fmt:gsub("%%%d+%$s", "%%s"):gsub("%%%d+%$d", "%%d")
                local pat = "^" .. AkcQOL_EscapePattern(fmt):gsub("%%%%s", "(.+)"):gsub("%%%%d", "(%%d+)") .. "$"
                selfLootPatterns[#selfLootPatterns + 1] = pat
            end
        end
    end

    function AkcQOL_IsSelfLootMessage(msg)
        local clean = AkcQOL_EarlyCleanString(msg)
        if not clean or clean == "" then return false end

        if not selfLootPatterns then BuildSelfLootPatterns() end
        for _, pat in ipairs(selfLootPatterns) do
            if clean:match(pat) then return true end
        end

        if clean:sub(1, 11) == "You receive" or clean:sub(1, 7) == "You won" or clean:sub(1, 10) == "You create" then
            return true
        end

        local name = UnitName and UnitName("player")
        if name and name ~= "" then
            local escapedName = AkcQOL_EscapePattern(name)
            if clean:match("^" .. escapedName .. "%s+receives") or clean:match("^" .. escapedName .. "%s+won") then
                return true
            end
        end

        return false
    end
end

function AddLootLogEntry(text)
    text = AkcQOL_EarlyCleanString(text)
    if not text or text == "" then return end

    local now = (GetTime and GetTime()) or 0
    local recent = AKCQOL_RECENT_LOOT_LOGS[text]
    if recent and (now - recent) < 1.5 then return end

    for k, t in pairs(AKCQOL_RECENT_LOOT_LOGS) do
        if (now - t) > 5 then AKCQOL_RECENT_LOOT_LOGS[k] = nil end
    end
    AKCQOL_RECENT_LOOT_LOGS[text] = now

    AddLogEntry("loot", text)
end

local LootLogFrame = CreateFrame("Frame")
LootLogFrame:RegisterEvent("LOOT_OPENED")
LootLogFrame:RegisterEvent("CHAT_MSG_LOOT")
LootLogFrame:SetScript("OnEvent", function(self, event, ...)

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logMailTradeLoot == false then return end
    if event == "LOOT_OPENED" then
        local numLoot = GetNumLootItems() or 0
        local logTrash = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logLootTrash
        if numLoot > 0 then
            for i = 1, numLoot do
                local lootIcon, lootName, lootQuantity, currencyID, lootQuality = GetLootSlotInfo(i)

                if lootName and (lootQuality ~= 0 or logTrash) then
                    local entry = lootName
                    if lootQuantity and lootQuantity > 1 then
                        entry = entry .. " x" .. lootQuantity
                    end
                    AddLootLogEntry(entry)
                end
            end
        end
    elseif event == "CHAT_MSG_LOOT" then
        local msg = ...
        if msg and AkcQOL_IsSelfLootMessage(msg) then

            local logTrash = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.logLootTrash
            if logTrash or not string.find(msg, "9d9d9d", 1, true) then
                AddLootLogEntry(msg)
            end
        end
    end
end)

-- Midnight Season 2 (12.1). Bump SEASON.key when a new season lands so the
-- per-character season counters (sparks, keystones, top keys) start fresh.
local SEASON = {
    key             = "MN2",
    sparkItem       = 274476,            -- Spark of Tides
    sparkTracker    = 3509,              -- Tidal Spark Dust: quantity/maxQuantity = season sparks
    sparkQuests     = { 98172, 96995 },  -- Trailing Xal'atath, Turn Back the Surge
    sparkStart      = 1787065200,        -- 2026-08-18 15:00 UTC (fallback only)
    delveBountyQuest = 86371,
    nemesisNpc      = 265500,            -- Azta'rec (Venomfall Deeps)
    nemesisMatch    = "azta",
    catalyst        = 3465,              -- Venomblight Manaflux
    crestHero       = 3445,
    crestMyth       = 3446,
    crestHeroAlt    = 3440,              -- shadow ids; used only if the primary is undiscovered
    crestMythAlt    = 3441,
}

local function GetDelveBountyCompleted()
    if not C_QuestLog or not C_QuestLog.IsQuestFlaggedCompleted then return false end
    return C_QuestLog.IsQuestFlaggedCompleted(SEASON.delveBountyQuest)
end

local function MarkNemesisDone()
    if not AkcQOLDB then return end
    local name, realm = UnitFullName("player")
    local charName = (realm and realm ~= "") and (name .. "-" .. realm) or (name or "Unknown")
    if not AkcQOLDB[charName] then return end
    if AkcQOLDB[charName].nemesisCompleted then return end
    AkcQOLDB[charName].nemesisCompleted = true
    print(L["|cff8c5cffAkc|r|cffffffffQOL|r: Nemesis kill tracked."])
end

local NemesisEventFrame = CreateFrame("Frame")
NemesisEventFrame:RegisterEvent("BOSS_KILL")
NemesisEventFrame:RegisterEvent("ENCOUNTER_END")
NemesisEventFrame:RegisterEvent("CHAT_MSG_LOOT")
NemesisEventFrame:SetScript("OnEvent", function(_, event, ...)
    if not AkcQOLDB then return end

    if event == "BOSS_KILL" then
        local _, rawName = ...
        local bossName = CleanStr(rawName, nil)
        if bossName and bossName:lower():find(SEASON.nemesisMatch, 1, true) then
            MarkNemesisDone()
        end

    elseif event == "ENCOUNTER_END" then
        local _, _, _, _, success = ...
        if success == 1 then
            for i = 1, 5 do
                local bossUnit = "boss" .. i
                if UnitExists(bossUnit) then
                    local ok2, guid = pcall(UnitGUID, bossUnit)
                    if ok2 and guid then
                        local ok3, _, _, _, _, _, npcStr = pcall(strsplit, "-", guid)
                        if ok3 and tonumber(npcStr) == SEASON.nemesisNpc then
                            MarkNemesisDone()
                            return
                        end
                    end
                end
            end
        end

    elseif event == "CHAT_MSG_LOOT" then

        local lootMsg = CleanStr((...), nil)
        if lootMsg and lootMsg:lower():find(SEASON.nemesisMatch, 1, true) then
            MarkNemesisDone()
        end
    end
end)

SLASH_AKCQOLNEMESIS1 = "/akcnm"
SlashCmdList["AKCQOLNEMESIS"] = function(msg)
    if not AkcQOLDB then return end
    local name, realm = UnitFullName("player")
    local charName = (realm and realm ~= "") and (name .. "-" .. realm) or (name or "Unknown")
    if not AkcQOLDB[charName] then return end
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "done" then
        AkcQOLDB[charName].nemesisCompleted = true
        print(string.format(L["|cff8c5cffAkc|r|cffffffffQOL|r: Nemesis marked as |cFF00FF00Done|r for %s"], charName))
    elseif msg == "reset" then
        AkcQOLDB[charName].nemesisCompleted = false
        print(string.format(L["|cff8c5cffAkc|r|cffffffffQOL|r: Nemesis marked as |cFFFF4444Not Done|r for %s"], charName))
    else
        local status = AkcQOLDB[charName].nemesisCompleted and ("|cFF00FF00" .. L["Done"] .. "|r") or ("|cFFFF4444" .. L["Not Done"] .. "|r")
        print(L["|cff8c5cffAkc|r|cffffffffQOL|r: Nemesis status: "] .. status)
        print(L["  |cFF888888/akcnm done|r  - mark as completed"])
        print(L["  |cFF888888/akcnm reset|r - mark as not done"])
    end
end

local function GetWeeklySparkCompleted()
    if not C_QuestLog or not C_QuestLog.IsQuestFlaggedCompleted then return false end
    for _, questID in ipairs(SEASON.sparkQuests) do
        if C_QuestLog.IsQuestFlaggedCompleted(questID) then
            return true
        end
    end
    return false
end

local function GetGlobalSparkCap()
    local cap
    if C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo then
        local ok, ci = pcall(C_CurrencyInfo.GetCurrencyInfo, SEASON.sparkTracker)
        local mq = ok and ci and tonumber(ci.maxQuantity)
        if mq and mq > 0 then cap = mq end
    end
    if not cap then
        local now = GetServerTime and GetServerTime() or time()
        local weeksSinceStart = math.floor((now - SEASON.sparkStart) / (7 * 24 * 3600))
        cap = math.max(1, weeksSinceStart)
    end

    if AkcQOLDB then
        for k, v in pairs(AkcQOLDB) do
            if k ~= "version" and k ~= "hiddenChars" and k ~= "global" and type(v) == "table" then
                local c = tonumber(v.sparkTotalEarned or v.sparkCount or 0) or 0
                if c > cap then cap = c end
            end
        end
    end
    return cap
end

-- Prey hunts: read from the Great Vault activity list (the "AlsoReceive"
-- row carries hunt progress in Midnight). No progress data -> nil.
local function GetHuntProgress()
    if C_WeeklyRewards and C_WeeklyRewards.GetActivities then
        local ok, activities = pcall(C_WeeklyRewards.GetActivities)
        if ok and activities then
            for _, act in ipairs(activities) do
                if act.type == 4 then
                    local completed = tonumber(act.progress) or 0
                    local threshold = tonumber(act.threshold) or 15
                    return math.min(completed, threshold), threshold
                end
            end
        end
    end
    return nil
end

-- One-time reset of season-scoped counters when the season key changes.
local function CheckSeasonRollover()
    if not AkcQOLDB or not AkcQOLDB.global then return end
    if AkcQOLDB.global.seasonKey == SEASON.key then return end
    for k, data in pairs(AkcQOLDB) do
        if type(k) == "string" and k:find("-", 1, true) and type(data) == "table" then
            data.sparkCount, data.sparkTotalEarned = 0, 0
            data.keystoneLevel, data.keystoneDungeon = 0, nil
            data.topKeys = {}
            data.huntProgress = nil
            data.thisWeek = nil
        end
    end
    AkcQOLDB.global.seasonKey = SEASON.key
end

local function CheckWeeklyReset()
    if not AkcQOLDB then return end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end

    local nextReset = C_DateAndTime and C_DateAndTime.GetSecondsUntilWeeklyReset and C_DateAndTime.GetSecondsUntilWeeklyReset()
    if not nextReset or nextReset <= 0 then
        return
    end

    local currentTime = GetServerTime()
    local thisWeekReset = currentTime + nextReset
    local lastReset = AkcQOLDB.global.lastReset

    if lastReset and lastReset < currentTime then
        print(L["|cff8c5cffAkc|r|cffffffffQOL|r: New weekly reset detected. Clearing weekly Matrix data..."])
        for charName, data in pairs(AkcQOLDB) do
            if type(data) == "table" and data.raids then
                data.raids = {}
                if type(data.dungeons) == "table" then
                    for _, dungeonData in pairs(data.dungeons) do
                        if type(dungeonData) == "table" then
                            dungeonData.mplus = 0
                            dungeonData.m0Progress = "0/0"
                            dungeonData.isComplete = false
                        end
                    end
                end
                data.topKeys = {}
                data.sparkQuestCompleted = false
                data.delveBountyCompleted = false
                data.nemesisCompleted = false
                data.huntProgress = nil
                data.cofferShardsWeekly = 0
                data.thisWeek = nil
            end
        end
    end

    AkcQOLDB.global.lastReset = thisWeekReset
end

local DBFrame = CreateFrame("Frame")
DBFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
DBFrame:RegisterEvent("PLAYER_LOGOUT")
DBFrame:RegisterEvent("QUEST_LOG_UPDATE")
DBFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")

-- Meslek haftalik bilgi-puani questleri: skillLineID -> quest bayraklari
-- (limit-1 listelerde herhangi biri tamamlandiysa o hafta yapilmis sayilir).
local PROF_WEEKLY_QUESTS = {
    [171] = { 93690 },
    [164] = { 93691 },
    [333] = { 93697, 93698, 93699 },
    [202] = { 93692 },
    [182] = { 93700, 93701, 93702, 93703, 93704 },
    [773] = { 93693 },
    [755] = { 93694 },
    [165] = { 93695 },
    [186] = { 93705, 93706, 93707, 93708, 93709 },
    [393] = { 93710, 93711, 93712, 93713, 93714 },
    [197] = { 93696 },
}

local function SaveCurrentCharacterData()
    if not AkcQOLDB then
        AkcQOLDB = { hiddenChars = {}, global = { autoSell = true, autoRepair = true, fastLoot = false, autoInsertKeystone = true, showOrb = false, autoCinematic = true, showRaidProgress = false, showMinimap = false, showTalentHelper = false, showItemLevel = false, showHUD = false } }
    end

    CheckSeasonRollover()
    CheckWeeklyReset()

    if not AkcQOLDB.hiddenChars then AkcQOLDB.hiddenChars = {} end

    if AkcQOLDB.inspectCache then
        local cutoff = time() - (7 * 86400)
        for k, v in pairs(AkcQOLDB.inspectCache) do
            if not v.time or v.time < cutoff then
                AkcQOLDB.inspectCache[k] = nil
            end
        end
    end
    if not AkcQOLDB.global then AkcQOLDB.global = { autoSell = true, autoRepair = true, fastLoot = false, autoInsertKeystone = true, showOrb = false, autoCinematic = true } end

    if AkcQOLDB.global.autoLoot ~= nil then
        if AkcQOLDB.global.fastLoot == nil then AkcQOLDB.global.fastLoot = AkcQOLDB.global.autoLoot end
        AkcQOLDB.global.autoLoot = nil
    end

    if AkcQOLDB.global.showOrb == nil then AkcQOLDB.global.showOrb = false end
    if AkcQOLDB.global.autoCinematic == nil then AkcQOLDB.global.autoCinematic = false end
    if AkcQOLDB.global.showRaidProgress == nil then AkcQOLDB.global.showRaidProgress = false end
    if AkcQOLDB.global.showItemLevel == nil then AkcQOLDB.global.showItemLevel = false end
    if AkcQOLDB.global.fastLoot == nil then AkcQOLDB.global.fastLoot = false end
    if AkcQOLDB.global.autoInsertKeystone == nil then AkcQOLDB.global.autoInsertKeystone = false end
    if _G.AkcQOL_ApplyFastLoot then _G.AkcQOL_ApplyFastLoot() end

    local name, realm = UnitFullName("player")
    local charName = (realm and realm ~= "") and (name .. "-" .. realm) or name
    local _, classFileName = UnitClass("player")
    local classColor = RAID_CLASS_COLORS[classFileName] and RAID_CLASS_COLORS[classFileName].colorStr or "ffffffff"

    if name and (realm and realm ~= "") and AkcQOLDB[name] and type(AkcQOLDB[name]) == "table" then
        local old = AkcQOLDB[name]
        if not AkcQOLDB[charName] then
            AkcQOLDB[charName] = { color = classColor, raids = {}, dungeons = {}, topKeys = {} }
        end
        local cur = AkcQOLDB[charName]
        if old.raids and next(old.raids) then
            for k, v in pairs(old.raids) do cur.raids[k] = v end
        end
        if old.dungeons and next(old.dungeons) then
            for k, v in pairs(old.dungeons) do
                if not cur.dungeons[k] or (type(v.mplus) == "number" and (not cur.dungeons[k].mplus or v.mplus > cur.dungeons[k].mplus)) then
                    cur.dungeons[k] = v
                end
            end
        end
        if old.topKeys and #old.topKeys > 0 and (#(cur.topKeys or {}) == 0 or #old.topKeys > #(cur.topKeys or {})) then
            cur.topKeys = old.topKeys
        end
        AkcQOLDB[name] = nil
    end

    if not AkcQOLDB[charName] then
        AkcQOLDB[charName] = { color = classColor, raids = {}, dungeons = {}, topKeys = {} }
    end
    if not AkcQOLDB[charName].dungeons then AkcQOLDB[charName].dungeons = {} end
    if not AkcQOLDB[charName].raids then AkcQOLDB[charName].raids = {} end
    if not AkcQOLDB[charName].topKeys then AkcQOLDB[charName].topKeys = {} end
    AkcQOLDB[charName].color = classColor
    AkcQOLDB[charName].level = UnitLevel("player")
    local _, equippedILvl = GetAverageItemLevel()
    AkcQOLDB[charName].ilvl = tonumber(string.format("%.2f", equippedILvl or 0))
    AkcQOLDB[charName].rating = C_ChallengeMode.GetOverallDungeonScore() or 0

    local sparkDone = GetWeeklySparkCompleted()
    AkcQOLDB[charName].sparkQuestCompleted = sparkDone

    AkcQOLDB[charName].delveBountyCompleted = GetDelveBountyCompleted()

    local sparkNow = GetItemCount(SEASON.sparkItem, true) or 0
    local prevCount = AkcQOLDB[charName].sparkCount or 0
    local totalEarned = AkcQOLDB[charName].sparkTotalEarned or prevCount

    if sparkNow > prevCount then
        totalEarned = totalEarned + (sparkNow - prevCount)
    end

    if totalEarned < sparkNow then totalEarned = sparkNow end
    AkcQOLDB[charName].sparkCount = sparkNow
    AkcQOLDB[charName].sparkTotalEarned = totalEarned

    local huntFulfilled, huntRequired = GetHuntProgress()
    AkcQOLDB[charName].huntProgress = huntFulfilled and string.format("%d/%d", huntFulfilled, huntRequired) or nil

    pcall(function()
        local info = C_CurrencyInfo.GetCurrencyInfo(3310)
        if info then
            AkcQOLDB[charName].cofferShards = info.quantity or 0
            AkcQOLDB[charName].cofferShardsMax = info.maxQuantity or 600
            AkcQOLDB[charName].cofferShardsWeekly = info.totalEarned or 0

            if info.quantityEarnedThisWeek ~= nil then
                AkcQOLDB[charName].cofferShardsWeekly = info.quantityEarnedThisWeek
            end
            if info.maxWeeklyQuantity and info.maxWeeklyQuantity > 0 then
                AkcQOLDB[charName].cofferShardsWeeklyCap = info.maxWeeklyQuantity
            else
                AkcQOLDB[charName].cofferShardsWeeklyCap = 600
            end
        end
    end)

    pcall(function()
        local keyInfo = C_CurrencyInfo.GetCurrencyInfo(3028)
        if keyInfo then
            AkcQOLDB[charName].restoredCofferKeys = keyInfo.quantity or 0
        end
    end)

    local KEYSTONE_MAP_NAMES = {
        [239] = "Seat of the Triumvirate",
        [161] = "Skyreach",
        [560] = "Maisara Caverns",
        [557] = "Windrunner Spire",
        [556] = "Pit of Saron",
        [402] = "Algeth'ar Academy",
        [558] = "Magisters' Terrace",
        [559] = "Nexus-Point Xenas",
    }
    local function SaveKeystoneInfo()
        pcall(function()
            local mapID = C_MythicPlus.GetOwnedKeystoneChallengeMapID()
            if mapID then
                local level = C_MythicPlus.GetOwnedKeystoneLevel()

                local mapName = C_ChallengeMode.GetMapUIInfo(mapID)

                if not mapName or mapName == "" then
                    mapName = KEYSTONE_MAP_NAMES[mapID]
                end

                if not mapName or mapName == "" then
                    for bag = 0, 4 do
                        for slot = 1, C_Container.GetContainerNumSlots(bag) do
                            local info = C_Container.GetContainerItemInfo(bag, slot)
                            if info and info.itemName then
                                local dn = info.itemName:match("^Keystone: (.+)$")
                                    or info.itemName:match("^Anahtar Ta")
                                if dn then mapName = dn break end
                            end
                        end
                        if mapName and mapName ~= "" then break end
                    end
                end
                AkcQOLDB[charName].keystoneLevel = level or 0
                AkcQOLDB[charName].keystoneDungeon = mapName or ("Map" .. mapID)
                AkcQOLDB[charName].keystoneMapID = mapID
            else
                AkcQOLDB[charName].keystoneLevel = 0
                AkcQOLDB[charName].keystoneDungeon = nil
                AkcQOLDB[charName].keystoneMapID = nil
            end
        end)
    end
    SaveKeystoneInfo()
    C_Timer.After(3, SaveKeystoneInfo)
    C_Timer.After(8, SaveKeystoneInfo)
    C_Timer.After(15, SaveKeystoneInfo)

    local DUNGEON_MAP_IDS = {
        ["Algeth'ar Academy"] = 402,
        ["Magisters' Terrace"] = 558,
        ["Maisara Caverns"] = 560,
        ["Nexus-Point Xenas"] = 559,
        ["Pit of Saron"] = 556,
        ["Seat of the Triumvirate"] = 239,
        ["Skyreach"] = 161,
        ["Windrunner Spire"] = 557,
    }
    local seasonDungeonIDs = {}
    local dungeonDisplayNames = {}
    local lockoutNameToMapID = {}
    for engName, dMapID in pairs(DUNGEON_MAP_IDS) do
        seasonDungeonIDs[dMapID] = true
        local locName
        if C_ChallengeMode and C_ChallengeMode.GetMapUIInfo then
            local ok, n = pcall(C_ChallengeMode.GetMapUIInfo, dMapID)
            if ok and type(n) == "string" and n ~= "" then locName = n end
        end
        dungeonDisplayNames[dMapID] = locName or engName
        lockoutNameToMapID[engName] = dMapID
        if locName then lockoutNameToMapID[locName] = dMapID end
    end

    local function SaveDungeonBestLevel(dMapID, level)
        if not dMapID or not seasonDungeonIDs[dMapID] or type(level) ~= "number" or level <= 0 then return end
        local d = AkcQOLDB[charName].dungeons[dMapID]
        if not d then return end
        if level > (d.mplusBest or 0) then
            d.mplusBest = level
        end
    end

    local function ReadBestLevelFromTables(...)
        local bestLevel = 0
        for i = 1, select("#", ...) do
            local info = select(i, ...)
            if type(info) == "table" then
                local level = info.level or info.bestRunLevel or info.keyLevel or info.mythicLevel or info.challengeLevel
                if type(level) == "number" and level > bestLevel then
                    bestLevel = level
                end
            end
        end
        return bestLevel
    end

    for dbKey, dbData in pairs(AkcQOLDB) do
        if dbKey ~= "version" and dbKey ~= "hiddenChars" and dbKey ~= "global"
            and type(dbData) == "table" and type(dbData.dungeons) == "table" then
            local legacyKeys
            for k in pairs(dbData.dungeons) do
                if type(k) == "string" then
                    legacyKeys = legacyKeys or {}
                    legacyKeys[#legacyKeys + 1] = k
                end
            end
            if legacyKeys then
                for _, k in ipairs(legacyKeys) do
                    local rec = dbData.dungeons[k]
                    local dMapID = DUNGEON_MAP_IDS[k]
                    if dMapID and type(rec) == "table" then
                        local cur = dbData.dungeons[dMapID]
                        if not cur or (rec.mplusBest or 0) > (cur.mplusBest or 0) then
                            dbData.dungeons[dMapID] = rec
                        end
                    end
                    dbData.dungeons[k] = nil
                end
            end
        end
    end

    for dMapID in pairs(seasonDungeonIDs) do
        if not AkcQOLDB[charName].dungeons[dMapID] then
            AkcQOLDB[charName].dungeons[dMapID] = { m0Progress = "0/0", isComplete = false, mplus = 0, mplusBest = 0 }
        end

        AkcQOLDB[charName].dungeons[dMapID].name = dungeonDisplayNames[dMapID]
    end

    for dMapID in pairs(AkcQOLDB[charName].dungeons) do
        if not seasonDungeonIDs[dMapID] then
            AkcQOLDB[charName].dungeons[dMapID] = nil
        end
    end

    for dMapID in pairs(seasonDungeonIDs) do
        if AkcQOLDB[charName].dungeons[dMapID] then
            AkcQOLDB[charName].dungeons[dMapID].m0Progress = "0/0"
            AkcQOLDB[charName].dungeons[dMapID].isComplete = false
        end
    end

    AkcQOLDB[charName].raids = {}

    local raidLockouts = {}
    for i = 1, GetNumSavedInstances() do
        local name, _, _, difficultyID, locked, _, _, isRaid, _, difficultyName, numEncounters, encounterProgress = GetSavedInstanceInfo(i)
        if locked then
            if isRaid then

                local dName = string.lower(difficultyName or "")
                local diffShort, diffOrder
                if difficultyID == 16 or string.find(dName, "mythic", 1, true) then
                    diffShort, diffOrder = "M", 4
                elseif difficultyID == 15 or string.find(dName, "heroic", 1, true) then
                    diffShort, diffOrder = "H", 3
                elseif difficultyID == 14 or string.find(dName, "normal", 1, true) then
                    diffShort, diffOrder = "N", 2
                elseif difficultyID == 17 or string.find(dName, "raid finder", 1, true) or string.find(dName, "looking for raid", 1, true) then
                    diffShort, diffOrder = "LFR", 1
                else
                    diffShort, diffOrder = "N", 2
                end
                if not raidLockouts[name] then raidLockouts[name] = {} end
                table.insert(raidLockouts[name], {
                    diff = diffShort,
                    order = diffOrder,
                    killed = encounterProgress or 0,
                    total = numEncounters or 0,
                })
            elseif difficultyID == 23 or difficultyName == "Mythic" then

                local dMapID = lockoutNameToMapID[name]
                if dMapID and AkcQOLDB[charName].dungeons[dMapID] then
                    AkcQOLDB[charName].dungeons[dMapID].m0Progress = string.format("%d/%d", encounterProgress or 0, numEncounters or 0)
                    AkcQOLDB[charName].dungeons[dMapID].isComplete = (encounterProgress == numEncounters and numEncounters > 0)
                end
            end
        end
    end

    for raidName, lockouts in pairs(raidLockouts) do
        local raidEntry = {}
        for _, info in ipairs(lockouts) do
            raidEntry[info.diff] = { killed = info.killed, total = info.total }
        end
        AkcQOLDB[charName].raids[raidName] = raidEntry
    end

    local runHistory = C_MythicPlus.GetRunHistory(false, true)
    if runHistory then
        table.sort(runHistory, function(a, b) return a.level > b.level end)
        for i, run in ipairs(runHistory) do
            local dMapID = run.mapChallengeModeID
            local rec = dMapID and AkcQOLDB[charName].dungeons[dMapID]
            if rec then
                if run.level > (rec.mplus or 0) then
                    rec.mplus = run.level
                end
                SaveDungeonBestLevel(dMapID, run.level)
            end
            if i <= 8 and dMapID then
                local mapName = dungeonDisplayNames[dMapID]
                if not mapName and C_ChallengeMode and C_ChallengeMode.GetMapUIInfo then
                    local ok, n = pcall(C_ChallengeMode.GetMapUIInfo, dMapID)
                    if ok and type(n) == "string" and n ~= "" then mapName = n end
                end
                if mapName then
                    local color = run.level >= 10 and "|cFFB794F6" or "|cff0070DD"
                    AkcQOLDB[charName].topKeys[i] = string.format("%s+%d|r %s", color, run.level, mapName)
                end
            end
        end
    end

    local allTimeHistory = C_MythicPlus.GetRunHistory(true, true)
    if allTimeHistory then
        for _, run in ipairs(allTimeHistory) do
            SaveDungeonBestLevel(run.mapChallengeModeID, run.level)
        end
    end

    if C_MythicPlus then
        for _, dMapID in pairs(DUNGEON_MAP_IDS) do
            if C_MythicPlus.GetSeasonBestForMap then
                local ok, a, b, c, d = pcall(C_MythicPlus.GetSeasonBestForMap, dMapID)
                if ok then
                    SaveDungeonBestLevel(dMapID, ReadBestLevelFromTables(a, b, c, d))
                end
            end
            if C_MythicPlus.GetMapScoreInfo then
                local ok, scoreInfo = pcall(C_MythicPlus.GetMapScoreInfo, dMapID)
                if ok and type(scoreInfo) == "table" then
                    SaveDungeonBestLevel(dMapID, scoreInfo.bestRunLevel or scoreInfo.level or 0)
                end
            end
        end
    end

    local toRemove = {}
    for key in pairs(AkcQOLDB) do
        if key ~= "version" and key ~= "hiddenChars" and key ~= "global" and type(key) == "string" and not key:find("-", 1, true) then
            for other in pairs(AkcQOLDB) do
                if other ~= key and type(other) == "string" and other:find("-", 1, true) and other:match("^" .. key:gsub("%-", "%%-") .. "%-") then
                    toRemove[key] = true
                    break
                end
            end
        end
    end
    for key in pairs(toRemove) do AkcQOLDB[key] = nil end

    -- This Week: Great Vault yuvalari + meslek haftaliklari (secret/hata guvenli)
    pcall(function()
        local ct = AkcQOLDB[charName]
        if not ct then return end
        local tw = { vault = {}, profs = {} }
        if C_WeeklyRewards and C_WeeklyRewards.GetActivities then
            local okA, acts = pcall(C_WeeklyRewards.GetActivities)
            if okA and type(acts) == "table" then
                for _, a in ipairs(acts) do
                    local okF, t, p, th = pcall(function()
                        return tonumber(a.type), tonumber(a.progress), tonumber(a.threshold)
                    end)
                    if okF and t and p and th and th > 0 then
                        local v = tw.vault[t]
                        if not v then
                            v = { slots = 0, filled = 0 }
                            tw.vault[t] = v
                        end
                        v.slots = v.slots + 1
                        if p >= th then v.filled = v.filled + 1 end
                    end
                end
            end
        end
        if GetProfessions and GetProfessionInfo and C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then
            local p1, p2 = GetProfessions()
            local function AddProf(pidx)
                if not pidx then return end
                local pname, _, _, _, _, _, skillLine = GetProfessionInfo(pidx)
                local quests = skillLine and PROF_WEEKLY_QUESTS[skillLine]
                if not quests then return end
                local done = false
                for _, q in ipairs(quests) do
                    local okQ, c = pcall(C_QuestLog.IsQuestFlaggedCompleted, q)
                    if okQ and c then done = true break end
                end
                tw.profs[#tw.profs + 1] = { name = pname, done = done }
            end
            AddProf(p1)
            AddProf(p2)
        end
        if C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo then
            -- Dawncrest'ler: sezonluk buyuyen cap (useTotalEarnedForMaxQty);
            -- golge ID'lere (3346/3348) DIKKAT - dogrulanmis oyuncu ID'leri kullaniliyor.
            local function Crest(id, altId)
                local okC, ci = pcall(C_CurrencyInfo.GetCurrencyInfo, id)
                if okC and ci and ci.discovered == false and altId then
                    local okA, alt = pcall(C_CurrencyInfo.GetCurrencyInfo, altId)
                    if okA and alt and alt.discovered then ci = alt end
                end
                if okC and ci then
                    local cap = tonumber(ci.maxQuantity) or 0
                    local earned = tonumber(ci.useTotalEarnedForMaxQty and ci.totalEarned or ci.quantity) or 0
                    if cap > 0 then return { earned = earned, cap = cap, name = ci.name } end
                end
                return nil
            end
            tw.crestHero = Crest(SEASON.crestHero, SEASON.crestHeroAlt)
            tw.crestMyth = Crest(SEASON.crestMyth, SEASON.crestMythAlt)
            local okK, kci = pcall(C_CurrencyInfo.GetCurrencyInfo, SEASON.catalyst)
            if okK and kci then
                tw.catalyst = { q = tonumber(kci.quantity) or 0, max = tonumber(kci.maxQuantity) or 8, name = kci.name }
            end
        end
        ct.thisWeek = tw
    end)

    if not AkcQOLDB.global.nemesisMigrated then
        for k, v in pairs(AkcQOLDB) do
            if type(v) == "table" and v.nemesisCompleted then
                v.nemesisCompleted = false
            end
        end
        AkcQOLDB.global.nemesisMigrated = true
    end
end

DBFrame:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGOUT" then
        SaveCurrentCharacterData()
        return
    end
    if event == "PLAYER_ENTERING_WORLD" then
        RequestRaidInfo()
        C_MythicPlus.RequestRewards()
        C_MythicPlus.RequestMapInfo()
        C_Timer.After(2, SaveCurrentCharacterData)
    elseif event == "QUEST_LOG_UPDATE" and WVTrackerFrame and WVTrackerFrame:IsShown() then
        C_Timer.After(0.5, function()
            SaveCurrentCharacterData()

            if _G.AkcQOLMatrix_Refresh then _G.AkcQOLMatrix_Refresh() end
        end)
    elseif event == "CHALLENGE_MODE_COMPLETED" then
        C_MythicPlus.RequestRewards()
        C_MythicPlus.RequestMapInfo()
        C_Timer.After(1, function()
            SaveCurrentCharacterData()
            if _G.AkcQOLMatrix_Refresh and WVTrackerFrame and WVTrackerFrame:IsShown() then _G.AkcQOLMatrix_Refresh() end
        end)
        C_Timer.After(5, function()
            SaveCurrentCharacterData()
            if _G.AkcQOLMatrix_Refresh and WVTrackerFrame and WVTrackerFrame:IsShown() then _G.AkcQOLMatrix_Refresh() end
        end)
    end
end)

local MATRIX_THEME = {

    frameBg = AkcQOL_Theme.colors.windowBg,
    titleBg = AkcQOL_Theme.colors.header,
    border = AkcQOL_Theme.colors.border,
    rowBase = {1, 1, 1, 0.018},
    rowAlt = AkcQOL_Theme.colors.rowBg,
    rowLine = {0, 0, 0, 0.20},
    headerBg = AkcQOL_Theme.colors.panelBg,
    text = {
        primary = "FFE5E7EB",
        muted = "FF8A8C90",
        faint = "FF565B66",
    },
    status = {
        done = { hex = "34D399", color = {0.204, 0.827, 0.600}, bgAlpha = 0.13 },
        warn = { hex = "F59E0B", color = {0.960, 0.620, 0.040}, bgAlpha = 0.13 },
        bad = { hex = "F87171", color = {0.973, 0.443, 0.443}, bgAlpha = 0.11 },
        neutral = { hex = "9CA3AF", color = {0.612, 0.639, 0.686}, bgAlpha = 0.08 },
        purple = { hex = "B794F6", color = {0.718, 0.580, 0.965}, bgAlpha = 0.13 },
        blue = { hex = "60A5FA", color = {0.376, 0.647, 0.980}, bgAlpha = 0.12 },
    },
    sections = {
        charInfo = { label = L["CHARACTER INFO"], hex = "F59E0B", color = {0.960, 0.620, 0.040} },
        raids = { label = L["RAIDS"], hex = "34D399", color = {0.204, 0.827, 0.600} },
        dungeons = { label = L["DUNGEONS"], hex = "60A5FA", color = {0.376, 0.647, 0.980} },
        vault = { label = L["WEEKLY VAULT (TOP 8 KEYS)"], hex = "B794F6", color = {0.718, 0.580, 0.965} },
        thisweek = { label = L["THIS WEEK"], hex = "8C5CFF", color = {0.549, 0.361, 1.0} },
    },
}

local function RebuildMatrixSectionLabels()
    MATRIX_THEME.sections.charInfo.label = L["CHARACTER INFO"]
    MATRIX_THEME.sections.raids.label = L["RAIDS"]
    MATRIX_THEME.sections.dungeons.label = L["DUNGEONS"]
    MATRIX_THEME.sections.vault.label = L["WEEKLY VAULT (TOP 8 KEYS)"]
    MATRIX_THEME.sections.thisweek.label = L["THIS WEEK"]
end
if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(RebuildMatrixSectionLabels) end

local TrackerFrame = CreateFrame("Frame", "WVTrackerFrame", UIParent)
TrackerFrame:SetSize(600, 450)
TrackerFrame:SetPoint("CENTER")
TrackerFrame:Hide()
TrackerFrame:SetMovable(true)
TrackerFrame:EnableMouse(true)
TrackerFrame:RegisterForDrag("LeftButton")
TrackerFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
TrackerFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
TrackerFrame:SetClampedToScreen(true)
TrackerFrame:SetFrameStrata("HIGH")
TrackerFrame:SetResizable(true)
if TrackerFrame.SetResizeBounds then
    TrackerFrame:SetResizeBounds(500, 200)
else
    TrackerFrame:SetMinResize(500, 200)
end

local TrackerBG = TrackerFrame:CreateTexture(nil, "BACKGROUND")
TrackerBG:SetAllPoints()
TrackerBG:SetTexture(WV_FLAT_TEX)
TrackerBG:SetVertexColor(MATRIX_THEME.frameBg[1], MATRIX_THEME.frameBg[2], MATRIX_THEME.frameBg[3], MATRIX_THEME.frameBg[4])

WV_CreateBorder(TrackerFrame, "TOPLEFT", "TOPLEFT", "TOPRIGHT", "TOPRIGHT", nil, 1)
WV_CreateBorder(TrackerFrame, "BOTTOMLEFT", "BOTTOMLEFT", "BOTTOMRIGHT", "BOTTOMRIGHT", nil, 1)
WV_CreateBorder(TrackerFrame, "TOPLEFT", "TOPLEFT", "BOTTOMLEFT", "BOTTOMLEFT", 1, nil)
WV_CreateBorder(TrackerFrame, "TOPRIGHT", "TOPRIGHT", "BOTTOMRIGHT", "BOTTOMRIGHT", 1, nil)

local TitleBar = CreateFrame("Frame", nil, TrackerFrame)
TitleBar:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 0, 0)
TitleBar:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", 0, 0)
TitleBar:SetHeight(30)
TitleBar:EnableMouse(true)
TitleBar:RegisterForDrag("LeftButton")
TitleBar:SetScript("OnDragStart", function() TrackerFrame:StartMoving() end)
TitleBar:SetScript("OnDragStop", function() TrackerFrame:StopMovingOrSizing() end)

local TitleBG = TitleBar:CreateTexture(nil, "BACKGROUND", nil, 1)
TitleBG:SetAllPoints()
TitleBG:SetTexture(WV_FLAT_TEX)
TitleBG:SetVertexColor(MATRIX_THEME.titleBg[1], MATRIX_THEME.titleBg[2], MATRIX_THEME.titleBg[3], MATRIX_THEME.titleBg[4])

AkcQOL_Theme.AddAccentLine(TitleBar)

local TitleTopHL = TitleBar:CreateTexture(nil, "ARTWORK")
TitleTopHL:Hide()
local TitleTopHL2 = TitleBar:CreateTexture(nil, "ARTWORK")
TitleTopHL2:Hide()

local titleSep = TrackerFrame:CreateTexture(nil, "ARTWORK")
titleSep:SetTexture(WV_FLAT_TEX)
titleSep:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))
titleSep:SetPoint("TOPLEFT", TitleBar, "BOTTOMLEFT", 0, 0)
titleSep:SetPoint("TOPRIGHT", TitleBar, "BOTTOMRIGHT", 0, 0)
titleSep:SetHeight(1)

local titleDropShadow = TrackerFrame:CreateTexture(nil, "ARTWORK")
titleDropShadow:Hide()

local TitleText = TitleBar:CreateFontString(nil, "OVERLAY")
AkcQOL_Theme.SetFont(TitleText, 14, "", true)
TitleText:SetPoint("LEFT", 10, 0)
TitleText:SetText(AkcQOL_Theme.Accent("AkcQOL") .. " |cFFE5E7EBMatrix|r")

local MatrixStatText = TitleBar:CreateFontString(nil, "OVERLAY")
AkcQOL_Theme.SetFont(MatrixStatText, 12, "")
MatrixStatText:SetPoint("LEFT", TitleText, "RIGHT", 30, 0)
MatrixStatText:SetJustifyH("LEFT")
MatrixStatText:SetWordWrap(false)
MatrixStatText:SetNonSpaceWrap(false)

function _G.AkcQOLMatrix_UpdateStatDisplay(specID)
    if not MatrixStatText then return end
    if not specID then
        local specIndex = GetSpecialization()
        specID = specIndex and GetSpecializationInfo(specIndex) or nil
    end
    if not specID or not AkcQOLStatPriority or not AkcQOLStatPriority[specID] then
        MatrixStatText:SetText("")
        return
    end
    local stats = AkcQOLStatPriority[specID]
    local _, className = UnitClass("player")
    local specName = ""
    local specNames = {
        [71]="Arms",[72]="Fury",[73]="Protection",
        [65]="Holy",[66]="Protection",[70]="Retribution",
        [253]="BM",[254]="MM",[255]="Survival",
        [259]="Assassin",[260]="Outlaw",[261]="Subtlety",
        [256]="Disc",[257]="Holy",[258]="Shadow",
        [250]="Blood",[251]="Frost",[252]="Unholy",
        [262]="Elemental",[263]="Enhance",[264]="Resto",
        [62]="Arcane",[63]="Fire",[64]="Frost",
        [265]="Affli",[266]="Demo",[267]="Destro",
        [268]="BrM",[269]="WW",[270]="MW",
        [102]="Balance",[103]="Feral",[104]="Guardian",[105]="Resto",
        [577]="Havoc",[581]="Veng",
        [1467]="Deva",[1468]="Pres",[1473]="Aug",
    }
    specName = specNames[specID] or "?"
    local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
    local cc = classColor and classColor.colorStr or "FFFFFFFF"
    local stText = "|c" .. cc .. specName .. "|r |cFF66FF66ST|r |cFFCCCCCC" .. stats.st .. "|r  |cFFFF6666AoE|r |cFFCCCCCC" .. stats.aoe .. "|r"
    MatrixStatText:SetText(stText)
end

local matrixStatFrame = CreateFrame("Frame")
matrixStatFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
matrixStatFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
matrixStatFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_SPECIALIZATION_CHANGED" and arg1 ~= "player" then return end
    C_Timer.After(0.5, function() _G.AkcQOLMatrix_UpdateStatDisplay() end)
end)

local AkcQOL_CloseMatrixPopups
local CloseBtn = CreateFrame("Button", nil, TitleBar)
CloseBtn:SetSize(24, 24)
CloseBtn:SetPoint("RIGHT", TitleBar, "RIGHT", -4, 0)
local CloseTxt = CloseBtn:CreateFontString(nil, "OVERLAY")
AkcQOL_Theme.SetFont(CloseTxt, 14, WV_FONT_FLAGS)
CloseTxt:SetAllPoints()
CloseTxt:SetText("|cFFFF4444X|r")
CloseBtn:SetScript("OnClick", function()
    if AkcQOL_CloseMatrixPopups then AkcQOL_CloseMatrixPopups() end
    AkcQOL_SafeHideFrame(TrackerFrame)
end)
CloseBtn:SetScript("OnEnter", function() CloseTxt:SetText("|cFFFF0000X|r") end)
CloseBtn:SetScript("OnLeave", function() CloseTxt:SetText("|cFFFF4444X|r") end)

local LogsBtn = CreateFrame("Button", nil, TitleBar)
LogsBtn:SetPoint("RIGHT", CloseBtn, "LEFT", -8, 0)
LogsBtn:SetSize(58, 20)
local LogsBtnBg = LogsBtn:CreateTexture(nil, "BACKGROUND")
LogsBtnBg:SetAllPoints()
LogsBtnBg:SetTexture(WV_FLAT_TEX)
LogsBtnBg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))
local LogsBtnInner = LogsBtn:CreateTexture(nil, "ARTWORK")
LogsBtnInner:SetPoint("TOPLEFT", 1, -1)
LogsBtnInner:SetPoint("BOTTOMRIGHT", -1, 1)
LogsBtnInner:SetTexture(WV_FLAT_TEX)
LogsBtnInner:SetGradient("VERTICAL",
    CreateColor(0.090, 0.098, 0.118, 1),
    CreateColor(0.130, 0.141, 0.165, 1))
local LogsBtnTopHL = LogsBtn:CreateTexture(nil, "OVERLAY")
LogsBtnTopHL:SetPoint("TOPLEFT", 1, -1)
LogsBtnTopHL:SetPoint("TOPRIGHT", -1, -1)
LogsBtnTopHL:SetHeight(1)
LogsBtnTopHL:SetTexture(WV_FLAT_TEX)
LogsBtnTopHL:SetVertexColor(1, 1, 1, 0.07)
local LogsBtnText = LogsBtn:CreateFontString(nil, "OVERLAY")
AkcQOL_Theme.SetFont(LogsBtnText, 11, "")
LogsBtnText:SetAllPoints()
LogsBtnText:SetText("|cFFE5E7EB" .. L["Logs"] .. "|r")
LogsBtn:SetScript("OnEnter", function()
    LogsBtnInner:SetGradient("VERTICAL",
        CreateColor(0.130, 0.141, 0.165, 1),
        CreateColor(0.180, 0.196, 0.227, 1))
    LogsBtnBg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.borderLight))
end)
LogsBtn:SetScript("OnLeave", function()
    LogsBtnInner:SetGradient("VERTICAL",
        CreateColor(0.090, 0.098, 0.118, 1),
        CreateColor(0.130, 0.141, 0.165, 1))
    LogsBtnBg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))
end)
LogsBtn:SetScript("OnClick", function()
    if AkcQOL_IsFrameOpen(AKCQOL_LOGS_FRAME) then
        AkcQOL_SafeHideFrame(AKCQOL_LOGS_FRAME)
    elseif AkcQOL_ShowLogsWindow then
        AkcQOL_ShowLogsWindow("mail")
    end
end)
LogsBtn:Hide()

local ErrorAlertBtn = CreateFrame("Button", nil, TitleBar)
ErrorAlertBtn:SetSize(48, 16)
ErrorAlertBtn:SetPoint("RIGHT", LogsBtn, "LEFT", -5, 0)
ErrorAlertBtn:SetFrameLevel(TitleBar:GetFrameLevel() + 20)
local ErrorAlertBg = ErrorAlertBtn:CreateTexture(nil, "BACKGROUND")
ErrorAlertBg:SetAllPoints()
ErrorAlertBg:SetTexture(WV_FLAT_TEX)
ErrorAlertBg:SetVertexColor(0.19, 0.055, 0.045, 0.98)
local ErrorAlertBorder = ErrorAlertBtn:CreateTexture(nil, "BORDER")
ErrorAlertBorder:SetPoint("TOPLEFT", -1, 1)
ErrorAlertBorder:SetPoint("BOTTOMRIGHT", 1, -1)
ErrorAlertBorder:SetTexture(WV_FLAT_TEX)
ErrorAlertBorder:SetVertexColor(1.0, 0.25, 0.2, 0.8)
local ErrorAlertText = ErrorAlertBtn:CreateFontString(nil, "OVERLAY")
AkcQOL_Theme.SetFont(ErrorAlertText, 10, "")
ErrorAlertText:SetAllPoints()
ErrorAlertText:SetText("|cFFFF7A7ALua|r")
ErrorAlertBtn:SetScript("OnClick", function()
    if AkcQOL_ShowLogsWindow then
        AkcQOL_ShowLogsWindow("lua")
    elseif _G.AkcQOL_ShowErrorLogWindow then
        _G.AkcQOL_ShowErrorLogWindow()
    end
end)
ErrorAlertBtn:SetScript("OnEnter", function(self)
    ErrorAlertBg:SetVertexColor(0.28, 0.075, 0.06, 0.98)
    ErrorAlertBorder:SetVertexColor(1.0, 0.35, 0.3, 1)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    GameTooltip:AddLine("|cFFFF7A7A" .. L["Lua Errors"] .. "|r")
    GameTooltip:AddLine(L["Click to open Logs > Lua."], 1, 1, 1)
    GameTooltip:Show()
end)
ErrorAlertBtn:SetScript("OnLeave", function()
    ErrorAlertBg:SetVertexColor(0.19, 0.055, 0.045, 0.98)
    ErrorAlertBorder:SetVertexColor(1.0, 0.25, 0.2, 0.8)
    GameTooltip:Hide()
end)
ErrorAlertBtn:Hide()

do
local Theme = AkcQOL_Theme
local SettingsFrame = CreateFrame("Frame", "AkcQOLSettingsFrame", TrackerFrame, "BackdropTemplate")

function SettingsFrame:ApplyBigSize()
    local sh = (UIParent and UIParent:GetHeight()) or 768
    self:SetSize(880, math.max(600, math.min(960, math.floor(sh * 0.86))))
end
SettingsFrame:ApplyBigSize()

SettingsFrame:SetPoint("CENTER")
SettingsFrame:SetFrameStrata("TOOLTIP")
SettingsFrame:EnableMouse(true)
SettingsFrame:SetClampedToScreen(true)
SettingsFrame:SetMovable(true)
Theme.ApplyWindow(SettingsFrame)
SettingsFrame:Hide()

tinsert(UISpecialFrames, "AkcQOLSettingsFrame")

SettingsFrame.titleBar = CreateFrame("Frame", nil, SettingsFrame)
SettingsFrame.titleBar:SetPoint("TOPLEFT", 1, -1)
SettingsFrame.titleBar:SetPoint("TOPRIGHT", -1, -1)
SettingsFrame.titleBar:SetHeight(32)
SettingsFrame.titleBar:EnableMouse(true)
SettingsFrame.titleBar:RegisterForDrag("LeftButton")
SettingsFrame.titleBar:SetScript("OnDragStart", function()
    if SettingsFrame:GetParent() == UIParent then SettingsFrame:StartMoving() end
end)
SettingsFrame.titleBar:SetScript("OnDragStop", function()
    SettingsFrame:StopMovingOrSizing()
end)
SettingsFrame.titleBarBg = SettingsFrame.titleBar:CreateTexture(nil, "BACKGROUND")
SettingsFrame.titleBarBg:SetAllPoints()
SettingsFrame.titleBarBg:SetTexture(WV_FLAT_TEX)
SettingsFrame.titleBarBg:SetVertexColor(Theme.rgba(Theme.colors.header))
Theme.AddAccentLine(SettingsFrame.titleBar)
SettingsFrame.titleBarSep = SettingsFrame.titleBar:CreateTexture(nil, "BORDER")
SettingsFrame.titleBarSep:SetTexture(WV_FLAT_TEX)
SettingsFrame.titleBarSep:SetVertexColor(Theme.rgba(Theme.colors.border))
SettingsFrame.titleBarSep:SetPoint("BOTTOMLEFT")
SettingsFrame.titleBarSep:SetPoint("BOTTOMRIGHT")
SettingsFrame.titleBarSep:SetHeight(1)

local SettingsTitle = SettingsFrame.titleBar:CreateFontString(nil, "OVERLAY")
Theme.SetFont(SettingsTitle, 14, "", true)
SettingsTitle:SetPoint("LEFT", 12, 0)
SettingsTitle:SetText(Theme.Accent("AkcQOL") .. " |cFFE5E7EB" .. L["Settings"] .. "|r")

local SettingsCloseBtn = CreateFrame("Button", nil, SettingsFrame.titleBar)
SettingsCloseBtn:SetSize(24, 24)
SettingsCloseBtn:SetPoint("RIGHT", -4, 0)
SettingsCloseBtn.txt = SettingsCloseBtn:CreateFontString(nil, "OVERLAY")
Theme.SetFont(SettingsCloseBtn.txt, 14, "")
SettingsCloseBtn.txt:SetAllPoints()
SettingsCloseBtn.txt:SetText("|cFFFF4444X|r")
SettingsCloseBtn:SetScript("OnEnter", function(self) self.txt:SetText("|cFFFF0000X|r") end)
SettingsCloseBtn:SetScript("OnLeave", function(self) self.txt:SetText("|cFFFF4444X|r") end)
SettingsCloseBtn:SetScript("OnClick", function()
    AkcQOL_SafeHideFrame(SettingsFrame)
end)

SettingsFrame.ownTitle = SettingsFrame.titleBar
SettingsFrame.ownClose = SettingsCloseBtn

local contentPane = CreateFrame("Frame", nil, SettingsFrame)
contentPane:SetPoint("TOPLEFT", SettingsFrame, "TOPLEFT", 10, -43)
contentPane:SetPoint("BOTTOMRIGHT", SettingsFrame, "BOTTOMRIGHT", -10, 10)

local activeSection = "auto"

do
    local function qoToggle(key, label, order, onSet, desc)
        return {
            name = label, desc = desc, type = "toggle", order = order, width = 1.4,
            get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global[key]) or false end,
            set = function(_, v)
                if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global[key] = v end
                if onSet then onSet(v) end
            end,
        }
    end

    local function qoToggleOn(key, label, order, onSet, desc)
        return {
            name = label, desc = desc, type = "toggle", order = order, width = 1.4,
            get = function() return not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global[key] == false) end,
            set = function(_, v)
                if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global[key] = v end
                if onSet then onSet(v) end
            end,
        }
    end

    local function ilvlToggle(key, label, order, desc)
        return {
            name = label, desc = desc, type = "toggle", order = order, width = 2,
            get = function()
                if not (AkcQOLDB and AkcQOLDB.global) then return true end
                if not AkcQOLDB.global.itemLevel then
                    AkcQOLDB.global.itemLevel = { arrow = true, gemEnchant = true, decimals = true }
                end
                return AkcQOLDB.global.itemLevel[key] ~= false
            end,
            set = function(_, v)
                if AkcQOLDB and AkcQOLDB.global then
                    AkcQOLDB.global.itemLevel = AkcQOLDB.global.itemLevel or { arrow = true, gemEnchant = true, decimals = true }
                    AkcQOLDB.global.itemLevel[key] = v
                end
                if _G.AkcQOLItemLevel_ApplyOptions then _G.AkcQOLItemLevel_ApplyOptions() end
            end,
        }
    end
    local function BuildQoLSettingsGroups()
    _G.AkcQOLQoLSettingsGroups = {
        qolAutomation = {
            name = L["Automation"], type = "group", order = -30,
            args = {
                autoSell           = qoToggle("autoSell", L["Auto Sell Grey Items"], 1, nil, L["Automatically sells all poor-quality (grey) items whenever you open a merchant, and prints the gold earned."]),
                autoRepair         = qoToggle("autoRepair", L["Auto Repair"], 2, nil, L["Automatically repairs your gear at any repair merchant — uses guild bank funds first if available, otherwise your own gold."]),
                fastLoot           = qoToggle("fastLoot", L["Fast Loot"], 3, function() if _G.AkcQOL_ApplyFastLoot then _G.AkcQOL_ApplyFastLoot() end end, L["Automatically loots every item the moment loot drops, so you never have to click to loot."]),
                autoInsertKeystone = qoToggle("autoInsertKeystone", L["Auto Insert M+ Keystone"], 4, function(v) if v and _G.AkcQOL_ScheduleAutoInsertKeystone then _G.AkcQOL_ScheduleAutoInsertKeystone() end end, L["Automatically places your Mythic+ keystone into the font when you open it."]),
                autoCinematic      = qoToggle("autoCinematic", L["Skip Cinematics"], 5, nil, L["Automatically skips in-game cinematics and movies as they begin."]),
                hideProfessionOutfit = qoToggle("hideProfessionOutfit", L["Hide Profession Outfit"], 6, function() if _G.AkcQOL_ApplyProfessionAppearance then _G.AkcQOL_ApplyProfessionAppearance() end end, L["Removes the cosmetic profession outfit the game puts on you at login and whenever you start a profession, so you never wear the profession transmog. Applies out of combat (a buff gained during combat is removed the moment you leave combat); fishing gear is removed when you stop fishing. Account-wide."]),
                announceInstanceReset = qoToggle("announceInstanceReset", L["Announce Instance Resets"], 8, nil, L["When you reset your instances, sends one \"[AkcQOL] Instances have been reset.\" line to your party/raid chat (throttled to once per 5 seconds). Off by default."]),
                addonProfilePanel = {
                    name = L["AddOn Profile Buttons"],
                    desc = L["Adds PvP / Dungeon / Raid profile buttons under Blizzard's AddOns list so you can switch whole addon sets in one click. Untick to leave Blizzard's AddOns window completely untouched."],
                    type = "toggle", order = 8.5, width = 1.4,
                    get = function()
                        return not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.hideAddonProfilePanel == true)
                    end,
                    set = function(_, v)
                        if AkcQOLDB and AkcQOLDB.global then
                            AkcQOLDB.global.hideAddonProfilePanel = not v
                        end
                        if _G.AkcQOL_ApplyAddonProfilePanel then _G.AkcQOL_ApplyAddonProfilePanel() end
                    end,
                },
                autoAcceptInvite = {
                    name = L["Auto-Accept Invites"],
                    desc = L["Automatically accepts incoming party/raid invitations. Use the \"From Whom\" option below to control whose invites are accepted -- keep it on \"Friends, Guild & Battle.net\" so random or scam invites still show the normal popup. Off by default."],
                    type = "toggle", order = 8.5, width = 1.4,
                    get = function()
                        return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.autoAcceptInvite
                            and AkcQOLDB.global.autoAcceptInvite.enabled == true
                    end,
                    set = function(_, v)
                        if not (AkcQOLDB and AkcQOLDB.global) then return end
                        AkcQOLDB.global.autoAcceptInvite = AkcQOLDB.global.autoAcceptInvite or {}
                        AkcQOLDB.global.autoAcceptInvite.enabled = v and true or false
                        if _G.AkcQOL_ApplyAutoAcceptInvite then _G.AkcQOL_ApplyAutoAcceptInvite() end
                    end,
                },
                autoAcceptMode = {
                    name = L["Auto-Accept: From Whom"],
                    desc = L["|cff00ff00Friends, Guild & Battle.net|r (recommended): only accepts invites from a character friend, a guild member, or a Battle.net friend -- anyone else still shows the normal invite popup.\n\n|cffff5555Everyone|r: accepts ANY invite, including random or unwanted ones. Use with care."],
                    type = "select", order = 8.6, width = 1.5,
                    values = { all = L["Everyone"], friends = L["Friends, Guild & Battle.net"] },
                    get = function()
                        local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.autoAcceptInvite
                        return (d and d.mode == "all") and "all" or "friends"
                    end,
                    set = function(_, v)
                        if not (AkcQOLDB and AkcQOLDB.global) then return end
                        AkcQOLDB.global.autoAcceptInvite = AkcQOLDB.global.autoAcceptInvite or {}
                        AkcQOLDB.global.autoAcceptInvite.mode = (v == "all") and "all" or "friends"
                        if _G.AkcQOL_ApplyAutoAcceptInvite then _G.AkcQOL_ApplyAutoAcceptInvite() end
                    end,
                    disabled = function()
                        return not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.autoAcceptInvite
                            and AkcQOLDB.global.autoAcceptInvite.enabled)
                    end,
                },
                dynamicFPS = {
                    name = L["Dynamic FPS (instances)"], desc = L["Automatically lowers graphics-heavy settings (particles, shadows, reflections, water, weather, lights, LOD...) inside raids / dungeons / arenas / battlegrounds, and restores your normal graphics in the open world.\n\nJust tick this box -- that's all you need. |cff00ff00No /reload or commands required.|r It only acts inside instances, so you won't see a change while standing in town. Fully reversible and reload-safe: your own graphics settings are captured and put back -- unticking restores them."],
                    type = "toggle", order = 7, width = 1.4,
                    get = function()
                        local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.dynFPS
                        return d ~= nil and d.mode ~= nil and d.mode ~= "off"
                    end,
                    set = function(_, v)
                        if not (AkcQOLDB and AkcQOLDB.global) then return end
                        AkcQOLDB.global.dynFPS = AkcQOLDB.global.dynFPS or {}
                        AkcQOLDB.global.dynFPS.mode = v and "auto" or "off"
                        if _G.AkcQOL_ApplyDynamicFPS then _G.AkcQOL_ApplyDynamicFPS() end
                    end,
                },
            },
        },
        qolDisplay = {
            name = L["Display"], type = "group", order = -20,
            args = {

                wipeChatPrint    = qoToggle("wipeChatPrint", L["Wipe Percentage in Chat"], 1.5, nil, L["After a raid or dungeon boss wipe, prints the lowest boss health reached (e.g. \"Wipe at 23% boss HP.\") to your chat. Off by default."]),
                showMinimap      = qoToggle("showMinimap", L["Show Minimap Button"], 2, function(v)
                    if AkcQOLMinimapBtn then if v then AkcQOLMinimapBtn:Show() else AkcQOLMinimapBtn:Hide() end end
                end, L["Shows the AkcQOL minimap button: left-click toggles the matrix, right-click opens settings, drag to move it. The /akc and /akcsettings commands work without it."]),
                showItemLevel    = qoToggle("showItemLevel", L["Show Item Levels"], 3, function() if _G.AkcQOL_ToggleItemLevel then _G.AkcQOL_ToggleItemLevel() end end, L["Paints item-level numbers on items in the character sheet, bags, bank (Account/Warband), the loot window and the equipment flyout. Equipped slots also show red G/E warnings for missing gems/enchants."]),
                ilvlArrow        = ilvlToggle("arrow", L["Item Level: Upgrade Arrow"], 3.1, L["Shows an arrow next to bag items that are an item-level upgrade over your equipped gear."]),
                ilvlGemEnchant   = ilvlToggle("gemEnchant", L["Item Level: Gem & Enchant Warnings"], 3.2, L["Shows the red G/E letters on equipped slots that are missing gems or enchants."]),
                ilvlDecimals     = ilvlToggle("decimals", L["Item Level: Decimals"], 3.3, L["Shows item level with decimals (e.g. 489.75) where available instead of a rounded number."]),
                showRaidProgress = qoToggle("showRaidProgress", L["Show Raid Progress"], 4, nil, L["Near a raid, shows a top-of-screen panel of this week's boss kills per difficulty (from your saved lockouts). Hover a difficulty tab for its per-boss list."]),
                combatTextFont = qoToggle("combatTextFont", L["Stylish Combat Numbers"], 5, function(v)
                    if v then
                        if _G.AkcQOL_CombatFontRelogPrompt then _G.AkcQOL_CombatFontRelogPrompt() end
                    else
                        if _G.AkcQOL_ApplyCombatTextFont then _G.AkcQOL_ApplyCombatTextFont(v) end
                    end
                end, L["Renders WoW's floating damage & healing numbers — over enemies AND on your own character — with a custom font. Numbers on you change instantly; the numbers over enemies change after you fully log out to character-select and back in (a /reload is not enough)."]),
                combatTextFontFace = {
                    name = L["Combat Number Font"],
                    desc = L["The font for the floating combat numbers. Your own numbers update instantly; numbers over enemies change after a full logout to character-select (not just /reload)."],
                    type = "select", order = 5.1, width = 1.5,
                    values = function()
                        local out = {}
                        local faces = _G.AkcQOL_GetCombatTextFontFaces and _G.AkcQOL_GetCombatTextFontFaces() or {}
                        for k, v in pairs(faces) do out[k] = v.label end
                        return out
                    end,
                    sorting = function()
                        local faces = _G.AkcQOL_GetCombatTextFontFaces and _G.AkcQOL_GetCombatTextFontFaces() or {}
                        local keys = {}
                        for k in pairs(faces) do keys[#keys + 1] = k end
                        table.sort(keys, function(a, b) return (faces[a].order or 99) < (faces[b].order or 99) end)
                        return keys
                    end,
                    get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatTextFontFace) or "akc" end,
                    set = function(_, v)
                        if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.combatTextFontFace = v end
                        if _G.AkcQOL_CombatFontRelogPrompt then _G.AkcQOL_CombatFontRelogPrompt() end
                    end,
                    disabled = function() return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatTextFont == false end,
                },
                combatTextAnim = {
                    name = L["Combat Number Animation"],
                    desc = L["How the damage numbers over enemies move. \"WoW Default\" scatters them in the hit direction; the other styles make them rise in a tidy column. Applies instantly — no reload needed."],
                    type = "select", order = 5.2, width = 1.5,
                    values = function()
                        local out = {}
                        local styles = _G.AkcQOL_GetCombatAnimStyles and _G.AkcQOL_GetCombatAnimStyles() or {}
                        for k, v in pairs(styles) do out[k] = v.label end
                        return out
                    end,
                    sorting = function()
                        local styles = _G.AkcQOL_GetCombatAnimStyles and _G.AkcQOL_GetCombatAnimStyles() or {}
                        local keys = {}
                        for k in pairs(styles) do keys[#keys + 1] = k end
                        table.sort(keys, function(a, b) return (styles[a].order or 99) < (styles[b].order or 99) end)
                        return keys
                    end,
                    get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatTextAnim) or "default" end,
                    set = function(_, v)
                        if _G.AkcQOL_ApplyCombatAnim then _G.AkcQOL_ApplyCombatAnim(v) end
                        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Combat number animation applied."])
                    end,
                },
                combatTextScale = {
                    name = L["Combat Number Size"],
                    desc = L["Size of the damage numbers over enemies. 1.0 = Blizzard default. Applies instantly."],
                    type = "range", order = 5.3, width = 1.5,
                    min = 0.5, max = 2.5, step = 0.05,
                    get = function() return (AkcQOLDB and AkcQOLDB.global and tonumber(AkcQOLDB.global.combatTextWorldScale)) or 1 end,
                    set = function(_, v)
                        if _G.AkcQOL_SetCombatNumberScale then _G.AkcQOL_SetCombatNumberScale(v) end
                    end,
                },
                combatTextBehindBars = {
                    name = L["Numbers Behind Action Bars"],
                    desc = L["Keeps the incoming heal/damage numbers on your character BEHIND the action bars instead of over them, so they never cover your ability icons. Applies out of combat."],
                    type = "toggle", order = 5.35, width = 1.6,
                    get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatTextBehindBars == true) or false end,
                    set = function(_, v)
                        if _G.AkcQOL_SetCombatTextBehindBars then _G.AkcQOL_SetCombatTextBehindBars(v) end
                    end,
                },
                combatRiseHeight = {
                    name = L["Launch Height (enemy numbers)"],
                    desc = L["How hard the numbers are thrown when they appear over an enemy. 2.5 = Blizzard default. |cFFFFD100Negative values throw them DOWNWARD instead of up.|r Applies instantly."],
                    type = "range", order = 5.4, width = 1.5,
                    min = -5, max = 6, step = 0.25,
                    get = function() return _G.AkcQOL_GetCombatRise and _G.AkcQOL_GetCombatRise("height") or 2.5 end,
                    set = function(_, v)
                        if _G.AkcQOL_SetCombatRise then _G.AkcQOL_SetCombatRise("height", v) end
                    end,
                },
                combatRiseSpeed = {
                    name = L["Drift Speed (enemy numbers)"],
                    desc = L["How fast the numbers keep climbing the screen after they appear. 0.015 = Blizzard default. |cFFFFD100Negative values make them sink downward.|r Applies instantly."],
                    type = "range", order = 5.5, width = 1.5,
                    min = -0.05, max = 0.06, step = 0.005,
                    get = function() return _G.AkcQOL_GetCombatRise and _G.AkcQOL_GetCombatRise("speed") or 0.015 end,
                    set = function(_, v)
                        if _G.AkcQOL_SetCombatRise then _G.AkcQOL_SetCombatRise("speed", v) end
                    end,
                },
                combatSelfFloatMode = {
                    name = L["Your Own Numbers: Direction"],
                    desc = L["Which way the incoming damage/healing numbers on YOUR character travel. Applies instantly."],
                    type = "select", order = 5.6, width = 1.5,
                    values = function()
                        return { [1] = L["Up"], [2] = L["Down"], [3] = L["Arc"] }
                    end,
                    sorting = function() return { 1, 2, 3 } end,
                    get = function() return _G.AkcQOL_GetSelfFloatMode and _G.AkcQOL_GetSelfFloatMode() or 1 end,
                    set = function(_, v)
                        if _G.AkcQOL_SetSelfFloatMode then _G.AkcQOL_SetSelfFloatMode(v) end
                    end,
                },
            },
        },
        qolHud = {
            name = L["HUD & Info"], type = "group", order = -10,
            args = {
                hudDesc = {
                    name = L["A small floating panel showing your spec/loadout, lowest durability and loot spec. Drag it anywhere on screen."],
                    type = "description", order = 0.1, fontSize = "medium",
                },
                hudPreview = {
                    name = L["Preview HUD (8 Seconds)"],
                    desc = L["Temporarily bring the HUD to the front so you can see it and where it sits — even while \"Show HUD Info\" is off."],
                    type = "execute", order = 0.3, width = 1.2,
                    func = function() if _G.AkcQOL_PreviewHUD then _G.AkcQOL_PreviewHUD() end end,
                },
                hudResetPos = {
                    name = L["Reset HUD Position (Center)"],
                    desc = L["Move the HUD back to the center of the screen."],
                    type = "execute", order = 0.4, width = 1.2,
                    func = function() if _G.AkcQOL_ResetHUDPosition then _G.AkcQOL_ResetHUDPosition() end end,
                },
                showTalentHelper = qoToggle("showTalentHelper", L["Talent Helper"], 1, nil, L["Adds M+ and Raid build side panels to the talent window (WarcraftLogs builds, switchable to Archon). One click loads a build into your talents; if it can't be applied directly it falls back to a copy-paste popup."]),
                talentWarning = qoToggle("talentWarning", L["Talent Build Warning"], 1.2, function()
                    if _G.AkcQOL_CheckTalentProfile then _G.AkcQOL_CheckTalentProfile(true) end
                end, L["Shows a popup warning when you enter a dungeon or raid while your current talents do not match a known top build. Off by default -- turn it on only if you want the reminder. (Separate from the Talent Helper side panels, which this never affects.)"]),
                talentAutoScale = {
                    name = L["Auto-resize Talent Window"],
                    desc = L["Automatically scales the talent window down when it would not fit on screen (e.g. with the build side panels attached)."],
                    type = "toggle", order = 1.5, width = 1.4,
                    get = function() return not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.talentAutoScale == false) end,
                    set = function(_, v)
                        if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.talentAutoScale = v end
                    end,
                },
                showHUD          = qoToggle("showHUD", L["Show HUD Info"], 2, function() if _G.AkcQOL_ApplyHUDVisibility then _G.AkcQOL_ApplyHUDVisibility() end end, L["Shows a small draggable panel with your spec and active loadout, the currently loaded talent build name (when one is loaded), your lowest gear durability and your loot spec."]),
                hudLocked        = qoToggle("hudLocked", L["Lock HUD (click-through)"], 2.5, function() if _G.AkcQOL_ApplyHUDLock then _G.AkcQOL_ApplyHUDLock() end end, L["Locks the HUD info panel in place and lets mouse clicks pass through it, so it can't be dragged or block clicks on things behind it."]),
                hudScale = {
                    name = L["HUD Info Scale"], type = "range", order = 10, width = 1.5,
                    min = 0.5, max = 2.0, step = 0.1, isPercent = true,
                    get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.hudScale) or 1.0 end,
                    set = function(_, v)
                        local cur = (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.hudScale) or 1.0
                        if _G.AkcQOL_SetHUDScale then _G.AkcQOL_SetHUDScale(v - cur) end
                    end,
                },
                restoreDefaults = {
                    name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                    confirm = true,
                    confirmText = L["Reset all HUD & Info settings to defaults?"],
                    func = function()
                        if _G.AkcQOL_ResetHUDDefaults then _G.AkcQOL_ResetHUDDefaults() end
                        LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                    end,
                },
            },
        },
        qolLogging = {
            name = L["Logging"], type = "group", order = -8,
            args = {
                desc = {
                    name = L["AkcQOL can keep local activity logs (viewable via /akc logs). Everything is stored only on your computer, in this addon's saved variables."],
                    type = "description", order = 0, fontSize = "medium",
                },
                logMailTradeLoot = qoToggleOn("logMailTradeLoot", L["Mail / Trade / Loot Logging"], 1, nil,
                    L["Records mailbox contents and taken attachments, trade contents, and looted items into the Mail / Trade / Loot logs."]),
                logChat = qoToggleOn("logChat", L["Chat Logging"], 2, nil,
                    L["Records guild / party / raid / say / yell / instance chat AND WHISPERS into the Chat Log.\n\n|cffffcc66Privacy:|r whispers are stored in plain text on your computer, in this addon's SavedVariables file (WTF folder). Nothing is ever sent anywhere. Use the Clear Log button in the log window (/akc logs) to delete stored history at any time."]),
                logLootTrash = qoToggle("logLootTrash", L["Also Log Trash (Poor) Loot"], 3, nil,
                    L["By default the Loot log skips grey \"Poor\" quality junk. Turn this on to log those items too."]),
            },
        },
    }
    end
    BuildQoLSettingsGroups()
    if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(BuildQoLSettingsGroups) end
end

do
    local METER_WINDOWS = { "DamageMeterSessionWindow1", "DamageMeterSessionWindow2", "DamageMeterSessionWindow3" }

    local function DmgMeterDB()
        local g = AkcQOLDB and AkcQOLDB.global
        if not g then return nil end
        g.dmgMeter = g.dmgMeter or {}
        local d = g.dmgMeter
        if d.enabled == nil then d.enabled = false end
        if d.mouseoverMode == nil then d.mouseoverMode = "show" end
        if d.mouseoverMode == "off" then d.mouseoverMode = "none" end
        if d.combatMode == nil then d.combatMode = "show" end
        if d.minAlpha == nil then d.minAlpha = 0 end
        if d.maxAlpha == nil then d.maxAlpha = 1 end
        return d
    end

    local hoverLinger = 0
    local wasInCombat = false
    local restoreUntil = 0
    local function ClusterHovered()
        for _, name in ipairs(METER_WINDOWS) do
            local w = _G[name]
            if w then
                local okShown, shown = pcall(w.IsShown, w)
                if okShown and shown then
                    local okOver, over = pcall(w.IsMouseOver, w)
                    if okOver and over then return true end
                    local sw = w.SourceWindow
                    if sw then
                        local okS, sShown = pcall(sw.IsShown, sw)
                        if okS and sShown then
                            local okO, sOver = pcall(sw.IsMouseOver, sw)
                            if okO and sOver then return true end
                        end
                    end
                end
            end
        end
        return false
    end

    local driver = CreateFrame("Frame")
    local function DriverOnUpdate(_, elapsed)
        local d = DmgMeterDB()
        if not d or not d.enabled then return end
        local hovered = ClusterHovered()
        if hovered then
            hoverLinger = 0.30
        elseif hoverLinger > 0 then
            hoverLinger = hoverLinger - elapsed
        end
        local effHover = hovered or hoverLinger > 0
        local target
        local inCombat = InCombatLockdown and InCombatLockdown()
        if inCombat and d.combatMode == "show" then
            target = d.maxAlpha
        elseif inCombat and d.combatMode == "hide" then
            target = d.minAlpha
        elseif d.mouseoverMode == "hide" then
            target = effHover and d.minAlpha or d.maxAlpha
        elseif d.mouseoverMode == "show" then
            target = effHover and d.maxAlpha or d.minAlpha
        else

            if wasInCombat and not inCombat and d.combatMode ~= "none" then
                restoreUntil = GetTime() + 1.5
            end
            if GetTime() < restoreUntil then target = d.maxAlpha end
        end
        wasInCombat = inCombat and true or false
        if target == nil then return end
        local speed = elapsed * 6
        if speed > 1 then speed = 1 end
        for _, name in ipairs(METER_WINDOWS) do
            local win = _G[name]
            if win and win.IsShown and win:IsShown() then
                local cur = win:GetAlpha() or 1
                local na = cur + (target - cur) * speed
                if math.abs(na - target) < 0.01 then na = target end
                win:SetAlpha(na)
            end
        end
    end

    function _G.AkcQOL_RefreshDamageMeter()
        local d = DmgMeterDB()

        driver:SetScript("OnUpdate", (d and d.enabled) and DriverOnUpdate or nil)
        if not d or d.enabled then return end

        for _, name in ipairs(METER_WINDOWS) do
            local win = _G[name]
            if win and win.SetAlpha then win:SetAlpha(1) end
        end
    end

    local function refresh() if _G.AkcQOL_RefreshDamageMeter then _G.AkcQOL_RefreshDamageMeter() end end

    driver:RegisterEvent("PLAYER_LOGIN")
    driver:SetScript("OnEvent", function(self)
        self:UnregisterEvent("PLAYER_LOGIN")
        refresh()
    end)

    local function InjectDamageMeterGroup()
        if not _G.AkcQOLQoLSettingsGroups then return end
        _G.AkcQOLQoLSettingsGroups.qolDamageMeter = {
            name = L["Damage Meter"], type = "group", order = -5,
            args = {
                desc = {
                    name = L["Control the visibility of Blizzard's built-in Damage Meter windows (DPS / HPS). Uses an opacity fade, so it is safe in combat. For best results set the meter's Edit Mode visibility to \"Always Visible\"."],
                    type = "description", order = 0, fontSize = "medium",
                },
                enabled = {
                    name = L["Control Damage Meter Visibility"], type = "toggle", order = 1, width = 2,
                    get = function() local d = DmgMeterDB(); return d and d.enabled end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.enabled = v end; refresh() end,
                },
                mouseoverMode = {
                    name = L["On Mouseover"], type = "select", order = 2, width = 1.5,
                    values = { none = L["No change"], show = L["Show on mouseover"], hide = L["Hide on mouseover"] },
                    get = function() local d = DmgMeterDB(); return (d and d.mouseoverMode) or "show" end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.mouseoverMode = v end; refresh() end,
                },
                combatMode = {
                    name = L["In Combat"], type = "select", order = 3, width = 1.5,
                    values = { none = L["No change"], show = L["Always show in combat"], hide = L["Hide in combat"] },
                    get = function() local d = DmgMeterDB(); return (d and d.combatMode) or "show" end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.combatMode = v end; refresh() end,
                },
                minAlpha = {
                    name = L["Hidden Opacity"], type = "range", order = 4, width = 1.5,
                    min = 0, max = 1, step = 0.05, isPercent = true,
                    get = function() local d = DmgMeterDB(); return (d and d.minAlpha) or 0 end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.minAlpha = v end; refresh() end,
                },
                maxAlpha = {
                    name = L["Shown Opacity"], type = "range", order = 5, width = 1.5,
                    min = 0, max = 1, step = 0.05, isPercent = true,
                    get = function() local d = DmgMeterDB(); return (d and d.maxAlpha) or 1 end,
                    set = function(_, v) local d = DmgMeterDB(); if d then d.maxAlpha = v end; refresh() end,
                },
                restoreDefaults = {
                    name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                    confirm = true,
                    confirmText = L["Reset all Damage Meter settings to defaults?"],
                    func = function()
                        if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.dmgMeter = nil end
                        DmgMeterDB()
                        refresh()
                        LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                    end,
                },
            },
        }
    end
    InjectDamageMeterGroup()
    if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(InjectDamageMeterGroup) end

    refresh()
end
local RenderSection

local function AkcBlankPanelTitle(self)
    self.label:SetText("")
    self.content:ClearAllPoints()
    self.content:SetPoint("TOPLEFT", 10, -10)
    self.content:SetPoint("BOTTOMRIGHT", -10, 10)
end

local raidcd = { host = CreateFrame("Frame", nil, contentPane) }
raidcd.host:SetAllPoints(contentPane)
raidcd.host:Hide()

raidcd.fallback = raidcd.host:CreateFontString(nil, "OVERLAY")
Theme.SetFont(raidcd.fallback, 12, "")
raidcd.fallback:SetPoint("TOPLEFT", raidcd.host, "TOPLEFT", 6, -38)
raidcd.fallback:SetPoint("TOPRIGHT", raidcd.host, "TOPRIGHT", -6, -38)
raidcd.fallback:SetJustifyH("LEFT")
local function RebuildFallbackText()
    raidcd.fallback:SetText(L["|cFFE5E7EBSettings are loading. If this stays empty, type|r |cFFF59E0B/akcsettings|r |cFFE5E7EBonce.|r"])
end
RebuildFallbackText()
if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(RebuildFallbackText) end
raidcd.fallback:Hide()

local ROOT_APP     = "AkcQOLRaidCD"
local SECTION_APP  = "AkcQOLSection"
local SEARCH_APP   = "AkcQOLSearch"
local TOPBAR_H     = 28
local MENU_PAD     = 8
local MENU_GAP     = 4
local OVERVIEW_APP = "AkcQOLOverview"
local OVERVIEW_KEY = "overview"
local TILE_MIN_W   = 190
local TILE_MAX_COLS = 5
local TILE_H_MAX   = 88
local TILE_H_MIN   = 46
local OVERVIEW_MIN = 150

function raidcd.Available()
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not (reg and reg.GetOptionsTable) then return false end
    local ok, tbl = pcall(reg.GetOptionsTable, reg, "AkcQOLRaidCD")
    return ok and tbl and true or false
end

function raidcd.GetRootOptions()
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not reg then return nil end
    local ok, getter = pcall(reg.GetOptionsTable, reg, ROOT_APP)
    if not ok or type(getter) ~= "function" then return nil end
    local ok2, tbl = pcall(getter, "dialog", "AceConfigDialog-3.0")
    if ok2 and type(tbl) == "table" and type(tbl.args) == "table" then return tbl end
    return nil
end

function raidcd.GetCategoryGroup(key)
    if not key then return nil end
    local root = raidcd.GetRootOptions()
    local g = root and root.args and root.args[key]
    if type(g) == "table" and g.type == "group" then return g end
    return nil
end

local function AkcGroupTitle(g, key)
    local title = g and g.name
    if type(title) == "function" then
        local ok, v = pcall(title)
        title = ok and v or nil
    end
    if type(title) ~= "string" or title == "" then return key end
    return title
end

function raidcd.BuildCategoryList()
    local list = {}
    local root = raidcd.GetRootOptions()
    if not root then return list end
    for key, g in pairs(root.args) do
        if key ~= OVERVIEW_KEY and type(g) == "table" and g.type == "group" and not g.inline then
            local hidden = g.hidden
            if type(hidden) == "function" then
                local okH, v = pcall(hidden)
                hidden = okH and v or false
            end
            if hidden ~= true then
                local icon = g.icon
                if type(icon) == "function" then
                    local okI, v = pcall(icon)
                    icon = (okI and type(v) == "string") and v or nil
                end
                list[#list + 1] = {
                    key = key,
                    title = AkcGroupTitle(g, key),
                    icon = type(icon) == "string" and icon or nil,
                    order = tonumber(g.order) or 100,
                }
            end
        end
    end
    table.sort(list, function(a, b)
        if a.order ~= b.order then return a.order < b.order end
        return a.title < b.title
    end)
    return list
end

local SEARCH_SKIP_TYPES = {
    header = true, description = true,
}

local function SearchOptionName(entry)
    local n = entry.name
    if type(n) == "function" then
        local ok, v = pcall(n)
        n = ok and v or nil
    end
    if type(n) ~= "string" then return nil end
    n = n:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")
    n = n:gsub("^%s+", ""):gsub("%s+$", "")
    if n == "" then return nil end
    return n
end

local function BuildSearchIndex()
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not reg then return {} end
    local ok, getter = pcall(reg.GetOptionsTable, reg, "AkcQOLRaidCD")
    if not ok or not getter then return {} end

    local root = getter
    if type(getter) == "function" then
        local ok2, tbl = pcall(getter, "dialog", "AceConfigDialog-3.0")
        root = ok2 and tbl or nil
    end
    if type(root) ~= "table" or type(root.args) ~= "table" then return {} end

    local results = {}
    local function walk(tbl, path, trail, depth)
        if depth > 6 or type(tbl) ~= "table" or type(tbl.args) ~= "table" then return end
        for key, entry in pairs(tbl.args) do
            if type(entry) == "table" then
                local label = SearchOptionName(entry)
                if entry.type == "group" then
                    local nextPath = path
                    if not entry.inline then
                        nextPath = { unpack(path) }
                        nextPath[#nextPath + 1] = key
                    end
                    local nextTrail = label and (trail ~= "" and (trail .. " > " .. label) or label) or trail
                    walk(entry, nextPath, nextTrail, depth + 1)
                elseif label and not SEARCH_SKIP_TYPES[entry.type] then
                    results[#results + 1] = {
                        label = label,
                        trail = trail,
                        path = path,
                        entry = entry,
                        parent = tbl.args,
                        lower = label:lower(),
                        trailLower = (trail or ""):lower(),
                    }
                end
            end
        end
    end
    walk(root, {}, "", 1)
    return results
end

local MAX_SEARCH_RESULTS = 18

local function CopySearchEntry(entry, order, trail)
    local copy = {}
    for k, v in pairs(entry) do copy[k] = v end
    copy.order = order
    local crumb = "|cFF9AA0A6" .. (trail ~= "" and trail or "Settings") .. "|r"
    local d = copy.desc
    if type(d) == "string" then
        copy.desc = d .. "\n\n" .. crumb
    elseif type(d) ~= "function" then
        copy.desc = crumb
    end
    if copy.type ~= "range" and copy.type ~= "select" then
        copy.width = "full"
    end
    return copy
end

function raidcd.RunSearch(query)
    query = (query or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")

    if query == "" then
        if raidcd.page == "search" then raidcd.ShowMenuPage() end
        return
    end

    raidcd.index = raidcd.index or BuildSearchIndex()

    local hits = {}
    for _, item in ipairs(raidcd.index) do
        if item.lower:find(query, 1, true) or item.trailLower:find(query, 1, true) then
            hits[#hits + 1] = item
        end
    end
    table.sort(hits, function(a, b)
        local ai = a.lower:find(query, 1, true) and 0 or 1
        local bi = b.lower:find(query, 1, true) and 0 or 1
        if ai ~= bi then return ai < bi end
        return a.label < b.label
    end)

    local args = {}
    local total = #hits
    local shown = math.min(total, MAX_SEARCH_RESULTS)
    local picked, order = {}, 0

    for i = 1, shown do
        local item = hits[i]
        if not picked[item.entry] then
            picked[item.entry] = true
            order = order + 1
            args["akcfound" .. order] = CopySearchEntry(item.entry, order, item.trail)
        end
    end

    if order > 0 and order < MAX_SEARCH_RESULTS then
        local seenParent = {}
        for i = 1, shown do
            local item = hits[i]
            if item.parent and not seenParent[item.parent] then
                seenParent[item.parent] = true
                local added = 0
                for _, sib in ipairs(raidcd.index) do
                    if order >= MAX_SEARCH_RESULTS or added >= 4 then break end
                    if sib.parent == item.parent and not picked[sib.entry] then
                        picked[sib.entry] = true
                        added = added + 1
                        order = order + 1
                        args["akcfound" .. order] = CopySearchEntry(sib.entry, order, sib.trail)
                    end
                end
                if added > 0 then
                    args["akcrel" .. order] = {
                        type = "description", order = order - added - 0.5, fontSize = "small",
                        name = "|cFF7A7A82" .. L["Related settings:"] .. "|r",
                    }
                end
            end
            if order >= MAX_SEARCH_RESULTS then break end
        end
    end

    if total == 0 then
        args.akcnone = {
            type = "description", order = 1, fontSize = "medium",
            name = "|cFF9AA0A6" .. L["No settings match your search."] .. "|r",
        }
    elseif total > shown then
        args.akcmore = {
            type = "description", order = 999, fontSize = "medium",
            name = "\n|cFF9AA0A6" .. string.format(L["...and %d more. Keep typing to narrow it down."], total - shown) .. "|r",
        }
    end

    raidcd.searchOptions.args = args

    raidcd.fallback:Hide()
    raidcd.activeKey, raidcd.activeTitle = nil, nil
    if raidcd.crumb then raidcd.crumb:SetText("") end
    if raidcd.page ~= "search" then raidcd.SetPage("search") end
    raidcd.RenderCurrentPage()
end

function raidcd.EnsureSearchUI()
    if raidcd.searchBox then return end
    if not raidcd.topBar then return end

    local box = CreateFrame("EditBox", nil, raidcd.topBar, "InputBoxTemplate")
    box:SetAutoFocus(false)
    box:SetHeight(20)
    AkcQOL_Theme.SetFont(box, 12, "")
    box:SetTextInsets(4, 4, 0, 0)
    raidcd.searchBox = box

    local hint = box:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    AkcQOL_Theme.SetFont(hint, 12, "")
    hint:SetPoint("LEFT", 6, 0)
    hint:SetTextColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.textMuted))
    hint:SetText(L["Search settings..."])
    box.akcHint = hint

    box:SetScript("OnTextChanged", function(self)
        local txt = self:GetText() or ""
        hint:SetShown(txt == "")
        if raidcd.suppressSearch then return end
        raidcd.searchGen = (raidcd.searchGen or 0) + 1
        if txt == "" or not (C_Timer and C_Timer.After) then
            raidcd.RunSearch(txt)
            return
        end
        local gen = raidcd.searchGen
        C_Timer.After(0.15, function()
            if raidcd.searchGen == gen then raidcd.RunSearch(txt) end
        end)
    end)
    box:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        if raidcd.page == "search" then
            raidcd.ShowMenuPage()
        else
            self:SetText("")
        end
    end)

    raidcd.AnchorSearchBox(true)
end

local function AkcClearSearchBox()
    local box = raidcd.searchBox
    if not box or (box:GetText() or "") == "" then return end
    raidcd.suppressSearch = true
    pcall(box.SetText, box, "")
    raidcd.suppressSearch = nil
    raidcd.searchGen = (raidcd.searchGen or 0) + 1
    box:ClearFocus()
    if box.akcHint then box.akcHint:Show() end
end

function raidcd.AnchorSearchBox(wide)
    local box = raidcd.searchBox
    if not (box and raidcd.topBar) then return end
    box:ClearAllPoints()
    box:SetPoint("RIGHT", raidcd.topBar, "RIGHT", -12, 0)
    if wide or not raidcd.backBtn then
        box:SetPoint("LEFT", raidcd.topBar, "LEFT", 12, 0)
    else
        box:SetPoint("LEFT", raidcd.backBtn, "RIGHT", 12, 0)
    end
end

function raidcd.SetPage(page)
    raidcd.page = page or "menu"
    if not raidcd.menuPage then return end
    local isMenu = (raidcd.page == "menu")
    raidcd.menuPage:SetShown(isMenu)
    raidcd.detailPage:SetShown(not isMenu)
    if raidcd.backBtn then raidcd.backBtn:SetShown(not isMenu) end
    if raidcd.crumb then raidcd.crumb:SetShown(raidcd.page == "detail") end
    if raidcd.searchBox then
        raidcd.searchBox:SetShown(raidcd.page ~= "detail")
        raidcd.AnchorSearchBox(isMenu)
        if raidcd.page == "detail" then raidcd.searchBox:ClearFocus() end
    end
    if raidcd.detailPage then
        pcall(raidcd.detailPage.EnableKeyboard, raidcd.detailPage, raidcd.page ~= "menu")
    end
end

function raidcd.MenuMetrics(n)
    local page = raidcd.menuPage
    if not page or n <= 0 then return 1, TILE_H_MAX, TILE_MIN_W, 0 end

    local availW = (page:GetWidth() or 0) - MENU_PAD * 2
    local availH = (page:GetHeight() or 0) - MENU_PAD * 2
    if availW < 120 then availW = 120 end
    if availH < 120 then availH = 120 end

    local cols = math.floor((availW + MENU_GAP) / (TILE_MIN_W + MENU_GAP))
    if cols < 2 then cols = 2 end
    if cols > TILE_MAX_COLS then cols = TILE_MAX_COLS end
    if cols > n then cols = n end

    local rows = math.ceil(n / cols)
    local tileW = math.floor((availW - (cols - 1) * MENU_GAP) / cols)

    local tileH = TILE_H_MAX
    local room = availH - OVERVIEW_MIN - MENU_GAP
    local needed = rows * tileH + (rows - 1) * MENU_GAP
    if needed > room then
        tileH = math.floor((room - (rows - 1) * MENU_GAP) / rows)
    end
    if tileH > TILE_H_MAX then tileH = TILE_H_MAX end
    if tileH < TILE_H_MIN then tileH = TILE_H_MIN end

    local gridH = rows * tileH + (rows - 1) * MENU_GAP
    return cols, tileH, tileW, gridH
end

function raidcd.CreateMenuRow(i)
    local row = CreateFrame("Button", nil, raidcd.menuPage)
    row:SetPushedTextOffset(0, 0)

    row.border = row:CreateTexture(nil, "BORDER")
    row.border:SetTexture(WV_FLAT_TEX)
    row.border:SetAllPoints()
    row.border:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))

    row.bg = row:CreateTexture(nil, "BORDER")
    row.bg:SetTexture(WV_FLAT_TEX)
    row.bg:SetPoint("TOPLEFT", row.border, "TOPLEFT", 1, -1)
    row.bg:SetPoint("BOTTOMRIGHT", row.border, "BOTTOMRIGHT", -1, 1)
    row.bg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.panelBg))

    row:SetHighlightTexture(WV_FLAT_TEX)
    local hl = row:GetHighlightTexture()
    if hl then
        local hc = AkcQOL_Theme.colors.rowHover
        hl:SetVertexColor(hc[1], hc[2], hc[3])
        hl:SetAlpha(0.45)
        hl:SetBlendMode("BLEND")
        hl:ClearAllPoints()
        hl:SetPoint("TOPLEFT", 1, -1)
        hl:SetPoint("BOTTOMRIGHT", -1, 1)
    end

    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    AkcQOL_Theme.SetFont(row.text, 14, "", true)
    row.text:SetJustifyH("CENTER")
    row.text:SetWordWrap(false)
    row.text:SetTextColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.text))

    row:SetScript("OnClick", function(self)
        if self.akcKey then raidcd.ShowCategory(self.akcKey, self.akcTitle) end
    end)

    raidcd.rows[i] = row
    return row
end

function raidcd.RefreshMenu(cats)
    if not raidcd.menuPage then return end
    raidcd.rows = raidcd.rows or {}

    cats = cats or raidcd.cats or raidcd.BuildCategoryList()
    raidcd.cats = cats

    for i = 1, #(raidcd.rows) do
        if raidcd.rows[i] then raidcd.rows[i]:Hide() end
    end

    local gridH = 0
    if #cats > 0 then
        local cols, tileH, tileW, gh = raidcd.MenuMetrics(#cats)
        gridH = gh

        local fnt = math.max(12, math.min(15, math.floor(tileH * 0.17)))
        local textH = fnt + 6
        local iconSz = math.max(18, math.min(40, tileH - textH - 20))

        for i, item in ipairs(cats) do
            local row = raidcd.rows[i] or raidcd.CreateMenuRow(i)
            local col = (i - 1) % cols
            local line = math.floor((i - 1) / cols)

            row:SetSize(tileW, tileH)
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", raidcd.menuPage, "TOPLEFT",
                MENU_PAD + col * (tileW + MENU_GAP),
                -(MENU_PAD + line * (tileH + MENU_GAP)))

            row.akcKey, row.akcTitle = item.key, item.title

            row.icon:ClearAllPoints()
            row.icon:SetSize(iconSz, iconSz)
            row.icon:SetPoint("TOP", row, "TOP", 0, -8)
            if item.icon then
                row.icon:SetTexture(item.icon)
                row.icon:Show()
            else
                row.icon:Hide()
            end

            AkcQOL_Theme.SetFont(row.text, fnt, "", true)
            row.text:ClearAllPoints()
            row.text:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 4, 7)
            row.text:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -4, 7)
            row.text:SetText(item.title)
            row:Show()
        end
    end

    local ov = raidcd.overviewContainer and raidcd.overviewContainer.frame
    if ov then
        ov:ClearAllPoints()
        ov:SetPoint("TOPLEFT", raidcd.menuPage, "TOPLEFT", MENU_PAD, -(MENU_PAD + gridH + MENU_GAP))
        ov:SetPoint("BOTTOMRIGHT", raidcd.menuPage, "BOTTOMRIGHT", -MENU_PAD, MENU_PAD)
        ov:Show()
    end
end

function raidcd.RenderOverview()
    local ACD = LibStub and LibStub("AceConfigDialog-3.0", true)
    if not (ACD and raidcd.overviewContainer) then return false end
    raidcd.rendering = true
    local ok = pcall(ACD.Open, ACD, OVERVIEW_APP, raidcd.overviewContainer)
    if raidcd.PolishFonts then pcall(raidcd.PolishFonts) end
    raidcd.lastOpen = (GetTime and GetTime()) or 0
    raidcd.rendering = nil
    return ok
end

function raidcd.RenderCurrentPage()
    local ACD = LibStub and LibStub("AceConfigDialog-3.0", true)
    if not (ACD and raidcd.pageContainer) then return false end

    local app
    if raidcd.page == "detail" and raidcd.activeKey then
        app = SECTION_APP
    elseif raidcd.page == "search" then
        app = SEARCH_APP
    end
    if not app then return false end

    raidcd.rendering = true
    local ok = pcall(ACD.Open, ACD, app, raidcd.pageContainer)
    raidcd.lastOpen = (GetTime and GetTime()) or 0
    raidcd.rendering = nil

    if ok then
        pcall(raidcd.PolishFonts)
        pcall(function()
            local kids = raidcd.pageContainer.children
            local sf = kids and kids[1]
            if sf and sf.DoLayout then sf:DoLayout() end
        end)
    end
    return ok
end

function raidcd.ShowCategory(key, title)
    local ACD = LibStub and LibStub("AceConfigDialog-3.0", true)
    if not (ACD and raidcd.pageContainer and key) then return end

    raidcd.activeKey, raidcd.activeTitle = key, title
    if raidcd.crumb then raidcd.crumb:SetText(title or "") end
    AkcClearSearchBox()
    raidcd.SetPage("detail")

    local okSt, st = pcall(ACD.GetStatusTable, ACD, SECTION_APP)
    if okSt and type(st) == "table" then
        st.scroll = st.scroll or {}
        st.scroll.offset = 0
        st.scroll.scrollvalue = 0
    end
    if raidcd.RenderCurrentPage() then
        raidcd.fallback:Hide()
    else
        raidcd.fallback:Show()
    end
end

function raidcd.ShowMenuPage()
    raidcd.fallback:Hide()
    raidcd.activeKey, raidcd.activeTitle = nil, nil
    if raidcd.crumb then raidcd.crumb:SetText("") end
    AkcClearSearchBox()
    if raidcd.pageContainer then
        pcall(function() raidcd.pageContainer:ReleaseChildren() end)
    end
    raidcd.SetPage("menu")
    pcall(raidcd.RefreshMenu)
    pcall(raidcd.RenderOverview)
end

function raidcd.HookConfigRefresh()
    if not raidcd.openHooked then
        local ACD = LibStub and LibStub("AceConfigDialog-3.0", true)
        if ACD and hooksecurefunc then
            local okHook = pcall(hooksecurefunc, ACD, "Open", function(_, app)
                if app == SECTION_APP or app == SEARCH_APP or app == OVERVIEW_APP then
                    raidcd.lastOpen = (GetTime and GetTime()) or 0
                end
            end)
            raidcd.openHooked = okHook
        end
    end
    if raidcd.refreshHooked then return end
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not (reg and reg.RegisterCallback) then return end
    local ok = pcall(reg.RegisterCallback, "AkcQOL_SettingsBridge", "ConfigTableChange",
        function(_, appName)
            if appName ~= ROOT_APP then return end
            raidcd.index = nil
            raidcd.cats = nil
            if raidcd.rendering or raidcd.refreshQueued then return end
            if not (raidcd.host and raidcd.host:IsShown()) then return end
            if raidcd.page ~= "detail" and raidcd.page ~= "search" then return end
            raidcd.refreshQueued = true
            local function run()
                raidcd.refreshQueued = nil
                if not (raidcd.host and raidcd.host:IsShown()) then return end
                if raidcd.page ~= "detail" and raidcd.page ~= "search" then return end
                local now = (GetTime and GetTime()) or 0
                if now - (raidcd.lastOpen or 0) < 0.1 then return end
                raidcd.RenderCurrentPage()
            end
            if C_Timer and C_Timer.After then C_Timer.After(0, run) else run() end
        end)
    raidcd.refreshHooked = ok
end

function raidcd.EnsurePageContainer()
    if raidcd.pageContainer then return true end
    local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
    if not (AceGUI and raidcd.detailPage) then return false end
    local ok, container = pcall(function()
        local c = AceGUI:Create("BlizOptionsGroup")
        c.SetTitle = AkcBlankPanelTitle
        c:SetTitle()
        c.frame:SetParent(raidcd.detailPage)
        c.frame:ClearAllPoints()
        c.frame:SetAllPoints(raidcd.detailPage)
        c.frame:Show()
        return c
    end)
    if not (ok and container) then return false end
    raidcd.pageContainer = container
    return true
end

function raidcd.EnsurePages()
    if raidcd.pageContainer then return true end
    local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not (AceGUI and reg) then return false end

    raidcd.rows = raidcd.rows or {}
    if raidcd.topBar then return raidcd.EnsurePageContainer() end

    local bar = CreateFrame("Frame", nil, raidcd.host)
    bar:SetPoint("TOPLEFT", raidcd.host, "TOPLEFT", 0, 0)
    bar:SetPoint("TOPRIGHT", raidcd.host, "TOPRIGHT", 0, 0)
    bar:SetHeight(TOPBAR_H)
    raidcd.topBar = bar

    local back = CreateFrame("Button", nil, bar, "BackdropTemplate")
    back:SetSize(84, 22)
    back:SetPoint("LEFT", bar, "LEFT", 8, 0)
    AkcQOL_Theme.SkinButton(back)
    back.txt = back:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    AkcQOL_Theme.SetFont(back.txt, 13, "", true)
    back.txt:SetPoint("CENTER")
    back.txt:SetText(AkcQOL_Theme.Accent("<") .. "  " .. (L["Back"] or "Back"))
    back.txt:SetTextColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.text))
    back:SetScript("OnClick", function() raidcd.ShowMenuPage() end)
    back:Hide()
    raidcd.backBtn = back

    local crumb = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    AkcQOL_Theme.SetFont(crumb, 15, "", true)
    crumb:SetPoint("LEFT", back, "RIGHT", 14, 0)
    crumb:SetPoint("RIGHT", bar, "RIGHT", -12, 0)
    crumb:SetJustifyH("LEFT")
    crumb:SetWordWrap(false)
    crumb:SetTextColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.text))
    crumb:Hide()
    raidcd.crumb = crumb

    local menu = CreateFrame("Frame", nil, raidcd.host)
    menu:SetPoint("TOPLEFT", raidcd.host, "TOPLEFT", 0, -TOPBAR_H)
    menu:SetPoint("BOTTOMRIGHT", raidcd.host, "BOTTOMRIGHT", 0, 0)
    menu:Hide()
    if menu.SetClipsChildren then menu:SetClipsChildren(true) end
    raidcd.menuPage = menu

    menu:SetScript("OnSizeChanged", function()
        if raidcd.relayoutQueued then return end
        raidcd.relayoutQueued = true
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function()
                raidcd.relayoutQueued = nil
                if raidcd.page == "menu" then
                    pcall(raidcd.RefreshMenu)
                    pcall(raidcd.RenderOverview)
                end
            end)
        else
            raidcd.relayoutQueued = nil
        end
    end)

    local detail = CreateFrame("Frame", nil, raidcd.host)
    detail:SetPoint("TOPLEFT", raidcd.host, "TOPLEFT", 0, -TOPBAR_H)
    detail:SetPoint("BOTTOMRIGHT", raidcd.host, "BOTTOMRIGHT", 0, 0)
    detail:Hide()
    detail:EnableKeyboard(false)
    detail:SetPropagateKeyboardInput(true)
    detail:SetScript("OnKeyDown", function(self, key)
        local locked = InCombatLockdown and InCombatLockdown()
        if key == "ESCAPE" and raidcd.page ~= "menu" then
            if not locked then self:SetPropagateKeyboardInput(false) end
            if C_Timer and C_Timer.After then
                C_Timer.After(0, function()
                    if raidcd.host and raidcd.host:IsShown()
                        and raidcd.page and raidcd.page ~= "menu" then
                        raidcd.ShowMenuPage()
                    end
                end)
            else
                raidcd.ShowMenuPage()
            end
        elseif not locked then
            self:SetPropagateKeyboardInput(true)
        end
    end)
    raidcd.detailPage = detail

    raidcd.sectionOptions = { type = "group", name = "", args = {} }
    if not raidcd.sectionRegistered then
        raidcd.sectionRegistered = pcall(reg.RegisterOptionsTable, reg, SECTION_APP, function()
            local g = raidcd.activeKey and raidcd.GetCategoryGroup(raidcd.activeKey)
            raidcd.sectionOptions.args = (type(g) == "table" and type(g.args) == "table") and g.args or {}
            return raidcd.sectionOptions
        end)
    end

    raidcd.overviewOptions = { type = "group", name = "", args = {} }
    if not raidcd.overviewRegistered then
        raidcd.overviewRegistered = pcall(reg.RegisterOptionsTable, reg, OVERVIEW_APP, function()
            local g = raidcd.GetCategoryGroup(OVERVIEW_KEY)
            raidcd.overviewOptions.args = (type(g) == "table" and type(g.args) == "table") and g.args or {}
            return raidcd.overviewOptions
        end)
    end

    pcall(function()
        local c = AceGUI:Create("BlizOptionsGroup")
        c.SetTitle = AkcBlankPanelTitle
        c:SetTitle()
        c.frame:SetParent(raidcd.menuPage)
        c.frame:ClearAllPoints()
        c.frame:SetPoint("TOPLEFT", raidcd.menuPage, "TOPLEFT", MENU_PAD, -(MENU_PAD + 200))
        c.frame:SetPoint("BOTTOMRIGHT", raidcd.menuPage, "BOTTOMRIGHT", -MENU_PAD, MENU_PAD)
        c.frame:Hide()
        raidcd.overviewContainer = c
    end)

    raidcd.searchOptions = raidcd.searchOptions or { type = "group", name = "", args = {} }
    if not raidcd.searchRegistered then
        raidcd.searchRegistered = pcall(reg.RegisterOptionsTable, reg, SEARCH_APP, function()
            return raidcd.searchOptions
        end)
    end

    return raidcd.EnsurePageContainer()
end

-- Swap to the theme font, reverting when the font fails to load: a fontless
-- FontString throws on its next SetText.
local function AkcSafeSetFont(fs)
    local face, size, flags = fs:GetFont()
    if not face then
        pcall(fs.SetFont, fs, STANDARD_TEXT_FONT or "Fonts\FRIZQT__.TTF", 12, "")
        return
    end
    local target = AkcQOL_Theme.fontPath
    if face == target then return end
    pcall(fs.SetFont, fs, target, math.max(size or 12, 13), "")
    if not fs:GetFont() then
        pcall(fs.SetFont, fs, face, size or 12, flags or "")
    end
end

function raidcd.PolishFonts()
    pcall(function()
        local root = raidcd.pageContainer and raidcd.pageContainer.frame
        if not root then return end
        local restyle
        restyle = function(frame, depth)
            if not frame or depth > 8 then return end
            if frame.GetObjectType and frame:GetObjectType() == "FontString" then
                AkcSafeSetFont(frame)
                return
            end
            if frame.GetRegions then
                local regions = { frame:GetRegions() }
                for i = 1, #regions do
                    local r = regions[i]
                    if r and r.GetObjectType and r:GetObjectType() == "FontString" then
                        AkcSafeSetFont(r)
                    end
                end
            end
            if frame.GetChildren then
                local kids = { frame:GetChildren() }
                for i = 1, #kids do
                    restyle(kids[i], depth + 1)
                end
            end
        end
        restyle(root, 0)
    end)
end

function raidcd.Hide()
    raidcd.activeKey, raidcd.activeTitle = nil, nil
    if raidcd.pageContainer then
        pcall(function() raidcd.pageContainer:ReleaseChildren() end)
    end
    if raidcd.overviewContainer then
        pcall(function() raidcd.overviewContainer:ReleaseChildren() end)
    end
    if raidcd.detailPage then raidcd.detailPage:Hide() end
    if raidcd.menuPage then raidcd.menuPage:Hide() end
    raidcd.page = nil
    raidcd.host:Hide()
end

function raidcd.Show()
    if not raidcd.EnsurePages() then return false end
    raidcd.host:Show()
    pcall(raidcd.EnsureSearchUI)
    pcall(raidcd.HookConfigRefresh)

    raidcd.activeKey, raidcd.activeTitle = nil, nil
    raidcd.index = nil
    raidcd.cats = nil
    AkcClearSearchBox()
    if raidcd.pageContainer then
        pcall(function() raidcd.pageContainer:ReleaseChildren() end)
    end
    raidcd.SetPage("menu")

    local function feed()
        if not raidcd.host:IsShown() then return false end
        local ok, cats = pcall(raidcd.BuildCategoryList)
        if ok and type(cats) == "table" and #cats > 0 then
            raidcd.fallback:Hide()
            raidcd.cats = cats
            local okR, errR = pcall(raidcd.RefreshMenu, cats)
            pcall(raidcd.RenderOverview)
            if not okR then
                raidcd.lastMenuError = tostring(errR)
                if _G.AkcQOL_RecordLuaError then
                    pcall(_G.AkcQOL_RecordLuaError, "Settings Menu", raidcd.lastMenuError, "", "AkcQOL")
                end
            end
            return true
        end
        raidcd.lastError = (not ok) and cats or raidcd.lastError
        return false
    end

    if not feed() then
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function()
                if raidcd.host:IsShown() and not feed() then raidcd.fallback:Show() end
            end)
        else
            raidcd.fallback:Show()
        end
    end
    return true
end

function _G.AkcQOL_RefreshErrorLogButton()
    local count = 0
    local unread = 0
    if _G.AkcQOL_GetLuaErrorCount then
        count = _G.AkcQOL_GetLuaErrorCount() or 0
    end
    if _G.AkcQOL_GetUnreadLuaErrorCount then
        unread = _G.AkcQOL_GetUnreadLuaErrorCount() or 0
    else
        unread = count
    end
    if ErrorAlertBtn and ErrorAlertText then
        if unread > 0 then
            local alertLabel = unread > 99 and "Lua 99+" or ("Lua " .. unread)
            ErrorAlertBtn:SetWidth(unread > 99 and 56 or 48)
            ErrorAlertText:SetText("|cFFFFB4B4" .. alertLabel .. "|r")
            ErrorAlertBtn:Show()
        else
            ErrorAlertBtn:Hide()
        end
    end
end
SettingsFrame:HookScript("OnShow", _G.AkcQOL_RefreshErrorLogButton)
_G.AkcQOL_RefreshErrorLogButton()

RenderSection = function(key)
    activeSection = key
    if raidcd.Available() then
        raidcd.fallback:Hide()
        raidcd.Show()
    else
        raidcd.Hide()
        raidcd.fallback:Show()
    end
end

SettingsFrame:HookScript("OnShow", function() RenderSection(activeSection) end)
SettingsFrame:HookScript("OnHide", function() raidcd.Hide() end)
RenderSection("auto")

end



SLASH_AKCQOLSETTINGS1 = "/akcsettings"
SlashCmdList["AKCQOLSETTINGS"] = function()

    if AkcQOL_ShowLogsWindow then AkcQOL_ShowLogsWindow("settings") end
end

local FilterBtn = CreateFrame("Button", nil, TitleBar)
FilterBtn:SetPoint("RIGHT", LogsBtn, "LEFT", -5, 0)
FilterBtn:SetSize(85, 20)
ErrorAlertBtn:ClearAllPoints()
ErrorAlertBtn:SetPoint("RIGHT", FilterBtn, "LEFT", -6, 0)
local FilterBtnBg = FilterBtn:CreateTexture(nil, "BACKGROUND")
FilterBtnBg:SetAllPoints()
FilterBtnBg:SetTexture(WV_FLAT_TEX)
FilterBtnBg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))
local FilterBtnInner = FilterBtn:CreateTexture(nil, "ARTWORK")
FilterBtnInner:SetPoint("TOPLEFT", 1, -1)
FilterBtnInner:SetPoint("BOTTOMRIGHT", -1, 1)
FilterBtnInner:SetTexture(WV_FLAT_TEX)
FilterBtnInner:SetGradient("VERTICAL",
    CreateColor(0.090, 0.098, 0.118, 1),
    CreateColor(0.130, 0.141, 0.165, 1))
local FilterBtnTopHL = FilterBtn:CreateTexture(nil, "OVERLAY")
FilterBtnTopHL:SetPoint("TOPLEFT", 1, -1)
FilterBtnTopHL:SetPoint("TOPRIGHT", -1, -1)
FilterBtnTopHL:SetHeight(1)
FilterBtnTopHL:SetTexture(WV_FLAT_TEX)
FilterBtnTopHL:SetVertexColor(1, 1, 1, 0.07)
local FilterBtnText = FilterBtn:CreateFontString(nil, "OVERLAY")
AkcQOL_Theme.SetFont(FilterBtnText, 11, "")
FilterBtnText:SetAllPoints()
FilterBtnText:SetText("|cFFE5E7EB" .. L["Characters"] .. "|r")
FilterBtn:SetScript("OnEnter", function()
    FilterBtnInner:SetGradient("VERTICAL",
        CreateColor(0.130, 0.141, 0.165, 1),
        CreateColor(0.180, 0.196, 0.227, 1))
    FilterBtnBg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.borderLight))
end)
FilterBtn:SetScript("OnLeave", function()
    FilterBtnInner:SetGradient("VERTICAL",
        CreateColor(0.090, 0.098, 0.118, 1),
        CreateColor(0.130, 0.141, 0.165, 1))
    FilterBtnBg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))
end)

MatrixStatText:SetPoint("RIGHT", ErrorAlertBtn, "LEFT", -8, 0)

local ResizeGrip = CreateFrame("Button", nil, TrackerFrame)
ResizeGrip:SetSize(24, 24)
ResizeGrip:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 2)
ResizeGrip:SetFrameLevel(TrackerFrame:GetFrameLevel() + 10)

local gripLines = {}
for j = 0, 2 do
    local shadow = ResizeGrip:CreateTexture(nil, "OVERLAY", nil, 0)
    shadow:SetTexture(WV_FLAT_TEX)
    shadow:SetVertexColor(0, 0, 0, 0.6)
    shadow:SetSize(2, (3 - j) * 6)
    shadow:SetPoint("BOTTOMRIGHT", -(j * 6 + 1), 1)
    local line = ResizeGrip:CreateTexture(nil, "OVERLAY", nil, 1)
    line:SetTexture(WV_FLAT_TEX)
    line:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.accent))
    line:SetSize(2, (3 - j) * 6)
    line:SetPoint("BOTTOMRIGHT", -(j * 6 + 2), 2)
    gripLines[#gripLines + 1] = line
end

local function GripTooltip(owner)
    if not GameTooltip then return end
    local pct = math.floor((AkcQOL_Theme.GetTextScale and AkcQOL_Theme.GetTextScale() or 1) * 100 + 0.5)
    GameTooltip:SetOwner(owner, "ANCHOR_TOPLEFT")
    GameTooltip:AddLine("Window size", 1, 1, 1)
    GameTooltip:AddLine("Drag: resize the window.", 0.62, 0.62, 0.70)
    GameTooltip:AddLine("Right-click: cycle text size (now " .. pct .. "%).", 0.62, 0.62, 0.70)
    GameTooltip:Show()
end

ResizeGrip:SetScript("OnEnter", function(self)
    for _, ln in ipairs(gripLines) do ln:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.text)) end
    GripTooltip(self)
end)
ResizeGrip:SetScript("OnLeave", function()
    for _, ln in ipairs(gripLines) do ln:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.accent)) end
    if GameTooltip then GameTooltip:Hide() end
end)

if not AkcQOLDB then AkcQOLDB = {} end
if not AkcQOLDB.global then AkcQOLDB.global = {} end
if not AkcQOLDB.global.panelScale then AkcQOLDB.global.panelScale = 1.0 end

do
    local scaleInit = CreateFrame("Frame")
    scaleInit:RegisterEvent("PLAYER_LOGIN")
    scaleInit:SetScript("OnEvent", function(self)
        self:UnregisterEvent("PLAYER_LOGIN")
        if AkcQOLDB and AkcQOLDB.global and not TrackerFrame.akcqolEmbeddedHost then
            local snapped = _G.AkcQOL_SnapPanelScale and _G.AkcQOL_SnapPanelScale(AkcQOLDB.global.panelScale) or AkcQOLDB.global.panelScale or 1.0
            AkcQOLDB.global.panelScale = snapped
            TrackerFrame:SetScale(snapped)
        end
    end)
end

local isSizing = false
local startCursorX, startCursorY
local startScale

local function SnapPanelScale(scale)
    scale = tonumber(scale) or 1.0
    if scale > 0.95 and scale < 1.05 then return 1.0 end
    return scale
end
_G.AkcQOL_SnapPanelScale = SnapPanelScale

local TEXT_SCALE_STEPS = { 100, 110, 120, 130, 140 }

local function CycleTextScale(self)
    local cur = math.floor((AkcQOL_Theme.GetTextScale and AkcQOL_Theme.GetTextScale() or 1) * 100 + 0.5)
    local nextPct = TEXT_SCALE_STEPS[1]
    if cur < TEXT_SCALE_STEPS[#TEXT_SCALE_STEPS] then
        for _, v in ipairs(TEXT_SCALE_STEPS) do
            if cur < v then nextPct = v break end
        end
    end
    AkcQOL_Theme.SetTextScale(nextPct / 100)
    if self and self:IsMouseOver() then GripTooltip(self) end
    print("|cff8c5cffAkc|r|cffffffffQOL|r: Text size: |cFFF59E0B" .. nextPct .. "%|r")
end

ResizeGrip:SetScript("OnMouseDown", function(self, button)
    if button == "RightButton" then
        CycleTextScale(self)
        return
    end
    if button == "LeftButton" then
        isSizing = true
        startCursorX, startCursorY = GetCursorPosition()
        startScale = TrackerFrame:GetScale()
        self:SetScript("OnUpdate", function()
            if isSizing then

                if not IsMouseButtonDown("LeftButton") then
                    isSizing = false
                    ResizeGrip:SetScript("OnUpdate", nil)

                    local fin = SnapPanelScale(TrackerFrame:GetScale())
                    TrackerFrame:SetScale(fin)
                    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.panelScale = fin end
                    if TrackerFrame.AkcRefreshGrid then TrackerFrame.AkcRefreshGrid() end
                    return
                end
                local currentX, currentY = GetCursorPosition()
                local diff = (currentX - startCursorX) / 400
                local newScale = startScale + diff

                if newScale < 0.6 then newScale = 0.6 end
                if newScale > 2.0 then newScale = 2.0 end

                local screenW = UIParent:GetWidth()
                local screenH = UIParent:GetHeight()
                local frameW = TrackerFrame:GetWidth()
                local frameH = TrackerFrame:GetHeight()
                if frameW > 0 and frameH > 0 then
                    local maxScaleW = screenW / frameW
                    local maxScaleH = screenH / frameH
                    local maxScale = math.min(maxScaleW, maxScaleH)
                    if newScale > maxScale then newScale = maxScale end
                end

                TrackerFrame:SetScale(newScale)
                if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.panelScale = newScale end
            end
        end)
    end
end)

ResizeGrip:SetScript("OnMouseUp", function(self, button)
    isSizing = false
    self:SetScript("OnUpdate", nil)

    local fin = SnapPanelScale(TrackerFrame:GetScale())
    TrackerFrame:SetScale(fin)
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.panelScale = fin end
    if TrackerFrame.AkcRefreshGrid then TrackerFrame.AkcRefreshGrid() end
end)

SLASH_AKCQOLTEXT1 = "/akctext"
SlashCmdList["AKCQOLTEXT"] = function(msg)
    local pct = tonumber((msg or ""):match("(%d+)"))
    if pct then
        local applied = AkcQOL_Theme.SetTextScale(pct / 100)
        print("|cff8c5cffAkc|r|cffffffffQOL|r: Text size: |cFFF59E0B" .. math.floor(applied * 100 + 0.5) .. "%|r")
    else
        local cur = math.floor((AkcQOL_Theme.GetTextScale and AkcQOL_Theme.GetTextScale() or 1) * 100 + 0.5)
        print("|cff8c5cffAkc|r|cffffffffQOL|r: Text size: |cFFF59E0B" .. cur .. "%|r. Usage: /akctext 100-160")
    end
end

local FilterMenu = CreateFrame("Frame", nil, TrackerFrame)
FilterMenu:SetPoint("TOPRIGHT", FilterBtn, "BOTTOMRIGHT", 0, -5)
FilterMenu:SetWidth(300)
FilterMenu:SetFrameStrata("TOOLTIP")
FilterMenu:Hide()

local FilterMenuBG = FilterMenu:CreateTexture(nil, "BACKGROUND")
FilterMenuBG:SetAllPoints()
FilterMenuBG:SetTexture(WV_FLAT_TEX)
do
    local pb = AkcQOL_Theme.colors.panelBg
    FilterMenuBG:SetVertexColor(pb[1], pb[2], pb[3], 0.96)
end

WV_CreateBorder(FilterMenu, "TOPLEFT", "TOPLEFT", "TOPRIGHT", "TOPRIGHT", nil, 1)
WV_CreateBorder(FilterMenu, "BOTTOMLEFT", "BOTTOMLEFT", "BOTTOMRIGHT", "BOTTOMRIGHT", nil, 1)
WV_CreateBorder(FilterMenu, "TOPLEFT", "TOPLEFT", "BOTTOMLEFT", "BOTTOMLEFT", 1, nil)
WV_CreateBorder(FilterMenu, "TOPRIGHT", "TOPRIGHT", "BOTTOMRIGHT", "BOTTOMRIGHT", 1, nil)

FilterMenu.items = {}

local function UpdateTrackerInfo() end

local function GetOrderedChars(charList)
    local order = AkcQOLDB.global.charOrder or {}

    local posMap = {}
    for i, name in ipairs(order) do
        posMap[name] = i
    end

    table.sort(charList, function(a, b)
        local pa, pb = posMap[a], posMap[b]
        if pa and pb then return pa < pb end
        if pa then return true end
        if pb then return false end
        return a < b
    end)
    return charList
end

local function SaveCharOrder(charList)
    AkcQOLDB.global.charOrder = {}
    for i, name in ipairs(charList) do
        AkcQOLDB.global.charOrder[i] = name
    end
end

local function RebuildFilterMenu()
    for _, item in ipairs(FilterMenu.items) do item:Hide() end

    local allChars = {}
    for cName, _ in pairs(AkcQOLDB) do
        if cName ~= "version" and cName ~= "hiddenChars" and cName ~= "global" and cName:find("-", 1, true) then
            table.insert(allChars, cName)
        end
    end
    GetOrderedChars(allChars)

    local mY = -10
    for i, cName in ipairs(allChars) do
        local row = FilterMenu.items[i]
        if not row then
            row = CreateFrame("Frame", nil, FilterMenu)
            row:SetHeight(24)

            row.cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            row.cb:SetSize(22, 22)
            row.cb:SetPoint("LEFT", 10, 0)

            row.text = row:CreateFontString(nil, "OVERLAY")
            AkcQOL_Theme.SetFont(row.text, 11, WV_FONT_FLAGS)
            row.text:SetPoint("LEFT", row.cb, "RIGHT", 4, 0)
            row.text:SetWidth(175)
            row.text:SetJustifyH("LEFT")

            row.upBtn = CreateFrame("Button", nil, row)
            row.upBtn:SetSize(16, 20)
            row.upBtn:SetPoint("RIGHT", row, "RIGHT", -16, 0)
            row.upBtn.text = row.upBtn:CreateFontString(nil, "OVERLAY")
            AkcQOL_Theme.SetFont(row.upBtn.text, 16, "")
            row.upBtn.text:SetPoint("CENTER", 0, 0)
            row.upBtn.text:SetText("|cFF4DE6FF+|r")
            row.upBtn:SetScript("OnEnter", function(self) self.text:SetText("|cFFFFFFFF+|r") end)
            row.upBtn:SetScript("OnLeave", function(self) self.text:SetText("|cFF4DE6FF+|r") end)

            row.downBtn = CreateFrame("Button", nil, row)
            row.downBtn:SetSize(16, 20)
            row.downBtn:SetPoint("LEFT", row.upBtn, "RIGHT", 0, 0)
            row.downBtn.text = row.downBtn:CreateFontString(nil, "OVERLAY")
            AkcQOL_Theme.SetFont(row.downBtn.text, 16, "")
            row.downBtn.text:SetPoint("CENTER", 0, 0)
            row.downBtn.text:SetText("|cFF4DE6FF-|r")
            row.downBtn:SetScript("OnEnter", function(self) self.text:SetText("|cFFFFFFFF-|r") end)
            row.downBtn:SetScript("OnLeave", function(self) self.text:SetText("|cFF4DE6FF-|r") end)

            FilterMenu.items[i] = row
        end

        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", FilterMenu, "TOPLEFT", 0, mY)
        row:SetPoint("TOPRIGHT", FilterMenu, "TOPRIGHT", 0, mY)

        local cColor = (AkcQOLDB[cName] and AkcQOLDB[cName].color) or "ffffffff"
        row.text:SetText(string.format("|c%s%s|r", cColor, cName))
        row.cb:SetChecked(not AkcQOLDB.hiddenChars[cName])

        row.cb:SetScript("OnClick", function(self)
            AkcQOLDB.hiddenChars[cName] = not self:GetChecked()
            UpdateTrackerInfo()
        end)

        local idx = i
        row.upBtn:SetScript("OnClick", function()
            if idx <= 1 then return end
            allChars[idx], allChars[idx - 1] = allChars[idx - 1], allChars[idx]
            SaveCharOrder(allChars)
            RebuildFilterMenu()
            UpdateTrackerInfo()
        end)
        row.upBtn:SetAlpha(i > 1 and 1 or 0.3)

        row.downBtn:SetScript("OnClick", function()
            if idx >= #allChars then return end
            allChars[idx], allChars[idx + 1] = allChars[idx + 1], allChars[idx]
            SaveCharOrder(allChars)
            RebuildFilterMenu()
            UpdateTrackerInfo()
        end)
        row.downBtn:SetAlpha(i < #allChars and 1 or 0.3)

        row:Show()
        mY = mY - 24
    end
    FilterMenu:SetHeight(math.abs(mY) + 10)
end

AkcQOL_CloseMatrixPopups = function(except)
    if except ~= "characters" then
        AkcQOL_SafeHideFrame(FilterMenu)
    end
    if except ~= "settings" then
        AkcQOL_SafeHideFrame(_G.AkcQOLSettingsFrame)
    end
    if except ~= "logs" and AKCQOL_LOGS_FRAME then
        AkcQOL_SafeHideFrame(AKCQOL_LOGS_FRAME)
    end
    if except ~= "export" and AKCQOL_LOG_EXPORT_FRAME then
        AkcQOL_SafeHideFrame(AKCQOL_LOG_EXPORT_FRAME)
    end
end
_G.AkcQOL_CloseMatrixPopups = AkcQOL_CloseMatrixPopups

FilterBtn:SetScript("OnClick", function()
    if AkcQOL_IsFrameOpen(FilterMenu) then
        AkcQOL_SafeHideFrame(FilterMenu)
    else
        AkcQOL_CloseMatrixPopups("characters")
        RebuildFilterMenu()
        AkcQOL_SafeShowFrame(FilterMenu)
    end
end)

tinsert(UISpecialFrames, "WVTrackerFrame")

TrackerFrame:SetScript("OnHide", function()
    if TrackerFrame.akcqolEmbeddedHost then
        if not TrackerFrame.akcqolDetaching then
            local host = TrackerFrame.akcqolEmbeddedHost
            C_Timer.After(0, function()
                if host and host.IsShown and host:IsShown() and host.activeTab == "matrix" then
                    AkcQOL_SafeShowFrame(TrackerFrame)
                end
            end)
        end
        return
    end
    AkcQOL_CloseMatrixPopups()
end)

local SCROLLBAR_WIDTH = 12
local ScrollFrame = CreateFrame("ScrollFrame", nil, TrackerFrame)
ScrollFrame:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 2, -31)
ScrollFrame:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -(SCROLLBAR_WIDTH + 6), 4)
ScrollFrame:EnableMouse(true)
ScrollFrame:RegisterForDrag("LeftButton")
ScrollFrame:SetScript("OnDragStart", function() TrackerFrame:StartMoving() end)
ScrollFrame:SetScript("OnDragStop", function() TrackerFrame:StopMovingOrSizing() end)
ScrollFrame:EnableMouseWheel(true)

local scrollTrack = CreateFrame("Frame", nil, TrackerFrame)
scrollTrack:SetWidth(SCROLLBAR_WIDTH)
scrollTrack:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", -2, -32)
scrollTrack:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 5)
local scrollTrackBg = scrollTrack:CreateTexture(nil, "BACKGROUND")
scrollTrackBg:SetAllPoints()
scrollTrackBg:SetTexture(WV_FLAT_TEX)
do
    local ic = AkcQOL_Theme.colors.insetBg
    scrollTrackBg:SetVertexColor(ic[1], ic[2], ic[3], 0.55)
end

local scrollThumb = CreateFrame("Button", nil, scrollTrack)
scrollThumb:SetWidth(SCROLLBAR_WIDTH)
scrollThumb:SetHeight(40)
scrollThumb:SetPoint("TOP", scrollTrack, "TOP", 0, 0)
local thumbTex = scrollThumb:CreateTexture(nil, "ARTWORK")
thumbTex:SetAllPoints()
thumbTex:SetTexture(WV_FLAT_TEX)
thumbTex:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))

scrollThumb:SetScript("OnEnter", function() thumbTex:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.borderLight)) end)
scrollThumb:SetScript("OnLeave", function()
    if not scrollThumb.isDragging then thumbTex:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border)) end
end)

local function UpdateScrollbar()
    local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
    local trackH = scrollTrack:GetHeight()
    if trackH <= 0 then trackH = 1 end

    if maxScroll <= 0 then
        scrollThumb:Hide()
        return
    end
    scrollThumb:Show()

    local visibleH = ScrollFrame:GetHeight()
    local contentH = visibleH + maxScroll
    local thumbH = math.max(20, math.floor((visibleH / contentH) * trackH))
    scrollThumb:SetHeight(thumbH)

    local scrollPos = ScrollFrame:GetVerticalScroll()
    local scrollFrac = scrollPos / maxScroll
    local travel = trackH - thumbH
    local thumbY = -math.floor(scrollFrac * travel)
    scrollThumb:ClearAllPoints()
    scrollThumb:SetPoint("TOP", scrollTrack, "TOP", 0, thumbY)
end

ScrollFrame:SetScript("OnMouseWheel", function(self, delta)
    local current = self:GetVerticalScroll()
    local maxScroll = self:GetVerticalScrollRange() or 0
    local new = current - (delta * 30)
    if new < 0 then new = 0 end
    if new > maxScroll then new = maxScroll end
    self:SetVerticalScroll(new)
    UpdateScrollbar()
end)

scrollTrack:EnableMouseWheel(true)
scrollTrack:SetScript("OnMouseWheel", function(_, delta)
    local current = ScrollFrame:GetVerticalScroll()
    local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
    local new = current - (delta * 30)
    if new < 0 then new = 0 end
    if new > maxScroll then new = maxScroll end
    ScrollFrame:SetVerticalScroll(new)
    UpdateScrollbar()
end)

scrollThumb:SetMovable(true)
scrollThumb:EnableMouse(true)
scrollThumb:RegisterForDrag("LeftButton")
scrollThumb:SetScript("OnDragStart", function(self)
    self.isDragging = true
    thumbTex:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.accent))
    local _, _, _, _, startY = self:GetPoint()
    self.dragStartY = startY
    self.dragStartCursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
    self:SetScript("OnUpdate", function(button)
        if not button.isDragging then return end
        local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
        local deltaY = button.dragStartCursorY - cursorY
        local trackH = scrollTrack:GetHeight()
        local thumbH = button:GetHeight()
        local travel = trackH - thumbH
        if travel <= 0 then return end

        local newThumbY = button.dragStartY - deltaY
        if newThumbY > 0 then newThumbY = 0 end
        if newThumbY < -travel then newThumbY = -travel end

        local scrollFrac = (-newThumbY) / travel
        local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
        ScrollFrame:SetVerticalScroll(scrollFrac * maxScroll)

        button:ClearAllPoints()
        button:SetPoint("TOP", scrollTrack, "TOP", 0, newThumbY)
    end)
end)
scrollThumb:SetScript("OnDragStop", function(self)
    self.isDragging = false
    self:SetScript("OnUpdate", nil)
    thumbTex:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.border))
end)

scrollTrack:EnableMouse(true)
scrollTrack:SetScript("OnMouseDown", function(self, button)
    if button ~= "LeftButton" then return end
    local _, cursorY = GetCursorPosition()
    cursorY = cursorY / UIParent:GetEffectiveScale()
    local trackTop = self:GetTop()
    if not trackTop then return end
    local clickOffset = trackTop - cursorY
    local trackH = self:GetHeight()
    local thumbH = scrollThumb:GetHeight()
    local travel = trackH - thumbH
    if travel <= 0 then return end

    local thumbCenter = clickOffset - thumbH / 2
    if thumbCenter < 0 then thumbCenter = 0 end
    if thumbCenter > travel then thumbCenter = travel end
    local scrollFrac = thumbCenter / travel
    local maxScroll = ScrollFrame:GetVerticalScrollRange() or 0
    ScrollFrame:SetVerticalScroll(scrollFrac * maxScroll)
    UpdateScrollbar()
end)

C_Timer.NewTicker(0.5, function()
    if TrackerFrame:IsShown() then
        UpdateScrollbar()
    end
end)

local ContentFrame = CreateFrame("Frame", nil, ScrollFrame)
ContentFrame:SetSize(750, 800)
ScrollFrame:SetScrollChild(ContentFrame)

ContentFrame.fsList = {}
ContentFrame.rectList = {}

local DeferMatrixLayout

local function AkcQOL_RestoreStandaloneMatrixLayout()
    if InCombatLockdown() then
        if DeferMatrixLayout then DeferMatrixLayout("restore") end
        return
    end
    TrackerFrame:SetParent(UIParent)
    TrackerFrame:ClearAllPoints()
    TrackerFrame:SetPoint("CENTER")
    TrackerFrame:SetSize(600, 450)
    TrackerFrame:SetScale((AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.panelScale) or 1.0)
    TrackerFrame:SetMovable(true)
    TrackerFrame:SetResizable(true)
    TrackerFrame:RegisterForDrag("LeftButton")
    TrackerFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    TrackerFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

    TitleBar:Show()
    titleSep:Show()
    ResizeGrip:Show()

    ScrollFrame:ClearAllPoints()
    ScrollFrame:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 2, -31)
    ScrollFrame:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -(SCROLLBAR_WIDTH + 6), 4)
    ScrollFrame:RegisterForDrag("LeftButton")
    ScrollFrame:SetScript("OnDragStart", function() TrackerFrame:StartMoving() end)
    ScrollFrame:SetScript("OnDragStop", function() TrackerFrame:StopMovingOrSizing() end)

    scrollTrack:ClearAllPoints()
    scrollTrack:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", -2, -32)
    scrollTrack:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 5)
end

local pendingMatrixLayout
local matrixLayoutWatcher = CreateFrame("Frame")
matrixLayoutWatcher:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_REGEN_ENABLED")
    local pending = pendingMatrixLayout
    pendingMatrixLayout = nil
    if not pending then return end
    if pending.mode == "attach" then
        if pending.host then _G.AkcQOL_AttachMatrixToMain(pending.host) end
    else
        AkcQOL_RestoreStandaloneMatrixLayout()
    end
end)

DeferMatrixLayout = function(mode, host)
    pendingMatrixLayout = { mode = mode, host = host }
    matrixLayoutWatcher:RegisterEvent("PLAYER_REGEN_ENABLED")
end

function _G.AkcQOL_AttachMatrixToMain(host)
    if not host or not TrackerFrame then return end
    if InCombatLockdown() then
        DeferMatrixLayout("attach", host)
        return
    end
    pendingMatrixLayout = nil
    TrackerFrame.akcqolEmbeddedHost = host
    TrackerFrame:SetParent(host)
    TrackerFrame:ClearAllPoints()
    TrackerFrame:SetPoint("TOPLEFT", host, "TOPLEFT", 74, -50)
    TrackerFrame:SetPoint("BOTTOMRIGHT", host, "BOTTOMRIGHT", -14, 12)
    TrackerFrame:SetScale(1)
    TrackerFrame:SetFrameStrata(host:GetFrameStrata())
    TrackerFrame:SetFrameLevel(host:GetFrameLevel() + 4)
    TrackerFrame:SetMovable(false)
    TrackerFrame:SetResizable(false)
    pcall(TrackerFrame.RegisterForDrag, TrackerFrame)
    TrackerFrame:SetScript("OnDragStart", nil)
    TrackerFrame:SetScript("OnDragStop", nil)

    TitleBar:Hide()
    titleSep:Hide()
    ResizeGrip:Hide()

    ScrollFrame:ClearAllPoints()
    ScrollFrame:SetPoint("TOPLEFT", TrackerFrame, "TOPLEFT", 2, -2)
    ScrollFrame:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -(SCROLLBAR_WIDTH + 6), 4)
    pcall(ScrollFrame.RegisterForDrag, ScrollFrame)
    ScrollFrame:SetScript("OnDragStart", nil)
    ScrollFrame:SetScript("OnDragStop", nil)

    scrollTrack:ClearAllPoints()
    scrollTrack:SetPoint("TOPRIGHT", TrackerFrame, "TOPRIGHT", -2, -3)
    scrollTrack:SetPoint("BOTTOMRIGHT", TrackerFrame, "BOTTOMRIGHT", -2, 5)

    RequestRaidInfo()
    C_MythicPlus.RequestRewards()
    C_MythicPlus.RequestMapInfo()
    AkcQOL_SafeShowFrame(TrackerFrame)
    C_Timer.After(0.1, function()
        if TrackerFrame.akcqolEmbeddedHost == host and UpdateTrackerInfo then
            UpdateTrackerInfo()
        end
    end)
end

function _G.AkcQOL_DetachMatrixFromMain(host)
    if not TrackerFrame or not TrackerFrame.akcqolEmbeddedHost then return end
    if host and TrackerFrame.akcqolEmbeddedHost ~= host then return end
    TrackerFrame.akcqolDetaching = true
    AkcQOL_SafeHideFrame(TrackerFrame)
    TrackerFrame.akcqolEmbeddedHost = nil
    TrackerFrame.akcqolDetaching = nil
    AkcQOL_RestoreStandaloneMatrixLayout()
end

function _G.AkcQOL_ToggleMatrixCharacters(anchor)
    if not FilterMenu or not anchor then return end
    if AkcQOL_IsFrameOpen(FilterMenu) then
        AkcQOL_SafeHideFrame(FilterMenu)
        return
    end
    if _G.AkcQOLSettingsFrame then AkcQOL_SafeHideFrame(_G.AkcQOLSettingsFrame) end
    RebuildFilterMenu()
    FilterMenu:SetParent(UIParent)
    FilterMenu:SetFrameStrata("TOOLTIP")
    FilterMenu:SetFrameLevel(1000)
    FilterMenu:SetScale((AKCQOL_LOGS_FRAME and AKCQOL_LOGS_FRAME.GetScale and AKCQOL_LOGS_FRAME:GetScale()) or 1)
    if FilterMenu.SetToplevel then FilterMenu:SetToplevel(true) end
    FilterMenu:ClearAllPoints()
    FilterMenu:SetPoint("TOPRIGHT", anchor, "BOTTOMRIGHT", 0, -6)
    AkcQOL_SafeShowFrame(FilterMenu)
    if FilterMenu.Raise then FilterMenu:Raise() end
end

_G.AkcQOLMatrix_FilterMenu = FilterMenu

local function GetDungeonBanner(dName)
    if not AkcQOLDB.global.bannerCache then AkcQOLDB.global.bannerCache = {} end
    if AkcQOLDB.global.bannerCache[dName] then
        return AkcQOLDB.global.bannerCache[dName]
    end

    for i = 1, 2500 do
        local name, _, _, buttonImage = EJ_GetInstanceInfo(i)
        if name and buttonImage then
            AkcQOLDB.global.bannerCache[name] = buttonImage
        end
    end

    return AkcQOLDB.global.bannerCache[dName] or 134400
end

local dungeonTeleportCache = nil

local DUNGEON_TELEPORT_FALLBACKS = {
    [402] = { dungeon = "Algeth'ar Academy",      name = "Path of the Draconic Diploma", id = 393273 },
    [558] = { dungeon = "Magisters' Terrace",     name = "Path of Devoted Magistry", id = 1254572 },
    [560] = { dungeon = "Maisara Caverns",        name = "Path of Cavernous Depths", id = 1254559 },
    [559] = { dungeon = "Nexus-Point Xenas",      name = "Path of the Fractured Core", id = 1254563 },
    [556] = { dungeon = "Pit of Saron",           name = "Path of Unyielding Blight", id = 1254555 },
    [239] = { dungeon = "Seat of the Triumvirate", name = "Path of Dark Dereliction", id = 1254551 },
    [161] = { dungeon = "Skyreach",               name = "Path of the Skies", id = 159898 },
    [557] = { dungeon = "Windrunner Spire",       name = "Path of the Windrunners", id = 1254400 },
}

local function AkcQOL_GetDungeonDisplayName(dMapID)
    if not dMapID then return nil end
    if C_ChallengeMode and C_ChallengeMode.GetMapUIInfo then
        local ok, n = pcall(C_ChallengeMode.GetMapUIInfo, dMapID)
        if ok and type(n) == "string" and n ~= "" then return n end
    end
    local fb = DUNGEON_TELEPORT_FALLBACKS[dMapID]
    return (fb and fb.dungeon) or ("Map " .. tostring(dMapID))
end

local dungeonIconCache = {}
function _G.AkcQOL_GetDungeonIcon(engName)
    if type(engName) ~= "string" or engName == "" then return nil end
    local cached = dungeonIconCache[engName]
    if cached ~= nil then
        return cached or nil
    end
    local mapID
    for id, fb in pairs(DUNGEON_TELEPORT_FALLBACKS) do
        if fb.dungeon == engName then mapID = id break end
    end
    local icon
    if mapID and C_ChallengeMode and C_ChallengeMode.GetMapUIInfo then
        local ok, _, _, _, tex = pcall(C_ChallengeMode.GetMapUIInfo, mapID)
        if ok and tex and tex ~= 0 then icon = tex end
    end
    dungeonIconCache[engName] = icon or false
    return icon
end

local function AkcQOL_GetTeleportSpellBanks()
    local banks = {}
    if Enum and Enum.SpellBookSpellBank then
        if Enum.SpellBookSpellBank.Player then
            banks[#banks + 1] = Enum.SpellBookSpellBank.Player
        end
        if Enum.SpellBookSpellBank.General then
            banks[#banks + 1] = Enum.SpellBookSpellBank.General
        end
    end
    return banks
end

local function AkcQOL_SpellIDMatches(a, b)
    local numA = tonumber(a)
    local numB = tonumber(b)
    return numA and numB and numA == numB
end

local function AkcQOL_SpellBookContainsCurrentCharSpell(spellID)
    if not spellID or not C_SpellBook or not C_SpellBook.GetSpellBookItemInfo then return false end

    for _, bank in ipairs(AkcQOL_GetTeleportSpellBanks()) do
        for slot = 1, 5000 do
            local ok, info = pcall(C_SpellBook.GetSpellBookItemInfo, slot, bank)
            if not ok or not info then break end
            if AkcQOL_SpellIDMatches(info.spellID, spellID) then
                return true
            end
        end
    end

    return false
end

local function AkcQOL_IsKnownTeleportSpell(spellID)
    if not spellID then return false end

    if C_SpellBook and C_SpellBook.FindSpellBookSlotForSpell then
        local ok, slot = pcall(C_SpellBook.FindSpellBookSlotForSpell, spellID)
        if ok and tonumber(slot or 0) > 0 then return true end
    end

    if type(IsPlayerSpell) == "function" then
        local ok, known = pcall(IsPlayerSpell, spellID)
        if ok and known then return true end
    end

    if type(IsSpellKnownOrOverridesKnown) == "function" then
        local ok, known = pcall(IsSpellKnownOrOverridesKnown, spellID)
        if ok and known then return true end
    end

    if type(IsSpellKnown) == "function" then
        local ok, known = pcall(IsSpellKnown, spellID)
        if ok and known then return true end
    end

    if C_SpellBook then
        for _, bank in ipairs(AkcQOL_GetTeleportSpellBanks()) do
            if C_SpellBook.IsSpellKnown then
                local ok, known = pcall(C_SpellBook.IsSpellKnown, spellID, bank)
                if ok and known then return true end
            end
        end
    end

    return AkcQOL_SpellBookContainsCurrentCharSpell(spellID)
end

local function BuildDungeonTeleportCache()
    dungeonTeleportCache = {}

    local found = {}
    for _, bank in ipairs(AkcQOL_GetTeleportSpellBanks()) do
        local i = 1
        while i < 5000 do
            local ok, info = pcall(C_SpellBook.GetSpellBookItemInfo, i, bank)
            if not ok or not info then break end
            if info.spellID then
                local ok2, desc = pcall(C_Spell.GetSpellDescription, info.spellID)
                if ok2 and desc and desc ~= "" then
                    local descLower = desc:lower()
                    if descLower:find("teleport") and descLower:find("entrance") then
                        local spellInfo = C_Spell.GetSpellInfo(info.spellID)
                        if spellInfo and spellInfo.name then
                            found[#found + 1] = {
                                desc = descLower,
                                name = spellInfo.name,
                                id = info.spellID,
                            }
                        end
                    end
                end
            end
            i = i + 1
        end
    end

    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    if not AkcQOLDB.global.dungeonTeleports then AkcQOLDB.global.dungeonTeleports = {} end

    for dMapID, fallback in pairs(DUNGEON_TELEPORT_FALLBACKS) do
        if not dungeonTeleportCache[dMapID] and AkcQOL_IsKnownTeleportSpell(fallback.id) then
            dungeonTeleportCache[dMapID] = { name = fallback.name, id = fallback.id, known = true }
            AkcQOLDB.global.dungeonTeleports[dMapID] = { name = fallback.name, id = fallback.id }
        end
    end

    for _, spell in ipairs(found) do
        for dMapID in pairs(DUNGEON_TELEPORT_FALLBACKS) do

            local dName = AkcQOL_GetDungeonDisplayName(dMapID)
            if dName and spell.desc:find(dName:lower(), 1, true) then
                dungeonTeleportCache[dMapID] = { name = spell.name, id = spell.id, known = true }
                AkcQOLDB.global.dungeonTeleports[dMapID] = { name = spell.name, id = spell.id }
            end
        end
    end
end

local function GetDungeonTeleportSpell(dungeonMapID)
    if not dungeonTeleportCache then
        BuildDungeonTeleportCache()
    end
    local record = dungeonTeleportCache[dungeonMapID]
    if type(record) == "string" then record = { name = record } end
    if type(record) ~= "table" then return false end
    if not record.known then return false end

    local spellName = record.name
    local spellID = record.id
    if spellID then
        local spellInfo = C_Spell.GetSpellInfo(spellID)
        if spellInfo and spellInfo.name and spellInfo.name ~= "" then
            spellName = spellInfo.name
        end
    end
    if not spellName or spellName == "" then return false end

    return spellName, spellID
end

function AkcQOL_FormatTeleportCooldown(seconds)
    seconds = math.max(0, math.ceil(tonumber(seconds) or 0))
    if seconds >= 3600 then
        return string.format("%dh %02dm", math.floor(seconds / 3600), math.floor((seconds % 3600) / 60))
    elseif seconds >= 60 then
        return string.format("%dm %02ds", math.floor(seconds / 60), seconds % 60)
    end
    return string.format("%ds", seconds)
end

function AkcQOL_GetTeleportCooldownRemaining(spellID, spellName)
    local spell = spellID or spellName
    if not spell then return 0 end

    local startTime, duration, isEnabled, modRate
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok, cdInfo = pcall(C_Spell.GetSpellCooldown, spell)
        if ok and type(cdInfo) == "table" then
            startTime = tonumber(cdInfo.startTime or cdInfo.start or 0) or 0
            duration = tonumber(cdInfo.duration or 0) or 0
            isEnabled = cdInfo.isEnabled
            modRate = tonumber(cdInfo.modRate or 1) or 1
        end
    end

    if (not duration or duration <= 0) and type(GetSpellCooldown) == "function" then
        local ok, s, d, e, m = pcall(GetSpellCooldown, spell)
        if ok then
            startTime = tonumber(s or 0) or 0
            duration = tonumber(d or 0) or 0
            isEnabled = e
            modRate = tonumber(m or 1) or 1
        end
    end

    if isEnabled == false or isEnabled == 0 then return 0 end
    if not startTime or not duration or startTime <= 0 or duration <= 2 then return 0 end

    local now = type(GetTime) == "function" and GetTime() or 0
    local remaining = duration - ((now - startTime) * (modRate > 0 and modRate or 1))
    return remaining > 1 and remaining or 0
end

function AkcQOL_ApplyTeleportButtonState(btn)
    if not btn then return end

    local remaining = AkcQOL_GetTeleportCooldownRemaining(btn.spellID, btn.spellDisplayName)
    btn.teleportCooldownRemaining = remaining
    btn.teleportOnCooldown = remaining > 0

    if btn.teleportOnCooldown then
        if type(InCombatLockdown) ~= "function" or not InCombatLockdown() then
            btn:SetAttribute("type", nil)
            btn:SetAttribute("type1", nil)
            btn:SetAttribute("spell", nil)
            btn:SetAttribute("spell1", nil)
        end
        if btn.portalIcon then
            if btn.portalIcon.SetDesaturated then pcall(btn.portalIcon.SetDesaturated, btn.portalIcon, true) end
            btn.portalIcon:SetVertexColor(0.72, 0.72, 0.72, 1)
            btn.portalIcon:SetAlpha(0.45)
        end
        if btn.cooldownText then
            btn.cooldownText:SetText(AkcQOL_FormatTeleportCooldown(remaining))
            btn.cooldownText:Show()
        end
    else
        if type(InCombatLockdown) ~= "function" or not InCombatLockdown() then
            local tpCastSpell = btn.spellID or btn.spellDisplayName
            btn:SetAttribute("type", "spell")
            btn:SetAttribute("type1", "spell")
            btn:SetAttribute("spell", tpCastSpell)
            btn:SetAttribute("spell1", tpCastSpell)
        end
        if btn.portalIcon then
            if btn.portalIcon.SetDesaturated then pcall(btn.portalIcon.SetDesaturated, btn.portalIcon, false) end
            btn.portalIcon:SetVertexColor(1, 1, 1, 1)
            btn.portalIcon:SetAlpha(0.85)
        end
        if btn.cooldownText then
            btn.cooldownText:SetText("")
            btn.cooldownText:Hide()
        end
    end
end

local tpCacheFrame = CreateFrame("Frame")
tpCacheFrame:RegisterEvent("SPELLS_CHANGED")
tpCacheFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
tpCacheFrame:SetScript("OnEvent", function() dungeonTeleportCache = nil end)

local teleportSecureHost = CreateFrame("Frame", "AkcQOLTeleportSecureHost", ContentFrame)
teleportSecureHost:SetAllPoints(ContentFrame)

local function AkcQOL_EnsureTeleportDriver()
    if teleportSecureHost.akcqolDriverSet then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    if type(RegisterStateDriver) == "function"
        and pcall(RegisterStateDriver, teleportSecureHost, "visibility", "[combat] hide; show") then
        teleportSecureHost.akcqolDriverSet = true
    end
end
AkcQOL_EnsureTeleportDriver()

local teleportBtnPool = {}
local teleportBtnCount = 0

local function AkcQOL_CloseMatrixAfterTeleport()
    if GameTooltip then GameTooltip:Hide() end
    if FilterMenu then AkcQOL_SafeHideFrame(FilterMenu) end
    if _G.AkcQOLSettingsFrame then AkcQOL_SafeHideFrame(_G.AkcQOLSettingsFrame) end

    if AKCQOL_LOGS_FRAME and AkcQOL_IsFrameOpen(AKCQOL_LOGS_FRAME) then
        AkcQOL_SafeHideFrame(AKCQOL_LOGS_FRAME)
    end

    if TrackerFrame and AkcQOL_IsFrameOpen(TrackerFrame) then
        AkcQOL_SafeHideFrame(TrackerFrame)
    end
end

local function GetOrCreateTeleportBtn(parent)
    teleportBtnCount = teleportBtnCount + 1
    local btn = teleportBtnPool[teleportBtnCount]
    if not btn then
        btn = CreateFrame("Button", "AkcQOLTeleportBtn" .. teleportBtnCount, parent, "SecureActionButtonTemplate")
        btn:SetAttribute("type", "spell")
        btn:SetAttribute("type1", "spell")
        btn:SetAttribute("useOnKeyDown", false)
        btn:SetAttribute("pressAndHoldAction", false)
        btn:RegisterForClicks("AnyUp", "AnyDown")
        btn:EnableMouse(true)

        btn:SetHighlightTexture("Interface\\Buttons\\WHITE8X8")
        btn:GetHighlightTexture():SetVertexColor(0.2, 0.7, 1.0, 0.12)

        btn.portalIcon = btn:CreateTexture(nil, "OVERLAY")
        btn.portalIcon:SetSize(14, 14)
        btn.portalIcon:SetAtlas("Taxi_Frame_Green")
        btn.portalIcon:SetAlpha(0.85)

        btn.cooldownText = btn:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        AkcQOL_Theme.SetFont(btn.cooldownText, 10, "")
        btn.cooldownText:SetTextColor(1.0, 0.82, 0.24, 1)
        btn.cooldownText:SetShadowOffset(1, -1)
        btn.cooldownText:SetShadowColor(0, 0, 0, 1)
        btn.cooldownText:SetJustifyH("LEFT")
        btn.cooldownText:SetWidth(64)
        btn.cooldownText:Hide()

        btn:SetScript("OnEnter", function(self)
            AkcQOL_ApplyTeleportButtonState(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(L["Teleport"], 0.33, 0.87, 1)
            GameTooltip:AddLine(self.spellDisplayName or "", 0.7, 0.7, 0.7)
            if self.teleportOnCooldown then
                GameTooltip:AddLine(L["Cooldown: "] .. AkcQOL_FormatTeleportCooldown(self.teleportCooldownRemaining or 0), 1, 0.82, 0.24)
            else
                GameTooltip:AddLine(L["Click to teleport"], 0.5, 0.5, 0.5)
            end
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        btn:SetScript("PostClick", function(self)
            if self.teleportOnCooldown then return end
            if C_Timer and C_Timer.After then
                C_Timer.After(0.6, AkcQOL_CloseMatrixAfterTeleport)
            else
                AkcQOL_CloseMatrixAfterTeleport()
            end
        end)
        teleportBtnPool[teleportBtnCount] = btn
    end
    return btn
end

C_Timer.NewTicker(1, function()
    if not TrackerFrame:IsShown() then return end
    for i = 1, #teleportBtnPool do
        local button = teleportBtnPool[i]
        if button and button:IsShown() then
            AkcQOL_ApplyTeleportButtonState(button)
        end
    end
end)

local teleportCombatWatcher = CreateFrame("Frame")
teleportCombatWatcher:SetScript("OnEvent", function(self)
    self:UnregisterEvent("PLAYER_REGEN_ENABLED")
    if TrackerFrame and TrackerFrame:IsShown() and TrackerFrame.AkcRefreshGrid then
        TrackerFrame.AkcRefreshGrid()
    end
end)

local function HideAllTeleportBtns()

    if InCombatLockdown() then
        teleportCombatWatcher:RegisterEvent("PLAYER_REGEN_ENABLED")
        return
    end

    for i = 1, #teleportBtnPool do
        if teleportBtnPool[i] then teleportBtnPool[i]:Hide() end
    end
    teleportBtnCount = 0
end

UpdateTrackerInfo = function()
    TrackerFrame.AkcRefreshGrid = UpdateTrackerInfo
    SaveCurrentCharacterData()
    HideAllTeleportBtns()

    for _, fs in ipairs(ContentFrame.fsList) do fs:Hide() end
    for _, rect in ipairs(ContentFrame.rectList) do rect:Hide() end
    local fsIdx, rectIdx = 1, 1

    local function DrawText(txt, x, y, w, align, font, wrap)
        local fs = ContentFrame.fsList[fsIdx]
        if not fs then
            fs = ContentFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            ContentFrame.fsList[fsIdx] = fs
        end
        fsIdx = fsIdx + 1
        fs:SetFontObject(font or "GameFontHighlightSmall")

        local _, fontH = fs:GetFont()
        fontH = math.max(fontH or 10, font == "GameFontNormal" and 13 or 12)
        local ps = TrackerFrame:GetScale() or 1
        if ps < 1 then
            fontH = math.min(math.floor(fontH / ps + 0.5), fontH + 5)
        end
        AkcQOL_Theme.SetFont(fs, fontH, "", font == "GameFontNormal")
        fs:SetTextColor(0.898, 0.906, 0.922, 1)
        fs:SetWordWrap(wrap == true)
        fs:SetNonSpaceWrap(false)
        fs:SetText(txt)
        fs:ClearAllPoints()
        fs:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", x, y)
        if w then fs:SetWidth(w) end
        fs:SetJustifyH(align)
        fs:Show()
    end

    local function DrawRect(x, y, w, h, r, g, b, a, layer)
        local rect = ContentFrame.rectList[rectIdx]
        if not rect then
            rect = ContentFrame:CreateTexture(nil, layer or "BACKGROUND")
            ContentFrame.rectList[rectIdx] = rect
        end
        rectIdx = rectIdx + 1
        rect:SetDrawLayer(layer or "BACKGROUND")
        rect:SetTexCoord(0, 1, 0, 1)
        rect:SetVertexColor(1, 1, 1, 1)
        rect:SetColorTexture(r, g, b, a)
        rect:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", x, y)
        rect:SetSize(w, h)
        rect:Show()
        return rect
    end

    local function DrawArt(x, y, w, h, texture, layer)
        local rect = ContentFrame.rectList[rectIdx]
        if not rect then
            rect = ContentFrame:CreateTexture(nil, layer or "ARTWORK")
            ContentFrame.rectList[rectIdx] = rect
        end
        rectIdx = rectIdx + 1
        rect:SetDrawLayer(layer or "ARTWORK", 2)
        rect:SetTexCoord(0, 1, 0, 1)
        rect:SetVertexColor(1, 1, 1, 1)
        rect:SetTexture(texture)
        rect:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", x, y)
        rect:SetSize(w, h)
        rect:Show()
        return rect
    end

    if not AkcQOLDB then return end

    local function hasRealmKey(key)
        return key and key:find("-", 1, true)
    end

    local visibleChars = {}
    local allRaids, allDungeons = {}, {}
    local maxKeys = 0

    for char, data in pairs(AkcQOLDB) do
        if char ~= "version" and char ~= "hiddenChars" and char ~= "global" and hasRealmKey(char) then
            if not AkcQOLDB.hiddenChars[char] then
                table.insert(visibleChars, char)
                for rName, _ in pairs(data.raids or {}) do allRaids[rName] = true end

                for dMapID, _ in pairs(data.dungeons or {}) do
                    if type(dMapID) == "number" then allDungeons[dMapID] = true end
                end
                if #(data.topKeys or {}) > maxKeys then maxKeys = #(data.topKeys or {}) end
            end
        end
    end
    GetOrderedChars(visibleChars)

    local raidList, dungeonList = {}, {}
    for k in pairs(allRaids) do table.insert(raidList, k) end
    for k in pairs(allDungeons) do table.insert(dungeonList, k) end
    table.sort(raidList)

    table.sort(dungeonList, function(a, b)
        return (AkcQOL_GetDungeonDisplayName(a) or "") < (AkcQOL_GetDungeonDisplayName(b) or "")
    end)

    local nameW = 232

    local minCharColW = TrackerFrame.akcqolEmbeddedHost and 100 or 116
    local calculatedGridW = nameW + (#visibleChars * minCharColW)

    local embeddedVisibleW = TrackerFrame.akcqolEmbeddedHost and math.max(760, math.floor((ScrollFrame:GetWidth() or 760) - 2)) or 760
    local gridW = math.max(embeddedVisibleW, calculatedGridW)
    local colW = (gridW - nameW) / math.max(1, #visibleChars)

    if not InCombatLockdown() then
        if not TrackerFrame.akcqolEmbeddedHost then
            TrackerFrame:SetWidth(gridW + SCROLLBAR_WIDTH + 8)
        end
        ContentFrame:SetWidth(gridW)
    end

    local startY = 0
    local currentY = startY

    if not AkcQOLDB.global.sectionCollapsed then AkcQOLDB.global.sectionCollapsed = {} end
    local secCol = AkcQOLDB.global.sectionCollapsed

    if not AkcQOLDB.global.charInfoVisible then
        AkcQOLDB.global.charInfoVisible = { level = true, ilvl = true, rating = true, keystone = true, cofferKeys = true, catalyst = true }
    end
    local civ = AkcQOLDB.global.charInfoVisible

    if not ContentFrame.sectionToggles then ContentFrame.sectionToggles = {} end
    for _, btn in pairs(ContentFrame.sectionToggles) do btn:Hide() end
    if ContentFrame.charInfoSettingsBtn then ContentFrame.charInfoSettingsBtn:Hide() end

    local function GetSectionToggle(key)
        if ContentFrame.sectionToggles[key] then return ContentFrame.sectionToggles[key] end
        local btn = CreateFrame("Button", nil, ContentFrame)
        btn:EnableMouse(true)
        btn.hl = btn:CreateTexture(nil, "HIGHLIGHT")
        btn.hl:SetAllPoints()
        btn.hl:SetTexture(WV_FLAT_TEX)
        btn.hl:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.rowHover))
        btn:SetScript("OnClick", function(self, mouseBtn)
            if mouseBtn == "RightButton" and self.onRightClick then
                self.onRightClick()
            else
                secCol[key] = not secCol[key]
                AkcQOLDB.global.sectionCollapsed = secCol
                UpdateTrackerInfo()
            end
        end)
        btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        ContentFrame.sectionToggles[key] = btn
        return btn
    end

    local headerH = 34

    local function DrawDataRow(y, h, alt)
        local c = alt and MATRIX_THEME.rowAlt or MATRIX_THEME.rowBase
        DrawRect(0, y, gridW, h, c[1], c[2], c[3], c[4], "ARTWORK")
        DrawRect(0, y - h + 1, gridW, 1, MATRIX_THEME.rowLine[1], MATRIX_THEME.rowLine[2], MATRIX_THEME.rowLine[3], MATRIX_THEME.rowLine[4], "OVERLAY")
    end

    local function DrawStatusChip(label, x, y, w, statusKey)
        local status = MATRIX_THEME.status[statusKey or "neutral"] or MATRIX_THEME.status.neutral
        local maxW = math.max(24, w - 12)
        local chipW = math.min(maxW, math.max(46, (#label * 7) + 18))
        local chipX = x + math.floor((w - chipW) / 2)
        DrawRect(chipX, y - 3, chipW, 18, status.color[1], status.color[2], status.color[3], status.bgAlpha or 0.12, "ARTWORK")
        DrawRect(chipX, y - 3, 2, 18, status.color[1], status.color[2], status.color[3], 0.78, "OVERLAY")
        DrawText("|cFF" .. status.hex .. label .. "|r", chipX, y - 6, chipW, "CENTER")
    end

    local function DrawDash(x, y, w)
        DrawText("|c" .. MATRIX_THEME.text.faint .. "-|r", x, y, w, "CENTER")
    end

    local function DrawSectionHeader(key, y, section, labelX, labelW)
        labelX = labelX or 14
        labelW = labelW or (nameW - labelX - 8)
        DrawRect(0, y, gridW, headerH, MATRIX_THEME.headerBg[1], MATRIX_THEME.headerBg[2], MATRIX_THEME.headerBg[3], MATRIX_THEME.headerBg[4], "ARTWORK")
        DrawRect(0, y, gridW, headerH, section.color[1], section.color[2], section.color[3], 0.045, "ARTWORK")
        DrawRect(0, y, gridW, 1, section.color[1], section.color[2], section.color[3], 0.68, "OVERLAY")
        DrawRect(0, y, 3, headerH, section.color[1], section.color[2], section.color[3], 0.90, "OVERLAY")
        DrawRect(nameW, y - 4, 1, headerH - 8, 1, 1, 1, 0.045, "OVERLAY")

        local chevron
        if CreateAtlasMarkup then
            chevron = CreateAtlasMarkup(secCol[key] and "Campaign_HeaderIcon_Closed" or "Campaign_HeaderIcon_Open", 12, 12)
        elseif CreateTextureMarkup then

            chevron = CreateTextureMarkup(secCol[key] and "Interface\\Buttons\\UI-PlusButton-Up" or "Interface\\Buttons\\UI-MinusButton-Up", 16, 16, 12, 12, 0, 1, 0, 1)
        else
            chevron = secCol[key] and ">" or "v"
        end
        DrawText(chevron .. " |cFF" .. section.hex .. section.label .. "|r", labelX, y - 10, labelW, "LEFT", "GameFontNormal")
    end

    local function DrawSectionEnd(yTop, yBottom, section)
        local secH = math.abs(yTop - yBottom)
        DrawRect(0, yBottom, gridW, 1, section.color[1], section.color[2], section.color[3], 0.48, "OVERLAY")
        DrawRect(0, yTop, 3, secH, section.color[1], section.color[2], section.color[3], 0.78, "OVERLAY")
        DrawRect(gridW - 1, yTop, 1, secH, section.color[1], section.color[2], section.color[3], 0.22, "OVERLAY")
    end

    DrawSectionHeader("charInfo", startY, MATRIX_THEME.sections.charInfo, 34, nameW - 42)

    local headerTextY = currentY - 6
    for i, char in ipairs(visibleChars) do
        local cColor = AkcQOLDB[char].color or "ffffffff"
        local baseName, realm = char:match("^(.-)%-(.+)$")
        if not baseName then
            baseName, realm = char, nil
        end
        DrawText(string.format("|c%s%s|r", cColor, baseName), nameW + ((i-1)*colW), headerTextY, colW, "CENTER", "GameFontNormal")
        if realm then
            DrawText(string.format("|cFF8A8C90%s|r", realm), nameW + ((i-1)*colW), headerTextY - 13, colW, "CENTER", "GameFontHighlightSmall")
        end
    end

    if not ContentFrame.charInfoSettingsBtn then
        local sb = CreateFrame("Button", nil, ContentFrame)
        sb:EnableMouse(true)
        sb:SetSize(20, 20)
        sb.bg = sb:CreateTexture(nil, "BACKGROUND")
        sb.bg:SetAllPoints()
        sb.bg:SetTexture(WV_FLAT_TEX)
        sb.bg:SetVertexColor(0, 0, 0, 0)

        sb.icon = sb:CreateTexture(nil, "ARTWORK")
        sb.icon:SetTexture("Interface\\Buttons\\UI-OptionsButton")
        sb.icon:SetVertexColor(1.0, 0.78, 0.20, 1)
        sb.icon:SetAllPoints()
        sb.text = sb:CreateFontString(nil, "OVERLAY")
        sb.text:Hide()
        sb:SetScript("OnEnter", function(self)
            self.bg:SetVertexColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.rowHover))
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(L["Toggle visible rows"])
            GameTooltip:Show()
        end)
        sb:SetScript("OnLeave", function(self)
            self.bg:SetVertexColor(0, 0, 0, 0)
            GameTooltip:Hide()
        end)
        sb:SetScript("OnClick", function()
            if ContentFrame.charInfoPopup and ContentFrame.charInfoPopup:IsShown() then
                ContentFrame.charInfoPopup:Hide()
                return
            end
            if not ContentFrame.charInfoPopup then

                local popup = CreateFrame("Frame", "AkcQOLMatrixRowsPopup", TrackerFrame, "BackdropTemplate")
                popup:SetSize(180, 186)
                popup:SetFrameStrata("TOOLTIP")
                popup:EnableMouse(true)
                popup:SetToplevel(true)
                AkcQOL_Theme.ApplyBackdrop(popup, "panel", { accentBorder = true })
                tinsert(UISpecialFrames, "AkcQOLMatrixRowsPopup")

                popup:SetScript("OnUpdate", function(self)
                    if (IsMouseButtonDown("LeftButton") or IsMouseButtonDown("RightButton"))
                        and not self:IsMouseOver()
                        and not (ContentFrame.charInfoSettingsBtn and ContentFrame.charInfoSettingsBtn:IsMouseOver()) then
                        self:Hide()
                    end
                end)

                local rows = {
                    { key = "level", label = L["Level"] },
                    { key = "ilvl", label = L["Item Level"] },
                    { key = "rating", label = L["Mythic+ Score"] },
                    { key = "keystone", label = L["Mythic+ Keystone"] },
                    { key = "cofferKeys", label = L["Restored Coffer Keys"] },
                    { key = "catalyst", label = L["Catalyst"] },
                }
                local py = -8
                for _, row in ipairs(rows) do
                    local cb = CreateFrame("CheckButton", nil, popup, "UICheckButtonTemplate")
                    cb:SetSize(22, 22)
                    cb:SetPoint("TOPLEFT", 8, py)
                    cb:SetChecked(civ[row.key] ~= false)
                    local lbl = cb:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                    AkcQOL_Theme.SetFont(lbl, 12, "")
                    lbl:SetTextColor(AkcQOL_Theme.rgba(AkcQOL_Theme.colors.text))
                    lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
                    lbl:SetText(row.label)
                    cb:SetScript("OnClick", function(self)
                        AkcQOLDB.global.charInfoVisible[row.key] = self:GetChecked() and true or false
                        UpdateTrackerInfo()
                    end)
                    py = py - 26
                end
                popup:SetHeight(math.abs(py) + 8)
                ContentFrame.charInfoPopup = popup
            end
            ContentFrame.charInfoPopup:ClearAllPoints()
            ContentFrame.charInfoPopup:SetPoint("TOPLEFT", ContentFrame.charInfoSettingsBtn, "BOTTOMLEFT", 0, -2)
            ContentFrame.charInfoPopup:Show()
        end)
        ContentFrame.charInfoSettingsBtn = sb
    end

    ContentFrame.charInfoSettingsBtn:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 6, startY - 7)
    ContentFrame.charInfoSettingsBtn:SetFrameLevel(ContentFrame:GetFrameLevel() + 8)
    ContentFrame.charInfoSettingsBtn:Show()

    local ciToggle = GetSectionToggle("charInfo")
    ciToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 28, startY)
    ciToggle:SetSize(nameW - 30, headerH)
    ciToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
    ciToggle:Show()

    currentY = currentY - (headerH + 6)

    local isAltRow = false

    if not secCol.charInfo then

    if civ.level ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText(L["Level"], 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local val = AkcQOLDB[char].level or "-"
            if val == "-" then
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            else
                DrawText(tostring(val), nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            end
        end
        currentY = currentY - 24
    end

    if civ.ilvl ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText(L["Item Level"], 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local val = AkcQOLDB[char] and AkcQOLDB[char].ilvl
            local text = (val and val > 0) and string.format("|cff00FF00%.2f|r", val) or (val == 0 and "0" or "-")
            DrawText(text, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
        end
        currentY = currentY - 24
    end

    if civ.rating ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText(L["Mythic+ Score"], 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local val = AkcQOLDB[char] and AkcQOLDB[char].rating
            local text = "-"
            if val and val > 0 then
                local colorObj = C_ChallengeMode.GetDungeonScoreRarityColor(val)
                if colorObj then
                    text = colorObj:WrapTextInColorCode(val)
                else
                    text = string.format("|cffFF8000%d|r", val)
                end
            elseif val == 0 then
                text = "0"
            end
            if text == "-" then
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            else
                DrawText(text, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            end
        end
        currentY = currentY - 24
    end

    if civ.keystone ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText(L["Mythic+ Key"], 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local level = AkcQOLDB[char] and AkcQOLDB[char].keystoneLevel or 0
            local dungeon = AkcQOLDB[char] and AkcQOLDB[char].keystoneDungeon
            if dungeon and level > 0 then

                local short = dungeon:gsub("'", ""):sub(1, 10)
                local keyColor = level >= 10 and "|cFFB794F6" or level >= 7 and "|cff0070DD" or "|cff1EFF00"
                DrawText(keyColor .. "+" .. level .. "|r " .. short, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
            else
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            end
        end
        currentY = currentY - 24
    end

    if civ.cofferKeys ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText(L["Restored Coffer Keys"], 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local keys = AkcQOLDB[char] and AkcQOLDB[char].restoredCofferKeys or 0
            if keys > 0 then
                DrawStatusChip(tostring(keys), nameW + ((i-1)*colW), currentY, colW, "done")
            else
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            end
        end
        currentY = currentY - 24
    end

    if civ.catalyst ~= false then
        DrawDataRow(currentY, 24, isAltRow)
        isAltRow = not isAltRow
        DrawText(L["Catalyst"], 10, currentY - 6, nameW - 10, "LEFT")
        for i, char in ipairs(visibleChars) do
            local tw = AkcQOLDB[char] and AkcQOLDB[char].thisWeek
            local c = tw and tw.catalyst
            if c then
                DrawStatusChip(c.q .. "/" .. c.max, nameW + ((i-1)*colW), currentY, colW, c.q > 0 and "purple" or "neutral")
            else
                DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
            end
        end
        currentY = currentY - 24
    end
    end
    DrawSectionEnd(startY, currentY, MATRIX_THEME.sections.charInfo)
    currentY = currentY - 8

    do
    local twSafeY, twSafeAlt = currentY, isAltRow
    local twOK = pcall(function()
        isAltRow = false
        local twStartY = currentY
        DrawSectionHeader("thisweek", currentY, MATRIX_THEME.sections.thisweek, 16, nameW - 24)
        local twToggle = GetSectionToggle("thisweek")
        twToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        twToggle:SetSize(gridW, 34)
        twToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        twToggle:Show()
        currentY = currentY - 34
        if not secCol.thisweek then
            local T = Enum and Enum.WeeklyRewardChestThresholdType
            local VAULT_ROWS = {
                { vtype = (T and T.Raid) or 3, label = L["Vault: Raid"] },
                { vtype = (T and (T.Activities or T.MythicPlus)) or 1, label = L["Vault: Dungeons"] },
                { vtype = (T and T.World) or 6, label = L["Vault: World"] },
            }
            for _, row in ipairs(VAULT_ROWS) do
                DrawDataRow(currentY, 24, isAltRow)
                isAltRow = not isAltRow
                DrawText(row.label, 10, currentY - 6, nameW - 10, "LEFT")
                for i, char in ipairs(visibleChars) do
                    local tw = AkcQOLDB[char] and AkcQOLDB[char].thisWeek
                    local v = tw and tw.vault and tw.vault[row.vtype]
                    local x = nameW + ((i-1)*colW)
                    if v and v.slots and v.slots > 0 then
                        local st = (v.filled >= v.slots and "done") or (v.filled > 0 and "warn") or "bad"
                        DrawStatusChip(v.filled .. "/" .. v.slots, x, currentY, colW, st)
                    else
                        DrawDash(x, currentY - 6, colW)
                    end
                end
                currentY = currentY - 24
            end
            DrawDataRow(currentY, 24, isAltRow)
            isAltRow = not isAltRow
            DrawText(L["Profession Weeklies"], 10, currentY - 6, nameW - 10, "LEFT")
            for i, char in ipairs(visibleChars) do
                local tw = AkcQOLDB[char] and AkcQOLDB[char].thisWeek
                local profs = tw and tw.profs
                local x = nameW + ((i-1)*colW)
                if profs and #profs > 0 then
                    local done = 0
                    for _, pr in ipairs(profs) do if pr.done then done = done + 1 end end
                    local st = (done >= #profs and "done") or (done > 0 and "warn") or "bad"
                    DrawStatusChip(done .. "/" .. #profs, x, currentY, colW, st)
                else
                    DrawDash(x, currentY - 6, colW)
                end
            end
            currentY = currentY - 24
            local function CrestLabel(field, fallback)
                for _, char in ipairs(visibleChars) do
                    local tw = AkcQOLDB[char] and AkcQOLDB[char].thisWeek
                    local c = tw and tw[field]
                    if c and c.name and c.name ~= "" then return c.name end
                end
                return fallback
            end
            local sparkCap = GetGlobalSparkCap()
            local EXTRA_ROWS = {
                { label = L["Weekly Spark"], get = function(tw2, cd)
                    local done = cd and cd.sparkQuestCompleted
                    return done and L["Done"] or L["Not Done"], done and "done" or "bad"
                end },
                { label = L["Spark of Tides"], get = function(tw2, cd)
                    local total = cd and (cd.sparkTotalEarned or cd.sparkCount) or 0
                    return total .. "/" .. sparkCap, (total >= sparkCap and "done") or (total > 0 and "warn") or "bad"
                end },
                { label = L["Prey Hunts"], get = function(tw2, cd)
                    local p = cd and cd.huntProgress
                    if not p then return nil end
                    local a, b = p:match("(%d+)/(%d+)")
                    return p, (a and b and a == b) and "done" or (a and tonumber(a) > 0 and "warn") or "bad"
                end },
                { label = L["Trovehunter's Bounty"], get = function(tw2, cd)
                    local done = cd and cd.delveBountyCompleted
                    return done and L["Done"] or L["Open"], done and "done" or "bad"
                end },
                { label = L["Nemesis"], get = function(tw2, cd)
                    local done = cd and cd.nemesisCompleted
                    return done and L["Done"] or L["Not Done"], done and "done" or "bad"
                end },
                { label = CrestLabel("crestHero", L["Hero Crest"]), get = function(tw2)
                    local c = tw2 and tw2.crestHero
                    if c then return c.earned .. "/" .. c.cap, (c.earned >= c.cap and "done") or (c.earned > 0 and "warn") or "bad" end
                end },
                { label = CrestLabel("crestMyth", L["Myth Crest"]), get = function(tw2)
                    local c = tw2 and tw2.crestMyth
                    if c then return c.earned .. "/" .. c.cap, (c.earned >= c.cap and "done") or (c.earned > 0 and "warn") or "bad" end
                end },
                { label = L["Coffer Shards (Weekly)"], get = function(tw2, cd)
                    local w, cap = cd and cd.cofferShardsWeekly, cd and cd.cofferShardsWeeklyCap
                    if type(w) == "number" and type(cap) == "number" and cap > 0 then
                        return w .. "/" .. cap, (w >= cap and "done") or (w > 0 and "warn") or "bad"
                    end
                end },
            }
            for _, row in ipairs(EXTRA_ROWS) do
                DrawDataRow(currentY, 24, isAltRow)
                isAltRow = not isAltRow
                DrawText(row.label, 10, currentY - 6, nameW - 10, "LEFT")
                for i, char in ipairs(visibleChars) do
                    local cd = AkcQOLDB[char]
                    local txt, st = row.get(cd and cd.thisWeek, cd)
                    local x = nameW + ((i-1)*colW)
                    if txt then
                        DrawStatusChip(txt, x, currentY, colW, st)
                    else
                        DrawDash(x, currentY - 6, colW)
                    end
                end
                currentY = currentY - 24
            end
        end
        DrawSectionEnd(twStartY, currentY, MATRIX_THEME.sections.thisweek)
        currentY = currentY - 8
    end)
    if not twOK then
        -- Half-drawn section would make every later section overlap it.
        currentY, isAltRow = twSafeY, twSafeAlt
        local tog = GetSectionToggle("thisweek")
        if tog then tog:Hide() end
    end
    end

    if #raidList > 0 then
        isAltRow = false
        local raidsStartY = currentY
        DrawSectionHeader("raids", currentY, MATRIX_THEME.sections.raids, 16, nameW - 24)

        local raidToggle = GetSectionToggle("raids")
        raidToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        raidToggle:SetSize(gridW, 34)
        raidToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        raidToggle:Show()

        local DIFF_ORDER = { "LFR", "N", "H", "M" }
        local CELL_PAD = 12
        local BOX_GAP = 2

        if not secCol.raids then

        local DIFF_HDR_COLORS = { LFR = "888888", N = "66FF66", H = "FF9933", M = "FF4D4D" }
        for i = 1, #visibleChars do
            local cellX = nameW + ((i-1) * colW)
            local boxW = math.floor((colW - CELL_PAD - BOX_GAP * 3) / 4)
            if boxW < 10 then boxW = 10 end
            local totalBoxW = boxW * 4 + BOX_GAP * 3
            local boxStartX = cellX + math.floor((colW - totalBoxW) / 2)
            for di, diff in ipairs(DIFF_ORDER) do
                local bx = boxStartX + (di - 1) * (boxW + BOX_GAP)
                local hdrColor = DIFF_HDR_COLORS[diff] or "AAAAAA"
                DrawText("|cFF" .. hdrColor .. diff .. "|r", bx, currentY - 11, boxW, "CENTER", "GameFontNormal")
            end
        end
        end

        currentY = currentY - 34

        if not secCol.raids then
        local DIFF_COLORS = {
            LFR = { border = {0.5, 0.5, 0.5}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
            N   = { border = {0.4, 1.0, 0.4}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
            H   = { border = {1.0, 0.6, 0.2}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
            M   = { border = {1.0, 0.3, 0.3}, full = {0.25, 0.70, 0.42}, partial = {0.86, 0.58, 0.16}, empty = {0.18, 0.19, 0.22} },
        }

        for _, itemName in ipairs(raidList) do
            DrawDataRow(currentY, 24, isAltRow)
            isAltRow = not isAltRow

            DrawText(itemName, 10, currentY - 6, nameW - 10, "LEFT")
            for i, char in ipairs(visibleChars) do
                local raidData = AkcQOLDB[char] and AkcQOLDB[char].raids and AkcQOLDB[char].raids[itemName]
                local cellX = nameW + ((i-1) * colW)

                if type(raidData) == "table" then

                    local boxW = math.floor((colW - CELL_PAD - BOX_GAP * 3) / 4)
                    if boxW < 10 then boxW = 10 end
                    local totalBoxW = boxW * 4 + BOX_GAP * 3
                    local boxStartX = cellX + math.floor((colW - totalBoxW) / 2)

                    for di, diff in ipairs(DIFF_ORDER) do
                        local info = raidData[diff]
                        local bx = boxStartX + (di - 1) * (boxW + BOX_GAP)
                        local dc = DIFF_COLORS[diff]

                        local boxY = currentY - 3
                        local textY = currentY - 8
                        if info and info.killed > 0 then
                            local isFull = (info.killed == info.total and info.total > 0)
                            local bgColor = isFull and dc.full or dc.partial

                            DrawRect(bx, boxY, boxW, 18, bgColor[1], bgColor[2], bgColor[3], 0.62, "ARTWORK")
                            DrawRect(bx, boxY, boxW, 1, dc.border[1], dc.border[2], dc.border[3], 0.6, "OVERLAY")
                            DrawRect(bx, boxY - 17, boxW, 1, dc.border[1], dc.border[2], dc.border[3], 0.6, "OVERLAY")
                            local label = string.format("%d/%d", info.killed, info.total)
                            DrawText("|cFFFFFFFF" .. label .. "|r", bx, textY, boxW, "CENTER")
                        elseif info then

                            DrawRect(bx, boxY, boxW, 18, dc.empty[1], dc.empty[2], dc.empty[3], 0.42, "ARTWORK")
                            DrawText("|cFF555555" .. string.format("%d/%d", info.killed, info.total) .. "|r", bx, textY, boxW, "CENTER")
                        else

                            DrawRect(bx, boxY, boxW, 18, dc.empty[1], dc.empty[2], dc.empty[3], 0.42, "ARTWORK")
                            DrawText("|cFF555555" .. diff .. "|r", bx, textY, boxW, "CENTER")
                        end
                    end
                elseif type(raidData) == "string" then

                    DrawText(raidData, cellX, currentY - 6, colW, "CENTER")
                else
                    DrawDash(cellX, currentY - 6, colW)
                end
            end
            currentY = currentY - 24
        end
        end
        DrawSectionEnd(raidsStartY, currentY, MATRIX_THEME.sections.raids)
        currentY = currentY - 8
    end

    if #dungeonList > 0 then
        isAltRow = false
        local dungStartY = currentY
        DrawSectionHeader("dungeons", currentY, MATRIX_THEME.sections.dungeons, 16, nameW - 24)

        local dungToggle = GetSectionToggle("dungeons")
        dungToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        dungToggle:SetSize(gridW, 34)
        dungToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        dungToggle:Show()
        currentY = currentY - 34

        if not secCol.dungeons then
        for _, dungeonMapID in ipairs(dungeonList) do
            DrawDataRow(currentY, 36, isAltRow)
            isAltRow = not isAltRow

            local dungeonName = AkcQOL_GetDungeonDisplayName(dungeonMapID)
            local bannerTexture = GetDungeonBanner(dungeonName)
            DrawRect(6, currentY - 3, nameW - 14, 30, 0, 0, 0, 0.14, "ARTWORK")
            DrawArt(12, currentY - 5, 66, 26, bannerTexture)

            local tpSpell, tpSpellID = GetDungeonTeleportSpell(dungeonMapID)
            local tpRemaining = 0
            if tpSpell then
                tpRemaining = AkcQOL_GetTeleportCooldownRemaining(tpSpellID, tpSpell)
            end
            local reservedRight = 12
            if tpSpell then
                reservedRight = (tpRemaining > 0) and 68 or 34
            end

            DrawText(dungeonName, 84, currentY - 8, nameW - 88 - reservedRight, "LEFT", nil, true)

            if tpSpell and not InCombatLockdown() then
                local tpBtn = GetOrCreateTeleportBtn(teleportSecureHost)
                tpBtn:SetSize(nameW - 10, 34)
                tpBtn:ClearAllPoints()
                tpBtn:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 4, currentY - 1)
                tpBtn.dungeonName = dungeonName
                tpBtn.spellDisplayName = tpSpell
                tpBtn.spellID = tpSpellID
                tpBtn.teleportCooldownRemaining = tpRemaining
                tpBtn:SetFrameLevel(ContentFrame:GetFrameLevel() + 10)
                if tpBtn.portalIcon then
                    tpBtn.portalIcon:ClearAllPoints()
                    tpBtn.portalIcon:SetPoint("RIGHT", tpBtn, "LEFT", nameW - 18, 0)
                    if tpBtn.cooldownText then
                        tpBtn.cooldownText:ClearAllPoints()
                        tpBtn.cooldownText:SetJustifyH("RIGHT")
                        tpBtn.cooldownText:SetPoint("RIGHT", tpBtn.portalIcon, "LEFT", -4, 0)
                    end
                end
                AkcQOL_ApplyTeleportButtonState(tpBtn)
                tpBtn:Show()
            end

            for i, char in ipairs(visibleChars) do
                local d = AkcQOLDB[char] and AkcQOLDB[char].dungeons and AkcQOLDB[char].dungeons[dungeonMapID]
                local val = "|c" .. MATRIX_THEME.text.faint .. "-|r"

                if d then
                    local best = math.max(d.mplusBest or 0, d.mplus or 0)
                    local bestStr = "|c" .. MATRIX_THEME.text.faint .. "-|r"
                    if best > 0 then
                        local bColor = best >= 10 and "A335EE" or (best >= 7 and "0070DD" or "C0C0C0")
                        bestStr = string.format("|cff%s+%d|r", bColor, best)
                    end

                    local m0Progress = d.m0Progress or "0/0"
                    local m0Str = "|c" .. MATRIX_THEME.text.faint .. "-|r"
                    if m0Progress ~= "0/0" then
                        local m0Color = d.isComplete and "00FF00" or "FF0000"
                        m0Str = string.format("|cff%s%s|r", m0Color, m0Progress)
                    end

                    val = bestStr .. "  " .. m0Str
                end

                DrawText(val, nameW + ((i-1)*colW), currentY - 12, colW, "CENTER")
            end
            currentY = currentY - 36
        end
        end
        DrawSectionEnd(dungStartY, currentY, MATRIX_THEME.sections.dungeons)
        currentY = currentY - 8
    end

    if maxKeys > 0 then
        isAltRow = false
        local vaultStartY = currentY
        DrawSectionHeader("vault", currentY, MATRIX_THEME.sections.vault, 16, nameW - 24)

        local vaultToggle = GetSectionToggle("vault")
        vaultToggle:SetPoint("TOPLEFT", ContentFrame, "TOPLEFT", 0, currentY)
        vaultToggle:SetSize(gridW, 34)
        vaultToggle:SetFrameLevel(ContentFrame:GetFrameLevel() + 5)
        vaultToggle:Show()
        currentY = currentY - 34

        if not secCol.vault then
        for k = 1, maxKeys do
            DrawDataRow(currentY, 24, isAltRow)
            isAltRow = not isAltRow

            DrawText(L["Key #"] .. k, 10, currentY - 6, nameW - 10, "LEFT")
            for i, char in ipairs(visibleChars) do
                local val = (AkcQOLDB[char] and AkcQOLDB[char].topKeys and AkcQOLDB[char].topKeys[k]) or "-"
                if val == "-" then
                    DrawDash(nameW + ((i-1)*colW), currentY - 6, colW)
                else
                    DrawText(val, nameW + ((i-1)*colW), currentY - 6, colW, "CENTER")
                end
            end
            currentY = currentY - 24
        end
        end
        DrawSectionEnd(vaultStartY, currentY, MATRIX_THEME.sections.vault)
    end

    local totalHeight = math.abs(currentY - startY)

    if not InCombatLockdown() then
        ContentFrame:SetHeight(totalHeight)
        local frameHeight = math.max(220, math.min(800, totalHeight + 36))
        if not TrackerFrame.akcqolEmbeddedHost then
            TrackerFrame:SetHeight(frameHeight)
        end
    end
end

_G.AkcQOLMatrix_Refresh = UpdateTrackerInfo

local combatEndFrame = CreateFrame("Frame")
combatEndFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
combatEndFrame:SetScript("OnEvent", function()
    AkcQOL_EnsureTeleportDriver()
    for _, frame in ipairs({ WVTrackerFrame, FilterMenu, AkcQOLSettingsFrame, AKCQOL_LOGS_FRAME, AKCQOL_LOG_EXPORT_FRAME }) do
        if frame and frame.akcqolSoftHidden then
            AkcQOL_SafeHideFrame(frame)
        end
    end
    if WVTrackerFrame and AkcQOL_IsFrameOpen(WVTrackerFrame) then
        UpdateTrackerInfo()
    end
end)

SLASH_AKCQOL1 = "/akc"
SlashCmdList["AKCQOL"] = function(msg)
    msg = type(msg) == "string" and msg:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
    if msg == "settings" then
        if AkcQOL_ShowLogsWindow then AkcQOL_ShowLogsWindow("settings") end
        return
    elseif msg == "logs" then
        if AkcQOL_ShowLogsWindow then AkcQOL_ShowLogsWindow("mail") end
        return
    elseif msg == "matrix" then
        if AkcQOL_ShowLogsWindow then AkcQOL_ShowLogsWindow("matrix") end
        return
    elseif msg ~= "" then
        print(L["|cff8c5cffAkc|r|cffffffffQOL|r: Usage: /akc [settings | logs | matrix]"])
        return
    end
    if AKCQOL_LOGS_FRAME and AkcQOL_IsFrameOpen(AKCQOL_LOGS_FRAME) then
        AkcQOL_SafeHideFrame(AKCQOL_LOGS_FRAME)
    elseif AkcQOL_IsFrameOpen(WVTrackerFrame) then
        AkcQOL_CloseMatrixPopups()
        AkcQOL_SafeHideFrame(WVTrackerFrame)
    elseif AkcQOL_ShowLogsWindow then
        AkcQOL_ShowLogsWindow("matrix")
    else
        RequestRaidInfo()
        C_MythicPlus.RequestRewards()
        C_MythicPlus.RequestMapInfo()
        C_Timer.After(0.5, function()
            UpdateTrackerInfo()
            AkcQOL_SafeShowFrame(WVTrackerFrame)
        end)
    end
end
