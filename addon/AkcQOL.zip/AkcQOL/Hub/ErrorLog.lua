
local ADDON_NAME = ...

local L = AkcQOL_L

if type(L) ~= "table" then
    L = setmetatable({}, { __index = function(_, key) return key end })
end

local Theme = AkcQOL_Theme

local MAX_ERROR_LOG = 200
local ROW_COUNT = 13
local ERROR_RATE_LIMIT = 10
local ERROR_THROTTLE_SECONDS = 5
local SOUND_COOLDOWN = 0.25
local LUA_ERROR_SOUND_FALLBACK = 8959
local LUA_ERROR_SOUND_FILE = "Interface\\AddOns\\" .. (ADDON_NAME or "AkcQOL") .. "\\Media\\lua-error.ogg"

local WHITE_TEX = "Interface\\Buttons\\WHITE8x8"

local errorFrame
local selectedIndex = 1
local listOffset = 0
local captureWindowStart = 0
local captureWindowCount = 0
local throttledUntil = 0
local throttleNoticePending = false
local handlingError = false
local bugGrabberMirrorRegistered = false
local bugGrabberCallbackOwner = {}
local lastSyncedBugGrabberSession = nil
local lastSyncedBugGrabberCount = -1
local nativeEventsRegistered = false
local lastSoundAt = 0
local previousErrorHandler
local ApplyCaptureMode


local function EnsureDB()
    if type(AkcQOLDB) ~= "table" then AkcQOLDB = {} end
    if type(AkcQOLDB.global) ~= "table" then AkcQOLDB.global = {} end
    if type(AkcQOLDB.global.luaErrors) ~= "table" then AkcQOLDB.global.luaErrors = {} end

    local db = AkcQOLDB.global.luaErrors
    if type(db.entries) ~= "table" then db.entries = {} end
    if type(db.nextID) ~= "number" then db.nextID = 1 end
    if db.enabled == nil then db.enabled = true end
    if db.suppressPopups == nil then db.suppressPopups = true end
    if db.soundEnabled == nil then db.soundEnabled = true end
    if type(db.unreadCount) ~= "number" then db.unreadCount = 0 end
    if type(db.maxEntries) ~= "number" then db.maxEntries = MAX_ERROR_LOG end
    return db
end

local function SafeString(value, fallback)
    if value == nil then return fallback or "" end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return "<secret value>" end
    end
    local ok, text = pcall(tostring, value)
    if ok and text then return text end
    return "<unprintable error value>"
end

local function GetLuaErrorSoundID()
    if type(SOUNDKIT) == "table" then
        return SOUNDKIT.RAID_WARNING
            or SOUNDKIT.UI_RAID_BOSS_WHISPER_WARNING
            or SOUNDKIT.READY_CHECK
            or LUA_ERROR_SOUND_FALLBACK
    end
    return LUA_ERROR_SOUND_FALLBACK
end

local function PlayBuiltInLuaWarning()
    local soundID = GetLuaErrorSoundID()
    if not soundID or type(PlaySound) ~= "function" then return end

    local ok = pcall(PlaySound, soundID, "Master")
    if not ok then
        pcall(PlaySound, soundID)
    end
end

local function PlayCustomLuaErrorSound()
    if type(PlaySoundFile) ~= "function" then return false end

    local ok, played = pcall(PlaySoundFile, LUA_ERROR_SOUND_FILE, "Master")
    if ok and played then return true end
    ok, played = pcall(PlaySoundFile, LUA_ERROR_SOUND_FILE)
    return (ok and played) and true or false
end

local function PlayLuaErrorSound(force)
    local db = EnsureDB()
    if not force and db.soundEnabled == false then return end

    if not force and type(GetTime) == "function" then
        local now = GetTime()
        if now - lastSoundAt < SOUND_COOLDOWN then return end
        lastSoundAt = now
    end

    if not PlayCustomLuaErrorSound() then
        PlayBuiltInLuaWarning()
    end
end

local function GetTimestamp()
    if type(time) == "function" then
        local ok, value = pcall(time)
        if ok and value then return value end
    end
    return 0
end

local function FormatTimestamp(ts)
    if ts and ts > 0 and type(date) == "function" then
        local ok, value = pcall(date, "%Y-%m-%d %H:%M:%S", ts)
        if ok and value then return value end
    end
    return "Unknown"
end

local function GetPlayerTag()
    local name = "Unknown"
    if type(UnitNameUnmodified) == "function" then
        name = UnitNameUnmodified("player") or name
    elseif type(UnitName) == "function" then
        name = UnitName("player") or name
    end

    local realm = ""
    if type(GetNormalizedRealmName) == "function" then
        realm = GetNormalizedRealmName() or ""
    elseif type(GetRealmName) == "function" then
        realm = GetRealmName() or ""
    end

    if realm ~= "" then
        return name .. "-" .. realm
    end
    return name
end

local function FirstLine(text)
    text = tostring(text or "")
    local line = text:match("([^\r\n]+)") or text
    if line == "" then line = L["Unknown error"] end
    return line
end

local function TrimForList(text, limit)
    text = FirstLine(text)
    limit = limit or 80
    if #text > limit then
        return string.sub(text, 1, limit - 3) .. "..."
    end
    return text
end

local function StripColorCodes(text)
    text = tostring(text or "")
    text = text:gsub("|c%x%x%x%x%x%x%x%x", "")
    text = text:gsub("|r", "")
    text = text:gsub("|H.-|h(.-)|h", "%1")
    text = text:gsub("|T.-|t", "")
    text = text:gsub("||", "|")
    return text
end

local function ExtractAddonFromPath(text, skipOwnAddon)
    text = tostring(text or ""):gsub("\\", "/")
    for addon in text:gmatch("AddOns/([^/%s:\r\n]+)") do
        if not skipOwnAddon or addon ~= ADDON_NAME then
            return addon
        end
    end
    return nil
end

local function GuessAddon(message, stack)

    local addon = ExtractAddonFromPath(message, false)
    if addon then return addon end
    addon = ExtractAddonFromPath(stack, true)
    if addon then return addon end
    return "Unknown"
end

local function GetDebugStack()
    if type(debugstack) ~= "function" then return "" end

    if type(GetCallstackHeight) == "function" and type(GetErrorCallstackHeight) == "function" then
        local ok, stack = pcall(function()
            local currentStackHeight = GetCallstackHeight()
            local errorCallStackHeight = GetErrorCallstackHeight()
            if currentStackHeight and errorCallStackHeight then
                local debugStackLevel = currentStackHeight - (errorCallStackHeight - 1)
                return debugstack(debugStackLevel, 20, 20)
            end
            return nil
        end)
        if ok and stack then return tostring(stack) end
    end

    local ok, stack = pcall(debugstack, 4, 20, 20)
    if ok and stack then return tostring(stack) end
    return ""
end

local function RefreshStoredAddonGuesses()
    local db = EnsureDB()
    if db.addonGuessVersion == 2 then return end

    for _, entry in ipairs(db.entries) do
        if type(entry) == "table" then
            entry.addon = GuessAddon(entry.message, entry.stack)
        end
    end

    db.addonGuessVersion = 2
end

local function IsRateLimited()
    if type(GetTime) ~= "function" then return false end

    local now = GetTime()
    if now < throttledUntil then
        return true
    end

    if now - captureWindowStart > 1 then
        captureWindowStart = now
        captureWindowCount = 0
        throttleNoticePending = false
    end

    captureWindowCount = captureWindowCount + 1
    if captureWindowCount > ERROR_RATE_LIMIT then
        throttledUntil = now + ERROR_THROTTLE_SECONDS
        throttleNoticePending = true
        return true
    end

    return false
end

local function TrimStoredEntries(entries, maxEntries)
    maxEntries = maxEntries or MAX_ERROR_LOG
    while #entries > maxEntries do
        table.remove(entries)
    end
end

local function RefreshErrorButton()
    if type(_G.AkcQOL_RefreshErrorLogButton) == "function" then
        pcall(_G.AkcQOL_RefreshErrorLogButton)
    end
end

local function RefreshViewer()
    if errorFrame and errorFrame:IsShown() and type(errorFrame.Refresh) == "function" then
        errorFrame:Refresh()
    end
end

local function IsViewerShown()
    return errorFrame and errorFrame:IsShown()
end

local function RecountUnread(db)
    db = db or EnsureDB()
    local count = 0
    for _, entry in ipairs(db.entries) do
        if type(entry) == "table" and entry.unread then
            count = count + 1
        end
    end
    db.unreadCount = count
    return count
end

local function EnsureSelectedVisible()
    if selectedIndex <= listOffset then
        listOffset = selectedIndex - 1
    elseif selectedIndex > listOffset + ROW_COUNT then
        listOffset = selectedIndex - ROW_COUNT
    end
    if listOffset < 0 then listOffset = 0 end
end

local function MarkErrorsSeen()
    local db = EnsureDB()
    for _, entry in ipairs(db.entries) do
        if type(entry) == "table" then
            entry.unread = false
        end
    end
    RecountUnread(db)
    RefreshErrorButton()
end

local function GetExternalBugGrabber()
    local bg = _G.BugGrabber
    if type(bg) == "table"
        and type(bg.GetDB) == "function"
        and type(bg.GetSessionId) == "function"
    then
        return bg
    end
    return nil
end

local function FindEntryByErrorKey(entries, kind, message, addon)
    for i, entry in ipairs(entries) do
        if entry.kind == kind
            and entry.message == message
            and entry.addon == addon
        then
            return entry, i
        end
    end
    return nil
end

local function MoveEntryToTop(entries, index)
    if not index or index <= 1 then return end
    local entry = table.remove(entries, index)
    if entry then
        table.insert(entries, 1, entry)
    end
end

local function AddEntry(kind, message, stack, addonName, force)
    if handlingError and not force then return end

    handlingError = true
    local shouldPlaySound = false
    local ok = pcall(function()
        local db = EnsureDB()
        if db.enabled == false then return end

        if not force and IsRateLimited() then
            if throttleNoticePending then
                throttleNoticePending = false
                AddEntry(
                    "Throttle",
                    L["Too many Lua errors at once. AkcQOL paused error capture for a few seconds."],
                    "",
                    ADDON_NAME or "AkcQOL",
                    true
                )
            end
            return
        end

        local entries = db.entries
        local cleanKind = SafeString(kind, "Lua Error")
        local cleanMessage = SafeString(message, "Unknown error")
        local cleanStack = SafeString(stack, "")
        local cleanAddon = SafeString(addonName, "")
        if cleanAddon == "" then
            cleanAddon = GuessAddon(cleanMessage, cleanStack)
        end
        local now = GetTimestamp()
        local existing, existingIndex = FindEntryByErrorKey(entries, cleanKind, cleanMessage, cleanAddon)

        if existing then
            existing.count = (existing.count or 1) + 1
            existing.lastSeen = now
            existing.lastSeenText = FormatTimestamp(now)
            existing.stack = cleanStack
            if not IsViewerShown() then
                MoveEntryToTop(entries, existingIndex)
                selectedIndex = 1
                listOffset = 0
            end
            return
        end

        local entry = {
            id = db.nextID,
            kind = cleanKind,
            message = cleanMessage,
            stack = cleanStack,
            addon = cleanAddon,
            player = GetPlayerTag(),
            firstSeen = now,
            firstSeenText = FormatTimestamp(now),
            lastSeen = now,
            lastSeenText = FormatTimestamp(now),
            count = 1,
            unread = true,
            soundPlayed = true,
        }

        db.nextID = db.nextID + 1
        table.insert(entries, 1, entry)
        TrimStoredEntries(entries, db.maxEntries)
        if IsViewerShown() and #entries > 1 then

            selectedIndex = selectedIndex + 1
        else
            selectedIndex = 1
            listOffset = 0
        end
        RecountUnread(db)
        shouldPlaySound = true
    end)

    handlingError = false

    if ok then
        if shouldPlaySound then
            PlayLuaErrorSound(false)
        end
        RefreshErrorButton()
        RefreshViewer()
    end
end

local function HandleLuaError(err)
    local ok = pcall(function()
        local message = SafeString(err, "Unknown Lua error")
        local stack = GetDebugStack()
        AddEntry("Lua Error", message, stack, GuessAddon(message, stack), false)
    end)
    -- A failure here is deliberately ignored: the error handler must never
    -- raise inside itself, or the client loses every later error report.

    local db = EnsureDB()
    if db.suppressPopups == false
        and previousErrorHandler and previousErrorHandler ~= HandleLuaError then
        pcall(previousErrorHandler, err)
    end
end

local function SuppressBlizzardErrorUI()
    local db = EnsureDB()
    if db.suppressPopups == false then return end

    if UIParent and type(UIParent.UnregisterEvent) == "function" then
        pcall(UIParent.UnregisterEvent, UIParent, "ADDON_ACTION_BLOCKED")
        pcall(UIParent.UnregisterEvent, UIParent, "ADDON_ACTION_FORBIDDEN")
    end

    if ScriptErrorsFrame and type(ScriptErrorsFrame.UnregisterEvent) == "function" then
        pcall(ScriptErrorsFrame.UnregisterEvent, ScriptErrorsFrame, "LUA_WARNING")
        pcall(ScriptErrorsFrame.UnregisterEvent, ScriptErrorsFrame, "LUA_ERROR")
    end

    if ScriptErrorsFrame and type(ScriptErrorsFrame.Hide) == "function" then
        pcall(ScriptErrorsFrame.Hide, ScriptErrorsFrame)
    end
end

local function RestoreBlizzardErrorUI()
    if UIParent and type(UIParent.RegisterEvent) == "function" then
        pcall(UIParent.RegisterEvent, UIParent, "ADDON_ACTION_BLOCKED")
        pcall(UIParent.RegisterEvent, UIParent, "ADDON_ACTION_FORBIDDEN")
    end

    if ScriptErrorsFrame and type(ScriptErrorsFrame.RegisterEvent) == "function" then
        pcall(ScriptErrorsFrame.RegisterEvent, ScriptErrorsFrame, "LUA_WARNING")
        pcall(ScriptErrorsFrame.RegisterEvent, ScriptErrorsFrame, "LUA_ERROR")
    end
end

local function InstallErrorHandler()
    if GetExternalBugGrabber() then return end

    if type(seterrorhandler) == "function" then

        if previousErrorHandler == nil and type(geterrorhandler) == "function" then
            local ok, current = pcall(geterrorhandler)
            if ok and current and current ~= HandleLuaError then
                previousErrorHandler = current
            end
        end
        pcall(seterrorhandler, HandleLuaError)
    end
    SuppressBlizzardErrorUI()
end

local function RecordProtectedAction(event, addonName, functionName)
    addonName = tostring(addonName or "Unknown")
    functionName = tostring(functionName or "Unknown")

    local kind = "Blocked Action"
    if event == "ADDON_ACTION_FORBIDDEN" then
        kind = "Forbidden Action"
    end

    local message = string.format(L["AddOn '%s' tried to call protected function '%s'."], addonName, functionName)
    AddEntry(kind, message, GetDebugStack(), addonName, false)
end

local function RecordLuaWarning(...)
    local parts = {}
    for i = 1, select("#", ...) do
        local value = select(i, ...)
        parts[#parts + 1] = SafeString(value, "")
    end
    local message = table.concat(parts, " ")
    if message == "" then message = "Lua warning" end
    AddEntry("Lua Warning", message, GetDebugStack(), GuessAddon(message, ""), false)
end

local function GuessBugGrabberKind(message)
    message = tostring(message or "")
    if message:match("^LUA_WARNING:") then
        return "Lua Warning"
    end
    if message:find("ADDON_ACTION_BLOCKED", 1, true) then
        return "Blocked Action"
    end
    if message:find("ADDON_ACTION_FORBIDDEN", 1, true) then
        return "Forbidden Action"
    end
    return "Lua Error"
end

local function GetBugGrabberSourceKey(err, sessionID, safeMessage)
    local sessionText = "?"
    if sessionID ~= nil then
        sessionText = SafeString(sessionID, "?")
    elseif type(err) == "table" and err.session ~= nil then
        sessionText = SafeString(err.session, "?")
    end
    return "BugGrabber:" .. sessionText .. ":" .. (safeMessage or "")
end

local function FindEntryBySourceKey(entries, sourceKey)
    if not sourceKey then return nil end
    for i, entry in ipairs(entries) do
        if entry.sourceKey == sourceKey then
            return entry, i
        end
    end
    return nil
end

local function MirrorBugGrabberError(err, sessionID, silent)
    if type(err) ~= "table" then return end

    local db = EnsureDB()
    if db.enabled == false then return end

    local message = SafeString(err.message, "Unknown BugGrabber error")
    local stack = SafeString(err.stack, "")
    local localsText = SafeString(err.locals, "")
    if localsText ~= "" then
        stack = stack .. "\n\nLocals:\n" .. localsText
    end

    local sourceKey = GetBugGrabberSourceKey(err, sessionID, message)
    local now = tonumber(err.time) or GetTimestamp()
    local entries = db.entries
    local existing = FindEntryBySourceKey(entries, sourceKey)
    local isNewEntry = false

    if existing then
        existing.kind = GuessBugGrabberKind(message)
        existing.message = message
        existing.stack = stack
        existing.addon = GuessAddon(message, stack)
        existing.lastSeen = now
        existing.lastSeenText = FormatTimestamp(now)
        existing.count = tonumber(err.counter) or existing.count or 1
    else
        local isUnread = not silent
        local entry = {
            id = db.nextID,
            kind = GuessBugGrabberKind(message),
            message = message,
            stack = stack,
            addon = GuessAddon(message, stack),
            player = GetPlayerTag(),
            firstSeen = now,
            firstSeenText = FormatTimestamp(now),
            lastSeen = now,
            lastSeenText = FormatTimestamp(now),
            count = tonumber(err.counter) or 1,
            source = "BugGrabber",
            sourceKey = sourceKey,
            unread = isUnread,
            soundPlayed = isUnread,
        }

        db.nextID = db.nextID + 1
        table.insert(entries, 1, entry)
        TrimStoredEntries(entries, db.maxEntries)
        if IsViewerShown() and #entries > 1 then

            selectedIndex = selectedIndex + 1
        else
            selectedIndex = 1
            listOffset = 0
        end
        isNewEntry = true
    end

    if not silent and isNewEntry then
        PlayLuaErrorSound(false)
    end
    RecountUnread(db)
    RefreshErrorButton()
    RefreshViewer()
end

local function SyncBugGrabberSession(bg)
    if not bg then return end

    local okSession, sessionID = pcall(function()
        return bg:GetSessionId()
    end)
    if not okSession or not sessionID then return end

    local okDB, bugDB = pcall(function()
        return bg:GetDB()
    end)
    if not okDB or type(bugDB) ~= "table" then return end

    if lastSyncedBugGrabberSession == sessionID and #bugDB == lastSyncedBugGrabberCount then
        return
    end
    lastSyncedBugGrabberSession = sessionID
    lastSyncedBugGrabberCount = #bugDB

    for _, err in ipairs(bugDB) do
        if type(err) == "table" and err.session == sessionID then
            MirrorBugGrabberError(err, sessionID, true)
        end
    end
end

local function EnableBugGrabberMirror(bg)
    if not bg then return false end

    if not bugGrabberMirrorRegistered then

        if type(bg.RegisterCallback) ~= "function" and type(bg.setupCallbacks) == "function" then
            pcall(bg.setupCallbacks)
        end
        if type(bg.RegisterCallback) == "function" then
            local ok = pcall(bg.RegisterCallback, bugGrabberCallbackOwner, "BugGrabber_BugGrabbed", function(_, errorObject)
                local sessionID
                pcall(function() sessionID = bg:GetSessionId() end)
                pcall(MirrorBugGrabberError, errorObject, sessionID)
            end)
            if ok then
                bugGrabberMirrorRegistered = true
            end
        end

        if not bugGrabberMirrorRegistered and EventRegistry and type(EventRegistry.RegisterCallback) == "function" then
            EventRegistry:RegisterCallback("BugGrabber.BugGrabbed", function(_, tableID)
                local activeBG = GetExternalBugGrabber()
                if not activeBG then return end

                local ok, err = pcall(function()
                    if type(activeBG.GetErrorByID) == "function" then
                        return activeBG:GetErrorByID(tableID)
                    end
                    return nil
                end)
                if ok and err then
                    local sessionID
                    pcall(function() sessionID = activeBG:GetSessionId() end)
                    MirrorBugGrabberError(err, sessionID)
                end
            end, bugGrabberCallbackOwner)

            bugGrabberMirrorRegistered = true
        end

        if bugGrabberMirrorRegistered and EventRegistry and type(EventRegistry.TriggerEvent) == "function" then
            pcall(EventRegistry.TriggerEvent, EventRegistry, "BugGrabber.DisplayRegistered")
        end
    end

    SyncBugGrabberSession(bg)
    return true
end

local function CreateTextButton(parent, text, width, height, color)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(width, height)

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(WHITE_TEX)
    bg:SetVertexColor(Theme.rgba(Theme.colors.panelBg))

    local border = btn:CreateTexture(nil, "BORDER")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetTexture(WHITE_TEX)
    border:SetVertexColor(color[1], color[2], color[3], 0.55)

    local label = btn:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(label, 10, "")
    label:SetAllPoints()
    label:SetText(text)

    btn.bg = bg
    btn.border = border
    btn.label = label
    btn:SetScript("OnEnter", function()
        bg:SetVertexColor(Theme.rgba(Theme.colors.rowHover))
        border:SetVertexColor(color[1], color[2], color[3], 0.9)
    end)
    btn:SetScript("OnLeave", function()
        bg:SetVertexColor(Theme.rgba(Theme.colors.panelBg))
        border:SetVertexColor(color[1], color[2], color[3], 0.55)
    end)
    return btn
end

local function BuildDetailText(entry)
    if not entry then
        return L["No Lua errors captured yet."]
    end

    local lines = {}
    local function Add(line)
        lines[#lines + 1] = line or ""
    end

    Add(L["AkcQOL Lua Error Log"])
    Add("")
    Add(L["ID:"] .. " " .. tostring(entry.id or "-"))
    Add(L["Type:"] .. " " .. tostring(entry.kind or "Lua Error"))
    Add(L["AddOn:"] .. " " .. tostring(entry.addon or "Unknown"))
    Add(L["Player:"] .. " " .. tostring(entry.player or "Unknown"))
    Add(L["First Seen:"] .. " " .. tostring(entry.firstSeenText or "Unknown"))
    Add(L["Last Seen:"] .. " " .. tostring(entry.lastSeenText or entry.firstSeenText or "Unknown"))
    Add(L["Count:"] .. " " .. tostring(entry.count or 1))
    if entry.source then
        Add(L["Source:"] .. " " .. tostring(entry.source))
    end
    Add("")
    Add(L["Message:"])
    Add(StripColorCodes(entry.message or ""))

    if entry.stack and entry.stack ~= "" then
        Add("")
        Add(L["Stack:"])
        Add(StripColorCodes(entry.stack))
    end

    return table.concat(lines, "\n")
end


local function EnsureViewer()
    if errorFrame then return errorFrame end

    local f = CreateFrame("Frame", "AkcQOLErrorLogFrame", UIParent, "BackdropTemplate")
    f:SetSize(760, 530)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(700)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    Theme.ApplyWindow(f)

    f:SetBackdropBorderColor(Theme.rgba(Theme.colors.bad))
    f:Hide()

    local titleBar = CreateFrame("Frame", nil, f)
    titleBar:SetPoint("TOPLEFT", 1, -1)
    titleBar:SetPoint("TOPRIGHT", -1, -1)
    titleBar:SetHeight(34)

    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")

    titleBg:SetPoint("TOPLEFT", 0, -2)
    titleBg:SetPoint("BOTTOMRIGHT")
    titleBg:SetTexture(WHITE_TEX)
    titleBg:SetVertexColor(Theme.rgba(Theme.colors.header))

    local title = titleBar:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(title, 14, "", true)
    title:SetPoint("LEFT", 12, 0)
    title:SetText(Theme.Accent("AkcQOL") .. " " .. L["Lua Errors"])
    Theme.StyleTitle(title)

    local countText = titleBar:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(countText, 10, "")
    countText:SetPoint("LEFT", title, "RIGHT", 12, -1)
    countText:SetTextColor(Theme.rgba(Theme.colors.textMuted))
    f.countText = countText

    local close = CreateTextButton(titleBar, "|cFFFF4D4DX|r", 24, 22, Theme.colors.bad)
    close:SetPoint("RIGHT", -8, 0)
    close:SetFrameLevel(titleBar:GetFrameLevel() + 10)
    Theme.SetFont(close.label, 13, "")
    close:SetScript("OnClick", function() f:Hide() end)

    local clear = CreateTextButton(titleBar, "|cFFFF7A7A" .. L["Clear"] .. "|r", 58, 20, Theme.colors.bad)
    clear:SetPoint("RIGHT", close, "LEFT", -6, 0)
    local function ResetClearConfirm()
        clear.confirmArmed = false
        clear.label:SetText("|cFFFF7A7A" .. L["Clear"] .. "|r")
    end
    clear:SetScript("OnClick", function()
        if not clear.confirmArmed then
            clear.confirmArmed = true
            clear.label:SetText("|cFFFF4D4D" .. L["Sure?"] .. "|r")
            if C_Timer and type(C_Timer.After) == "function" then
                C_Timer.After(4, function()
                    if clear.confirmArmed then ResetClearConfirm() end
                end)
            end
            return
        end
        ResetClearConfirm()
        local db = EnsureDB()
        db.entries = {}
        db.nextID = 1
        selectedIndex = 1
        listOffset = 0
        RecountUnread(db)
        RefreshErrorButton()
        f:Refresh()
    end)

    local selectAll = CreateTextButton(titleBar, "|cFFE5E7EB" .. L["Select All"] .. "|r", 78, 20, Theme.colors.accent)
    selectAll:SetPoint("RIGHT", clear, "LEFT", -6, 0)
    selectAll:SetScript("OnClick", function()
        if f.detailEdit then
            f.detailEdit:SetFocus()
            f.detailEdit:HighlightText()
        end
    end)

    local soundToggle = CreateTextButton(titleBar, "|cFF7CFF8A" .. L["Sound On"] .. "|r", 78, 20, Theme.colors.good)
    soundToggle:SetPoint("RIGHT", selectAll, "LEFT", -6, 0)

    local function UpdateSoundToggle()
        local db = EnsureDB()
        if db.soundEnabled == false then
            soundToggle.label:SetText("|cFF9CA3AF" .. L["Sound Off"] .. "|r")
        else
            soundToggle.label:SetText("|cFF7CFF8A" .. L["Sound On"] .. "|r")
        end
    end

    soundToggle:SetScript("OnClick", function()
        local db = EnsureDB()
        db.soundEnabled = not (db.soundEnabled == true)
        UpdateSoundToggle()
    end)
    f.UpdateSoundToggle = UpdateSoundToggle

    local testSound = CreateTextButton(titleBar, "|cFFE5E7EB" .. L["Test"] .. "|r", 44, 20, Theme.colors.warn)
    testSound:SetPoint("RIGHT", soundToggle, "LEFT", -6, 0)
    testSound:SetScript("OnClick", function()
        PlayLuaErrorSound(true)
    end)

    local newer = CreateTextButton(titleBar, "|cFFE5E7EB>|r", 24, 20, Theme.colors.accent)
    newer:SetPoint("RIGHT", testSound, "LEFT", -6, 0)
    Theme.SetFont(newer.label, 13, "")
    newer:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("|cFFE5E7EB" .. L["Newer Error"] .. "|r")
        GameTooltip:Show()
    end)
    newer:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    newer:SetScript("OnClick", function()
        if selectedIndex > 1 then
            selectedIndex = selectedIndex - 1
            EnsureSelectedVisible()
            f:Refresh()
        end
    end)

    local older = CreateTextButton(titleBar, "|cFFFFC38A<|r", 24, 20, Theme.colors.accent)
    older:SetPoint("RIGHT", newer, "LEFT", -6, 0)
    Theme.SetFont(older.label, 13, "")
    older:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine("|cFFE5E7EB" .. L["Older Error"] .. "|r")
        GameTooltip:Show()
    end)
    older:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    older:SetScript("OnClick", function()
        local db = EnsureDB()
        if selectedIndex < #db.entries then
            selectedIndex = selectedIndex + 1
            EnsureSelectedVisible()
            f:Refresh()
        end
    end)

    local resolve = CreateTextButton(titleBar, "", 104, 20, Theme.colors.good)
    resolve:SetPoint("RIGHT", older, "LEFT", -6, 0)
    local function UpdateResolveButton()
        local db = EnsureDB()
        local entry = db.entries and db.entries[selectedIndex]
        if entry and entry.resolved then
            resolve.label:SetText("|cFF7CFF8A" .. L["Resolved"] .. "|r")
        else
            resolve.label:SetText("|cFFB9BBBE" .. L["Mark Resolved"] .. "|r")
        end
    end
    UpdateResolveButton()
    resolve:SetScript("OnClick", function()
        local db = EnsureDB()
        local entry = db.entries and db.entries[selectedIndex]
        if not entry then return end
        entry.resolved = not (entry.resolved == true)
        UpdateResolveButton()
        f:Refresh()
    end)
    resolve:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(L["Mark this error resolved"], 1, 0.82, 0)
        GameTooltip:AddLine(L["A green check marks errors you've fixed. Click again to un-resolve."], 1, 1, 1, true)
        GameTooltip:Show()
    end)
    resolve:HookScript("OnLeave", function() GameTooltip:Hide() end)
    f.UpdateResolveButton = UpdateResolveButton

    local list = CreateFrame("Frame", nil, f, "BackdropTemplate")
    list:SetPoint("TOPLEFT", 10, -44)
    list:SetPoint("BOTTOMLEFT", 10, 40)
    list:SetWidth(270)
    Theme.ApplyBackdrop(list, "panel")

    list:EnableMouseWheel(true)
    list:SetScript("OnMouseWheel", function(_, delta)
        local db = EnsureDB()
        local maxOffset = math.max(0, #db.entries - ROW_COUNT)
        local newOffset = listOffset - delta * 3
        if newOffset < 0 then newOffset = 0 end
        if newOffset > maxOffset then newOffset = maxOffset end
        if newOffset ~= listOffset then
            listOffset = newOffset
            f:Refresh()
        end
    end)

    f.rows = {}
    for i = 1, ROW_COUNT do
        local row = CreateFrame("Button", nil, list)
        row:SetHeight(32)
        row:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 34)
        row:SetPoint("RIGHT", -6, 0)

        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture(WHITE_TEX)
        bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
        row.bg = bg

        local marker = row:CreateTexture(nil, "BORDER")
        marker:SetPoint("TOPLEFT")
        marker:SetPoint("BOTTOMLEFT")
        marker:SetWidth(3)
        marker:SetTexture(WHITE_TEX)
        marker:SetVertexColor(Theme.rgba(Theme.colors.border))
        row.marker = marker

        local main = row:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(main, 10, "")
        main:SetPoint("TOPLEFT", 8, -3)
        main:SetPoint("RIGHT", -6, 0)
        main:SetJustifyH("LEFT")
        main:SetTextColor(Theme.rgba(Theme.colors.text))
        row.main = main

        local meta = row:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(meta, 10, "")
        meta:SetPoint("BOTTOMLEFT", 8, 4)
        meta:SetPoint("RIGHT", -6, 0)
        meta:SetJustifyH("LEFT")
        meta:SetTextColor(Theme.rgba(Theme.colors.textMuted))
        row.meta = meta

        row:SetScript("OnClick", function(self)
            if self.entryIndex then
                selectedIndex = self.entryIndex
                local db = EnsureDB()
                local entry = db.entries and db.entries[selectedIndex]
                if entry then entry.unread = false end
                f:Refresh()
            end
        end)
        row:SetScript("OnEnter", function(self)
            if self.entryIndex ~= selectedIndex then
                self.bg:SetVertexColor(Theme.rgba(Theme.colors.rowHover))
            end
        end)
        row:SetScript("OnLeave", function(self)
            if self.entryIndex ~= selectedIndex then
                local db = EnsureDB()
                local entry = db.entries and db.entries[self.entryIndex]
                if entry and entry.unread then

                    self.bg:SetVertexColor(0.075, 0.11, 0.17, 0.92)
                else
                    self.bg:SetVertexColor(Theme.rgba(Theme.colors.rowBg))
                end
            end
        end)

        f.rows[i] = row
    end

    local detail = CreateFrame("Frame", nil, f, "BackdropTemplate")
    detail:SetPoint("TOPLEFT", list, "TOPRIGHT", 10, 0)
    detail:SetPoint("BOTTOMRIGHT", -10, 40)
    Theme.ApplyBackdrop(detail, "inset")

    local scroll = CreateFrame("ScrollFrame", "AkcQOLErrorLogDetailScroll", detail, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -8)
    scroll:SetPoint("BOTTOMRIGHT", -28, 8)

    local edit = CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    Theme.SetFont(edit, 11, "")
    edit:SetTextColor(Theme.rgba(Theme.colors.text))
    edit:SetJustifyH("LEFT")
    edit:SetJustifyV("TOP")
    edit:SetWidth(430)
    edit:SetHeight(2200)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scroll:SetScrollChild(edit)
    f.detailEdit = edit
    f.detailScroll = scroll

    local captureToggle = CreateTextButton(f, "", 120, 20, Theme.colors.good)
    captureToggle:SetPoint("BOTTOMLEFT", 10, 10)

    local popupToggle = CreateTextButton(f, "", 190, 20, Theme.colors.accent)
    popupToggle:SetPoint("LEFT", captureToggle, "RIGHT", 8, 0)

    local function UpdateOptionToggles()
        local db = EnsureDB()
        if db.enabled == false then
            captureToggle.label:SetText("|cFF9CA3AF" .. L["Capture: Off"] .. "|r")
        else
            captureToggle.label:SetText("|cFF7CFF8A" .. L["Capture: On"] .. "|r")
        end
        if db.suppressPopups == false then
            popupToggle.label:SetText("|cFF9CA3AF" .. L["Hide Blizzard error popups: Off"] .. "|r")
        else
            popupToggle.label:SetText("|cFF8AB6FF" .. L["Hide Blizzard error popups: On"] .. "|r")
        end
    end
    f.UpdateOptionToggles = UpdateOptionToggles

    captureToggle:SetScript("OnClick", function()
        local db = EnsureDB()
        db.enabled = (db.enabled == false)
        if ApplyCaptureMode then ApplyCaptureMode() end
        UpdateOptionToggles()
    end)
    captureToggle:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(L["Error capture"], 1, 0.82, 0)
        GameTooltip:AddLine(L["When enabled, AkcQOL records Lua errors into this log. Takes effect immediately."], 1, 1, 1, true)
        GameTooltip:Show()
    end)
    captureToggle:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    popupToggle:SetScript("OnClick", function()
        local db = EnsureDB()
        db.suppressPopups = (db.suppressPopups == false)
        if db.suppressPopups then
            SuppressBlizzardErrorUI()
        else
            RestoreBlizzardErrorUI()
        end
        UpdateOptionToggles()
    end)
    popupToggle:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:AddLine(L["Blizzard error popups"], 1, 0.82, 0)
        GameTooltip:AddLine(L["When on, AkcQOL hides Blizzard's red error popups and logs the errors here instead. Takes effect immediately."], 1, 1, 1, true)
        GameTooltip:Show()
    end)
    popupToggle:HookScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    function f:Refresh()
        local db = EnsureDB()
        local entries = db.entries
        if selectedIndex < 1 then selectedIndex = 1 end
        if selectedIndex > #entries then selectedIndex = math.max(1, #entries) end
        local maxOffset = math.max(0, #entries - ROW_COUNT)
        if listOffset > maxOffset then listOffset = maxOffset end
        if listOffset < 0 then listOffset = 0 end
        local selected = entries[selectedIndex]
        if selected and selected.unread then
            selected.unread = false
        end
        RecountUnread(db)
        RefreshErrorButton()

        if self.countText then
            self.countText:SetText(string.format("|cFF9CA3AF" .. L["%d stored"] .. "|r", #entries))
        end

        for i, row in ipairs(self.rows) do
            local entryIndex = listOffset + i
            local entry = entries[entryIndex]
            if entry then
                row.entryIndex = entryIndex
                local mainText = TrimForList(StripColorCodes(entry.message), 43)
                if entry.resolved then

                    mainText = "|TInterface\\RaidFrame\\ReadyCheck-Ready:0|t " .. mainText
                end
                row.main:SetText(mainText)
                row.meta:SetText(string.format("%s - %s x%d", tostring(entry.kind or "Lua Error"), tostring(entry.addon or "Unknown"), entry.count or 1))
                row:Show()

                local c = Theme.colors
                if entryIndex == selectedIndex then
                    row.bg:SetVertexColor(Theme.rgba(c.rowHover))
                    row.marker:SetVertexColor(Theme.rgba(c.accent))
                elseif entry.resolved then

                    row.bg:SetVertexColor(0.06, 0.12, 0.07, 0.85)
                    row.marker:SetVertexColor(c.good[1], c.good[2], c.good[3], 0.9)
                elseif entry.unread then

                    row.bg:SetVertexColor(0.075, 0.11, 0.17, 0.92)
                    row.marker:SetVertexColor(0.28, 0.60, 1.0, 1)
                elseif entry.kind == "Throttle" then
                    row.bg:SetVertexColor(0.14, 0.11, 0.07, 0.9)
                    row.marker:SetVertexColor(c.warn[1], c.warn[2], c.warn[3], 0.8)
                else
                    row.bg:SetVertexColor(Theme.rgba(c.rowBg))
                    row.marker:SetVertexColor(c.bad[1], c.bad[2], c.bad[3], 0.75)
                end
            else
                row.entryIndex = nil
                row:Hide()
            end
        end

        self.detailEdit:SetText(BuildDetailText(selected))
        self.detailEdit:ClearFocus()
        self.detailScroll:SetVerticalScroll(0)
        if self.UpdateSoundToggle then
            self.UpdateSoundToggle()
        end
        if self.UpdateOptionToggles then
            self.UpdateOptionToggles()
        end
        if self.UpdateResolveButton then
            self.UpdateResolveButton()
        end
    end

    errorFrame = f
    return f
end

local function ShowViewer()
    RefreshStoredAddonGuesses()
    local f = EnsureViewer()
    MarkErrorsSeen()
    EnsureSelectedVisible()
    f:Refresh()
    f:Show()
end

local function ToggleViewer()
    RefreshStoredAddonGuesses()
    local f = EnsureViewer()
    if f:IsShown() then
        f:Hide()
    else
        MarkErrorsSeen()
        EnsureSelectedVisible()
        f:Refresh()
        f:Show()
    end
end

local function ClearLog()
    local db = EnsureDB()
    db.entries = {}
    db.nextID = 1
    selectedIndex = 1
    listOffset = 0
    RecountUnread(db)
    RefreshErrorButton()
    RefreshViewer()
end

_G.AkcQOL_ShowErrorLogWindow = ShowViewer
_G.AkcQOL_ClearErrorLog = ClearLog
_G.AkcQOL_GetLuaErrorCount = function()
    local db = EnsureDB()
    return #db.entries
end
_G.AkcQOL_GetUnreadLuaErrorCount = function()
    local db = EnsureDB()
    return db.unreadCount or 0
end
_G.AkcQOL_RecordLuaError = function(kind, message, stack, addonName)

    AddEntry(kind, message, stack, addonName, true)
end

_G.AkcQOL_GetErrorSetting = function(key)
    local db = EnsureDB()
    return db[key]
end
_G.AkcQOL_SetErrorSetting = function(key, value)
    if type(key) ~= "string" then return end
    local db = EnsureDB()
    if key == "maxEntries" then
        value = tonumber(value) or MAX_ERROR_LOG
        if value < 10 then value = 10 elseif value > 1000 then value = 1000 end
        db.maxEntries = value
        TrimStoredEntries(db.entries, db.maxEntries)
        RefreshViewer()
        return
    end
    db[key] = value
    if key == "enabled" then
        if ApplyCaptureMode then ApplyCaptureMode() end
    elseif key == "suppressPopups" then
        if value == false then RestoreBlizzardErrorUI() else SuppressBlizzardErrorUI() end
    end

    if errorFrame and errorFrame:IsShown() then
        if errorFrame.UpdateSoundToggle then pcall(errorFrame.UpdateSoundToggle) end
        if errorFrame.UpdateOptionToggles then pcall(errorFrame.UpdateOptionToggles) end
    end
end
_G.AkcQOL_TestLuaErrorSound = function()
    PlayLuaErrorSound(true)
end

SLASH_AKCQOLERRORLOG1 = "/akcerrors"
SLASH_AKCQOLERRORLOG2 = "/akcqolerrorlog"
SlashCmdList["AKCQOLERRORLOG"] = function(msg)
    msg = tostring(msg or ""):lower()
    if msg == "clear" then
        ClearLog()
        print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. L["Lua error log cleared."])
    else
        ToggleViewer()
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("ADDON_LOADED")

local function RegisterNativeCaptureEvents()
    if nativeEventsRegistered then return end
    eventFrame:RegisterEvent("ADDON_ACTION_BLOCKED")
    eventFrame:RegisterEvent("ADDON_ACTION_FORBIDDEN")
    pcall(eventFrame.RegisterEvent, eventFrame, "LUA_WARNING")
    nativeEventsRegistered = true
end

local function UnregisterNativeCaptureEvents()
    if not nativeEventsRegistered then return end
    eventFrame:UnregisterEvent("ADDON_ACTION_BLOCKED")
    eventFrame:UnregisterEvent("ADDON_ACTION_FORBIDDEN")
    pcall(eventFrame.UnregisterEvent, eventFrame, "LUA_WARNING")
    nativeEventsRegistered = false
end

function ApplyCaptureMode()
    local db = EnsureDB()

    if type(_G.AkcQOLBoot_Retire) == "function" then
        pcall(_G.AkcQOLBoot_Retire)
    end

    if db.enabled == false then
        UnregisterNativeCaptureEvents()
        if previousErrorHandler and type(geterrorhandler) == "function" and type(seterrorhandler) == "function" then
            local ok, current = pcall(geterrorhandler)
            if ok and current == HandleLuaError then
                pcall(seterrorhandler, previousErrorHandler)
            end
        end
        return
    end

    local bg = GetExternalBugGrabber()
    if bg then
        UnregisterNativeCaptureEvents()
        EnableBugGrabberMirror(bg)
    else
        RegisterNativeCaptureEvents()
        InstallErrorHandler()
    end
end

eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        ApplyCaptureMode()
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(1, ApplyCaptureMode)
            C_Timer.After(5, ApplyCaptureMode)
        end
    elseif event == "ADDON_LOADED" then
        ApplyCaptureMode()
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        RecordProtectedAction(event, ...)
    elseif event == "LUA_WARNING" then
        RecordLuaWarning(...)
    end
end)

ApplyCaptureMode()
