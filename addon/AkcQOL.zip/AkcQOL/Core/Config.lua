local _, addon = ...

local L = AkcQOL_L

local akcBoxedGroups = {}


local GetNumSpecializationsForClassID = (C_SpecializationInfo and C_SpecializationInfo.GetNumSpecializationsForClassID) or GetNumSpecializationsForClassID
local GetSpecializationInfoForClassID = (C_SpecializationInfo and C_SpecializationInfo.GetSpecializationInfoForClassID) or GetSpecializationInfoForClassID

local PI_SOUND_OPTIONS_FALLBACK = {
    raidwarning = L["Raid Warning"],
    readycheck = L["Ready Check"],
    alarm = L["Alarm Clock"],
    bosswarn = L["Boss Warning"],
    questdone = L["Quest Complete"],
    ping = L["Map Ping"],
    whisper = L["Whisper"],
    queue = L["Queue Pop"],
    auction = L["Auction Bell"],
    invite = L["Group Invite"],
    levelup = L["Level Up"],
}

local function NormalizePISoundStyle(style)

    if type(style) == "string" and style:match("^cdm%d+$") then return style end
    local options = addon.GetPIAlertSoundOptions and addon:GetPIAlertSoundOptions() or PI_SOUND_OPTIONS_FALLBACK
    if options[style or ""] then
        return style
    end
    return "raidwarning"
end

local function NormalizePISoundVolume(volume)
    volume = tonumber(volume) or 100
    if volume < 0 then volume = 0 elseif volume > 100 then volume = 100 end
    return math.floor(volume + 0.5)
end

local function EnsureGlobal(key)
    AkcQOLDB = AkcQOLDB or {}
    AkcQOLDB.global = AkcQOLDB.global or {}
    if not key then return AkcQOLDB.global end
    AkcQOLDB.global[key] = AkcQOLDB.global[key] or {}
    return AkcQOLDB.global[key]
end

local ACTION_BAR_MOUSEOVER_BARS = {
    { key = "main", name = L["Main Bar"] },
    { key = "bottomLeft", name = L["Action Bar 2"] },
    { key = "bottomRight", name = L["Action Bar 3"] },
    { key = "right", name = L["Action Bar 4"] },
    { key = "left", name = L["Action Bar 5"] },
    { key = "bar5", name = L["Action Bar 6"] },
    { key = "bar6", name = L["Action Bar 7"] },
    { key = "bar7", name = L["Action Bar 8"] },
    { key = "pet", name = L["Pet Bar"] },
    { key = "stance", name = L["Stance Bar"] },
}

local function NormalizeAlpha(value, fallback)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value == nil then value = 1 end
    if value < 0 then return 0 end
    if value > 1 then return 1 end
    return value
end

local function NormalizeNumber(value, fallback, minValue, maxValue)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function EnsureActionBarMouseoverDB(db)
    db.actionBarMouseover = db.actionBarMouseover or {}
    local ab = db.actionBarMouseover
    if ab.enabled == nil then ab.enabled = false end
    ab.minAlpha = NormalizeAlpha(ab.minAlpha, 0)
    ab.maxAlpha = NormalizeAlpha(ab.maxAlpha, 1)
    if ab.maxAlpha < ab.minAlpha then ab.maxAlpha = ab.minAlpha end
    ab.hoverDelay = NormalizeNumber(ab.hoverDelay, 0.7, 0, 2)
    if ab.alwaysShowInCombat == nil then ab.alwaysShowInCombat = false end
    if ab.alwaysShowInEditMode == nil then ab.alwaysShowInEditMode = false end
    ab.bars = ab.bars or {}
    for _, def in ipairs(ACTION_BAR_MOUSEOVER_BARS) do
        if ab.bars[def.key] == nil then
            ab.bars[def.key] = false
        end
    end
    return ab
end

local function EnsureLocatorColor(color, defaults)
    if type(color) ~= "table" then color = {} end
    color.r = NormalizeAlpha(color.r, defaults.r)
    color.g = NormalizeAlpha(color.g, defaults.g)
    color.b = NormalizeAlpha(color.b, defaults.b)
    color.a = NormalizeAlpha(color.a, defaults.a)
    return color
end

local function EnsurePersonalLocatorDB(db)
    db.personalLocator = db.personalLocator or {}
    local locator = db.personalLocator

    locator.player = locator.player or {}
    local player = locator.player
    if player.enabled == nil then player.enabled = false end
    if player.combatOnly == nil then player.combatOnly = false end
    if player.style ~= "crosshair" and player.style ~= "brackets"
        and player.style ~= "beacon" and player.style ~= "ring" then
        player.style = "crosshair"
    end
    if player.classColor == nil then player.classColor = false end
    if player.pulse == nil then player.pulse = false end
    if player.spin == nil then player.spin = false end
    player.size = NormalizeNumber(player.size, 52, 20, 160)
    player.thickness = NormalizeNumber(player.thickness, 3, 1, 12)
    player.outline = NormalizeNumber(player.outline, 2, 0, 6)
    player.gap = NormalizeNumber(player.gap, 8, 0, 40)
    player.offsetX = NormalizeNumber(player.offsetX, 0, -500, 500)
    player.offsetY = NormalizeNumber(player.offsetY, -11, -500, 500)
    player.color = EnsureLocatorColor(player.color, { r = 0.20, g = 1.00, b = 0.35, a = 0.95 })

    locator.cursor = locator.cursor or {}
    local cursor = locator.cursor
    if cursor.enabled == nil then cursor.enabled = false end
    if cursor.combatOnly == nil then cursor.combatOnly = false end
    if cursor.dot == nil then cursor.dot = false end
    if cursor.pulse == nil then cursor.pulse = false end
    if cursor.classColor == nil then cursor.classColor = false end
    if cursor.spin == nil then cursor.spin = false end
    if cursor.trail == nil then cursor.trail = false end
    if cursor.crosshair == nil then cursor.crosshair = false end
    cursor.size = NormalizeNumber(cursor.size, 52, 24, 160)
    cursor.thickness = NormalizeNumber(cursor.thickness, 3, 1, 12)
    cursor.outline = NormalizeNumber(cursor.outline, 2, 0, 6)
    cursor.color = EnsureLocatorColor(cursor.color, { r = 1.00, g = 0.82, b = 0.20, a = 0.95 })

    return locator
end

local function RefreshPersonalLocator()
    if addon.RefreshPersonalLocator then addon:RefreshPersonalLocator() end
end

local function GetProfileValues(excludeCurrent)
    local values = {}
    local dbObj = addon.AkcQOL and addon.AkcQOL.db
    if not dbObj then return values end
    for _, name in ipairs(dbObj:GetProfiles({})) do
        values[name] = name
    end
    if excludeCurrent then
        values[dbObj:GetCurrentProfile()] = nil
    end
    return values
end

local function ApplyCurrentProfile()
    local profile = addon.AkcQOL.db.profile
    if profile.piAlert and profile.piAlert.enabled then
        if addon.InitializePIAlert then addon:InitializePIAlert() end
    elseif addon.DisablePIAlert then
        addon:DisablePIAlert()
    end
    if profile.readyCheckHelper and profile.readyCheckHelper.enabled then
        if addon.InitializeReadyCheckHelper then addon:InitializeReadyCheckHelper() end
    elseif addon.DisableReadyCheckHelper then
        addon:DisableReadyCheckHelper()
    end
    if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
    if addon.RefreshPersonalLocator then addon:RefreshPersonalLocator() end
    if addon.RefreshSingleButtonAssistantKeybind then addon.RefreshSingleButtonAssistantKeybind() end
    if addon.BreakTimer_ApplySettings then addon.BreakTimer_ApplySettings() end
    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
end

local function BuildOptions()
    local db = addon.AkcQOL.db.profile
    db.readyCheckHelper = db.readyCheckHelper or {}
    if db.readyCheckHelper.enabled == nil then db.readyCheckHelper.enabled = false end
    if db.readyCheckHelper.locked == nil then db.readyCheckHelper.locked = false end
    db.readyCheckHelper.point = db.readyCheckHelper.point or "CENTER"
    db.readyCheckHelper.relPoint = db.readyCheckHelper.relPoint or "CENTER"
    db.readyCheckHelper.xOfs = db.readyCheckHelper.xOfs or 0
    db.readyCheckHelper.yOfs = db.readyCheckHelper.yOfs or 150
    db.piAlert = db.piAlert or {}
    if db.piAlert.enabled == nil then db.piAlert.enabled = false end
    if db.piAlert.screen == nil then db.piAlert.screen = false end
    if db.piAlert.sound == nil then db.piAlert.sound = false end
    db.piAlert.soundStyle = NormalizePISoundStyle(db.piAlert.soundStyle)
    db.piAlert.soundVolume = NormalizePISoundVolume(db.piAlert.soundVolume)
    if db.piAlert.message == nil or db.piAlert.message == "" then db.piAlert.message = "Power Infusion on YOU!" end
    if db.piAlert.chatMessage == nil then db.piAlert.chatMessage = true end
    if db.piAlert.throttle == nil then db.piAlert.throttle = 2 end
    db.breakTimer = db.breakTimer or {}
    if db.breakTimer.enabled == nil then db.breakTimer.enabled = true end
    if db.breakTimer.locked == nil then db.breakTimer.locked = true end
    if db.breakTimer.sound == nil then db.breakTimer.sound = false end
    db.singleButtonAssistantKeybind = db.singleButtonAssistantKeybind or {}
    do
        local sba = db.singleButtonAssistantKeybind

        if sba.hideArrow == nil and sba.showKeybind == nil and sba.enabled ~= nil then
            sba.hideArrow = sba.enabled
            sba.showKeybind = sba.enabled
        end
        if sba.hideArrow == nil then sba.hideArrow = false end
        if sba.showKeybind == nil then sba.showKeybind = false end
    end
    local actionBarMouseover = EnsureActionBarMouseoverDB(db)
    local personalLocator = EnsurePersonalLocatorDB(db)

    local options = {
        name = "AkcQOL",
        type = "group",
        childGroups = "tree",
        args = {
            piAlert = {
                name = L["Power Infusion Alert"],
                type = "group",
                args = {
                    piAlertDesc = {
                        name = L["Get an unmissable alert the moment Power Infusion lands on you."],
                        type = "description",
                        order = 0.1,
                        fontSize = "medium",
                    },
                    piAlertEnabled = {
                        name = L["Enable PI Alert"],
                        desc = L["Alert when Power Infusion is applied to you."],
                        type = "toggle",
                        order = 1,
                        width = 1.4,
                        get = function() return db.piAlert.enabled end,
                        set = function(_, val)
                            db.piAlert.enabled = val
                            if val and addon.InitializePIAlert then addon:InitializePIAlert() end
                            if not val and addon.DisablePIAlert then addon:DisablePIAlert() end
                        end,
                    },
                    piAlertScreen = {
                        name = L["Show Screen Text"],
                        desc = L["Show the configured PI message in the middle of the screen."],
                        type = "toggle", width = 1.4,
                        order = 2,
                        get = function() return db.piAlert.screen end,
                        set = function(_, val) db.piAlert.screen = val end,
                    },
                    piAlertSound = {
                        name = L["Play PI Sound"],
                        desc = L["Play a short sound with the PI alert."],
                        type = "toggle", width = 1.4,
                        order = 3,
                        get = function() return db.piAlert.sound end,
                        set = function(_, val) db.piAlert.sound = val end,
                    },
                    piAlertChatMessage = {
                        name = L["Chat Message"],
                        desc = L["Also print a note to your chat window when Power Infusion is applied to you."],
                        type = "toggle", width = 1.4,
                        order = 4,
                        get = function() return db.piAlert.chatMessage end,
                        set = function(_, val) db.piAlert.chatMessage = val end,
                    },
                    piAlertSoundHeader = {
                        name = L["Sound & Text"],
                        type = "header",
                        order = 4.5,
                    },
                    piAlertSoundStyle = {
                        name = function()
                            local cur = NormalizePISoundStyle(db.piAlert.soundStyle)
                            local label = (addon.GetSoundLabel and addon:GetSoundLabel(cur)) or cur
                            return L["PI Sound:"] .. "  |cffffd100" .. label .. "|r"
                        end,
                        desc = L["Click to pick from WoW's full categorized sound menu (Alerts, Instruments, Animals, Impacts, Warcraft 3/2, Devices). Selecting a sound previews it."],
                        type = "execute",
                        order = 5,
                        width = 1.5,
                        func = function()
                            if addon.OpenSoundAlertMenu then
                                addon:OpenSoundAlertMenu(
                                    function() return NormalizePISoundStyle(db.piAlert.soundStyle) end,
                                    function(key)
                                        db.piAlert.soundStyle = NormalizePISoundStyle(key)
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                                    end,
                                    function() return db.piAlert.soundVolume end)
                            end
                        end,
                    },
                    piAlertVolume = {
                        name = L["Make It Stand Out"],
                        desc = L["While this alert plays, your other game sounds (spell effects, music, ambience) briefly dip so the alert cuts through, then return to normal. Higher = a deeper dip. 0 = off. Use \"Test PI Sound + Text\" to preview."],
                        type = "range",
                        order = 6,
                        width = 1.5,
                        min = 0, max = 100, step = 5,
                        get = function() return NormalizePISoundVolume(db.piAlert.soundVolume) end,
                        set = function(_, val) db.piAlert.soundVolume = NormalizePISoundVolume(val) end,
                    },
                    piAlertMessage = {
                        name = L["Screen Text"],
                        desc = L["Text shown by the PI alert."],
                        type = "input",
                        order = 7,
                        width = 2,
                        get = function() return db.piAlert.message end,
                        set = function(_, val)
                            db.piAlert.message = (val and val ~= "") and val or "Power Infusion on YOU!"
                        end,
                    },
                    piAlertTest = {
                        name = L["Test PI Sound + Text"],
                        desc = L["Play the selected PI sound and show the PI text."],
                        type = "execute",
                        order = 8,
                        width = 1.2,
                        func = function()
                            if addon.TestPIAlert then addon:TestPIAlert() end
                        end,
                    },
                    restoreDefaults = {
                        name = L["Restore Defaults"],
                        type = "execute",
                        order = 100,
                        width = 1.2,
                        confirm = true,
                        confirmText = L["Reset all Power Infusion Alert settings to defaults?"],
                        func = function()
                            local pi = db.piAlert
                            wipe(pi)
                            pi.enabled = false
                            pi.screen = false
                            pi.sound = false
                            pi.soundStyle = "raidwarning"
                            pi.soundVolume = 100
                            pi.message = "Power Infusion on YOU!"
                            pi.chatMessage = true
                            pi.throttle = 2
                            if addon.DisablePIAlert then addon:DisablePIAlert() end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                        end,
                    },
                },
            },
            readyCheck = {
                name = L["Ready Check Helper"],
                type = "group",
                args = {
                    readyCheckDesc = {
                        name = L["Shows a compact checklist of who is ready while a ready check is running."],
                        type = "description",
                        order = 0.1,
                        fontSize = "medium",
                    },
                    readyCheckEnabled = {
                        name = L["Enable Ready Check Helper"],
                        desc = L["Show a checklist while a ready check is active."],
                        type = "toggle",
                        order = 1,
                        width = 1.4,
                        get = function() return db.readyCheckHelper.enabled end,
                        set = function(_, val)
                            db.readyCheckHelper.enabled = val
                            if val then
                                if addon.InitializeReadyCheckHelper then
                                    addon:InitializeReadyCheckHelper()
                                end
                            elseif addon.DisableReadyCheckHelper then
                                addon:DisableReadyCheckHelper()
                            elseif addon.HideReadyCheckHelper then
                                addon:HideReadyCheckHelper()
                            end
                        end,
                    },
                    readyCheckLocked = {
                        name = L["Lock Ready Check Helper"],
                        desc = L["Prevent the ready check helper from being dragged."],
                        type = "toggle", width = 1.4,
                        order = 2,
                        get = function() return db.readyCheckHelper.locked end,
                        set = function(_, val)
                            db.readyCheckHelper.locked = val
                            if addon.UpdateReadyCheckHelperLock then
                                addon:UpdateReadyCheckHelperLock()
                            end
                        end,
                    },
                    readyCheckTest = {
                        name = L["Test Ready Check Panel"],
                        desc = L["Show the helper briefly so you can place it."],
                        type = "execute",
                        order = 3,
                        width = 1.2,
                        func = function()
                            if addon.TestReadyCheckHelper then addon:TestReadyCheckHelper() end
                        end,
                    },
                    readyCheckReset = {
                        name = L["Reset Ready Check Position"],
                        type = "execute",
                        order = 4,
                        width = 1.2,
                        func = function()
                            if addon.ResetReadyCheckHelperPosition then addon:ResetReadyCheckHelperPosition() end
                        end,
                    },
                    restoreDefaults = {
                        name = L["Restore Defaults"],
                        type = "execute",
                        order = 100,
                        width = 1.2,
                        confirm = true,
                        confirmText = L["Reset all Ready Check Helper settings to defaults?"],
                        func = function()
                            local rc = db.readyCheckHelper
                            wipe(rc)
                            rc.enabled = false
                            rc.locked = false
                            rc.point = "CENTER"
                            rc.relPoint = "CENTER"
                            rc.xOfs = 0
                            rc.yOfs = 150
                            if addon.DisableReadyCheckHelper then addon:DisableReadyCheckHelper() end
                            if addon.ResetReadyCheckHelperPosition then addon:ResetReadyCheckHelperPosition() end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                        end,
                    },
                },
            },
            assistant = {
                name = L["Single-Button Assistant"],
                type = "group",
                args = {
                    assistantDesc = {
                        name = L["WoW's Assisted Combat suggests your next ability. To use it: press |cffffd100P|r to open your spellbook, then drag the Assisted Combat icon (top-right of that window) onto an action bar. This add-on can then tidy up that suggestion:"],
                        type = "description",
                        order = 0.5,
                        fontSize = "medium",
                    },
                    assistantHideArrow = {
                        name = L["Hide Suggestion Arrow"],
                        desc = L["Remove the moving arrow / glow that WoW draws over the currently-suggested ability."],
                        type = "toggle", width = 1.4,
                        order = 1,
                        get = function() return db.singleButtonAssistantKeybind.hideArrow end,
                        set = function(_, val)
                            db.singleButtonAssistantKeybind.hideArrow = val
                            if addon.RefreshSingleButtonAssistantKeybind then
                                addon.RefreshSingleButtonAssistantKeybind()
                            end
                        end,
                    },
                    assistantShowKeybind = {
                        name = L["Show Suggested Keybind"],
                        desc = L["Show the keybind of the currently-suggested ability over its action button (the normal hotkey text is hidden while it is active)."],
                        type = "toggle", width = 1.4,
                        order = 2,
                        get = function() return db.singleButtonAssistantKeybind.showKeybind end,
                        set = function(_, val)
                            db.singleButtonAssistantKeybind.showKeybind = val
                            if addon.RefreshSingleButtonAssistantKeybind then
                                addon.RefreshSingleButtonAssistantKeybind()
                            end
                        end,
                    },
                    akcRRPromoSpacer = {
                        name = "\n\n\n",
                        type = "description",
                        order = 190,
                    },
                    akcRRPromoHeader = {
                        name = L["|cFFF59E0BWant a fully-featured, professional single-button assistant?|r"],
                        type = "description",
                        order = 191,
                        fontSize = "large",
                        image = "Interface\\AddOns\\AkcQOL\\Media\\Icon",
                        imageWidth = 44,
                        imageHeight = 44,
                    },
                    akcRRPromoBody = {
                        name = L["\nGet |cff8c5cffAkc|r|cffffffffQOR|r |cFFE5E7EB— the dedicated rotation addon by the same author.|r\n\n|cFFE5E7EBAvailable on|r |cFFF59E0BCurseForge|r |cFFE5E7EBand|r |cFFF59E0BWago|r|cFFE5E7EB.|r\n"],
                        type = "description",
                        order = 192,
                        fontSize = "large",
                    },
                    restoreDefaults = {
                        name = L["Restore Defaults"],
                        type = "execute",
                        order = 100,
                        width = 1.2,
                        confirm = true,
                        confirmText = L["Reset all Single-Button Assistant settings to defaults?"],
                        func = function()
                            local sba = db.singleButtonAssistantKeybind
                            sba.enabled = false
                            sba.hideArrow = false
                            sba.showKeybind = false
                            if addon.RefreshSingleButtonAssistantKeybind then
                                addon.RefreshSingleButtonAssistantKeybind()
                            end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                        end,
                    },
                },
            },
        },
    }


    local actionBarArgs = {
        description = {
            name = L["Fade selected Blizzard action bars until your mouse is over them."],
            type = "description",
            order = 0.1,
            fontSize = "medium",
        },
        enabled = {
            name = L["Enable Action Bar Mouseover"],
            desc = L["Fade selected Blizzard action bars until your mouse is over them."],
            type = "toggle",
            order = 1,
            width = 1.4,
            get = function() return actionBarMouseover.enabled end,
            set = function(_, val)
                actionBarMouseover.enabled = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
                if _G.AkcQOL_ApplyBarButton then _G.AkcQOL_ApplyBarButton() end
            end,
        },
        showBarButton = {
            name = L["Show Toggle Button on Action Bar"],
            desc = L["Shows a small checkbox next to your main action bar that turns this feature on/off. It stays hidden until you hover it. Right-click it to open these settings."],
            type = "toggle",
            order = 1.1,
            width = 2,
            get = function() return AkcQOLDB ~= nil and AkcQOLDB.global ~= nil and AkcQOLDB.global.showActionBarButton == true end,
            set = function(_, val)
                if not (AkcQOLDB and AkcQOLDB.global) then return end
                AkcQOLDB.global.showActionBarButton = val
                if _G.AkcQOL_ApplyBarButton then _G.AkcQOL_ApplyBarButton() end
            end,
        },
        restoreDefaults = {
            name = L["Restore Defaults"],
            type = "execute",
            order = 100,
            width = 1.2,
            confirm = true,
            confirmText = L["Reset all Action Bar Mouseover settings to defaults?"],
            func = function()
                wipe(actionBarMouseover)
                EnsureActionBarMouseoverDB(db)
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
                LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
            end,
        },
        fadeHeader = {
            name = L["Fading"],
            type = "header",
            order = 1.5,
        },
        minAlpha = {
            name = L["Hidden Alpha"],
            desc = L["Alpha used when the bar is not hovered."],
            type = "range",
            order = 2,
            width = 1.5,
            min = 0, max = 1, step = 0.05,
            get = function() return NormalizeAlpha(actionBarMouseover.minAlpha, 0) end,
            set = function(_, val)
                actionBarMouseover.minAlpha = NormalizeAlpha(val, 0)
                if actionBarMouseover.maxAlpha < actionBarMouseover.minAlpha then
                    actionBarMouseover.maxAlpha = actionBarMouseover.minAlpha
                end
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        maxAlpha = {
            name = L["Visible Alpha"],
            desc = L["Alpha used when the bar is hovered or forced visible."],
            type = "range",
            order = 3,
            width = 1.5,
            min = 0, max = 1, step = 0.05,
            get = function() return NormalizeAlpha(actionBarMouseover.maxAlpha, 1) end,
            set = function(_, val)
                actionBarMouseover.maxAlpha = NormalizeAlpha(val, 1)
                if actionBarMouseover.maxAlpha < actionBarMouseover.minAlpha then
                    actionBarMouseover.maxAlpha = actionBarMouseover.minAlpha
                end
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        hoverDelay = {
            name = L["Mouse Leave Delay"],
            desc = L["Keeps selected bars visible briefly after the mouse leaves, so flyout menus can be selected."],
            type = "range",
            order = 4,
            width = 1.5,
            min = 0, max = 2, step = 0.05,
            get = function() return NormalizeNumber(actionBarMouseover.hoverDelay, 0.7, 0, 2) end,
            set = function(_, val)
                actionBarMouseover.hoverDelay = NormalizeNumber(val, 0.7, 0, 2)
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        alwaysShowInCombat = {
            name = L["Keep Visible In Combat"],
            desc = L["Selected bars stay fully visible while you are in combat."],
            type = "toggle", width = 1.4,
            order = 5,
            get = function() return actionBarMouseover.alwaysShowInCombat end,
            set = function(_, val)
                actionBarMouseover.alwaysShowInCombat = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        alwaysShowInEditMode = {
            name = L["Keep Visible In Edit Mode"],
            desc = L["Selected bars stay fully visible while Blizzard Edit Mode is open."],
            type = "toggle", width = 1.4,
            order = 6,
            get = function() return actionBarMouseover.alwaysShowInEditMode end,
            set = function(_, val)
                actionBarMouseover.alwaysShowInEditMode = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        barsHeader = {
            name = L["Bars"],
            type = "header",
            order = 10,
        },
    }

    local barOrder = 11
    for _, def in ipairs(ACTION_BAR_MOUSEOVER_BARS) do
        local key = def.key
        actionBarArgs["bar_" .. key] = {
            name = def.name,
            type = "toggle", width = 1.4,
            order = barOrder,
            get = function() return actionBarMouseover.bars[key] end,
            set = function(_, val)
                actionBarMouseover.bars[key] = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        }
        barOrder = barOrder + 1
    end

    actionBarArgs.resetAlpha = {
        name = L["Reset Bars"],
        desc = L["Uncheck all selected bars and return bars touched by this feature to full alpha."],
        type = "execute",
        order = 30,
        width = 1.2,
        func = function()
            if addon.DisableActionBarMouseover then addon:DisableActionBarMouseover() end
            for _, def in ipairs(ACTION_BAR_MOUSEOVER_BARS) do
                actionBarMouseover.bars[def.key] = false
            end
            if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
        end,
    }

    options.args.actionBarMouseover = {
        name = L["Action Bar Mouseover"],
        type = "group",
        order = 3,
        args = actionBarArgs,
    }

    options.args.personalLocator = {
        name = L["Personal Locator"],
        type = "group",
        order = 4,
        args = {
            description = {
                name = L["A lightweight screen-space character marker and mouse halo. Both are click-through, combat-safe, and independently configurable."],
                type = "description",
                order = 0.1,
                fontSize = "medium",
            },
            preview = {
                name = L["Preview Both (8 Seconds)"],
                desc = L["Temporarily show the current character marker and mouse circle without changing their enabled settings."],
                type = "execute",
                order = 2,
                width = 1.2,
                func = function()
                    if addon.PreviewPersonalLocator then addon:PreviewPersonalLocator() end
                end,
            },
            restoreDefaults = {
                name = L["Restore Defaults"],
                type = "execute",
                order = 100,
                width = 1.2,
                confirm = true,
                confirmText = L["Reset all Personal Locator settings to defaults?"],
                func = function()
                    wipe(personalLocator)
                    EnsurePersonalLocatorDB(db)
                    RefreshPersonalLocator()
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
            playerHeader = {
                name = L["Where I Am — Character Marker"],
                type = "header",
                order = 10,
            },
            playerEnabled = {
                name = L["Enable Character Marker"],
                desc = L["Show an adjustable marker over your character's screen position."],
                type = "toggle",
                order = 11,
                width = 1.4,
                get = function() return personalLocator.player.enabled end,
                set = function(_, val)
                    personalLocator.player.enabled = val
                    RefreshPersonalLocator()
                end,
            },
            playerCombatOnly = {
                name = L["Character Marker: Combat Only"],
                type = "toggle", width = 2,
                order = 12,
                get = function() return personalLocator.player.combatOnly end,
                set = function(_, val)
                    personalLocator.player.combatOnly = val
                    RefreshPersonalLocator()
                end,
            },
            playerStyle = {
                name = L["Marker Style"],
                type = "select",
                order = 13,
                width = 1.5,
                values = {
                    crosshair = L["Crosshair"],
                    brackets = L["Target Brackets"],
                    beacon = L["Downward Beacon"],
                    ring = L["Ground Ring"],
                },
                get = function() return personalLocator.player.style end,
                set = function(_, val)
                    personalLocator.player.style = val
                    RefreshPersonalLocator()
                end,
            },
            playerClassColor = {
                name = L["Use Class Color"],
                desc = L["Color the marker with your class color. Overrides the manual color below (alpha is kept)."],
                type = "toggle", width = 1.4,
                order = 13.3,
                get = function() return personalLocator.player.classColor end,
                set = function(_, val)
                    personalLocator.player.classColor = val
                    RefreshPersonalLocator()
                end,
            },
            playerColor = {
                name = L["Marker Color"],
                type = "color", width = 0.8,
                order = 14,
                hasAlpha = true,
                disabled = function() return personalLocator.player.classColor end,
                get = function()
                    local c = personalLocator.player.color
                    return c.r, c.g, c.b, c.a
                end,
                set = function(_, r, g, b, a)
                    local c = personalLocator.player.color
                    c.r, c.g, c.b, c.a = r, g, b, a
                    RefreshPersonalLocator()
                end,
            },
            playerPulse = {
                name = L["Pulse Animation"],
                desc = L["Gently breathe the marker in and out so it stays easy to spot."],
                type = "toggle", width = 1.4,
                order = 14.3,
                get = function() return personalLocator.player.pulse end,
                set = function(_, val)
                    personalLocator.player.pulse = val
                    RefreshPersonalLocator()
                end,
            },
            playerSpin = {
                name = L["Spin Animation"],
                desc = L["Slowly rotate the marker. Best with the Ground Ring and Target Brackets styles."],
                type = "toggle", width = 1.4,
                order = 14.4,
                get = function() return personalLocator.player.spin end,
                set = function(_, val)
                    personalLocator.player.spin = val
                    RefreshPersonalLocator()
                end,
            },
            playerSize = {
                name = L["Marker Size"],
                type = "range",
                order = 15,
                width = 1.5,
                min = 20, max = 160, step = 2,
                get = function() return personalLocator.player.size end,
                set = function(_, val)
                    personalLocator.player.size = val
                    RefreshPersonalLocator()
                end,
            },
            playerThickness = {
                name = L["Line Thickness"],
                type = "range",
                order = 16,
                width = 1.5,
                min = 1, max = 12, step = 1,
                get = function() return personalLocator.player.thickness end,
                set = function(_, val)
                    personalLocator.player.thickness = val
                    RefreshPersonalLocator()
                end,
            },
            playerOutline = {
                name = L["Black Outline"],
                type = "range",
                order = 17,
                width = 1.5,
                min = 0, max = 6, step = 1,
                get = function() return personalLocator.player.outline end,
                set = function(_, val)
                    personalLocator.player.outline = val
                    RefreshPersonalLocator()
                end,
            },
            playerGap = {
                name = L["Center Gap"],
                desc = L["Empty space at the center of Crosshair and Beacon styles."],
                type = "range",
                order = 18,
                width = 1.5,
                min = 0, max = 40, step = 1,
                get = function() return personalLocator.player.gap end,
                set = function(_, val)
                    personalLocator.player.gap = val
                    RefreshPersonalLocator()
                end,
            },
            playerOffsetX = {
                name = L["Horizontal Offset"],
                desc = L["Move the marker left or right from screen center."],
                type = "range",
                order = 19,
                width = 1.5,
                min = -300, max = 300, step = 1,
                get = function() return personalLocator.player.offsetX end,
                set = function(_, val)
                    personalLocator.player.offsetX = val
                    RefreshPersonalLocator()
                end,
            },
            playerUnlock = {
                name = L["Unlock — Drag to Position"], type = "toggle", order = 18.5, width = 2,
                desc = L["Unlocks the marker so you can drag it straight onto your character. The two offset sliders update themselves as you drop it. Lock it again when you are done."],
                get = function() return personalLocator.player.unlock == true end,
                set = function(_, v)
                    if _G.AkcQOL_SetLocatorUnlock then _G.AkcQOL_SetLocatorUnlock(v) end
                end,
            },
            playerRecenter = {
                name = L["Center Marker"], type = "execute", order = 18.6, width = 1.2,
                desc = L["Puts the marker back to the middle of the screen."],
                func = function()
                    if _G.AkcQOL_CenterLocatorMarker then _G.AkcQOL_CenterLocatorMarker() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
            playerOffsetY = {
                name = L["Vertical Offset"],
                desc = L["Move the marker up or down until it matches your camera and character position."],
                type = "range",
                order = 20,
                width = 1.5,
                min = -300, max = 300, step = 1,
                get = function() return personalLocator.player.offsetY end,
                set = function(_, val)
                    personalLocator.player.offsetY = val
                    RefreshPersonalLocator()
                end,
            },
            cursorHeader = {
                name = L["Mouse Circle"],
                type = "header",
                order = 30,
            },
            cursorEnabled = {
                name = L["Enable Mouse Circle"],
                desc = L["Show a smooth, click-through halo around the hardware cursor."],
                type = "toggle",
                order = 31,
                width = 1.4,
                get = function() return personalLocator.cursor.enabled end,
                set = function(_, val)
                    personalLocator.cursor.enabled = val
                    RefreshPersonalLocator()
                end,
            },
            cursorCombatOnly = {
                name = L["Mouse Circle: Combat Only"],
                type = "toggle", width = 1.4,
                order = 32,
                get = function() return personalLocator.cursor.combatOnly end,
                set = function(_, val)
                    personalLocator.cursor.combatOnly = val
                    RefreshPersonalLocator()
                end,
            },
            cursorClassColor = {
                name = L["Use Class Color"],
                desc = L["Color the cursor circle with your class color. Overrides the manual color below (alpha is kept)."],
                type = "toggle", width = 1.4,
                order = 32.5,
                get = function() return personalLocator.cursor.classColor end,
                set = function(_, val)
                    personalLocator.cursor.classColor = val
                    RefreshPersonalLocator()
                end,
            },
            cursorColor = {
                name = L["Circle Color"],
                type = "color", width = 0.8,
                order = 33,
                hasAlpha = true,
                disabled = function() return personalLocator.cursor.classColor end,
                get = function()
                    local c = personalLocator.cursor.color
                    return c.r, c.g, c.b, c.a
                end,
                set = function(_, r, g, b, a)
                    local c = personalLocator.cursor.color
                    c.r, c.g, c.b, c.a = r, g, b, a
                    RefreshPersonalLocator()
                end,
            },
            cursorSize = {
                name = L["Circle Size"],
                type = "range",
                order = 34,
                width = 1.5,
                min = 24, max = 160, step = 2,
                get = function() return personalLocator.cursor.size end,
                set = function(_, val)
                    personalLocator.cursor.size = val
                    RefreshPersonalLocator()
                end,
            },
            cursorThickness = {
                name = L["Circle Thickness"],
                type = "range",
                order = 35,
                width = 1.5,
                min = 1, max = 12, step = 1,
                get = function() return personalLocator.cursor.thickness end,
                set = function(_, val)
                    personalLocator.cursor.thickness = val
                    RefreshPersonalLocator()
                end,
            },
            cursorOutline = {
                name = L["Circle Outline"],
                type = "range",
                order = 36,
                width = 1.5,
                min = 0, max = 6, step = 1,
                get = function() return personalLocator.cursor.outline end,
                set = function(_, val)
                    personalLocator.cursor.outline = val
                    RefreshPersonalLocator()
                end,
            },
            cursorDot = {
                name = L["Show Center Dot"],
                type = "toggle", width = 1.4,
                order = 37,
                get = function() return personalLocator.cursor.dot end,
                set = function(_, val)
                    personalLocator.cursor.dot = val
                    RefreshPersonalLocator()
                end,
            },
            cursorPulse = {
                name = L["Soft Pulse"],
                desc = L["Apply a subtle alpha pulse to make the cursor easier to recover in visual clutter."],
                type = "toggle", width = 1.4,
                order = 38,
                get = function() return personalLocator.cursor.pulse end,
                set = function(_, val)
                    personalLocator.cursor.pulse = val
                    RefreshPersonalLocator()
                end,
            },
            cursorSpin = {
                name = L["Spin Animation"],
                desc = L["Slowly rotate the cursor ring for a lively, easy-to-track halo."],
                type = "toggle", width = 1.4,
                order = 39,
                get = function() return personalLocator.cursor.spin end,
                set = function(_, val)
                    personalLocator.cursor.spin = val
                    RefreshPersonalLocator()
                end,
            },
            cursorTrail = {
                name = L["Motion Trail"],
                desc = L["Leave a short fading trail of soft dots behind the cursor as it moves — great for finding the pointer fast."],
                type = "toggle", width = 1.4,
                order = 40,
                get = function() return personalLocator.cursor.trail end,
                set = function(_, val)
                    personalLocator.cursor.trail = val
                    RefreshPersonalLocator()
                end,
            },
            cursorCrosshair = {
                name = L["Precision Crosshair"],
                desc = L["Add thin cross lines through the cursor center for precise aiming."],
                type = "toggle", width = 1.4,
                order = 41,
                get = function() return personalLocator.cursor.crosshair end,
                set = function(_, val)
                    personalLocator.cursor.crosshair = val
                    RefreshPersonalLocator()
                end,
            },
        },
    }


    if _G.AkcQOLQoLSettingsGroups then
        for k, v in pairs(_G.AkcQOLQoLSettingsGroups) do
            options.args[k] = v
        end
    end

    local function BoxifyGroup(group, boxes)
        if type(group) ~= "table" or type(group.args) ~= "table" then return end
        if akcBoxedGroups[group] then return end

        local source = group.args
        local placed = {}
        local newArgs = {}
        local boxOrder = 0

        for _, box in ipairs(boxes) do
            local inner = {}
            local innerOrder = 0
            for _, key in ipairs(box.keys) do
                local entry = source[key]
                if entry then
                    placed[key] = true
                    innerOrder = innerOrder + 1
                    entry.order = innerOrder
                    if entry.type == "toggle" and entry.width == "full" then
                        entry.width = nil
                    end
                    inner[key] = entry
                end
            end
            if next(inner) then
                boxOrder = boxOrder + 1
                newArgs["akcbox" .. boxOrder] = {
                    name = box.title,
                    type = "group",
                    inline = true,
                    order = boxOrder,
                    args = inner,
                }
            end
        end

        local leftover = {}
        for key, entry in pairs(source) do
            if not placed[key] then leftover[key] = entry end
        end
        if next(leftover) then
            boxOrder = boxOrder + 1
            newArgs["akcbox" .. boxOrder] = {
                name = L["Other"],
                type = "group",
                inline = true,
                order = boxOrder,
                args = leftover,
            }
        end

        group.args = newArgs
        akcBoxedGroups[group] = true
    end

    BoxifyGroup(options.args.qolAutomation, {
        { title = L["Vendor & Loot"], keys = { "autoSell", "autoRepair", "fastLoot" } },
        { title = L["Convenience"], keys = { "autoInsertKeystone", "autoCinematic", "hideProfessionOutfit" } },
        { title = L["Group & Chat"], keys = { "autoAcceptInvite", "autoAcceptMode", "announceInstanceReset" } },
        { title = L["Interface"], keys = { "addonProfilePanel" } },
        { title = L["Performance"], keys = { "dynamicFPS" } },
    })

    BoxifyGroup(options.args.qolDisplay, {
        { title = L["On Screen"], keys = { "showMinimap", "showRaidProgress", "wipeChatPrint" } },
        { title = L["Item Level"], keys = { "showItemLevel", "ilvlArrow", "ilvlGemEnchant", "ilvlDecimals" } },
        { title = L["Combat Numbers"], keys = {
            "combatTextFont", "combatTextFontFace", "combatTextAnim", "combatTextScale",
            "combatRiseHeight", "combatRiseSpeed", "combatSelfFloatMode",
        } },
    })

    BoxifyGroup(options.args.qolHud, {
        { title = L["Talent Helper"], keys = { "showTalentHelper", "talentWarning", "talentAutoScale" } },
        { title = L["HUD Panel"], keys = { "hudDesc", "showHUD", "hudLocked", "hudScale", "hudPreview", "hudResetPos" } },
    })

    BoxifyGroup(options.args.qolLogging, {
        { title = L["What to Log"], keys = { "desc", "logMailTradeLoot", "logChat", "logLootTrash" } },
        { title = L["Housekeeping"], keys = { "restoreUntil" } },
    })

    if options.args.personalLocator and options.args.personalLocator.args then
        options.args.personalLocator.args.playerHeader = nil
        options.args.personalLocator.args.cursorHeader = nil
    end

    BoxifyGroup(options.args.personalLocator, {
        { title = L["Overview"], keys = { "description", "preview" } },
        { title = L["Character Marker"], keys = {
            "playerEnabled", "playerCombatOnly", "playerClassColor",
            "playerPulse", "playerSpin", "playerStyle", "playerColor" } },
        { title = L["Marker Size & Position"], keys = {
            "playerSize", "playerThickness", "playerOutline", "playerGap",
            "playerOffsetX", "playerOffsetY", "playerUnlock", "playerRecenter" } },
        { title = L["Mouse Circle"], keys = {
            "cursorEnabled", "cursorCombatOnly", "cursorClassColor",
            "cursorDot", "cursorPulse", "cursorSpin", "cursorTrail",
            "cursorCrosshair", "cursorColor" } },
        { title = L["Circle Size"], keys = {
            "cursorSize", "cursorThickness", "cursorOutline" } },
        { title = L["Tools"], keys = { "restoreDefaults" } },
    })

    BoxifyGroup(options.args.recentSpells, {
        { title = L["The Bar"],          keys = { "desc", "enabled", "count", "iconSize", "scale" } },
        { title = L["Layout"],           keys = { "orientation", "newestSide", "locked", "resetPos" } },
        { title = L["Icon Behaviour"],   keys = { "lifetime", "onlySpells", "popAnim" } },
        { title = L["Tooltip"],          keys = { "tooltips", "tooltipAnchor" } },
        { title = L["Tools"],            keys = { "preview", "restoreDefaults" } },
    })


    options.args.overview = {
        name = L["Overview"],
        type = "group",
        args = {
            title = {
                name = "|cff8c5cffAkc|r|cffffffffQOL|r  —  " .. L["Quality of Life"],
                type = "header",
                order = 1,
            },
            blurb = {
                name = L["A unified quality-of-life toolkit — automation, display tweaks, HUD, mouseover bars and more, all in one panel. Pick a tile above to begin."],
                type = "description",
                fontSize = "medium",
                order = 2,
            },
            aboutHeader = {
                name = L["About & Credits"],
                type = "header", hidden = true,
                order = 5,
            },
            aboutText = {
                name = L["AkcQOL is a personal merge: ideas learned from many wonderful community addons, unified into one package and always under development. |cFFF59E0BStrictly non-commercial|r — no payments, no donations, ever.\nFull credit to the original authors; no claim of original invention. Authors — reach out and any credit or change is handled immediately."],
                type = "description",
                fontSize = "small",
                order = 6,
            },
            cmdHeader = {
                name = L["Slash Commands"],
                type = "header", hidden = true,
                order = 10,
            },
            cmds = {
                name = "|cff8c5cff/akc|r " .. L["Open the main Matrix window (the addon's icon grid)"] .. "   |cff8c5cff/akctalent|r " .. L["Open talent builds"] .. "   |cff8c5cff/akcsettings|r " .. L["Open these settings"],
                type = "description",
                fontSize = "small",
                order = 11,
            },

            wvHeader = {
                name = L["Warvideo"],
                type = "header", hidden = true,
                order = 20,
            },
            wvLogging = {
                name = L["Enable combat logging for Warvideo"],
                desc = L["Off by default. When on, AkcQOL turns on WoW's combat logging INSIDE instances (raid / dungeon / scenario) so Warvideo's macOS app can auto-capture boss HP and wipes. It never logs in the open world, and it only manages logging that it turned on.\n\n|cffff8080Windows note:|r while logging, real-time antivirus (e.g. Windows Defender) scanning the growing Logs\\WoWCombatLog.txt file can drop your FPS badly. If you enable this, add your WoW \"_retail_\\Logs\" folder to your antivirus exclusions."],
                type = "toggle",
                order = 21,
                width = 2,
                get = function() return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.warvideoLogging == true end,
                set = function(_, v)
                    EnsureGlobal().warvideoLogging = v
                    if _G.AkcQOL_ApplyWarvideoLogging then _G.AkcQOL_ApplyWarvideoLogging() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
            wvStatus = {
                name = function()
                    local setOn = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.warvideoLogging == true

                    if not setOn then
                        return "|TInterface\\COMMON\\Indicator-Red:14:14|t  " .. L["Combat logging: |cffff4040off|r (default)"]
                    end
                    local live
                    pcall(function()
                        local v = LoggingCombat and LoggingCombat()
                        if v == nil or (issecretvalue and issecretvalue(v)) then return end
                        live = v and true or false
                    end)
                    if live then
                        return "|TInterface\\COMMON\\Indicator-Green:14:14|t  " .. L["Combat logging: |cff20ff20active|r (you're in an instance)"]
                    end
                    return "|TInterface\\COMMON\\Indicator-Green:14:14|t  " .. L["Combat logging: |cffffd100on|r (starts when you enter an instance)"]
                end,
                type = "description",
                fontSize = "medium",
                order = 22,
            },
            wvDesc = {
                name = L["Warvideo's macOS app auto-records boss fights from your combat log. Turn the toggle above on only if you use Warvideo — it's off by default, so the addon changes nothing on a fresh install."],
                type = "description", hidden = true,
                fontSize = "medium",
                order = 23,
            },
            wvSite = {
                name = L["Site"],
                desc = L["Warvideo: the macOS app that auto-records from your combat log (shown for reference; you can select and copy the text)."],
                type = "input",
                order = 21.5,
                width = 2,
                get = function() return "warvideo.app" end,
                set = function() end,
            },
        },
    }

    options.args.skyriding = {
        name = L["Skyriding"], type = "group",
        args = {
            desc = {
                name = L["An on-screen tracker for your skyriding abilities. It appears only while you are on a skyriding mount."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            preview = {
                name = L["Preview Tracker (12 Seconds)"],
                desc = L["Show the tracker on top so you can drag it into place, even while not flying."],
                type = "execute", order = 4, width = 1.2,
                func = function() if _G.AkcQOL_PreviewSkyriding then _G.AkcQOL_PreviewSkyriding() end end,
            },
            resetPos = {
                name = L["Reset Position (Center)"],
                type = "execute", order = 5, width = 1.2,
                func = function() if _G.AkcQOL_ResetSkyridingPosition then _G.AkcQOL_ResetSkyridingPosition() end end,
            },
            enabled = {
                name = L["Enable Skyriding Tracker"], type = "toggle", order = 1, width = 1.4,
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.skyriding; return not d or d.enabled ~= false end,
                set = function(_, v)
                    EnsureGlobal("skyriding").enabled = v
                    if _G.AkcQOL_ApplySkyridingVisibility then _G.AkcQOL_ApplySkyridingVisibility() end
                end,
            },
            style = {
                name = L["Layout"], type = "select", order = 2, width = 1.5,
                values = { icons = L["Icon row"], bars = L["Compact bars"], vigor = L["Vigor bar (segmented)"] },
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.skyriding and AkcQOLDB.global.skyriding.style) or "icons" end,
                set = function(_, v) if _G.AkcQOL_SetSkyridingStyle then _G.AkcQOL_SetSkyridingStyle(v) end end,
            },
            showSpeed = {
                name = L["Show Speed Bar"],
                desc = L["Adds a thin flight-speed readout (as % of run speed) under the Vigor bar layout. Turns gold near top speed (Thrill of the Skies)."],
                type = "toggle", order = 2.5, width = 1.4,
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.skyriding
                    return not d or d.showSpeed ~= false
                end,
                set = function(_, v)
                    EnsureGlobal("skyriding").showSpeed = v
                    if _G.AkcQOL_RefreshSkyriding then _G.AkcQOL_RefreshSkyriding() end
                end,
            },
            scale = {
                name = L["Scale"], type = "range", order = 3, width = 1.5,
                min = 0.5, max = 2.0, step = 0.05, isPercent = true,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.skyriding and AkcQOLDB.global.skyriding.scale) or 1.0 end,
                set = function(_, v) if _G.AkcQOL_SetSkyridingScale then _G.AkcQOL_SetSkyridingScale(v) end end,
            },
            restoreDefaults = {
                name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                confirm = true,
                confirmText = L["Reset all Skyriding Tracker settings to defaults?"],
                func = function()
                    if _G.AkcQOL_ResetSkyridingDefaults then _G.AkcQOL_ResetSkyridingDefaults() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
        },
    }

    options.args.wowLatency = {
        name = L["WoW Latency"], type = "group",
        args = {
            desc = {
                name = L["Fine-tune how responsive the game feels. These change Blizzard console variables (CVars) directly -- nothing here is active until you change it, and it affects your whole ACCOUNT, not just this character."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            sqwHeader = { name = L["Spell Queue Window"], type = "header", order = 1 },
            sqwDesc = {
                name = L["When you press an ability during the last part of your current cast or global cooldown, the game \"queues\" it so it fires the instant the current action ends -- this hides your latency and keeps your rotation gap-free. Blizzard's default is 400 ms, which can feel sluggish (your key presses commit early). Lowering it makes the character feel snappier and more responsive; but set it too low and you must press closer to on-time or a gap opens between abilities.\n\nGood value = your world ping + about 100 ms (e.g. 45 ms ping -> ~145 ms). The button below sets that for you automatically."],
                type = "description", order = 1.1, fontSize = "medium",
            },
            sqwStatus = {
                type = "description", order = 1.2, fontSize = "medium",
                name = function()
                    local cur  = _G.AkcQOL_GetSpellQueueWindow and _G.AkcQOL_GetSpellQueueWindow()
                    local ping = _G.AkcQOL_GetWorldPing and _G.AkcQOL_GetWorldPing()
                    local rec  = _G.AkcQOL_GetRecommendedSQW and _G.AkcQOL_GetRecommendedSQW()
                    return string.format(
                        L["Current window: |cff8c5cff%s ms|r      Your world ping: |cff8c5cff%s ms|r      Recommended: |cff8c5cff%s ms|r"],
                        tostring(cur or "?"), tostring(ping or "?"), tostring(rec or "?"))
                end,
            },
            sqw = {
                name = L["Spell Queue Window (ms)"], type = "range", order = 1.3, width = 1.5,
                min = 0, max = 400, step = 10, bigStep = 10,
                get = function() return _G.AkcQOL_GetSpellQueueWindow and _G.AkcQOL_GetSpellQueueWindow() or 400 end,
                set = function(_, v)
                    if _G.AkcQOL_SetSpellQueueWindow then _G.AkcQOL_SetSpellQueueWindow(v) end
                end,
            },
            sqwRecommended = {
                name = L["Apply Recommended (ping + 100)"], type = "execute", order = 1.4, width = 1.2,
                desc = L["Sets the window to your current world ping + 100 ms (kept within 100-400)."],
                func = function()
                    if _G.AkcQOL_ApplyRecommendedSQW then _G.AkcQOL_ApplyRecommendedSQW() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
            sqwReset = {
                name = L["Reset to Default (400)"], type = "execute", order = 1.5, width = 1.2,
                func = function()
                    if _G.AkcQOL_SetSpellQueueWindow then _G.AkcQOL_SetSpellQueueWindow(400) end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
            sqwCurrent = {
                name = L["Show Current Value"], type = "execute", order = 1.6, width = 1.2,
                desc = L["Prints the current Spell Queue Window value to chat, so you can confirm it."],
                func = function() if _G.AkcQOL_PrintSpellQueueWindow then _G.AkcQOL_PrintSpellQueueWindow() end end,
            },
            netHeader = { name = L["Network"], type = "header", order = 2 },
            nagle = {
                name = L["Optimize Network for Speed"], type = "toggle", order = 2.1, width = 1.4,
                desc = L["Disables the server-side Nagle algorithm so the game sends smaller network packets more often instead of batching them -- this can shave perceived latency at the cost of slightly more network overhead. This is the same option as the \"Optimize Network for Speed\" checkbox in ESC > Options > Network; toggling it here changes that setting too."],
                get = function() return _G.AkcQOL_GetNagleOptimize and _G.AkcQOL_GetNagleOptimize() end,
                set = function(_, v) if _G.AkcQOL_SetNagleOptimize then _G.AkcQOL_SetNagleOptimize(v) end end,
            },
            ipv6 = {
                name = L["Enable IPv6 (requires game restart)"], type = "toggle", order = 2.2, width = 2,
                desc = L["Makes the client connect to realms over IPv6 instead of IPv4. On some ISPs (including several in Turkey) this can cut sudden ping spikes; on others it does nothing or isn't available. |cffffcc00This only takes effect after a FULL game restart|r (the connection is opened at login). Only useful if your connection has real native IPv6."],
                get = function() return _G.AkcQOL_GetIPv6 and _G.AkcQOL_GetIPv6() end,
                set = function(_, v) if _G.AkcQOL_SetIPv6 then _G.AkcQOL_SetIPv6(v) end end,
            },
        },
    }

    options.args.recentSpells = {
        name = L["Cast History"], type = "group",
        args = {
            desc = {
                name = L["A bar that shows the icons of the abilities you most recently cast. Set how many icons to show below."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            preview = {
                name = L["Preview Tracker (30 Seconds)"],
                desc = L["Show the bar on top with sample icons so you can drag it into place."],
                type = "execute", order = 4, width = 1.2,
                func = function() if _G.AkcQOL_PreviewRecentSpells then _G.AkcQOL_PreviewRecentSpells() end end,
            },
            resetPos = {
                name = L["Reset Position (Center)"],
                type = "execute", order = 5, width = 1.2,
                func = function() if _G.AkcQOL_ResetRecentSpellsPosition then _G.AkcQOL_ResetRecentSpellsPosition() end end,
            },
            enabled = {
                name = L["Enable Cast History Bar"], type = "toggle", order = 1, width = 1.4,
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells; return d and d.enabled == true end,
                set = function(_, v)
                    EnsureGlobal("recentSpells").enabled = v
                    if _G.AkcQOL_ApplyRecentSpells then _G.AkcQOL_ApplyRecentSpells() end
                end,
            },
            count = {
                name = L["Number of Icons"], type = "range", order = 2, width = 1.5,
                min = 1, max = 12, step = 1,
                desc = L["How many of your most recent casts to display."],
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells and AkcQOLDB.global.recentSpells.count) or 5 end,
                set = function(_, v) if _G.AkcQOL_SetRecentSpellsCount then _G.AkcQOL_SetRecentSpellsCount(v) end end,
            },
            iconSize = {
                name = L["Icon Size"], type = "range", order = 2.5, width = 1.5,
                min = 20, max = 56, step = 1,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells and AkcQOLDB.global.recentSpells.iconSize) or 36 end,
                set = function(_, v) if _G.AkcQOL_SetRecentSpellsIconSize then _G.AkcQOL_SetRecentSpellsIconSize(v) end end,
            },
            orientation = {
                name = L["Bar Direction"], type = "select", order = 2.7, width = 1.5,
                desc = L["Lay the icons out side by side, or stacked from top to bottom."],
                values = { horizontal = L["Horizontal"], vertical = L["Vertical"] },
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    return (d and d.orientation == "vertical") and "vertical" or "horizontal"
                end,
                set = function(_, v)
                    if _G.AkcQOL_SetRecentSpellsOrientation then _G.AkcQOL_SetRecentSpellsOrientation(v) end
                end,
            },
            newestSide = {
                name = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    if d and d.orientation == "vertical" then return L["Newest Cast End"] end
                    return L["Newest Cast Side"]
                end,
                type = "select", order = 3, width = 1.5,
                values = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    if d and d.orientation == "vertical" then
                        return { left = L["Top"], right = L["Bottom"] }
                    end
                    return { left = L["Left"], right = L["Right"] }
                end,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells and AkcQOLDB.global.recentSpells.newest) or "left" end,
                set = function(_, v) if _G.AkcQOL_SetRecentSpellsSide then _G.AkcQOL_SetRecentSpellsSide(v) end end,
            },
            scale = {
                name = L["Scale"], type = "range", order = 3.5, width = 1.5,
                min = 0.5, max = 2.0, step = 0.05, isPercent = true,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells and AkcQOLDB.global.recentSpells.scale) or 1.0 end,
                set = function(_, v) if _G.AkcQOL_SetRecentSpellsScale then _G.AkcQOL_SetRecentSpellsScale(v) end end,
            },
            locked = {
                name = L["Lock Bar"], type = "toggle", order = 3.7, width = 1.4,
                desc = L["When locked, the bar is display-only and mouse clicks pass straight through it -- a left-click-drag over it still turns your camera, as if the bar weren't there. Unlock to grab and drag it into position, then lock it again."],
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells; return not d or d.locked ~= false end,
                set = function(_, v) if _G.AkcQOL_SetRecentSpellsLocked then _G.AkcQOL_SetRecentSpellsLocked(v) end end,
            },
            lifetime = {
                name = L["Icon Lifetime (seconds)"], type = "range", order = 3.4, width = 1.5,
                desc = L["Each icon fades out this long after you cast it. Set to 0 to keep them on screen until pushed off the end."],
                min = 0, max = 30, step = 1,
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    return (d and tonumber(d.lifetime)) or 10
                end,
                set = function(_, v)
                    if _G.AkcQOL_SetRecentSpellsLifetime then _G.AkcQOL_SetRecentSpellsLifetime(v) end
                end,
            },
            popAnim = {
                name = L["Pop Animation"], type = "toggle", order = 3.5, width = 1.4,
                desc = L["The newest icon briefly scales up and back down as it lands."],
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    return not d or d.popAnim ~= false
                end,
                set = function(_, v)
                    if _G.AkcQOL_SetRecentSpellsPop then _G.AkcQOL_SetRecentSpellsPop(v) end
                end,
            },
            onlySpells = {
                name = L["Skills Only"], type = "toggle", order = 3.6, width = 1.4,
                desc = L["Skip mounts, toys and hearthstones so only real abilities land on the bar."],
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    return not d or d.onlySpells ~= false
                end,
                set = function(_, v)
                    if _G.AkcQOL_SetRecentSpellsOnlySpells then _G.AkcQOL_SetRecentSpellsOnlySpells(v) end
                end,
            },
            tooltipAnchor = {
                name = L["Tooltip Position"], type = "select", order = 3.9, width = 1.5,
                desc = L["Where the spell tooltip appears when you hover an icon."],
                values = {
                    icon    = L["Next to the icon"],
                    default = L["Game's own tooltip corner"],
                },
                disabled = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    return d and d.tooltips == false
                end,
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells
                    return (d and d.tooltipAnchor == "default") and "default" or "icon"
                end,
                set = function(_, v)
                    if _G.AkcQOL_SetRecentSpellsTooltipAnchor then _G.AkcQOL_SetRecentSpellsTooltipAnchor(v) end
                end,
            },
            tooltips = {
                name = L["Show Tooltips on Hover"], type = "toggle", order = 3.8, width = 1.4,
                desc = L["Hovering an icon shows that spell's tooltip. This never blocks clicks -- a left-click-drag over the bar still turns your camera even with tooltips on."],
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.recentSpells; return not d or d.tooltips ~= false end,
                set = function(_, v) if _G.AkcQOL_SetRecentSpellsTooltips then _G.AkcQOL_SetRecentSpellsTooltips(v) end end,
            },
            restoreDefaults = {
                name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                confirm = true,
                confirmText = L["Reset all Cast History settings to defaults?"],
                func = function()
                    if _G.AkcQOL_ResetRecentSpellsDefaults then _G.AkcQOL_ResetRecentSpellsDefaults() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
        },
    }

    options.args.petAlert = {
        name = L["Pet Alert"], type = "group",
        args = {
            desc = {
                name = L["Plays a sound when your pet's health drops below the threshold. Works for any class with a pet (Hunter, Warlock, Death Knight, ...)."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            enabled = {
                name = L["Enable Pet Health Alert"], type = "toggle", order = 1, width = 1.4,
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert; return not d or d.enabled ~= false end,
                set = function(_, v)
                    EnsureGlobal("petAlert").enabled = v
                    if _G.AkcQOL_ApplyPetAlert then _G.AkcQOL_ApplyPetAlert() end
                end,
            },
            threshold = {
                name = L["Health Threshold (%)"], type = "range", order = 2, width = 1.5,
                min = 10, max = 95, step = 5,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.threshold) or 50 end,
                set = function(_, v)
                    EnsureGlobal("petAlert").threshold = v
                end,
            },
            soundHeader = {
                name = L["Sound & Text"],
                type = "header",
                order = 2.8,
            },
            sound = {
                name = function()
                    local cur = (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.soundStyle) or "bosswarn"
                    local label = (addon.GetSoundLabel and addon:GetSoundLabel(cur)) or cur
                    return L["Alert Sound:"] .. "  |cffffd100" .. label .. "|r"
                end,
                desc = L["Click to pick from WoW's full categorized sound menu (Alerts, Instruments, Animals, Impacts, Warcraft 3/2, Devices). Selecting a sound previews it."],
                type = "execute", order = 3, width = 1.5,
                func = function()
                    if addon.OpenSoundAlertMenu then
                        addon:OpenSoundAlertMenu(
                            function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.soundStyle) or "bosswarn" end,
                            function(key)
                                EnsureGlobal("petAlert").soundStyle = key
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                            end,
                            function() return AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.volume end)
                    end
                end,
            },
            volume = {
                name = L["Make It Stand Out"],
                desc = L["While this alert plays, your other game sounds (spell effects, music, ambience) briefly dip so the alert cuts through, then return to normal. Higher = a deeper dip. 0 = off. Use \"Test Sound + Text\" to preview."],
                type = "range", order = 3.5, width = 1.5,
                min = 0, max = 100, step = 5,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.volume) or 100 end,
                set = function(_, v)
                    EnsureGlobal("petAlert").volume = v
                end,
            },
            screen = {
                name = L["Show Screen Text"],
                desc = L["Flash the message below in the middle of the screen when your pet drops low (same as the PI Alert's screen text)."],
                type = "toggle", order = 3.6, width = 1.4,
                get = function() return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.screen == true end,
                set = function(_, v)
                    EnsureGlobal("petAlert").screen = v
                end,
            },
            message = {
                name = L["Screen Text"],
                desc = L["Text shown in the middle of the screen by the pet alert."],
                type = "input", order = 3.7, width = 2,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.petAlert and AkcQOLDB.global.petAlert.message) or "Pet health is LOW!" end,
                set = function(_, v)
                    EnsureGlobal("petAlert").message = (v and v ~= "") and v or "Pet health is LOW!"
                end,
            },
            test = {
                name = L["Test Sound + Text"], type = "execute", order = 4, width = 1.2,
                func = function() if _G.AkcQOL_TestPetAlert then _G.AkcQOL_TestPetAlert() end end,
            },
            restoreDefaults = {
                name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                confirm = true,
                confirmText = L["Reset all Pet Alert settings to defaults?"],
                func = function()
                    if _G.AkcQOL_ResetPetAlertDefaults then _G.AkcQOL_ResetPetAlertDefaults() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
        },
    }

    options.args.castAlert = {
        name = L["Cast Alert"], type = "group",
        args = {
            desc = {
                name = L["Warns you the moment an enemy starts casting a spell AT YOU — built for Mythic+. Requires enemy nameplates to be shown (default V key)."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            enabled = {
                name = L["Enable Cast Alert"], type = "toggle", order = 1, width = 1.4,
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert; return not d or d.enabled ~= false end,
                set = function(_, v)
                    EnsureGlobal("castAlert").enabled = v
                    if _G.AkcQOL_ApplyCastAlert then _G.AkcQOL_ApplyCastAlert() end
                end,
            },
            onlyInstances = {
                name = L["Only Inside Instances"],
                desc = L["Alert only in dungeons, raids and other instances. Untick to also alert in the open world."],
                type = "toggle", order = 1.5, width = 1.4,
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert; return not d or d.onlyInstances ~= false end,
                set = function(_, v)
                    EnsureGlobal("castAlert").onlyInstances = v
                end,
            },
            throttle = {
                name = L["Alert Cooldown (seconds)"],
                desc = L["Minimum time between two alerts, so back-to-back casts don't spam you."],
                type = "range", order = 2, width = 1.5,
                min = 1, max = 10, step = 1,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert and AkcQOLDB.global.castAlert.throttle) or 2 end,
                set = function(_, v)
                    EnsureGlobal("castAlert").throttle = v
                end,
            },
            soundHeader = {
                name = L["Sound & Text"],
                type = "header",
                order = 2.8,
            },
            sound = {
                name = function()
                    local cur = (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert and AkcQOLDB.global.castAlert.soundStyle) or "bosswarn"
                    local label = (addon.GetSoundLabel and addon:GetSoundLabel(cur)) or cur
                    return L["Alert Sound:"] .. "  |cffffd100" .. label .. "|r"
                end,
                desc = L["Click to pick from WoW's full categorized sound menu. Selecting a sound previews it."],
                type = "execute", order = 3, width = 1.5,
                func = function()
                    if addon.OpenSoundAlertMenu then
                        addon:OpenSoundAlertMenu(
                            function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert and AkcQOLDB.global.castAlert.soundStyle) or "bosswarn" end,
                            function(key)
                                EnsureGlobal("castAlert").soundStyle = key
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                            end,
                            function() return AkcQOLDB.global.castAlert and AkcQOLDB.global.castAlert.volume end)
                    end
                end,
            },
            volume = {
                name = L["Make It Stand Out"],
                desc = L["While this alert plays, your other game sounds (spell effects, music, ambience) briefly dip so the alert cuts through, then return to normal. Higher = a deeper dip. 0 = off. Use \"Test Sound + Text\" to preview."],
                type = "range", order = 3.5, width = 1.5,
                min = 0, max = 100, step = 5,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert and AkcQOLDB.global.castAlert.volume) or 100 end,
                set = function(_, v)
                    EnsureGlobal("castAlert").volume = v
                end,
            },
            screen = {
                name = L["Show Screen Text"],
                desc = L["Flash the spell name and the message below in the middle of the screen when an enemy casts at you."],
                type = "toggle", order = 3.6, width = 1.4,
                get = function() local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert; return not d or d.screen ~= false end,
                set = function(_, v)
                    EnsureGlobal("castAlert").screen = v
                end,
            },
            message = {
                name = L["Screen Text"],
                desc = L["Text shown after the spell name (e.g. \"FROSTBOLT • CASTING ON YOU!\")."],
                type = "input", order = 3.7, width = 2,
                get = function() return (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.castAlert and AkcQOLDB.global.castAlert.message) or "CASTING ON YOU!" end,
                set = function(_, v)
                    EnsureGlobal("castAlert").message = (v and v ~= "") and v or "CASTING ON YOU!"
                end,
            },
            test = {
                name = L["Test Sound + Text"], type = "execute", order = 4, width = 1.2,
                func = function() if _G.AkcQOL_TestCastAlert then _G.AkcQOL_TestCastAlert() end end,
            },
            restoreDefaults = {
                name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                confirm = true,
                confirmText = L["Reset all Cast Alert settings to defaults?"],
                func = function()
                    if _G.AkcQOL_ResetCastAlertDefaults then _G.AkcQOL_ResetCastAlertDefaults() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
        },
    }

    options.args.combatRez = {
        name = L["Combat Rez"], type = "group",
        args = {
            desc = {
                name = L["Tracks the shared combat-resurrection charges in raids and Mythic+: how many battle rezzes are available and how long until the next one. Optionally flashes a big warning when a group member dies."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            enabled = {
                name = L["Enable Combat Rez Timer"],
                desc = L["Shows the movable charge tracker inside raid encounters and Mythic+ keys (charges + time until the next charge). It stays hidden everywhere else."],
                type = "toggle", order = 1, width = 1.4,
                get = function() return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatRez and AkcQOLDB.global.combatRez.enabled == true end,
                set = function(_, v)
                    EnsureGlobal("combatRez").enabled = v
                    if _G.AkcQOL_ApplyCombatRez then _G.AkcQOL_ApplyCombatRez() end
                end,
            },
            unlock = {
                name = L["Unlock"],
                desc = L["Shows the tracker with sample values so you can drag it where you want, then untick to lock it. (Dragging is disabled during combat.)"],
                type = "toggle", order = 2, width = 1.4,
                get = function() return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatRez and AkcQOLDB.global.combatRez.unlock == true end,
                set = function(_, v)
                    EnsureGlobal("combatRez").unlock = v
                    if _G.AkcQOL_ApplyCombatRez then _G.AkcQOL_ApplyCombatRez() end
                end,
            },
            deathWarn = {
                name = L["Death as Warning"],
                desc = L["Flashes a big red \"<name> died!\" in the upper middle of the screen the moment a party/raid member dies."],
                type = "toggle", order = 3, width = 1.4,
                get = function()
                    local d = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.combatRez
                    return not d or d.deathWarn ~= false
                end,
                set = function(_, v)
                    EnsureGlobal("combatRez").deathWarn = v
                    if _G.AkcQOL_ApplyCombatRez then _G.AkcQOL_ApplyCombatRez() end
                end,
            },
            testDeath = {
                name = L["Test Death Warning"],
                desc = L["Preview the on-screen death warning with your own name."],
                type = "execute", order = 4, width = 1.2,
                func = function() if _G.AkcQOL_TestCombatRezDeathWarning then _G.AkcQOL_TestCombatRezDeathWarning() end end,
            },
            resetPos = {
                name = L["Reset Position"],
                desc = L["Moves the tracker back to its default spot (upper middle of the screen)."],
                type = "execute", order = 5, width = 1.2,
                func = function() if _G.AkcQOL_ResetCombatRezPosition then _G.AkcQOL_ResetCombatRezPosition() end end,
            },
            restoreDefaults = {
                name = L["Restore Defaults"], type = "execute", order = 100, width = 1.2,
                confirm = true,
                confirmText = L["Reset all Combat Rez settings to defaults?"],
                func = function()
                    wipe(EnsureGlobal("combatRez"))
                    if _G.AkcQOL_ApplyCombatRez then _G.AkcQOL_ApplyCombatRez() end
                    if _G.AkcQOL_ResetCombatRezPosition then _G.AkcQOL_ResetCombatRezPosition() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                end,
            },
        },
    }

    options.args.breakTimer = {
        name = L["Break Timer"], type = "group",
        args = {
            desc = {
                name = L["A movable on-screen countdown for raid and Mythic+ breaks, so everyone can see when the break ends."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            enabled = {
                name = L["Enable Break Timer"], type = "toggle", order = 1, width = 1.4,
                get = function() return db.breakTimer.enabled end,
                set = function(_, v)
                    db.breakTimer.enabled = v
                    if addon.BreakTimer_ApplySettings then addon.BreakTimer_ApplySettings() end
                end,
            },
            locked = {
                name = L["Lock Position"],
                desc = L["Prevent the break timer from being dragged."],
                type = "toggle", order = 2, width = 1.4,
                get = function() return db.breakTimer.locked end,
                set = function(_, v)
                    db.breakTimer.locked = v
                    if addon.BreakTimer_ApplySettings then addon.BreakTimer_ApplySettings() end
                end,
            },
            sound = {
                name = L["Sound at Break End"],
                desc = L["Play a sound when the break countdown finishes."],
                type = "toggle", order = 3, width = 1.4,
                get = function() return db.breakTimer.sound end,
                set = function(_, v)
                    db.breakTimer.sound = v
                    if addon.BreakTimer_ApplySettings then addon.BreakTimer_ApplySettings() end
                end,
            },
            test = {
                name = L["Test Break Timer"],
                desc = L["Start a short test countdown so you can see and place the timer."],
                type = "execute", order = 4, width = 1.2,
                func = function()

                    if addon.StartBreakTimer then
                        addon.StartBreakTimer(30, UnitName and UnitName("player") or "player", "Test")
                    end
                end,
            },
            cancel = {
                name = L["Cancel Break Timer"],
                desc = L["Stop and hide the currently running break countdown."],
                type = "execute", order = 5, width = 1.2,
                func = function()
                    if addon.CancelBreakTimer then addon:CancelBreakTimer() end
                end,
            },
        },
    }

    options.args.profiles = {
        name = L["Profiles"], type = "group",
        args = {
            desc = {
                name = L["Settings profiles let each character keep its own AkcQOL configuration, or share one profile across characters."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            current = {
                name = function()
                    return L["Current profile:"] .. "  |cffffd100" .. addon.AkcQOL.db:GetCurrentProfile() .. "|r"
                end,
                type = "description", order = 1, fontSize = "medium",
            },
            choose = {
                name = L["Active Profile"],
                desc = L["Switch to another saved profile."],
                type = "select", order = 2, width = 1.5,
                values = function() return GetProfileValues(false) end,
                get = function() return addon.AkcQOL.db:GetCurrentProfile() end,
                set = function(_, v)
                    if v and v ~= addon.AkcQOL.db:GetCurrentProfile() then
                        addon.AkcQOL.db:SetProfile(v)
                        ApplyCurrentProfile()
                    end
                end,
            },
            newProfile = {
                name = L["New Profile"],
                desc = L["Create a new profile with default settings and switch to it."],
                type = "input", order = 3, width = 2,
                get = function() return "" end,
                set = function(_, v)
                    v = type(v) == "string" and v:trim() or ""
                    if v ~= "" then
                        addon.AkcQOL.db:SetProfile(v)
                        ApplyCurrentProfile()
                    end
                end,
            },
            copyFrom = {
                name = L["Copy From"],
                desc = L["Copy all settings from another profile into the current one."],
                type = "select", order = 4, width = 1.5,
                confirm = true,
                confirmText = L["Overwrite the current profile with the selected one?"],
                values = function() return GetProfileValues(true) end,
                disabled = function() return next(GetProfileValues(true)) == nil end,
                get = false,
                set = function(_, v)
                    if v then
                        addon.AkcQOL.db:CopyProfile(v)
                        ApplyCurrentProfile()
                    end
                end,
            },
            resetProfile = {
                name = L["Reset Profile"],
                desc = L["Reset the current profile back to default settings."],
                type = "execute", order = 7, width = 1.2,
                confirm = true,
                confirmText = L["Reset the current profile to defaults?"],
                func = function()
                    addon.AkcQOL.db:ResetProfile()
                    ApplyCurrentProfile()
                end,
            },
            deleteProfile = {
                name = L["Delete Profile"],
                desc = L["Delete the selected profile permanently. The active profile cannot be deleted."],
                type = "select", order = 6, width = 1.5,
                confirm = true,
                confirmText = L["Delete the selected profile permanently?"],
                values = function() return GetProfileValues(true) end,
                disabled = function() return next(GetProfileValues(true)) == nil end,
                get = false,
                set = function(_, v)
                    if v then
                        pcall(addon.AkcQOL.db.DeleteProfile, addon.AkcQOL.db, v)
                        LibStub("AceConfigRegistry-3.0"):NotifyChange("AkcQOLRaidCD")
                    end
                end,
            },
        },
    }

    options.args.errorLog = {
        name = L["Lua Errors"], type = "group",
        args = {
            desc = {
                name = L["AkcQOL has a built-in Lua error log (open it any time with /akcerrors). These control how it behaves."],
                type = "description", order = 0.1, fontSize = "medium",
            },
            capture = {
                name = L["Capture Lua Errors"], type = "toggle", order = 1, width = 1.4,
                desc = L["When on, AkcQOL records UI Lua errors into its own log. Takes effect immediately."],
                get = function() return not _G.AkcQOL_GetErrorSetting or _G.AkcQOL_GetErrorSetting("enabled") ~= false end,
                set = function(_, v) if _G.AkcQOL_SetErrorSetting then _G.AkcQOL_SetErrorSetting("enabled", v and true or false) end end,
            },
            sound = {
                name = L["Play a Sound on Error"], type = "toggle", order = 2, width = 1.4,
                desc = L["Plays a short warning sound whenever a new error is captured. Turn this off for silent logging."],
                get = function() return not _G.AkcQOL_GetErrorSetting or _G.AkcQOL_GetErrorSetting("soundEnabled") ~= false end,
                set = function(_, v) if _G.AkcQOL_SetErrorSetting then _G.AkcQOL_SetErrorSetting("soundEnabled", v and true or false) end end,
            },
            suppressPopups = {
                name = L["Hide Blizzard Error Popups"], type = "toggle", order = 3, width = 1.4,
                desc = L["Hides Blizzard's red Lua error popups and logs the errors here instead. Takes effect immediately."],
                get = function() return not _G.AkcQOL_GetErrorSetting or _G.AkcQOL_GetErrorSetting("suppressPopups") ~= false end,
                set = function(_, v) if _G.AkcQOL_SetErrorSetting then _G.AkcQOL_SetErrorSetting("suppressPopups", v and true or false) end end,
            },
            maxEntries = {
                name = L["Max Stored Errors"], type = "range", order = 4, width = 1.5,
                min = 25, max = 500, step = 25,
                desc = L["How many errors to keep before the oldest are dropped."],
                get = function() return (_G.AkcQOL_GetErrorSetting and _G.AkcQOL_GetErrorSetting("maxEntries")) or 200 end,
                set = function(_, v) if _G.AkcQOL_SetErrorSetting then _G.AkcQOL_SetErrorSetting("maxEntries", v) end end,
            },
            testSound = {
                name = L["Test Sound"], type = "execute", order = 5, width = 1.2,
                func = function() if _G.AkcQOL_TestLuaErrorSound then _G.AkcQOL_TestLuaErrorSound() end end,
            },
            openLog = {
                name = L["Open Error Log"], type = "execute", order = 6, width = 1.2,
                func = function() if _G.AkcQOL_ShowErrorLogWindow then _G.AkcQOL_ShowErrorLogWindow() end end,
            },
            clearLog = {
                name = L["Clear Error Log"], type = "execute", order = 7, width = 1.2,
                confirm = true, confirmText = L["Clear all stored Lua errors?"],
                func = function() if _G.AkcQOL_ClearErrorLog then _G.AkcQOL_ClearErrorLog() end end,
            },
        },
    }

    do
    local TYPE_RANK = {
        description = 1, toggle = 2, range = 3,
        select = 4, input = 5, color = 6, execute = 7,
    }

    local function OrderByType(group)
        if type(group) ~= "table" or type(group.args) ~= "table" then return end
        local list = {}
        for key, entry in pairs(group.args) do
            if type(entry) == "table" then
                if entry.type == "header" then
                    group.args[key] = nil
                else
                    list[#list + 1] = {
                        key = key,
                        entry = entry,
                        rank = TYPE_RANK[entry.type] or 8,
                        old = tonumber(entry.order) or 50,
                    }
                end
            end
        end
        table.sort(list, function(a, b)
            if a.rank ~= b.rank then return a.rank < b.rank end
            if a.old ~= b.old then return a.old < b.old end
            return a.key < b.key
        end)
        for i, item in ipairs(list) do
            if item.key == "restoreDefaults" then
                item.entry.order = 999
            else
                item.entry.order = i
            end
        end
    end

        local alertOrder = { piAlert = 1, castAlert = 2, petAlert = 3, combatRez = 4, errorLog = 5 }
        for _, k in ipairs({ "piAlert", "castAlert", "petAlert", "combatRez", "errorLog" }) do
            local g = options.args[k]
            if g then
                if not options.args.alerts then
                    options.args.alerts = { name = L["Alerts"], type = "group", args = {} }
                end
                OrderByType(g)
                g.inline = true
                g.order  = alertOrder[k]
                options.args.alerts.args[k] = g
                options.args[k] = nil
            end
        end
    end

    do
        local auto = options.args.qolAutomation
        if auto and type(auto.args) == "table" then
            local fold = {
                { key = "qolDisplay", order = 20 },
                { key = "breakTimer", order = 30 },
                { key = "qolLogging", order = 40 },
            }
            for _, e in ipairs(fold) do
                local g = options.args[e.key]
                if g then
                    g.inline = true
                    g.order  = e.order
                    auto.args[e.key] = g
                    options.args[e.key] = nil
                end
            end
        end
    end

    do
        local function TabToggle(key, label, order, desc)
            return {
                name = label,
                desc = desc,
                type = "toggle",
                order = order,
                width = 1.4,
                get = function()
                    return not (AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global[key] == true)
                end,
                set = function(_, val)
                    EnsureGlobal()
                    AkcQOLDB.global[key] = not val
                    if _G.AkcQOL_ApplyAkcHouseTabs then _G.AkcQOL_ApplyAkcHouseTabs() end
                end,
            }
        end

        options.args.auctionHouse = {
            name = L["Auction House"],
            type = "group",
            args = {
                desc = {
                    name = L["Choose which AkcHouse tabs appear at the bottom of the auction house window."],
                    type = "description", order = 0.1, fontSize = "medium",
                },
                shopping = TabToggle("akcHouseHideShopping", L["Show Shopping Tab"], 1,
                    L["The Shopping tab holds your shopping lists and bulk buying."]),
                selling = TabToggle("akcHouseHideSelling", L["Show Selling Tab"], 2,
                    L["The Selling tab holds the bag view, price list and posting tools."]),
                note = {
                    name = "\n|cFFFFD100" .. L["Close and reopen the auction house (or /reload) for a change to show up."] .. "|r",
                    type = "description", order = 10, fontSize = "medium",
                },
            },
        }
    end

    local LAYOUT = {
        auctionHouse       = { order = 65, icon = "Interface\\Icons\\INV_Misc_Coin_01" },
        overview           = { order = 10, icon = "Interface\\Icons\\INV_Misc_Book_09" },
        qolAutomation      = { order = 20, icon = "Interface\\Icons\\Trade_Engineering" },
        qolDisplay         = { order = 30, icon = "Interface\\Icons\\INV_Misc_Spyglass_03" },
        qolHud             = { order = 40, icon = "Interface\\Icons\\INV_Misc_PocketWatch_01" },
        wowLatency         = { order = 42, icon = "Interface\\Icons\\Spell_Nature_Swiftness" },
        skyriding          = { order = 45, icon = "Interface\\Icons\\Ability_Mount_Drake_Bronze" },
        recentSpells       = { order = 48, icon = "Interface\\Icons\\Spell_Nature_TimeStop" },
        actionBarMouseover = { order = 50, icon = "Interface\\Icons\\INV_Misc_Gear_08" },
        personalLocator    = { order = 60, icon = "Interface\\Icons\\INV_Misc_Map_01" },
        qolDamageMeter     = { order = 70, icon = "Interface\\Icons\\Ability_Warrior_Trauma" },
        alerts             = { order = 72, icon = "Interface\\Icons\\Spell_Holy_PowerInfusion" },
        breakTimer         = { order = 76, icon = "Interface\\Icons\\Spell_Holy_BorrowedTime" },
        readyCheck         = { order = 77, icon = "Interface\\Icons\\INV_Misc_Food_15" },
        assistant          = { order = 78, icon = "Interface\\Icons\\INV_Misc_Key_03" },
        qolLogging         = { order = 85, icon = "Interface\\Icons\\INV_Scroll_03" },
        profiles           = { order = 90, icon = "Interface\\Icons\\INV_Misc_Note_02" },
    }
    for key, cfg in pairs(LAYOUT) do
        local g = options.args[key]
        if g then
            g.order = cfg.order
            g.icon = cfg.icon
            g.iconCoords = { 0.08, 0.92, 0.08, 0.92 }
        end
    end

    return options
end

function addon:SetupConfig()
    local AceConfig = LibStub("AceConfig-3.0")
    AceConfig:RegisterOptionsTable("AkcQOLRaidCD", BuildOptions)

    local AceConfigDialog = LibStub("AceConfigDialog-3.0", true)
    if AceConfigDialog and AceConfigDialog.SetDefaultSize then
        pcall(AceConfigDialog.SetDefaultSize, AceConfigDialog, "AkcQOLRaidCD", 820, 560)
    end

    if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
        local panel = CreateFrame("Frame")
        local title = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 16, -16)
        title:SetText("AkcQOL")
        local blurb = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        blurb:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
        blurb:SetJustifyH("LEFT")
        blurb:SetText(L["AkcQOL is configured from its own settings window (/akcsettings)."])
        local open = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        open:SetSize(220, 24)
        open:SetPoint("TOPLEFT", blurb, "BOTTOMLEFT", 0, -12)
        open:SetText(L["Open AkcQOL Settings"])
        open:SetScript("OnClick", function()
            if SettingsPanel and SettingsPanel:IsShown() and HideUIPanel then
                HideUIPanel(SettingsPanel)
            end
            if _G.AkcQOL_ShowLogsWindow then
                _G.AkcQOL_ShowLogsWindow("settings")
            else
                LibStub("AceConfigDialog-3.0"):Open("AkcQOLRaidCD")
            end
        end)
        local category = Settings.RegisterCanvasLayoutCategory(panel, "AkcQOL")
        Settings.RegisterAddOnCategory(category)
    end

    ApplyCurrentProfile()
end
