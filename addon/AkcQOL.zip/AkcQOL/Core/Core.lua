local ADDON_NAME, addon = ...

local AkcQOL = LibStub("AceAddon-3.0"):NewAddon(ADDON_NAME, "AceEvent-3.0")
addon.AkcQOL = AkcQOL

local defaults = {
    profile = {
        readyCheckHelper = {
            enabled = false,
            locked = false,
            point = "CENTER",
            relPoint = "CENTER",
            xOfs = 0,
            yOfs = 150,
        },
        piAlert = {
            enabled = false,
            screen = false,
            sound = false,
            soundStyle = "raidwarning",
            soundVolume = 100,
            message = "Power Infusion on YOU!",
            chatMessage = true,
            throttle = 2,
        },
        breakTimer = {
            enabled = true,
            locked = true,
            sound = false,
            point = "TOP",
            relPoint = "TOP",
            xOfs = 0,
            yOfs = -120,
        },
        singleButtonAssistantKeybind = {
            enabled = false,
        },
        actionBarMouseover = {
            enabled = false,
            minAlpha = 0,
            maxAlpha = 1,
            hoverDelay = 0.7,
            alwaysShowInCombat = false,
            alwaysShowInEditMode = false,
            bars = {
                main = false,
                bottomLeft = false,
                bottomRight = false,
                right = false,
                left = false,
                bar5 = false,
                bar6 = false,
                bar7 = false,
                pet = false,
                stance = false,
            },
        },
        personalLocator = {
            player = {
                enabled = false,
                combatOnly = false,
                style = "crosshair",
                size = 52,
                thickness = 3,
                outline = 2,
                gap = 8,
                offsetX = 0,
                offsetY = -11,
                color = { r = 0.20, g = 1.00, b = 0.35, a = 0.95 },
            },
            cursor = {
                enabled = false,
                combatOnly = false,
                size = 52,
                thickness = 3,
                outline = 2,
                dot = false,
                pulse = false,
                color = { r = 1.00, g = 0.82, b = 0.20, a = 0.95 },
            },
        },
    },
}

function AkcQOL:OnInitialize()

    if type(EnrageRaidCDDB) == "table" and
        (type(AkcQOLRaidCDDB) ~= "table" or not AkcQOLRaidCDDB.migratedFromEnrageDB) then
        AkcQOLRaidCDDB = EnrageRaidCDDB
        AkcQOLRaidCDDB.migratedFromEnrageDB = true
    end

    self.db = LibStub("AceDB-3.0"):New("AkcQOLRaidCDDB", defaults, true)

    addon:SetupConfig()
end
