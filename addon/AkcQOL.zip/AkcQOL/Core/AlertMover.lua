-- AlertMover: shared placement for the big on-screen warning texts.
--
-- Every alert module builds its own frame lazily, the first time it has
-- something to say. This file gives each of them the same things without
-- repeating the code four times: a saved position, drag-to-move, and a
-- placement mode that shows a sample so the text can be positioned before it
-- has ever fired.
--
-- Alerts that draw the same message through two frames (a plain one and an
-- alpha-driven one for restricted content) register both under one key and
-- share a single saved position.

local L = AkcQOL_L

local registry = {}

local function Entry(key)
    local entry = registry[key]
    if not entry then
        entry = { frames = {}, moving = false }
        registry[key] = entry
    end
    return entry
end

-- Modules keep their settings in different places -- most under the global
-- table, PI Alert inside the AceDB profile -- so each may hand over its own
-- accessor and the position lands next to the rest of its options. When a
-- module's own table is not ready yet this returns nil rather than falling
-- back: writing the position somewhere the module never reads it would split
-- one setting across two tables with no error to show for it.
local function Store(key)
    local entry = registry[key]
    if entry and entry.store then
        local ok, tbl = pcall(entry.store)
        if ok and type(tbl) == "table" then return tbl end
        return nil
    end
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    if type(AkcQOLDB.global[key]) ~= "table" then AkcQOLDB.global[key] = {} end
    return AkcQOLDB.global[key]
end

local function SavedPosition(key)
    local store = Store(key)
    return store and store.textPos
end

local function ApplyPosition(frame, pos)
    if not (pos and pos.p) then return end
    frame:ClearAllPoints()
    frame:SetPoint(pos.p, UIParent, pos.rp or pos.p, pos.x or 0, pos.y or 0)
end

-- While a text is being placed, the module that owns it must not be able to
-- take it away again: the cast alert hides itself on a timer, PI and the pet
-- alert hide on their own events, and Sync() hides whenever a checkbox is
-- toggled. Hide and SetAlpha are muted for the duration and handed back
-- untouched on lock.
local function Freeze(frame)
    if frame.akcMoveFrozen then return end
    frame.akcMoveFrozen = true
    frame.Hide = function() end
    frame.SetAlpha = function() end
end

local function Thaw(frame)
    if not frame.akcMoveFrozen then return end
    frame.Hide = nil
    frame.SetAlpha = nil
    frame.akcMoveFrozen = nil
end

local function EnsureHintText(frame)
    if frame.akcMoveLabel then return frame.akcMoveLabel end
    local fs = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("TOP", frame, "BOTTOM", 0, -2)
    fs:SetText((L and L["Drag to place. Locks itself in combat."]) or "Drag to place. Locks itself in combat.")
    -- Theme font: the game's own has no Turkish s-cedilla or g-breve, so this
    -- line rendered with empty boxes inside the words.
    local Theme = _G.AkcQOL_Theme
    if Theme and Theme.SetFont then pcall(Theme.SetFont, fs, 12, "OUTLINE") end
    fs:Hide()
    frame.akcMoveLabel = fs
    return fs
end

local function Lock(key)
    local entry = registry[key]
    if not (entry and entry.moving) then return end
    entry.moving = false

    local frame = entry.primary or entry.frames[1]
    if not frame then return end

    Thaw(frame)
    frame:EnableMouse(false)
    if frame.akcMoveHint then frame.akcMoveHint:Hide() end
    if frame.akcMoveLabel then frame.akcMoveLabel:Hide() end
    -- Hidden but left opaque: the death warning calls Show() without touching
    -- alpha, so locking at zero would silence it for good.
    frame:Hide()
    frame:SetAlpha(1)
end

-- Registers one frame under `key`. Safe to call again for a second frame that
-- shows the same message; both then follow the same saved position. The frame
-- that supplies the sample text is the one the mover drives -- the twin may be
-- built first (the pet lamp is, in restricted content) and must not be picked
-- up by accident.
function _G.AkcQOL_SetupMovableAlert(key, frame, sampleFn, storeFn)
    if not (key and frame) then return frame end

    local entry = Entry(key)
    if storeFn then entry.store = storeFn end
    if sampleFn then
        entry.sample = sampleFn
        entry.primary = frame
    end

    for _, known in ipairs(entry.frames) do
        if known == frame then return frame end
    end
    entry.frames[#entry.frames + 1] = frame

    ApplyPosition(frame, SavedPosition(key))

    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:EnableMouse(false)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        local pos = { p = p, rp = rp, x = x, y = y }
        local store = Store(key)
        if store then store.textPos = pos end
        for _, other in ipairs(entry.frames) do
            if other ~= self then ApplyPosition(other, pos) end
        end
    end)
    -- Clicks pass through to the world: the warning text must never answer a
    -- click, least of all right-click, which turns the camera. Dragging runs
    -- off RegisterForDrag and is unaffected.
    if frame.SetPropagateMouseClicks then frame:SetPropagateMouseClicks(true) end
    if frame.SetPropagateMouseMotion then frame:SetPropagateMouseMotion(true) end

    local hint = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
    hint:SetAllPoints(frame)
    hint:SetColorTexture(0.55, 0.36, 1, 0.18)
    hint:Hide()
    frame.akcMoveHint = hint

    return frame
end

-- The settings button can be pressed before an alert has ever fired, so each
-- module hands over the function that builds its frame on demand.
function _G.AkcQOL_RegisterAlertBuilder(key, builder)
    if not (key and builder) then return end
    Entry(key).builder = builder
end

-- Re-reads the stored spot: needed when the table behind it changes without
-- the frame being rebuilt, as when the user switches AceDB profiles.
function _G.AkcQOL_RefreshAlertPosition(key)
    local entry = registry[key]
    if not entry then return end
    local pos = SavedPosition(key)
    if not pos then return end
    for _, frame in ipairs(entry.frames) do
        ApplyPosition(frame, pos)
    end
end

function _G.AkcQOL_ToggleAlertMover(key)
    local entry = registry[key]
    if not entry then return end
    if entry.moving then Lock(key) return end
    if entry.builder then pcall(entry.builder) end

    local frame = entry.primary or entry.frames[1]
    if not frame then return end

    -- One at a time, so two overlapping texts cannot both be draggable.
    for otherKey, other in pairs(registry) do
        if other.moving then Lock(otherKey) end
    end

    entry.moving = true

    -- Same as the bars: placement mode times out instead of relying on the
    -- user finding the settings button again.
    entry.moveToken = (entry.moveToken or 0) + 1
    if C_Timer and C_Timer.After then
        local token = entry.moveToken
        C_Timer.After(30, function()
            if entry.moving and entry.moveToken == token then Lock(key) end
        end)
    end
    if frame.text and entry.sample then
        local ok, sample = pcall(entry.sample)
        if ok and sample then frame.text:SetText(sample) end
    end
    frame:SetAlpha(1)
    frame:Show()
    frame:EnableMouse(true)
    if frame.akcMoveHint then frame.akcMoveHint:Show() end
    EnsureHintText(frame):Show()
    Freeze(frame)

    -- A twin frame is deliberately left alone. The pet lamp is never hidden by
    -- its module -- it stays shown at alpha 0 while the engine drives its alpha
    -- from the pet's health -- so touching it here would break that alert.
end

-- Called from the Restore Defaults buttons: drops the saved spot and puts the
-- frames back where their module first placed them.
function _G.AkcQOL_ResetAlertPosition(key, point, relPoint, x, y)
    Lock(key)
    local store = Store(key)
    if store then store.textPos = nil end

    local entry = registry[key]
    if not entry then return end
    for _, frame in ipairs(entry.frames) do
        frame:ClearAllPoints()
        frame:SetPoint(point or "CENTER", UIParent, relPoint or point or "CENTER", x or 0, y or 0)
    end
end

-- Placement mode must not survive into a pull: an invisible, mouse-catching
-- slab across the middle of the screen is the last thing anyone needs in
-- combat, and the options window closing is not something this file can see.
local watcher = CreateFrame("Frame")
watcher:RegisterEvent("PLAYER_REGEN_DISABLED")
watcher:SetScript("OnEvent", function()
    for key, entry in pairs(registry) do
        if entry.moving then Lock(key) end
    end
end)
