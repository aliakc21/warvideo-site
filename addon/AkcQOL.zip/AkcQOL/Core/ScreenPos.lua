-- =========================================================================
-- AkcQOL SCREEN-AWARE POSITION
-- Movable frames used to store one absolute TOP-LEFT offset from UIParent's
-- BOTTOMLEFT. Two problems came from that:
--   * UIParent's width scales with the display's aspect ratio (21:9 ~1835 units,
--     16:10 ~1229), so a spot picked on an ultrawide lands far right on a laptop.
--   * A TOP-LEFT anchor means the frame grows/shrinks downward, so changing the
--     icon size or count visibly slides the bar up or down while you tune it.
--
-- This helper stores the frame's CENTRE, once per screen:
--   * centre anchoring -> resizing keeps the bar visually where it is
--   * a centre is size-independent -> carrying it to another screen is just a
--     proportional map, no frame measurement needed
--
-- Lookup order:
--   1. an entry for THIS screen           -> use it (re-mapped if the UI scale changed)
--   2. legacy posX/posY (origin unknown)  -> converted to a centre, never rewritten
--        ^ this is what keeps the other machine's saved spot untouched until the
--          frame is dragged there, which gives that screen its own entry
--   3. an entry from another screen       -> mapped PROPORTIONALLY
--   4. nothing                            -> caller's default
--
-- Entry: cx,cy (frame centre in UIParent units) + uw,uh (canvas size at save time).
-- Old entries written as x,y(+fw,fh) top-left are read and upgraded transparently.
-- =========================================================================

AkcQOL_ScreenPos = AkcQOL_ScreenPos or {}
local SP = AkcQOL_ScreenPos

local function UIDims()
    if not UIParent then return nil end
    local w, h = UIParent:GetWidth(), UIParent:GetHeight()
    if type(w) ~= "number" or type(h) ~= "number" or w <= 0 or h <= 0 then return nil end
    return w, h
end

local function FrameScale(frame)
    local sc = frame and frame:GetScale()
    if type(sc) ~= "number" or sc <= 0 then return 1 end
    return sc
end

-- Frame size in UIParent units.
local function FrameSize(frame)
    if not frame then return 0, 0 end
    local sc = FrameScale(frame)
    local w, h = frame:GetWidth(), frame:GetHeight()
    if type(w) ~= "number" then w = 0 end
    if type(h) ~= "number" then h = 0 end
    return w * sc, h * sc
end

-- Identifies the display. Falls back to the UIParent canvas when the hardware
-- call is unavailable; either way it is stable on a given machine.
function SP.Key()
    local w, h
    if GetPhysicalScreenSize then
        local ok, pw, ph = pcall(GetPhysicalScreenSize)
        if ok and type(pw) == "number" and type(ph) == "number" and pw > 0 and ph > 0 then
            w, h = pw, ph
        end
    end
    if not w then
        w, h = UIDims()
        if not w then return nil end
    end
    return string.format("%dx%d", math.floor(w + 0.5), math.floor(h + 0.5))
end

-- Reads an entry as a centre, upgrading the old top-left format on the fly.
local function EntryCentre(e, frame)
    if type(e) ~= "table" then return nil end
    if type(e.cx) == "number" and type(e.cy) == "number" then return e.cx, e.cy end
    if type(e.x) ~= "number" or type(e.y) ~= "number" then return nil end
    local fw, fh = e.fw, e.fh
    if type(fw) ~= "number" or fw <= 0 or type(fh) ~= "number" or fh <= 0 then
        fw, fh = FrameSize(frame)
    end
    return e.x + fw / 2, e.y - fh / 2
end

-- Same relative spot on a different canvas: centred stays centred on any aspect.
local function MapCentre(cx, cy, srcW, srcH, uw, uh)
    if type(cx) ~= "number" or type(cy) ~= "number" then return nil end
    if type(srcW) ~= "number" or type(srcH) ~= "number" or srcW <= 0 or srcH <= 0 then return nil end
    local fx, fy = cx / srcW, cy / srcH
    if fx < 0 then fx = 0 elseif fx > 1 then fx = 1 end
    if fy < 0 then fy = 0 elseif fy > 1 then fy = 1 end
    return fx * uw, fy * uh
end

-- Centre for the CURRENT screen, in UIParent units. nil = use the caller's default.
function SP.Get(d, frame)
    if type(d) ~= "table" then return nil end
    local uw, uh = UIDims()
    local key = SP.Key()
    if not uw or not key then return nil end

    local screens = type(d.screens) == "table" and d.screens or nil
    local e = screens and screens[key]
    if type(e) == "table" then
        local cx, cy = EntryCentre(e, frame)
        if cx then
            -- same display, different UI scale -> re-fit proportionally
            if type(e.uw) == "number" and type(e.uh) == "number"
                and (math.abs(e.uw - uw) > 0.5 or math.abs(e.uh - uh) > 0.5) then
                local mx, my = MapCentre(cx, cy, e.uw, e.uh, uw, uh)
                if mx then return mx, my end
            end
            return cx, cy
        end
    end

    -- Legacy single position (top-left, origin screen unknown): reproduce it exactly
    -- as a centre and never rewrite it, so the other machine keeps reading its own value.
    if type(d.posX) == "number" and type(d.posY) == "number" then
        local fw, fh = FrameSize(frame)
        return d.posX + fw / 2, d.posY - fh / 2
    end

    -- Never seen this screen: carry the last known layout over, proportionally.
    if screens then
        local src = screens[d.screensLast]
        if type(src) ~= "table" then local _, v = next(screens); src = v end
        if type(src) == "table" then
            local cx, cy = EntryCentre(src, frame)
            local mx, my = MapCentre(cx, cy, src.uw, src.uh, uw, uh)
            if mx then return mx, my end
        end
    end
    return nil
end

-- Records the frame's centre against THIS screen only. Legacy posX/posY is left
-- alone on purpose so the other machine is not disturbed.
function SP.Save(d, frame)
    if type(d) ~= "table" or not frame then return end
    local uw, uh = UIDims()
    local key = SP.Key()
    local l, t = frame:GetLeft(), frame:GetTop()
    if not uw or not key or type(l) ~= "number" or type(t) ~= "number" then return end

    local sc = FrameScale(frame)
    local fw, fh = FrameSize(frame)
    if type(d.screens) ~= "table" then d.screens = {} end
    d.screens[key] = { cx = l * sc + fw / 2, cy = t * sc - fh / 2, uw = uw, uh = uh }
    d.screensLast = key
end

-- Drops only THIS screen's entry (used by "Reset Position"); other displays keep theirs.
function SP.Clear(d)
    if type(d) ~= "table" then return end
    local key = SP.Key()
    if key and type(d.screens) == "table" then d.screens[key] = nil end
    if d.screensLast == key then d.screensLast = nil end
end
