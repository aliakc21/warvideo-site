
local ADDON_NAME = ...

local migrator = CreateFrame("Frame")
migrator:RegisterEvent("ADDON_LOADED")
migrator:SetScript("OnEvent", function(self, _, loadedName)
    if loadedName ~= ADDON_NAME then return end
    self:UnregisterEvent("ADDON_LOADED")
    if type(EnrageDB) == "table" and
        (type(AkcQOLDB) ~= "table" or not AkcQOLDB.migratedFromEnrageDB) then
        AkcQOLDB = EnrageDB
        AkcQOLDB.migratedFromEnrageDB = true
    end

    local akcHouseMigrations = {
        AKCHOUSE_CONFIG = "AUCTIONATOR_CONFIG",
        AKCHOUSE_SAVEDVARS = "AUCTIONATOR_SAVEDVARS",
        AKCHOUSE_SHOPPING_LISTS = "AUCTIONATOR_SHOPPING_LISTS",
        AKCHOUSE_PRICE_DATABASE = "AUCTIONATOR_PRICE_DATABASE",
        AKCHOUSE_POSTING_HISTORY = "AUCTIONATOR_POSTING_HISTORY",
        AKCHOUSE_VENDOR_PRICE_CACHE = "AUCTIONATOR_VENDOR_PRICE_CACHE",
        AKCHOUSE_RECENT_SEARCHES = "AUCTIONATOR_RECENT_SEARCHES",
        AKCHOUSE_SELLING_GROUPS = "AUCTIONATOR_SELLING_GROUPS",
        AKCHOUSE_CHARACTER_CONFIG = "AUCTIONATOR_CHARACTER_CONFIG",
    }
    for newName, oldName in pairs(akcHouseMigrations) do
        if rawget(_G, newName) == nil and rawget(_G, oldName) ~= nil then
            _G[newName] = _G[oldName]
        end
    end
end)

_G.AkcQOLQoL_FreshInstall = (rawget(_G, "AkcQOLDB") == nil)

local L = AkcQOL_L

if type(L) ~= "table" then
    L = setmetatable({}, { __index = function(_, key) return key end })
end

local Theme = AkcQOL_Theme

local BOOT_MAX_ERRORS = 20
local BOOT_ERROR_MAX_AGE = 14 * 24 * 60 * 60
local bootButton
local bootFrame
local previousErrorHandler
local handlingError = false

local function BootSafeString(value, fallback)
    if value == nil then return fallback or "Unknown" end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return fallback or "<secret value>" end
    end
    local ok, text = pcall(tostring, value)
    if ok and text and text ~= "" then return text end
    return fallback or "<unreadable>"
end

local function EnsureBootDB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    if not AkcQOLDB.global.bootErrors then AkcQOLDB.global.bootErrors = {} end
    return AkcQOLDB.global.bootErrors
end

local function GuessAddon(message, stack)
    local text = (message or "") .. "\n" .. (stack or "")
    return text:match("Interface/AddOns/([^/\\]+)") or ADDON_NAME or "AkcQOL"
end

local function BuildBootErrorText()
    local errors = EnsureBootDB()
    if #errors == 0 then
        return L["No AkcQOL boot errors captured yet."]
    end

    local lines = {}
    for i, err in ipairs(errors) do
        lines[#lines + 1] = L["AkcQOL Boot Error"]
        lines[#lines + 1] = ""
        lines[#lines + 1] = L["ID:"] .. " " .. tostring(i)
        lines[#lines + 1] = L["Type:"] .. " " .. BootSafeString(err.kind, L["Lua Error"])
        lines[#lines + 1] = L["AddOn:"] .. " " .. BootSafeString(err.addon, L["Unknown"])
        lines[#lines + 1] = L["Time:"] .. " " .. BootSafeString(err.timeText, "-")
        lines[#lines + 1] = L["Count:"] .. " " .. tostring(err.count or 1)
        lines[#lines + 1] = ""
        lines[#lines + 1] = L["Message:"]
        lines[#lines + 1] = BootSafeString(err.message, L["Unknown error"])
        lines[#lines + 1] = ""
        lines[#lines + 1] = L["Stack:"]
        lines[#lines + 1] = BootSafeString(err.stack, L["No stack available"])
        lines[#lines + 1] = ""
        lines[#lines + 1] = string.rep("-", 56)
        lines[#lines + 1] = ""
    end
    return table.concat(lines, "\n")
end

local function ExpireOldBootErrors()
    if type(time) ~= "function" then return end
    local errors = EnsureBootDB()
    local now = time()
    for i = #errors, 1, -1 do
        local err = errors[i]
        local ts = type(err) == "table" and tonumber(err.time)
        if ts and ts > 0 and (now - ts) > BOOT_ERROR_MAX_AGE then
            table.remove(errors, i)
        end
    end
end

function AkcQOLBoot_RefreshButton()
    if not UIParent then return end
    local errors = EnsureBootDB()

    local hasUnread = false
    for _, err in ipairs(errors) do
        if type(err) == "table" and err.unread then
            hasUnread = true
            break
        end
    end
    if not hasUnread then
        if bootButton then bootButton:Hide() end
        return
    end

    if not bootButton then
        local template = BackdropTemplateMixin and "BackdropTemplate" or nil
        bootButton = CreateFrame("Button", "AkcQOLBootErrorButton", UIParent, template)
        bootButton:SetSize(74, 30)
        bootButton:SetPoint("TOP", UIParent, "TOP", 0, -90)
        bootButton:SetFrameStrata("DIALOG")
        bootButton:SetClampedToScreen(true)

        local themed = Theme and Theme.ApplyBackdrop and Theme.ApplyBackdrop(bootButton, "panel")
        if themed then
            bootButton:SetBackdropColor(0.68, 0.12, 0.10, 0.95)
            bootButton:SetBackdropBorderColor(Theme.rgba(Theme.colors.bad))
        else
            local bg = bootButton:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetTexture("Interface\\Buttons\\WHITE8X8")
            bg:SetVertexColor(0.68, 0.12, 0.10, 0.95)
            bootButton.bg = bg

            local border = bootButton:CreateTexture(nil, "BORDER")
            border:SetPoint("TOPLEFT")
            border:SetPoint("BOTTOMRIGHT")
            border:SetTexture("Interface\\Buttons\\WHITE8X8")
            border:SetVertexColor(1.0, 0.56, 0.34, 0.35)
            bootButton.border = border
        end

        local label = bootButton:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        label:SetPoint("CENTER")
        label:SetText("|cFFFFFFFF" .. L["Lua!"] .. "|r")
        bootButton.label = label

        bootButton:SetScript("OnEnter", function(self)
            if self.bg then
                self.bg:SetVertexColor(0.85, 0.18, 0.14, 1)
            elseif self.SetBackdropColor then
                self:SetBackdropColor(0.85, 0.18, 0.14, 1)
            end
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:AddLine(L["AkcQOL boot error"], 1, 0.82, 0)
            GameTooltip:AddLine(L["Click to open the emergency log."], 1, 1, 1)
            GameTooltip:Show()
        end)
        bootButton:SetScript("OnLeave", function(self)
            if self.bg then
                self.bg:SetVertexColor(0.68, 0.12, 0.10, 0.95)
            elseif self.SetBackdropColor then
                self:SetBackdropColor(0.68, 0.12, 0.10, 0.95)
            end
            GameTooltip:Hide()
        end)
        bootButton:SetScript("OnClick", function()
            if AkcQOLBoot_ShowViewer then AkcQOLBoot_ShowViewer() end
        end)
    end

    bootButton:Show()
end

function AkcQOLBoot_ShowViewer()
    if not UIParent then return end

    if not bootFrame then
        local template = BackdropTemplateMixin and "BackdropTemplate" or nil
        bootFrame = CreateFrame("Frame", "AkcQOLBootErrorFrame", UIParent, template)
        bootFrame:SetSize(760, 470)
        bootFrame:SetPoint("CENTER")
        bootFrame:SetFrameStrata("FULLSCREEN_DIALOG")
        bootFrame:SetClampedToScreen(true)
        bootFrame:EnableMouse(true)
        bootFrame:SetMovable(true)
        bootFrame:RegisterForDrag("LeftButton")
        bootFrame:SetScript("OnDragStart", bootFrame.StartMoving)
        bootFrame:SetScript("OnDragStop", bootFrame.StopMovingOrSizing)

        if bootFrame.SetBackdrop then
            local themed = Theme and Theme.ApplyWindow and Theme.ApplyWindow(bootFrame)
            if themed then

                bootFrame:SetBackdropBorderColor(Theme.rgba(Theme.colors.bad))
            else
                bootFrame:SetBackdrop({
                    bgFile = "Interface\\Buttons\\WHITE8X8",
                    edgeFile = "Interface\\Buttons\\WHITE8X8",
                    edgeSize = 1,
                })
                bootFrame:SetBackdropColor(0.02, 0.025, 0.035, 0.94)
                bootFrame:SetBackdropBorderColor(0.95, 0.25, 0.18, 0.9)
            end
        else
            local bg = bootFrame:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetTexture("Interface\\Buttons\\WHITE8X8")
            bg:SetVertexColor(0.02, 0.025, 0.035, 0.94)
        end

        local title = bootFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        if Theme and Theme.Accent then
            title:SetText(Theme.Accent("AkcQOL") .. " " .. L["Emergency Lua Log"])
            Theme.StyleTitle(title)
        else
            title:SetText("|cFFFFB347AkcQOL|r " .. L["Emergency Lua Log"])
        end
        if Theme and Theme.SetFont then
            local _, titleSize = title:GetFont()
            Theme.SetFont(title, titleSize or 16, "", true)
        end

        local buttonTemplate = BackdropTemplateMixin and "BackdropTemplate" or nil

        local close = CreateFrame("Button", nil, bootFrame, buttonTemplate)
        close:SetSize(32, 28)
        close:SetPoint("TOPRIGHT", -10, -10)
        if Theme and Theme.SkinButton then Theme.SkinButton(close) end
        close.text = close:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        close.text:SetPoint("CENTER")
        close.text:SetText("|cFFFF5A4EX|r")
        if Theme and Theme.SetFont then
            local _, closeSize = close.text:GetFont()
            Theme.SetFont(close.text, closeSize or 16, "")
        end
        close:SetScript("OnClick", function() bootFrame:Hide() end)

        local clear = CreateFrame("Button", nil, bootFrame, buttonTemplate)
        clear:SetSize(110, 28)
        clear:SetPoint("BOTTOMLEFT", 18, 14)
        local clearSkinned = Theme and Theme.SkinButton and Theme.SkinButton(clear)
        if not clearSkinned then
            clear.bg = clear:CreateTexture(nil, "BACKGROUND")
            clear.bg:SetAllPoints()
            clear.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
            clear.bg:SetVertexColor(0.48, 0.12, 0.10, 0.95)
        end
        clear.text = clear:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        clear.text:SetPoint("CENTER")
        clear.text:SetText(L["Clear"])
        if Theme and Theme.SetFont then
            local _, clearSize = clear.text:GetFont()
            Theme.SetFont(clear.text, clearSize or 12, "")
        end
        if clearSkinned then

            clear.text:SetTextColor(Theme.rgba(Theme.colors.bad))
        end

        local scroll = CreateFrame("ScrollFrame", nil, bootFrame, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 18, -52)
        scroll:SetPoint("BOTTOMRIGHT", -40, 54)
        bootFrame.scroll = scroll

        if Theme and Theme.ApplyBackdrop and BackdropTemplateMixin then
            local scrollInset = CreateFrame("Frame", nil, bootFrame, "BackdropTemplate")
            scrollInset:SetPoint("TOPLEFT", scroll, "TOPLEFT", 0, 0)
            scrollInset:SetPoint("BOTTOMRIGHT", scroll, "BOTTOMRIGHT", 22, 0)
            scrollInset:SetFrameLevel(math.max(0, scroll:GetFrameLevel() - 1))
            Theme.ApplyBackdrop(scrollInset, "inset")
        else
            local scrollBg = bootFrame:CreateTexture(nil, "BACKGROUND")
            scrollBg:SetPoint("TOPLEFT", scroll, "TOPLEFT", 0, 0)
            scrollBg:SetPoint("BOTTOMRIGHT", scroll, "BOTTOMRIGHT", 22, 0)
            scrollBg:SetTexture("Interface\\Buttons\\WHITE8X8")
            scrollBg:SetVertexColor(0, 0, 0, 0.45)
        end

        local edit = CreateFrame("EditBox", nil, scroll)
        edit:SetMultiLine(true)
        edit:SetAutoFocus(false)
        edit:SetFontObject(ChatFontNormal)
        if Theme and Theme.SetFont then
            local _, editSize = edit:GetFont()
            Theme.SetFont(edit, editSize or 13, "")
        end

        edit:SetWidth(690)
        edit:SetTextInsets(10, 10, 10, 10)
        edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        scroll:SetScrollChild(edit)
        bootFrame.edit = edit

        local function ResetClearConfirm()
            clear.confirmArmed = false
            clear.text:SetText(L["Clear"])
        end
        clear:SetScript("OnClick", function()
            if not clear.confirmArmed then
                clear.confirmArmed = true
                clear.text:SetText(L["Really clear?"])
                if C_Timer and type(C_Timer.After) == "function" then
                    C_Timer.After(4, function()
                        if clear.confirmArmed then ResetClearConfirm() end
                    end)
                end
                return
            end
            ResetClearConfirm()
            AkcQOLDB.global.bootErrors = {}
            edit:SetText(BuildBootErrorText())
            scroll:SetVerticalScroll(0)
            AkcQOLBoot_RefreshButton()
        end)

        local hint = bootFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hint:SetPoint("BOTTOMRIGHT", -18, 22)
        hint:SetText("|cFFBFC7D5" .. L["Click inside the box, Cmd/Ctrl+A, Cmd/Ctrl+C to copy."] .. "|r")
        if Theme and Theme.SetFont then
            local _, hintSize = hint:GetFont()
            Theme.SetFont(hint, hintSize or 10, "")
        end
    end

    for _, err in ipairs(EnsureBootDB()) do
        err.unread = false
    end
    bootFrame.edit:SetText(BuildBootErrorText())
    bootFrame.edit:HighlightText(0, 0)
    bootFrame.scroll:SetVerticalScroll(0)
    bootFrame:Show()

    AkcQOLBoot_RefreshButton()
end

function AkcQOLBoot_RecordError(kind, message, stack, addon)
    local errors = EnsureBootDB()
    kind = BootSafeString(kind, "Lua Error")
    message = BootSafeString(message, "Unknown error")
    stack = BootSafeString(stack, "No stack available")
    addon = BootSafeString(addon, ADDON_NAME or "AkcQOL")

    for i, err in ipairs(errors) do
        if type(err) == "table" and err.kind == kind and err.message == message and err.addon == addon then
            err.count = (err.count or 1) + 1
            err.stack = stack
            err.time = time and time() or err.time or 0
            err.timeText = date and date("%Y-%m-%d %H:%M:%S") or err.timeText or "-"
            err.unread = true
            if i > 1 then
                table.remove(errors, i)
                table.insert(errors, 1, err)
            end
            AkcQOLBoot_RefreshButton()
            return
        end
    end

    table.insert(errors, 1, {
        kind = kind,
        message = message,
        stack = stack,
        addon = addon,
        count = 1,
        time = time and time() or 0,
        timeText = date and date("%Y-%m-%d %H:%M:%S") or "-",
        unread = true,
    })
    while #errors > BOOT_MAX_ERRORS do table.remove(errors) end
    AkcQOLBoot_RefreshButton()
end

function AkcQOLBoot_CleanupRemovedModules()
    if not AkcQOLDB or not AkcQOLDB.global then return end

    AkcQOLDB.global.ah = nil

    local luaErrors = AkcQOLDB.global.luaErrors
    local entries = luaErrors and luaErrors.entries
    if type(entries) == "table" then
        local kept = {}
        local unreadCount = 0

        local removedAddonMarker = "AkcQOL" .. string.char(65, 72)
        local legacyRemovedAddonMarker = "Enrage" .. string.char(65, 72)
        for i = 1, #entries do
            local err = entries[i]
            local message = type(err) == "table" and BootSafeString(err.message, "") or ""
            local stack = type(err) == "table" and BootSafeString(err.stack, "") or ""
            if not message:find(removedAddonMarker, 1, true) and not stack:find(removedAddonMarker, 1, true)
                and not message:find(legacyRemovedAddonMarker, 1, true) and not stack:find(legacyRemovedAddonMarker, 1, true) then
                kept[#kept + 1] = err
                if type(err) == "table" and err.unread then
                    unreadCount = unreadCount + 1
                end
            end
        end
        luaErrors.entries = kept
        luaErrors.unreadCount = unreadCount
    end
end

local function BootErrorHandler(err)
    if handlingError then
        if previousErrorHandler then pcall(previousErrorHandler, err) end
        return
    end

    handlingError = true
    local message = BootSafeString(err, "Unknown Lua error")
    local stack = "No stack available"
    if type(debugstack) == "function" then
        local okStack, stackText = pcall(debugstack, 2)
        if okStack then stack = BootSafeString(stackText, stack) end
    end
    AkcQOLBoot_RecordError("Lua Error", message, stack, GuessAddon(message, stack))
    handlingError = false

    if previousErrorHandler and previousErrorHandler ~= BootErrorHandler then
        pcall(previousErrorHandler, err)
    end
end

ExpireOldBootErrors()

if type(geterrorhandler) == "function" then
    pcall(function() previousErrorHandler = geterrorhandler() end)
end
if type(seterrorhandler) == "function" then
    pcall(seterrorhandler, BootErrorHandler)
end

function AkcQOLBoot_Retire()
    if type(geterrorhandler) ~= "function" or type(seterrorhandler) ~= "function" then return end
    if not previousErrorHandler then return end
    local ok, current = pcall(geterrorhandler)
    if ok and current == BootErrorHandler then
        pcall(seterrorhandler, previousErrorHandler)
    end
end

local ready = CreateFrame("Frame")
ready:RegisterEvent("PLAYER_LOGIN")
ready:SetScript("OnEvent", function()
    AkcQOLBoot_CleanupRemovedModules()
    AkcQOLBoot_RefreshButton()
end)

SLASH_AKCQOLBOOT1 = "/akcboot"
SLASH_AKCQOLBOOT2 = "/akcqolboot"
SlashCmdList["AKCQOLBOOT"] = function()
    AkcQOLBoot_ShowViewer()
end
