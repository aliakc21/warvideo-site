local ADDON_NAME, addon = ...

-- Locale registry. Language packs live in Core/Locales/<code>.lua and call
-- AkcQOL_RegisterLocale(code, table). English is the source language: the keys
-- ARE the English strings, so enUS needs no table and any missing translation
-- falls back to the key itself.
local locales = {}
local active = nil
local activeCode = nil

local L = setmetatable({}, { __index = function(_, key)
    local t = active
    if t then
        local v = t[key]
        if v ~= nil then return v end
    end
    return key
end })
_G.AkcQOL_L = L

-- Endonyms for the language dropdown. Only registered packs (plus Automatic
-- and English) are actually offered.
local NATIVE_NAMES = {
    enUS = "English",
    trTR = "Türkçe",
    deDE = "Deutsch",
    frFR = "Français",
    esES = "Español (EU)",
    esMX = "Español (AL)",
    itIT = "Italiano",
    ptBR = "Português",
    ruRU = "Русский",
    koKR = "한국어",
    zhCN = "简体中文",
    zhTW = "繁體中文",
}

-- The same languages in Latin letters, for a client that has no font for
-- their own script (an English client usually lacks Hangul and Han).
local LATIN_NAMES = {
    koKR = "Korean",
    zhCN = "Chinese (Simplified)",
    zhTW = "Chinese (Traditional)",
}

-- string.upper only knows A-Z. Alert texts are shown in capitals, and in any
-- other script they came out half done ("PET CANı AZ", Russian left in lower
-- case). The two-byte letters of Latin-1, Turkish and Cyrillic are raised
-- here too, and with the Turkish interface a dotted i becomes İ, as Turkish
-- writes it. Text holding |c / |T escapes only gets A-Z raised, as before.
-- A-Z is mapped by hand rather than with string.upper, which follows the C
-- locale and can rewrite the bytes inside multi-byte letters.
local function UpperAscii(text)
    return (text:gsub("[a-z]", function(c) return string.char(c:byte() - 32) end))
end

local UPPER = {}
do
    local pairsList = {
        "à", "À", "á", "Á", "â", "Â", "ã", "Ã", "ä", "Ä", "å", "Å", "æ", "Æ", "ç", "Ç",
        "è", "È", "é", "É", "ê", "Ê", "ë", "Ë", "ì", "Ì", "í", "Í", "î", "Î", "ï", "Ï",
        "ñ", "Ñ", "ò", "Ò", "ó", "Ó", "ô", "Ô", "õ", "Õ", "ö", "Ö", "ø", "Ø",
        "ù", "Ù", "ú", "Ú", "û", "Û", "ü", "Ü", "ý", "Ý", "ş", "Ş", "ğ", "Ğ", "ı", "I", "œ", "Œ",
    }
    for i = 1, #pairsList, 2 do UPPER[pairsList[i]] = pairsList[i + 1] end
    -- Cyrillic: а..п (D0 B0..BF) -> А..П (D0 90..9F), р..я (D1 80..8F) -> Р..Я (D0 A0..AF), ё -> Ё
    for b = 0xB0, 0xBF do UPPER[string.char(0xD0, b)] = string.char(0xD0, b - 0x20) end
    for b = 0x80, 0x8F do UPPER[string.char(0xD1, b)] = string.char(0xD0, b + 0x20) end
    UPPER["\209\145"] = "\208\129"
end

function _G.AkcQOL_Upper(text)
    if type(text) ~= "string" then return text end
    if text:find("|", 1, true) then return UpperAscii(text) end
    if activeCode == "trTR" then text = text:gsub("i", "\196\176") end
    text = UpperAscii(text)
    return (text:gsub("[\192-\223][\128-\191]", function(c) return UPPER[c] or c end))
end

-- The game's own font (UIErrorsFrame, StaticPopup) has no Turkish İ; a plain
-- I reads the same there instead of an empty box.
function _G.AkcQOL_ForGameFont(text)
    if type(text) ~= "string" then return text end
    return (text:gsub("\196\176", "I"))
end

function _G.AkcQOL_GetLanguageLatinName(code)
    return LATIN_NAMES[code] or NATIVE_NAMES[code] or code
end

local Resolve

-- Tables built at file load capture English strings (the saved language
-- preference is unreadable that early). Files register a rebuilder here so a
-- late resolve can reconstruct them in the right language.
local rebuilders = {}
function _G.AkcQOL_RegisterLocaleRebuild(fn)
    if type(fn) == "function" then rebuilders[#rebuilders + 1] = fn end
end
local function RunRebuilders()
    for _, fn in ipairs(rebuilders) do pcall(fn) end
end

function _G.AkcQOL_RegisterLocale(code, tbl)
    if type(code) == "string" and type(tbl) == "table" then
        locales[code] = tbl
        -- Re-resolve right away so files loading after this pack already see
        -- the translated strings at file scope (auto/client-locale mode).
        if Resolve then Resolve() end
    end
end

function _G.AkcQOL_GetLanguageChoices()
    local out = {
        auto = L["Automatic (game language)"],
        enUS = "English",
    }
    for code, tbl in pairs(locales) do
        if next(tbl) ~= nil then
            out[code] = NATIVE_NAMES[code] or code
        end
    end
    return out
end

-- The saved preference lives in AkcQOLDB.global.language ("auto" or a locale
-- code). SavedVariables are not loaded yet while this file runs, so we resolve
-- once now (client locale) and again at ADDON_LOADED (user preference).
Resolve = function()
    local pref = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.language
    local code = (type(pref) == "string" and pref ~= "auto") and pref or GetLocale()
    if code == "enGB" then code = "enUS" end
    active = locales[code]
    activeCode = code
end

-- The language the addon actually draws in: the saved preference, or the
-- game's locale in automatic mode. The theme needs it to pick a font that has
-- that language's letters.
function _G.AkcQOL_GetActiveLanguageCode()
    return activeCode or GetLocale()
end

_G.AkcQOL_ApplyLanguage = function()
    Resolve()
    RunRebuilders()
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, _, name)
    if name == ADDON_NAME then
        Resolve()
        RunRebuilders()
        self:UnregisterAllEvents()
    end
end)
Resolve()
