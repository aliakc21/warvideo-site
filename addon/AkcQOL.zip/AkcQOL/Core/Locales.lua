local ADDON_NAME, addon = ...

local L = setmetatable({}, { __index = function(_, key) return key end })
addon.L = L
_G.AkcQOL_L = L
