local ADDON_NAME, addon = ...

-- Locale registry. Language packs live in Core/Locales/<code>.lua and call
-- AkcQOL_RegisterLocale(code, table). English is the source language: the keys
-- ARE the English strings, so enUS needs no table and any missing translation
-- falls back to the key itself.
local locales = {}
local active = nil

local L = setmetatable({}, { __index = function(_, key)
    local t = active
    if t then
        local v = t[key]
        if v ~= nil then return v end
    end
    return key
end })
_G.AkcQOL_L = L

-- Endonyms for the language dropdown. Only registered packs (plus Automatic
-- and English) are actually offered.
local NATIVE_NAMES = {
    enUS = "English",
    trTR = "Türkçe",
    deDE = "Deutsch",
    frFR = "Français",
    esES = "Español (EU)",
    esMX = "Español (AL)",
    itIT = "Italiano",
    ptBR = "Português",
    ruRU = "Русский",
    koKR = "한국어",
    zhCN = "简体中文",
    zhTW = "繁體中文",
}

local Resolve

-- Tables built at file load capture English strings (the saved language
-- preference is unreadable that early). Files register a rebuilder here so a
-- late resolve can reconstruct them in the right language.
local rebuilders = {}
function _G.AkcQOL_RegisterLocaleRebuild(fn)
    if type(fn) == "function" then rebuilders[#rebuilders + 1] = fn end
end
local function RunRebuilders()
    for _, fn in ipairs(rebuilders) do pcall(fn) end
end

function _G.AkcQOL_RegisterLocale(code, tbl)
    if type(code) == "string" and type(tbl) == "table" then
        locales[code] = tbl
        -- Re-resolve right away so files loading after this pack already see
        -- the translated strings at file scope (auto/client-locale mode).
        if Resolve then Resolve() end
    end
end

function _G.AkcQOL_GetLanguageChoices()
    local out = {
        auto = L["Automatic (game language)"],
        enUS = "English",
    }
    for code, tbl in pairs(locales) do
        if next(tbl) ~= nil then
            out[code] = NATIVE_NAMES[code] or code
        end
    end
    return out
end

-- The saved preference lives in AkcQOLDB.global.language ("auto" or a locale
-- code). SavedVariables are not loaded yet while this file runs, so we resolve
-- once now (client locale) and again at ADDON_LOADED (user preference).
Resolve = function()
    local pref = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.language
    local code = (type(pref) == "string" and pref ~= "auto") and pref or GetLocale()
    if code == "enGB" then code = "enUS" end
    active = locales[code]
end

_G.AkcQOL_ApplyLanguage = function()
    Resolve()
    RunRebuilders()
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, _, name)
    if name == ADDON_NAME then
        Resolve()
        RunRebuilders()
        self:UnregisterAllEvents()
    end
end)
Resolve()
