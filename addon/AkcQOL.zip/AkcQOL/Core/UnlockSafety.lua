-- UnlockSafety: a way out of every "unlocked for dragging" frame.
--
-- Several movable frames sit in the middle of the screen and take the mouse
-- while unlocked. Right-click-drag turns the camera in this game, so a
-- mouse-enabled frame there is a dead zone: the camera will not turn, and
-- clicks on the world or on a window behind it go nowhere. Worse, most of
-- those unlock flags are saved variables, so the dead zone comes back after a
-- reload and the only way out is finding the same checkbox in the settings.
--
-- Every unlockable frame registers here and gets the same two exits:
--   right-click on the frame  -> lock it
--   entering combat           -> lock it
-- Both go through the module's own lock function, so the saved flag, the
-- checkbox and the frame stay in agreement.

local registry = {}

local function LockOne(entry)
    if not entry or not entry.lock then return end
    pcall(entry.lock)
end

-- `lockFn` must persist the module's own "locked" state and re-apply it, the
-- same way the settings checkbox does.
function _G.AkcQOL_RegisterUnlockable(key, frame, lockFn)
    if not (key and frame and lockFn) then return end

    local entry = registry[key]
    if not entry then
        entry = {}
        registry[key] = entry
    end
    entry.frame = frame
    entry.lock = lockFn

    if not frame.akcUnlockHooked then
        frame.akcUnlockHooked = true
        -- HookScript, not SetScript: these frames already carry drag handlers
        -- and click handlers of their own.
        frame:HookScript("OnMouseUp", function(_, button)
            if button == "RightButton" then LockOne(entry) end
        end)
    end
end

function _G.AkcQOL_LockAllUnlockables()
    for _, entry in pairs(registry) do
        LockOne(entry)
    end
end

local watcher = CreateFrame("Frame")
watcher:RegisterEvent("PLAYER_REGEN_DISABLED")
watcher:SetScript("OnEvent", _G.AkcQOL_LockAllUnlockables)
