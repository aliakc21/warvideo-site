local _, addon = ...

local WHITE = "Interface\\Buttons\\WHITE8x8"

local Theme = {
    accentHex = "8c5cff",
    colors = {
        accent      = { 0.549, 0.361, 1.000, 1.00 },
            windowBg    = { 0.055, 0.055, 0.075, 0.96 },
        panelBg     = { 0.085, 0.085, 0.110, 0.92 },
        insetBg     = { 0.030, 0.030, 0.045, 0.90 },
        rowBg       = { 1.000, 1.000, 1.000, 0.04 },
        rowHover    = { 0.549, 0.361, 1.000, 0.12 },
        border      = { 0.160, 0.150, 0.220, 1.00 },
        borderLight = { 0.360, 0.300, 0.560, 1.00 },
        header      = { 0.100, 0.090, 0.150, 1.00 },
        text        = { 0.920, 0.920, 0.950, 1.00 },
        textMuted   = { 0.620, 0.620, 0.700, 1.00 },
        good        = { 0.350, 0.850, 0.450, 1.00 },
        bad         = { 0.950, 0.380, 0.320, 1.00 },
        warn        = { 1.000, 0.800, 0.250, 1.00 },
    },
}

Theme.fontPath = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\PTSansNarrow-Regular.ttf"
Theme.fontBoldPath = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\PTSansNarrow-Bold.ttf"
Theme.iconPath = "Interface\\AddOns\\AkcQOL\\Media\\Icon"

_G.AkcQOL_Theme = Theme

local BACKDROP_1PX = { bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 }
local BACKDROP_BG_ONLY = { bgFile = WHITE }

local function rgba(c) return c[1], c[2], c[3], c[4] end
Theme.rgba = rgba

function Theme.Accent(text)
    return "|cff" .. Theme.accentHex .. tostring(text) .. "|r"
end

function Theme.ApplyBackdrop(frame, kind, opts)
    if not frame or not frame.SetBackdrop then return false end
    opts = opts or {}
    local ok = pcall(frame.SetBackdrop, frame, opts.borderless and BACKDROP_BG_ONLY or BACKDROP_1PX)
    if not ok then return false end
    local c = Theme.colors
    local bg = (kind == "panel" and c.panelBg) or (kind == "inset" and c.insetBg) or c.windowBg
    frame:SetBackdropColor(rgba(bg))
    if not opts.borderless then
        frame:SetBackdropBorderColor(rgba(opts.accentBorder and c.borderLight or c.border))
    end
    return true
end

function Theme.AddAccentLine(frame)
    if not frame or frame.__akcAccentLine or not frame.CreateTexture then return end
    local line = frame:CreateTexture(nil, "BORDER")
    line:SetTexture(WHITE)
    line:SetVertexColor(rgba(Theme.colors.accent))
    line:SetPoint("TOPLEFT", 1, -1)
    line:SetPoint("TOPRIGHT", -1, -1)
    line:SetHeight(2)
    frame.__akcAccentLine = line
    return line
end

function Theme.ApplyWindow(frame, opts)
    if not Theme.ApplyBackdrop(frame, "window") then return false end
    if not opts or opts.accentLine ~= false then
        Theme.AddAccentLine(frame)
    end
    return true
end

function Theme.StyleTitle(fontString, accent)
    if not fontString or not fontString.SetTextColor then return end
    local c = accent and Theme.colors.accent or Theme.colors.text
    fontString:SetTextColor(rgba(c))
end

Theme.fontRegistry = setmetatable({}, { __mode = "k" })

local MIN_TEXT_SCALE, MAX_TEXT_SCALE = 1.0, 1.6

function Theme.GetTextScale()
    local db = _G.AkcQOLDB
    local v = db and db.global and tonumber(db.global.textScale) or 1.0
    if v < MIN_TEXT_SCALE then v = MIN_TEXT_SCALE end
    if v > MAX_TEXT_SCALE then v = MAX_TEXT_SCALE end
    return v
end

function Theme.SetFont(fontString, size, flags, bold)
    if not fontString or not fontString.SetFont then return false end
    local path = bold and Theme.fontBoldPath or Theme.fontPath
    size = size or 12
    Theme.fontRegistry[fontString] = { size = size, flags = flags or "", bold = bold and true or false }
    local scaled = math.max(1, math.floor(size * Theme.GetTextScale() + 0.5))
    local ok = fontString:SetFont(path, scaled, flags or "")
    if not ok then return false end
    if fontString.SetShadowColor then

        if scaled >= 13 then
            fontString:SetShadowColor(0, 0, 0, 0.5)
            fontString:SetShadowOffset(1, -1)
        else
            fontString:SetShadowColor(0, 0, 0, 0)
        end
    end
    return true
end

function Theme.SetTextScale(mult)
    mult = tonumber(mult) or 1.0
    if mult < MIN_TEXT_SCALE then mult = MIN_TEXT_SCALE end
    if mult > MAX_TEXT_SCALE then mult = MAX_TEXT_SCALE end
    if _G.AkcQOLDB and _G.AkcQOLDB.global then
        _G.AkcQOLDB.global.textScale = mult
    end
    for fs, spec in pairs(Theme.fontRegistry) do
        if fs.SetFont then
            Theme.SetFont(fs, spec.size, spec.flags, spec.bold)
        end
    end
    return mult
end

do
    local reapply = CreateFrame("Frame")
    reapply:RegisterEvent("PLAYER_LOGIN")
    reapply:SetScript("OnEvent", function(self)
        self:UnregisterEvent("PLAYER_LOGIN")
        if Theme.GetTextScale() > 1.0 then
            Theme.SetTextScale(Theme.GetTextScale())
        end
    end)
end

function Theme.SkinButton(btn)
    if not btn or btn.__akcSkinned or not btn.SetBackdrop then return false end
    if not Theme.ApplyBackdrop(btn, "panel") then return false end
    btn.__akcSkinned = true
    btn:HookScript("OnEnter", function(self)
        if self.SetBackdropBorderColor then
            self:SetBackdropBorderColor(rgba(Theme.colors.borderLight))
            self:SetBackdropColor(rgba(Theme.colors.rowHover))
        end
    end)
    btn:HookScript("OnLeave", function(self)
        if self.SetBackdropBorderColor then
            self:SetBackdropBorderColor(rgba(Theme.colors.border))
            self:SetBackdropColor(rgba(Theme.colors.panelBg))
        end
    end)
    return true
end

-- GameTooltip is shared with the whole UI and its fonts have no Turkish glyphs,
-- so our own tooltips showed boxes. Whenever GameTooltip is shown for one of
-- OUR frames (name prefixed AkcQOL/Enrage/WVTracker, or flagged akcqolTooltip),
-- restyle its lines with the theme font; Blizzard's fonts are restored the
-- moment the tooltip hides, so nothing outside the addon is affected.
do
    local patched = {}

    local function RestoreTooltipFonts()
        for fs, orig in pairs(patched) do
            pcall(fs.SetFont, fs, orig[1], orig[2], orig[3])
            patched[fs] = nil
        end
    end

    local function IsOurs(frame)
        local f = frame
        for _ = 1, 20 do
            if not f then return false end
            if f.akcqolTooltip then return true end
            local n = f.GetName and f:GetName()
            if type(n) == "string" and (n:find("^AkcQOL") or n:find("^Enrage") or n:find("^WVTracker")) then
                return true
            end
            f = f.GetParent and f:GetParent() or nil
        end
        return false
    end

    function Theme.StyleTooltip(tooltip)
        tooltip = tooltip or GameTooltip
        if not tooltip or not tooltip.NumLines then return end
        local name = tooltip:GetName()
        if not name then return end
        for i = 1, tooltip:NumLines() do
            for _, side in ipairs({ "TextLeft", "TextRight" }) do
                local fs = _G[name .. side .. i]
                if fs and fs.GetFont and fs:IsShown() then
                    local file, size, flags = fs:GetFont()
                    if file and size and file ~= Theme.fontPath then
                        if not patched[fs] then patched[fs] = { file, size, flags } end
                        pcall(fs.SetFont, fs, Theme.fontPath, size, flags)
                        if not fs:GetFont() then
                            pcall(fs.SetFont, fs, file, size, flags)
                            patched[fs] = nil
                        end
                    end
                end
            end
        end
    end

    local function RestyleIfOurs(tooltip)
        local owner = tooltip.GetOwner and tooltip:GetOwner()
        if owner and IsOurs(owner) then Theme.StyleTooltip(tooltip) end
    end

    -- Three separate tooltip frames are in play. Ace3 does NOT put option text
    -- on GameTooltip: AceConfigDialog and AceGUI each create their own
    -- GameTooltipTemplate frame, so hooking GameTooltip alone left every
    -- settings-panel description in the game's font -- the one missing the
    -- Turkish letters, which is where the empty boxes came from.
    local function InstallTooltipHooks(tooltip)
        if not (tooltip and tooltip.HookScript) or tooltip.akcqolFontHooked then return end
        tooltip.akcqolFontHooked = true
        tooltip:HookScript("OnShow", RestyleIfOurs)
        -- OnShow fires only on hidden -> shown; moving the mouse from one
        -- option to the next rewrites an already-visible tooltip, so the
        -- restyle also has to run on Show.
        if hooksecurefunc then
            hooksecurefunc(tooltip, "Show", RestyleIfOurs)
        end
        tooltip:HookScript("OnHide", RestoreTooltipFonts)
    end

    InstallTooltipHooks(GameTooltip)
    InstallTooltipHooks(_G.AceConfigDialogTooltip)
    InstallTooltipHooks(_G.AceGUITooltip)

    -- Those two belong to libraries; if a load order ever puts them after this
    -- file, catch them once everything is up.
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            InstallTooltipHooks(_G.AceConfigDialogTooltip)
            InstallTooltipHooks(_G.AceGUITooltip)
        end)
    end
end
