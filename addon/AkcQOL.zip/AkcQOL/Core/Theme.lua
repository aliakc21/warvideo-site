local ADDON_NAME, addon = ...

local WHITE = "Interface\\Buttons\\WHITE8x8"

local Theme = {
    accentHex = "8c5cff",
    colors = {
        accent      = { 0.549, 0.361, 1.000, 1.00 },
        accentDim   = { 0.549, 0.361, 1.000, 0.45 },
        windowBg    = { 0.055, 0.055, 0.075, 0.96 },
        panelBg     = { 0.085, 0.085, 0.110, 0.92 },
        insetBg     = { 0.030, 0.030, 0.045, 0.90 },
        rowBg       = { 1.000, 1.000, 1.000, 0.04 },
        rowHover    = { 0.549, 0.361, 1.000, 0.12 },
        border      = { 0.160, 0.150, 0.220, 1.00 },
        borderLight = { 0.360, 0.300, 0.560, 1.00 },
        header      = { 0.100, 0.090, 0.150, 1.00 },
        text        = { 0.920, 0.920, 0.950, 1.00 },
        textMuted   = { 0.620, 0.620, 0.700, 1.00 },
        good        = { 0.350, 0.850, 0.450, 1.00 },
        bad         = { 0.950, 0.380, 0.320, 1.00 },
        warn        = { 1.000, 0.800, 0.250, 1.00 },
    },
}

Theme.fontPath = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\PTSansNarrow-Regular.ttf"
Theme.fontBoldPath = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\PTSansNarrow-Bold.ttf"
Theme.iconPath = "Interface\\AddOns\\AkcQOL\\Media\\Icon"

addon.Theme = Theme
_G.AkcQOL_Theme = Theme

local BACKDROP_1PX = { bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 }
local BACKDROP_BG_ONLY = { bgFile = WHITE }

local function rgba(c) return c[1], c[2], c[3], c[4] end
Theme.rgba = rgba

function Theme.Accent(text)
    return "|cff" .. Theme.accentHex .. tostring(text) .. "|r"
end

function Theme.ApplyBackdrop(frame, kind, opts)
    if not frame or not frame.SetBackdrop then return false end
    opts = opts or {}
    local ok = pcall(frame.SetBackdrop, frame, opts.borderless and BACKDROP_BG_ONLY or BACKDROP_1PX)
    if not ok then return false end
    local c = Theme.colors
    local bg = (kind == "panel" and c.panelBg) or (kind == "inset" and c.insetBg) or c.windowBg
    frame:SetBackdropColor(rgba(bg))
    if not opts.borderless then
        frame:SetBackdropBorderColor(rgba(opts.accentBorder and c.borderLight or c.border))
    end
    return true
end

function Theme.AddAccentLine(frame)
    if not frame or frame.__akcAccentLine or not frame.CreateTexture then return end
    local line = frame:CreateTexture(nil, "BORDER")
    line:SetTexture(WHITE)
    line:SetVertexColor(rgba(Theme.colors.accent))
    line:SetPoint("TOPLEFT", 1, -1)
    line:SetPoint("TOPRIGHT", -1, -1)
    line:SetHeight(2)
    frame.__akcAccentLine = line
    return line
end

function Theme.ApplyWindow(frame, opts)
    if not Theme.ApplyBackdrop(frame, "window") then return false end
    if not opts or opts.accentLine ~= false then
        Theme.AddAccentLine(frame)
    end
    return true
end

function Theme.StyleTitle(fontString, accent)
    if not fontString or not fontString.SetTextColor then return end
    local c = accent and Theme.colors.accent or Theme.colors.text
    fontString:SetTextColor(rgba(c))
end

Theme.fontRegistry = setmetatable({}, { __mode = "k" })

local MIN_TEXT_SCALE, MAX_TEXT_SCALE = 1.0, 1.6

function Theme.GetTextScale()
    local db = _G.AkcQOLDB
    local v = db and db.global and tonumber(db.global.textScale) or 1.0
    if v < MIN_TEXT_SCALE then v = MIN_TEXT_SCALE end
    if v > MAX_TEXT_SCALE then v = MAX_TEXT_SCALE end
    return v
end

function Theme.SetFont(fontString, size, flags, bold)
    if not fontString or not fontString.SetFont then return false end
    local path = bold and Theme.fontBoldPath or Theme.fontPath
    size = size or 12
    Theme.fontRegistry[fontString] = { size = size, flags = flags or "", bold = bold and true or false }
    local scaled = math.max(1, math.floor(size * Theme.GetTextScale() + 0.5))
    local ok = fontString:SetFont(path, scaled, flags or "")
    if not ok then return false end
    if fontString.SetShadowColor then

        if scaled >= 13 then
            fontString:SetShadowColor(0, 0, 0, 0.5)
            fontString:SetShadowOffset(1, -1)
        else
            fontString:SetShadowColor(0, 0, 0, 0)
        end
    end
    return true
end

function Theme.SetTextScale(mult)
    mult = tonumber(mult) or 1.0
    if mult < MIN_TEXT_SCALE then mult = MIN_TEXT_SCALE end
    if mult > MAX_TEXT_SCALE then mult = MAX_TEXT_SCALE end
    if _G.AkcQOLDB and _G.AkcQOLDB.global then
        _G.AkcQOLDB.global.textScale = mult
    end
    for fs, spec in pairs(Theme.fontRegistry) do
        if fs.SetFont then
            Theme.SetFont(fs, spec.size, spec.flags, spec.bold)
        end
    end
    return mult
end

do
    local reapply = CreateFrame("Frame")
    reapply:RegisterEvent("PLAYER_LOGIN")
    reapply:SetScript("OnEvent", function(self)
        self:UnregisterEvent("PLAYER_LOGIN")
        if Theme.GetTextScale() > 1.0 then
            Theme.SetTextScale(Theme.GetTextScale())
        end
    end)
end

function Theme.SkinButton(btn)
    if not btn or btn.__akcSkinned or not btn.SetBackdrop then return false end
    if not Theme.ApplyBackdrop(btn, "panel") then return false end
    btn.__akcSkinned = true
    btn:HookScript("OnEnter", function(self)
        if self.SetBackdropBorderColor then
            self:SetBackdropBorderColor(rgba(Theme.colors.borderLight))
            self:SetBackdropColor(rgba(Theme.colors.rowHover))
        end
    end)
    btn:HookScript("OnLeave", function(self)
        if self.SetBackdropBorderColor then
            self:SetBackdropBorderColor(rgba(Theme.colors.border))
            self:SetBackdropColor(rgba(Theme.colors.panelBg))
        end
    end)
    return true
end
