-- Compatibility shims for FrameXML globals that Midnight (12.x) removed but
-- the bundled Ace3 libraries still call at runtime.
--
-- SetDesaturation(texture, bool) was removed in 12.x; AceGUI's CheckBox still calls it.
if type(_G.SetDesaturation) ~= "function" then
    function _G.SetDesaturation(texture, desaturated)
        if texture and texture.SetDesaturated then
            texture:SetDesaturated(desaturated and true or false)
        end
    end
end

-- AceGUI's Keybinding widget still reaches for the old spell API.
if type(_G.GetSpellInfo) ~= "function" and C_Spell and C_Spell.GetSpellInfo then
    function _G.GetSpellInfo(spell)
        local info = C_Spell.GetSpellInfo(spell)
        if not info then return nil end
        return info.name, nil, info.iconID, info.castTime,
               info.minRange, info.maxRange, info.spellID, info.originalIconID
    end
end

-- Addon metadata helpers moved into C_AddOns in 11.x.
if type(_G.GetAddOnMetadata) ~= "function" and C_AddOns and C_AddOns.GetAddOnMetadata then
    _G.GetAddOnMetadata = C_AddOns.GetAddOnMetadata
end
if type(_G.IsAddOnLoaded) ~= "function" and C_AddOns and C_AddOns.IsAddOnLoaded then
    _G.IsAddOnLoaded = C_AddOns.IsAddOnLoaded
end
if type(_G.LoadAddOn) ~= "function" and C_AddOns and C_AddOns.LoadAddOn then
    _G.LoadAddOn = C_AddOns.LoadAddOn
end
