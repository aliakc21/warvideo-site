--[[
    Display.lua - Visual cooldown bars for the Raid CD Tracker
    Multi-panel support: each panel has its own anchor, bars, and spell list.
]]

local _, addon = ...

local BACKDROP_INFO = {
    bgFile   = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile     = true,
    tileSize = 16,
    edgeSize = 10,
    insets   = { left = 2, right = 2, top = 2, bottom = 2 },
}

-- Per-panel UI data: panelFrames[panelID] = { anchor, barPool, activeBars }
local panelFrames = {}

-- Raid CD cooldown tracker removed from the UI: hard-disable all panel rendering so
-- no on-screen cooldown panels are ever created/shown, regardless of saved settings.
local RAIDCD_TRACKER_DISABLED = true

local function HeaderMouseoverEnabled()
    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    return profile and profile.headerMouseover
end

local function ApplyHeaderVisibility(pf, panelDB)
    if not pf or not pf.anchor or not panelDB then return end
    local anchor = pf.anchor
    local showHeader = not panelDB.locked
        and (panelDB.headerVisible or not HeaderMouseoverEnabled() or anchor.isHeaderHovering)

    anchor:EnableMouse(not panelDB.locked)
    if showHeader then
        anchor:SetBackdropColor(0, 0, 0, 0.5)
        anchor:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)
        anchor.title:Show()
        anchor.settingsBtn:Show()
    else
        anchor:SetBackdropColor(0, 0, 0, 0)
        anchor:SetBackdropBorderColor(0, 0, 0, 0)
        anchor.title:Hide()
        anchor.settingsBtn:Hide()
    end
end

-- ---------------------------------------------------------------------------
-- Scan group/raid roster
-- ---------------------------------------------------------------------------
local function GetGroupMembers()
    local members = {}
    local seen = {}

    local function addUnit(unit)
        if not UnitExists(unit) then return end
        local name = UnitName(unit)
        if not name or seen[name] then return end
        local _, classToken = UnitClass(unit)
        seen[name] = true
        table.insert(members, { name = name, class = classToken })
    end

    if IsInRaid() then
        for i = 1, 40 do addUnit("raid" .. i) end
    elseif IsInGroup() then
        addUnit("player")
        for i = 1, 4 do addUnit("party" .. i) end
    else
        addUnit("player")
    end
    return members
end

-- ---------------------------------------------------------------------------
-- Create a single panel display
-- ---------------------------------------------------------------------------
function addon:CreatePanelDisplay(panelID)
    if panelFrames[panelID] then return end

    local panelDB = addon.Enrage.db.profile.panels[panelID]
    if not panelDB then return end

    local pf = {
        barPool = {},
        activeBars = {},
    }

    local anch = CreateFrame("Frame", "EnrageRaidCDAnchor_" .. panelID, UIParent, "BackdropTemplate")
    anch:SetSize(203, 30)
    anch:SetPoint(panelDB.point, UIParent, panelDB.relPoint, panelDB.xOfs, panelDB.yOfs)
    anch:SetBackdrop(BACKDROP_INFO)
    anch:SetBackdropColor(0, 0, 0, 0.5)
    anch:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)
    anch:SetClampedToScreen(true)

    -- Title
    local title = anch:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    title:SetPoint("CENTER")
    title:SetText(panelDB.name)
    anch.title = title

    -- Settings button
    local settingsBtn = CreateFrame("Button", nil, anch)
    settingsBtn:SetSize(16, 16)
    settingsBtn:SetPoint("RIGHT", anch, "RIGHT", -4, 0)
    settingsBtn:SetNormalTexture("Interface\\Buttons\\UI-OptionsButton")
    settingsBtn:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    settingsBtn:SetScript("OnClick", function()
        if _G.Enrage_OpenMatrixSettingsSection then
            _G.Enrage_OpenMatrixSettingsSection("raidcd")
        else
            LibStub("AceConfigDialog-3.0"):Open("EnrageRaidCD")
        end
    end)
    settingsBtn:SetScript("OnEnter", function(self)
        anch.isHeaderHovering = true
        addon:UpdatePanelFrameLock(panelID)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText("AkcQOL Settings")
        GameTooltip:Show()
    end)
    settingsBtn:SetScript("OnLeave", function()
        C_Timer.After(0.05, function()
            if MouseIsOver and (MouseIsOver(anch) or MouseIsOver(settingsBtn)) then return end
            anch.isHeaderHovering = false
            addon:UpdatePanelFrameLock(panelID)
        end)
        GameTooltip:Hide()
    end)
    anch.settingsBtn = settingsBtn

    -- Dragging
    anch:SetMovable(true)
    anch:EnableMouse(true)
    anch:RegisterForDrag("LeftButton")
    anch:SetScript("OnEnter", function(self)
        self.isHeaderHovering = true
        addon:UpdatePanelFrameLock(panelID)
    end)
    anch:SetScript("OnLeave", function(self)
        C_Timer.After(0.05, function()
            if MouseIsOver and (MouseIsOver(self) or MouseIsOver(settingsBtn)) then return end
            self.isHeaderHovering = false
            addon:UpdatePanelFrameLock(panelID)
        end)
    end)
    anch:SetScript("OnDragStart", function(self)
        if not panelDB.locked then
            self:StartMoving()
        end
    end)
    anch:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, xOfs, yOfs = self:GetPoint()
        panelDB.point = point
        panelDB.relPoint = relPoint
        panelDB.xOfs = xOfs
        panelDB.yOfs = yOfs
    end)

    pf.anchor = anch
    panelFrames[panelID] = pf

    addon:UpdatePanelFrameLock(panelID)
end

-- ---------------------------------------------------------------------------
-- Destroy a panel display
-- ---------------------------------------------------------------------------
function addon:DestroyPanelDisplay(panelID)
    local pf = panelFrames[panelID]
    if not pf then return end
    for _, bar in ipairs(pf.activeBars) do
        bar:Hide()
    end
    if pf.anchor then
        pf.anchor:Hide()
        pf.anchor:SetParent(nil)
    end
    panelFrames[panelID] = nil
end

-- ---------------------------------------------------------------------------
-- Create all panel displays
-- ---------------------------------------------------------------------------
function addon:CreateDisplay()
    if RAIDCD_TRACKER_DISABLED then return end
    for panelID in pairs(addon.Enrage.db.profile.panels) do
        addon:CreatePanelDisplay(panelID)
    end
end

-- ---------------------------------------------------------------------------
-- Frame lock per panel
-- ---------------------------------------------------------------------------
function addon:UpdatePanelFrameLock(panelID)
    local pf = panelFrames[panelID]
    if not pf or not pf.anchor then return end
    local panelDB = addon.Enrage.db.profile.panels[panelID]
    if not panelDB then return end

    ApplyHeaderVisibility(pf, panelDB)
end

function addon:UpdateFrameLock()
    for panelID in pairs(panelFrames) do
        addon:UpdatePanelFrameLock(panelID)
    end
end

-- ---------------------------------------------------------------------------
-- Bar acquire/release per panel
-- ---------------------------------------------------------------------------
local function AcquireBar(panelID)
    local pf = panelFrames[panelID]
    if not pf then return nil end
    local bar = table.remove(pf.barPool)
    if not bar then
        bar = CreateFrame("StatusBar", nil, pf.anchor)
        bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")

        bar.bg = bar:CreateTexture(nil, "BACKGROUND")
        bar.bg:SetAllPoints()
        bar.bg:SetColorTexture(0, 0, 0, 0.6)

        bar.icon = bar:CreateTexture(nil, "OVERLAY")
        bar.icon:SetSize(1, 1)
        bar.icon:SetPoint("LEFT", bar, "LEFT", 2, 0)

        bar.nameText = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        bar.nameText:SetPoint("LEFT", bar.icon, "RIGHT", 4, 0)
        bar.nameText:SetJustifyH("LEFT")

        bar.timeText = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        bar.timeText:SetPoint("RIGHT", bar, "RIGHT", -4, 0)
        bar.timeText:SetJustifyH("RIGHT")
    else
        bar:SetParent(pf.anchor)
    end

    bar:Show()
    return bar
end

local function ReleaseBar(panelID, bar)
    local pf = panelFrames[panelID]
    if not pf then return end
    bar:Hide()
    bar:ClearAllPoints()
    bar.enrageStatus = nil
    bar.enrageExpirationTime = nil
    bar.enrageDuration = nil
    bar.enrageLastTimeText = nil
    table.insert(pf.barPool, bar)
end

-- ---------------------------------------------------------------------------
-- Update bars for a single panel
-- ---------------------------------------------------------------------------
function addon:UpdatePanelBars(panelID)
    if RAIDCD_TRACKER_DISABLED then return end
    local pf = panelFrames[panelID]
    if not pf or not pf.anchor then return end

    local panelDB = addon.Enrage.db.profile.panels[panelID]
    if not panelDB then return end

    local globalDB = addon.Enrage.db.profile

    if not globalDB.enabled then
        pf.anchor:Hide()
        return
    end
    if not globalDB.showOutsideRaid and not IsInGroup() and not IsInRaid() then
        pf.anchor:Hide()
        return
    end
    pf.anchor:Show()

    local cooldowns = addon:GetActiveCooldowns()
    local barWidth = panelDB.barWidth
    local barHeight = panelDB.barHeight
    local spacing = panelDB.barSpacing
    local showIcons = globalDB.showIcons
    local growUp = panelDB.barGrowUp
    local trackedSpells = panelDB.trackedSpells
    local now = GetTime()
    local myName = UnitName("player")

    -- Release old bars
    for _, bar in ipairs(pf.activeBars) do
        ReleaseBar(panelID, bar)
    end
    wipe(pf.activeBars)

    -- Build display list
    local displayList = {}
    local members = GetGroupMembers()
    local showSelf = globalDB.showSelf

    local mySpecIndex = GetSpecialization()
    local mySpecID = mySpecIndex and GetSpecializationInfo(mySpecIndex) or 0

    for _, member in ipairs(members) do
        if showSelf or member.name ~= myName then
            local classSpells = addon.SpellsByClass[member.class]
            if classSpells then
                -- Spec resolution: player=self, addon users=Roster.spec, fallback=InferredSpec.
                local memberSpec, specSource
                if member.name == myName then
                    memberSpec, specSource = mySpecID, "self"
                elseif addon.Roster[member.name] then
                    memberSpec, specSource = addon.Roster[member.name].spec or 0, "addon"
                elseif addon.InferredSpecs[member.name] then
                    memberSpec, specSource = addon.InferredSpecs[member.name], "inferred"
                end

                for _, spellID in ipairs(classSpells) do
                    if trackedSpells[spellID] then
                        local info = addon.RaidCDData[spellID]
                        local hasAddon = (specSource == "self") or (specSource == "addon")

                        local showSpell = true
                        if specSource == "self" then
                            if info.spec ~= 0 and not IsSpellKnown(spellID) then
                                showSpell = false
                            end
                        elseif specSource == "addon" then
                            local rosterInfo = addon.Roster[member.name]
                            if info.spec ~= 0 and rosterInfo and rosterInfo.cdModifiers then
                                if not rosterInfo.cdModifiers[spellID] then
                                    showSpell = false
                                end
                            end
                        elseif specSource == "inferred" then
                            -- Inferred spec is known; keep only matching spec-specific spells.
                            if info.spec ~= 0 and info.spec ~= memberSpec then
                                showSpell = false
                            end
                        else
                            -- Spec is unknown; hide spec-specific spells to avoid false positives.
                            -- Spec-agnostic spells remain visible.
                            if info.spec ~= 0 then
                                showSpell = false
                            end
                        end

                        if showSpell then
                            local key = member.name .. "-" .. spellID
                            local cd = cooldowns[key]
                            local remaining = cd and (cd.expirationTime - now) or 0
                            local status = (remaining > 0) and "cd" or "ready"

                            table.insert(displayList, {
                                spellID     = spellID,
                                playerName  = member.name,
                                playerClass = member.class,
                                remaining   = remaining,
                                duration    = cd and cd.duration or info.baseCD,
                                expirationTime = cd and cd.expirationTime or nil,
                                status      = status,
                            })
                        end
                    end
                end
            end
        end
    end

    -- Sort
    local statusOrder = { cd = 1, ready = 2 }
    table.sort(displayList, function(a, b)
        local oa, ob = statusOrder[a.status], statusOrder[b.status]
        if oa ~= ob then return oa < ob end
        if a.status == "cd" then return a.remaining < b.remaining end
        if a.playerClass ~= b.playerClass then return a.playerClass < b.playerClass end
        return a.playerName < b.playerName
    end)

    -- Create bars
    for i, entry in ipairs(displayList) do
        local bar = AcquireBar(panelID)
        if not bar then break end
        table.insert(pf.activeBars, bar)

        bar:SetSize(barWidth, barHeight)
        local yDir = growUp and 1 or -1
        local yOffset = yDir * ((i - 1) * (barHeight + spacing) + 2)
        bar:SetPoint("TOPLEFT", pf.anchor, "BOTTOM", -(barWidth / 2), yOffset)

        bar:SetMinMaxValues(0, entry.duration)

        local classColor = RAID_CLASS_COLORS[entry.playerClass]

        if entry.status == "cd" then
            bar:SetValue(entry.remaining)
            bar:SetAlpha(0.65)
        else -- ready
            bar:SetAlpha(1)
            bar:SetValue(entry.duration)
        end
        if classColor then
            bar:SetStatusBarColor(classColor.r, classColor.g, classColor.b, 0.8)
        else
            bar:SetStatusBarColor(0.5, 0.5, 0.5, 0.8)
        end

        -- Icon
        local info = addon.RaidCDData[entry.spellID]
        local spellLabel = info and info.name or ("Spell " .. entry.spellID)
        local apiName = C_Spell.GetSpellName(entry.spellID)
        if apiName and apiName ~= "" then spellLabel = apiName end

        bar.icon:SetSize(barHeight - 2, barHeight - 2)
        if showIcons then
            bar.icon:SetTexture(C_Spell.GetSpellTexture(entry.spellID))
            bar.icon:SetAlpha(1)
        else
            bar.icon:SetTexture(nil)
            bar.icon:SetAlpha(0)
        end
        bar.icon:Show()

        -- Texts
        local coloredName = entry.playerName
        if classColor then
            coloredName = "|c" .. classColor.colorStr .. entry.playerName .. "|r"
        end

        if globalDB.showSpellName then
            bar.nameText:SetText(coloredName .. " - " .. spellLabel)
        else
            bar.nameText:SetText(coloredName)
        end

        if entry.status == "cd" then
            local timeText = string.format("%.1f", entry.remaining)
            bar.timeText:SetText(timeText)
            bar.enrageLastTimeText = timeText
        else
            bar.timeText:SetText("|cff00ff00Ready|r")
            bar.enrageLastTimeText = nil
        end

        -- Lightweight ticker metadata. Structural panel work is only repeated
        -- when roster/settings/cooldown state changes.
        bar.enrageStatus = entry.status
        bar.enrageExpirationTime = entry.expirationTime
        bar.enrageDuration = entry.duration
    end
end

-- ---------------------------------------------------------------------------
-- Full panel refresh. Used only when structure/state has changed.
-- ---------------------------------------------------------------------------
function addon:UpdateAllPanels()
    if RAIDCD_TRACKER_DISABLED then return end
    for panelID in pairs(addon.Enrage.db.profile.panels) do
        addon:UpdatePanelBars(panelID)
    end
    addon.panelsDirty = false
end

function addon:MarkPanelsDirty()
    self.panelsDirty = true
end

-- Update only the visible countdown values. Returns true when a cooldown has
-- completed and a structural rebuild is needed to re-sort Ready entries.
function addon:UpdatePanelTimers()
    if RAIDCD_TRACKER_DISABLED then return false end
    if not addon.Enrage.db.profile.enabled then return false end

    local now = GetTime()
    for _, pf in pairs(panelFrames) do
        for _, bar in ipairs(pf.activeBars) do
            if bar.enrageStatus == "cd" and bar.enrageExpirationTime then
                local remaining = bar.enrageExpirationTime - now
                if remaining <= 0 then
                    return true
                end

                bar:SetValue(remaining)
                local timeText = string.format("%.1f", remaining)
                if timeText ~= bar.enrageLastTimeText then
                    bar.timeText:SetText(timeText)
                    bar.enrageLastTimeText = timeText
                end
            end
        end
    end

    return false
end

function addon:TickPanels()
    if self.panelsDirty then
        self:UpdateAllPanels()
    elseif self:UpdatePanelTimers() then
        self:MarkPanelsDirty()
        self:UpdateAllPanels()
    end
end

-- ---------------------------------------------------------------------------
-- Refresh panel title text
-- ---------------------------------------------------------------------------
function addon:RefreshPanelTitle(panelID)
    local pf = panelFrames[panelID]
    if pf and pf.anchor and pf.anchor.title then
        local panelDB = addon.Enrage.db.profile.panels[panelID]
        if panelDB then
            pf.anchor.title:SetText(panelDB.name)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Reset panel position
-- ---------------------------------------------------------------------------
function addon:ResetPosition(panelID)
    if panelID then
        local panelDB = addon.Enrage.db.profile.panels[panelID]
        if panelDB then
            panelDB.point = "CENTER"
            panelDB.relPoint = "CENTER"
            panelDB.xOfs = 0
            panelDB.yOfs = 0
            local pf = panelFrames[panelID]
            if pf and pf.anchor then
                pf.anchor:ClearAllPoints()
                pf.anchor:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
            end
        end
    else
        for id in pairs(addon.Enrage.db.profile.panels) do
            addon:ResetPosition(id)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Hide all panels
-- ---------------------------------------------------------------------------
function addon:HideDisplay()
    for _, pf in pairs(panelFrames) do
        if pf.anchor then pf.anchor:Hide() end
    end
end

-- ---------------------------------------------------------------------------
-- RefreshDisplay (backward compat, no-op)
-- ---------------------------------------------------------------------------
function addon:RefreshDisplay()
end
