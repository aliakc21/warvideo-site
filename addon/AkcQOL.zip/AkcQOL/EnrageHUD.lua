-- =========================================================================
-- ENRAGE HUD - Talent Build Info, Durability, Loot Spec
-- Draggable, scalable info frame
-- =========================================================================

local FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"

local hudFrame, talentText, buildText, durabilityText, lootSpecIcon, lootSpecText
local hudUpdateTicker

------------------------------------------------------------
-- Talent build detection
------------------------------------------------------------
-- Get the active WoW loadout name (e.g. "Single", "M+", "Raid")
local function GetActiveLoadoutName()
    local name
    pcall(function()
        local specIndex = GetSpecialization()
        if not specIndex then return end
        local specID = GetSpecializationInfo(specIndex)
        if not specID then return end
        -- GetLastSelectedSavedConfigID returns the LOADOUT configID (not the spec configID)
        local loadoutConfigID = C_ClassTalents.GetLastSelectedSavedConfigID(specID)
        if loadoutConfigID then
            local info = C_Traits.GetConfigInfo(loadoutConfigID)
            if info and info.name and info.name ~= "" then
                name = info.name
            end
        end
    end)
    return name
end

------------------------------------------------------------
-- Durability
------------------------------------------------------------
local DURABILITY_SLOTS = { 1, 3, 5, 6, 7, 8, 9, 10, 16, 17 }

local function GetLowestDurability()
    local lowest = 100
    for _, slotID in ipairs(DURABILITY_SLOTS) do
        local cur, mx = GetInventoryItemDurability(slotID)
        if cur and mx and mx > 0 then
            local pct = math.floor((cur / mx) * 100)
            if pct < lowest then lowest = pct end
        end
    end
    return lowest
end

------------------------------------------------------------
-- Loot Spec
------------------------------------------------------------
local function GetLootSpecInfo()
    local lootSpecID = GetLootSpecialization()
    if lootSpecID == 0 then
        -- Using current spec
        local specIndex = GetSpecialization()
        if specIndex then
            local _, name, _, icon = GetSpecializationInfo(specIndex)
            return name, icon
        end
        return "?", nil
    else
        local _, name, _, icon = GetSpecializationInfoByID(lootSpecID)
        return name, icon
    end
end

------------------------------------------------------------
-- HUD Frame creation
------------------------------------------------------------
local function CreateHUD()
    if hudFrame then return end

    hudFrame = CreateFrame("Frame", "EnrageHUDFrame", UIParent)
    hudFrame:SetSize(220, 48)
    hudFrame:SetFrameStrata("LOW")
    hudFrame:SetClampedToScreen(true)

    -- Restore position or center
    if EnrageDB and EnrageDB.global and EnrageDB.global.hudPosX then
        hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT",
            EnrageDB.global.hudPosX, EnrageDB.global.hudPosY)
    else
        hudFrame:SetPoint("TOP", UIParent, "TOP", 0, -10)
    end

    -- Restore scale
    local savedScale = EnrageDB and EnrageDB.global and EnrageDB.global.hudScale or 1.0
    hudFrame:SetScale(savedScale)

    -- Make draggable
    hudFrame:SetMovable(true)
    hudFrame:EnableMouse(true)
    hudFrame:RegisterForDrag("LeftButton")
    hudFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    local function LockHUDPosition()
        hudFrame:StopMovingOrSizing()
        local left, top = hudFrame:GetLeft(), hudFrame:GetTop()
        if left and top then
            hudFrame:ClearAllPoints()
            hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
            if EnrageDB and EnrageDB.global then
                EnrageDB.global.hudPosX = left
                EnrageDB.global.hudPosY = top
            end
        end
    end

    hudFrame:SetScript("OnDragStop", LockHUDPosition)

    -- Scale is controlled from Settings +/- buttons

    -- No background - clean floating text
    -- Clickthrough overlay so dragging works from anywhere on the text
    local hitOverlay = CreateFrame("Frame", nil, hudFrame)
    hitOverlay:SetAllPoints()
    hitOverlay:EnableMouse(true)
    hitOverlay:RegisterForDrag("LeftButton")
    hitOverlay:SetScript("OnDragStart", function() hudFrame:StartMoving() end)
    hitOverlay:SetScript("OnDragStop", LockHUDPosition)

    -- All rows use fixed LEFT anchor to hudFrame so nothing shifts
    -- Row 1: Spec + WoW loadout name (e.g. "Fury - Single")
    talentText = hitOverlay:CreateFontString(nil, "OVERLAY")
    talentText:SetFont(FONT_FACE, 12, FONT_FLAGS)
    talentText:SetPoint("LEFT", hudFrame, "LEFT", 0, 0)
    talentText:SetJustifyH("LEFT")
    talentText:SetText("|cFF888888?|r")

    -- Row 2: Loaded boss/dungeon name (e.g. "Midnight Falls")
    buildText = hitOverlay:CreateFontString(nil, "OVERLAY")
    buildText:SetFont(FONT_FACE, 11, FONT_FLAGS)
    buildText:SetPoint("TOPLEFT", talentText, "BOTTOMLEFT", 0, -1)
    buildText:SetJustifyH("LEFT")
    buildText:SetText("")

    -- Row 3: Durability + Loot Spec (fixed below row 1, shifts up when row 2 hidden)
    durabilityText = hitOverlay:CreateFontString(nil, "OVERLAY")
    durabilityText:SetFont(FONT_FACE, 11, FONT_FLAGS)
    durabilityText:SetJustifyH("LEFT")
    durabilityText:SetText("|cFFAAAAAADurability: 100%|r")

    -- Loot spec: text then icon
    lootSpecText = hitOverlay:CreateFontString(nil, "OVERLAY")
    lootSpecText:SetFont(FONT_FACE, 11, FONT_FLAGS)
    lootSpecText:SetPoint("LEFT", durabilityText, "RIGHT", 8, 0)
    lootSpecText:SetJustifyH("LEFT")
    lootSpecText:SetText("|cFFAAAAAALoot:|r")

    lootSpecIcon = hitOverlay:CreateTexture(nil, "OVERLAY")
    lootSpecIcon:SetSize(16, 16)
    lootSpecIcon:SetPoint("LEFT", lootSpecText, "RIGHT", 3, 0)

    _G.EnrageHUDFrame = hudFrame
end

------------------------------------------------------------
-- Update HUD
------------------------------------------------------------
local function UpdateHUD()
    if not hudFrame or not hudFrame:IsShown() then return end
    if not pcall(function() GetSpecialization() end) then return end -- APIs not ready yet

    -- Row 1: Spec name + WoW loadout name
    local specIndex = GetSpecialization()
    local specName = specIndex and select(2, GetSpecializationInfo(specIndex)) or "?"
    local _, className = UnitClass("player")
    local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
    local colorStr = classColor and classColor.colorStr or "FFFFFFFF"

    local loadoutName = GetActiveLoadoutName()
    if loadoutName then
        talentText:SetText("|c" .. colorStr .. specName .. "|r |cFF888888-|r |cFF00FF00" .. loadoutName .. "|r")
    else
        talentText:SetText("|c" .. colorStr .. specName .. "|r")
    end

    -- Row 2: Show loaded boss/dungeon name
    local lastBuild = _G.Enrage_LastLoadedBuild
    local buildName = nil
    if lastBuild and lastBuild:find("^WCL:") then
        buildName = lastBuild:sub(5)
    end

    -- Anchor durability row based on whether build text is visible
    durabilityText:ClearAllPoints()
    if buildName then
        buildText:SetText("|cFFFFAA00" .. buildName .. "|r")
        buildText:Show()
        durabilityText:SetPoint("TOPLEFT", buildText, "BOTTOMLEFT", 0, -1)
    else
        buildText:SetText("")
        buildText:Hide()
        durabilityText:SetPoint("TOPLEFT", talentText, "BOTTOMLEFT", 0, -1)
    end

    -- Durability
    local dur = GetLowestDurability()
    local durColor = "00FF00"
    if dur <= 25 then durColor = "FF0000"
    elseif dur <= 50 then durColor = "FFAA00" end
    durabilityText:SetText("|cFFAAAAAADurability: |r|cFF" .. durColor .. dur .. "%|r")

    -- Loot spec
    local specName, specIcon = GetLootSpecInfo()
    if specIcon then
        lootSpecIcon:SetTexture(specIcon)
        lootSpecIcon:Show()
    else
        lootSpecIcon:Hide()
    end
    lootSpecText:SetText("|cFFAAAAAALoot:|r")
end

------------------------------------------------------------
-- Show/Hide
------------------------------------------------------------
local function ShowHUD()
    if not hudFrame then CreateHUD() end
    hudFrame:Show()
    if not hudUpdateTicker then
        hudUpdateTicker = C_Timer.NewTicker(2, UpdateHUD)
    end
    UpdateHUD()
end

local function HideHUD()
    if hudFrame then hudFrame:Hide() end
    if hudUpdateTicker then
        hudUpdateTicker:Cancel()
        hudUpdateTicker = nil
    end
end

local function ApplyHUDVisibility()
    if EnrageDB and EnrageDB.global and EnrageDB.global.showHUD ~= false then
        ShowHUD()
    else
        HideHUD()
    end
end
_G.Enrage_ApplyHUDVisibility = ApplyHUDVisibility

-- Scale adjustment from Settings
_G.Enrage_SetHUDScale = function(delta)
    if not EnrageDB or not EnrageDB.global then return end
    local cur = EnrageDB.global.hudScale or 1.0
    local newScale = cur + delta
    if newScale < 0.5 then newScale = 0.5 end
    if newScale > 3.0 then newScale = 3.0 end
    EnrageDB.global.hudScale = newScale
    if hudFrame then hudFrame:SetScale(newScale) end
end

------------------------------------------------------------
-- Initialize on PLAYER_LOGIN (after EnrageDB is ready)
------------------------------------------------------------
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
initFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
initFrame:RegisterEvent("ACTIVE_COMBAT_CONFIG_CHANGED")
initFrame:RegisterEvent("TRAIT_CONFIG_LIST_UPDATED")
initFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        if not EnrageDB then EnrageDB = {} end
        if not EnrageDB.global then EnrageDB.global = {} end
        if EnrageDB.global.showHUD == nil then EnrageDB.global.showHUD = false end
        if not EnrageDB.global.hudScale then EnrageDB.global.hudScale = 1.0 end
        -- Restore last loaded build from SavedVariables
        if EnrageDB.global.lastLoadedBuild then
            _G.Enrage_LastLoadedBuild = EnrageDB.global.lastLoadedBuild
        end
        ApplyHUDVisibility()
    elseif event == "ACTIVE_COMBAT_CONFIG_CHANGED" then
        -- TalentPanel owns Enrage_LastLoadedBuild persistence. HUD only redraws it.
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(0.5, UpdateHUD)
        end
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        -- TalentPanel clears/restores build tags after spec changes; HUD waits for APIs.
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(1.0, UpdateHUD)
            C_Timer.After(3.0, UpdateHUD)
        end
    elseif event == "TRAIT_CONFIG_UPDATED" or event == "TRAIT_CONFIG_LIST_UPDATED" then
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(0.5, UpdateHUD)
            C_Timer.After(1.5, UpdateHUD)
        end
    end
end)
