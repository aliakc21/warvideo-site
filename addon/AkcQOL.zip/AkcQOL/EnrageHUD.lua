-- =========================================================================
-- ENRAGE HUD - Talent Build Info, Durability, Loot Spec
-- Draggable, scalable info frame
-- =========================================================================

local FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"

local hudFrame, talentText, buildText, durabilityText, lootSpecIcon, lootSpecText
local hudUpdateTicker

------------------------------------------------------------
-- Talent build detection
------------------------------------------------------------
-- Get the active WoW loadout name (e.g. "Single", "M+", "Raid")
local function GetActiveLoadoutName()
    local name
    pcall(function()
        local specIndex = GetSpecialization()
        if not specIndex then return end
        local specID = GetSpecializationInfo(specIndex)
        if not specID then return end
        -- GetLastSelectedSavedConfigID returns the LOADOUT configID (not the spec configID)
        local loadoutConfigID = C_ClassTalents.GetLastSelectedSavedConfigID(specID)
        if loadoutConfigID then
            local info = C_Traits.GetConfigInfo(loadoutConfigID)
            if info and info.name and info.name ~= "" then
                name = info.name
            end
        end
    end)
    return name
end

------------------------------------------------------------
-- Durability
------------------------------------------------------------
local DURABILITY_SLOTS = { 1, 3, 5, 6, 7, 8, 9, 10, 16, 17 }

local function GetLowestDurability()
    local lowest = 100
    for _, slotID in ipairs(DURABILITY_SLOTS) do
        local cur, mx = GetInventoryItemDurability(slotID)
        if cur and mx and mx > 0 then
            local pct = math.floor((cur / mx) * 100)
            if pct < lowest then lowest = pct end
        end
    end
    return lowest
end

------------------------------------------------------------
-- Loot Spec
------------------------------------------------------------
local function GetLootSpecInfo()
    local lootSpecID = GetLootSpecialization()
    if lootSpecID == 0 then
        -- Using current spec
        local specIndex = GetSpecialization()
        if specIndex then
            local _, name, _, icon = GetSpecializationInfo(specIndex)
            return name, icon
        end
        return "?", nil
    else
        local _, name, _, icon = GetSpecializationInfoByID(lootSpecID)
        return name, icon
    end
end

------------------------------------------------------------
-- HUD Frame creation
------------------------------------------------------------
local function CreateHUD()
    if hudFrame then return end

    hudFrame = CreateFrame("Frame", "EnrageHUDFrame", UIParent)
    hudFrame:SetSize(220, 48)
    hudFrame:SetFrameStrata("LOW")
    -- No screen clamp: the frame is anchored TOPLEFT and tight-fits the text, growing
    -- right/down. With clamping on, any width change near a screen edge (loadout name,
    -- durability digit count, the WCL build row) would shove the whole frame back inside
    -- and jump the anchor every 2s. Drag + "Reset HUD Position" recover it if pushed off.
    hudFrame:SetClampedToScreen(false)

    -- Restore position or center
    if EnrageDB and EnrageDB.global and EnrageDB.global.hudPosX then
        hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT",
            EnrageDB.global.hudPosX, EnrageDB.global.hudPosY)
    else
        hudFrame:SetPoint("TOP", UIParent, "TOP", 0, -10)
    end

    -- Restore scale
    local savedScale = EnrageDB and EnrageDB.global and EnrageDB.global.hudScale or 1.0
    hudFrame:SetScale(savedScale)

    -- Make draggable
    hudFrame:SetMovable(true)
    hudFrame:EnableMouse(true)
    hudFrame:RegisterForDrag("LeftButton")
    hudFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    local function LockHUDPosition()
        hudFrame:StopMovingOrSizing()
        local left, top = hudFrame:GetLeft(), hudFrame:GetTop()
        if left and top then
            hudFrame:ClearAllPoints()
            hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
            if EnrageDB and EnrageDB.global then
                EnrageDB.global.hudPosX = left
                EnrageDB.global.hudPosY = top
            end
        end
    end

    hudFrame:SetScript("OnDragStop", LockHUDPosition)

    -- Scale is controlled from Settings +/- buttons

    -- No background - clean floating text
    -- Clickthrough overlay so dragging works from anywhere on the text
    local hitOverlay = CreateFrame("Frame", nil, hudFrame)
    hitOverlay:SetAllPoints()
    hitOverlay:EnableMouse(true)
    hitOverlay:RegisterForDrag("LeftButton")
    hitOverlay:SetScript("OnDragStart", function() hudFrame:StartMoving() end)
    hitOverlay:SetScript("OnDragStop", LockHUDPosition)

    -- All rows use fixed LEFT anchor to hudFrame so nothing shifts
    -- Row 1: Spec + WoW loadout name (e.g. "Fury - Single")
    talentText = hitOverlay:CreateFontString(nil, "OVERLAY")
    talentText:SetFont(FONT_FACE, 12, FONT_FLAGS)
    talentText:SetPoint("TOPLEFT", hudFrame, "TOPLEFT", 1, -1)
    talentText:SetJustifyH("LEFT")
    talentText:SetText("|cFF888888?|r")

    -- Row 2: Loaded boss/dungeon name (e.g. "Midnight Falls")
    buildText = hitOverlay:CreateFontString(nil, "OVERLAY")
    buildText:SetFont(FONT_FACE, 11, FONT_FLAGS)
    buildText:SetPoint("TOPLEFT", talentText, "BOTTOMLEFT", 0, -1)
    buildText:SetJustifyH("LEFT")
    buildText:SetText("")

    -- Row 3: Durability + Loot Spec (fixed below row 1, shifts up when row 2 hidden)
    durabilityText = hitOverlay:CreateFontString(nil, "OVERLAY")
    durabilityText:SetFont(FONT_FACE, 11, FONT_FLAGS)
    durabilityText:SetJustifyH("LEFT")
    durabilityText:SetText("|cFFAAAAAADurability: 100%|r")

    -- Loot spec: text then icon
    lootSpecText = hitOverlay:CreateFontString(nil, "OVERLAY")
    lootSpecText:SetFont(FONT_FACE, 11, FONT_FLAGS)
    lootSpecText:SetPoint("LEFT", durabilityText, "RIGHT", 8, 0)
    lootSpecText:SetJustifyH("LEFT")
    lootSpecText:SetText("|cFFAAAAAALoot:|r")

    lootSpecIcon = hitOverlay:CreateTexture(nil, "OVERLAY")
    lootSpecIcon:SetSize(16, 16)
    lootSpecIcon:SetPoint("LEFT", lootSpecText, "RIGHT", 3, 0)

    _G.EnrageHUDFrame = hudFrame
end

------------------------------------------------------------
-- Update HUD
------------------------------------------------------------
local function UpdateHUD()
    if not hudFrame or not hudFrame:IsShown() then return end
    if not pcall(function() GetSpecialization() end) then return end -- APIs not ready yet

    -- Row 1: Spec name + WoW loadout name
    local specIndex = GetSpecialization()
    local specName = specIndex and select(2, GetSpecializationInfo(specIndex)) or "?"
    local _, className = UnitClass("player")
    local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
    local colorStr = classColor and classColor.colorStr or "FFFFFFFF"

    local loadoutName = GetActiveLoadoutName()
    if loadoutName then
        talentText:SetText("|c" .. colorStr .. specName .. "|r |cFF888888-|r |cFF00FF00" .. loadoutName .. "|r")
    else
        talentText:SetText("|c" .. colorStr .. specName .. "|r")
    end

    -- Row 2: Show loaded boss/dungeon name
    local lastBuild = _G.Enrage_LastLoadedBuild
    local buildName = nil
    if lastBuild and lastBuild:find("^WCL:") then
        buildName = lastBuild:sub(5)
    end

    -- Anchor durability row based on whether build text is visible
    durabilityText:ClearAllPoints()
    if buildName then
        buildText:SetText("|cFFFFAA00" .. buildName .. "|r")
        buildText:Show()
        durabilityText:SetPoint("TOPLEFT", buildText, "BOTTOMLEFT", 0, -1)
    else
        buildText:SetText("")
        buildText:Hide()
        durabilityText:SetPoint("TOPLEFT", talentText, "BOTTOMLEFT", 0, -1)
    end

    -- Durability
    local dur = GetLowestDurability()
    local durColor = "00FF00"
    if dur <= 25 then durColor = "FF0000"
    elseif dur <= 50 then durColor = "FFAA00" end
    durabilityText:SetText("|cFFAAAAAADurability: |r|cFF" .. durColor .. dur .. "%|r")

    -- Loot spec
    local specName, specIcon = GetLootSpecInfo()
    if specIcon then
        lootSpecIcon:SetTexture(specIcon)
        lootSpecIcon:Show()
    else
        lootSpecIcon:Hide()
    end
    lootSpecText:SetText("|cFFAAAAAALoot:|r")

    -- Tight-fit: shrink the frame to EXACTLY the visible text (no extra width/height),
    -- so the draggable box matches the text and nothing "bumps" near the screen edge.
    -- Texts are anchored from hudFrame's TOPLEFT and grow right/down, so the bounding
    -- box maps 1:1 onto the frame; SetSize keeps TOPLEFT fixed (no visual jump).
    local PAD = 2
    local buildShown = buildText:IsShown()
    local iconShown = lootSpecIcon:IsShown()

    local wTalent = talentText:GetStringWidth() or 0
    local wBuild = buildShown and (buildText:GetStringWidth() or 0) or 0
    local wLootRow = (durabilityText:GetStringWidth() or 0) + 8
        + (lootSpecText:GetStringWidth() or 0) + (iconShown and (3 + 16) or 0)
    local maxW = math.max(wTalent, wBuild, wLootRow, 16)

    local hTalent = talentText:GetStringHeight() or 12
    local hBuildRow = buildShown and ((buildText:GetStringHeight() or 11) + 1) or 0
    local hLootRow = math.max(durabilityText:GetStringHeight() or 11, iconShown and 16 or 0) + 1
    local totalH = hTalent + hBuildRow + hLootRow

    hudFrame:SetSize(math.ceil(maxW) + PAD, math.ceil(totalH) + PAD)
end

------------------------------------------------------------
-- Show/Hide
------------------------------------------------------------
local function ShowHUD()
    if not hudFrame then CreateHUD() end
    hudFrame:Show()
    if not hudUpdateTicker then
        hudUpdateTicker = C_Timer.NewTicker(2, UpdateHUD)
    end
    UpdateHUD()
end

local function HideHUD()
    if hudFrame then hudFrame:Hide() end
    if hudUpdateTicker then
        hudUpdateTicker:Cancel()
        hudUpdateTicker = nil
    end
end

local function ApplyHUDVisibility()
    if EnrageDB and EnrageDB.global and EnrageDB.global.showHUD ~= false then
        ShowHUD()
    else
        HideHUD()
    end
end
_G.Enrage_ApplyHUDVisibility = ApplyHUDVisibility

-- Scale adjustment from Settings
_G.Enrage_SetHUDScale = function(delta)
    if not EnrageDB or not EnrageDB.global then return end
    local cur = EnrageDB.global.hudScale or 1.0
    local newScale = cur + delta
    if newScale < 0.5 then newScale = 0.5 end
    if newScale > 3.0 then newScale = 3.0 end
    EnrageDB.global.hudScale = newScale
    if hudFrame then hudFrame:SetScale(newScale) end
end

------------------------------------------------------------
-- Preview + Reset (driven from Settings > HUD & Info)
------------------------------------------------------------
-- Lazily build a highlight box so Preview shows exactly where the HUD sits.
local function EnsureHUDPreviewHighlight()
    if not hudFrame or hudFrame.previewParts then return end
    local fill = hudFrame:CreateTexture(nil, "BACKGROUND")
    fill:SetAllPoints(hudFrame)
    fill:SetColorTexture(0.10, 0.55, 1.0, 0.16)
    local function edge()
        local t = hudFrame:CreateTexture(nil, "BORDER")
        t:SetColorTexture(0.30, 0.80, 1.0, 0.9)
        return t
    end
    local top, bot, lft, rgt = edge(), edge(), edge(), edge()
    top:SetPoint("TOPLEFT", hudFrame, "TOPLEFT");  top:SetPoint("TOPRIGHT", hudFrame, "TOPRIGHT");  top:SetHeight(1)
    bot:SetPoint("BOTTOMLEFT", hudFrame, "BOTTOMLEFT"); bot:SetPoint("BOTTOMRIGHT", hudFrame, "BOTTOMRIGHT"); bot:SetHeight(1)
    lft:SetPoint("TOPLEFT", hudFrame, "TOPLEFT");  lft:SetPoint("BOTTOMLEFT", hudFrame, "BOTTOMLEFT");  lft:SetWidth(1)
    rgt:SetPoint("TOPRIGHT", hudFrame, "TOPRIGHT"); rgt:SetPoint("BOTTOMRIGHT", hudFrame, "BOTTOMRIGHT"); rgt:SetWidth(1)
    hudFrame.previewParts = { fill, top, bot, lft, rgt }
end

local function SetHUDPreviewHighlight(on)
    if on then EnsureHUDPreviewHighlight() end
    if hudFrame and hudFrame.previewParts then
        for _, t in ipairs(hudFrame.previewParts) do
            if on then t:Show() else t:Hide() end
        end
    end
end

-- Temporarily raise the HUD above the settings panel so you can see it and where it
-- sits, even if "Show HUD Info" is off. Token guards overlapping previews.
local hudPreviewToken = 0
_G.Enrage_PreviewHUD = function()
    if not hudFrame then CreateHUD() end
    hudPreviewToken = hudPreviewToken + 1
    local token = hudPreviewToken
    hudFrame:Show()
    hudFrame:SetFrameStrata("TOOLTIP")
    SetHUDPreviewHighlight(true)
    UpdateHUD()
    if C_Timer and C_Timer.After then
        C_Timer.After(8, function()
            if token ~= hudPreviewToken then return end
            SetHUDPreviewHighlight(false)
            if hudFrame then hudFrame:SetFrameStrata("LOW") end
            ApplyHUDVisibility()
        end)
    end
end

-- Recenter the HUD on screen, persist it (drag-save format), then preview so the
-- user immediately sees where it landed.
_G.Enrage_ResetHUDPosition = function()
    if not hudFrame then CreateHUD() end
    hudFrame:Show()
    UpdateHUD()  -- size is correct before we center
    hudFrame:ClearAllPoints()
    hudFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    local left, top = hudFrame:GetLeft(), hudFrame:GetTop()
    if left and top then
        hudFrame:ClearAllPoints()
        hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
        if EnrageDB and EnrageDB.global then
            EnrageDB.global.hudPosX = left
            EnrageDB.global.hudPosY = top
        end
    end
    if _G.Enrage_PreviewHUD then _G.Enrage_PreviewHUD() end
end

-- Restore every HUD setting (shown/scale/position) to defaults.
_G.Enrage_ResetHUDDefaults = function()
    if not EnrageDB or not EnrageDB.global then return end
    local g = EnrageDB.global
    g.showHUD = false       -- default: off
    g.hudScale = 1.0
    g.hudPosX, g.hudPosY = nil, nil
    if hudFrame then
        hudFrame:SetScale(1.0)
        hudFrame:ClearAllPoints()
        hudFrame:SetPoint("TOP", UIParent, "TOP", 0, -10)
    end
    ApplyHUDVisibility()    -- showHUD=false -> hides
end

------------------------------------------------------------
-- Initialize on PLAYER_LOGIN (after EnrageDB is ready)
------------------------------------------------------------
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
initFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
initFrame:RegisterEvent("ACTIVE_COMBAT_CONFIG_CHANGED")
initFrame:RegisterEvent("TRAIT_CONFIG_LIST_UPDATED")
initFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        if not EnrageDB then EnrageDB = {} end
        if not EnrageDB.global then EnrageDB.global = {} end
        if EnrageDB.global.showHUD == nil then EnrageDB.global.showHUD = false end
        if not EnrageDB.global.hudScale then EnrageDB.global.hudScale = 1.0 end
        -- Restore last loaded build from SavedVariables
        if EnrageDB.global.lastLoadedBuild then
            _G.Enrage_LastLoadedBuild = EnrageDB.global.lastLoadedBuild
        end
        ApplyHUDVisibility()
    elseif event == "ACTIVE_COMBAT_CONFIG_CHANGED" then
        -- TalentPanel owns Enrage_LastLoadedBuild persistence. HUD only redraws it.
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(0.5, UpdateHUD)
        end
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        -- TalentPanel clears/restores build tags after spec changes; HUD waits for APIs.
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(1.0, UpdateHUD)
            C_Timer.After(3.0, UpdateHUD)
        end
    elseif event == "TRAIT_CONFIG_UPDATED" or event == "TRAIT_CONFIG_LIST_UPDATED" then
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(0.5, UpdateHUD)
            C_Timer.After(1.5, UpdateHUD)
        end
    end
end)
