local _, addon = ...

-- Broadcast a CD cast to the group
function addon:BroadcastCast(spellID, effectiveCD, remaining)
    local channel = self:GetCommChannel()
    if channel then
        local payload = "C," .. spellID .. "," .. effectiveCD
        if remaining then
            payload = payload .. "," .. remaining
        end
        addon.Enrage:SendCommMessage(addon.COMM_PREFIX, payload, channel)
    end
end

-- Announce join / talent data to the group (never during combat)
function addon:SendJoin()
    if addon.inCombat then return end
    if not IsInGroup() and not IsInRaid() then return end

    local specIndex = GetSpecialization()
    local specID = specIndex and GetSpecializationInfo(specIndex) or 0

    local modParts = {}
    for spellID, info in pairs(addon.RaidCDData) do
        local known = addon.IsOwnTrackedSpellKnown and addon:IsOwnTrackedSpellKnown(spellID) or IsSpellKnown(spellID)
        if known then
            local actualCD = addon.GetOwnSpellCooldownDuration and addon:GetOwnSpellCooldownDuration(spellID, specID) or (addon.CDCache[spellID] or addon:GetSpecBasedCD(spellID, specID))
            table.insert(modParts, spellID .. ":" .. actualCD)
        end
    end

    local channel = self:GetCommChannel()
    if channel then
        addon.Enrage:SendCommMessage(addon.COMM_PREFIX, "J," .. specID .. "," .. table.concat(modParts, ","), channel)
    end
end

-- Announce leave
function addon:SendLeave()
    local channel = self:GetCommChannel()
    if channel then
        addon.Enrage:SendCommMessage(addon.COMM_PREFIX, "L", channel)
    end
end

-- Strip realm name from "Player-Realm" format
local function StripRealm(name)
    if not name then return name end
    return name:match("^([^%-]+)") or name
end

-- Incoming message handler
function addon.Enrage:OnCommReceived(prefix, message, distribution, sender)
    if prefix ~= addon.COMM_PREFIX then return end

    sender = StripRealm(sender)
    if sender == UnitName("player") then return end

    local msgType, rest = message:match("^(%a),?(.*)")
    if not msgType then return end

    if msgType == "C" then
        addon:HandleCastMessage(sender, rest)
    elseif msgType == "J" then
        addon:HandleJoinMessage(sender, rest)
    elseif msgType == "L" then
        addon:HandleLeaveMessage(sender)
    end
end

function addon:HandleCastMessage(sender, rest)
    local spellIDStr, effectiveCDStr, remainingStr = rest:match("^(%d+),(%d+%.?%d*),?(%d*%.?%d*)")
    if not spellIDStr then return end

    local spellID = tonumber(spellIDStr)
    local effectiveCD = tonumber(effectiveCDStr)
    local remaining = tonumber(remainingStr)
    if not spellID or not effectiveCD then return end
    spellID = addon.CanonicalizeSpellID and addon:CanonicalizeSpellID(spellID) or spellID
    if not addon.RaidCDData[spellID] then return end

    local senderClass = "UNKNOWN"
    local senderSpec = 0
    if addon.Roster[sender] then
        senderClass = addon.Roster[sender].class
        senderSpec = addon.Roster[sender].spec or 0
    else
        local unit = addon:GetUnitForName(sender)
        if unit then
            _, senderClass = UnitClass(unit)
        end
    end

    -- If the received cooldown equals baseCD, the sender may have been tainted
    -- in combat. Prefer the spec-specific value when available.
    local info = addon.RaidCDData[spellID]
    if effectiveCD == info.baseCD and info.specCD and senderSpec ~= 0 then
        local specCD = info.specCD[senderSpec]
        if specCD then
            effectiveCD = specCD
        end
    end

    addon:StartCooldown(sender, senderClass, spellID, effectiveCD, remaining)
end

local lastJoinResponse = 0 -- Spam guard for automatic Join responses.

function addon:HandleJoinMessage(sender, rest)
    local parts = { strsplit(",", rest) }
    local specID = tonumber(parts[1]) or 0

    local senderClass = "UNKNOWN"
    local unit = addon:GetUnitForName(sender)
    if unit then
        _, senderClass = UnitClass(unit)
    end

    local cdModifiers = {}
    for i = 2, #parts do
        local sid, cd = parts[i]:match("^(%d+):(%d+%.?%d*)")
        if sid and cd then
            cdModifiers[tonumber(sid)] = tonumber(cd)
        end
    end

    local isNew = (addon.Roster[sender] == nil)
    addon.Roster[sender] = {
        class       = senderClass,
        spec        = specID,
        cdModifiers = cdModifiers,
    }
    -- Roster data is authoritative; remove any inferred spec for this sender.
    addon.InferredSpecs[sender] = nil

    -- Correct cooldowns that were started from Tier 2 fallback with baseCD
    -- once authoritative CDR/spec data arrives through Join.
    local now = GetTime()
    for key, cd in pairs(addon.ActiveCooldowns) do
        if cd.playerName == sender then
            local trueCD = cdModifiers[cd.spellID]
            if trueCD and trueCD ~= cd.duration then
                local elapsed = cd.duration - (cd.expirationTime - now)
                if elapsed < 0 then elapsed = 0 end
                local newRemaining = trueCD - elapsed
                if newRemaining > 0 then
                    cd.duration       = trueCD
                    cd.expirationTime = now + newRemaining
                    cd.wallExpires    = time() + newRemaining
                else
                    addon.ActiveCooldowns[key] = nil
                end
            end
        end
    end
    addon:MarkPanelsDirty()

    -- If a new sender announces itself, answer with our Join data at most once
    -- every five seconds.
    if isNew and (now - lastJoinResponse > 5) then
        lastJoinResponse = now
        C_Timer.After(0.5, function()
            addon:SendJoin()
        end)
    end
end

function addon:HandleLeaveMessage(sender)
    addon.Roster[sender] = nil
    addon.InferredSpecs[sender] = nil
    for key in pairs(addon.ActiveCooldowns) do
        if key:find("^" .. sender .. "%-") then
            addon.ActiveCooldowns[key] = nil
        end
    end
    addon:MarkPanelsDirty()
end

function addon:GetCommChannel()
    local home = LE_PARTY_CATEGORY_HOME or 1
    local instance = LE_PARTY_CATEGORY_INSTANCE or 2

    if IsInRaid and IsInRaid(instance) and not IsInRaid(home) then
        return "INSTANCE_CHAT"
    elseif IsInGroup and IsInGroup(instance) and not IsInGroup(home) then
        return "INSTANCE_CHAT"
    elseif IsInRaid() then
        return "RAID"
    elseif IsInGroup() then
        return "PARTY"
    end
    return nil
end

function addon:GetUnitForName(name)
    if IsInRaid() then
        for i = 1, 40 do
            local unit = "raid" .. i
            if UnitExists(unit) and UnitName(unit) == name then
                return unit
            end
        end
    elseif IsInGroup() then
        for i = 1, 4 do
            local unit = "party" .. i
            if UnitExists(unit) and UnitName(unit) == name then
                return unit
            end
        end
    end
    return nil
end
