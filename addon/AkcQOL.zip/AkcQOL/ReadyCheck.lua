local _, addon = ...

local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"
local ICON_SIZE = 42
local ICON_SPACING = 8
local DEFAULT_Y_OFFSET = 150
local DEFAULT_FRAME_WIDTH = 520
local FRAME_HEIGHT = ICON_SIZE + 12
local ICON_TOP_INSET = 4
local READY_POPUP_GAP = 4

local ICONS = {
    food = "Interface\\Icons\\INV_Misc_Food_15",
    flask = "Interface\\Icons\\INV_Potion_83",
    augment = "Interface\\Icons\\INV_Misc_Rune_01",
    healthstone = "Interface\\Icons\\INV_Stone_04",
    weaponOil = "Interface\\Icons\\INV_Potion_93",
}

local helperFrame
local eventFrame
local updateQueued = false
local hideQueued = false
local hideToken = 0
local manuallyDismissed = false
local ScheduleUpdate
local RefreshReadyCheckFit
local GetReadyCheckPopup
local SavePosition

local function SafeString(value)
    if value == nil then return nil end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return nil end
    end
    local ok, text = pcall(tostring, value)
    if ok and text and text ~= "" then return text end
    return nil
end

local function Lower(value)
    value = SafeString(value) or ""
    return string.lower(value)
end

local function TextContainsAny(text, needles)
    text = text or ""
    for _, needle in ipairs(needles) do
        if text:find(needle, 1, true) then
            return true
        end
    end
    return false
end

local function GetDB()
    local profile = addon.Enrage and addon.Enrage.db and addon.Enrage.db.profile
    if not profile then return nil end

    profile.readyCheckHelper = profile.readyCheckHelper or {}
    local db = profile.readyCheckHelper
    if db.enabled == nil then db.enabled = false end
    if db.locked == nil then db.locked = false end
    db.point = db.point or "CENTER"
    db.relPoint = db.relPoint or "CENTER"
    db.xOfs = db.xOfs or 0
    db.yOfs = db.yOfs or DEFAULT_Y_OFFSET
    if db.iconBarMigrationV1 == nil then
        db.iconBarMigrationV1 = true
        if db.point == "CENTER" and db.relPoint == "CENTER" and (db.xOfs or 0) == 0 and (db.yOfs or DEFAULT_Y_OFFSET) == 210 then
            db.yOfs = DEFAULT_Y_OFFSET
        end
    end
    return db
end

local function PlayerHasAura(matchFn)
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 200 do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not aura then break end
            local auraName = SafeString(aura.name) or ""
            local spellID = aura.spellId or aura.spellID
            if matchFn(Lower(auraName), spellID, aura) then
                return true, auraName, aura.icon
            end
        end
        return false
    end

    local auraFn = UnitAura or UnitBuff
    if auraFn then
        for i = 1, 200 do
            local ok, name, icon, count, dispelType, duration, expirationTime, source, isStealable, nameplateShowPersonal, spellID = pcall(auraFn, "player", i, "HELPFUL")
            if not ok or not name then break end
            local auraName = SafeString(name) or ""
            if matchFn(Lower(auraName), spellID) then
                return true, auraName, icon
            end
        end
    end

    return false
end

local function GetItemIconTexture(itemID, fallback)
    if C_Item and C_Item.GetItemIconByID then
        local ok, icon = pcall(C_Item.GetItemIconByID, itemID)
        if ok and icon then return icon end
    end
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, itemInfoID, itemType, itemSubType, itemEquipLoc, icon = pcall(C_Item.GetItemInfoInstant, itemID)
        if ok and icon then return icon end
    end
    if GetItemIcon then
        local ok, icon = pcall(GetItemIcon, itemID)
        if ok and icon then return icon end
    end
    return fallback
end

local function GetBagUpperBound()
    local maxBag = NUM_BAG_SLOTS or 4
    if Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag then
        maxBag = math.max(maxBag, Enum.BagIndex.ReagentBag)
    end
    return maxBag
end

local function RequestItemInfo(itemID)
    if itemID and C_Item and C_Item.RequestLoadItemDataByID then
        pcall(C_Item.RequestLoadItemDataByID, itemID)
    end
end

local function GetNameFromLink(itemLink)
    itemLink = SafeString(itemLink)
    if not itemLink then return nil end
    local name = itemLink:match("%[(.-)%]")
    return name and name ~= "" and name or nil
end

local function GetItemDetails(itemID, itemLink)
    local query = itemLink or itemID
    if not query then return nil end

    local itemName, resolvedLink, itemType, itemSubType, itemTexture, classID, subclassID
    if C_Item and C_Item.GetItemInfo then
        local ok
        ok, itemName, resolvedLink, _, _, _, itemType, itemSubType, _, _, itemTexture, _, classID, subclassID = pcall(C_Item.GetItemInfo, query)
        if not ok then itemName = nil end
    end

    if not itemName and GetItemInfo then
        local ok
        ok, itemName, resolvedLink, _, _, _, itemType, itemSubType, _, _, itemTexture, _, classID, subclassID = pcall(GetItemInfo, query)
        if not ok then itemName = nil end
    end

    itemName = SafeString(itemName) or GetNameFromLink(itemLink)
    resolvedLink = SafeString(resolvedLink) or itemLink
    itemType = Lower(itemType)
    itemSubType = Lower(itemSubType)
    if not itemName then RequestItemInfo(itemID) end

    return {
        name = itemName,
        link = resolvedLink,
        itemType = itemType,
        itemSubType = itemSubType,
        icon = itemTexture,
        classID = classID,
        subclassID = subclassID,
    }
end

local function GetBagItem(bag, slot)
    local itemID, itemLink, itemIcon, count

    if C_Container and C_Container.GetContainerItemInfo then
        local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
        if ok and info then
            itemID = info.itemID
            itemLink = info.hyperlink
            itemIcon = info.iconFileID
            count = info.stackCount
        end
    elseif GetContainerItemInfo then
        local ok, icon, stackCount, _, _, _, link, _, _, _, legacyItemID = pcall(GetContainerItemInfo, bag, slot)
        if ok then
            itemID = legacyItemID
            itemLink = link
            itemIcon = icon
            count = stackCount
        end
    end

    itemLink = SafeString(itemLink)
    if not itemID and itemLink then
        itemID = tonumber(itemLink:match("item:(%d+)"))
    end
    if not itemID then return nil end

    local details = GetItemDetails(itemID, itemLink)
    local name = details and details.name
    local link = details and details.link
    local icon = itemIcon or (details and details.icon)

    return {
        bag = bag,
        slot = slot,
        itemID = itemID,
        link = link,
        name = name,
        nameLower = Lower(name),
        icon = icon,
        count = count or 1,
        itemType = details and details.itemType or "",
        itemSubType = details and details.itemSubType or "",
        classID = details and details.classID,
        subclassID = details and details.subclassID,
    }
end

local function FindBagItem(matchFn, scoreFn)
    local bestItem, bestScore
    local maxBag = GetBagUpperBound()

    for bag = 0, maxBag do
        local slots = 0
        if C_Container and C_Container.GetContainerNumSlots then
            local ok, numSlots = pcall(C_Container.GetContainerNumSlots, bag)
            slots = ok and numSlots or 0
        elseif GetContainerNumSlots then
            local ok, numSlots = pcall(GetContainerNumSlots, bag)
            slots = ok and numSlots or 0
        end

        for slot = 1, slots do
            local item = GetBagItem(bag, slot)
            if item and matchFn(item) then
                local score = scoreFn and scoreFn(item) or 1
                if not bestItem or score > bestScore then
                    bestItem = item
                    bestScore = score
                end
            end
        end
    end

    return bestItem
end

local function GetItemCountSafe(itemID)
    if C_Item and C_Item.GetItemCount then
        local ok, count = pcall(C_Item.GetItemCount, itemID, false, true)
        if ok and count and count > 0 then return count end
    end
    if GetItemCount then
        local ok, count = pcall(GetItemCount, itemID, false, true)
        if ok and count and count > 0 then return count end
    end
    return 0
end

local function IsConsumable(item)
    local consumableClass = LE_ITEM_CLASS_CONSUMABLE or (Enum and Enum.ItemClass and Enum.ItemClass.Consumable)
    return not consumableClass or item.classID == consumableClass
end

-- Reads a bag item's tooltip to decide whether it actually grants the "Well Fed"
-- stat buff. The food & drink subclass mixes real stat foods with plain mana/utility
-- drinks (e.g. Argentleaf Tea grants "Relaxed", not "Well Fed"), and individual food
-- names are arbitrary, so the tooltip is the only reliable signal.
-- Returns: grantsWellFed (true / false / nil-when-unreadable), statValue (number).
local function GetWellFedInfo(bag, slot)
    if bag == nil or slot == nil then return nil, 0 end
    if not (C_TooltipInfo and C_TooltipInfo.GetBagItem) then return nil, 0 end

    local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
    if not ok or type(data) ~= "table" or type(data.lines) ~= "table" then
        return nil, 0
    end

    local grants, statValue = false, 0
    for _, line in ipairs(data.lines) do
        local text = line and SafeString(line.leftText)
        if text then
            local lower = string.lower(text)
            if lower:find("well fed", 1, true) or lower:find("well-fed", 1, true) then
                grants = true
                -- Stat numbers carry thousands separators ("1,512"); strip a comma/space
                -- only when it sits between digits so each numeric token stays intact.
                local cleaned = text:gsub("(%d)[,%s](%d)", "%1%2"):gsub("(%d)[,%s](%d)", "%1%2")
                -- The stat magnitude is the largest number that is NOT a duration
                -- ("for 1 hour", "10 sec") — those would otherwise outrank the stat.
                for num, suffix in cleaned:gmatch("(%d+)%s*(%a*)") do
                    local unit = string.lower(suffix)
                    local isDuration = unit == "sec" or unit == "secs" or unit == "second" or unit == "seconds"
                        or unit == "min" or unit == "mins" or unit == "minute" or unit == "minutes"
                        or unit == "hr" or unit == "hrs" or unit == "hour" or unit == "hours"
                    if not isDuration then
                        local n = tonumber(num)
                        if n and n > statValue then statValue = n end
                    end
                end
            end
        end
    end
    return grants, statValue
end

local function IsFoodItem(item)
    local foodSubclass = LE_ITEM_CONSUMABLE_FOOD_AND_DRINK
    if IsConsumable(item) and foodSubclass and item.subclassID == foodSubclass then
        return true
    end
    if IsConsumable(item) and TextContainsAny(item.itemSubType, { "food", "drink" }) then
        return true
    end
    return TextContainsAny(item.nameLower, { "feast", "banquet", "hearty", "meal" })
end

local function FoodScore(item)
    local grants, statValue = GetWellFedInfo(item.bag, item.slot)
    item.wellFedGrants = grants -- cached so the post-selection guard reuses this read
    local score
    if grants == true then
        -- Confirmed stat food: dominates everything, ranked by stat magnitude.
        score = 1000 + (statValue or 0)
    elseif grants == false then
        -- Tooltip read fine but no Well Fed line: mana/utility drink (tea, water,
        -- conjured refreshment). Keep it only as an absolute last resort.
        score = -1000
    else
        -- Tooltip not ready yet: fall back to the old name heuristics.
        score = 1
    end
    if TextContainsAny(item.nameLower, { "feast", "banquet" }) then score = score + 200 end
    if TextContainsAny(item.nameLower, { "hearty", "meal", "bounty" }) then score = score + 50 end
    if TextContainsAny(item.nameLower, { "tea", "water", "conjured", "refreshment", "sparkling", "soda", "cola", "juice", "coffee", "milk" }) then
        score = score - 30
    end
    return score
end

local function IsFlaskOrPhialItem(item)
    return IsConsumable(item) and TextContainsAny(item.nameLower, { "flask", "phial" })
end

local function IsAugmentRuneItem(item)
    return IsConsumable(item) and TextContainsAny(item.nameLower, {
        "augment rune",
        "crystallized augment",
        "draconic augment",
        "void-touched",
        "void touched",
    })
end

local function IsWeaponOilItem(item)
    if not IsConsumable(item) or IsAugmentRuneItem(item) then return false end
    if item.nameLower:match("^oil ") or item.nameLower:match(" oil ") or item.nameLower:match(" oil$") then
        return true
    end
    return TextContainsAny(item.nameLower, {
        "thalassian phoenix oil",
        "phoenix oil",
        "mana oil",
        "wizard oil",
        "weapon oil",
        "sharpening stone",
        "weightstone",
        "whetstone",
        "buzzing rune",
        "howling rune",
        "hissing rune",
        "chirping rune",
    })
end

local function GetBagSlotItemReference(item)
    if not item then return nil end
    if item.bag ~= nil and item.slot ~= nil then
        return tostring(item.bag) .. " " .. tostring(item.slot)
    end
    return item.name or item.link
end

local function GetItemDisplayName(item)
    if not item then return nil end
    return item.name or (item.itemID and ("item:" .. tostring(item.itemID))) or "item"
end

local function GetEquippedItemEquipLoc(slotID)
    local link = GetInventoryItemLink and GetInventoryItemLink("player", slotID)
    if not link then return nil end

    local equipLoc
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, itemID, itemType, itemSubType, loc = pcall(C_Item.GetItemInfoInstant, link)
        if ok then equipLoc = loc end
    elseif GetItemInfoInstant then
        local ok, itemID, itemType, itemSubType, loc = pcall(GetItemInfoInstant, link)
        if ok then equipLoc = loc end
    end

    return SafeString(equipLoc)
end

local function IsEquippedOffhandWeapon()
    local offHandSlot = INVSLOT_OFFHAND or 17
    local equipLoc = GetEquippedItemEquipLoc(offHandSlot)
    return equipLoc == "INVTYPE_WEAPON" or equipLoc == "INVTYPE_WEAPONOFFHAND"
end

local function GetWeaponEnchantStatus()
    local mainHandSlot = INVSLOT_MAINHAND or 16
    local offHandSlot = INVSLOT_OFFHAND or 17
    local hasMainHandItem = GetInventoryItemLink and GetInventoryItemLink("player", mainHandSlot) ~= nil
    local offhandIsWeapon = IsEquippedOffhandWeapon()
    local hasMainHandEnchant, hasOffHandEnchant = false, false

    if GetWeaponEnchantInfo then
        local ok, mainEnchant, mainExpiration, mainCharges, mainEnchantID, offEnchant = pcall(GetWeaponEnchantInfo)
        if ok then
            hasMainHandEnchant = mainEnchant and true or false
            hasOffHandEnchant = offEnchant and true or false
        end
    end

    return {
        mainHandSlot = mainHandSlot,
        offHandSlot = offHandSlot,
        hasMainHandItem = hasMainHandItem,
        offhandIsWeapon = offhandIsWeapon,
        hasMainHandEnchant = hasMainHandEnchant,
        hasOffHandEnchant = hasOffHandEnchant,
    }
end

local function GetWeaponSlotText(slotID)
    if slotID == (INVSLOT_OFFHAND or 17) then
        return "off hand"
    end
    return "main hand"
end

local function BuildWeaponOilState(label, slotID, ready, oilItem)
    local actionItem = oilItem
    local slotText = GetWeaponSlotText(slotID)
    local missingDetail = oilItem and ("No temporary weapon enchant on " .. slotText .. ". Click to apply " .. GetItemDisplayName(oilItem) .. ".") or ("No temporary weapon enchant on " .. slotText .. " and no weapon oil/rune found in bags.")
    local actionVerb = ready and "Reapply" or "Apply"

    return {
        label = label,
        ready = ready,
        detail = ready and ("Temporary weapon enchant detected on " .. slotText .. ".") or missingDetail,
        icon = (oilItem and oilItem.icon) or ICONS.weaponOil,
        actionExpected = not ready,
        clickWhenReady = true,
        actionItem = GetBagSlotItemReference(actionItem),
        actionBag = actionItem and actionItem.bag or nil,
        actionSlot = actionItem and actionItem.slot or nil,
        actionTargetSlot = actionItem and slotID or nil,
        actionText = actionItem and ("Click: " .. actionVerb .. " " .. GetItemDisplayName(actionItem) .. " to " .. slotText) or nil,
        actionBinding = actionItem and (GetBagSlotItemReference(actionItem) .. " -> " .. tostring(slotID)) or nil,
    }
end

local function CanChangeSecureAttributes()
    return not (InCombatLockdown and InCombatLockdown())
end

local function GroupHasWarlock()
    if not ((IsInGroup and IsInGroup()) or (IsInRaid and IsInRaid())) then
        return false
    end

    local function UnitIsWarlock(unit)
        if not (UnitExists and UnitExists(unit) and UnitClass) then return false end
        local ok, localizedClass, classFile = pcall(UnitClass, unit)
        return ok and classFile == "WARLOCK"
    end

    if UnitIsWarlock("player") then return true end

    if IsInRaid and IsInRaid() then
        local count = (GetNumGroupMembers and GetNumGroupMembers()) or 0
        for i = 1, count do
            if UnitIsWarlock("raid" .. i) then return true end
        end
    elseif IsInGroup and IsInGroup() then
        for i = 1, 4 do
            if UnitIsWarlock("party" .. i) then return true end
        end
    end

    return false
end

local function HasFoodBuff()
    return PlayerHasAura(function(name)
        return TextContainsAny(name, { "well fed", "well-fed", "hearty meal" })
    end)
end

local function HasFlaskOrPhial()
    return PlayerHasAura(function(name)
        return TextContainsAny(name, { "flask", "phial" })
    end)
end

local function HasAugmentRune()
    return PlayerHasAura(function(name)
        return TextContainsAny(name, { "augment rune", "crystallized augment", "draconic augment", "augmented", "void-touched", "void touched" })
    end)
end

local function GetStates()
    local foodReady, foodName, foodIcon = HasFoodBuff()
    local flaskReady, flaskName, flaskIcon = HasFlaskOrPhial()
    local augmentReady, augmentName, augmentIcon = HasAugmentRune()
    local foodItem = FindBagItem(IsFoodItem, FoodScore)
    -- Never recommend an item we can positively confirm does NOT grant Well Fed
    -- (e.g. Argentleaf Tea / mana drinks). nil means tooltip unreadable -> keep it.
    if foodItem and foodItem.wellFedGrants == false then
        foodItem = nil
    end
    local flaskItem = FindBagItem(IsFlaskOrPhialItem)
    local augmentItem = FindBagItem(IsAugmentRuneItem)
    local oilItem = FindBagItem(IsWeaponOilItem)
    local oilStatus = GetWeaponEnchantStatus()
    local foodActionItem = not foodReady and foodItem or nil
    local flaskActionItem = not flaskReady and flaskItem or nil
    local augmentActionItem = not augmentReady and augmentItem or nil

    local states = {
        {
            label = "Food Buff",
            ready = foodReady,
            detail = foodName or (foodItem and ("No Well Fed buff detected. Click to use " .. GetItemDisplayName(foodItem) .. ".") or "No Well Fed buff detected and no food found in bags."),
            icon = foodIcon or (foodItem and foodItem.icon) or ICONS.food,
            actionExpected = not foodReady,
            actionItem = GetBagSlotItemReference(foodActionItem),
            actionBag = foodActionItem and foodActionItem.bag or nil,
            actionSlot = foodActionItem and foodActionItem.slot or nil,
            actionText = foodActionItem and ("Click: Use " .. GetItemDisplayName(foodActionItem)) or nil,
            actionBinding = foodActionItem and GetBagSlotItemReference(foodActionItem) or nil,
        },
        {
            label = "Flask / Phial",
            ready = flaskReady,
            detail = flaskName or (flaskItem and ("No flask or phial aura detected. Click to use " .. GetItemDisplayName(flaskItem) .. ".") or "No flask or phial aura detected and no flask/phial found in bags."),
            icon = flaskIcon or (flaskItem and flaskItem.icon) or ICONS.flask,
            actionExpected = not flaskReady,
            actionItem = GetBagSlotItemReference(flaskActionItem),
            actionBag = flaskActionItem and flaskActionItem.bag or nil,
            actionSlot = flaskActionItem and flaskActionItem.slot or nil,
            actionText = flaskActionItem and ("Click: Use " .. GetItemDisplayName(flaskActionItem)) or nil,
            actionBinding = flaskActionItem and GetBagSlotItemReference(flaskActionItem) or nil,
        },
        {
            label = "Augment Rune",
            ready = augmentReady,
            detail = augmentName or (augmentItem and ("No augment rune aura detected. Click to use " .. GetItemDisplayName(augmentItem) .. ".") or "No augment rune aura detected and no augment rune found in bags."),
            icon = augmentIcon or (augmentItem and augmentItem.icon) or GetItemIconTexture(259085, ICONS.augment),
            actionExpected = not augmentReady,
            actionItem = GetBagSlotItemReference(augmentActionItem),
            actionBag = augmentActionItem and augmentActionItem.bag or nil,
            actionSlot = augmentActionItem and augmentActionItem.slot or nil,
            actionText = augmentActionItem and ("Click: Use " .. GetItemDisplayName(augmentActionItem)) or nil,
            actionBinding = augmentActionItem and GetBagSlotItemReference(augmentActionItem) or nil,
        },
    }

    if GroupHasWarlock() then
        local count = GetItemCountSafe(5512)
        table.insert(states, {
            label = "Healthstone",
            ready = count > 0,
            detail = count > 0 and (count .. " in bags.") or "Warlock in group, no Healthstone found.",
            icon = GetItemIconTexture(5512, ICONS.healthstone),
        })
    end

    if oilStatus.offhandIsWeapon then
        table.insert(states, BuildWeaponOilState("Main Hand Oil", oilStatus.mainHandSlot, (not oilStatus.hasMainHandItem) or oilStatus.hasMainHandEnchant, oilItem))
        table.insert(states, BuildWeaponOilState("Off Hand Oil", oilStatus.offHandSlot, oilStatus.hasOffHandEnchant, oilItem))
    else
        table.insert(states, BuildWeaponOilState("Weapon Oil", oilStatus.mainHandSlot, (not oilStatus.hasMainHandItem) or oilStatus.hasMainHandEnchant, oilItem))
    end

    return states
end

local function CreateRow(index)
    local row = CreateFrame("Button", "EnrageReadyCheckItemButton" .. index, helperFrame, "SecureActionButtonTemplate")
    row:SetSize(ICON_SIZE, ICON_SIZE)
    row:SetFrameLevel(helperFrame:GetFrameLevel() + 20)
    row:EnableMouse(true)
    if row.SetMouseClickEnabled then row:SetMouseClickEnabled(true) end
    row:RegisterForClicks("LeftButtonUp")
    row:RegisterForDrag("LeftButton")
    row:SetAttribute("useOnKeyDown", false)
    row:SetHighlightTexture(FLAT_TEX)
    row:GetHighlightTexture():SetVertexColor(1.00, 0.82, 0.25, 0.18)

    row.border = row:CreateTexture(nil, "BACKGROUND")
    row.border:SetTexture(FLAT_TEX)
    row.border:SetAllPoints()

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetTexture(FLAT_TEX)
    row.bg:SetPoint("TOPLEFT", row, "TOPLEFT", 2, -2)
    row.bg:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -2, 2)

    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetPoint("TOPLEFT", row, "TOPLEFT", 5, -5)
    row.icon:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -5, 5)
    row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    row.missingShade = row:CreateTexture(nil, "OVERLAY")
    row.missingShade:SetTexture(FLAT_TEX)
    row.missingShade:SetDrawLayer("OVERLAY", 1)
    row.missingShade:SetPoint("TOPLEFT", row.icon, "TOPLEFT", 0, 0)
    row.missingShade:SetPoint("BOTTOMRIGHT", row.icon, "BOTTOMRIGHT", 0, 0)

    row.statusIcon = row:CreateTexture(nil, "OVERLAY")
    row.statusIcon:SetDrawLayer("OVERLAY", 7)
    row.statusIcon:SetSize(23, 23)
    row.statusIcon:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 3, -3)

    row:SetScript("OnEnter", function(self)
        if not self.tooltipTitle then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.tooltipTitle, 1.0, 0.82, 0.25)
        if self.tooltipStatus and self.tooltipStatus ~= "" then
            GameTooltip:AddLine(self.tooltipStatus, self.tooltipReady and 0.30 or 1.00, self.tooltipReady and 0.90 or 0.45, self.tooltipReady and 0.50 or 0.35)
        end
        if self.tooltipText and self.tooltipText ~= "" then
            GameTooltip:AddLine(self.tooltipText, 0.86, 0.88, 0.94, true)
        end
        if self.tooltipClick and self.tooltipClick ~= "" then
            GameTooltip:AddLine(self.tooltipClick, 0.35, 0.74, 1.00, true)
            if self.tooltipBinding and self.tooltipBinding ~= "" then
                GameTooltip:AddLine("Bag slot: " .. self.tooltipBinding, 0.55, 0.60, 0.68, true)
            end
        elseif self.tooltipNoItem and self.tooltipNoItem ~= "" then
            GameTooltip:AddLine(self.tooltipNoItem, 1.00, 0.50, 0.36, true)
        end
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    row:SetScript("OnDragStart", function(self)
        local db = GetDB()
        if not db or db.locked or GetReadyCheckPopup() then return end
        self.dragSuppressUntil = GetTime() + 0.25
        GameTooltip:Hide()
        helperFrame:StartMoving()
    end)
    row:SetScript("OnDragStop", function(self)
        self.dragSuppressUntil = GetTime() + 0.25
        helperFrame:StopMovingOrSizing()
        if SavePosition then SavePosition() end
    end)
    row:SetScript("PostClick", function(self, button)
        if button ~= "LeftButton" then return end
        if not self.tooltipTitle then return end
        if self.dragSuppressUntil and GetTime() < self.dragSuppressUntil then return end
        if not self.secureActionItem then
            if self.tooltipNoItem then
                print("|cff00ccffEnrage:|r No usable item found for " .. self.tooltipTitle .. ".")
            end
            return
        end
        if C_Timer and C_Timer.After then
            C_Timer.After(0.2, ScheduleUpdate)
            C_Timer.After(0.8, ScheduleUpdate)
            C_Timer.After(1.5, ScheduleUpdate)
        else
            ScheduleUpdate()
        end
    end)

    helperFrame.rows[index] = row
    return row
end

local function SetRowClickEnabled(row, enabled)
    if not row then return end
    if row.SetMouseMotionEnabled then pcall(row.SetMouseMotionEnabled, row, true) end
    if row.SetMouseClickEnabled then pcall(row.SetMouseClickEnabled, row, true) end
    if row.RegisterForClicks then
        if enabled then
            pcall(row.RegisterForClicks, row, "LeftButtonUp")
        else
            pcall(row.RegisterForClicks, row)
        end
    end
end

local function SetRowAction(row, state)
    row.tooltipClick = state.actionText
    row.tooltipBinding = state.actionBinding
    row.tooltipNoItem = (state.actionExpected and not state.actionItem) and "No usable item found in bags." or nil
    row.secureActionItem = state.actionItem
    row.actionBag = state.actionBag
    row.actionSlot = state.actionSlot
    row.actionTargetSlot = state.actionTargetSlot

    if not CanChangeSecureAttributes() then
        return
    end

    row:SetAttribute("type", nil)
    row:SetAttribute("type1", nil)
    row:SetAttribute("*type1", nil)
    row:SetAttribute("item", nil)
    row:SetAttribute("item1", nil)
    row:SetAttribute("*item1", nil)
    row:SetAttribute("unit", nil)
    row:SetAttribute("unit1", nil)
    row:SetAttribute("*unit1", nil)
    row:SetAttribute("target-bag", nil)
    row:SetAttribute("target-slot", nil)
    row:SetAttribute("target-item", nil)
    row:SetAttribute("target-slot1", nil)
    row:SetAttribute("*target-slot1", nil)
    row:SetAttribute("macro", nil)
    row:SetAttribute("macrotext", nil)
    row:SetAttribute("macrotext1", nil)
    row:SetAttribute("*macrotext1", nil)

    if state.actionItem then
        row:SetAttribute("type", "item")
        row:SetAttribute("type1", "item")
        row:SetAttribute("*type1", "item")
        row:SetAttribute("item", state.actionItem)
        row:SetAttribute("item1", state.actionItem)
        row:SetAttribute("*item1", state.actionItem)
        row:SetAttribute("unit", "player")
        row:SetAttribute("unit1", "player")
        row:SetAttribute("*unit1", "player")
        if state.actionTargetSlot then
            row:SetAttribute("target-slot", state.actionTargetSlot)
            row:SetAttribute("target-slot1", state.actionTargetSlot)
            row:SetAttribute("*target-slot1", state.actionTargetSlot)
        end
    end

    SetRowClickEnabled(row, (not state.ready) or (state.clickWhenReady and state.actionItem))
end

local function SetRow(row, state)
    row.icon:SetTexture(state.icon or ICONS.food)
    row.tooltipTitle = state.label
    row.tooltipText = state.detail or ""
    row.tooltipReady = state.ready and true or false
    row.tooltipStatus = state.ready and "OK" or "Missing"
    SetRowAction(row, state)

    if state.ready then
        row.statusIcon:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
        row.statusIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        row.statusIcon:SetBlendMode("BLEND")
        row.statusIcon:SetVertexColor(0.15, 1.00, 0.08, 1)
        row.statusIcon:Show()
        row.border:SetVertexColor(0.30, 0.90, 0.50, 0.92)
        row.bg:SetVertexColor(0.035, 0.120, 0.070, 0.94)
        row.missingShade:SetVertexColor(0.00, 0.00, 0.00, 0.00)
    else
        row.statusIcon:SetTexture("Interface\\RAIDFRAME\\ReadyCheck-NotReady")
        row.statusIcon:SetTexCoord(0, 1, 0, 1)
        row.statusIcon:SetBlendMode("BLEND")
        row.statusIcon:SetVertexColor(1.00, 0.12, 0.05, 1)
        row.statusIcon:Show()
        row.border:SetVertexColor(1.00, 0.35, 0.30, 0.94)
        row.bg:SetVertexColor(0.180, 0.045, 0.040, 0.96)
        row.missingShade:SetVertexColor(0.00, 0.00, 0.00, 0.52)
    end
end

local function FrameIsShown(frame)
    if not frame or type(frame.IsShown) ~= "function" then return false end
    local ok, shown = pcall(frame.IsShown, frame)
    return ok and shown == true
end

local function GetFrameWidthSafe(frame)
    if not frame or type(frame.GetWidth) ~= "function" then return nil end
    local ok, width = pcall(frame.GetWidth, frame)
    if ok and type(width) == "number" and width > 0 then return width end
    return nil
end

local function TextLooksLikeReadyCheck(text)
    text = Lower(text)
    return text:find("ready", 1, true) and text:find("check", 1, true)
end

local function IsReadyCheckPopup(frame)
    if not FrameIsShown(frame) then return false end

    local which = SafeString(frame.which)
    if which and TextLooksLikeReadyCheck(which) then return true end

    local textFrame = frame.Text or frame.text
    if not textFrame and frame.GetTextFontString then
        local ok, result = pcall(frame.GetTextFontString, frame)
        if ok then textFrame = result end
    end

    local text
    if textFrame and textFrame.GetText then
        local ok, result = pcall(textFrame.GetText, textFrame)
        if ok then text = SafeString(result) end
    end
    return text and TextLooksLikeReadyCheck(text)
end

function GetReadyCheckPopup()
    if StaticPopup_Visible then
        for _, popupID in ipairs({ "READY_CHECK", "READY_CHECK_CONFIRM", "CONFIRM_READY_CHECK" }) do
            local ok, frame = pcall(StaticPopup_Visible, popupID)
            if ok and IsReadyCheckPopup(frame) then return frame end
        end
    end

    if type(StaticPopup_DisplayedFrames) == "table" then
        for _, frame in ipairs(StaticPopup_DisplayedFrames) do
            if IsReadyCheckPopup(frame) then return frame end
        end
    end

    for i = 1, 4 do
        local frame = _G["StaticPopup" .. i]
        if IsReadyCheckPopup(frame) then return frame end
    end

    return nil
end

local function GetReadyCheckFitWidth(contentWidth)
    local width = math.max(contentWidth, ICON_SIZE)

    local parentWidth
    if UIParent and UIParent.GetWidth then
        local ok, width = pcall(UIParent.GetWidth, UIParent)
        if ok then parentWidth = width end
    end
    if parentWidth and parentWidth > 80 then
        width = math.min(width, parentWidth - 40)
    end

    return width, GetReadyCheckPopup()
end

local function PositionFrame()
    local db = GetDB()
    if not db or not helperFrame then return end

    helperFrame:ClearAllPoints()
    local popup = GetReadyCheckPopup()
    if popup then
        helperFrame:SetPoint("BOTTOM", popup, "TOP", 0, READY_POPUP_GAP)
        return
    end

    helperFrame:SetPoint(db.point, UIParent, db.relPoint, db.xOfs, db.yOfs)
end

function SavePosition()
    local db = GetDB()
    if not db or not helperFrame then return end

    local point, _, relPoint, xOfs, yOfs = helperFrame:GetPoint()
    db.point = point or "CENTER"
    db.relPoint = relPoint or "CENTER"
    db.xOfs = xOfs or 0
    db.yOfs = yOfs or DEFAULT_Y_OFFSET
end

local function EnsureFrame()
    if helperFrame then return helperFrame end

    local f = CreateFrame("Frame", "EnrageReadyCheckHelperFrame", UIParent, "BackdropTemplate")
    f:SetSize(DEFAULT_FRAME_WIDTH, FRAME_HEIGHT)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(900)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(false)
    f:SetBackdrop({
        bgFile = FLAT_TEX,
        edgeFile = FLAT_TEX,
        edgeSize = 1,
    })
    f:SetBackdropColor(0.018, 0.020, 0.024, 0.00)
    f:SetBackdropBorderColor(0.96, 0.62, 0.04, 0.00)
    f.rows = {}
    f:Hide()

    local header = f:CreateTexture(nil, "BACKGROUND")
    header:SetTexture(FLAT_TEX)
    header:SetVertexColor(0.060, 0.064, 0.076, 0.98)
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(38)
    header:Hide()

    local accent = f:CreateTexture(nil, "ARTWORK")
    accent:SetTexture(FLAT_TEX)
    accent:SetVertexColor(0.96, 0.62, 0.04, 0.95)
    accent:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -39)
    accent:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -39)
    accent:SetHeight(1)
    accent:Hide()

    local title = f:CreateFontString(nil, "OVERLAY")
    title:SetFont(FONT_FACE, 14, FONT_FLAGS)
    title:SetPoint("TOPLEFT", f, "TOPLEFT", 14, -11)
    title:SetText("|cFFF59E0BReady|r |cFFE5E7EBCheck|r")
    title:Hide()
    f.title = title

    local summary = f:CreateFontString(nil, "OVERLAY")
    summary:SetFont(FONT_FACE, 12, FONT_FLAGS)
    summary:SetPoint("TOPRIGHT", f, "TOPRIGHT", -44, -12)
    summary:SetTextColor(0.86, 0.88, 0.94, 1)
    summary:Hide()
    f.summary = summary

    local closeButton = CreateFrame("Button", nil, f)
    closeButton:SetSize(20, 20)
    -- Keep the dismiss control outside the icon footprint so it never covers
    -- the final consumable icon or its ready/missing marker.
    closeButton:SetPoint("LEFT", f, "RIGHT", 4, 0)
    closeButton:SetHitRectInsets(-2, -2, -2, -2)

    closeButton.bg = closeButton:CreateTexture(nil, "BACKGROUND")
    closeButton.bg:SetTexture(FLAT_TEX)
    closeButton.bg:SetAllPoints()
    closeButton.bg:SetVertexColor(0.16, 0.02, 0.02, 0.90)

    closeButton.text = closeButton:CreateFontString(nil, "OVERLAY")
    closeButton.text:SetFont(FONT_FACE, 13, FONT_FLAGS)
    closeButton.text:SetAllPoints()
    closeButton.text:SetJustifyH("CENTER")
    closeButton.text:SetJustifyV("MIDDLE")
    closeButton.text:SetTextColor(0.96, 0.34, 0.32, 1)
    closeButton.text:SetText("X")

    closeButton:SetScript("OnClick", function()
        addon:DismissReadyCheckHelper()
    end)
    closeButton:SetScript("OnEnter", function(self)
        self.bg:SetVertexColor(0.34, 0.06, 0.06, 0.92)
        self.text:SetTextColor(1.00, 0.52, 0.48, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Close", 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    closeButton:SetScript("OnLeave", function(self)
        self.bg:SetVertexColor(0.16, 0.02, 0.02, 0.90)
        self.text:SetTextColor(0.96, 0.34, 0.32, 1)
        GameTooltip:Hide()
    end)
    closeButton:Hide()
    f.closeButton = closeButton

    local footer = f:CreateFontString(nil, "OVERLAY")
    footer:SetFont(FONT_FACE, 10, FONT_FLAGS)
    footer:SetPoint("BOTTOM", f, "BOTTOM", 0, 9)
    footer:SetTextColor(0.65, 0.70, 0.78, 1)
    footer:Hide()
    f.footer = footer

    helperFrame = f
    addon:UpdateReadyCheckHelperLock()
    PositionFrame()
    return f
end

function addon:UpdateReadyCheckHelperLock()
    if not helperFrame then return end
    helperFrame.footer:SetText("")
end

function addon:UpdateReadyCheckHelper()
    if not CanChangeSecureAttributes() then return end

    local f = EnsureFrame()
    local states = GetStates()
    local readyCount = 0
    local contentWidth = (#states * ICON_SIZE) + (math.max(#states - 1, 0) * ICON_SPACING)
    local frameWidth = GetReadyCheckFitWidth(contentWidth)
    local startX = math.floor((frameWidth - contentWidth) / 2)
    if startX < 0 then startX = 0 end

    f:SetWidth(frameWidth)
    PositionFrame()

    for i, state in ipairs(states) do
        local row = f.rows[i] or CreateRow(i)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", f, "TOPLEFT", startX + ((i - 1) * (ICON_SIZE + ICON_SPACING)), -ICON_TOP_INSET)
        SetRow(row, state)
        row:Show()
        if state.ready then readyCount = readyCount + 1 end
    end

    for i = #states + 1, #f.rows do
        f.rows[i]:Hide()
    end

    f.summary:SetText(string.format("%d/%d", readyCount, #states))
    if readyCount == #states then
        f.summary:SetTextColor(0.30, 0.90, 0.50, 1)
        f:SetBackdropBorderColor(0.30, 0.90, 0.50, 0.00)
    else
        f.summary:SetTextColor(1.00, 0.45, 0.35, 1)
        f:SetBackdropBorderColor(0.96, 0.62, 0.04, 0.00)
    end

    if f.closeButton then
        f.closeButton:Show()
    end

    f:SetHeight(FRAME_HEIGHT)
end

RefreshReadyCheckFit = function()
    if not helperFrame or not helperFrame:IsShown() then return end
    addon:UpdateReadyCheckHelper()
end

local function QueueReadyCheckFitRefresh()
    if not C_Timer or not C_Timer.After then
        RefreshReadyCheckFit()
        return
    end

    C_Timer.After(0.05, RefreshReadyCheckFit)
    C_Timer.After(0.20, RefreshReadyCheckFit)
    C_Timer.After(0.50, RefreshReadyCheckFit)
end

function addon:HideReadyCheckHelper()
    hideToken = hideToken + 1
    if helperFrame then
        if not CanChangeSecureAttributes() then
            hideQueued = true
            return
        end
        hideQueued = false
        helperFrame:Hide()
    end
end

function addon:DismissReadyCheckHelper()
    manuallyDismissed = true
    addon:HideReadyCheckHelper()
end

function addon:ShowReadyCheckHelper(duration, force)
    local db = GetDB()
    if not db or (not force and db.enabled == false) then return end
    if not CanChangeSecureAttributes() then return end

    -- A new ready check or an explicit test is a new display session. Manual
    -- dismissal only suppresses the current one.
    manuallyDismissed = false
    hideToken = hideToken + 1
    local token = hideToken

    EnsureFrame()
    PositionFrame()
    addon:UpdateReadyCheckHelper()
    helperFrame:Show()
    QueueReadyCheckFitRefresh()

    if duration and duration > 0 and C_Timer and C_Timer.After then
        C_Timer.After(math.min(duration + 1, 45), function()
            if token == hideToken then
                addon:HideReadyCheckHelper()
            end
        end)
    end
end

ScheduleUpdate = function()
    if manuallyDismissed or updateQueued or not (helperFrame and helperFrame:IsShown()) then return end
    updateQueued = true

    if C_Timer and C_Timer.After then
        C_Timer.After(0.12, function()
            updateQueued = false
            if helperFrame and helperFrame:IsShown() then
                addon:UpdateReadyCheckHelper()
            end
        end)
    else
        updateQueued = false
        addon:UpdateReadyCheckHelper()
    end
end

function addon:TestReadyCheckHelper()
    addon:ShowReadyCheckHelper(10, true)
end

function addon:ResetReadyCheckHelperPosition()
    local db = GetDB()
    if not db then return end
    db.point = "CENTER"
    db.relPoint = "CENTER"
    db.xOfs = 0
    db.yOfs = DEFAULT_Y_OFFSET
    if helperFrame then
        PositionFrame()
    end
end

function addon:InitializeReadyCheckHelper()
    EnsureFrame()

    if not eventFrame then
        eventFrame = CreateFrame("Frame", "EnrageReadyCheckHelperEventFrame")
        eventFrame:SetScript("OnEvent", function(_, event, arg1, arg2)
            if event == "READY_CHECK" then
                addon:ShowReadyCheckHelper(arg2)
            elseif event == "READY_CHECK_FINISHED" then
                manuallyDismissed = false
                addon:HideReadyCheckHelper()
            elseif event == "UNIT_AURA" then
                if arg1 == "player" then ScheduleUpdate() end
            elseif event == "UNIT_INVENTORY_CHANGED" then
                if arg1 == "player" then ScheduleUpdate() end
            elseif event == "PLAYER_REGEN_ENABLED" then
                if hideQueued then
                    addon:HideReadyCheckHelper()
                else
                    ScheduleUpdate()
                end
            else
                ScheduleUpdate()
            end
        end)
    end

    eventFrame:UnregisterAllEvents()
    eventFrame:RegisterEvent("READY_CHECK")
    eventFrame:RegisterEvent("READY_CHECK_FINISHED")
    eventFrame:RegisterEvent("UNIT_AURA")
    eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
    eventFrame:RegisterEvent("UNIT_INVENTORY_CHANGED")
    eventFrame:RegisterEvent("GET_ITEM_INFO_RECEIVED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
end

function addon:DisableReadyCheckHelper()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
    end
    addon:HideReadyCheckHelper()
end
