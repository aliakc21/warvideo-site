-- =========================================================================
-- ENRAGE TALENT PANEL
-- Left: M+ Dungeon builds | Right: Raid Boss builds
-- Source: WarcraftLogs Top 100
-- =========================================================================

local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local FONT_FACE = "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"
local PANEL_WIDTH = 170
local ROW_HEIGHT = 42
local HEADER_HEIGHT = 78  -- increased to fit tab bar (title 22 + tabs 18 + subtitle/spec 30 + padding)

-- M+ Dungeon boss route data (Midnight Season 1)
-- Cumulative enemy forces % you should have before each boss
_G.ENRAGE_DUNGEON_ROUTE_DATA = {
    ["Windrunner Spire"] = {
        { boss = "Emberdawn",               pct = 45.35 },
        { boss = "Derelict Duo",            pct = 57.36 },
        { boss = "Commander Kroluk",        pct = 100 },
        { boss = "The Restless Heart",      pct = 100 },
    },
    ["Magisters' Terrace"] = {
        { boss = "Arcanotron Custos",       pct = 27.81 },
        { boss = "Seranel Sunlash",         pct = 48.91 },
        { boss = "Gemellus",                pct = 78.06 },
        { boss = "Degentrius",              pct = 100 },
    },
    ["Nexus-Point Xenas"] = {
        { boss = "Chief Corewright Kasreth", pct = 29.36 },
        { boss = "Corewarden Nysarra",      pct = 73.66 },
        { boss = "Lothraxion",              pct = 100 },
    },
    ["Maisara Caverns"] = {
        { boss = "Muro'jin & Nekraxx",      pct = 48.60 },
        { boss = "Vordaza",                 pct = 89.95 },
        { boss = "Rak'tul",                 pct = 100 },
    },
    ["Algeth'ar Academy"] = {
        { boss = "Overgrown Ancient",       pct = 0 },
        { boss = "Crawth",                  pct = 21.52 },
        { boss = "Vexamus",                 pct = 72.61 },
        { boss = "Echo of Doragosa",        pct = 100 },
    },
    ["Seat of the Triumvirate"] = {
        { boss = "Zuraal the Ascended",     pct = 14.61 },
        { boss = "Saprish",                 pct = 56.87 },
        { boss = "Viceroy Nezhar",          pct = 100 },
        { boss = "L'ura",                   pct = 100 },
    },
    ["Skyreach"] = {
        { boss = "Ranjit",                  pct = 0 },
        { boss = "Araknath",                pct = 28.07 },
        { boss = "Rukhran",                 pct = 52.20 },
        { boss = "High Sage Viryx",         pct = 60.09 },
    },
    ["Pit of Saron"] = {
        { boss = "Forgemaster Garfrost",    pct = 0 },
        { boss = "Ick & Krick",             pct = 58.63 },
        { boss = "Scourgelord Tyrannus",    pct = 79.94 },
    },
}
local lastLoadedKey = nil
local lastLoadTime = 0
local pendingLoadKey = nil

-- Smooth position tracking to prevent panels flying on mouse wheel
local smoothPos = { lx = nil, ly = nil, rx = nil, ry = nil }
local LERP_FACTOR = 0.30  -- 30% per tick: smooth but responsive.

local MPLUS_COLOR = { 0.4, 0.85, 1.0 }  -- M+ blue
local RAID_COLOR = { 0.95, 0.55, 0.1 }  -- Raid orange

-- =========================================================================
-- DATA SOURCE REGISTRY: each source has identity and build lookup logic.
-- =========================================================================
local DATA_SOURCES = {
    {
        key      = "wcl",
        label    = "WarcraftLogs",
        short    = "WCL",
        color    = { 0.95, 0.78, 0.20 },  -- gold
        subtitle = "WarcraftLogs Top 100",
        getBuilds = function(specID)
            return specID and EnrageWCLBuilds and EnrageWCLBuilds[specID] or nil
        end,
    },
    {
        key      = "archon",
        label    = "Archon",
        short    = "Archon",
        color    = { 0.55, 0.85, 0.45 },  -- green (Archon brand-ish)
        subtitle = "Archon.gg Builds",
        getBuilds = function(specID)
            return specID and EnrageArchonBuilds and EnrageArchonBuilds[specID] or nil
        end,
    },
}

local function GetSourceByKey(key)
    for _, src in ipairs(DATA_SOURCES) do
        if src.key == key then return src end
    end
    return DATA_SOURCES[1]
end

local SPEC_NAMES = {
    [71] = "Arms", [72] = "Fury", [73] = "Protection",
    [65] = "Holy", [66] = "Protection", [70] = "Retribution",
    [253] = "Beast Mastery", [254] = "Marksmanship", [255] = "Survival",
    [259] = "Assassination", [260] = "Outlaw", [261] = "Subtlety",
    [256] = "Discipline", [257] = "Holy", [258] = "Shadow",
    [250] = "Blood", [251] = "Frost", [252] = "Unholy",
    [262] = "Elemental", [263] = "Enhancement", [264] = "Restoration",
    [62] = "Arcane", [63] = "Fire", [64] = "Frost",
    [265] = "Affliction", [266] = "Demonology", [267] = "Destruction",
    [268] = "Brewmaster", [269] = "Windwalker", [270] = "Mistweaver",
    [102] = "Balance", [103] = "Feral", [104] = "Guardian", [105] = "Restoration",
    [577] = "Havoc", [581] = "Vengeance",
    [1467] = "Devastation", [1468] = "Preservation", [1473] = "Augmentation",
}

-- State
local leftPanel = nil   -- M+ panel
local rightPanel = nil   -- Raid panel
local leftRows = {}
local rightRows = {}
local trackedTalentFrame = nil

------------------------------------------------------------
-- Utility
------------------------------------------------------------
local function GetPlayerClassAndSpec()
    local _, className = UnitClass("player")
    local specIndex = GetSpecialization()
    local specID = specIndex and GetSpecializationInfo(specIndex) or nil
    return className, specID
end

local function GetBuildSourceKey(buildKey)
    local prefix = tostring(buildKey or ""):match("^([^:]+):")
    if not prefix then return nil end
    local lowerPrefix = string.lower(prefix)
    for _, source in ipairs(DATA_SOURCES) do
        if lowerPrefix == string.lower(source.key or "")
            or lowerPrefix == string.lower(source.short or "")
            or lowerPrefix == string.lower(source.label or "") then
            return source.key
        end
    end
    return nil
end

local function GetBuildKindFromKey(buildKey)
    local lowerKey = string.lower(tostring(buildKey or ""))
    if lowerKey == "" then return nil end

    if lowerKey:find("all dungeons", 1, true) or lowerKey:find("mplus", 1, true) or lowerKey:find("m+", 1, true) then
        return "mplus"
    end
    for _, dungeonName in ipairs(EnrageWCLDungeonList or {}) do
        if lowerKey:find(string.lower(dungeonName), 1, true) then
            return "mplus"
        end
    end

    if lowerKey:find("all bosses", 1, true) or lowerKey:find("raid", 1, true) then
        return "raid"
    end
    for _, bossName in ipairs(EnrageWCLBossList or {}) do
        if bossName:sub(1, 3) ~= "---" and lowerKey:find(string.lower(bossName), 1, true) then
            return "raid"
        end
    end

    return nil
end

local function SaveTalentPanelSourceForBuild(buildKey)
    if not EnrageDB or not EnrageDB.global then return end
    local sourceKey = GetBuildSourceKey(buildKey)
    local kind = GetBuildKindFromKey(buildKey)
    if not sourceKey or not kind then return end
    if not EnrageDB.global.talentPanelSources then EnrageDB.global.talentPanelSources = {} end
    EnrageDB.global.talentPanelSources[kind] = sourceKey
end

local function PersistLastLoadedBuildKey(buildKey, specID)
    buildKey = tostring(buildKey or "")
    if buildKey == "" then return end
    lastLoadedKey = buildKey
    _G.Enrage_LastLoadedBuild = buildKey
    if EnrageDB and EnrageDB.global then
        if not specID then
            local _, currentSpecID = GetPlayerClassAndSpec()
            specID = currentSpecID
        end
        EnrageDB.global.lastLoadedBuild = buildKey
        EnrageDB.global.lastLoadedBuildSpec = specID
        SaveTalentPanelSourceForBuild(buildKey)
    end
end

local function ClearLastLoadedBuildKey()
    lastLoadedKey = nil
    _G.Enrage_LastLoadedBuild = nil
    if EnrageDB and EnrageDB.global then
        EnrageDB.global.lastLoadedBuild = nil
        EnrageDB.global.lastLoadedBuildSpec = nil
    end
end

local function GetCurrentTalentString()
    local str = ""
    pcall(function()
        local configID = C_ClassTalents.GetActiveConfigID()
        if configID then
            str = C_Traits.GenerateImportString(configID) or ""
        end
    end)
    return str
end

local function RestoreLastLoadedBuildKey()
    local _, specID = GetPlayerClassAndSpec()
    local key = lastLoadedKey

    if (not key or key == "") and _G.Enrage_LastLoadedBuild then
        key = _G.Enrage_LastLoadedBuild
    end

    if (not key or key == "") and EnrageDB and EnrageDB.global then
        local savedSpec = EnrageDB.global.lastLoadedBuildSpec
        if not savedSpec or tonumber(savedSpec) == tonumber(specID) then
            key = EnrageDB.global.lastLoadedBuild
        end
    end

    key = tostring(key or "")
    if key ~= "" then
        PersistLastLoadedBuildKey(key, specID)
    end
    return key
end

local talentAlertFrame = nil
local lastTalentAlertKey = nil
local ignoredTalentAlertKey = nil

local TALENT_PROFILE_INFO = {
    mplus = {
        label = "Dungeon",
        color = MPLUS_COLOR,
        targetText = "M+ Dungeon",
        bodyText = "You are in a dungeon, but current talents do not match AkcQOL M+ Dungeon builds.",
    },
    raid = {
        label = "Raid",
        color = RAID_COLOR,
        targetText = "Raid",
        bodyText = "You are in a raid, but current talents do not match AkcQOL Raid builds.",
    },
}

local function NormalizeTalentImportString(value)
    value = tostring(value or "")
    value = value:gsub("%s+", "")
    return value
end

local function TalentStringsMatch(a, b)
    local left = NormalizeTalentImportString(a)
    local right = NormalizeTalentImportString(b)
    return left ~= "" and right ~= "" and left == right
end

local function AddTalentImportValue(set, value)
    if type(value) == "string" then
        local normalized = NormalizeTalentImportString(value)
        if normalized ~= "" then
            set[normalized] = true
            return 1
        end
    elseif type(value) == "table" then
        local count = 0
        for _, child in pairs(value) do
            count = count + AddTalentImportValue(set, child)
        end
        return count
    end
    return 0
end

local function BuildKnownTalentSet(kind)
    local _, specID = GetPlayerClassAndSpec()
    local set, count = {}, 0
    for _, source in ipairs(DATA_SOURCES) do
        local builds = source.getBuilds(specID)
        if type(builds) == "table" then
            if kind == "mplus" then
                count = count + AddTalentImportValue(set, builds.mplus)
            elseif kind == "raid" then
                count = count + AddTalentImportValue(set, builds.raid)
                count = count + AddTalentImportValue(set, builds.bosses)
            end
        end
    end
    return set, count
end

local function FindKnownBuildKeyByImport(kind, importString)
    local current = NormalizeTalentImportString(importString)
    if current == "" then return nil end

    local _, specID = GetPlayerClassAndSpec()
    local diffMap = { nm = "normal", hc = "heroic", mt = "mythic" }

    local function Matches(value)
        return TalentStringsMatch(value, current)
    end

    for _, source in ipairs(DATA_SOURCES) do
        local builds = source.getBuilds(specID)
        if type(builds) == "table" then
            local prefix = source.short or source.label or source.key

            if (not kind or kind == "mplus") and Matches(builds.mplus) then
                return prefix .. ":All Dungeons"
            end

            if not kind or kind == "raid" then
                if Matches(builds.raid) then
                    return prefix .. ":All Bosses"
                end
                if type(builds.bosses) == "table" then
                    for index, bossData in pairs(builds.bosses) do
                        local bossName = EnrageWCLBossList and EnrageWCLBossList[index]
                        if bossName and bossName:sub(1, 3) ~= "---" then
                            for diff, fullKey in pairs(diffMap) do
                                local candidate = type(bossData) == "table" and (bossData[fullKey] or bossData[diff]) or bossData
                                if Matches(candidate) then
                                    return prefix .. ":" .. bossName .. ":" .. diff
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return nil
end

local function ReconcileLastLoadedBuildFromCurrentTalents(kind, keepWhenUnknown)
    local current = NormalizeTalentImportString(GetCurrentTalentString())
    if current == "" then
        return keepWhenUnknown and RestoreLastLoadedBuildKey() or nil
    end

    local matchedKey = FindKnownBuildKeyByImport(kind, current)
    if matchedKey then
        local _, specID = GetPlayerClassAndSpec()
        PersistLastLoadedBuildKey(matchedKey, specID)
        return matchedKey
    end

    if keepWhenUnknown then
        return RestoreLastLoadedBuildKey()
    end

    ClearLastLoadedBuildKey()
    return nil
end

local function LastLoadedBuildMatchesKind(kind)
    local key = RestoreLastLoadedBuildKey()
    key = tostring(key or "")
    if key == "" then return false end
    local lowerKey = string.lower(key)

    if kind == "mplus" then
        if lowerKey:find("all dungeons", 1, true) or lowerKey:find("mplus", 1, true) or lowerKey:find("m+", 1, true) then return true end
        for _, dungeonName in ipairs(EnrageWCLDungeonList or {}) do
            if lowerKey:find(string.lower(dungeonName), 1, true) then return true end
        end
    elseif kind == "raid" then
        if lowerKey:find("all bosses", 1, true) or lowerKey:find("raid", 1, true) then return true end
        for _, bossName in ipairs(EnrageWCLBossList or {}) do
            if bossName:sub(1, 3) ~= "---" and lowerKey:find(string.lower(bossName), 1, true) then
                return true
            end
        end
    end

    return false
end

local function CurrentTalentMatchesKnownBuild(kind)
    if LastLoadedBuildMatchesKind(kind) then return true end

    local matchedKey = ReconcileLastLoadedBuildFromCurrentTalents(kind, true)
    if matchedKey and LastLoadedBuildMatchesKind(kind) then return true end

    local current = NormalizeTalentImportString(GetCurrentTalentString())
    if current == "" then return true end

    local known, count = BuildKnownTalentSet(kind)
    if count == 0 then return true end
    return known[current] == true
end

local function GetExpectedTalentProfile()
    local inInstance, instanceType = IsInInstance()
    if not inInstance then return nil, instanceType end
    if instanceType == "party" then return "mplus", instanceType end
    if instanceType == "raid" then return "raid", instanceType end
    return nil, instanceType
end

local function CreateTalentAlertButton(parent, text, width)
    local button = CreateFrame("Button", nil, parent, "UIPanelDynamicResizeButtonTemplate")
    button:SetSize(width or 120, 26)
    button:SetText(text)
    local fs = button.GetFontString and button:GetFontString()
    if fs and fs.SetTextColor then
        fs:SetTextColor(1, 0.82, 0.2, 1)
    end
    return button
end

local function EnsureTalentAlertFrame()
    if talentAlertFrame then return talentAlertFrame end

    local frame = CreateFrame("Frame", "EnrageTalentProfileAlert", UIParent, "BackdropTemplate")
    frame:SetSize(450, 122)
    frame:SetPoint("TOP", UIParent, "TOP", 0, -300)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:SetBackdrop({
        bgFile = FLAT_TEX,
        edgeFile = FLAT_TEX,
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.025, 0.020, 0.016, 0.92)
    frame:SetBackdropBorderColor(0.4, 0.85, 1.0, 0.85)
    frame:Hide()

    local title = frame:CreateFontString(nil, "OVERLAY")
    title:SetFont(FONT_FACE, 15, FONT_FLAGS)
    title:SetPoint("TOP", frame, "TOP", 0, -12)
    title:SetText("|cFFFFD34DTalent Profile Warning|r")
    frame.title = title

    local close = CreateFrame("Button", nil, frame)
    close:SetSize(22, 22)
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -8)
    close:SetHitRectInsets(-2, -2, -2, -2)
    close.bg = close:CreateTexture(nil, "BACKGROUND")
    close.bg:SetTexture(FLAT_TEX)
    close.bg:SetAllPoints()
    close.bg:SetVertexColor(0.22, 0.05, 0.05, 0)
    close.text = close:CreateFontString(nil, "OVERLAY")
    close.text:SetFont(FONT_FACE, 13, FONT_FLAGS)
    close.text:SetAllPoints()
    close.text:SetJustifyH("CENTER")
    close.text:SetJustifyV("MIDDLE")
    close.text:SetTextColor(0.96, 0.34, 0.32, 1)
    close.text:SetText("X")
    close:SetScript("OnClick", function()
        ignoredTalentAlertKey = lastTalentAlertKey
        frame:Hide()
    end)
    close:SetScript("OnEnter", function(self)
        self.bg:SetVertexColor(0.34, 0.06, 0.06, 0.92)
        self.text:SetTextColor(1.00, 0.52, 0.48, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Close this warning", 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    close:SetScript("OnLeave", function(self)
        self.bg:SetVertexColor(0.22, 0.05, 0.05, 0)
        self.text:SetTextColor(0.96, 0.34, 0.32, 1)
        GameTooltip:Hide()
    end)
    frame.close = close

    local body = frame:CreateFontString(nil, "OVERLAY")
    body:SetFont("Fonts\\ARIALN.TTF", 12, "")
    body:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -42)
    body:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -42)
    body:SetJustifyH("CENTER")
    body:SetTextColor(0.93, 0.94, 0.98, 1)
    frame.body = body

    local open = CreateTalentAlertButton(frame, "Open Builds", 132)
    open:SetPoint("BOTTOM", frame, "BOTTOM", -68, 14)
    open:SetScript("OnClick", function()
        frame:Hide()
        if PlayerSpellsUtil and PlayerSpellsUtil.OpenToClassTalents then
            pcall(PlayerSpellsUtil.OpenToClassTalents)
        elseif PlayerSpellsFrame and ShowUIPanel then
            pcall(ShowUIPanel, PlayerSpellsFrame)
        elseif ToggleTalentFrame then
            pcall(ToggleTalentFrame)
        end
        C_Timer.After(0.5, function()
            if SlashCmdList and SlashCmdList["WVBUILDS"] and (not leftPanel or not leftPanel:IsShown()) then
                SlashCmdList["WVBUILDS"]()
            end
        end)
    end)
    frame.open = open

    local ignore = CreateTalentAlertButton(frame, "Ignore", 96)
    ignore:SetPoint("LEFT", open, "RIGHT", 10, 0)
    ignore:SetScript("OnClick", function()
        ignoredTalentAlertKey = lastTalentAlertKey
        frame:Hide()
    end)
    frame.ignore = ignore

    talentAlertFrame = frame
    return frame
end

local function ShowTalentAlert(kind, instanceType)
    local info = TALENT_PROFILE_INFO[kind]
    if not info then return end

    local _, specID = GetPlayerClassAndSpec()
    local current = NormalizeTalentImportString(GetCurrentTalentString())
    local alertKey = tostring(kind) .. ":" .. tostring(instanceType or "") .. ":" .. tostring(specID or "") .. ":" .. current
    lastTalentAlertKey = alertKey
    if ignoredTalentAlertKey == alertKey then return end

    local frame = EnsureTalentAlertFrame()
    local color = info.color or { 1, 0.82, 0.2 }
    frame:SetBackdropBorderColor(color[1], color[2], color[3], 0.92)
    frame.title:SetText(string.format("|cFFFFD34D%s Talent Warning|r", info.label))
    frame.body:SetText(info.bodyText)
    frame:Show()
end

local function CheckTalentProfile(force)
    local expected, instanceType = GetExpectedTalentProfile()
    if not expected then
        if talentAlertFrame then talentAlertFrame:Hide() end
        return
    end

    if CurrentTalentMatchesKnownBuild(expected) then
        if talentAlertFrame then talentAlertFrame:Hide() end
        lastTalentAlertKey = nil
        return
    end

    local _, specID = GetPlayerClassAndSpec()
    local current = NormalizeTalentImportString(GetCurrentTalentString())
    local key = tostring(expected) .. ":" .. tostring(instanceType or "") .. ":" .. tostring(specID or "") .. ":" .. current
    if not force and (lastTalentAlertKey == key or ignoredTalentAlertKey == key) then return end
    ShowTalentAlert(expected, instanceType)
end

_G.Enrage_CheckTalentProfile = CheckTalentProfile

local function ScheduleTalentProfileCheck(force, delay)
    C_Timer.After(delay or 1.0, function()
        CheckTalentProfile(force)
    end)
end

------------------------------------------------------------
-- Taint-safe position tracking
------------------------------------------------------------
local originalTalentScale = nil
local appliedTalentScale = nil
local pendingTalentScale = nil

local talentCombatFrame = CreateFrame("Frame")
talentCombatFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
talentCombatFrame:SetScript("OnEvent", function()
    if pendingTalentScale and trackedTalentFrame then
        trackedTalentFrame:SetScale(pendingTalentScale)
        appliedTalentScale = pendingTalentScale
        pendingTalentScale = nil
    end
end)

local function SafeSetTalentScale(scale)
    if InCombatLockdown() then
        pendingTalentScale = scale
    else
        trackedTalentFrame:SetScale(scale)
        appliedTalentScale = scale
        pendingTalentScale = nil
    end
end

------------------------------------------------------------
-- Import talent build (copy popup + C_Traits application)
------------------------------------------------------------
local function ShowCopyPopup(importString)
    local popup = _G["WVT_ImportPopup"]
    if not popup then
        popup = CreateFrame("Frame", "WVT_ImportPopup", UIParent, "BackdropTemplate")
        popup:SetSize(420, 110)
        popup:SetPoint("CENTER")
        popup:SetFrameStrata("FULLSCREEN_DIALOG")
        popup:SetBackdrop({
            bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
            edgeSize = 24,
            insets = { left = 5, right = 5, top = 5, bottom = 5 },
        })

        local title = popup:CreateFontString(nil, "OVERLAY")
        title:SetFont(FONT_FACE, 11, FONT_FLAGS)
        title:SetPoint("TOP", 0, -14)
        title:SetText("|cFFFFD100Ctrl+C to copy|r |cFF888888\226\134\146 Loadouts \226\134\146 Import \226\134\146 Ctrl+V|r")

        popup.editBox = CreateFrame("EditBox", nil, popup, "InputBoxTemplate")
        popup.editBox:SetSize(370, 22)
        popup.editBox:SetPoint("CENTER", 0, -5)
        popup.editBox:SetAutoFocus(true)
        popup.editBox:SetFont(FONT_FACE, 10, FONT_FLAGS)
        popup.editBox:SetScript("OnEscapePressed", function() popup:Hide() end)
        popup.editBox:SetScript("OnEnterPressed", function() popup:Hide() end)

        local hint = popup:CreateFontString(nil, "OVERLAY")
        hint:SetFont(FONT_FACE, 9, FONT_FLAGS)
        hint:SetPoint("BOTTOM", 0, 14)
        hint:SetText("|cFF555555Press ESC to close|r")

        local closeBtn = CreateFrame("Button", nil, popup, "UIPanelCloseButton")
        closeBtn:SetPoint("TOPRIGHT", -2, -2)
    end

    popup.editBox:SetText(importString)
    popup.editBox:HighlightText()
    popup:Show()
    C_Timer.After(15, function() if popup:IsShown() then popup:Hide() end end)
end

local function GetTalentsFrame()
    if not PlayerSpellsFrame then return nil end
    return PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
end

local function ImportTalentBuild(importString, buildKey)
    if not importString or importString == "" then
        print("|cFFFF4444[AkcQOL]|r Talent import string is empty.")
        return
    end

    local talentsFrame = GetTalentsFrame()
    if not talentsFrame then
        print("|cFFFF4444[AkcQOL]|r Open the talent window before loading a build.")
        return
    end

    local configID = C_ClassTalents.GetActiveConfigID()
    if not configID then
        print("|cFFFF4444[AkcQOL]|r Could not read the active talent config.")
        return
    end

    local specID = PlayerUtil.GetCurrentSpecID()
    local treeID = C_ClassTalents.GetTraitTreeForSpec(specID)
    if not treeID then
        print("|cFFFF4444[AkcQOL]|r Could not read the current talent tree.")
        return
    end

    local importStream = ExportUtil.MakeImportDataStream(importString)
    if not importStream then
        print("|cFFFF4444[AkcQOL]|r Could not parse the talent import string.")
        ShowCopyPopup(importString)
        return
    end

    local headerValid, _, streamSpecID, _
    local ok1 = pcall(function()
        headerValid, _, streamSpecID, _ = talentsFrame:ReadLoadoutHeader(importStream)
    end)

    if not ok1 or not headerValid then
        print("|cFFFF4444[AkcQOL]|r Invalid talent import string.")
        ShowCopyPopup(importString)
        return
    end

    if streamSpecID ~= specID then
        print("|cFFFF4444[AkcQOL]|r This build is for a different spec. Expected " .. specID .. ", got " .. (streamSpecID or "?") .. ".")
        return
    end

    local loadoutContent
    local ok2 = pcall(function()
        loadoutContent = talentsFrame:ReadLoadoutContent(importStream, treeID)
    end)

    if not ok2 or not loadoutContent then
        print("|cFFFF4444[AkcQOL]|r Could not read talent build content.")
        ShowCopyPopup(importString)
        return
    end

    local loadoutEntryInfo
    local ok3 = pcall(function()
        loadoutEntryInfo = talentsFrame:ConvertToImportLoadoutEntryInfo(configID, treeID, loadoutContent)
    end)

    if not ok3 or not loadoutEntryInfo then
        print("|cFFFF4444[AkcQOL]|r Could not convert talent build.")
        ShowCopyPopup(importString)
        return
    end

    -- Sort by node position
    -- Main tree first (low Y values), Hero Talent sub-trees last (offset 1M+)
    -- so hero talents are purchased AFTER their prerequisite class/spec talents.
    local nodeOrder = {}
    pcall(function()
        -- Main class/spec tree
        for _, nodeID in pairs(C_Traits.GetTreeNodes(treeID)) do
            local nodeInfo = C_Traits.GetNodeInfo(configID, nodeID)
            if nodeInfo and nodeInfo.isVisible then
                nodeOrder[nodeID] = nodeInfo.posY * 10000 + nodeInfo.posX
            end
        end
        -- Hero Talent sub-trees (San'layn / Deathbringer / etc.)
        local subTreeIDs = (C_Traits.GetTreeInfo and C_Traits.GetTreeInfo(configID, treeID) and C_Traits.GetTreeInfo(configID, treeID).subTreeIDs) or {}
        for _, subTreeID in ipairs(subTreeIDs) do
            local subNodes = C_Traits.GetTreeNodes(subTreeID) or {}
            for _, nodeID in pairs(subNodes) do
                local nodeInfo = C_Traits.GetNodeInfo(configID, nodeID)
                if nodeInfo and nodeInfo.isVisible then
                    -- 1M offset guarantees hero talents come after main tree
                    nodeOrder[nodeID] = 1000000 + nodeInfo.posY * 10000 + nodeInfo.posX
                end
            end
        end
    end)

    -- Unknown nodes sort to the very end (defensive: any node not in either tree)
    table.sort(loadoutEntryInfo, function(a, b)
        return (nodeOrder[a.nodeID] or 9999999) < (nodeOrder[b.nodeID] or 9999999)
    end)

    pcall(function()
        if C_ClassTalents.GetStarterBuildActive() then
            C_ClassTalents.SetStarterBuildActive(false)
        end
    end)

    C_Traits.ResetTree(configID, treeID)

    local errorCount = 0
    for _, entry in ipairs(loadoutEntryInfo) do
        local nodeInfo = C_Traits.GetNodeInfo(configID, entry.nodeID)
        if nodeInfo then
            local result = true
            if nodeInfo.type == Enum.TraitNodeType.Single or nodeInfo.type == Enum.TraitNodeType.Tiered then
                for rank = 1, (entry.ranksPurchased or 1) do
                    result = C_Traits.PurchaseRank(configID, entry.nodeID)
                    if not result then break end
                end
            else
                result = C_Traits.SetSelection(configID, entry.nodeID, entry.selectionEntryID)
            end
            if not result then errorCount = errorCount + 1 end
        end
    end

    -- Set pending key BEFORE CommitConfig (events may fire during commit)
    pendingLoadKey = buildKey
    lastLoadTime = GetTime()

    local commitOk = pcall(function() C_ClassTalents.CommitConfig(configID) end)

    -- Also set lastLoadedKey immediately as fallback (events may not fire reliably)
    PersistLastLoadedBuildKey(buildKey)

    if errorCount > 0 then
        print("|cFF00FF00[AkcQOL]|r Build load started: " .. (buildKey or "Build") .. " (" .. errorCount .. " node(s) skipped).")
    else
        print("|cFF00FF00[AkcQOL]|r Build load started: " .. (buildKey or "Build") .. ".")
    end

    -- Refresh panels with increasing delays to catch the commit completion
    C_Timer.After(0.5, RefreshAllPanels)
    C_Timer.After(2.0, RefreshAllPanels)
    C_Timer.After(4.0, RefreshAllPanels)
end

------------------------------------------------------------
-- Create a WCL panel (used for both left and right)
------------------------------------------------------------
local function CreateWCLSidePanel(panelName, titleStr, titleColor, subtitleStr, sourceSettingKey)
    local panel = CreateFrame("Frame", panelName, UIParent, "BackdropTemplate")
    panel:SetSize(PANEL_WIDTH, 700)
    panel:SetFrameStrata("HIGH")
    panel:SetFrameLevel(100)
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel.sourceSettingKey = sourceSettingKey

    panel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        edgeSize = 20,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })

    -- Title bar
    local titleBar = CreateFrame("Frame", nil, panel)
    titleBar:SetPoint("TOPLEFT", 6, -6)
    titleBar:SetPoint("TOPRIGHT", -6, -6)
    titleBar:SetHeight(22)

    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")
    titleBg:SetAllPoints()
    titleBg:SetTexture(FLAT_TEX)
    titleBg:SetVertexColor(titleColor[1] * 0.2, titleColor[2] * 0.2, titleColor[3] * 0.2, 0.6)

    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    titleText:SetFont(FONT_FACE, 10, FONT_FLAGS)
    titleText:SetPoint("CENTER", 0, 0)
    titleText:SetText(titleStr)

    -- =========================================================================
    -- TAB BAR: switch between WCL and Archon data sources.
    -- =========================================================================
    panel.dataSource = "wcl"  -- default
    panel.tabs = {}

    local tabBar = CreateFrame("Frame", nil, panel)
    tabBar:SetPoint("TOPLEFT", titleBar, "BOTTOMLEFT", 0, -4)
    tabBar:SetPoint("TOPRIGHT", titleBar, "BOTTOMRIGHT", 0, -4)
    tabBar:SetHeight(18)

    local tabCount = #DATA_SOURCES
    local tabSpacing = 2
    -- Available width inside tab bar (PANEL_WIDTH - 12 for left+right insets)
    local tabBarW = PANEL_WIDTH - 12
    local tabW = math.floor((tabBarW - tabSpacing * (tabCount - 1)) / tabCount)

    local function StyleTab(tab, isActive)
        local src = tab.source
        local r, g, b = src.color[1], src.color[2], src.color[3]
        if isActive then
            tab.bg:SetVertexColor(r * 0.55, g * 0.55, b * 0.55, 0.95)
            tab.border:SetVertexColor(r, g, b, 1.0)
            tab.label:SetText(string.format("|cFF%02x%02x%02x%s|r",
                math.min(255, math.floor(r*255*1.2)), math.min(255, math.floor(g*255*1.2)), math.min(255, math.floor(b*255*1.2)),
                src.label))
        else
            tab.bg:SetVertexColor(0.10, 0.10, 0.12, 0.6)
            tab.border:SetVertexColor(r * 0.35, g * 0.35, b * 0.35, 0.5)
            tab.label:SetText(string.format("|cFF%02x%02x%02x%s|r",
                math.floor(r*255*0.7), math.floor(g*255*0.7), math.floor(b*255*0.7),
                src.label))
        end
    end

    for idx, src in ipairs(DATA_SOURCES) do
        local tab = CreateFrame("Button", nil, tabBar)
        tab.source = src
        tab:SetSize(tabW, 18)
        tab:SetPoint("LEFT", (idx - 1) * (tabW + tabSpacing), 0)

        tab.border = tab:CreateTexture(nil, "BACKGROUND")
        tab.border:SetAllPoints()
        tab.border:SetTexture(FLAT_TEX)

        tab.bg = tab:CreateTexture(nil, "ARTWORK")
        tab.bg:SetPoint("TOPLEFT", 1, -1)
        tab.bg:SetPoint("BOTTOMRIGHT", -1, 1)
        tab.bg:SetTexture(FLAT_TEX)

        tab.label = tab:CreateFontString(nil, "OVERLAY")
        tab.label:SetFont(FONT_FACE, 9, FONT_FLAGS)
        tab.label:SetPoint("CENTER", 0, 0)

        tab:SetScript("OnEnter", function(self)
            if panel.dataSource ~= self.source.key then
                self.bg:SetVertexColor(self.source.color[1] * 0.30, self.source.color[2] * 0.30, self.source.color[3] * 0.30, 0.85)
            end
        end)
        tab:SetScript("OnLeave", function(self)
            StyleTab(self, panel.dataSource == self.source.key)
        end)
        tab:SetScript("OnClick", function(self)
            if panel.dataSource == self.source.key then return end
            if panel.SetDataSourceKey then
                panel:SetDataSourceKey(self.source.key, true)
            end
            if _G.WVT_RefreshBuilds then _G.WVT_RefreshBuilds() end
        end)

        StyleTab(tab, idx == 1)  -- first tab active by default
        panel.tabs[idx] = tab
    end

    function panel:SetDataSourceKey(sourceKey, shouldSave)
        local source = GetSourceByKey(sourceKey or "wcl")
        self.dataSource = source.key
        for _, tab in ipairs(self.tabs or {}) do
            StyleTab(tab, self.dataSource == tab.source.key)
        end
        if self.subLabel then
            self.subLabel:SetText("|cFFAAAAAA" .. source.subtitle .. "|r")
        end
        if shouldSave and EnrageDB and EnrageDB.global and self.sourceSettingKey then
            if not EnrageDB.global.talentPanelSources then EnrageDB.global.talentPanelSources = {} end
            EnrageDB.global.talentPanelSources[self.sourceSettingKey] = source.key
        end
    end

    -- Subtitle (data source description, updates on tab switch)
    local subLabel = panel:CreateFontString(nil, "OVERLAY")
    subLabel:SetFont(FONT_FACE, 8, FONT_FLAGS)
    subLabel:SetPoint("TOP", tabBar, "BOTTOM", 0, -3)
    subLabel:SetText("|cFFAAAAAA" .. DATA_SOURCES[1].subtitle .. "|r")
    panel.subLabel = subLabel

    -- Spec label
    local specLabel = panel:CreateFontString(nil, "OVERLAY")
    specLabel:SetFont(FONT_FACE, 12, FONT_FLAGS)
    specLabel:SetPoint("TOP", subLabel, "BOTTOM", 0, -3)
    panel.specLabel = specLabel

    -- Scroll area
    local scrollArea = CreateFrame("Frame", nil, panel)
    scrollArea:SetPoint("TOPLEFT", 6, -HEADER_HEIGHT)
    scrollArea:SetPoint("BOTTOMRIGHT", -6, 6)
    scrollArea:EnableMouseWheel(true)
    scrollArea:SetClipsChildren(true)  -- never let rows spill past the panel bottom
    panel.scrollArea = scrollArea

    -- Create rows (max 12)
    local rows = {}
    for i = 1, 14 do
        local row = CreateFrame("Frame", nil, scrollArea, "BackdropTemplate")
        row:SetHeight(ROW_HEIGHT)
        row:SetPoint("TOPLEFT", 0, -((i - 1) * (ROW_HEIGHT + 1)))
        row:SetPoint("TOPRIGHT", 0, -((i - 1) * (ROW_HEIGHT + 1)))

        row:SetBackdrop({
            bgFile = FLAT_TEX,
            edgeFile = FLAT_TEX,
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 },
        })
        row:SetBackdropColor(0.06, 0.06, 0.08, 0.7)
        row:SetBackdropBorderColor(0.25, 0.22, 0.15, 0.3)

        -- Name text
        local nameText = row:CreateFontString(nil, "OVERLAY")
        nameText:SetFont(FONT_FACE, 10, FONT_FLAGS)
        nameText:SetPoint("TOPLEFT", 4, -4)
        nameText:SetPoint("TOPRIGHT", -4, -4)
        nameText:SetJustifyH("CENTER")
        nameText:SetWordWrap(false)

        -- Load button (used for M+ panel)
        local loadBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        loadBtn:SetSize(PANEL_WIDTH - 28, 18)
        loadBtn:SetPoint("BOTTOM", 0, 4)
        loadBtn:SetText("Load")
        loadBtn:GetFontString():SetFont(FONT_FACE, 10, FONT_FLAGS)

        -- Difficulty buttons (used for Raid panel): Nm (left), Hc (middle), Mt (right)
        -- Custom flat style buttons with color-coded backgrounds
        local function CreateDiffBtn(parent, label, r, g, b)
            local btn = CreateFrame("Button", nil, parent)
            btn:SetSize(40, 18)

            -- Border (outer edge, drawn first)
            local border = btn:CreateTexture(nil, "BACKGROUND")
            border:SetAllPoints()
            border:SetTexture("Interface\\Buttons\\WHITE8x8")
            border:SetVertexColor(r * 0.6, g * 0.6, b * 0.6, 0.8)
            btn.border = border

            -- Background (inner fill, 1px inset from edges)
            local bg = btn:CreateTexture(nil, "ARTWORK")
            bg:SetPoint("TOPLEFT", 1, -1)
            bg:SetPoint("BOTTOMRIGHT", -1, 1)
            bg:SetTexture("Interface\\Buttons\\WHITE8x8")
            bg:SetVertexColor(r * 0.3, g * 0.3, b * 0.3, 0.9)
            btn.bg = bg

            local text = btn:CreateFontString(nil, "OVERLAY")
            text:SetFont(FONT_FACE, 8, FONT_FLAGS)
            text:SetPoint("CENTER", 0, 0)
            text:SetText(string.format("|cFF%02x%02x%02x%s|r", r*255, g*255, b*255, label))
            btn.label = text

            btn:SetScript("OnEnter", function()
                bg:SetVertexColor(r * 0.5, g * 0.5, b * 0.5, 1.0)
                border:SetVertexColor(r, g, b, 1.0)
            end)
            btn:SetScript("OnLeave", function()
                bg:SetVertexColor(r * 0.3, g * 0.3, b * 0.3, 0.9)
                border:SetVertexColor(r * 0.6, g * 0.6, b * 0.6, 0.8)
            end)

            btn:Hide()
            return btn
        end

        -- 3 compact buttons
        local ROW_INNER_W = PANEL_WIDTH - 12  -- scrollArea has 6px padding each side
        local BTN_PAD = 6
        local BTN_GAP = 2
        local btnW = math.floor((ROW_INNER_W - BTN_PAD * 2 - BTN_GAP * 2) / 3)

        local nmBtn = CreateDiffBtn(row, "N", 0.4, 1.0, 0.4)
        nmBtn:SetSize(btnW, 14)
        nmBtn:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", BTN_PAD, 3)

        local hcBtn = CreateDiffBtn(row, "H", 1.0, 0.6, 0.2)
        hcBtn:SetSize(btnW, 14)
        hcBtn:SetPoint("LEFT", nmBtn, "RIGHT", BTN_GAP, 0)

        local mtBtn = CreateDiffBtn(row, "M", 1.0, 0.3, 0.3)
        mtBtn:SetSize(btnW, 14)
        mtBtn:SetPoint("LEFT", hcBtn, "RIGHT", BTN_GAP, 0)

        -- Hover
        row:EnableMouse(true)
        row:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.12, 0.10, 0.06, 0.8)
            self:SetBackdropBorderColor(0.60, 0.50, 0.20, 0.5)
        end)
        row:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0.06, 0.06, 0.08, 0.7)
            self:SetBackdropBorderColor(0.25, 0.22, 0.15, 0.3)
            GameTooltip:Hide()
        end)

        rows[i] = {
            frame = row,
            nameText = nameText,
            loadBtn = loadBtn,
            nmBtn = nmBtn,
            hcBtn = hcBtn,
            mtBtn = mtBtn,
        }
    end

    panel:Hide()
    return panel, rows
end

------------------------------------------------------------
-- Refresh panel rows with encounter list
------------------------------------------------------------
-- Helper: resolve difficulty string from data (backward compat)
-- data can be: string (old format), or table with normal/heroic/mythic keys (new format)
-- diff is "nm", "hc", or "mt"
local DIFF_KEY_MAP = { nm = "normal", hc = "heroic", mt = "mythic" }
local function ResolveDifficultyStr(data, diff)
    if type(data) == "table" then
        local fullKey = DIFF_KEY_MAP[diff] or diff
        return data[fullKey] or data[diff] or ""
    elseif type(data) == "string" then
        return data
    end
    return ""
end

-- Helper: set up a single difficulty button on a row
local DIFF_LABELS = { nm = "N", hc = "H", mt = "M" }
local DIFF_COLORS = {
    nm = { 0.4, 1.0, 0.4 },
    hc = { 1.0, 0.6, 0.2 },
    mt = { 1.0, 0.3, 0.3 },
}

local function SetupDiffBtn(btn, importStr, currentTalent, buildKey, diff)
    local str = ResolveDifficultyStr(importStr, diff)
    local key = buildKey .. ":" .. diff
    local c = DIFF_COLORS[diff] or { 1, 1, 1 }
    if str ~= "" then
        if lastLoadedKey == key or TalentStringsMatch(str, currentTalent) then
            -- Active state: green glow
            if btn.label then
                btn.label:SetText("|cFF00FF00Active|r")
            end
            if btn.bg then btn.bg:SetVertexColor(0, 0.3, 0, 0.9) end
            if btn.border then btn.border:SetVertexColor(0, 0.8, 0, 1.0) end
        else
            -- Normal state: color-coded
            if btn.label then
                btn.label:SetText(string.format("|cFF%02x%02x%02x%s|r", c[1]*255, c[2]*255, c[3]*255, DIFF_LABELS[diff] or diff))
            end
            if btn.bg then btn.bg:SetVertexColor(c[1]*0.3, c[2]*0.3, c[3]*0.3, 0.9) end
            if btn.border then btn.border:SetVertexColor(c[1]*0.6, c[2]*0.6, c[3]*0.6, 0.8) end
        end
        btn:Enable()
        btn:SetScript("OnClick", function()
            ImportTalentBuild(str, key)
        end)
    else
        -- No data: greyed out
        if btn.label then btn.label:SetText("|cFF666666" .. (DIFF_LABELS[diff] or diff) .. "|r") end
        if btn.bg then btn.bg:SetVertexColor(0.1, 0.1, 0.1, 0.5) end
        if btn.border then btn.border:SetVertexColor(0.2, 0.2, 0.2, 0.5) end
        btn:Disable()
    end
    btn:Show()
end

-- Scale the visible rows so the whole list fits the panel height (= talent frame
-- height). Without this the list overflows past the panel bottom on specs with many
-- bosses. Reads the current scroll-area height, so it self-corrects as the panel sizes.
local function FitPanelRows(panel)
    local rows = panel and panel.rowObjects
    local n = (panel and panel.shownRowCount) or 0
    if not rows or n <= 0 then return end
    local areaH = (panel.scrollArea and panel.scrollArea:GetHeight()) or 0
    if areaH <= 0 then return end
    local rowH = math.floor((areaH - (n - 1)) / n)
    if rowH > ROW_HEIGHT then rowH = ROW_HEIGHT end
    if rowH < 34 then rowH = 34 end
    for i = 1, n do
        local r = rows[i]
        if r and r.frame then
            r.frame:ClearAllPoints()
            r.frame:SetPoint("TOPLEFT", 0, -((i - 1) * (rowH + 1)))
            r.frame:SetPoint("TOPRIGHT", 0, -((i - 1) * (rowH + 1)))
            r.frame:SetHeight(rowH)
        end
    end
end

local function RefreshSidePanel(panel, rows, encounterList, buildType, color, scrollOffset)
    if not panel or not panel:IsShown() then return end

    local _, specID = GetPlayerClassAndSpec()
    local _, className = UnitClass("player")

    -- Update spec label
    if panel.specLabel then
        local specName = specID and SPEC_NAMES[specID] or "?"
        local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
        local colorStr = classColor and classColor.colorStr or "FFFFFFFF"
        panel.specLabel:SetText("|c" .. colorStr .. specName .. "|r")
    end

    -- Use active data source for this panel (set by tab click; defaults to WCL)
    local activeSource = GetSourceByKey(panel.dataSource or "wcl")
    local sourceLabel = activeSource.short  -- "WCL" or "Archon", used in tooltips.
    local wclBuilds = activeSource.getBuilds(specID) or {}
    local importStr = wclBuilds[buildType] or ""
    local currentTalent = GetCurrentTalentString()
    local isRaid = (buildType == "raid")

    -- Row 1: "All" button, with key prefixed by source.
    local allLabel = isRaid and "All Bosses" or "All Dungeons"
    local allKey = sourceLabel .. ":" .. allLabel

    if rows[1] then
        local r = rows[1]
        r.frame:ClearAllPoints()
        r.frame:SetPoint("TOPLEFT", 0, 0)
        r.frame:SetPoint("TOPRIGHT", 0, 0)
        r.frame:Show()

        r.nameText:SetText(string.format("|cFF%02x%02x%02x%s|r", color[1]*255, color[2]*255, color[3]*255, allLabel))

        if isRaid then
            -- Show 3 difficulty buttons, hide single load button
            r.loadBtn:Hide()
            -- importStr can be string (old) or table (new with nm/hc/mt)
            SetupDiffBtn(r.nmBtn, importStr, currentTalent, allKey, "nm")
            SetupDiffBtn(r.hcBtn, importStr, currentTalent, allKey, "hc")
            SetupDiffBtn(r.mtBtn, importStr, currentTalent, allKey, "mt")
        else
            -- M+: single load button, hide difficulty buttons
            r.nmBtn:Hide()
            r.hcBtn:Hide()
            r.mtBtn:Hide()
            r.loadBtn:Show()
            if importStr ~= "" then
                if TalentStringsMatch(importStr, currentTalent) or lastLoadedKey == allKey then
                    r.loadBtn:SetText("|cFF00FF00Active|r")
                else
                    r.loadBtn:SetText("Load")
                end
                r.loadBtn:Enable()
                r.loadBtn:SetScript("OnClick", function()
                    ImportTalentBuild(importStr, allKey)
                end)
            else
                r.loadBtn:SetText("|cFF666666N/A|r")
                r.loadBtn:Disable()
            end
        end

        r.frame:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.12, 0.10, 0.06, 0.8)
            self:SetBackdropBorderColor(0.60, 0.50, 0.20, 0.5)
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:AddLine(allLabel, color[1], color[2], color[3])
            GameTooltip:AddLine(activeSource.subtitle, 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
    end

    -- Remaining rows: encounter names
    local list = encounterList or {}
    for i = 2, 14 do
        local r = rows[i]
        local idx = (i - 1) + (scrollOffset or 0)
        if idx <= #list then
            local encounterName = list[idx]
            r.frame:ClearAllPoints()
            r.frame:SetPoint("TOPLEFT", 0, -((i - 1) * (ROW_HEIGHT + 1)))
            r.frame:SetPoint("TOPRIGHT", 0, -((i - 1) * (ROW_HEIGHT + 1)))
            r.frame:Show()

            -- Check if this is a raid header separator (prefix "---")
            local isSeparator = encounterName:sub(1, 3) == "---"
            if isSeparator then
                local raidName = encounterName:sub(4)
                r.nameText:SetText("|cFFFFD100" .. raidName .. "|r")
                r.loadBtn:Hide()
                r.nmBtn:Hide()
                r.hcBtn:Hide()
                r.mtBtn:Hide()
                r.frame:SetBackdropColor(0.15, 0.12, 0.05, 0.9)
                r.frame:SetBackdropBorderColor(0.5, 0.4, 0.1, 0.6)
                r.frame:SetScript("OnEnter", nil)
                r.frame:SetScript("OnLeave", nil)
            else
            -- Set boss/dungeon name
            r.nameText:SetText("|cFFCCCCCC" .. encounterName .. "|r")

            if isRaid then
                -- Show 3 difficulty buttons, hide single load button
                r.loadBtn:Hide()

                -- Per-boss talent build: compute real boss index (skip separators)
                local bossIdx = 0
                for li = 1, idx do
                    if not list[li] or list[li]:sub(1,3) ~= "---" then
                        bossIdx = bossIdx + 1
                    end
                end
                local bossData = nil
                if wclBuilds.bosses then
                    bossData = wclBuilds.bosses[bossIdx]
                end
                -- If no boss-specific data, fall back to the "All" importStr
                local rowData = bossData or importStr
                local bossKey = sourceLabel .. ":" .. encounterName

                SetupDiffBtn(r.nmBtn, rowData, currentTalent, bossKey, "nm")
                SetupDiffBtn(r.hcBtn, rowData, currentTalent, bossKey, "hc")
                SetupDiffBtn(r.mtBtn, rowData, currentTalent, bossKey, "mt")
            else
                -- M+: single load button, hide difficulty buttons
                r.nmBtn:Hide()
                r.hcBtn:Hide()
                r.mtBtn:Hide()
                r.loadBtn:Show()

                local bossStr = nil
                if buildType == "raid" and wclBuilds.bosses then
                    bossStr = wclBuilds.bosses[idx]
                end
                local rowStr = bossStr or importStr
                local rowKey = sourceLabel .. ":" .. encounterName
                if rowStr ~= "" then
                    if TalentStringsMatch(rowStr, currentTalent) or lastLoadedKey == rowKey then
                        r.loadBtn:SetText("|cFF00FF00Active|r")
                    else
                        r.loadBtn:SetText("Load")
                    end
                    r.loadBtn:Enable()
                    r.loadBtn:SetScript("OnClick", function()
                        ImportTalentBuild(rowStr, rowKey)
                    end)
                else
                    r.loadBtn:SetText("|cFF666666N/A|r")
                    r.loadBtn:Disable()
                end
            end

            r.frame:SetScript("OnEnter", function(self)
                self:SetBackdropColor(0.12, 0.10, 0.06, 0.8)
                self:SetBackdropBorderColor(0.60, 0.50, 0.20, 0.5)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:AddLine(encounterName, color[1], color[2], color[3])
                GameTooltip:AddLine(activeSource.subtitle, 0.7, 0.7, 0.7)
                -- Show route % data for M+ dungeons
                local routeData = not isRaid and _G.ENRAGE_DUNGEON_ROUTE_DATA[encounterName]
                if routeData then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("Route - Enemy Forces", 1, 0.82, 0)
                    local prevPct = 0
                    for bi, bossInfo in ipairs(routeData) do
                        local segment = bossInfo.pct - prevPct
                        local pctColor
                        if bossInfo.pct >= 100 then
                            pctColor = "|cFF00FF00"
                        elseif bossInfo.pct >= 50 then
                            pctColor = "|cFFFFFF00"
                        else
                            pctColor = "|cFFFF8800"
                        end
                        local segText = segment > 0 and string.format("  (+%.0f%%)", segment) or ""
                        GameTooltip:AddDoubleLine(
                            string.format("|cFFCCCCCC%d.|r %s", bi, bossInfo.boss),
                            string.format("%s%.1f%%%s|r", pctColor, bossInfo.pct, "|cFF888888" .. segText .. "|r"),
                            1, 1, 1, 1, 1, 1
                        )
                        prevPct = bossInfo.pct
                    end
                end
                GameTooltip:Show()
            end)
            r.frame:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0.06, 0.06, 0.08, 0.7)
                self:SetBackdropBorderColor(0.25, 0.22, 0.15, 0.3)
                GameTooltip:Hide()
            end)
            end -- end of else (non-separator)
        else
            r.frame:Hide()
        end
    end
    panel.rowObjects = rows
    panel.shownRowCount = math.min(14, #(encounterList or {}) + 1)
    FitPanelRows(panel)
end

------------------------------------------------------------
-- Position panels relative to talent frame
------------------------------------------------------------
local function UpdateLeftPanelPosition()
    if not leftPanel or not leftPanel:IsShown() then return end
    if not trackedTalentFrame or not trackedTalentFrame:IsShown() then
        leftPanel:Hide()
        return
    end

    local panelScale = leftPanel:GetEffectiveScale()
    local scale = trackedTalentFrame:GetEffectiveScale()
    local ratio = scale / panelScale
    local left = trackedTalentFrame:GetLeft()
    local top = trackedTalentFrame:GetTop()
    local bottom = trackedTalentFrame:GetBottom()
    if not left or not top or not bottom then return end

    local targetX = (left * ratio) - PANEL_WIDTH - 2
    if targetX < 0 then targetX = 0 end
    local targetY = top * ratio
    local panelH = (top - bottom) * ratio

    -- Smooth interpolation
    if smoothPos.lx then
        local dx = targetX - smoothPos.lx
        local dy = targetY - smoothPos.ly
        if math.abs(dx) < 0.5 and math.abs(dy) < 0.5 then
            smoothPos.lx = targetX
            smoothPos.ly = targetY
        else
            smoothPos.lx = smoothPos.lx + dx * LERP_FACTOR
            smoothPos.ly = smoothPos.ly + dy * LERP_FACTOR
        end
    else
        smoothPos.lx = targetX
        smoothPos.ly = targetY
    end

    leftPanel:ClearAllPoints()
    leftPanel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", smoothPos.lx, smoothPos.ly)
    leftPanel:SetHeight(panelH)
    if leftPanel.lastFitH ~= panelH then
        leftPanel.lastFitH = panelH
        FitPanelRows(leftPanel)
    end
end

local function UpdateRightPanelPosition()
    if not rightPanel or not rightPanel:IsShown() then return end
    if not trackedTalentFrame or not trackedTalentFrame:IsShown() then
        rightPanel:Hide()
        return
    end

    local panelScale = rightPanel:GetEffectiveScale()
    local scale = trackedTalentFrame:GetEffectiveScale()
    local ratio = scale / panelScale
    local right = trackedTalentFrame:GetRight()
    local top = trackedTalentFrame:GetTop()
    local bottom = trackedTalentFrame:GetBottom()
    if not right or not top or not bottom then return end

    local targetX = (right * ratio) + 2
    local screenW = GetScreenWidth()
    if targetX + PANEL_WIDTH > screenW then targetX = screenW - PANEL_WIDTH end
    local targetY = top * ratio
    local panelH = (top - bottom) * ratio

    -- Smooth interpolation
    if smoothPos.rx then
        local dx = targetX - smoothPos.rx
        local dy = targetY - smoothPos.ry
        if math.abs(dx) < 0.5 and math.abs(dy) < 0.5 then
            smoothPos.rx = targetX
            smoothPos.ry = targetY
        else
            smoothPos.rx = smoothPos.rx + dx * LERP_FACTOR
            smoothPos.ry = smoothPos.ry + dy * LERP_FACTOR
        end
    else
        smoothPos.rx = targetX
        smoothPos.ry = targetY
    end

    rightPanel:ClearAllPoints()
    rightPanel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", smoothPos.rx, smoothPos.ry)
    rightPanel:SetHeight(panelH)
    if rightPanel.lastFitH ~= panelH then
        rightPanel.lastFitH = panelH
        FitPanelRows(rightPanel)
    end
end

local function UpdateAllPositions()
    if not trackedTalentFrame or not trackedTalentFrame:IsShown() then
        if originalTalentScale and trackedTalentFrame then
            SafeSetTalentScale(originalTalentScale)
            originalTalentScale = nil
            appliedTalentScale = nil
        end
        if leftPanel then leftPanel:Hide() end
        if rightPanel then rightPanel:Hide() end
        return
    end

    if not originalTalentScale then
        originalTalentScale = trackedTalentFrame:GetScale()
    end

    local screenW = GetScreenWidth()
    local tfNativeW = trackedTalentFrame:GetWidth()
    local panelNeeded = PANEL_WIDTH + 4

    local maxScaleThatFits = (screenW - 2 * panelNeeded) / tfNativeW
    local targetScale = originalTalentScale
    if maxScaleThatFits < originalTalentScale then
        targetScale = maxScaleThatFits
        if targetScale < 0.5 then targetScale = 0.5 end
    end

    if not appliedTalentScale or math.abs(targetScale - appliedTalentScale) > 0.01 then
        SafeSetTalentScale(targetScale)
    end

    UpdateLeftPanelPosition()
    UpdateRightPanelPosition()
end

------------------------------------------------------------
-- Refresh all panels
------------------------------------------------------------
function RefreshAllPanels()
    if leftPanel and leftPanel:IsShown() then
        RefreshSidePanel(leftPanel, leftRows, EnrageWCLDungeonList, "mplus", MPLUS_COLOR, 0)
    end
    if rightPanel and rightPanel:IsShown() then
        RefreshSidePanel(rightPanel, rightRows, EnrageWCLBossList, "raid", RAID_COLOR, 0)
    end
    CheckTalentProfile(true)
end

-- Global for external calls
_G.WVT_RefreshBuilds = RefreshAllPanels

------------------------------------------------------------
-- Create panels
------------------------------------------------------------
local function CreatePanels()
    if not leftPanel then
        leftPanel, leftRows = CreateWCLSidePanel(
            "EnrageMPlusPanel",
            "|cFF66D9FFM+ Dungeons|r",
            MPLUS_COLOR,
            "|cFFAAAAAAWarcraftLogs M+ Season 1|r",
            "mplus"
        )

    end

    if not rightPanel then
        rightPanel, rightRows = CreateWCLSidePanel(
            "EnrageRaidPanel",
            "|cFFFF8800Raid Bosses|r",
            RAID_COLOR,
            "|cFFAAAAAAWarcraftLogs Heroic|r",
            "raid"
        )

    end
end

local function GetSavedPanelSource(kind)
    if EnrageDB and EnrageDB.global and type(EnrageDB.global.talentPanelSources) == "table" then
        local saved = EnrageDB.global.talentPanelSources[kind]
        if saved then return GetSourceByKey(saved).key end
    end

    local buildKey = RestoreLastLoadedBuildKey()
    if GetBuildKindFromKey(buildKey) == kind then
        return GetBuildSourceKey(buildKey)
    end

    return nil
end

local function RestorePanelDataSources()
    if leftPanel and leftPanel.SetDataSourceKey then
        leftPanel:SetDataSourceKey(GetSavedPanelSource("mplus") or leftPanel.dataSource or "wcl", false)
    end
    if rightPanel and rightPanel.SetDataSourceKey then
        rightPanel:SetDataSourceKey(GetSavedPanelSource("raid") or rightPanel.dataSource or "wcl", false)
    end
end

------------------------------------------------------------
-- Show / Hide
------------------------------------------------------------
local function ShowPanels(talentFrame)
    if EnrageDB and EnrageDB.global and EnrageDB.global.showTalentHelper == false then return end

    -- Restore lastLoadedKey from SavedVariables (survives reload)
    RestoreLastLoadedBuildKey()

    CreatePanels()
    RestorePanelDataSources()
    ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
    trackedTalentFrame = talentFrame

    -- Reset smooth positions so panels snap to correct position on first show
    smoothPos.lx = nil; smoothPos.ly = nil
    smoothPos.rx = nil; smoothPos.ry = nil

    leftPanel:Show()
    rightPanel:Show()

    UpdateAllPositions()
    RefreshAllPanels()

    -- OnUpdate for position tracking
    leftPanel:SetScript("OnUpdate", function(_, dt)
        leftPanel._elapsed = (leftPanel._elapsed or 0) + dt
        if leftPanel._elapsed < 0.05 then return end
        leftPanel._elapsed = 0
        UpdateAllPositions()
    end)
end

local function HidePanels()
    if originalTalentScale and trackedTalentFrame then
        SafeSetTalentScale(originalTalentScale)
        originalTalentScale = nil
        appliedTalentScale = nil
    end
    if leftPanel then leftPanel:Hide() end
    if rightPanel then rightPanel:Hide() end
    trackedTalentFrame = nil
end

------------------------------------------------------------
-- Hook talent window (taint-safe)
------------------------------------------------------------
local hooked = false

local function IsTalentTabVisible()
    if PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
        local tf = PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
        if tf and tf:IsShown() then return true end
    end
    if ClassTalentFrame and ClassTalentFrame:IsShown() then
        return true
    end
    return false
end

local function GetVisibleTalentFrame()
    if PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
        local tf = PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
        if tf and tf:IsShown() then return PlayerSpellsFrame end
    end
    if ClassTalentFrame and ClassTalentFrame:IsShown() then
        return ClassTalentFrame
    end
    return nil
end

local function OnTalentVisibilityChanged()
    if IsTalentTabVisible() then
        local frame = GetVisibleTalentFrame()
        if frame then ShowPanels(frame) end
    else
        HidePanels()
    end
end

local function TryHookAll()
    if hooked then return end

    if PlayerSpellsFrame then
        hooked = true
        local talentsFrame = PlayerSpellsFrame.TalentsTab or PlayerSpellsFrame.TalentsFrame
        if talentsFrame then
            talentsFrame:HookScript("OnShow", function()
                C_Timer.After(0.1, function() OnTalentVisibilityChanged() end)
            end)
            talentsFrame:HookScript("OnHide", function()
                HidePanels()
            end)
        end

        PlayerSpellsFrame:HookScript("OnHide", function()
            HidePanels()
        end)

        if IsTalentTabVisible() then
            C_Timer.After(0.1, function() OnTalentVisibilityChanged() end)
        end
    end

    if ClassTalentFrame and not hooked then
        hooked = true
        ClassTalentFrame:HookScript("OnShow", function()
            C_Timer.After(0.1, function() OnTalentVisibilityChanged() end)
        end)
        ClassTalentFrame:HookScript("OnHide", function()
            HidePanels()
        end)
    end
end

local evtFrame = CreateFrame("Frame")
evtFrame:RegisterEvent("ADDON_LOADED")
evtFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
evtFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
evtFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
evtFrame:RegisterEvent("ACTIVE_COMBAT_CONFIG_CHANGED")
evtFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
evtFrame:RegisterEvent("ZONE_CHANGED")
evtFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
evtFrame:RegisterEvent("CHALLENGE_MODE_START")
evtFrame:RegisterEvent("ENCOUNTER_START")
evtFrame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
evtFrame:RegisterEvent("UNIT_SPELLCAST_FAILED_QUIET")
-- UNIT_SPELLCAST_SUCCEEDED removed: fires for ALL spells, caused false positives
evtFrame:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 == "Blizzard_PlayerSpells" or arg1 == "Blizzard_ClassTalentUI" then
            C_Timer.After(0.2, TryHookAll)
            C_Timer.After(1.0, TryHookAll)
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        RestoreLastLoadedBuildKey()
        C_Timer.After(1.0, TryHookAll)
        C_Timer.After(1.5, function()
            ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            RestorePanelDataSources()
            RefreshAllPanels()
        end)
        C_Timer.After(3.0, function()
            ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            RestorePanelDataSources()
            RefreshAllPanels()
        end)
        ScheduleTalentProfileCheck(true, 2.0)
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        if arg1 == "player" then
            ClearLastLoadedBuildKey()
            RefreshAllPanels()
            ScheduleTalentProfileCheck(true, 1.0)
        end
    elseif event == "TRAIT_CONFIG_UPDATED" then
        C_Timer.After(0.3, function()
            if pendingLoadKey then
                -- Our load cast completed - apply the key now
                PersistLastLoadedBuildKey(pendingLoadKey)
                pendingLoadKey = nil
            else
                ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
            end
            -- Always refresh panels (Active/Load state may change)
            RestorePanelDataSources()
            RefreshAllPanels()
            CheckTalentProfile(true)
        end)
    elseif event == "ACTIVE_COMBAT_CONFIG_CHANGED" then
        -- This also fires while our own ImportTalentBuild commit is settling.
        -- Preserve the active marker for Enrage-loaded builds; clear it only
        -- when the player actually switches loadouts outside our load flow.
        local recentEnrageLoadKey = nil
        if (GetTime() - lastLoadTime) < 10 then
            recentEnrageLoadKey = pendingLoadKey or lastLoadedKey or _G.Enrage_LastLoadedBuild
        end
        if recentEnrageLoadKey and recentEnrageLoadKey ~= "" then
            PersistLastLoadedBuildKey(recentEnrageLoadKey)
        else
            ReconcileLastLoadedBuildFromCurrentTalents(nil, true)
        end
        C_Timer.After(0.3, function()
            RestorePanelDataSources()
            RefreshAllPanels()
            CheckTalentProfile(true)
        end)
    elseif event == "ZONE_CHANGED_NEW_AREA" or event == "ZONE_CHANGED" or event == "ZONE_CHANGED_INDOORS"
        or event == "CHALLENGE_MODE_START" or event == "ENCOUNTER_START" then
        ScheduleTalentProfileCheck(false, 2.0)
    elseif event == "UNIT_SPELLCAST_INTERRUPTED" or event == "UNIT_SPELLCAST_FAILED_QUIET" then
        if arg1 == "player" and pendingLoadKey and (GetTime() - lastLoadTime) < 10 then
            pendingLoadKey = nil
            print("|cFFFF4444[AkcQOL]|r Talent load was cancelled.")
            RefreshAllPanels()
        end
    end
end)

------------------------------------------------------------
-- Slash commands
------------------------------------------------------------
SLASH_WVBUILDS1 = "/akctalent"
SlashCmdList["WVBUILDS"] = function()
    CreatePanels()
    if leftPanel:IsShown() then
        HidePanels()
        return
    end
    if PlayerSpellsFrame and PlayerSpellsFrame:IsShown() then
        ShowPanels(PlayerSpellsFrame)
    elseif ClassTalentFrame and ClassTalentFrame:IsShown() then
        ShowPanels(ClassTalentFrame)
    else
        -- Standalone mode
        trackedTalentFrame = nil
        leftPanel:SetScript("OnUpdate", nil)
        leftPanel:SetSize(PANEL_WIDTH, 500)
        leftPanel:ClearAllPoints()
        leftPanel:SetPoint("CENTER", UIParent, "CENTER", -100, 0)
        leftPanel:Show()

        rightPanel:SetSize(PANEL_WIDTH, 500)
        rightPanel:ClearAllPoints()
        rightPanel:SetPoint("CENTER", UIParent, "CENTER", 100, 0)
        rightPanel:Show()

        RefreshAllPanels()
    end
end

_G.EnrageWCLPanel_Refresh = RefreshAllPanels

-- =========================================================================
-- M+ TIMER BAR NOTCHES
-- Shows +2 / +3 chest thresholds as countdown time (e.g. 12:00 / 6:00)
-- Timer bar is COUNTDOWN; +3 at 40% fill, +2 at 20% fill
-- =========================================================================
do
    local timerNotches = {}
    local lastTimerBar = nil
    local activeMplus = false

    local function CreateNotch(parent)
        local n = {}
        n.glow = parent:CreateTexture(nil, "OVERLAY", nil, 5)
        n.glow:SetTexture(FLAT_TEX)
        n.line = parent:CreateTexture(nil, "OVERLAY", nil, 6)
        n.line:SetTexture(FLAT_TEX)
        n.label = parent:CreateFontString(nil, "OVERLAY", nil, 7)
        n.label:SetFont(FONT_FACE, 8, FONT_FLAGS)
        return n
    end

    local function ShowNotch(n, bar, xPos, barH, r, g, b, labelText)
        n.line:SetSize(1, barH)
        n.line:ClearAllPoints()
        n.line:SetPoint("CENTER", bar, "LEFT", xPos, 0)
        n.line:SetVertexColor(r, g, b, 1)
        n.line:Show()
        n.glow:SetSize(5, barH)
        n.glow:ClearAllPoints()
        n.glow:SetPoint("CENTER", bar, "LEFT", xPos, 0)
        n.glow:SetVertexColor(r, g, b, 0.25)
        n.glow:Show()
        n.label:SetText(string.format("|cFF%02x%02x%02x%s|r",
            math.floor(r * 255), math.floor(g * 255), math.floor(b * 255), labelText))
        n.label:ClearAllPoints()
        n.label:SetPoint("TOP", n.line, "BOTTOM", 0, -1)
        n.label:Show()
    end

    local function HideNotch(n)
        if n.line then n.line:Hide() end
        if n.glow then n.glow:Hide() end
        if n.label then n.label:Hide() end
    end

    local function HideAll()
        for _, n in pairs(timerNotches) do HideNotch(n) end
    end

    local function CollectStatusBars(frame, out, depth)
        if not frame or depth > 10 then return end
        for _, kid in pairs({ frame:GetChildren() }) do
            if kid:IsObjectType("StatusBar") and kid:IsShown() then
                local _, mx = kid:GetMinMaxValues()
                if mx and mx > 0 then out[#out + 1] = kid end
            end
            CollectStatusBars(kid, out, depth + 1)
        end
    end

    -- Timer bar = smaller max (seconds, typically 1200-3600). Force bar has larger max.
    local function FindTimerBar()
        local allBars = {}
        if ScenarioBlocksFrame then CollectStatusBars(ScenarioBlocksFrame, allBars, 0) end
        if #allBars == 0 and ObjectiveTrackerFrame then CollectStatusBars(ObjectiveTrackerFrame, allBars, 0) end
        if #allBars == 0 then return nil end
        -- Prefer bar with max in the "time in seconds" range
        for _, bar in ipairs(allBars) do
            local _, mx = bar:GetMinMaxValues()
            if mx and mx >= 300 and mx <= 3600 then
                return bar
            end
        end
        -- Fallback: top-most bar on screen (timer usually above forces)
        table.sort(allBars, function(a, b)
            local _, ay = a:GetCenter(); local _, by = b:GetCenter()
            return (ay or 0) > (by or 0)
        end)
        return allBars[1]
    end

    local function FormatTime(sec)
        local m = math.floor(sec / 60)
        local s = math.floor(sec % 60)
        return string.format("%d:%02d", m, s)
    end

    -- Get M+ time info from WoW API (bar:GetValue() is unreliable for this)
    local function GetMplusTime()
        if not C_ChallengeMode then return nil, nil end
        local mapID = C_ChallengeMode.GetActiveChallengeMapID()
        if not mapID then return nil, nil end
        local _, _, timeLimit = C_ChallengeMode.GetMapUIInfo(mapID)
        if not timeLimit or timeLimit <= 0 then return nil, nil end

        local elapsed = 0
        if GetWorldElapsedTimers and GetWorldElapsedTime then
            local timers = { GetWorldElapsedTimers() }
            for _, timerID in ipairs(timers) do
                if timerID and timerID > 0 then
                    local _, e = GetWorldElapsedTime(timerID)
                    if e and e > 0 then elapsed = e; break end
                end
            end
        end

        local remaining = math.max(0, timeLimit - elapsed)
        return timeLimit, remaining
    end

    local function UpdateNotches()
        HideAll()
        if not activeMplus then return end
        local bar = FindTimerBar()
        if not bar then return end

        if lastTimerBar and lastTimerBar ~= bar then timerNotches = {} end
        lastTimerBar = bar

        local barW = bar:GetWidth()
        local barH = bar:GetHeight()
        if barW <= 0 or barH <= 0 then return end

        local timeLimit, remaining = GetMplusTime()
        if not timeLimit then return end

        -- +3 cutoff: 40% of timeLimit. +2 cutoff: 20%.
        -- Label = buffer time left before you drop out of that threshold.
        local thresholds = {
            { pct = 0.40, r = 0.2, g = 1.0, b = 0.3 },  -- green (+3)
            { pct = 0.20, r = 0.4, g = 0.7, b = 1.0 },  -- blue  (+2)
        }

        for ti, th in ipairs(thresholds) do
            if not timerNotches[ti] then
                timerNotches[ti] = CreateNotch(bar)
            end
            local cutoff = timeLimit * th.pct
            local buffer = math.max(0, remaining - cutoff)
            ShowNotch(timerNotches[ti], bar, th.pct * barW, barH,
                th.r, th.g, th.b, FormatTime(buffer))
        end
    end

    local refreshTicker = nil
    local function StopTicker()
        if refreshTicker then refreshTicker:Cancel(); refreshTicker = nil end
    end
    local function StartTicker()
        if refreshTicker then return end
        -- 1 second for smooth live countdown
        refreshTicker = C_Timer.NewTicker(1, function()
            if activeMplus then UpdateNotches() else StopTicker() end
        end)
    end

    local function CheckDungeon()
        local _, _, difficultyID = GetInstanceInfo()
        if difficultyID == 8 then
            activeMplus = true
            C_Timer.After(0.5, UpdateNotches)
            StartTicker()
        else
            activeMplus = false
            HideAll()
            StopTicker()
        end
    end

    local events = CreateFrame("Frame")
    events:RegisterEvent("CHALLENGE_MODE_START")
    events:RegisterEvent("CHALLENGE_MODE_COMPLETED")
    events:RegisterEvent("CHALLENGE_MODE_RESET")
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
    events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    events:SetScript("OnEvent", function(_, event)
        if event == "CHALLENGE_MODE_COMPLETED" or event == "CHALLENGE_MODE_RESET" then
            activeMplus = false
            HideAll()
            StopTicker()
            return
        end
        C_Timer.After(0.5, CheckDungeon)
    end)
end
