local ADDON_NAME, addon = ...

local Enrage = LibStub("AceAddon-3.0"):NewAddon(ADDON_NAME, "AceEvent-3.0", "AceComm-3.0", "AceSerializer-3.0")
addon.Enrage = Enrage

local COMM_PREFIX = "ERCD"

-- Capture the raw SavedVariables state before AceDB applies defaults. This
-- lets the opt-in defaults migration distinguish an existing installation
-- from a genuinely fresh one without changing current users' behavior.
local function CopyRawTable(source, seen)
    if type(source) ~= "table" then return source end
    seen = seen or {}
    if seen[source] then return seen[source] end

    local copy = {}
    seen[source] = copy
    for key, value in pairs(source) do
        copy[CopyRawTable(key, seen)] = CopyRawTable(value, seen)
    end
    return copy
end

local hadSavedDatabase = type(EnrageRaidCDDB) == "table" and next(EnrageRaidCDDB) ~= nil
local savedProfilesBeforeAceDB = hadSavedDatabase and CopyRawTable(EnrageRaidCDDB.profiles) or nil

local defaults = {
    profile = {
        enabled = false,
        showSelf = false,
        showOutsideRaid = false,
        showSpellName = false,
        showIcons = false,
        headerMouseover = false,
        readyCheckHelper = {
            enabled = false,
            locked = false,
            point = "CENTER",
            relPoint = "CENTER",
            xOfs = 0,
            yOfs = 150,
        },
        piAlert = {
            enabled = false,
            screen = false,
            sound = false,
            soundStyle = "arcane",
            soundVolume = 100,
            message = "you have pi",
            throttle = 2,
        },
        singleButtonAssistantKeybind = {
            enabled = false,
        },
        actionBarMouseover = {
            enabled = false,
            minAlpha = 0,
            maxAlpha = 1,
            hoverDelay = 0.7,
            alwaysShowInCombat = false,
            alwaysShowInEditMode = false,
            bars = {
                main = false,
                bottomLeft = false,
                bottomRight = false,
                right = false,
                left = false,
                bar5 = false,
                bar6 = false,
                bar7 = false,
                pet = false,
                stance = false,
            },
        },
        personalLocator = {
            player = {
                enabled = false,
                combatOnly = false,
                style = "crosshair",
                size = 52,
                thickness = 3,
                outline = 2,
                gap = 8,
                offsetX = 0,
                offsetY = -11,
                color = { r = 0.20, g = 1.00, b = 0.35, a = 0.95 },
            },
            cursor = {
                enabled = false,
                combatOnly = false,
                size = 52,
                thickness = 3,
                outline = 2,
                dot = false,
                pulse = false,
                color = { r = 1.00, g = 0.82, b = 0.20, a = 0.95 },
            },
        },
        nextPanelID = 2,
        panels = {
            ["1"] = {
                name = "Raid CDs",
                locked = false,
                headerVisible = false,
                trackedSpells = {},
                barWidth = 200,
                barHeight = 20,
                barGrowUp = false,
                barSpacing = 2,
                point = "CENTER",
                relPoint = "CENTER",
                xOfs = 0,
                yOfs = 0,
            },
        },
    },
}

addon.ActiveCooldowns = {}
addon.Roster = {}
addon.InferredSpecs = {} -- Specs inferred from Tier 2 casts for players without the addon.
addon.inCombat = false
addon.CDCache = {}
addon.OwnCooldownSyncState = {}
addon.panelsDirty = true

function addon:GetSpecBasedCD(spellID, specID)
    local info = addon.RaidCDData[spellID]
    if not info then return 0 end
    if info.specCD and specID and info.specCD[specID] then
        return info.specCD[specID]
    end
    return info.baseCD
end

-- Migrate the legacy single-panel profile into the multi-panel format.
local function MigrateToMultiPanel(db)
    local profile = db.profile
    -- Legacy profiles stored trackedSpells at the profile root.
    if profile.trackedSpells then
        profile.panels = profile.panels or {}
        profile.panels["1"] = {
            name = "Raid CDs",
            locked = profile.locked or false,
            trackedSpells = profile.trackedSpells,
            barWidth = profile.barWidth or 200,
            barHeight = profile.barHeight or 20,
            barGrowUp = profile.barGrowUp or false,
            barSpacing = profile.barSpacing or 2,
            point = profile.point or "CENTER",
            relPoint = profile.relPoint or "CENTER",
            xOfs = profile.xOfs or 0,
            yOfs = profile.yOfs or 0,
        }
        profile.nextPanelID = 2
        -- Remove legacy root-level panel settings after migration.
        profile.trackedSpells = nil
        profile.locked = nil
        profile.barWidth = nil
        profile.barHeight = nil
        profile.barGrowUp = nil
        profile.barSpacing = nil
        profile.point = nil
        profile.relPoint = nil
        profile.xOfs = nil
        profile.yOfs = nil
    end
end

local function ApplyOptInDefaultsMigration(db)
    local profile = db.profile
    if profile.optInDefaultsV1 then return false end

    local profileName = db.GetCurrentProfile and db:GetCurrentProfile() or "Default"
    local rawProfile = savedProfilesBeforeAceDB and savedProfilesBeforeAceDB[profileName]
    local isExistingProfile = hadSavedDatabase and type(rawProfile) == "table"

    if isExistingProfile then
        -- Preserve the previous defaults for existing installations only when
        -- that setting was never explicitly saved by the user.
        if rawProfile.enabled == nil then profile.enabled = true end
        if rawProfile.showSelf == nil then profile.showSelf = true end
        if rawProfile.showSpellName == nil then profile.showSpellName = true end
        if rawProfile.showIcons == nil then profile.showIcons = true end
        if rawProfile.headerMouseover == nil then profile.headerMouseover = true end

        local rawReady = type(rawProfile.readyCheckHelper) == "table" and rawProfile.readyCheckHelper or {}
        if rawReady.enabled == nil then profile.readyCheckHelper.enabled = true end

        local rawPI = type(rawProfile.piAlert) == "table" and rawProfile.piAlert or {}
        if rawPI.enabled == nil then profile.piAlert.enabled = true end
        if rawPI.screen == nil then profile.piAlert.screen = true end
        if rawPI.sound == nil then profile.piAlert.sound = true end

        local rawAssistant = type(rawProfile.singleButtonAssistantKeybind) == "table" and rawProfile.singleButtonAssistantKeybind or {}
        if rawAssistant.enabled == nil then profile.singleButtonAssistantKeybind.enabled = true end

        local rawMouseover = type(rawProfile.actionBarMouseover) == "table" and rawProfile.actionBarMouseover or {}
        if rawMouseover.alwaysShowInCombat == nil then profile.actionBarMouseover.alwaysShowInCombat = true end
        if rawMouseover.alwaysShowInEditMode == nil then profile.actionBarMouseover.alwaysShowInEditMode = true end
    end

    profile.optInDefaultsV1 = true
    return isExistingProfile
end

function Enrage:OnInitialize()
    self.db = LibStub("AceDB-3.0"):New("EnrageRaidCDDB", defaults, true)

    MigrateToMultiPanel(self.db)
    local preserveLegacySpellDefaults = ApplyOptInDefaultsMigration(self.db)

    -- Existing installs retain the original default spell selections. Fresh
    -- installs start with no selected cooldowns and opt in from panel settings.
    if preserveLegacySpellDefaults then
        for _, panel in pairs(self.db.profile.panels) do
            if next(panel.trackedSpells) == nil then
                for spellID, info in pairs(addon.RaidCDData) do
                    panel.trackedSpells[spellID] = info.trackByDefault
                end
            end
        end
    end

    addon:RestoreCooldowns()
    self:RegisterComm(COMM_PREFIX)
    addon:SetupConfig()
end

-- WoW 12.0: RegisterEvent("UNIT_SPELLCAST_*") is unreliable for party/raid units.
-- Match the M33kAuras/WeakAuras pattern by giving each unit its own
-- RegisterUnitEvent frame; grouped vararg registration can silently fail.
local castWatchers = {}
local activeCastUnits = {}
local globalCastWatcherRegistered = false
local IsGroupUnit

local function MakeCastWatcher(unit)
    local safeUnit = tostring(unit):gsub("[^%w_]", "_")
    local f = CreateFrame("Frame", "EnrageCastWatcher_" .. safeUnit)
    f:SetScript("OnEvent", function(_, event, unit, castGUID, spellID)
        Enrage:UNIT_SPELLCAST_SUCCEEDED(event, unit, castGUID, spellID)
    end)
    return f
end

-- LibOpenRaid/ExBoss uses this global path for other players' cooldowns.
-- Blizzard sometimes passes the cast on a token like "target" / "nameplateX"
-- instead of "raid12", so RegisterUnitEvent alone may not be enough.
local globalCastWatcher = CreateFrame("Frame", "EnrageGlobalCastWatcher")
globalCastWatcher:SetScript("OnEvent", function(_, event, unit, castGUID, spellID)
    if unit == "player" then return end
    if IsGroupUnit and not IsGroupUnit(unit) then return end
    Enrage:UNIT_SPELLCAST_SUCCEEDED(event, unit, castGUID, spellID)
end)

local function UpdateCastWatcher()
    local wanted = { player = true }
    if IsInRaid() then
        for i = 1, 40 do
            wanted["raid" .. i] = true
        end
    else
        for i = 1, 4 do
            wanted["party" .. i] = true
        end
    end

    for unit in pairs(activeCastUnits) do
        if not wanted[unit] and castWatchers[unit] then
            castWatchers[unit]:UnregisterEvent("UNIT_SPELLCAST_SUCCEEDED")
            activeCastUnits[unit] = nil
        end
    end

    for unit in pairs(wanted) do
        if not castWatchers[unit] then
            castWatchers[unit] = MakeCastWatcher(unit)
        end
        castWatchers[unit]:UnregisterEvent("UNIT_SPELLCAST_SUCCEEDED")
        castWatchers[unit]:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", unit)
        activeCastUnits[unit] = true
    end

    if not globalCastWatcherRegistered then
        globalCastWatcher:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
        globalCastWatcherRegistered = true
    end
end
addon.UpdateCastWatcher = UpdateCastWatcher
addon.IsGlobalCastWatcherRegistered = function() return globalCastWatcherRegistered end

function Enrage:OnEnable()
    -- Listen to UNIT_SPELLCAST_SUCCEEDED with explicit per-unit frames.
    UpdateCastWatcher()

    -- CLEU registration is synced against the current restriction state.
    if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    if addon.RegisterExternalCooldownSources then addon:RegisterExternalCooldownSources() end
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        pcall(C_ChatInfo.RegisterAddonMessagePrefix, "oRA")
        pcall(C_ChatInfo.RegisterAddonMessagePrefix, "VIGIL")
        pcall(C_ChatInfo.RegisterAddonMessagePrefix, "OmniCD")
    end

    self:RegisterEvent("GROUP_ROSTER_UPDATE")
    self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    self:RegisterEvent("TRAIT_CONFIG_UPDATED")
    self:RegisterEvent("SPELL_UPDATE_COOLDOWN")
    self:RegisterEvent("PLAYER_REGEN_DISABLED")
    self:RegisterEvent("PLAYER_REGEN_ENABLED")
    self:RegisterEvent("PLAYER_LOGOUT")
    self:RegisterEvent("ENCOUNTER_START")
    self:RegisterEvent("ENCOUNTER_END")
    self:RegisterEvent("CHALLENGE_MODE_START")
    self:RegisterEvent("CHALLENGE_MODE_COMPLETED")
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self:RegisterEvent("CHAT_MSG_ADDON")

    addon:CreateDisplay()
    if addon.InitializePIAlert then addon:InitializePIAlert() end
    if self.db.profile.readyCheckHelper.enabled and addon.InitializeReadyCheckHelper then
        addon:InitializeReadyCheckHelper()
    end
    if addon.InitializeActionBarMouseover then addon:InitializeActionBarMouseover() end
    if addon.InitializePersonalLocator then addon:InitializePersonalLocator() end
    self.ticker = C_Timer.NewTicker(0.1, function() addon:TickPanels() end)
    self.cleuTicker = C_Timer.NewTicker(2, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
        if addon.RegisterExternalCooldownSources then addon:RegisterExternalCooldownSources() end
    end)
    C_Timer.After(2, function()
        addon:UpdateCDCache()
        addon:SendJoin()
        if addon.RegisterExternalCooldownSources then addon:RegisterExternalCooldownSources(true) end
    end)
end

function Enrage:OnDisable()
    if self.ticker then
        self.ticker:Cancel()
        self.ticker = nil
    end
    if self.cleuTicker then
        self.cleuTicker:Cancel()
        self.cleuTicker = nil
    end
    if addon.DisablePIAlert then addon:DisablePIAlert() end
    if addon.DisableReadyCheckHelper then addon:DisableReadyCheckHelper() end
    if addon.DisableActionBarMouseover then addon:DisableActionBarMouseover() end
    if addon.DisablePersonalLocator then addon:DisablePersonalLocator() end
    addon:HideDisplay()
end

function Enrage:PLAYER_LOGOUT()
    addon:SaveCooldowns()
end

function Enrage:ENCOUNTER_START()
    -- Encounter/M+ restrictions can change dynamically; do not force-disable
    -- addonless fallback when the client still allows CLEU.
    if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    C_Timer.After(0.5, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

function Enrage:ENCOUNTER_END(_, encounterID, encounterName, difficultyID, groupSize, success)
    if success == 1 then
        wipe(addon.ActiveCooldowns)
        addon:MarkPanelsDirty()
    end
    -- Encounter state can change CLEU availability; resync shortly after it ends.
    C_Timer.After(1, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

function Enrage:CHALLENGE_MODE_START()
    -- CLEU is not always unavailable in Mythic+; keep it synced so ground cooldowns
    -- such as AMZ/SLT can still be detected when the client permits it.
    if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    C_Timer.After(1, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

function Enrage:CHALLENGE_MODE_COMPLETED()
    -- Resync CLEU after the Mythic+ run completes.
    C_Timer.After(1, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

function Enrage:PLAYER_ENTERING_WORLD()
    -- After loading screens, resync CLEU for the new instance context.
    C_Timer.After(2, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

local SafeUnitName

-- Remove inferred specs for players no longer in the current group.
local function PruneInferredSpecs()
    if not next(addon.InferredSpecs) then return end
    local active = {}
    if IsInRaid() then
        for i = 1, 40 do
            local name = SafeUnitName("raid" .. i)
            if name then active[name] = true end
        end
    elseif IsInGroup() then
        for i = 1, 4 do
            local name = SafeUnitName("party" .. i)
            if name then active[name] = true end
        end
    end
    for name in pairs(addon.InferredSpecs) do
        if not active[name] then
            addon.InferredSpecs[name] = nil
        end
    end
end

-- WoW 12.0: spellID can become a secret value in tainted execution paths.
local function IsSecret(v)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, v)
        if ok and isSecret == true then return true end
    end
    return type(v) == "nil"
end

local function SafeUnitBool(func, unit)
    if type(func) ~= "function" then return false end
    local ok, value = pcall(func, unit)
    if not ok or IsSecret(value) then return false end
    return value == true
end

function SafeUnitName(unit)
    local ok, name = pcall(UnitName, unit)
    if ok and name and not IsSecret(name) then return name end
    return nil
end

IsGroupUnit = function(unit)
    if type(unit) ~= "string" then return false end
    if SafeUnitBool(UnitExists, unit) and (SafeUnitBool(UnitInParty, unit) or SafeUnitBool(UnitInRaid, unit)) then
        return true
    end
    if unit == "party1" or unit == "party2" or unit == "party3" or unit == "party4" then
        return true
    end
    return unit:match("^raid%d+$") ~= nil
end

local SPELL_ALIASES = {
    [145629] = 51052, -- Anti-Magic Zone area aura/dummy -> player cooldown spell
    [209426] = 196718, -- Darkness buff/area -> player cooldown spell
    [81782]  = 62618, -- Power Word: Barrier area aura -> player cooldown spell
}

function addon:CanonicalizeSpellID(spellID)
    spellID = tonumber(spellID)
    if not spellID then return nil end
    return SPELL_ALIASES[spellID] or spellID
end

-- Realm-stripped name
local function StripRealm(name)
    if not name then return name end
    return name:match("^([^%-]+)") or name
end

-- Resolve a group unit token from a GUID, then read its class.
local function ResolveClassFromGUID(guid)
    if not guid then return "UNKNOWN" end
    if IsInRaid() then
        for i = 1, 40 do
            local u = "raid" .. i
            local ok, unitGUID = pcall(UnitGUID, u)
            if ok and not IsSecret(unitGUID) and unitGUID == guid then
                local _, c = UnitClass(u)
                return c or "UNKNOWN"
            end
        end
    end
    if IsInGroup() then
        for i = 1, 4 do
            local u = "party" .. i
            local ok, unitGUID = pcall(UnitGUID, u)
            if ok and not IsSecret(unitGUID) and unitGUID == guid then
                local _, c = UnitClass(u)
                return c or "UNKNOWN"
            end
        end
    end
    return "UNKNOWN"
end

local function ResolveNameFromGUID(guid)
    if not guid then return nil end
    if IsInRaid() then
        for i = 1, 40 do
            local u = "raid" .. i
            local ok, unitGUID = pcall(UnitGUID, u)
            if ok and not IsSecret(unitGUID) and unitGUID == guid then
                return SafeUnitName(u)
            end
        end
    end
    if IsInGroup() then
        for i = 1, 4 do
            local u = "party" .. i
            local ok, unitGUID = pcall(UnitGUID, u)
            if ok and not IsSecret(unitGUID) and unitGUID == guid then
                return SafeUnitName(u)
            end
        end
    end
    local ok, playerGUID = pcall(UnitGUID, "player")
    if ok and not IsSecret(playerGUID) and playerGUID == guid then
        return SafeUnitName("player")
    end
    return nil
end

local function IsGroupMemberName(name)
    local cleanName = StripRealm(name)
    if not cleanName or cleanName == "" then return false end
    if cleanName == SafeUnitName("player") then return true end
    if IsInRaid() then
        for i = 1, 40 do
            if SafeUnitName("raid" .. i) == cleanName then return true end
        end
    elseif IsInGroup() then
        for i = 1, 4 do
            if SafeUnitName("party" .. i) == cleanName then return true end
        end
    end
    return false
end

local function ResolveNameFromUnitOrName(unitOrName)
    if type(unitOrName) ~= "string" or unitOrName == "" then return nil end
    if IsSecret(unitOrName) then return nil end
    if unitOrName:match("^Player%-") then
        return ResolveNameFromGUID(unitOrName)
    end
    if SafeUnitBool(UnitExists, unitOrName) then
        local name
        local ok, fullName = pcall(GetUnitName, unitOrName, true)
        if ok and fullName and not IsSecret(fullName) then
            name = fullName
        else
            local unitName = SafeUnitName(unitOrName)
            if unitName and not IsSecret(unitName) then name = unitName end
        end
        return StripRealm(name)
    end
    return StripRealm(unitOrName)
end

local function ResolveClassFromName(name)
    local cleanName = StripRealm(name)
    if not cleanName or cleanName == "" then return "UNKNOWN" end

    local rosterInfo = addon.Roster and addon.Roster[cleanName]
    if rosterInfo and rosterInfo.class then return rosterInfo.class end

    local unit = addon.GetUnitForName and addon:GetUnitForName(cleanName)
    if unit and SafeUnitBool(UnitExists, unit) then
        local _, class = UnitClass(unit)
        if class and not IsSecret(class) then return class end
    end

    if cleanName == SafeUnitName("player") then
        local _, class = UnitClass("player")
        if class and not IsSecret(class) then return class end
    end

    return "UNKNOWN"
end

local function ClearCooldown(playerName, spellID)
    if not playerName or not spellID then return end
    local key = playerName .. "-" .. spellID
    if addon.ActiveCooldowns[key] then
        addon.ActiveCooldowns[key] = nil
        addon:MarkPanelsDirty()
    end
end

local function StartExternalCooldown(source, senderName, spellID, remaining, fullDuration)
    local cleanName = ResolveNameFromUnitOrName(senderName)
    if not cleanName or cleanName == "" or cleanName == UNKNOWNOBJECT then return end
    if cleanName == SafeUnitName("player") then return end
    if not IsGroupMemberName(cleanName) then return end

    spellID = tonumber(spellID)
    if not spellID then return end

    local canonicalSpellID = SPELL_ALIASES[spellID] or spellID
    local info = addon.RaidCDData[canonicalSpellID]
    if not info then return end

    remaining = tonumber(remaining)
    if not remaining then return end

    if remaining <= 1.5 then
        ClearCooldown(cleanName, canonicalSpellID)
        return
    end

    fullDuration = tonumber(fullDuration) or info.baseCD or remaining
    if fullDuration < remaining then fullDuration = remaining end

    addon:StartCooldown(cleanName, ResolveClassFromName(cleanName), canonicalSpellID, fullDuration, remaining)
end

local function SafeBand(value, mask)
    if type(value) ~= "number" or IsSecret(value) then return 0 end
    return bit.band(value, mask)
end

local function IsTrackedSpellKnownByPlayer(spellID)
    if IsSpellKnown and IsSpellKnown(spellID) then return true end
    if C_Spell and C_Spell.IsSpellKnown then
        local ok, known = pcall(C_Spell.IsSpellKnown, spellID)
        if ok and known then return true end
    end
    if IsPlayerSpell then
        local ok, known = pcall(IsPlayerSpell, spellID)
        if ok and known then return true end
    end
    return false
end

function addon:IsOwnTrackedSpellKnown(spellID)
    return IsTrackedSpellKnownByPlayer(spellID)
end

local function ReadCooldownDurationObjectSeconds(durationObject)
    if not durationObject then return nil end
    if type(durationObject) == "number" then
        return durationObject > 0 and durationObject / 1000 or nil
    end
    if type(durationObject) == "table" or type(durationObject) == "userdata" then
        if durationObject.HasSecretValues then
            local okSecret, hasSecret = pcall(durationObject.HasSecretValues, durationObject)
            if okSecret and hasSecret then return nil end
        end
        if durationObject.GetTotalDuration then
            local ok, seconds = pcall(durationObject.GetTotalDuration, durationObject, "RealTime")
            if ok and type(seconds) == "number" and seconds > 0 then return seconds end
        end
        if durationObject.GetSeconds then
            local ok, seconds = pcall(durationObject.GetSeconds, durationObject)
            if ok and type(seconds) == "number" and seconds > 0 then return seconds end
        end
    end
    return nil
end

function addon:GetOwnSpellCooldownDuration(spellID, specID)
    spellID = self:CanonicalizeSpellID(spellID)
    if not spellID then return 0 end

    if C_Spell and C_Spell.GetSpellCooldownDuration then
        local ok, durationObject = pcall(C_Spell.GetSpellCooldownDuration, spellID, true)
        if ok then
            local seconds = ReadCooldownDurationObjectSeconds(durationObject)
            if seconds and seconds > 1.5 then
                self.CDCache[spellID] = seconds
                return seconds
            end
        end
    end

    if C_Spell and C_Spell.GetSpellCooldown then
        local ok, cdInfo = pcall(C_Spell.GetSpellCooldown, spellID)
        if ok and cdInfo and not IsSecret(cdInfo.duration) and cdInfo.duration and cdInfo.duration > 1.5 then
            self.CDCache[spellID] = cdInfo.duration
            return cdInfo.duration
        end
    end

    return self.CDCache[spellID] or self:GetSpecBasedCD(spellID, specID)
end

function addon:GetOwnCooldownSnapshot(spellID)
    spellID = self:CanonicalizeSpellID(spellID)
    if not spellID or not C_Spell or not C_Spell.GetSpellCooldown then return nil end

    local ok, cdInfo = pcall(C_Spell.GetSpellCooldown, spellID)
    if not ok or not cdInfo then return nil end
    if IsSecret(cdInfo.startTime) or IsSecret(cdInfo.duration) then return nil end
    if not cdInfo.startTime or not cdInfo.duration or cdInfo.startTime <= 0 or cdInfo.duration <= 1.5 then return nil end

    local remaining = cdInfo.startTime + cdInfo.duration - GetTime()
    if remaining <= 1.5 then return nil end

    return cdInfo.duration, remaining
end

function addon:PublishOwnCooldown(spellID, reason, force)
    spellID = self:CanonicalizeSpellID(spellID)
    local info = spellID and self.RaidCDData[spellID]
    if not info then return false end
    if not IsTrackedSpellKnownByPlayer(spellID) then return false end

    local duration, remaining = self:GetOwnCooldownSnapshot(spellID)
    if not duration or not remaining then return false end

    local playerName = SafeUnitName("player")
    if not playerName then return false end
    local _, playerClass = UnitClass("player")

    self:StartCooldown(playerName, playerClass or info.class or "UNKNOWN", spellID, duration, remaining)

    local now = GetTime()
    local state = self.OwnCooldownSyncState[spellID] or {}
    local shouldSend = force
        or not state.sentAt
        or (now - state.sentAt) > 1.5
        or not state.remaining
        or math.abs((state.remaining or 0) - remaining) > 1.0

    if shouldSend then
        self:BroadcastCast(spellID, duration, remaining)
        state.sentAt = now
        state.duration = duration
        state.remaining = remaining
        state.reason = reason
        self.OwnCooldownSyncState[spellID] = state
    end

    return true
end

function addon:ScanOwnCooldownsForBroadcast(reason)
    for spellID in pairs(self.RaidCDData or {}) do
        self:PublishOwnCooldown(spellID, reason, false)
    end
end

-- Shared Tier 2 handling used by both UNIT events and CLEU.
local function ProcessFallbackCast(senderName, senderClass, spellID, info)
    if not senderName or senderName == "" or senderName == UNKNOWNOBJECT then return end
    if senderName == SafeUnitName("player") then return end -- Self casts are handled by Tier 1.

    local duration = info.baseCD
    local rosterInfo = addon.Roster[senderName]
    if rosterInfo then
        senderClass = rosterInfo.class or senderClass
        if rosterInfo.cdModifiers and rosterInfo.cdModifiers[spellID] then
            duration = rosterInfo.cdModifiers[spellID]
        elseif info.specCD and rosterInfo.spec and info.specCD[rosterInfo.spec] then
            duration = info.specCD[rosterInfo.spec]
        end
    end

    local existing = addon.ActiveCooldowns[senderName .. "-" .. spellID]
    if existing and existing.expirationTime and existing.expirationTime > GetTime() then
        return
    end

    -- Spec inference
    if not rosterInfo and info.spec ~= 0 then
        addon.InferredSpecs[senderName] = info.spec
    end

    addon:StartCooldown(senderName, senderClass or "UNKNOWN", spellID, duration)
end

function Enrage:UNIT_SPELLCAST_SUCCEEDED(_, unit, _, spellID)
    if IsSecret(spellID) then return end

    local canonicalSpellID = SPELL_ALIASES[spellID] or spellID
    local info = addon.RaidCDData[canonicalSpellID]
    if not info then return end

    -- Tier 1: for the player, read the local cooldown and broadcast it.
    -- Party cast events are restricted in 12.x, so this is the most reliable path.
    if unit == "player" then
        C_Timer.After(0.05, function() addon:PublishOwnCooldown(canonicalSpellID, "unit", true) end)
        C_Timer.After(0.35, function() addon:PublishOwnCooldown(canonicalSpellID, "unit-late", false) end)
        return
    end

    -- Tier 2 via UNIT events: filter to group units, then use shared handling.
    if not IsGroupUnit(unit) then return end
    local senderName = SafeUnitName(unit)
    if IsSecret(senderName) then return end
    local _, senderClass = UnitClass(unit)
    if IsSecret(senderClass) then senderClass = "UNKNOWN" end
    ProcessFallbackCast(senderName, senderClass, canonicalSpellID, info)
end

-- ========================================================================
-- CLEU Tier 2, similar to the approach used by combat log addons.
-- WoW 12.0 can throw ADDON_ACTION_FORBIDDEN for COMBAT_LOG_EVENT_UNFILTERED
-- during some encounter/Mythic+ restriction windows. Register conditionally
-- and keep it available during out-of-combat windows when the client permits it.
-- ========================================================================
local cleuFrame = CreateFrame("Frame", "EnrageCleuWatcher")
local cleuRegistered = false

local TRACKED_CLEU_SUBEVENTS = {
    SPELL_CAST_SUCCESS = true,
    SPELL_SUMMON = true,
    SPELL_CREATE = true,
    SPELL_AURA_APPLIED = true,
    SPELL_AURA_REFRESH = true,
}

local AFFILIATION_MASK = bit.bor(
    COMBATLOG_OBJECT_AFFILIATION_PARTY or 0x2,
    COMBATLOG_OBJECT_AFFILIATION_RAID or 0x4
)

cleuFrame:SetScript("OnEvent", function()
    local _, subevent, _, sourceGUID, sourceName, sourceFlags, _, destGUID, destName, destFlags, _, spellID, spellName = CombatLogGetCurrentEventInfo()
    if addon.HandlePICombatLogEvent then
        addon:HandlePICombatLogEvent(subevent, destGUID, spellID, spellName)
    end

    if not TRACKED_CLEU_SUBEVENTS[subevent] then return end
    if not sourceName or not spellID or not sourceFlags then return end

    if IsSecret(spellID) or IsSecret(sourceName) or IsSecret(sourceFlags) then return end

    local cleanName = StripRealm(sourceName)
    if SafeBand(sourceFlags, AFFILIATION_MASK) == 0 and not IsGroupMemberName(cleanName) then
        return
    end

    local canonicalSpellID = SPELL_ALIASES[spellID] or spellID
    local info = addon.RaidCDData[canonicalSpellID]
    if not info then return end

    local senderClass = ResolveClassFromGUID(sourceGUID)
    ProcessFallbackCast(cleanName, senderClass, canonicalSpellID, info)
end)

-- CLEU register/unregister helpers guarded by the restriction check.
local function IsCleuRestricted()
    if C_CombatLog and C_CombatLog.IsCombatLogRestricted then
        local ok, restricted = pcall(C_CombatLog.IsCombatLogRestricted)
        if not ok or IsSecret(restricted) then return true end
        return restricted == true
    end
    -- If the restriction API is unavailable, assume CLEU is allowed.
    return false
end

local function TryRegisterCleu()
    if cleuRegistered then return end
    if IsCleuRestricted() then return end
    local ok = pcall(cleuFrame.RegisterEvent, cleuFrame, "COMBAT_LOG_EVENT_UNFILTERED")
    if ok then cleuRegistered = true end
end

local function UnregisterCleu()
    if not cleuRegistered then return end
    pcall(cleuFrame.UnregisterEvent, cleuFrame, "COMBAT_LOG_EVENT_UNFILTERED")
    cleuRegistered = false
end

local function SyncCleuRegistration()
    if IsCleuRestricted() then
        UnregisterCleu()
    else
        TryRegisterCleu()
    end
end

addon.TryRegisterCleu = TryRegisterCleu
addon.UnregisterCleu = UnregisterCleu
addon.SyncCleuRegistration = SyncCleuRegistration
addon.IsCleuRestricted = IsCleuRestricted
addon.IsCleuRegistered = function() return cleuRegistered end

function addon.OpenRaidCooldownUpdate(unitID, spellID, cooldownInfo)
    local openRaidLib = addon.OpenRaidLib
    local senderName = ResolveNameFromUnitOrName(unitID)
    if not senderName then return end

    local isReady, timeLeft, cooldownDuration
    if openRaidLib and openRaidLib.GetCooldownStatusFromCooldownInfo then
        local ok, percent, charges, minValue, maxValue, currentValue
        ok, isReady, percent, timeLeft, charges, minValue, maxValue, currentValue, cooldownDuration = pcall(openRaidLib.GetCooldownStatusFromCooldownInfo, cooldownInfo)
        if not ok then return end
    elseif type(cooldownInfo) == "table" then
        timeLeft = tonumber(cooldownInfo[1])
        cooldownDuration = tonumber(cooldownInfo[4])
        isReady = timeLeft and timeLeft <= 1.5
    end

    if isReady then
        StartExternalCooldown("LibOpenRaid", senderName, spellID, 0, cooldownDuration)
    else
        StartExternalCooldown("LibOpenRaid", senderName, spellID, timeLeft, cooldownDuration)
    end
end

function addon.OpenRaidCooldownListUpdate(unitID, unitCooldowns)
    if type(unitCooldowns) ~= "table" then return end
    for spellID, cooldownInfo in pairs(unitCooldowns) do
        addon.OpenRaidCooldownUpdate(unitID, spellID, cooldownInfo)
    end
end

function addon:RegisterExternalCooldownSources(requestData)
    if not self.OpenRaidCallbacksRegistered and LibStub and LibStub.GetLibrary then
        local openRaidLib = LibStub:GetLibrary("LibOpenRaid-1.0", true)
        if openRaidLib and openRaidLib.RegisterCallback then
            if not self.OpenRaidCooldownUpdateRegistered then
                local okUpdate, resultUpdate = pcall(openRaidLib.RegisterCallback, self, "CooldownUpdate", "OpenRaidCooldownUpdate")
                self.OpenRaidCooldownUpdateRegistered = okUpdate and resultUpdate == true
            end
            if not self.OpenRaidCooldownListRegistered then
                local okList, resultList = pcall(openRaidLib.RegisterCallback, self, "CooldownListUpdate", "OpenRaidCooldownListUpdate")
                self.OpenRaidCooldownListRegistered = okList and resultList == true
            end
            if self.OpenRaidCooldownUpdateRegistered or self.OpenRaidCooldownListRegistered then
                self.OpenRaidLib = openRaidLib
                self.OpenRaidCallbacksRegistered = true
            end
        end
    end

    if requestData and self.OpenRaidCallbacksRegistered and self.OpenRaidLib then
        local openRaidLib = self.OpenRaidLib
        if openRaidLib.RequestAllData then pcall(openRaidLib.RequestAllData) end
        if openRaidLib.RequestCooldownInfo then
            for spellID in pairs(addon.RaidCDData or {}) do
                pcall(openRaidLib.RequestCooldownInfo, spellID)
            end
        end
    end
end

local function HandleVigilAddonMessage(message, sender)
    local kind, body = strsplit(":", message or "", 2)
    if kind ~= "C" or not body then return end

    local spellID, cooldown = strsplit(":", body)
    StartExternalCooldown("Vigil", sender, spellID, cooldown, cooldown)
end

local function HandleOmniCDAddonMessage(message, sender)
    local header, guid, body = string.match(message or "", "(.-),(.-),(.+)")
    if header ~= "CD" or not guid or not body then return end

    local libDeflate = LibStub and LibStub:GetLibrary("LibDeflate", true)
    if not libDeflate or not libDeflate.DecodeForWoWAddonChannel or not libDeflate.DecompressDeflate then return end

    local okDecode, compressedData = pcall(libDeflate.DecodeForWoWAddonChannel, libDeflate, body)
    if not okDecode or not compressedData then return end

    local okDecompress, serialized = pcall(libDeflate.DecompressDeflate, libDeflate, compressedData)
    if not okDecompress or not serialized then return end

    local sourceName = ResolveNameFromGUID(guid) or sender
    while serialized do
        local spellID, duration, remaining, modRate, charges, rest = strsplit(",", serialized, 6)
        serialized = rest
        if spellID and duration and remaining then
            StartExternalCooldown("OmniCD", sourceName, spellID, remaining, duration)
        else
            break
        end
    end
end

function Enrage:CHAT_MSG_ADDON(_, prefix, message, distribution, sender)
    if IsSecret(message) or IsSecret(sender) then return end

    if prefix == "oRA" then
        local msgType, spellID, cooldown = strsplit(" ", message or "")
        if msgType ~= "CooldownUpdate" then return end

        StartExternalCooldown("oRA3", sender, spellID, cooldown)
    elseif prefix == "VIGIL" then
        HandleVigilAddonMessage(message, sender)
    elseif prefix == "OmniCD" then
        HandleOmniCDAddonMessage(message, sender)
    end
end

function Enrage:SPELL_UPDATE_COOLDOWN()
    if self.ownCooldownScanQueued then return end
    self.ownCooldownScanQueued = true
    C_Timer.After(0.05, function()
        self.ownCooldownScanQueued = false
        addon:ScanOwnCooldownsForBroadcast("spell-update")
    end)
end

function Enrage:PLAYER_REGEN_DISABLED()
    addon.inCombat = true
    if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    C_Timer.After(0.5, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

function Enrage:PLAYER_REGEN_ENABLED()
    addon.inCombat = false
    addon:UpdateCDCache()
    -- Send any Join message that was delayed during combat.
    addon:SendJoin()
    if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    C_Timer.After(0.5, function()
        if addon.SyncCleuRegistration then addon.SyncCleuRegistration() end
    end)
end

function addon:UpdateCDCache()
    if addon.inCombat then return end
    local specIndex = GetSpecialization()
    local mySpecID = specIndex and GetSpecializationInfo(specIndex) or 0
    for spellID, info in pairs(addon.RaidCDData) do
        if IsTrackedSpellKnownByPlayer(spellID) then
            addon.CDCache[spellID] = addon:GetOwnSpellCooldownDuration(spellID, mySpecID)
        end
    end
end

function Enrage:GROUP_ROSTER_UPDATE()
    PruneInferredSpecs()
    UpdateCastWatcher()
    addon:SendJoin()
    addon:MarkPanelsDirty()
end

function Enrage:PLAYER_SPECIALIZATION_CHANGED(_, unit)
    if unit == "player" then
        wipe(addon.CDCache)
        addon:UpdateCDCache()
        addon:SendJoin()
        addon:MarkPanelsDirty()
    end
end

function Enrage:TRAIT_CONFIG_UPDATED()
    wipe(addon.CDCache)
    addon:UpdateCDCache()
    addon:SendJoin()
    addon:MarkPanelsDirty()
end

-- Panel management
function addon:CreateNewPanel(name)
    local db = addon.Enrage.db.profile
    local id = tostring(db.nextPanelID)
    db.nextPanelID = db.nextPanelID + 1
    db.panels[id] = {
        name = name or ("Panel " .. id),
        locked = false,
        headerVisible = false,
        trackedSpells = {},
        barWidth = 200,
        barHeight = 20,
        barGrowUp = false,
        barSpacing = 2,
        point = "CENTER",
        relPoint = "CENTER",
        xOfs = 0,
        yOfs = 0,
    }
    addon:CreatePanelDisplay(id)
    addon:MarkPanelsDirty()
    addon:UpdateAllPanels()
    LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
    return id
end

function addon:RemovePanel(panelID)
    local db = addon.Enrage.db.profile
    local count = 0
    for _ in pairs(db.panels) do count = count + 1 end
    if count <= 1 then
        print("|cff00ccffEnrage:|r Cannot delete the last panel.")
        return
    end
    db.panels[panelID] = nil
    addon:DestroyPanelDisplay(panelID)
    addon:MarkPanelsDirty()
    LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
end

function addon:StartCooldown(playerName, playerClass, spellID, duration, remaining)
    remaining = remaining or duration
    local key = playerName .. "-" .. spellID
    self.ActiveCooldowns[key] = {
        spellID        = spellID,
        playerName     = playerName,
        playerClass    = playerClass,
        expirationTime = GetTime() + remaining,
        duration       = duration,
        wallExpires    = time() + remaining,
    }
    self:MarkPanelsDirty()
end

function addon:GetActiveCooldowns()
    local now = GetTime()
    local removed
    for key, cd in pairs(self.ActiveCooldowns) do
        if cd.expirationTime <= now then
            self.ActiveCooldowns[key] = nil
            removed = true
        end
    end
    if removed then self:MarkPanelsDirty() end
    return self.ActiveCooldowns
end

function addon:SaveCooldowns()
    local saved = {}
    local now = time()
    for key, cd in pairs(self.ActiveCooldowns) do
        local remaining = cd.wallExpires - now
        if remaining > 0 then
            saved[key] = {
                spellID     = cd.spellID,
                playerName  = cd.playerName,
                playerClass = cd.playerClass,
                duration    = cd.duration,
                wallExpires = cd.wallExpires,
            }
        end
    end
    EnrageRaidCDDB.savedCooldowns = saved
end

function addon:RestoreCooldowns()
    local saved = EnrageRaidCDDB and EnrageRaidCDDB.savedCooldowns
    if not saved then return end

    local now = time()
    local gameNow = GetTime()
    for key, cd in pairs(saved) do
        local remaining = cd.wallExpires - now
        if remaining > 0 then
            self.ActiveCooldowns[key] = {
                spellID        = cd.spellID,
                playerName     = cd.playerName,
                playerClass    = cd.playerClass,
                duration       = cd.duration,
                expirationTime = gameNow + remaining,
                wallExpires    = cd.wallExpires,
            }
        end
    end

    EnrageRaidCDDB.savedCooldowns = nil
    self:MarkPanelsDirty()
end

addon.COMM_PREFIX = COMM_PREFIX
