AkcHouseFullScanFrameMixin = {}

local FULL_SCAN_EVENTS = {
  "REPLICATE_ITEM_LIST_UPDATE",
  "AUCTION_HOUSE_CLOSED"
}

function AkcHouseFullScanFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseFullScanFrameMixin:OnLoad")
  AkcHouse.EventBus:RegisterSource(self, "AkcHouseFullScanFrameMixin")
  self.state = AkcHouse.SavedState
end

function AkcHouseFullScanFrameMixin:ResetData()
  self.scanData = {}
  self.dbKeysMapping = {}
end

function AkcHouseFullScanFrameMixin:InitiateScan()
  if self:CanInitiate() then
    AkcHouse.EventBus:Fire(self, AkcHouse.FullScan.Events.ScanStart)

    self.state.TimeOfLastReplicateScan = time()

    self.inProgress = true

    self:RegisterForEvents()
    AkcHouse.Utilities.Message(AKCHOUSE_L_STARTING_FULL_SCAN_REPLICATE)
    C_AuctionHouse.ReplicateItems()

    AkcHouse.EventBus:Fire(self, AkcHouse.FullScan.Events.ScanProgress, 0.1)
  else
    AkcHouse.Utilities.Message(self:NextScanMessage())
  end
end

function AkcHouseFullScanFrameMixin:IsAutoscanReady()
  local timeSinceLastScan = time() - (self.state.TimeOfLastReplicateScan or 0)

  return timeSinceLastScan >= (AkcHouse.Config.Get(AkcHouse.Config.Options.AUTOSCAN_INTERVAL) * 60) and self:CanInitiate()
end

function AkcHouseFullScanFrameMixin:CanInitiate()
  return
   ( self.state.TimeOfLastReplicateScan ~= nil and
     time() - self.state.TimeOfLastReplicateScan > 60 * 15 and
     not self.inProgress
   ) or self.state.TimeOfLastReplicateScan == nil
end

function AkcHouseFullScanFrameMixin:NextScanMessage()
  local timeSinceLastScan = time() - self.state.TimeOfLastReplicateScan
  local minutesUntilNextScan = 15 - math.ceil(timeSinceLastScan / 60)
  local secondsUntilNextScan = (15 * 60 - timeSinceLastScan) % 60

  return AKCHOUSE_L_NEXT_SCAN_MESSAGE:format(minutesUntilNextScan, secondsUntilNextScan)
end

function AkcHouseFullScanFrameMixin:RegisterForEvents()
  AkcHouse.Debug.Message("AkcHouseFullScanFrameMixin:RegisterForEvents()")

  FrameUtil.RegisterFrameForEvents(self, FULL_SCAN_EVENTS)
end

function AkcHouseFullScanFrameMixin:UnregisterForEvents()
  AkcHouse.Debug.Message("AkcHouseFullScanFrameMixin:UnregisterForEvents()")

  FrameUtil.UnregisterFrameForEvents(self, FULL_SCAN_EVENTS)
end

function AkcHouseFullScanFrameMixin:CacheScanData()

  AkcHouse.EventBus:Fire(self, AkcHouse.FullScan.Events.ScanProgress, 0.2)

  self:ResetData()
  self.waitingForData = C_AuctionHouse.GetNumReplicateItems()

  self:ProcessBatch(
    0,
    250,
    self.waitingForData
  )
end

local pendingItems = {}
local itemFrame = CreateFrame("Frame")
itemFrame.elapsed = 0
itemFrame:SetScript("OnEvent", function(_, _, itemID)
  if pendingItems[itemID] ~= nil then
    local forItemID = pendingItems[itemID]
    pendingItems[itemID] = nil
    for _, callback in ipairs(forItemID) do
      callback()
    end
  end
end)
itemFrame.OnUpdate = function(self, elapsed)
  itemFrame.elapsed = itemFrame.elapsed + elapsed
  if itemFrame.elapsed > 0.4 then
    for itemID in pairs(pendingItems) do
      C_Item.RequestLoadItemDataByID(itemID)
    end
    itemFrame.elapsed = 0
  end

  if next(pendingItems) == nil then
    itemFrame.elapsed = 0
    self:SetScript("OnUpdate", nil)
    self:UnregisterEvent("ITEM_DATA_LOAD_RESULT")
  end
end

local function LoadItemData(itemID, callback)
  pendingItems[itemID] = pendingItems[itemID] or {}
  table.insert(pendingItems[itemID], callback)
  itemFrame:RegisterEvent("ITEM_DATA_LOAD_RESULT")
  itemFrame:SetScript("OnUpdate", itemFrame.OnUpdate)
  C_Item.RequestLoadItemDataByID(itemID)
end

function AkcHouseFullScanFrameMixin:ProcessBatch(startIndex, stepSize, limit)
  if startIndex >= limit then
    C_Timer.After(2, function()
      if self.waitingForData > 0 then
        self.waitingForData = 0
        self:EndProcessing()
      end
    end)
    return
  end

  AkcHouse.EventBus:Fire(self,
    AkcHouse.FullScan.Events.ScanProgress,
    0.2 + startIndex/limit*0.8
  )

  AkcHouse.Debug.Message("AkcHouseFullScanFrameMixin:ProcessBatch (links)", startIndex, stepSize, limit)

  local i = startIndex
  while i < startIndex+stepSize and i < limit do
    local info = { C_AuctionHouse.GetReplicateItemInfo(i) }
    local link = C_AuctionHouse.GetReplicateItemLink(i)
    local timeLeft = C_AuctionHouse.GetReplicateItemTimeLeft(i)
    local index = i

    if not C_Item.DoesItemExistByID(info[17]) then
      self.waitingForData = self.waitingForData - 1
      if self.waitingForData == 0 then
        self:EndProcessing()
      end
    elseif not info[18] then
      LoadItemData(info[17], function()
        local link = C_AuctionHouse.GetReplicateItemLink(index)

        AkcHouse.Utilities.DBKeyFromLink(link, function(dbKeys)
          self.waitingForData = self.waitingForData - 1

          self.scanData[index + 1] = {
            replicateInfo = { C_AuctionHouse.GetReplicateItemInfo(index) },
            itemLink      = link,
            timeLeft      = C_AuctionHouse.GetReplicateItemTimeLeft(index),
          }
          self.dbKeysMapping[index + 1] = dbKeys

          if self.waitingForData == 0 then
            self:EndProcessing()
          end
        end)
      end)
    else
      AkcHouse.Utilities.DBKeyFromLink(link, function(dbKeys)
        self.waitingForData = self.waitingForData - 1
        self.scanData[index + 1] = {
          replicateInfo = info,
          itemLink      = link,
          timeLeft      = timeLeft,
        }
        self.dbKeysMapping[index + 1] = dbKeys

        if self.waitingForData == 0 then
          self:EndProcessing()
        end
      end)
    end

    i = i + 1
  end

  C_Timer.After(0.01, function()
    self:ProcessBatch(startIndex + stepSize, stepSize, limit)
  end)
end

function AkcHouseFullScanFrameMixin:OnEvent(event, ...)
  if event == "REPLICATE_ITEM_LIST_UPDATE" then
    AkcHouse.Debug.Message("REPLICATE_ITEM_LIST_UPDATE")

    FrameUtil.UnregisterFrameForEvents(self, { "REPLICATE_ITEM_LIST_UPDATE" })
    self:CacheScanData()
  elseif event =="AUCTION_HOUSE_CLOSED" then
    self:UnregisterForEvents()

    if self.inProgress then
      self.inProgress = false
      self:ResetData()

      AkcHouse.Utilities.Message(
        AKCHOUSE_L_FULL_SCAN_FAILED_REPLICATE .. " " .. self:NextScanMessage()
      )
      AkcHouse.EventBus:Fire(self, AkcHouse.FullScan.Events.ScanFailed)
    end
  end
end

local function GetInfo(replicateInfo, itemLink)
  local count = replicateInfo[3]
  local buyoutPrice = replicateInfo[10]
  local effectivePrice = buyoutPrice / count
  local available = replicateInfo[3]

  return effectivePrice, available
end

local function MergeInfo(scanData, dbKeysMapping)
  local allInfo = {}
  local index = 0

  for index = 1, #scanData do
    local effectivePrice, available = GetInfo(scanData[index].replicateInfo)

    if available > 0 and effectivePrice ~= 0 then
      for _, dbKey in ipairs(dbKeysMapping[index]) do
        if allInfo[dbKey] == nil then
          allInfo[dbKey] = {}
        end

        table.insert(allInfo[dbKey],
          { price = effectivePrice, available = available }
        )
      end
    end
  end

  return allInfo
end

function AkcHouseFullScanFrameMixin:EndProcessing()
  local fixedScanData = {}
  local fixedDbKeysMapping = {}

  for i = 1, #self.scanData do
    if self.scanData[i] ~= nil then
      table.insert(fixedScanData, self.scanData[i])
      table.insert(fixedDbKeysMapping, self.dbKeysMapping[i])
    end
  end

  local count = AkcHouse.Database:ProcessScan(MergeInfo(fixedScanData, fixedDbKeysMapping))
  AkcHouse.Utilities.Message(AKCHOUSE_L_FINISHED_PROCESSING:format(count))

  self.inProgress = false
  self:ResetData()

  self:UnregisterForEvents()

  AkcHouse.EventBus:Fire(self, AkcHouse.FullScan.Events.ScanComplete, fixedScanData)
end
