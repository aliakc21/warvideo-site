
function AkcHouse.Variables.GetConnectedRealmRoot()

  local currentRealm = GetNormalizedRealmName()
  local connections = GetAutoCompleteRealms()

  table.sort(connections)

  if connections[1] ~= nil then

    return connections[1]
  else

    return currentRealm
  end
end
