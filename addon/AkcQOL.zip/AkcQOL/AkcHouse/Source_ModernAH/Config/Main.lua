AkcHouse.Config.ItemMatching = {
  ITEM_ID_AND_LEVEL = "item level only",
  ITEM_ID = "item id",
  ITEM_NAME_AND_LEVEL = "item name and level",
  ITEM_NAME_ONLY = "item name only",
}

AkcHouse.Config.Options.SMALL_TABS = "small_tabs"
AkcHouse.Config.Options.PET_TOOLTIPS = "pet_tooltips"
AkcHouse.Config.Options.AUTOSCAN = "autoscan_2"
AkcHouse.Config.Options.AUTOSCAN_INTERVAL = "autoscan_interval"
AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT = "selling_cancel_shortcut"
AkcHouse.Config.Options.SELLING_BUY_SHORTCUT = "selling_buy_shortcut"
AkcHouse.Config.Options.SELLING_SPLIT_PANELS = "selling_split_panels"
AkcHouse.Config.Options.COLUMNS_SHOPPING_BUY_ITEM = "columns_shopping_buy_item"
AkcHouse.Config.Options.COLUMNS_SHOPPING_BUY_COMMODITY = "columns_shopping_buy_commodity"
AkcHouse.Config.Options.SHOPPING_ALWAYS_CONFIRM_COMMODITY_QUANTITY = "shopping_always_confirm_commodity_quantity"

AkcHouse.Config.Options.CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST = "crafting_info_show_cheapest_qualities_cost"

AkcHouse.Config.Options.AUCTION_DURATION = "auction_duration"
AkcHouse.Config.Options.AUCTION_SALES_PREFERENCE = "auction_sales_preference"
AkcHouse.Config.Options.UNDERCUT_PERCENTAGE = "undercut_percentage"
AkcHouse.Config.Options.UNDERCUT_STATIC_VALUE = "undercut_static_value"
AkcHouse.Config.Options.SELLING_ITEM_MATCHING = "selling_item_matching"

AkcHouse.Config.Options.DEFAULT_QUANTITIES = "default_quantities"
AkcHouse.Config.Options.UNDERCUT_SCAN_NOT_LIFO = "undercut_scan_not_lifo"

AkcHouse.Config.Defaults[AkcHouse.Config.Options.SMALL_TABS] = false
AkcHouse.Config.Defaults[AkcHouse.Config.Options.PET_TOOLTIPS] = true
AkcHouse.Config.Defaults[AkcHouse.Config.Options.AUTOSCAN] = false
AkcHouse.Config.Defaults[AkcHouse.Config.Options.AUTOSCAN_INTERVAL] = 15
AkcHouse.Config.Defaults[AkcHouse.Config.Options.UNDERCUT_SCAN_NOT_LIFO] = true
AkcHouse.Config.Defaults[AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT] = AkcHouse.Config.Shortcuts.RIGHT_CLICK
AkcHouse.Config.Defaults[AkcHouse.Config.Options.SELLING_BUY_SHORTCUT] = AkcHouse.Config.Shortcuts.ALT_RIGHT_CLICK
AkcHouse.Config.Defaults[AkcHouse.Config.Options.SELLING_SPLIT_PANELS] = false
AkcHouse.Config.Defaults[AkcHouse.Config.Options.CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST] = false
AkcHouse.Config.Defaults[AkcHouse.Config.Options.COLUMNS_SHOPPING_BUY_ITEM] = {}
AkcHouse.Config.Defaults[AkcHouse.Config.Options.COLUMNS_SHOPPING_BUY_COMMODITY] = {}
AkcHouse.Config.Defaults[AkcHouse.Config.Options.SHOPPING_ALWAYS_CONFIRM_COMMODITY_QUANTITY] = false

AkcHouse.Config.Defaults[AkcHouse.Config.Options.AUCTION_DURATION] = 24
AkcHouse.Config.Defaults[AkcHouse.Config.Options.AUCTION_SALES_PREFERENCE] = AkcHouse.Config.SalesTypes.PERCENTAGE
AkcHouse.Config.Defaults[AkcHouse.Config.Options.UNDERCUT_PERCENTAGE] = 0
AkcHouse.Config.Defaults[AkcHouse.Config.Options.UNDERCUT_STATIC_VALUE] = 0
AkcHouse.Config.Defaults[AkcHouse.Config.Options.SELLING_ITEM_MATCHING] = AkcHouse.Config.ItemMatching.ITEM_NAME_AND_LEVEL

AkcHouse.Config.Defaults[AkcHouse.Config.Options.DEFAULT_QUANTITIES] = {
  [Enum.ItemClass.Weapon]           = 1,
  [Enum.ItemClass.Armor]            = 1,
  [Enum.ItemClass.Container]        = 0,
  [Enum.ItemClass.Gem]              = 0,
  [Enum.ItemClass.ItemEnhancement]  = 0,
  [Enum.ItemClass.Consumable]       = 0,
  [Enum.ItemClass.Glyph]            = 0,
  [Enum.ItemClass.Tradegoods]       = 0,
  [Enum.ItemClass.Profession]       = 0,
  [Enum.ItemClass.Recipe]           = 0,
  [Enum.ItemClass.Battlepet]        = 1,
  [Enum.ItemClass.Questitem]        = 0,
  [Enum.ItemClass.Miscellaneous]    = 0,
}
