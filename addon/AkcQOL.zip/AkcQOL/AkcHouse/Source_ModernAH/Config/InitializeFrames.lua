function AkcHouse.Config.InitializeFrames()
  AkcHouse.Config.InternalInitializeFrames({
    "BasicOptions",
    "Tooltips",

    "ShoppingAlt",
    "Selling",
    "SellingShortcuts",
    "SellingAllItems",
    "Quantities",
    "Cancelling",

    "Profile",

    "Advanced",
  })
end
