AkcHouseConfigTooltipsFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigTooltipsFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigTooltipsFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_TOOLTIPS_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()

  if not AkcHouse.Constants.IsRetail then
    self.EnchantTooltips:SetText(AKCHOUSE_L_CONFIG_ENCHANT_GENERIC_TOOLTIP)
    self.ProspectTooltips:Show()
    self.MillTooltips:Show()
    self.AuctionAgeTooltips:SetPoint("TOPLEFT", self.MillTooltips, "BOTTOMLEFT")
  end
end

function AkcHouseConfigTooltipsFrameMixin:ShowSettings()
  self.MailboxTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.MAILBOX_TOOLTIPS))
  self.PetTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.PET_TOOLTIPS))
  self.VendorTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.VENDOR_TOOLTIPS))
  self.AuctionTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_TOOLTIPS))
  self.EnchantTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.ENCHANT_TOOLTIPS))
  self.ShiftStackTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SHIFT_STACK_TOOLTIPS))
  self.AuctionAgeTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_AGE_TOOLTIPS))

  if not AkcHouse.Constants.IsRetail then
    self.ProspectTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.PROSPECT_TOOLTIPS))
    self.MillTooltips:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.MILL_TOOLTIPS))
  end
end

function AkcHouseConfigTooltipsFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigTooltipsFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.MAILBOX_TOOLTIPS, self.MailboxTooltips:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.PET_TOOLTIPS, self.PetTooltips:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.VENDOR_TOOLTIPS, self.VendorTooltips:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.AUCTION_TOOLTIPS, self.AuctionTooltips:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.ENCHANT_TOOLTIPS, self.EnchantTooltips:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SHIFT_STACK_TOOLTIPS, self.ShiftStackTooltips:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.AUCTION_AGE_TOOLTIPS, self.AuctionAgeTooltips:GetChecked())

  if not AkcHouse.Constants.IsRetail then
    AkcHouse.Config.Set(AkcHouse.Config.Options.PROSPECT_TOOLTIPS, self.ProspectTooltips:GetChecked())
    AkcHouse.Config.Set(AkcHouse.Config.Options.MILL_TOOLTIPS, self.MillTooltips:GetChecked())
  end
end

function AkcHouseConfigTooltipsFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigTooltipsFrameMixin:Cancel()")
end
