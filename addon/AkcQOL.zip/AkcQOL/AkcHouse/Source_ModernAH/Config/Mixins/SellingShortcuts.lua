AkcHouseConfigSellingShortcutsFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigSellingShortcutsFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigSellingShortcutsFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_SELLING_SHORTCUTS_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

function AkcHouseConfigSellingShortcutsFrameMixin:ShowSettings()
  self.BagSelectShortcut:SetValue(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BAG_SELECT_SHORTCUT))
  self.CancelShortcut:SetValue(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT))
  self.BuyShortcut:SetValue(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BUY_SHORTCUT))

  self.PostShortcut:SetShortcut(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_POST_SHORTCUT))
  self.SkipShortcut:SetShortcut(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_SKIP_SHORTCUT))
  self.PrevShortcut:SetShortcut(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_PREV_SHORTCUT))
end

function AkcHouseConfigSellingShortcutsFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigSellingShortcutsFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_BAG_SELECT_SHORTCUT, self.BagSelectShortcut:GetValue())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT, self.CancelShortcut:GetValue())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_BUY_SHORTCUT, self.BuyShortcut:GetValue())

  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_POST_SHORTCUT, self.PostShortcut:GetShortcut())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_SKIP_SHORTCUT, self.SkipShortcut:GetShortcut())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_PREV_SHORTCUT, self.PrevShortcut:GetShortcut())
end

function AkcHouseConfigSellingShortcutsFrameMixin:UnhideAllClicked()
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_IGNORED_KEYS, {})
  self.UnhideAll:Disable()
end

function AkcHouseConfigSellingShortcutsFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigSellingShortcutsFrameMixin:Cancel()")
end
