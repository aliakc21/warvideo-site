AkcHouseConfigSellingAllItemsFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigSellingAllItemsFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigSellingAllItemsFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_SELLING_ALL_ITEMS_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()

  self.ItemSalesPreference:SetOnChange(function(selectedValue)
    self:OnSalesPreferenceChange(selectedValue)
  end)
end

function AkcHouseConfigSellingAllItemsFrameMixin:ShowSettings()
  self.currentItemDuration = AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_DURATION)
  self.currentItemSalesPreference = AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_SALES_PREFERENCE)

  self.DurationGroup:SetSelectedValue(self.currentItemDuration)
  self.SaveLastDurationAsDefault:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SAVE_LAST_DURATION_AS_DEFAULT))
  self.ItemSalesPreference:SetSelectedValue(self.currentItemSalesPreference)

  self:OnSalesPreferenceChange(self.currentItemSalesPreference)

  self.ItemUndercutPercentage:SetNumber(AkcHouse.Config.Get(AkcHouse.Config.Options.UNDERCUT_PERCENTAGE))
  self.ItemUndercutValue:SetAmount(AkcHouse.Config.Get(AkcHouse.Config.Options.UNDERCUT_STATIC_VALUE))

  self.GearPriceMultiplier:SetNumber(AkcHouse.Config.Get(AkcHouse.Config.Options.GEAR_PRICE_MULTIPLIER))
  self.ItemMatching:SetSelectedValue(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_ITEM_MATCHING))
end

function AkcHouseConfigSellingAllItemsFrameMixin:OnSalesPreferenceChange(selectedValue)
  self.currentItemSalesPreference = selectedValue

  if self.currentItemSalesPreference == AkcHouse.Config.SalesTypes.PERCENTAGE then
    self.ItemUndercutPercentage:Show()
    self.ItemUndercutValue:Hide()
  else
    self.ItemUndercutValue:Show()
    self.ItemUndercutPercentage:Hide()
  end
end

function AkcHouseConfigSellingAllItemsFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigSellingAllItemsFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.AUCTION_DURATION, self.DurationGroup:GetValue())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SAVE_LAST_DURATION_AS_DEFAULT, self.SaveLastDurationAsDefault:GetChecked())

  AkcHouse.Config.Set(AkcHouse.Config.Options.AUCTION_SALES_PREFERENCE, self.ItemSalesPreference:GetValue())
  AkcHouse.Config.Set(
    AkcHouse.Config.Options.UNDERCUT_PERCENTAGE,
    AkcHouse.Utilities.ValidatePercentage(self.ItemUndercutPercentage:GetNumber())
  )
  AkcHouse.Config.Set(AkcHouse.Config.Options.UNDERCUT_STATIC_VALUE, tonumber(self.ItemUndercutValue:GetAmount()))

  AkcHouse.Config.Set(AkcHouse.Config.Options.GEAR_PRICE_MULTIPLIER, self.GearPriceMultiplier:GetNumber())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_ITEM_MATCHING, self.ItemMatching:GetValue())
end

function AkcHouseConfigSellingAllItemsFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigSellingAllItemsFrameMixin:Cancel()")
end
