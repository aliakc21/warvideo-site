AkcHouseConfigCancellingFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigCancellingFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigCancellingFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_CANCELLING_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

function AkcHouseConfigCancellingFrameMixin:ShowSettings()
  self.UndercutScanPetsGear:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.UNDERCUT_SCAN_NOT_LIFO))
  self.UndercutItemsAhead:SetNumber(AkcHouse.Config.Get(AkcHouse.Config.Options.UNDERCUT_ITEMS_AHEAD))
  self.CancelUndercutShortcut:SetShortcut(AkcHouse.Config.Get(AkcHouse.Config.Options.CANCEL_UNDERCUT_SHORTCUT))
end

function AkcHouseConfigCancellingFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigCancellingFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.UNDERCUT_SCAN_NOT_LIFO, self.UndercutScanPetsGear:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.UNDERCUT_ITEMS_AHEAD, self.UndercutItemsAhead:GetNumber())
  AkcHouse.Config.Set(AkcHouse.Config.Options.CANCEL_UNDERCUT_SHORTCUT, self.CancelUndercutShortcut:GetShortcut())
end

function AkcHouseConfigCancellingFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigCancellingFrameMixin:Cancel()")
end
