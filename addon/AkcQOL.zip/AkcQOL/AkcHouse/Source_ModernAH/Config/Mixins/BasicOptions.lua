AkcHouseConfigBasicOptionsFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigBasicOptionsFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigBasicOptionsFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_BASIC_OPTIONS_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

function AkcHouseConfigBasicOptionsFrameMixin:ShowSettings()
  self.Autoscan:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.AUTOSCAN))
  self.AutoscanInterval:SetNumber(AkcHouse.Config.Get(AkcHouse.Config.Options.AUTOSCAN_INTERVAL))
  self.SmallTabs:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SMALL_TABS))
  self.DefaultTab:SetValue(tostring(AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_TAB)))
  self.ShowCraftingInfo:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW))
  self.ShowCraftingCost:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_COST))
  self.ShowCraftingProfit:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_PROFIT))
  self.ShowCraftingCheapestQualitiesCost:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST))
end

function AkcHouseConfigBasicOptionsFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigBasicOptionsFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.AUTOSCAN, self.Autoscan:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.AUTOSCAN_INTERVAL, self.AutoscanInterval:GetNumber())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SMALL_TABS, self.SmallTabs:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.DEFAULT_TAB, tonumber(self.DefaultTab:GetValue()))
  AkcHouse.Config.Set(AkcHouse.Config.Options.CRAFTING_INFO_SHOW, self.ShowCraftingInfo:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_COST, self.ShowCraftingCost:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_PROFIT, self.ShowCraftingProfit:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST, self.ShowCraftingCheapestQualitiesCost:GetChecked())
end

function AkcHouseConfigBasicOptionsFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigBasicOptionsFrameMixin:Cancel()")
end
