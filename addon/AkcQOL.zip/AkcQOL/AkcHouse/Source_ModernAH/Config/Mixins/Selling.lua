AkcHouseConfigSellingFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigSellingFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigSellingFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_SELLING_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

function AkcHouseConfigSellingFrameMixin:ShowSettings()
  self.AuctionChatLog:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_CHAT_LOG))
  self.ShowBidPrice:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE))
  self.ConfirmPostLowPrice:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CONFIRM_LOW_PRICE))
  self.SplitPanels:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_SPLIT_PANELS))

  self.BagShown:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SHOW_SELLING_BAG))
  self.IconSize:SetNumber(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_ICON_SIZE))
  self.BagCollapsed:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BAG_COLLAPSED))
  self.AutoSelectNext:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_AUTO_SELECT_NEXT))
  self.ReselectItem:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_SHOULD_RESELECT_ITEM))
  self.MissingFavourites:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_MISSING_FAVOURITES))
  self.PossessedFavouritesFirst:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_FAVOURITES_SORT_OWNED))

  self.UnhideAll:SetEnabled(#AKCHOUSE_SELLING_GROUPS.HiddenItems ~= 0)
end

function AkcHouseConfigSellingFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigSellingFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.AUCTION_CHAT_LOG, self.AuctionChatLog:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE, self.ShowBidPrice:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_CONFIRM_LOW_PRICE, self.ConfirmPostLowPrice:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_SPLIT_PANELS, self.SplitPanels:GetChecked())

  AkcHouse.Config.Set(AkcHouse.Config.Options.SHOW_SELLING_BAG, self.BagShown:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_ICON_SIZE, math.min(50, math.max(10, self.IconSize:GetNumber())))
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_BAG_COLLAPSED, self.BagCollapsed:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_AUTO_SELECT_NEXT, self.AutoSelectNext:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_SHOULD_RESELECT_ITEM, self.ReselectItem:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_MISSING_FAVOURITES, self.MissingFavourites:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_FAVOURITES_SORT_OWNED, self.PossessedFavouritesFirst:GetChecked())
end

function AkcHouseConfigSellingFrameMixin:UnhideAllClicked()
  AkcHouse.Groups.UnhideAll()
  AkcHouse.Groups.CallbackRegistry:TriggerEvent("Customise.EditMade")
  self.UnhideAll:Disable()
end

function AkcHouseConfigSellingFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigSellingFrameMixin:Cancel()")
end
