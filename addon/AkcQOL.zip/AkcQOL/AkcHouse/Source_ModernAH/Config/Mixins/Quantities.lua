AkcHouseConfigQuantitiesFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigQuantitiesFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigQuantitiesFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_QUANTITIES_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()

end

function AkcHouseConfigQuantitiesFrameMixin:ShowSettings()
  AkcHouse.Debug.Message("AkcHouseConfigQuantitiesFrameMixin:ShowSettings()")

  local settings = AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_QUANTITIES)
  for _, quantityOption in ipairs(self.Quantities) do

    quantityOption:SetNumber(settings[quantityOption.classID] or 0)
  end
end

function AkcHouseConfigQuantitiesFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigQuantitiesFrameMixin:Save()")

  local settings = AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_QUANTITIES)
  for _, quantityOption in ipairs(self.Quantities) do
    settings[quantityOption.classID] = quantityOption:GetNumber()
  end
end

function AkcHouseConfigQuantitiesFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigQuantitiesFrameMixin:Cancel()")
end
