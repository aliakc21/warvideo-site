AkcHouseConfigShoppingAltFrameMixin = CreateFromMixins(AkcHouseConfigShoppingFrameMixin)

function AkcHouseConfigShoppingAltFrameMixin:ShowSettings()
  AkcHouseConfigShoppingFrameMixin.ShowSettings(self)

  self.AlwaysConfirmQuantity:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SHOPPING_ALWAYS_CONFIRM_COMMODITY_QUANTITY))
end

function AkcHouseConfigShoppingAltFrameMixin:Save()
  AkcHouseConfigShoppingFrameMixin.Save(self)

  AkcHouse.Config.Set(AkcHouse.Config.Options.SHOPPING_ALWAYS_CONFIRM_COMMODITY_QUANTITY, self.AlwaysConfirmQuantity:GetChecked())
end
