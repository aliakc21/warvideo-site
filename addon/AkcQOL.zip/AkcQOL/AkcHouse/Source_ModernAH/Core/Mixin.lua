AkcHouseAHFrameMixin = {}

local function InitializeIncrementalScanFrame()
  local frame
  if AkcHouse.State.IncrementalScanFrameRef == nil then
    frame = CreateFrame(
      "FRAME",
      "AkcHouseIncrementalScanFrame",
      AuctionHouseFrame,
      "AkcHouseIncrementalScanFrameTemplate"
    )

    AkcHouse.State.IncrementalScanFrameRef = frame
  else
    frame = AkcHouse.State.IncrementalScanFrameRef
  end

  if not AkcHouse.Config.Get(AkcHouse.Config.Options.REPLICATE_SCAN) and
     AkcHouse.Config.Get(AkcHouse.Config.Options.AUTOSCAN) and
     frame:IsAutoscanReady() then
    frame:InitiateScan()
  end
end

local function InitializeFullScanFrame()
  local frame
  if AkcHouse.State.FullScanFrameRef == nil then
    frame = CreateFrame(
      "FRAME",
      "AkcHouseFullScanFrame",
      AuctionHouseFrame,
      "AkcHouseFullScanFrameTemplate"
    )

    AkcHouse.State.FullScanFrameRef = frame
  else
    frame = AkcHouse.State.FullScanFrameRef
  end

  if AkcHouse.Config.Get(AkcHouse.Config.Options.REPLICATE_SCAN) and
     AkcHouse.Config.Get(AkcHouse.Config.Options.AUTOSCAN) and
     frame:IsAutoscanReady() then
    frame:InitiateScan()
  end
end

local function InitializeAuctionHouseTabs()
  if AkcHouse.State.TabFrameRef == nil then
    AkcHouse.State.TabFrameRef = CreateFrame(
      "Frame",
      "AkcHouseAHTabsContainer",
      AuctionHouseFrame,
      "AkcHouseAHTabsContainerTemplate"
    )
  end
end

local function InitializeBuyItemFrame()
  if AkcHouse.State.BuyItemFrameRef == nil then
    AkcHouse.State.BuyItemFrameRef = CreateFrame(
      "Frame",
      "AkcHouseBuyItemFrame",
      AkcHouseShoppingFrame,
      "AkcHouseBuyItemFrameTemplate"
    )
  end
end

local function InitializeBuyCommodityFrame()
  if AkcHouse.State.BuyCommodityFrameRef == nil then
    AkcHouse.State.BuyCommodityFrameRef = CreateFrame(
      "Frame",
      "AkcHouseBuyCommodityFrame",
      AkcHouseShoppingFrame,
      "AkcHouseBuyCommodityFrameTemplate"
    )
  end
end

local setupSearchCategories = false
local function InitializeSearchCategories()
  if setupSearchCategories then
    return
  end

  AkcHouse.Search.InitializeCategories()

  setupSearchCategories = true
end

local function ShowDefaultTab()
  local tabs = AkcHouseAHTabsContainer.Tabs

  local chosenTab = tabs[AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_TAB)]

  if chosenTab then
    chosenTab:Click()
  end
end

function AkcHouseAHFrameMixin:OnLoad()
  FrameUtil.RegisterFrameForEvents(self, {
    "PLAYER_INTERACTION_MANAGER_FRAME_SHOW",
    "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
  })
end

function AkcHouseAHFrameMixin:OnShow()
  InitializeIncrementalScanFrame()
  InitializeFullScanFrame()
  InitializeSearchCategories()

  if AuctionHouseFrame:GetScale() < 0.5 then
    self:SetScript("OnUpdate", self.OnShow)
    return
  else
    self:SetScript("OnUpdate", nil)
  end

  AkcHouse.Debug.Message("AkcHouseAHFrameMixin:OnShow()")

  InitializeAuctionHouseTabs()
  InitializeBuyItemFrame()
  InitializeBuyCommodityFrame()

  ShowDefaultTab()

  C_Timer.After(0, ShowDefaultTab)
end

function AkcHouseAHFrameMixin:OnEvent(eventName, ...)
  local paneType = ...
  if eventName == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" and paneType == Enum.PlayerInteractionType.Auctioneer then
    self:Show()
  elseif eventName == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" and paneType == Enum.PlayerInteractionType.Auctioneer then
    self:Hide()
  end
end
