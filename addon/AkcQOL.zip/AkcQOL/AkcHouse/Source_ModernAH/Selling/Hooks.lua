local function SelectOwnItem(itemLocation)
  if not itemLocation:IsValid() or not C_AuctionHouse.IsSellItemValid(itemLocation) then
    return
  end

  AuctionHouseFrame.ItemSellFrame:SetItem(nil, nil, false)
  AuctionHouseFrame.CommoditiesSellFrame:SetItem(nil, nil, false)

  AkcHouseTabs_Selling:Click()

  local itemLink = C_Item.GetItemLink(itemLocation)
  AkcHouseBagCacheFrame:CacheLinkInfo(itemLink, function()
    local info = AkcHouse.Groups.Utilities.ToPostingItem(AkcHouseBagCacheFrame:GetByLinkInstant(itemLink, true))
    info.itemLink = itemLink
    info.location = itemLocation
    info.count = C_AuctionHouse.GetAvailablePostCount(itemLocation)
    AkcHouse.EventBus:RegisterSource(SelectOwnItem, "SellingItemClickedHook")
    AkcHouse.EventBus:Fire(SelectOwnItem, AkcHouse.Selling.Events.BagItemClicked, info)
  end)
end

local function AHShown()
  return AuctionHouseFrame and AuctionHouseFrame:IsShown() and AkcHouseTabs_Selling
end

hooksecurefunc(_G, "ContainerFrameItemButton_OnClick", function(self, button)
  if AHShown() and
      AkcHouse.Utilities.IsShortcutActive(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BAG_SELECT_SHORTCUT), button) then
    local itemLocation = ItemLocation:CreateFromBagAndSlot(self.GetBagID and self:GetBagID() or self:GetParent():GetID(), self:GetID());
    SelectOwnItem(itemLocation)
  end
end)

hooksecurefunc(_G, "HandleModifiedItemClick", function(itemLink, itemLocation)
  if itemLocation ~= nil and AHShown() and
      AkcHouse.Utilities.IsShortcutActive(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BAG_SELECT_SHORTCUT), GetMouseButtonClicked()) then
    SelectOwnItem(itemLocation)
  end
end)

if ContainerFrameItemButton_OnModifiedClick then
  hooksecurefunc(_G, "ContainerFrameItemButton_OnModifiedClick", function(self, button)
    if AHShown() and
        AkcHouse.Utilities.IsShortcutActive(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BAG_SELECT_SHORTCUT), button) then
      local itemLocation = ItemLocation:CreateFromBagAndSlot(self.GetBagID and self:GetBagID() or self:GetParent():GetID(), self:GetID());
      SelectOwnItem(itemLocation)
    end
  end)
end
