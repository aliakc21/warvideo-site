
function AkcHouse.Selling.DoesItemMatchFromKey(originalItemKey, originalItemLink, targetItemKey, targetItemLink)
  local matchType = AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_ITEM_MATCHING)

  if matchType == AkcHouse.Config.ItemMatching.ITEM_NAME_AND_LEVEL then
    if originalItemLink:find("battlepet:", nil, true) ~= nil then
      return AkcHouse.Utilities.GetPetLevelFromLink(originalItemLink) == AkcHouse.Utilities.GetPetLevelFromLink(targetItemLink)
    else
      return originalItemKey.itemLevel == targetItemKey.itemLevel and originalItemKey.itemSuffix == targetItemKey.itemSuffix
    end

  elseif matchType == AkcHouse.Config.ItemMatching.ITEM_ID then
    return true

  elseif matchType == AkcHouse.Config.ItemMatching.ITEM_NAME_ONLY then
    return C_Item.GetItemInfo(originalItemLink) == C_Item.GetItemInfo(targetItemLink)

  elseif matchType == AkcHouse.Config.ItemMatching.ITEM_ID_AND_LEVEL then
    if originalItemLink:find("battlepet:", nil, true) ~= nil then
      return AkcHouse.Utilities.GetPetLevelFromLink(originalItemLink) == AkcHouse.Utilities.GetPetLevelFromLink(targetItemLink)
    else
      return originalItemKey.itemLevel == targetItemKey.itemLevel
    end
  end
  return true
end

function AkcHouse.Selling.DoesItemMatchFromLink(originalItemLink, targetItemKey, targetItemLink)
  local matchType = AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_ITEM_MATCHING)

  if matchType == AkcHouse.Config.ItemMatching.ITEM_NAME_AND_LEVEL then
    if originalItemLink:find("battlepet:", nil, true) ~= nil then
      return AkcHouse.Utilities.GetPetLevelFromLink(originalItemLink) == AkcHouse.Utilities.GetPetLevelFromLink(targetItemLink)
    else
      return C_Item.GetDetailedItemLevelInfo(originalItemLink) == targetItemKey.itemLevel and C_Item.GetItemInfo(originalItemLink) == C_Item.GetItemInfo(targetItemLink)
    end

  elseif matchType == AkcHouse.Config.ItemMatching.ITEM_ID then
    return true

  elseif matchType == AkcHouse.Config.ItemMatching.ITEM_NAME_ONLY then
    return C_Item.GetItemInfo(originalItemLink) == C_Item.GetItemInfo(targetItemLink)

  elseif matchType == AkcHouse.Config.ItemMatching.ITEM_ID_AND_LEVEL then
    if originalItemLink:find("battlepet:", nil, true) ~= nil then
      return AkcHouse.Utilities.GetPetLevelFromLink(originalItemLink) == AkcHouse.Utilities.GetPetLevelFromLink(targetItemLink)
    else
      return C_Item.GetDetailedItemLevelInfo(originalItemLink) == targetItemKey.itemLevel
    end
  end
  return true
end
