local function userPrefersPercentage()
  return
    AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_SALES_PREFERENCE) ==
    AkcHouse.Config.SalesTypes.PERCENTAGE
end

local function getPercentage()
  return (100 - AkcHouse.Config.Get(AkcHouse.Config.Options.UNDERCUT_PERCENTAGE)) / 100
end

local function getSetAmount()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.UNDERCUT_STATIC_VALUE)
end

function AkcHouse.Selling.CalculateItemPriceFromPrice(basePrice)
  AkcHouse.Debug.Message(" AkcHouseItemSellingMixin:CalculateItemPriceFromResult")
  local value

  if userPrefersPercentage() then
    value = basePrice * getPercentage()

    AkcHouse.Debug.Message("Percentage calculation", basePrice, getPercentage(), value)
  else
    value = basePrice - getSetAmount()

    AkcHouse.Debug.Message("Static value calculation", basePrice, getSetAmount(), value)
  end

  if value < 100 and AkcHouse.Constants.IsRetail then
    value = 100
  elseif value < 1 then
    value = 1
  end

  return value
end
