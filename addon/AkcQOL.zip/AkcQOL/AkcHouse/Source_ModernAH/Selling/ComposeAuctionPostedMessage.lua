function AkcHouse.Selling.ComposeAuctionPostedMessage(auctionInfo)
  local result = auctionInfo.itemLink

  if auctionInfo.quantity > 1 then
    local effectiveUnitPrice = auctionInfo.buyoutAmount
    if auctionInfo.bidAmount ~= nil and effectiveUnitPrice == 0 then
      effectiveUnitPrice = auctionInfo.bidAmount
    end
    result = AkcHouse.Locales.Apply(
      "STACK_AUCTION_INFO",
      result .. AkcHouse.Utilities.CreateCountString(auctionInfo.quantity),
      GetMoneyString(auctionInfo.quantity * effectiveUnitPrice, true),
      GetMoneyString(effectiveUnitPrice, true)
    )

  else
    if auctionInfo.bidAmount ~= nil then
      result = AkcHouse.Locales.Apply(
        "BIDDING_AUCTION_INFO",
        result,
        GetMoneyString(auctionInfo.bidAmount, true)
      )
    end

    if auctionInfo.buyoutAmount ~= nil then
      result = AkcHouse.Locales.Apply(
        "BUYOUT_AUCTION_INFO",
        result,
        GetMoneyString(auctionInfo.buyoutAmount, true)
      )
    end
  end

  return result
end
