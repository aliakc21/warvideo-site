function AkcHouse.API.v1.RegisterForDBUpdate(callerID, callback)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(callback) ~= "function" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.RegisterForDBUpdate(string, function)"
    )
  end

  AkcHouse.EventBus:Register({
    ReceiveEvent = function()
      callback()
    end
  }, {
    AkcHouse.IncrementalScan.Events.PricesProcessed,
    AkcHouse.FullScan.Events.ScanComplete,
  })
end
