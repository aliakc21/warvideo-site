function AkcHouse.AH.SendSearchQueryByGenerator(itemKeyGenerator, sorts, splitOwnedItems)
  function rawSearch(itemKey)
    C_AuctionHouse.SendSearchQuery(itemKey, sorts, splitOwnedItems)
  end

  AkcHouse.AH.Internals.searchScan:SetSearch(itemKeyGenerator, rawSearch)
end

function AkcHouse.AH.SendSearchQueryByItemKey(itemKey, sorts, splitOwnedItems)
  function itemKeyGenerator()
    return itemKey
  end
  function rawSearch(itemKey)
    C_AuctionHouse.SendSearchQuery(itemKey, sorts, splitOwnedItems)
  end

  AkcHouse.AH.Internals.searchScan:SetSearch(itemKeyGenerator, rawSearch)
end

function AkcHouse.AH.SendSellSearchQueryByGenerator(itemKeyGenerator, sorts, splitOwnedItems)
  function rawSearch(itemKey)
    C_AuctionHouse.SendSellSearchQuery(itemKey, sorts, splitOwnedItems)
  end

  AkcHouse.AH.Internals.searchScan:SetSearch(itemKeyGenerator, rawSearch)
end

function AkcHouse.AH.SendSellSearchQueryByItemKey(itemKey, sorts, splitOwnedItems)
  function itemKeyGenerator()
    return itemKey
  end
  function rawSearch(itemKey)
    C_AuctionHouse.SendSellSearchQuery(itemKey, sorts, splitOwnedItems)
  end

  AkcHouse.AH.Internals.searchScan:SetSearch(itemKeyGenerator, rawSearch)
end

function AkcHouse.AH.QueryOwnedAuctions(...)
  local args = {...}
  AkcHouse.AH.Queue:Enqueue(function()
    C_AuctionHouse.QueryOwnedAuctions(unpack(args))
  end)
end

local sentBrowseQuery = true
function AkcHouse.AH.SendBrowseQuery(...)
  local args = {...}
  sentBrowseQuery = false
  AkcHouse.AH.Queue:Enqueue(function()
    sentBrowseQuery = true
    C_AuctionHouse.SendBrowseQuery(unpack(args))
  end)
end

function AkcHouse.AH.HasFullBrowseResults()
  return sentBrowseQuery and C_AuctionHouse.HasFullBrowseResults()
end

function AkcHouse.AH.RequestMoreBrowseResults(...)
  local args = {...}
  AkcHouse.AH.Queue:Enqueue(function()
    C_AuctionHouse.RequestMoreBrowseResults(unpack(args))
  end)
end

function AkcHouse.AH.IsNotThrottled()
  return AkcHouse.AH.Internals.throttling:IsReady()
end

function AkcHouse.AH.CancelAuction(...)

  C_AuctionHouse.CancelAuction(...)
end

function AkcHouse.AH.ReplicateItems()
  C_AuctionHouse.ReplicateItems()
end

function AkcHouse.AH.GetItemKeyInfo(itemKey, callback)
  AkcHouse.AH.Internals.itemKeyLoader:Get(itemKey, callback)
end

function AkcHouse.AH.GetAuctionItemSubClasses(classID)
  return C_AuctionHouse.GetAuctionItemSubClasses(classID)
end
