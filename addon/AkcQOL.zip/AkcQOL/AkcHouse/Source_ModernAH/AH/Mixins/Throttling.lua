
AkcHouseAHThrottlingFrameMixin = {}

local THROTTLING_EVENTS = {
  "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED",
  "AUCTION_HOUSE_THROTTLED_MESSAGE_QUEUED",
  "AUCTION_HOUSE_THROTTLED_MESSAGE_RESPONSE_RECEIVED",
  "AUCTION_HOUSE_THROTTLED_MESSAGE_SENT",
  "AUCTION_HOUSE_THROTTLED_SYSTEM_READY",
  "AUCTION_HOUSE_BROWSE_FAILURE"
}

function AkcHouseAHThrottlingFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseAHThrottlingFrameMixin:OnLoad")
  self.oldReady = false

  FrameUtil.RegisterFrameForEvents(self, THROTTLING_EVENTS)

  AkcHouse.EventBus:RegisterSource(self, "AkcHouseAHThrottlingFrameMixin")
end

function AkcHouseAHThrottlingFrameMixin:OnEvent(eventName, ...)
  if eventName == "AUCTION_HOUSE_THROTTLED_SYSTEM_READY" then
    AkcHouse.Debug.Message("normal ready")

  elseif eventName == "AUCTION_HOUSE_BROWSE_FAILURE" or
         eventName == "AUCTION_HOUSE_THROTTLED_MESSAGE_DROPPED" then
    AkcHouse.Debug.Message("fail", eventName)

  else
    AkcHouse.Debug.Message("not ready", eventName)
  end

  local ready = self:IsReady()

  if self.oldReady ~= ready then
    if ready then
      AkcHouse.EventBus:Fire(self, AkcHouse.AH.Events.Ready)
    end
    AkcHouse.EventBus:Fire(self, AkcHouse.AH.Events.ThrottleUpdate, ready)
  end

  self.oldReady = ready
end

function AkcHouseAHThrottlingFrameMixin:SearchQueried()
end

function AkcHouseAHThrottlingFrameMixin:IsReady()
  return C_AuctionHouse.IsThrottledMessageSystemReady()
end
