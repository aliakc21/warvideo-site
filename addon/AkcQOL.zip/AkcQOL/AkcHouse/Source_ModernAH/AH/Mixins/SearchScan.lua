
AkcHouseAHSearchScanFrameMixin = {}

local SEARCH_EVENTS = {
  "ITEM_SEARCH_RESULTS_UPDATED",
  "COMMODITY_SEARCH_RESULTS_UPDATED",
}

function AkcHouseAHSearchScanFrameMixin:OnLoad()
  AkcHouse.EventBus:RegisterSource(self, "AHSearchScanFrameMixin")
end

function AkcHouseAHSearchScanFrameMixin:OnHide()
  if self.searchFunc ~= nil then
    AkcHouse.AH.Queue:Remove(self.searchFunc)
    self.searchFunc = nil
  end
  self:SetScript("OnUpdate", nil)
  FrameUtil.UnregisterFrameForEvents(self, SEARCH_EVENTS)
end

function AkcHouseAHSearchScanFrameMixin:OnUpdate()
  self:AttemptSearch()
end

function AkcHouseAHSearchScanFrameMixin:OnEvent(eventName, ...)
  if eventName == "COMMODITY_SEARCH_RESULTS_UPDATED" and self:ValidateItemInfo(...) then
    local itemID = ...
    local has = C_AuctionHouse.HasSearchResults(C_AuctionHouse.MakeItemKey(itemID))
    local full = C_AuctionHouse.HasFullCommoditySearchResults(itemID)
    local quantity = C_AuctionHouse.GetCommoditySearchResultsQuantity(itemID)

    if (not has) or (has and not full and quantity == 0) then
      self:AttemptSearch()
    else
      AkcHouse.EventBus:Fire(self, AkcHouse.AH.Events.CommoditySearchResultsReady, itemID)
      FrameUtil.UnregisterFrameForEvents(self, SEARCH_EVENTS)
    end
  elseif eventName == "ITEM_SEARCH_RESULTS_UPDATED" and self:ValidateItemInfo(...) then
    local itemKey = ...
    local has = C_AuctionHouse.HasSearchResults(itemKey)
    local full = C_AuctionHouse.HasFullItemSearchResults(itemKey)
    local quantity = C_AuctionHouse.GetItemSearchResultsQuantity(itemKey)

    if (not has) or (has and not full and quantity == 0) then
      self:AttemptSearch()
    else
      FrameUtil.UnregisterFrameForEvents(self, SEARCH_EVENTS)
      AkcHouse.EventBus:Fire(self, AkcHouse.AH.Events.ItemSearchResultsReady, itemKey)
    end
  end
end

function AkcHouseAHSearchScanFrameMixin:SetSearch(itemKeyGenerator, rawSearch)
  if self.searchFunc ~= nil then
    AkcHouse.AH.Queue:Remove(self.searchFunc)
    self.searchFunc = nil
  end
  self.itemKeyGenerator = itemKeyGenerator
  self.rawSearch = rawSearch
  self:AttemptSearch()
end

function AkcHouseAHSearchScanFrameMixin:ValidateItemInfo(itemInfo)
  return (type(itemInfo) == "number" and self.itemKey.itemID == itemInfo) or
    (type(itemInfo) == "table" and AkcHouse.Utilities.ItemKeyString(itemInfo) == AkcHouse.Utilities.ItemKeyString(self.itemKey))
end

function AkcHouseAHSearchScanFrameMixin:AttemptSearch()
  if self.searchFunc ~= nil then
    AkcHouse.AH.Queue:Remove(self.searchFunc)
  end
  self.searchFunc = function()
    self.searchFunc = nil
    self.itemKey = self.itemKeyGenerator()
    if C_AuctionHouse.GetItemKeyInfo(self.itemKey) then
      FrameUtil.RegisterFrameForEvents(self, SEARCH_EVENTS)
      self:SetScript("OnUpdate", nil)
      self.rawSearch(self.itemKey)
    else
      self:SetScript("OnUpdate", self.OnUpdate)
    end
  end
  AkcHouse.AH.Queue:Enqueue(self.searchFunc)
end
