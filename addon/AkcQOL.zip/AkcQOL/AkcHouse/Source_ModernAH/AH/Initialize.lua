function AkcHouse.AH.Initialize()
  if AkcHouse.AH.Internals ~= nil then
    return
  end
  AkcHouse.AH.Internals = {}

  AkcHouse.AH.Internals.throttling = CreateFrame(
    "FRAME",
    "AkcHouseAHThrottlingFrame",
    AuctionHouseFrame,
    "AkcHouseAHThrottlingFrameTemplate"
  )

  AkcHouse.AH.Internals.itemKeyLoader = CreateFrame(
    "FRAME",
    "AkcHouseAHItemKeyLoaderFrame",
    AuctionHouseFrame,
    "AkcHouseAHItemKeyLoaderFrameTemplate"
  )

  AkcHouse.AH.Internals.searchScan = CreateFrame(
    "FRAME",
    "AkcHouseAHSearchScanFrame",
    AuctionHouseFrame,
    "AkcHouseAHSearchScanFrameTemplate"
  )

  AkcHouse.AH.Queue = CreateAndInitFromMixin(AkcHouse.AH.QueueMixin)
end
