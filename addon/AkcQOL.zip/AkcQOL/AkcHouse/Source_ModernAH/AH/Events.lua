AkcHouse.AH.Events.CommoditySearchResultsReady = "ah_commodity_results_ready"
AkcHouse.AH.Events.ItemSearchResultsReady = "ah_item_results_ready"
