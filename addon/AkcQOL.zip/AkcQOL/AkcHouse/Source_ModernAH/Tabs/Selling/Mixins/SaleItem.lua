local SALE_ITEM_EVENTS = {
  AkcHouse.AH.Events.CommoditySearchResultsReady,
  AkcHouse.AH.Events.ItemSearchResultsReady,
}

local function NormalizePrice(price)
  local normalizedPrice = price

  if AkcHouse.Constants.IsRetail then

    if normalizedPrice % 100 ~= 0 then
      normalizedPrice = normalizedPrice + (100 - normalizedPrice % 100)
    end

    if normalizedPrice < 100 then
      normalizedPrice = 100
    end
  elseif normalizedPrice < 1 then
    normalizedPrice = 1
  end

  return normalizedPrice
end

local function IsEquipment(itemInfo)

  return not itemInfo.isCommodity and AkcHouse.Utilities.IsEquipment(itemInfo.classId)
end

local function IsValidItem(item)
  return item ~= nil and

    item.location ~= nil and

    C_Item.DoesItemExist(item.location)
end

AkcHouseSaleItemMixin = {}

function AkcHouseSaleItemMixin:OnLoad()
  if AkcHouse.Config.Get(AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE) then
    self.BidPrice:Show()
  end
end

function AkcHouseSaleItemMixin:OnShow()
  AkcHouse.EventBus:Register(self, {
    AkcHouse.Selling.Events.BagItemClicked,
    AkcHouse.Selling.Events.ClearBagItem,
    AkcHouse.Selling.Events.RequestPost,
    AkcHouse.Selling.Events.ConfirmPost,
    AkcHouse.Selling.Events.SkipItem,
    AkcHouse.AH.Events.ThrottleUpdate,
    AkcHouse.Selling.Events.PriceSelected,
    AkcHouse.Selling.Events.RefreshSearch,
    AkcHouse.Components.Events.EnterPressed,
  })
  AkcHouse.EventBus:RegisterSource(self, "AkcHouseSaleItemMixin")

  local function SetupBindings()
    if self:IsVisible() then
      SetOverrideBinding(self, false, AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_POST_SHORTCUT), "CLICK AkcHousePostButton:LeftButton")
      SetOverrideBinding(self, false, AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_SKIP_SHORTCUT), "CLICK AkcHouseSkipPostingButton:LeftButton")
      SetOverrideBinding(self, false, AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_PREV_SHORTCUT), "CLICK AkcHousePrevPostingButton:LeftButton")
    end
  end
  if InCombatLockdown() then
    EventUtil.ContinueAfterAllEvents(SetupBindings, "PLAYER_REGEN_ENABLED")
  else
    SetupBindings()
  end

  self.lastItemInfo = nil
  self.nextItem = nil
  self.prevItem = nil

  self:UpdateSkipButton()
  self:Reset()

  if AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_SHOULD_RESELECT_ITEM) then
    local key = AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_RESELECT_ITEM)
    if key ~= nil then
      AkcHouse.EventBus:Fire(
        self, AkcHouse.Selling.Events.BagItemRequest, key
      )
    end
  end
end

function AkcHouseSaleItemMixin:OnHide()
  AkcHouse.EventBus:Unregister(self, {
    AkcHouse.Selling.Events.BagItemClicked,
    AkcHouse.Selling.Events.ClearBagItem,
    AkcHouse.Selling.Events.RequestPost,
    AkcHouse.Selling.Events.ConfirmPost,
    AkcHouse.Selling.Events.SkipItem,
    AkcHouse.AH.Events.ThrottleUpdate,
    AkcHouse.Selling.Events.PriceSelected,
    AkcHouse.Selling.Events.RefreshSearch,
    AkcHouse.Components.Events.EnterPressed,
  })
  if self.saleItemEventsRegistered then
    AkcHouse.EventBus:Unregister(self, SALE_ITEM_EVENTS)
  end
  AkcHouse.Config.Set(AkcHouse.Config.Options.SELLING_RESELECT_ITEM, self.lastKey)
  AkcHouse.EventBus:UnregisterSource(self)
  self:UnlockItem()

  if InCombatLockdown() then
    EventUtil.ContinueAfterAllEvents(function() ClearOverrideBindings(self) end, "PLAYER_REGEN_ENABLED")
  else
    ClearOverrideBindings(self)
  end
end

function AkcHouseSaleItemMixin:UpdateSkipButton()
  if AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_AUTO_SELECT_NEXT) then
    self.PostButton:SetSize(114, 22)
    self.SkipButton:Show()
  else
    self.PostButton:SetSize(194, 22)
    self.SkipButton:Hide()
  end
end

function AkcHouseSaleItemMixin:UnlockItem()
  if self.itemInfo ~= nil then

    if IsValidItem(self.itemInfo) then
      C_Item.UnlockItem(self.itemInfo.location)
    end
    self.itemInfo = nil
  end
end

function AkcHouseSaleItemMixin:LockItem()
  if IsValidItem(self.itemInfo) then
    C_Item.LockItem(self.itemInfo.location)
  end
end

function AkcHouseSaleItemMixin:OnUpdate()
  if self.itemInfo == nil then
    return

  elseif self.itemInfo.count == 0 then
    return

  elseif not C_Item.DoesItemExist(self.itemInfo.location) then

    self.itemInfo = nil
    self:Reset()
    return
  end

  self.TotalPrice:SetText(
    GetMoneyString(self.Quantity:GetNumber() * self.Price:GetAmount(), true)
  )

  if self.Quantity:GetNumber() > self:GetPostLimit() then
    self:SetMax()
  end

  self.MaxButton:SetEnabled(self.Quantity:GetNumber() ~= self:GetPostLimit())

  self.DepositPrice:SetText(GetMoneyString(self:GetDeposit(), true))
  self:UpdatePostButtonState()
  self:UpdateSkipButtonState()
end

function AkcHouseSaleItemMixin:GetPostLimit()
  return math.min(C_AuctionHouse.GetAvailablePostCount(self.itemInfo.location), self.itemInfo.count)
end
function AkcHouseSaleItemMixin:SetMax()
  self.Quantity:SetNumber(self:GetPostLimit())
end

function AkcHouseSaleItemMixin:GetDeposit()
  local deposit = 0

  if C_AuctionHouse.GetItemCommodityStatus(self.itemInfo.location) == Enum.ItemCommodityStatus.Commodity then
    deposit = C_AuctionHouse.CalculateCommodityDeposit(
      self.itemInfo.itemID,
      self:GetDuration(),
      self.Quantity:GetNumber()
    ) or deposit

  else
    deposit = C_AuctionHouse.CalculateItemDeposit(
      self.itemInfo.location,
      self:GetDuration(),
      self.Quantity:GetNumber()
    ) or deposit
  end

  return NormalizePrice(deposit)
end

function AkcHouseSaleItemMixin:ReceiveEvent(event, ...)
  if event == AkcHouse.Selling.Events.BagItemClicked then
    self:UnlockItem()
    local itemInfo = ...
    AkcHouse.AH.GetItemKeyInfo(C_AuctionHouse.MakeItemKey(itemInfo.itemID), function(itemKeyInfo)
      self.itemInfo = itemInfo
      self.itemInfo.isCommodity = itemKeyInfo.isCommodity
      self.nextItem = self.itemInfo and self.itemInfo.nextItem
      self.prevItem = self.itemInfo and self.itemInfo.prevItem
      self.lastKey = self.itemInfo and self.itemInfo.key
      self:LockItem()
      self:Update()
    end)

  elseif event == AkcHouse.Selling.Events.ClearBagItem then
    self.nextItem = nil
    self.prevItem = nil
    self.lastKey = nil
    self:Reset()

  elseif event == AkcHouse.AH.Events.ThrottleUpdate then
    self:UpdatePostButtonState()

  elseif event == AkcHouse.Selling.Events.RequestPost then
    self:PostItem()

  elseif event == AkcHouse.Selling.Events.ConfirmPost then
    self:PostItem(true)

  elseif event == AkcHouse.Selling.Events.SkipItem then
    self:SkipItem()

  elseif event == AkcHouse.Components.Events.EnterPressed then
    self:PostItem()

  elseif event == AkcHouse.Selling.Events.PriceSelected and
         self.itemInfo ~= nil then
    local selectedPrices, shouldUndercut = ...
    local buyoutAmount = selectedPrices.buyout or selectedPrices.bid

    if shouldUndercut then
      buyoutAmount = AkcHouse.Selling.CalculateItemPriceFromPrice(buyoutAmount)
    end

    if AkcHouse.Config.Get(AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE) then
      self:UpdateSalesPrice(buyoutAmount, selectedPrices.bid, true)
    else
      self:UpdateSalesPrice(buyoutAmount)
    end

  elseif event == AkcHouse.Selling.Events.RefreshSearch then
    self:RefreshButtonClicked()

  elseif event == AkcHouse.AH.Events.CommoditySearchResultsReady then
    local itemID = ...
    if itemID ~= self.expectedItemKey.itemID then
      return
    end

    self:ProcessCommodityResults(...)
    self.saleItemEventsRegistered = false
    AkcHouse.EventBus:Unregister(self, SALE_ITEM_EVENTS)

  elseif event == AkcHouse.AH.Events.ItemSearchResultsReady then
    local itemKey = ...
    if AkcHouse.Utilities.ItemKeyString(itemKey) ~=
        AkcHouse.Utilities.ItemKeyString(self.expectedItemKey) then
      return
    end

    local item = Item:CreateFromItemID(itemKey.itemID)
    item:ContinueOnItemLoad(function()
      self:ProcessItemResults(itemKey)
    end)
    self.saleItemEventsRegistered = false
    AkcHouse.EventBus:Unregister(self, SALE_ITEM_EVENTS)
  end
end

function AkcHouseSaleItemMixin:Update()
  self:UpdateVisuals()

  if self.itemInfo ~= nil then
    self:UpdateForNewItem()
  else
    self:UpdateForNoItem()
  end

  self:UpdatePostButtonState()
  self:UpdateSkipButtonState()

end

function AkcHouseSaleItemMixin:UpdateVisuals()
  self.Icon:SetItemInfo(self.itemInfo)

  if self.itemInfo ~= nil then
    self:SetItemName()

    if self.itemInfo.isCommodity then
      self.BidPrice:SetAlpha(0.5)
    else
      self.BidPrice:SetAlpha(1)
    end

  else

    self.TitleArea.Text:SetText("")
  end
end

function AkcHouseSaleItemMixin:SetItemName()
  local reagentQualityInfo
  if AkcHouse.Constants.IsRetail then
    reagentQualityInfo = C_TradeSkillUI.GetItemReagentQualityInfo(self.itemInfo.itemID)
  end
  local itemName = self.itemInfo.itemName
  if reagentQualityInfo then
    itemName = itemName .. " " .. CreateAtlasMarkup(reagentQualityInfo.iconChat, 17, 17)
  elseif self.itemInfo.itemLevel then
    itemName = AKCHOUSE_L_ITEM_NAME_X_ITEM_LEVEL_X:format(itemName, self.itemInfo.itemLevel)
  elseif self.itemInfo.itemLink:find("battlepet", nil, true) then
    itemName = AKCHOUSE_L_ITEM_NAME_X_ITEM_LEVEL_X:format(itemName, AkcHouse.Utilities.GetPetLevelFromLink(self.itemInfo.itemLink))
  end
  itemName = ITEM_QUALITY_COLORS[self.itemInfo.quality].color:WrapTextInColorCode(itemName)
  self.TitleArea.Text:SetText(itemName)
end

function AkcHouseSaleItemMixin:UpdateForNewItem()
  self:SetDuration()

  self.MaxButton:Disable()

  self:SetQuantity()

  AkcHouse.Utilities.DBKeyFromLink(self.itemInfo.itemLink, function(dbKeys)
    local price = AkcHouse.Database:GetFirstPrice(dbKeys)

    if price ~= nil then
      self:UpdateSalesPrice(price)
    elseif IsEquipment(self.itemInfo) then
      self:SetEquipmentMultiplier(self.itemInfo.itemLink)
    else
      self:UpdateSalesPrice(0)
    end
  end)

  self:DoSearch(self.itemInfo)
end

function AkcHouseSaleItemMixin:UpdateForNoItem()
  self.Quantity:SetNumber(0)
  self.MaxButton:Disable()
  self:UpdateSalesPrice(0)

  self.DepositPrice:SetText(GetMoneyString(100, true))
  self.TotalPrice:SetText(GetMoneyString(100, true))
end

local DURATIONS_TO_TIME = {
  [1] = 12,
  [2] = 24,
  [3] = 48,
}
function AkcHouseSaleItemMixin:SetDuration()
  local duration = AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_DURATION)

  self.Duration:SetSelectedValue(duration)
end

function AkcHouseSaleItemMixin:SetQuantity()
  local defaultQuantity = AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_QUANTITIES)[self.itemInfo.classId]

  if self.itemInfo.count == 0 then
    self.Quantity:SetNumber(0)
  elseif defaultQuantity ~= nil and defaultQuantity > 0 then

    self.Quantity:SetNumber(math.min(self.itemInfo.count, defaultQuantity, self:GetPostLimit()))
  else

    self:SetMax()
  end
end

function AkcHouseSaleItemMixin:DoSearch(itemInfo, ...)
  AkcHouse.EventBus:Register(self, SALE_ITEM_EVENTS)
  self.saleItemEventsRegistered = true

  local sortingOrder

  if itemInfo.isCommodity then
    sortingOrder = AkcHouse.Constants.CommodityResultsSorts
  else
    sortingOrder = AkcHouse.Constants.ItemResultsSorts
  end

  local comparisonKey
  if IsEquipment(itemInfo) then
    self.expectedItemKey = {itemID = itemInfo.itemID, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0}
    comparisonKey = {itemID = itemInfo.itemID, itemLevel = itemInfo.itemLevel, itemSuffix = 0, battlePetSpeciesID = 0}
    AkcHouse.AH.SendSellSearchQueryByItemKey(self.expectedItemKey, {sortingOrder}, true)
  else
    local battlePetID = itemInfo.itemLink:match("battlepet:(%d+)")

    if battlePetID then
      self.expectedItemKey = C_AuctionHouse.MakeItemKey(itemInfo.itemID, nil, nil, tonumber(battlePetID))
    else
      self.expectedItemKey = C_AuctionHouse.MakeItemKey(itemInfo.itemID)
    end
    comparisonKey = self.expectedItemKey
    AkcHouse.AH.SendSearchQueryByItemKey(self.expectedItemKey, {sortingOrder}, true)
  end
  local originalKey = IsValidItem(itemInfo) and C_AuctionHouse.GetItemKeyFromItem(itemInfo.location) or comparisonKey
  if originalKey.itemLevel == 0 then
    originalKey = comparisonKey
  end
  AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.SellSearchStart, self.expectedItemKey, itemInfo.itemLink, originalKey)
end

function AkcHouseSaleItemMixin:Reset()
  self:UnlockItem()

  self:Update()
end

function AkcHouseSaleItemMixin:UpdateSalesPrice(salesPrice, bidPrice, preserveBidPrice)
  if salesPrice == 0 then
    self.Price:SetAmount(0)
  else
    self.Price:SetAmount(NormalizePrice(salesPrice))
  end
  if bidPrice == nil then

    if not preserveBidPrice or self.BidPrice:GetAmount() >= self.Price:GetAmount() then
      self.BidPrice:Clear()
    end
  else
    self.BidPrice:SetAmount(bidPrice)
  end
end

function AkcHouseSaleItemMixin:SetEquipmentMultiplier(itemLink)
  self:UpdateSalesPrice(0)

  local item = Item:CreateFromItemLink(itemLink)
  item:ContinueOnItemLoad(function()
    local multiplier = AkcHouse.Config.Get(AkcHouse.Config.Options.GEAR_PRICE_MULTIPLIER)
    local vendorPrice = select(AkcHouse.Constants.ITEM_INFO.SELL_PRICE, C_Item.GetItemInfo(itemLink))
    if multiplier ~= 0 and vendorPrice ~= 0 then

      self:UpdateSalesPrice(
        vendorPrice * multiplier + self:GetDeposit()
      )
    end
  end)
end

function AkcHouseSaleItemMixin:OnEvent(eventName, ...)
end

function AkcHouseSaleItemMixin:GetCommodityResult(itemID)
  if C_AuctionHouse.GetCommoditySearchResultsQuantity(itemID) > 0 then
    return C_AuctionHouse.GetCommoditySearchResultInfo(itemID, 1)
  else
    return nil
  end
end

function AkcHouseSaleItemMixin:GetCommodityThreshold(itemID)
  local amount = 0

  local target = math.min(5000, math.floor(C_AuctionHouse.GetCommoditySearchResultsQuantity(itemID) * 0.2))
  for index = 1, C_AuctionHouse.GetNumCommoditySearchResults(itemID) do
    local result = C_AuctionHouse.GetCommoditySearchResultInfo(itemID, index)

    amount = amount + result.quantity

    if amount >= target then
      return AkcHouse.Utilities.PriceWarningThreshold(result.unitPrice)
    end
  end

  return nil
end

function AkcHouseSaleItemMixin:ProcessCommodityResults(itemID, ...)
  AkcHouse.Debug.Message("AkcHouseSaleItemMixin:ProcessCommodityResults()")

  local dbKeys = AkcHouse.Utilities.DBKeyFromBrowseResult({ itemKey = C_AuctionHouse.MakeItemKey(itemID) })

  local result = self:GetCommodityResult(itemID)

  if result ~= nil then
    for _, key in ipairs(dbKeys) do
      AkcHouse.Database:SetPrice(key, result.unitPrice)
    end
  end
  if self.itemInfo ~= nil then
    self.itemInfo.existingValue = result and result.unitPrice
  end

  self.priceThreshold = self:GetCommodityThreshold(itemID)

  if result == nil then
    return
  end

  local postingPrice = nil

  if result.containsOwnerItem and result.owners[1] == "player" then

    postingPrice = result.unitPrice
  else

    postingPrice = AkcHouse.Selling.CalculateItemPriceFromPrice(result.unitPrice)
  end

  if postingPrice == nil then
    AkcHouse.Debug.Message("No prices have been recorded for this item.")
    return
  end

  self:UpdateSalesPrice(postingPrice)
end

function AkcHouseSaleItemMixin:GetItemResult(itemKey)
  local itemInfo = self.itemInfo or self.lastItemInfo
  local compareKey = IsValidItem(itemInfo) and C_AuctionHouse.GetItemKeyFromItem(itemInfo.location) or itemKey
  for i = 1, C_AuctionHouse.GetNumItemSearchResults(itemKey) do
    local resultInfo = C_AuctionHouse.GetItemSearchResultInfo(itemKey, i)
    if AkcHouse.Selling.DoesItemMatchFromKey(compareKey, itemInfo.itemLink, resultInfo.itemKey, resultInfo.itemLink) then
      return resultInfo
    end
  end
  return nil
end

function AkcHouseSaleItemMixin:ProcessItemResults(itemKey)
  AkcHouse.Debug.Message("AkcHouseSaleItemMixin:ProcessItemResults()")

  if C_AuctionHouse.GetNumItemSearchResults(itemKey) > 0 then
    local result = C_AuctionHouse.GetItemSearchResultInfo(itemKey, 1)
    local dbKeys = AkcHouse.Utilities.DBKeyFromBrowseResult({ itemKey = result.itemKey })
    for _, key in ipairs(dbKeys) do
      AkcHouse.Database:SetPrice(key, result.buyoutAmount or result.bidAmount)
    end
  end

  local result = self:GetItemResult(itemKey)

  if self.itemInfo ~= nil then
    self.itemInfo.existingValue = result and (result.buyoutAmount or result.bidAmount)
  end

  self.priceThreshold = nil

  local postingPrice = nil

  if result == nil then
    return
  end

  if result.containsOwnerItem then

    postingPrice = result.buyoutAmount
  else
    postingPrice = AkcHouse.Selling.CalculateItemPriceFromPrice(result.buyoutAmount or result.bidAmount)
  end

  if postingPrice == nil then
    AkcHouse.Debug.Message("Lowest price not found.")
    return
  end

  self:UpdateSalesPrice(postingPrice)
end

function AkcHouseSaleItemMixin:GetPostButtonState()
  return
    self.itemInfo ~= nil and
    self.itemInfo.count > 0 and

    C_Item.DoesItemExist(self.itemInfo.location) and

    GetMoney() >= self:GetDeposit() and

    self.Quantity:GetNumber() > 0 and
    self.Quantity:GetNumber() <= self:GetPostLimit() and

    (
      (

        self.Price:GetAmount() > 0 and

        self.BidPrice:GetAmount() < self.Price:GetAmount()
      ) or (

        AkcHouse.Config.Get(AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE) and

        self.itemInfo.itemType == AkcHouse.Constants.ITEM_TYPES.ITEM and

        self.Price:GetAmount() == 0 and
        self.BidPrice:GetAmount() > 0
      )
    ) and

    AkcHouse.AH.IsNotThrottled()
end

function AkcHouseSaleItemMixin:GetConfirmationMessage()
  local effectiveUnitPrice = self.Price:GetAmount()
  if AkcHouse.Config.Get(AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE) and effectiveUnitPrice == 0 then
    effectiveUnitPrice = self.BidPrice:GetAmount()
  end

  local itemInfo = { C_Item.GetItemInfo(self.itemInfo.itemLink) }
  local vendorPrice = itemInfo[AkcHouse.Constants.ITEM_INFO.SELL_PRICE]
  if AkcHouse.Utilities.IsVendorable(itemInfo) and
     vendorPrice * self.Quantity:GetNumber()
       > math.floor(effectiveUnitPrice * self.Quantity:GetNumber() * AkcHouse.Constants.AfterAHCut) then
    return AKCHOUSE_L_CONFIRM_POST_BELOW_VENDOR
  end

  if self.priceThreshold ~= nil and self.priceThreshold >= effectiveUnitPrice then
    return AKCHOUSE_L_CONFIRM_POST_LOW_PRICE:format(GetMoneyString(effectiveUnitPrice, true))
  end
end

function AkcHouseSaleItemMixin:RequiresConfirmationState()
  return
    AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CONFIRM_LOW_PRICE) and
    self:GetConfirmationMessage() ~= nil
end

function AkcHouseSaleItemMixin:UpdatePostButtonState()
  if self:GetPostButtonState() then
    self.PostButton:Enable()
  else
    self.PostButton:Disable()
  end
end

function AkcHouseSaleItemMixin:UpdateSkipButtonState()
  self.SkipButton:SetEnabled(self.SkipButton:IsShown() and self.nextItem)
  self.PrevButton:SetEnabled(self.SkipButton:IsShown() and self.prevItem)
end

local AUCTION_DURATIONS = {
  [12] = 1,
  [24] = 2,
  [48] = 3,
}

function AkcHouseSaleItemMixin:GetDuration()
  return AUCTION_DURATIONS[self.Duration:GetValue()]
end

function AkcHouseSaleItemMixin:PostItem(confirmed)
  if not self:GetPostButtonState() then
    AkcHouse.Debug.Message("Trying to post when we can't. Returning")
    return
  elseif not confirmed and self:RequiresConfirmationState() then
    if self.SkipButton:IsEnabled() then
      AkcHouse.Dialogs.ShowConfirmAlt(self:GetConfirmationMessage(), ACCEPT, AKCHOUSE_L_SKIP, CANCEL, function()
        AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.ConfirmPost)
      end, function()
        AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.SkipItem)
      end)
    else
      AkcHouse.Dialogs.ShowConfirm(self:GetConfirmationMessage(), ACCEPT, CANCEL, function()
        AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.ConfirmPost)
      end)
    end
    return
  end

  local quantity = self.Quantity:GetNumber()
  local duration = self:GetDuration()
  local startingBid = self.BidPrice:GetAmount()
  local buyout = self.Price:GetAmount()
  local bidAmountReported = nil

  self.MultisellProgress:SetDetails(self.itemInfo.iconTexture, quantity)

  if not self.itemInfo.isCommodity then
    local params = nil
    if startingBid ~= 0 then
      bidAmountReported = startingBid
      params = {self.itemInfo.location, duration, quantity, startingBid, buyout ~= 0 and buyout or nil}
    else
      params = {self.itemInfo.location, duration, quantity, nil, buyout}
    end

    if C_AuctionHouse.PostItem(unpack(params)) then
      AuctionHouseFrame.ItemSellFrame:CachePendingPost(unpack(params))
    end
  else
    local params = {self.itemInfo.location, duration, quantity, buyout}

    if C_AuctionHouse.PostCommodity(unpack(params)) then
      AuctionHouseFrame.CommoditiesSellFrame:CachePendingPost(unpack(params))
    end
  end

  local postedInfo = {
    itemLink = self.itemInfo.itemLink,
    quantity = quantity,
    buyoutAmount = buyout,
    bidAmount = bidAmountReported,
  }

  if AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_CHAT_LOG) then
    AkcHouse.Utilities.Message(AkcHouse.Selling.ComposeAuctionPostedMessage(postedInfo))
  end

  AkcHouse.EventBus:Fire(self,
    AkcHouse.Selling.Events.AuctionCreated,
    postedInfo
  )

  local priceToSave = postedInfo.buyoutAmount
  if postedInfo.buyoutAmount == 0 then
    priceToSave = postedInfo.bidAmount
  end
  if self.itemInfo.existingValue == nil or self.itemInfo.existingValue > priceToSave then
    AkcHouse.Utilities.DBKeyFromLink(self.itemInfo.itemLink, function(dbKeys)
      for _, key in ipairs(dbKeys) do
        AkcHouse.Database:SetPrice(key, priceToSave)
      end

      AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.RefreshHistory)
    end)
  else

    AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.RefreshHistory)
  end

  if AkcHouse.Config.Get(AkcHouse.Config.Options.SAVE_LAST_DURATION_AS_DEFAULT) then
    AkcHouse.Config.Set(AkcHouse.Config.Options.AUCTION_DURATION, self.Duration:GetValue())
  end

  self.lastItemInfo = self.itemInfo
  self:Reset()

  if (AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_AUTO_SELECT_NEXT) and
      self.nextItem
     ) then

    AkcHouse.EventBus:Fire(
      self, AkcHouse.Selling.Events.BagItemRequest, self.nextItem
    )

  else

    self:DoSearch(self.lastItemInfo)
  end
end

function AkcHouseSaleItemMixin:SkipItem()
  if self.SkipButton:IsEnabled() then
    AkcHouse.EventBus:Fire(
      self, AkcHouse.Selling.Events.BagItemRequest, self.nextItem
    )
  end
end

function AkcHouseSaleItemMixin:PrevItem()
  if self.PrevButton:IsEnabled() then
    AkcHouse.EventBus:Fire(
      self, AkcHouse.Selling.Events.BagItemRequest, self.prevItem
    )
  end
end

function AkcHouseSaleItemMixin:RefreshButtonClicked()

  if self.itemInfo ~= nil then
    self:DoSearch(self.itemInfo)
  elseif self.lastItemInfo ~= nil then
    self:DoSearch(self.lastItemInfo)
  end
end
