AkcHouseShoppingHistoricalPriceProviderMixin = CreateFromMixins(AkcHouseHistoricalPriceProviderMixin)

function AkcHouseShoppingHistoricalPriceProviderMixin:OnLoad()
  AkcHouseHistoricalPriceProviderMixin.OnLoad(self)

  AkcHouse.EventBus:Register( self, { AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices })
end

function AkcHouseShoppingHistoricalPriceProviderMixin:ReceiveEvent(event, itemInfo)
  if event == AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices then
    self:SetItem(AkcHouse.Utilities.DBKeyFromBrowseResult({ itemKey = itemInfo.itemKey })[1])
  end
end

function AkcHouseShoppingHistoricalPriceProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_SHOPPING_HISTORICAL_PRICES)
end
