local SHOPPING_LIST_TABLE_LAYOUT = {
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "minPrice" },
    headerText = AKCHOUSE_L_RESULTS_PRICE_COLUMN,
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "minPrice" },
    width = 140
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "name" },
    headerText = AKCHOUSE_L_RESULTS_NAME_COLUMN,
    cellTemplate = "AkcHouseItemKeyCellTemplate"
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "itemLevel" },
    headerText = AKCHOUSE_L_ITEM_LEVEL,
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "itemLevel" },
    defaultHide = true,
    width = 70,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "isOwned" },
    headerText = AKCHOUSE_L_OWNED_COLUMN,
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "isOwned" },
    defaultHide = true,
    width = 70,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_RESULTS_AVAILABLE_COLUMN,
    headerParameters = { "totalQuantity" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "available" },
    width = 70
  }
}

AkcHouseShoppingTabDataProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin, AkcHouseItemKeyLoadingMixin)

function AkcHouseShoppingTabDataProviderMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseShoppingTabDataProviderMixin:OnLoad()")

  self:SetUpEvents()

  AkcHouseDataProviderMixin.OnLoad(self)
  AkcHouseItemKeyLoadingMixin.OnLoad(self)
end

function AkcHouseShoppingTabDataProviderMixin:SetUpEvents()
  AkcHouse.EventBus:RegisterSource(self, "Shopping List Data Provider")

  AkcHouse.EventBus:Register( self, {
    AkcHouse.Shopping.Tab.Events.SearchStart,
    AkcHouse.Shopping.Tab.Events.SearchEnd,
    AkcHouse.Shopping.Tab.Events.SearchIncrementalUpdate,
  })
end

function AkcHouseShoppingTabDataProviderMixin:ReceiveEvent(eventName, eventData, ...)
  if eventName == AkcHouse.Shopping.Tab.Events.SearchStart then
    self:Reset()
    self.onSearchStarted()
  elseif eventName == AkcHouse.Shopping.Tab.Events.SearchEnd then
    self:AppendEntries(self:PrettifyData(eventData), true)
  elseif eventName == AkcHouse.Shopping.Tab.Events.SearchIncrementalUpdate then
    self:AppendEntries(self:PrettifyData(eventData))
  end
end

function AkcHouseShoppingTabDataProviderMixin:PrettifyData(entries)
  for _, entry in ipairs(entries) do
    if entry.containsOwnerItem then
      entry.isOwned = AKCHOUSE_L_UNDERCUT_YES
    else
      entry.isOwned = ""
    end
    entry.available = FormatLargeNumber(entry.totalQuantity)
    entry.itemLevel = entry.itemKey.itemLevel
  end

  return entries
end

function AkcHouseShoppingTabDataProviderMixin:UniqueKey(entry)
  return AkcHouse.Utilities.ItemKeyString(entry.itemKey)
end

local COMPARATORS = {
  minPrice = AkcHouse.Utilities.NumberComparator,
  name = AkcHouse.Utilities.StringComparator,
  totalQuantity = AkcHouse.Utilities.NumberComparator,
  itemLevel = AkcHouse.Utilities.NumberComparator,
  isOwned = AkcHouse.Utilities.StringComparator,
}

function AkcHouseShoppingTabDataProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end

function AkcHouseShoppingTabDataProviderMixin:GetTableLayout()
  return SHOPPING_LIST_TABLE_LAYOUT
end

function AkcHouseShoppingTabDataProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_SHOPPING)
end

function AkcHouseShoppingTabDataProviderMixin:GetRowTemplate()
  return "AkcHouseShoppingResultsRowTemplate"
end
