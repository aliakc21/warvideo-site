AkcHouseItemKeyLoadingMixin = {}

function AkcHouseItemKeyLoadingMixin:OnLoad()
  AkcHouse.EventBus:Register(self, {AkcHouse.AH.Events.ItemKeyInfo})

  self:SetOnEntryProcessedCallback(function(entry)
    AkcHouse.AH.GetItemKeyInfo(entry.itemKey, function(itemKeyInfo, wasCached)
      self:ProcessItemKey(entry, itemKeyInfo)
      if wasCached then
        self:NotifyCacheUsed()
      end
    end)
  end)
end

function AkcHouseItemKeyLoadingMixin:ProcessItemKey(rowEntry, itemKeyInfo)
  local text = AuctionHouseUtil.GetItemDisplayTextFromItemKey(
    rowEntry.itemKey,
    itemKeyInfo,
    false
  )
  if AkcHouse.Constants.IsRetail then
    local info = C_TradeSkillUI.GetItemReagentQualityInfo(rowEntry.itemKey.itemID)
    if info then
      text = text .. " " .. CreateAtlasMarkup(info.iconChat, 17, 17)
    end
  end

  rowEntry.itemName = text
  rowEntry.plainItemName = itemKeyInfo.itemName
  rowEntry.name = AkcHouse.Utilities.RemoveTextColor(text):gsub("|A.-Tier(%d).-|a", AKCHOUSE_L_TIER .. " %1")
  rowEntry.iconTexture = itemKeyInfo.iconFileID
  rowEntry.noneAvailable = rowEntry.totalQuantity == 0

  self:SetDirty()
end
