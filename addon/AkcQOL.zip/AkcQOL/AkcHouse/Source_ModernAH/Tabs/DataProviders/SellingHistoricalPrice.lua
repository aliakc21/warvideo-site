AkcHouseSellingHistoricalPriceProviderMixin = CreateFromMixins(AkcHouseHistoricalPriceProviderMixin)

function AkcHouseSellingHistoricalPriceProviderMixin:OnLoad()
  AkcHouseHistoricalPriceProviderMixin.OnLoad(self)

  AkcHouse.EventBus:Register( self, {
    AkcHouse.Selling.Events.BagItemClicked,
    AkcHouse.Selling.Events.ClearBagItem,
    AkcHouse.Selling.Events.RefreshHistory,
  })
end

function AkcHouseSellingHistoricalPriceProviderMixin:ReceiveEvent(eventName, itemInfo)
  if eventName == AkcHouse.Selling.Events.BagItemClicked then
    AkcHouse.Utilities.DBKeyFromLink(itemInfo.itemLink, function(dbKeys)
      local dbKey = dbKeys[1]
      self:SetItem(dbKey)
    end)

  elseif eventName == AkcHouse.Selling.Events.ClearBagItem then
    self.lastDBKey = nil
    self:Reset()

  elseif eventName == AkcHouse.Selling.Events.RefreshHistory and self.lastDBKey ~= nil then
    self:SetItem(self.lastDBKey)
  end
end

function AkcHouseSellingHistoricalPriceProviderMixin:GetRowTemplate()
  return "AkcHouseHistoricalPriceRowTemplate"
end

function AkcHouseSellingHistoricalPriceProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_HISTORICAL_PRICES)
end
