AkcHouseSellingPostingHistoryProviderMixin = CreateFromMixins(AkcHousePostingHistoryProviderMixin)

function AkcHouseSellingPostingHistoryProviderMixin:OnLoad()
  AkcHousePostingHistoryProviderMixin.OnLoad(self)

  AkcHouse.EventBus:Register( self, {
    AkcHouse.Selling.Events.BagItemClicked,
    AkcHouse.Selling.Events.ClearBagItem,
    AkcHouse.Selling.Events.RefreshHistory,
  })
end

function AkcHouseSellingPostingHistoryProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_POSTING_HISTORY)
end

function AkcHouseSellingPostingHistoryProviderMixin:ReceiveEvent(eventName, eventData, ...)
  if eventName == AkcHouse.Selling.Events.BagItemClicked then
    AkcHouse.Utilities.DBKeyFromLink(eventData.itemLink, function(dbKeys)
      local dbKey = dbKeys[1]
      self:SetItem(dbKey)
    end)

  elseif eventName == AkcHouse.Selling.Events.ClearBagItem then
    self.lastDBKey = nil
    self:Reset()

  elseif eventName == AkcHouse.Selling.Events.RefreshHistory and self.lastDBKey ~= nil then
    self:SetItem(self.lastDBKey)
  end
end

function AkcHouseSellingPostingHistoryProviderMixin:GetRowTemplate()
  return "AkcHouseSellingPostingHistoryRowTemplate"
end
