local SEARCH_PROVIDER_LAYOUT = {
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "price" },
    headerText = AKCHOUSE_L_BUYOUT_PRICE,
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "price" },
    width = 145
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "bidPrice" },
    headerText = AKCHOUSE_L_BID_PRICE,
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "bidPrice" },
    width = 145,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_RESULTS_AVAILABLE_COLUMN,
    headerParameters = { "quantity" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "quantityFormatted" },
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_ITEM_LEVEL_COLUMN,
    headerParameters = { "level" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "levelPretty" },
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "otherSellers" },
    headerText = AKCHOUSE_L_SELLERS_COLUMN,
    cellTemplate = "AkcHouseTooltipStringCellTemplate",
    cellParameters = { "otherSellers" },
    defaultHide = true,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "owned" },
    headerText = AKCHOUSE_L_OWNED_COLUMN,
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "owned" },
    defaultHide = true,
    width = 70
  },
}

local SEARCH_EVENTS = {
  "ITEM_SEARCH_RESULTS_UPDATED",
  "AUCTION_HOUSE_NEW_BID_RECEIVED",
}

AkcHouseBuyItemDataProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin)

function AkcHouseBuyItemDataProviderMixin:OnLoad()
  AkcHouseDataProviderMixin.OnLoad(self)

  AkcHouse.EventBus:Register(self, {
    AkcHouse.Buying.Events.ShowItemBuy,
    AkcHouse.Buying.Events.RefreshingItems,
  })
end

function AkcHouseBuyItemDataProviderMixin:OnShow()
  FrameUtil.RegisterFrameForEvents(self, SEARCH_EVENTS)
  self:Reset()
end

function AkcHouseBuyItemDataProviderMixin:OnHide()
  FrameUtil.UnregisterFrameForEvents(self, SEARCH_EVENTS)
end

function AkcHouseBuyItemDataProviderMixin:ReceiveEvent(eventName, rowData, itemKeyInfo)
  if eventName == AkcHouse.Buying.Events.ShowItemBuy then

    self.expectedItemKey = rowData.itemKey
  elseif eventName == AkcHouse.Buying.Events.RefreshingItems then
    self:Reset()
    self.onSearchStarted()
  end
end

function AkcHouseBuyItemDataProviderMixin:GetTableLayout()
  return SEARCH_PROVIDER_LAYOUT
end

function AkcHouseBuyItemDataProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_SHOPPING_BUY_ITEM)
end

local COMPARATORS = {
  price = AkcHouse.Utilities.NumberComparator,
  bidPrice = AkcHouse.Utilities.NumberComparator,
  quantity = AkcHouse.Utilities.NumberComparator,
  level = AkcHouse.Utilities.NumberComparator,
  timeLeft = AkcHouse.Utilities.NumberComparator,
  owned = AkcHouse.Utilities.StringComparator,
  otherSellers = AkcHouse.Utilities.StringComparator,
}

function AkcHouseBuyItemDataProviderMixin:UniqueKey(entry)
  return entry.auctionID
end

function AkcHouseBuyItemDataProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end

function AkcHouseBuyItemDataProviderMixin:OnEvent(eventName, itemRef)
  if (eventName == "ITEM_SEARCH_RESULTS_UPDATED" and self.expectedItemKey ~= nil and
          AkcHouse.Utilities.ItemKeyString(self.expectedItemKey) == AkcHouse.Utilities.ItemKeyString(itemRef)
        ) then
    self.onPreserveScroll()
    self:Reset()
    self:AppendEntries(self:ProcessItemResults(itemRef), true)
  elseif eventName == "AUCTION_HOUSE_NEW_BID_RECEIVED" and self.expectedItemKey ~= nil then
    local auctionInfo = C_AuctionHouse.GetAuctionInfoByID(itemRef)
    if AkcHouse.Utilities.ItemKeyString(self.expectedItemKey) == AkcHouse.Utilities.ItemKeyString(auctionInfo.itemKey) then
      self:GetParent():Search()
    end
  end
end

local function cancelShortcutEnabled()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT) ~= AkcHouse.Config.Shortcuts.NONE
end

function AkcHouseBuyItemDataProviderMixin:ProcessItemResults(itemKey)
  local entries = {}
  local anyOwnedNotLoaded = false

  for index = 1, C_AuctionHouse.GetNumItemSearchResults(itemKey) do
    local resultInfo = C_AuctionHouse.GetItemSearchResultInfo(itemKey, index)
    local entry = AkcHouse.Search.GetBuyItemResult(resultInfo)

    if resultInfo.containsOwnerItem and (
        not C_AuctionHouse.CanCancelAuction(resultInfo.auctionID) or (entry.bidder and C_AuctionHouse.GetCancelCost(entry.auctionID) == 0)
      ) then
      anyOwnedNotLoaded = true
    end

    table.insert(entries, entry)
  end

  if anyOwnedNotLoaded and cancelShortcutEnabled() then
    AkcHouse.AH.QueryOwnedAuctions({})
  end

  return entries
end

function AkcHouseBuyItemDataProviderMixin:GetRowTemplate()
  return "AkcHouseBuyItemRowTemplate"
end
