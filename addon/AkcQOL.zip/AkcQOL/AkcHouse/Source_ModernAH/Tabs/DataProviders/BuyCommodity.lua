local SEARCH_PROVIDER_LAYOUT = {
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "price" },
    headerText = AKCHOUSE_L_PRICE,
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "price" },
    width = 145
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_RESULTS_AVAILABLE_COLUMN,
    headerParameters = { "quantity" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "quantityFormatted" },
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "otherSellers" },
    headerText = AKCHOUSE_L_SELLERS_COLUMN,
    cellTemplate = "AkcHouseTooltipStringCellTemplate",
    cellParameters = { "otherSellers" },
    defaultHide = true,
  },
}

local SEARCH_EVENTS = {
  "COMMODITY_SEARCH_RESULTS_UPDATED",
}

AkcHouseBuyCommodityDataProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin)

function AkcHouseBuyCommodityDataProviderMixin:OnLoad()
  AkcHouseDataProviderMixin.OnLoad(self)

  AkcHouse.EventBus:Register(self, {
    AkcHouse.Buying.Events.RefreshingCommodities,
  })
end

function AkcHouseBuyCommodityDataProviderMixin:ReceiveEvent(eventName, ...)
  if eventName == AkcHouse.Buying.Events.RefreshingCommodities then
    self:Reset()
    self.onSearchStarted()
  end
end

function AkcHouseBuyCommodityDataProviderMixin:GetTableLayout()
  return SEARCH_PROVIDER_LAYOUT
end

function AkcHouseBuyCommodityDataProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_SHOPPING_BUY_COMMODITY)
end

local COMPARATORS = {
  price = AkcHouse.Utilities.NumberComparator,
  quantity = AkcHouse.Utilities.NumberComparator,
  otherSellers = AkcHouse.Utilities.StringComparator,
}

function AkcHouseBuyCommodityDataProviderMixin:UniqueKey(entry)
  return entry.rowIndex
end

function AkcHouseBuyCommodityDataProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end

function AkcHouseBuyCommodityDataProviderMixin:SetListing(results)
  self.onPreserveScroll()
  self:Reset()
  self:AppendEntries(results, true)
end

function AkcHouseBuyCommodityDataProviderMixin:GetRowTemplate()
  return "AkcHouseBuyCommodityRowTemplate"
end
