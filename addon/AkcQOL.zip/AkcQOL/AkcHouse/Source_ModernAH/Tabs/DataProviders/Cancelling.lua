local CANCELLING_TABLE_LAYOUT = {
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "name" },
    headerText = AKCHOUSE_L_NAME,
    cellTemplate = "AkcHouseItemKeyCellTemplate",
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_QUANTITY,
    headerParameters = { "quantity" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "quantity" },
    width = 70
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_UNIT_PRICE,
    headerParameters = { "price" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "price" },
    width = 150,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_BID_PRICE,
    headerParameters = { "bidPrice" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "bidPrice" },
    width = 150,
    defaultHide = true,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_BIDDER,
    headerParameters = { "bidder" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "bidder" },
    defaultHide = true,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_TIME_LEFT,
    headerParameters = { "timeLeft" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "timeLeftPretty" },
    width = 90,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_IS_UNDERCUT,
    headerParameters = { "undercut" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "undercut" },
    width = 90,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_UNDERCUT_PRICE,
    headerParameters = { "undercutPrice" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "undercutPrice" },
    width = 150,
    defaultHide = true,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_ITEMS_AHEAD,
    headerParameters = { "itemsAhead" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "itemsAheadPretty" },
    width = 90,
  },
}

local DATA_EVENTS = {
  "OWNED_AUCTIONS_UPDATED",
  "AUCTION_CANCELED",
  "AUCTION_HOUSE_NEW_BID_RECEIVED",
}

local EVENT_BUS_EVENTS = {
  AkcHouse.Cancelling.Events.CancelConfirmed,
  AkcHouse.Cancelling.Events.UndercutStatus,
  AkcHouse.Cancelling.Events.UndercutScanStart,
}

local function DumpOwnedAuctions(callback)
  local result = {}

  local waiting = C_AuctionHouse.GetNumOwnedAuctions()

  for index = 1, C_AuctionHouse.GetNumOwnedAuctions() do
    local index = index
    local info = C_AuctionHouse.GetOwnedAuctionInfo(index)

    table.insert(result, info)

    AkcHouse.AH.GetItemKeyInfo(info.itemKey, function(itemKeyInfo)
      waiting = waiting - 1
      result[index].searchName = itemKeyInfo.itemName
      if waiting == 0 then
        callback(result)
      end
    end)
  end

  if C_AuctionHouse.GetNumOwnedAuctions() == 0 then
    callback(result)
  end
end

AkcHouseCancellingDataProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin, AkcHouseItemKeyLoadingMixin)

function AkcHouseCancellingDataProviderMixin:OnLoad()
  AkcHouseDataProviderMixin.OnLoad(self)
  AkcHouseItemKeyLoadingMixin.OnLoad(self)

  self.waitingforCancellation = {}
  self.beenCancelled = {}

  self.undercutInfo = {}
end

function AkcHouseCancellingDataProviderMixin:OnShow()
  AkcHouse.EventBus:Register(self, EVENT_BUS_EVENTS)

  self:QueryAuctions()

  FrameUtil.RegisterFrameForEvents(self, DATA_EVENTS)
end

function AkcHouseCancellingDataProviderMixin:OnHide()
  AkcHouse.EventBus:Unregister(self, EVENT_BUS_EVENTS)

  FrameUtil.UnregisterFrameForEvents(self, DATA_EVENTS)
end

function AkcHouseCancellingDataProviderMixin:QueryAuctions()
  self.onPreserveScroll()
  self.onSearchStarted()

  AkcHouse.AH.QueryOwnedAuctions({{sortOrder = 1, reverseSort = false}})
end

function AkcHouseCancellingDataProviderMixin:NoQueryRefresh()
  self.onPreserveScroll()
  DumpOwnedAuctions(function(auctions)
    self:PopulateAuctions(auctions)
  end)
end

local COMPARATORS = {
  price = AkcHouse.Utilities.NumberComparator,
  bidPrice = AkcHouse.Utilities.NumberComparator,
  name = AkcHouse.Utilities.StringComparator,
  bidder = AkcHouse.Utilities.StringComparator,
  quantity = AkcHouse.Utilities.NumberComparator,
  timeLeft = AkcHouse.Utilities.NumberComparator,
  undercut = AkcHouse.Utilities.StringComparator,
  undercutPrice = AkcHouse.Utilities.NumberComparator,
  itemsAhead = AkcHouse.Utilities.NumberComparator,
}

function AkcHouseCancellingDataProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end

function AkcHouseCancellingDataProviderMixin:OnEvent(eventName, auctionID, ...)
  if eventName == "AUCTION_CANCELED" then
    if (tIndexOf(self.waitingforCancellation, auctionID) ~= nil and
        tIndexOf(self.beenCancelled, auctionID) == nil) then
      table.insert(self.beenCancelled, auctionID)
      self:NoQueryRefresh()
    else
      self:QueryAuctions()
    end

  elseif eventName == "OWNED_AUCTIONS_UPDATED" then
    DumpOwnedAuctions(function(auctions)
      self:PopulateAuctions(auctions)
    end)
  elseif eventName == "AUCTION_HOUSE_NEW_BID_RECEIVED" then
    self:QueryAuctions()
  end
end

function AkcHouseCancellingDataProviderMixin:ReceiveEvent(eventName, eventData, ...)
  if eventName == AkcHouse.Cancelling.Events.CancelConfirmed then
    table.insert(self.waitingforCancellation, eventData)
    self:NoQueryRefresh()

  elseif eventName == AkcHouse.Cancelling.Events.UndercutScanStart then
    self.undercutInfo = {}

    self:NoQueryRefresh()

  elseif eventName == AkcHouse.Cancelling.Events.UndercutStatus then
    local isUndercut, minPrice, itemsAhead = ...
    if isUndercut then
      self.undercutInfo[eventData] = {state = AKCHOUSE_L_UNDERCUT_YES, minPrice = minPrice, itemsAhead = itemsAhead}
    else
      self.undercutInfo[eventData] = {state = AKCHOUSE_L_UNDERCUT_NO, minPrice = nil, itemsAhead = itemsAhead}
    end

    self:NoQueryRefresh()
  end
end

function AkcHouseCancellingDataProviderMixin:IsValidAuction(auctionInfo)
  return

    auctionInfo.itemKey.itemID ~= AkcHouse.Constants.WOW_TOKEN_ID and
    auctionInfo.status == 0 and
    tIndexOf(self.beenCancelled, auctionInfo.auctionID) == nil
end

function AkcHouseCancellingDataProviderMixin:IsSoldAuction(auctionInfo)
  return
    auctionInfo.itemKey.itemID ~= AkcHouse.Constants.WOW_TOKEN_ID and
    auctionInfo.status == 1
end

function AkcHouseCancellingDataProviderMixin:FilterAuction(auctionInfo)
  return self:GetParent():IsAuctionShown(auctionInfo)
end

function AkcHouseCancellingDataProviderMixin:PopulateAuctions(auctions)
  self:Reset()

  local results = {}
  local totalOnSale = 0
  local totalPending = 0

  for index, info in ipairs(auctions) do
    local price = info.buyoutAmount or info.bidAmount

    if self:IsValidAuction(info) then
      totalOnSale = totalOnSale + price * info.quantity
      if self:FilterAuction(info) then
        local undercutInfo = self.undercutInfo[info.auctionID]
        local entry = {
          id = info.auctionID,
          quantity = info.quantity,
          price = info.buyoutAmount,
          bidPrice = info.bidAmount,
          bidder = info.bidder,
          itemKey = info.itemKey,
          itemLink = info.itemLink,
          timeLeft = info.timeLeftSeconds,
          timeLeftPretty = AkcHouse.Utilities.FormatTimeLeft(info.timeLeftSeconds),
          cancelled = (tIndexOf(self.waitingforCancellation, info.auctionID) ~= nil),
          undercut = undercutInfo and undercutInfo.state or AKCHOUSE_L_UNDERCUT_UNKNOWN,
          undercutPrice = undercutInfo and undercutInfo.minPrice,
          itemsAhead = undercutInfo and undercutInfo.itemsAhead,
          itemsAheadPretty = undercutInfo and FormatLargeNumber(undercutInfo.itemsAhead),
          searchName = info.searchName,
          index = index,
        }
        if info.bidder ~= nil then
          entry.undercut = AKCHOUSE_L_UNDERCUT_BID
        end

        table.insert(results, entry)
      end
    elseif self:IsSoldAuction(info) then
      totalPending = totalPending + price
    end
  end
  table.sort(results, function(a, b)
    if a.bidder and a.bidPrice and (not b.bidder or not b.bidPrice) then
      return true
    elseif b.bidder and b.bidPrice and (not a.bidPrice or not a.bidder) then
      return false
    elseif a.bidPrice and a.bidder and b.bidPrice and b.bidder then
      return a.bidPrice > b.bidPrice
    else
      return a.index < b.index
    end
  end)
  self:AppendEntries(results, true)

  AkcHouse.EventBus:RegisterSource(self, "CancellingDataProvider")
    :Fire(self, AkcHouse.Cancelling.Events.TotalUpdated, totalOnSale, totalPending)
    :UnregisterSource(self)
end

function AkcHouseCancellingDataProviderMixin:UniqueKey(entry)
  return tostring(entry.id)
end

function AkcHouseCancellingDataProviderMixin:GetTableLayout()
  return CANCELLING_TABLE_LAYOUT
end

function AkcHouseCancellingDataProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_CANCELLING)
end

function AkcHouseCancellingDataProviderMixin:GetRowTemplate()
  return "AkcHouseCancellingListResultsRowTemplate"
end
