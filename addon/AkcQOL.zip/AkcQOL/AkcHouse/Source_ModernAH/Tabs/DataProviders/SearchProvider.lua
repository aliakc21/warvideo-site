local SEARCH_PROVIDER_LAYOUT = {
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "price" },
    headerText = AKCHOUSE_L_BUYOUT_PRICE,
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "price" },
    width = 145
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "bidPrice" },
    headerText = AKCHOUSE_L_BID_PRICE,
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "bidPrice" },
    width = 145
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_RESULTS_AVAILABLE_COLUMN,
    headerParameters = { "quantity" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "quantityFormatted" },
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_ITEM_LEVEL_COLUMN,
    headerParameters = { "level" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "levelPretty" },
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "timeLeft" },
    headerText = AKCHOUSE_L_TIME_LEFT,
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "timeLeftPretty" },
    defaultHide = true,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "otherSellers" },
    headerText = AKCHOUSE_L_SELLERS_COLUMN,
    cellTemplate = "AkcHouseTooltipStringCellTemplate",
    cellParameters = { "otherSellers" },
    defaultHide = true,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerParameters = { "owned" },
    headerText = AKCHOUSE_L_OWNED_COLUMN,
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "owned" },
    width = 70
  },
}

local SEARCH_EVENTS = {
  "COMMODITY_SEARCH_RESULTS_UPDATED",
  "COMMODITY_PURCHASE_SUCCEEDED",
  "ITEM_SEARCH_RESULTS_UPDATED",
}

AkcHouseSearchDataProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin)

function AkcHouseSearchDataProviderMixin:OnShow()
  FrameUtil.RegisterFrameForEvents(self, SEARCH_EVENTS)
  AkcHouse.EventBus:Register(self, {
    AkcHouse.Selling.Events.SellSearchStart,
    AkcHouse.Selling.Events.BagItemClicked,
    AkcHouse.Selling.Events.ClearBagItem,
    AkcHouse.Cancelling.Events.RequestCancel,
  })

  self:Reset()
end

function AkcHouseSearchDataProviderMixin:OnHide()
  FrameUtil.UnregisterFrameForEvents(self, SEARCH_EVENTS)
  AkcHouse.EventBus:Unregister(self, {
    AkcHouse.Selling.Events.SellSearchStart,
    AkcHouse.Selling.Events.BagItemClicked,
    AkcHouse.Selling.Events.ClearBagItem,
    AkcHouse.Cancelling.Events.RequestCancel,
  })
end

function AkcHouseSearchDataProviderMixin:ReceiveEvent(eventName, itemKey, originalItemLink, originalKey)
  if eventName == AkcHouse.Selling.Events.SellSearchStart then
    self:Reset()
    self.onSearchStarted()

    self.expectedItemKey = itemKey
    self.originalItemKey = originalKey
    self.originalItemLink = originalItemLink
  elseif eventName == AkcHouse.Selling.Events.BagItemClicked then
    self.onResetScroll()
  elseif eventName == AkcHouse.Selling.Events.ClearBagItem then
    self:Reset()
  elseif eventName == AkcHouse.Cancelling.Events.RequestCancel then
    self:RegisterEvent("AUCTION_CANCELED")
  end
end

function AkcHouseSearchDataProviderMixin:GetTableLayout()
  return SEARCH_PROVIDER_LAYOUT
end

function AkcHouseSearchDataProviderMixin:GetColumnHideStates()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.COLUMNS_SELLING_SEARCH)
end

local COMPARATORS = {
  price = AkcHouse.Utilities.NumberComparator,
  bidPrice = AkcHouse.Utilities.NumberComparator,
  quantity = AkcHouse.Utilities.NumberComparator,
  level = AkcHouse.Utilities.NumberComparator,
  timeLeft = AkcHouse.Utilities.NumberComparator,
  owned = AkcHouse.Utilities.StringComparator,
  otherSellers = AkcHouse.Utilities.StringComparator,
}

function AkcHouseSearchDataProviderMixin:UniqueKey(entry)
  return entry.auctionID
end

function AkcHouseSearchDataProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end

function AkcHouseSearchDataProviderMixin:OnEvent(eventName, itemRef, auctionID)
  if eventName == "COMMODITY_SEARCH_RESULTS_UPDATED" and self.expectedItemKey ~= nil and
          self.expectedItemKey.itemID == itemRef then
    self:Reset()
    self:AppendEntries(self:ProcessCommodityResults(itemRef), true)

  elseif (eventName == "ITEM_SEARCH_RESULTS_UPDATED" and self.expectedItemKey ~= nil and
          AkcHouse.Utilities.ItemKeyString(self.expectedItemKey) == AkcHouse.Utilities.ItemKeyString(itemRef)
        ) then
    self.onPreserveScroll()
    self:Reset()
    self:ProcessItemResults(itemRef)

  elseif eventName == "COMMODITY_PURCHASE_SUCCEEDED" then
    self.onPreserveScroll()
    self:RefreshView()

  elseif eventName == "AUCTION_CANCELED" then
    self:UnregisterEvent("AUCTION_CANCELED")
    self.onPreserveScroll()
    self:RefreshView()
  end
end

function AkcHouseSearchDataProviderMixin:RefreshView()
  self.onPreserveScroll()
  AkcHouse.EventBus
    :RegisterSource(self, "AkcHouseSearchDataProviderMixin")
    :Fire(self, AkcHouse.Selling.Events.RefreshSearch)
    :UnregisterSource(self)
end

local function cancelShortcutEnabled()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT) ~= AkcHouse.Config.Shortcuts.NONE
end

function AkcHouseSearchDataProviderMixin:ProcessCommodityResults(itemID)
  local entries = {}
  local anyOwnedNotLoaded = false

  for index = 1, C_AuctionHouse.GetNumCommoditySearchResults(itemID) do
    local resultInfo = C_AuctionHouse.GetCommoditySearchResultInfo(itemID, index)
    local entry = {
      price = resultInfo.unitPrice,
      bidPrice = nil,
      owners = resultInfo.owners,
      totalNumberOfOwners = resultInfo.totalNumberOfOwners,
      otherSellers = AkcHouse.Utilities.StringJoin(resultInfo.owners, PLAYER_LIST_DELIMITER),
      quantity = resultInfo.quantity,
      quantityFormatted = FormatLargeNumber(resultInfo.quantity),
      level = 0,
      levelPretty = "0",
      timeLeftPretty = AkcHouse.Utilities.FormatTimeLeft(resultInfo.timeLeftSeconds),
      timeLeft = resultInfo.timeLeftSeconds or 0,
      auctionID = resultInfo.auctionID,
      itemID = itemID,
      itemType = AkcHouse.Constants.ITEM_TYPES.COMMODITY,
      canBuy = not (resultInfo.containsOwnerItem or resultInfo.containsAccountItem)
    }

    if #entry.owners > 0 and #entry.owners < entry.totalNumberOfOwners then
      entry.otherSellers = AKCHOUSE_L_SELLERS_OVERFLOW_TEXT:format(entry.otherSellers, entry.totalNumberOfOwners - #entry.owners)
    end

    if resultInfo.containsOwnerItem then

      if not C_AuctionHouse.CanCancelAuction(resultInfo.auctionID) then
        anyOwnedNotLoaded = true
      end

      entry.otherSellers = GREEN_FONT_COLOR:WrapTextInColorCode(AUCTION_HOUSE_SELLER_YOU)
      entry.owned = AKCHOUSE_L_UNDERCUT_YES

    else
      entry.owned = GRAY_FONT_COLOR:WrapTextInColorCode(AKCHOUSE_L_UNDERCUT_NO)
    end

    table.insert(entries, entry)
  end

  if anyOwnedNotLoaded and cancelShortcutEnabled() then
    AkcHouse.AH.QueryOwnedAuctions({})
  end

  return entries
end

function AkcHouseSearchDataProviderMixin:ProcessItemResults(itemKey)
  local entries = {}
  local anyOwnedNotLoaded = false

  local item = Item:CreateFromItemID(itemKey.itemID)
  item:ContinueOnItemLoad(function()
    for index = 1, C_AuctionHouse.GetNumItemSearchResults(itemKey) do
      local resultInfo = C_AuctionHouse.GetItemSearchResultInfo(itemKey, index)
      if AkcHouse.Selling.DoesItemMatchFromKey(self.originalItemKey, self.originalItemLink, resultInfo.itemKey, resultInfo.itemLink) then
        local entry = AkcHouse.Search.GetBuyItemResult(resultInfo)

        if resultInfo.containsOwnerItem and not C_AuctionHouse.CanCancelAuction(resultInfo.auctionID) then
          anyOwnedNotLoaded = true
        end

        table.insert(entries, entry)
      end
    end

    if anyOwnedNotLoaded and cancelShortcutEnabled() then
      AkcHouse.AH.QueryOwnedAuctions({})
    end
    self:AppendEntries(entries, true)
  end)
end

function AkcHouseSearchDataProviderMixin:GetRowTemplate()
  return "AkcHouseSellSearchRowTemplate"
end
