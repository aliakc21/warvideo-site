AkcHouseTabContainerMixin = {}

local LibAHTab = LibStub("LibAHTab-1-0")

local padding = 0
local absoluteSize = nil
local minTabWidth = 36

function AkcHouseTabContainerMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseTabContainerMixin:OnLoad()")

  table.sort(
    AkcHouse.Tabs.State.knownTabs,
    function(left, right)
      return left.tabOrder < right.tabOrder
    end
  )

  self.Tabs = {}

  for _, details in ipairs(AkcHouse.Tabs.State.knownTabs) do
    local frameRef = CreateFrame(
      "FRAME",
      details.tabFrameName,
      AuctionHouseFrame,
      details.tabTemplate
    )
    local buttonFrameName = "AkcHouseTabs_" .. details.name
    LibAHTab:CreateTab(buttonFrameName, frameRef, details.textLabel, details.tabHeader)
    _G[buttonFrameName] = LibAHTab:GetButton(buttonFrameName)
    table.insert(AkcHouseAHTabsContainer.Tabs, _G[buttonFrameName])

    _G[buttonFrameName]:HookScript("OnShow", function(tab)
      if AkcHouse.Config.Get(AkcHouse.Config.Options.SMALL_TABS) then
        PanelTemplates_TabResize(tab, padding, absoluteSize, minTabWidth)
      end
    end)
    if AkcHouse.Config.Get(AkcHouse.Config.Options.SMALL_TABS) then
      PanelTemplates_TabResize(_G[buttonFrameName], padding, absoluteSize, minTabWidth)
    end
  end
end

function AkcHouseTabContainerMixin:OnShow()
  if AkcHouse.Config.Get(AkcHouse.Config.Options.SMALL_TABS) then
    for _, tab in ipairs(AuctionHouseFrame.Tabs) do
      PanelTemplates_TabResize(tab, padding, absoluteSize, minTabWidth)
    end
  end
end
