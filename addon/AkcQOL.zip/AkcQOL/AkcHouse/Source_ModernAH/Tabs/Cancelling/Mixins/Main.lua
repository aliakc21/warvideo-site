AkcHouseCancellingFrameMixin = {}

function AkcHouseCancellingFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseCancellingFrameMixin:OnLoad()")

  self.ResultsListing:Init(self.DataProvider)

  AkcHouse.EventBus:Register(self, {
    AkcHouse.Cancelling.Events.RequestCancel,
    AkcHouse.Cancelling.Events.TotalUpdated,
  })

  self.SearchFilter:HookScript("OnTextChanged", function()
    self.DataProvider:NoQueryRefresh()
  end)
end

function AkcHouseCancellingFrameMixin:RefreshButtonClicked()
  self.DataProvider:QueryAuctions()
end

function AkcHouseCancellingFrameMixin:IsAuctionShown(auctionInfo)
  local searchString = self.SearchFilter:GetText()
  if searchString ~= "" then
    local exact = searchString:match("^\"(.*)\"$")
    local name = string.lower(auctionInfo.searchName)
    if exact then
      return name == exact
    else
      return string.find(name, string.lower(searchString), 1, true)
    end
  else
    return true
  end
end

function AkcHouseCancellingFrameMixin:ReceiveEvent(eventName, ...)
  if eventName == AkcHouse.Cancelling.Events.RequestCancel then
    local auctionID = ...
    AkcHouse.Debug.Message("Executing cancel request", auctionID)

    local cancelCost = C_AuctionHouse.GetCancelCost(auctionID)
    if cancelCost > 0 then
      AkcHouse.Dialogs.ShowMoney(AKCHOUSE_L_BID_EXISTING_ON_OWNED_AUCTION, cancelCost, ACCEPT, CANCEL, function()
        AkcHouse.AH.CancelAuction(auctionID)
        AkcHouse.EventBus:RegisterSource(self, "CancellingFramePopupDialog")
          :Fire(self, AkcHouse.Cancelling.Events.CancelConfirmed, auctionID)
          :UnregisterSource(self)
      end)
    else
      AkcHouse.AH.CancelAuction(auctionID)
      AkcHouse.EventBus:RegisterSource(self, "CancellingFrame")
        :Fire(self, AkcHouse.Cancelling.Events.CancelConfirmed, auctionID)
    end

    PlaySound(SOUNDKIT.IG_MAINMENU_OPEN)

  elseif eventName == AkcHouse.Cancelling.Events.TotalUpdated then
    local totalOnSale, totalPending = ...

    local text = AKCHOUSE_L_TOTAL_ON_SALE:format(
        GetMoneyString(totalOnSale, true)
      )
    if totalPending > 0 then
      text = text .. " " ..
      AKCHOUSE_L_TOTAL_PENDING:format(
        GetMoneyString(totalPending, true)
      )
    end

    self.Total:SetText(text)
  end
end
