AkcHouseShoppingResultsRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseShoppingResultsRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHouseShoppingResultsRowMixin:OnClick()")

  if IsModifiedClick("DRESSUP") then
    AuctionHouseBrowseResultsFrameMixin.OnBrowseResultSelected({}, self.rowData)

  elseif button == "RightButton" then
    AkcHouse.EventBus
      :RegisterSource(self, "ShoppingResultsRowMixin")
      :Fire(self, AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices, self.rowData)
      :UnregisterSource(self)

  elseif IsShiftKeyDown() then
    AkcHouse.EventBus
      :RegisterSource(self, "ShoppingResultsRowMixin")
      :Fire(self, AkcHouse.Shopping.Tab.Events.UpdateSearchTerm, self.rowData.plainItemName)
      :UnregisterSource(self)
  else
    AkcHouseResultsRowTemplateMixin.OnClick(self, button, ...)

    if C_AuctionHouse.GetItemKeyInfo(self.rowData.itemKey) then
      local itemKeyInfo = C_AuctionHouse.GetItemKeyInfo(self.rowData.itemKey)
      if itemKeyInfo.isCommodity then
        AkcHouse.EventBus
          :RegisterSource(self, "ShoppingResultsRowMixin")
          :Fire(self, AkcHouse.Buying.Events.ShowCommodityBuy, self.rowData, itemKeyInfo)
          :UnregisterSource(self)
      else
        AkcHouse.EventBus
          :RegisterSource(self, "ShoppingResultsRowMixin")
          :Fire(self, AkcHouse.Buying.Events.ShowItemBuy, self.rowData, itemKeyInfo)
          :UnregisterSource(self)
      end
      AkcHouse.EventBus
        :RegisterSource(self, "ShoppingResultsRowMixin")
        :Fire(self, AkcHouse.Shopping.Tab.Events.BuyScreenShown)
        :UnregisterSource(self)
    end
  end
end
