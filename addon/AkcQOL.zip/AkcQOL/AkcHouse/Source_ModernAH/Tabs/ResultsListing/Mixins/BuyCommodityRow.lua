AkcHouseBuyCommodityRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseBuyCommodityRowMixin:Populate(rowData, ...)
  AkcHouseResultsRowTemplateMixin.Populate(self, rowData, ...)
  self.SelectedHighlight:SetShown(rowData.selected)
end

function AkcHouseBuyCommodityRowMixin:OnEnter()
  AkcHouseResultsRowTemplateMixin.OnEnter(self)
  GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
  if self.rowData.otherSellers ~= "" then
    GameTooltip:SetText(NORMAL_FONT_COLOR:WrapTextInColorCode(AUCTION_HOUSE_TOOLTIP_MULTIPLE_SELLERS_FORMAT:format(self.rowData.otherSellers)))
    GameTooltip:Show()
  end
end

function AkcHouseBuyCommodityRowMixin:OnLeave()
  AkcHouseResultsRowTemplateMixin.OnLeave(self)
  GameTooltip:Hide()
end

function AkcHouseBuyCommodityRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHouseBuyCommodityRowMixin:OnClick()")
  AkcHouse.EventBus
    :RegisterSource(self, "BuyCommodityRowMixin")
    :Fire(self, AkcHouse.Buying.Events.SelectCommodityRow, self.rowData.rowIndex)
    :UnregisterSource(self)
end
