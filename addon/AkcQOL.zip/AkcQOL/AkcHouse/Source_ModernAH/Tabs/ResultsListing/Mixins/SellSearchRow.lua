AkcHouseSellSearchRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

local function BuyEntry(entry)
  AkcHouse.EventBus
    :RegisterSource(BuyEntry, "BuyEntry")
    :Fire(BuyEntry, AkcHouse.Selling.Events.ShowConfirmPurchase, entry)
    :UnregisterSource(BuyEntry)
end

function AkcHouseSellSearchRowMixin:OnEnter()
  if AuctionHouseUtil ~= nil then
    AuctionHouseUtil.LineOnEnterCallback(self, self.rowData)
  end
  AkcHouseResultsRowTemplateMixin.OnEnter(self)
end

function AkcHouseSellSearchRowMixin:OnLeave()
  if AuctionHouseUtil ~= nil then
    AuctionHouseUtil.LineOnLeaveCallback(self, self.rowData)
  end
  AkcHouseResultsRowTemplateMixin.OnLeave(self)
end

function AkcHouseSellSearchRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHouseSellSearchRowMixin:OnClick()")

  if AkcHouse.Utilities.IsShortcutActive(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT), button) then
    if C_AuctionHouse.CanCancelAuction(self.rowData.auctionID) then
      AkcHouse.EventBus
        :RegisterSource(self, "SellSearchRow")
        :Fire(self, AkcHouse.Cancelling.Events.RequestCancel, self.rowData.auctionID)
        :UnregisterSource(self)
    end

  elseif AkcHouse.Utilities.IsShortcutActive(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_BUY_SHORTCUT), button) then
    if self.rowData.canBuy then
      BuyEntry(self.rowData)
    end

  elseif IsModifiedClick("DRESSUP") then
    DressUpLink(self.rowData.itemLink);

  elseif IsModifiedClick("CHATLINK") then
    AkcHouse.Utilities.InsertLink(self.rowData.itemLink)

  else
    AkcHouse.EventBus
      :RegisterSource(self, "SellSearchRow")
      :Fire(self, AkcHouse.Selling.Events.PriceSelected, {buyout = self.rowData.price, bid = self.rowData.bidPrice}, true)
      :UnregisterSource(self)
  end
end
