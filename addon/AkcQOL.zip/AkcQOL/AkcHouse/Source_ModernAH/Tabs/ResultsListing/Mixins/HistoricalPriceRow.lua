AkcHouseHistoricalPriceRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseHistoricalPriceRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHouseHistoricalPriceRowMixin:OnClick()")

  if button == "LeftButton" then
    AkcHouse.EventBus
      :RegisterSource(self, "HistoricalPriceRow")
      :Fire(self, AkcHouse.Selling.Events.PriceSelected, {buyout = self.rowData.minSeen})
      :UnregisterSource(self)
  elseif button == "RightButton" then
    AkcHouse.EventBus
      :RegisterSource(self, "HistoricalPriceRow")
      :Fire(self, AkcHouse.Selling.Events.PriceSelected, {buyout = self.rowData.maxSeen})
      :UnregisterSource(self)
  end
end
