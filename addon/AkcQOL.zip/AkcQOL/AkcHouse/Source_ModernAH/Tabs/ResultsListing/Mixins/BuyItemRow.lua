AkcHouseBuyItemRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseBuyItemRowMixin:OnEnter()
  if AuctionHouseUtil ~= nil then
    AuctionHouseUtil.LineOnEnterCallback(self, self.rowData)
  end
  AkcHouseResultsRowTemplateMixin.OnEnter(self)
end

function AkcHouseBuyItemRowMixin:Populate(rowData, ...)
  AkcHouseResultsRowTemplateMixin.Populate(self, rowData, ...)

  self.BidderHighlight:SetShown(rowData.bidder ~= nil and rowData.containsOwnerItem)
  self.OwnedHighlight:SetShown(rowData.bidder == nil and rowData.containsOwnerItem)
end

function AkcHouseBuyItemRowMixin:OnLeave()
  if AuctionHouseUtil ~= nil then
    AuctionHouseUtil.LineOnLeaveCallback(self, self.rowData)
  end
  AkcHouseResultsRowTemplateMixin.OnLeave(self)
end

function AkcHouseBuyItemRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHouseBuyItemRowMixin:OnClick()")

  if AkcHouse.Utilities.IsShortcutActive(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_CANCEL_SHORTCUT), button) then
    if C_AuctionHouse.CanCancelAuction(self.rowData.auctionID) then
      AkcHouse.EventBus
        :RegisterSource(self, "BuyItemRow")
        :Fire(self, AkcHouse.Cancelling.Events.RequestCancel, self.rowData.auctionID)
        :UnregisterSource(self)
    end

  elseif IsModifiedClick("DRESSUP") then
    DressUpLink(self.rowData.itemLink);

  elseif IsModifiedClick("CHATLINK") then
    AkcHouse.Utilities.InsertLink(self.rowData.itemLink)

  elseif self.rowData.canBuy then
    AkcHouse.EventBus
      :RegisterSource(self, "BuyItemRow")
      :Fire(self, AkcHouse.Buying.Events.ShowItemConfirmation, self.rowData)
      :UnregisterSource(self)
  end
end
