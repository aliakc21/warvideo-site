AkcHouseSellingPostingHistoryRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseSellingPostingHistoryRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHousePostingHistoryRowMixin:OnClick()")

  AkcHouse.EventBus
    :RegisterSource(self, "SellingPostingHistoryRow")
    :Fire(self, AkcHouse.Selling.Events.PriceSelected, {buyout = self.rowData.price, bid = self.rowData.bidPrice})
    :UnregisterSource(self)
end
