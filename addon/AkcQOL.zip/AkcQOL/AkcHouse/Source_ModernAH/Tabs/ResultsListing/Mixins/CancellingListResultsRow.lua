AkcHouseCancellingListResultsRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseCancellingListResultsRowMixin:OnClick(button, ...)
  AkcHouse.Debug.Message("AkcHouseCancellingListResultsRowMixin:OnClick", self.rowData and self.rowData.id)

  if IsModifiedClick("DRESSUP") then
    DressUpLink(self.rowData.itemLink);

  elseif IsModifiedClick("CHATLINK") then
    AkcHouse.Utilities.InsertLink(self.rowData.itemLink)

  elseif button == "LeftButton" then
    AkcHouse.EventBus
      :RegisterSource(self, "CancellingListResultRow")
      :Fire(self, AkcHouse.Cancelling.Events.RequestCancel, self.rowData.id)
      :UnregisterSource(self)
  elseif button == "RightButton" then
    if AkcHouse.Utilities.IsEquipment(select(6, C_Item.GetItemInfoInstant(self.rowData.itemKey.itemID))) and
       self.rowData.itemKey.itemLevel < AkcHouse.Constants.ITEM_LEVEL_THRESHOLD then
      local item = Item:CreateFromItemID(self.rowData.itemKey.itemID)
      item:ContinueOnItemLoad(function()
        AkcHouse.API.v1.MultiSearch(AKCHOUSE_L_CANCELLING_TAB, { item:GetItemName() })
      end)
    else
      AkcHouse.API.v1.MultiSearchExact(AKCHOUSE_L_CANCELLING_TAB, { self.rowData.searchName })
    end
  end
end

function AkcHouseCancellingListResultsRowMixin:Populate(rowData, dataIndex)
  AkcHouseResultsRowTemplateMixin.Populate(self, rowData, dataIndex)

  self:ApplyFade()
  self:ApplyUndercutHighlight()
  self:ApplyBidderHighlight()
end

function AkcHouseCancellingListResultsRowMixin:ApplyFade()

  if self.rowData.cancelled then
    self:SetAlpha(0.5)
  else
    self:SetAlpha(1)
  end
end

function AkcHouseCancellingListResultsRowMixin:ApplyUndercutHighlight()
  self.SelectedHighlight:SetShown(self.rowData.undercut == AKCHOUSE_L_UNDERCUT_YES)
end

function AkcHouseCancellingListResultsRowMixin:ApplyBidderHighlight()
  self.BidderHighlight:SetShown(self.rowData.bidder ~= nil)
end
