AkcHouseFullScanStatusMixin = {}

function AkcHouseFullScanStatusMixin:OnLoad()
  AkcHouse.EventBus:Register(self, {
    AkcHouse.IncrementalScan.Events.ScanStart,
    AkcHouse.IncrementalScan.Events.ScanProgress,
    AkcHouse.IncrementalScan.Events.ScanComplete,
    AkcHouse.IncrementalScan.Events.ScanFailed,
    AkcHouse.FullScan.Events.ScanStart,
    AkcHouse.FullScan.Events.ScanProgress,
    AkcHouse.FullScan.Events.ScanComplete,
    AkcHouse.FullScan.Events.ScanFailed,
  })
end

function AkcHouseFullScanStatusMixin:OnShow()
  self.Text:SetText("")
end

function AkcHouseFullScanStatusMixin:ReceiveEvent(event, eventData)
  if event == AkcHouse.IncrementalScan.Events.ScanStart or event == AkcHouse.FullScan.Events.ScanStart then
    self.Text:SetText("0%")

  elseif event == AkcHouse.IncrementalScan.Events.ScanProgress or event == AkcHouse.FullScan.Events.ScanProgress then
    self.Text:SetText(tostring(math.floor(eventData*100)) .. "%")

  elseif event == AkcHouse.IncrementalScan.Events.ScanComplete or event == AkcHouse.FullScan.Events.ScanComplete then
    self.Text:SetText("100%")

  else
    self.Text:SetText("")
  end
end
