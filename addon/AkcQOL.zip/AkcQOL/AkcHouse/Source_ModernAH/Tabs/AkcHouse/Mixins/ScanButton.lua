AkcHouseScanButtonMixin = {}

function AkcHouseScanButtonMixin:OnClick()
  if AkcHouse.Config.Get(AkcHouse.Config.Options.REPLICATE_SCAN) then
    AkcHouse.State.FullScanFrameRef:InitiateScan()
  else
    AkcHouse.State.IncrementalScanFrameRef:InitiateScan()
  end
end
