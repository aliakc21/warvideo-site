AkcHouseBuyCommodityWidePriceRangeWarningDialogMixin = {}

function AkcHouseBuyCommodityWidePriceRangeWarningDialogMixin:OnHide()
  self:Hide()
end

function AkcHouseBuyCommodityWidePriceRangeWarningDialogMixin:SetDetails(details)
  self.PurchaseDetails:SetText(
    RED_FONT_COLOR:WrapTextInColorCode(AKCHOUSE_L_CAREFUL_CAPS) .. "\n\n" ..
    AKCHOUSE_L_PRICE_VARIES_WARNING .. "\n\n" ..
    AKCHOUSE_L_UNIT_PRICE_RANGE:format(
      GetMoneyString(details.minUnitPrice, true),
      GetMoneyString(details.maxUnitPrice, true)
    )
  )
  self:Show()
end

function AkcHouseBuyCommodityWidePriceRangeWarningDialogMixin:StartPurchase()
  self:GetParent():ForceStartPurchase()
  self:Hide()
end

AkcHouseBuyCommodityFinalConfirmationDialogMixin = {}

function AkcHouseBuyCommodityFinalConfirmationDialogMixin:OnHide()
  self:Hide()
  if self.purchasePending then
    C_AuctionHouse.CancelCommoditiesPurchase()
    self.purchasePending = false
  end
end

function AkcHouseBuyCommodityFinalConfirmationDialogMixin:SetDetails(details)
  self.itemID = details.itemID
  self.quantity = details.quantity
  self.PurchaseDetails:SetText(details.prefix .. AKCHOUSE_L_CONFIRM_PURCHASE_OF_X_FOR_X
    :format(AkcHouse.Utilities.CreateCountString(details.quantity),
      GetMoneyString(details.total, true)) .. "\n\n" ..
    AKCHOUSE_L_BRACKETS_X_EACH:format(GetMoneyString(details.unitPrice, true))
    )
  self.purchasePending = true
  self:Show()
end

function AkcHouseBuyCommodityFinalConfirmationDialogMixin:ConfirmPurchase()
  C_AuctionHouse.ConfirmCommoditiesPurchase(self.itemID, self.quantity)
  self.purchasePending = false
  self:Hide()
end

AkcHouseBuyCommodityQuantityCheckConfirmationDialogMixin = {}

function AkcHouseBuyCommodityQuantityCheckConfirmationDialogMixin:OnHide()
  self:Hide()
  if self.purchasePending then
    C_AuctionHouse.CancelCommoditiesPurchase()
  end
end

function AkcHouseBuyCommodityQuantityCheckConfirmationDialogMixin:SetDetails(details)
  self.itemID = details.itemID
  self.quantity = details.quantity
  self.PurchaseDetails:SetText(
    details.prefix ..
    details.message:format(GetMoneyString(details.total, true), GetMoneyString(details.unitPrice, true))
    .. "\n\n" ..
    AKCHOUSE_L_ENTER_QUANTITY_TO_CONFIRM_PURCHASE:format(self.quantity)
    )
  self.QuantityInput:SetText("")
  self.purchasePending = true
  self:Show()
  self.QuantityInput:SetFocus()
end

function AkcHouseBuyCommodityQuantityCheckConfirmationDialogMixin:ConfirmPurchase()
  if tonumber(self.QuantityInput:GetText()) == self.quantity then
    C_AuctionHouse.ConfirmCommoditiesPurchase(self.itemID, self.quantity)
    self.purchasePending = false
    self:Hide()
  end
end
