AkcHouseBuyItemFrameTemplateMixin = {}

function AkcHouseBuyItemFrameTemplateMixin:OnLoad()
  AkcHouse.EventBus:Register(self, {
    AkcHouse.Buying.Events.ShowItemBuy,
    AkcHouse.Shopping.Tab.Events.SearchStart,
  })

  self.ResultsListing:Init(self.DataProvider)
end

function AkcHouseBuyItemFrameTemplateMixin:OnShow()
  self:GetParent().ResultsListing:Hide()
  self:GetParent().ShoppingResultsInset:Hide()
  self:GetParent().ExportCSV:Hide()
end

function AkcHouseBuyItemFrameTemplateMixin:OnHide()
  self:GetParent().ResultsListing:Show()
  self:GetParent().ShoppingResultsInset:Show()
  self:GetParent().ExportCSV:Show()
  self:Hide()
end

function AkcHouseBuyItemFrameTemplateMixin:ReceiveEvent(eventName, ...)
  if eventName == AkcHouse.Buying.Events.ShowItemBuy then
    local rowData, itemKeyInfo = ...

    self:Show()
    local prettyName = AuctionHouseUtil.GetItemDisplayTextFromItemKey(
      rowData.itemKey,
      itemKeyInfo,
      false
    )
    self.IconAndName:SetItem(rowData.itemKey, nil, itemKeyInfo.quality, prettyName, itemKeyInfo.iconFileID)
    self.IconAndName:SetScript("OnMouseUp", function()
      AuctionHouseFrame:SelectBrowseResult(rowData)

      AuctionHouseFrame.displayMode = nil
    end)

    local sortingOrder = AkcHouse.Constants.ItemResultsSorts
    self.expectedItemKey = rowData.itemKey
    self:Search()
  elseif eventName == AkcHouse.Shopping.Tab.Events.SearchStart then
    self:Hide()
  end
end

function AkcHouseBuyItemFrameTemplateMixin:Search()
  if not self.expectedItemKey then
    return
  end

  AkcHouse.EventBus
    :RegisterSource(self, "BuyItemFrame")
    :Fire(self, AkcHouse.Buying.Events.RefreshingItems)
    :UnregisterSource(self)
  local sortingOrder = AkcHouse.Constants.ItemResultsSorts
  AkcHouse.AH.SendSearchQueryByItemKey(self.expectedItemKey, {sortingOrder}, true)
end
