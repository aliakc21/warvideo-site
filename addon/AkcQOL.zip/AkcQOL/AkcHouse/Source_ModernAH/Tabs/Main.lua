AkcHouse.Tabs = {}

AkcHouse.Tabs.State = {
  knownTabs = {}
}

function AkcHouse.Tabs.Register(details)
  table.insert(AkcHouse.Tabs.State.knownTabs, details)
end

AkcHouse.Tabs.Register( {
  name = "Shopping",
  textLabel = AKCHOUSE_L_SHOPPING_TAB,
  tabTemplate = "AkcHouseShoppingTabFrameTemplate",
  tabHeader = AKCHOUSE_L_SHOPPING_TAB_HEADER_2,
  tabFrameName = "AkcHouseShoppingFrame",
  tabOrder = 1,
})
AkcHouse.Tabs.Register( {
  name = "AkcHouse",
  textLabel = AKCHOUSE_L_AKCHOUSE,
  tabTemplate = "AkcHouseConfigurationTabFrameTemplate",
  tabHeader = AKCHOUSE_L_INFO_TAB_HEADER,
  tabFrameName = "AkcHouseConfigFrame",
  tabOrder = 4,
})
AkcHouse.Tabs.Register( {
  name = "Cancelling",
  textLabel = AKCHOUSE_L_CANCELLING_TAB,
  tabTemplate = "AkcHouseCancellingTabFrameTemplate",
  tabHeader = AKCHOUSE_L_CANCELLING_TAB_HEADER,
  tabFrameName = "AkcHouseCancellingFrame",
  tabOrder = 3,
})
AkcHouse.Tabs.Register( {
  name = "Selling",
  textLabel = AKCHOUSE_L_SELLING_TAB,
  tabTemplate = "AkcHouseSellingTabFrameTemplate",
  tabHeader = AKCHOUSE_L_SELLING_TAB_HEADER,
  tabFrameName = "AkcHouseSellingFrame",
  tabOrder = 2,
})
