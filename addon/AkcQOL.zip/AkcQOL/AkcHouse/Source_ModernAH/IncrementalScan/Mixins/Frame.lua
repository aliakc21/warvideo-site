AkcHouseIncrementalScanFrameMixin = {}

local INCREMENTAL_SCAN_EVENTS = {
  "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
  "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED",
  "AUCTION_HOUSE_CLOSED"
}

function AkcHouseIncrementalScanFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseIncrementalScanFrameMixin:OnLoad")
  AkcHouse.EventBus:RegisterSource(self, "AkcHouseIncrementalScanFrameMixin")

  self.doingFullScan = false
  self.state = AkcHouse.SavedState

  self:RegisterForEvents()
end

function AkcHouseIncrementalScanFrameMixin:RegisterForEvents()
  AkcHouse.Debug.Message("AkcHouseIncrementalScanFrameMixin:RegisterForEvents()")

  FrameUtil.RegisterFrameForEvents(self, INCREMENTAL_SCAN_EVENTS)
end

function AkcHouseIncrementalScanFrameMixin:UnregisterForEvents()
  AkcHouse.Debug.Message("AkcHouseIncrementalScanFrameMixin:UnregisterForEvents()")

  FrameUtil.UnregisterFrameForEvents(self, INCREMENTAL_SCAN_EVENTS)
end

function AkcHouseIncrementalScanFrameMixin:OnEvent(event, ...)
  if event == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then
    self.info = {}
    self.rawScan = {}

    local browseResults = C_AuctionHouse.GetBrowseResults()

    if #browseResults <= AkcHouse.Constants.SummaryBatchSize then
      self:AddPrices(browseResults)
      self:NextStep()
    end
  elseif event == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
    self:AddPrices(...)
    self:NextStep()

  elseif event == "AUCTION_HOUSE_CLOSED" and self.doingFullScan then
    self.doingFullScan = false
    AkcHouse.Utilities.Message(AKCHOUSE_L_FULL_SCAN_FAILED_SUMMARY)
    AkcHouse.EventBus:Fire(self, AkcHouse.IncrementalScan.Events.ScanFailed)
  end
end

function AkcHouseIncrementalScanFrameMixin:IsAutoscanReady()
  local timeSinceLastScan = time() - (self.state.TimeOfLastBrowseScan or 0)

  return timeSinceLastScan >= (AkcHouse.Config.Get(AkcHouse.Config.Options.AUTOSCAN_INTERVAL) * 60)
end

function AkcHouseIncrementalScanFrameMixin:InitiateScan()
  if not self.doingFullScan then
    AkcHouse.Utilities.Message(AKCHOUSE_L_STARTING_FULL_SCAN_SUMMARY)
    self.state.TimeOfLastBrowseScan = time()
    AkcHouse.AH.SendBrowseQuery({searchString = "", sorts = {}, filters = {}, itemClassFilters = {}})
    self.previousDatabaseCount = AkcHouse.Database:GetItemCount()
    self.doingFullScan = true

    AkcHouse.EventBus:Fire(self, AkcHouse.IncrementalScan.Events.ScanStart)
    self:FireProgressEvent()
  else
    AkcHouse.Utilities.Message(AKCHOUSE_L_FULL_SCAN_IN_PROGRESS)
  end
end

function AkcHouseIncrementalScanFrameMixin:FireProgressEvent()
  local infoCount = 0

  if self.info ~= nil then
    for _, _  in pairs(self.info) do
      infoCount = infoCount + 1
    end
  end

  local dbCount = AkcHouse.Database:GetItemCount()

  local progress = 0.1

  if dbCount == 0 then

    progress = 0.5
  elseif dbCount > infoCount then

    progress = progress + 0.8 * infoCount / dbCount
  else

    progress = 0.9
  end

  AkcHouse.EventBus:Fire(self, AkcHouse.IncrementalScan.Events.ScanProgress, progress)
end

function AkcHouseIncrementalScanFrameMixin:AddPrices(results)
  AkcHouse.Debug.Message("AkcHouseIncrementalScanFrameMixin:AddPrices()", results)

  for _, resultInfo in ipairs(results) do
    if resultInfo.totalQuantity ~= 0 then
      local allDBKeys = AkcHouse.Utilities.DBKeyFromBrowseResult(resultInfo)

      for index, dbKey in ipairs(allDBKeys) do
        if self.info[dbKey] == nil then
          self.info[dbKey] = {}
        end

        table.insert(self.info[dbKey],
          { price = resultInfo.minPrice, available = resultInfo.totalQuantity }
        )
      end
      if self.doingFullScan then
        table.insert(self.rawScan, resultInfo)
      end
    end
  end

  if self.doingFullScan then
    self:FireProgressEvent()
  end
end

function AkcHouseIncrementalScanFrameMixin:NextStep()
  if self.doingFullScan and not AkcHouse.AH.HasFullBrowseResults() then
    AkcHouse.AH.RequestMoreBrowseResults()
  else
    local count = AkcHouse.Database:ProcessScan(self.info)
    local rawScan = self.rawScan

    self.info = {}
    self.rawScan = {}

    if self.doingFullScan then
      AkcHouse.Utilities.Message(AKCHOUSE_L_FINISHED_PROCESSING:format(count))
      self.doingFullScan = false

      AkcHouse.EventBus:Fire(self, AkcHouse.IncrementalScan.Events.ScanComplete, rawScan)
    end
    AkcHouse.EventBus:Fire(self, AkcHouse.IncrementalScan.Events.PricesProcessed)
  end
end
