AkcHouseItemKeyCellTemplateMixin = CreateFromMixins(AkcHouseCellMixin, AkcHouseRetailImportTableBuilderCellMixin)

function AkcHouseItemKeyCellTemplateMixin:Init()
  self.Text:SetJustifyH("LEFT")
end

function AkcHouseItemKeyCellTemplateMixin:Populate(rowData, index)
  AkcHouseCellMixin.Populate(self, rowData, index)
  self.UpdateTooltip = nil

  self.Text:SetText(rowData.itemName or "")

  if rowData.iconTexture ~= nil then
    self.Icon:SetTexture(rowData.iconTexture)
    self.Icon:Show()
  end

  self.Icon:SetAlpha(rowData.noneAvailable and 0.5 or 1.0)
end

function AkcHouseItemKeyCellTemplateMixin:OnEnter()

  if self.rowData.itemLink and not AkcHouse.Utilities.IsPetLink(self.rowData.itemLink) then
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetHyperlink(self.rowData.itemLink)
    GameTooltip:Show()
  else
    AuctionHouseUtil.LineOnEnterCallback(self, self.rowData)
  end
  AkcHouseCellMixin.OnEnter(self)
end

function AkcHouseItemKeyCellTemplateMixin:OnLeave()
  if self.rowData.itemLink ~= nil and not AkcHouse.Utilities.IsPetLink(self.rowData.itemLink) then
    GameTooltip:Hide()
  else
    AuctionHouseUtil.LineOnLeaveCallback(self, self.rowData)
  end
  AkcHouseCellMixin.OnLeave(self)
end
