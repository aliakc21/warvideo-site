local MIN_TAB_WIDTH = 70;
local TAB_PADDING = 20;

AkcHouseMiniTabButtonMixin = {}

function AkcHouseMiniTabButtonMixin:OnShow()
  local absoluteSize = nil
  PanelTemplates_TabResize(self, TAB_PADDING, absoluteSize, MIN_TAB_WIDTH)
end

function AkcHouseMiniTabButtonMixin:OnClick()
  self:GetParent():SetView(self:GetID())

  PlaySound(SOUNDKIT.IG_CHARACTER_INFO_TAB)
end
