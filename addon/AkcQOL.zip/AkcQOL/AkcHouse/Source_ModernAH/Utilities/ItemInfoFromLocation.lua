
function AkcHouse.Utilities.ItemInfoFromLocation(location)
  local itemKey = C_AuctionHouse.GetItemKeyFromItem(location)
  local itemType = C_AuctionHouse.GetItemCommodityStatus(location)

  local itemInfo = C_Container.GetContainerItemInfo(location:GetBagAndSlot())
  local icon, itemCount, quality, itemLink = itemInfo.iconFileID, itemInfo.stackCount, itemInfo.quality, itemInfo.hyperlink

  local _, _, _, _, _, classID, _ = C_Item.GetItemInfoInstant(itemLink or itemKey.itemID)

  if itemKey.battlePetSpeciesID ~= 0 then
    classID = Enum.ItemClass.Battlepet
  end

  if classID == Enum.ItemClass.Reagent then
    classID = Enum.ItemClass.Tradegoods
  end

  if quality == nil then
    AkcHouse.Debug.Message("Missing quality", itemKey.itemID)
    quality = 1
  end

  return {
    itemKey = itemKey,
    itemLink = itemLink,
    count = itemCount,
    iconTexture = icon,
    itemType = itemType,
    location = location,
    quality = quality,
    classId = classID,
    auctionable = C_AuctionHouse.IsSellItemValid(location, false),
    bagListing = quality ~= Enum.ItemQuality.Poor or AkcHouse.Utilities.IsEquipment(classID),
  }
end
