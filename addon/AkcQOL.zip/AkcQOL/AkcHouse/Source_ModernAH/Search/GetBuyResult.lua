function AkcHouse.Search.GetBuyItemResult(resultInfo)
  local entry = {
    price = resultInfo.buyoutAmount,
    bidPrice = resultInfo.bidAmount,
    level = resultInfo.itemKey.itemLevel or 0,
    levelPretty = "",
    owners = resultInfo.owners,
    totalNumberOfOwners = resultInfo.totalNumberOfOwners,
    otherSellers = AkcHouse.Utilities.StringJoin(resultInfo.owners, PLAYER_LIST_DELIMITER),
    timeLeft = resultInfo.timeLeft,
    timeLeftPretty = AkcHouse.Utilities.FormatTimeLeftBand(resultInfo.timeLeft),
    quantity = resultInfo.quantity,
    quantityFormatted = FormatLargeNumber(resultInfo.quantity),
    itemLink = resultInfo.itemLink,
    auctionID = resultInfo.auctionID,
    itemType = AkcHouse.Constants.ITEM_TYPES.ITEM,
    containsOwnerItem = resultInfo.containsOwnerItem,
    bidder = resultInfo.bidder,
    canBuy = resultInfo.buyoutAmount ~= nil and not (resultInfo.containsOwnerItem or resultInfo.containsAccountItem)
  }

  if #entry.owners > 0 and #entry.owners < entry.totalNumberOfOwners then
    entry.otherSellers = AKCHOUSE_L_SELLERS_OVERFLOW_TEXT:format(entry.otherSellers, entry.totalNumberOfOwners - #entry.owners)
  end

  if resultInfo.itemKey.battlePetSpeciesID ~= 0 and entry.itemLink ~= nil then
    entry.level = AkcHouse.Utilities.GetPetLevelFromLink(entry.itemLink)
    entry.levelPretty = tostring(entry.level)
  end

  local qualityColor = AkcHouse.Utilities.GetQualityColorFromLink(entry.itemLink)
  entry.levelPretty = "|c" .. qualityColor .. entry.level .. "|r"

  if resultInfo.containsOwnerItem then
    entry.otherSellers = GREEN_FONT_COLOR:WrapTextInColorCode(AUCTION_HOUSE_SELLER_YOU)
    entry.owned = AKCHOUSE_L_UNDERCUT_YES
  else
    entry.owned = GRAY_FONT_COLOR:WrapTextInColorCode(AKCHOUSE_L_UNDERCUT_NO)
  end

  return entry
end
