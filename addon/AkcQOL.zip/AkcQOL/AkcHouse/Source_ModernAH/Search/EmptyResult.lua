function AkcHouse.Search.GetEmptyResult(searchTerm, index)

  local cleanSearchParameter = searchTerm:gsub("\"", "")
  return {
    itemKey = {
      itemID = 1217,
      itemLevel = index,
      itemSuffix = 0,
      battlePetSpeciesID = 0
    },
    itemName = AkcHouse.Search.PrettifySearchString(searchTerm),
    iconTexture = 0,
    name = cleanSearchParameter,
    totalQuantity = 0,
    minPrice = 0,
    containsOwnerItem = false,
  }
end
