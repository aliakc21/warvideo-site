local function HasItemLevel(itemKey)

  return itemKey.itemLevel ~= nil and itemKey.itemLevel ~= 0
end

AkcHouse.Search.Filters.ItemLevelMixin = {}

function AkcHouse.Search.Filters.ItemLevelMixin:Init(filterTracker, browseResult, limits)
  self.limits = limits

  filterTracker:ReportFilterComplete(self:FilterCheck(browseResult.itemKey))
end

function AkcHouse.Search.Filters.ItemLevelMixin:FilterCheck(itemKey)
  return (not HasItemLevel(itemKey)) or self:ItemLevelCheck(itemKey)
end

function AkcHouse.Search.Filters.ItemLevelMixin:ItemLevelCheck(itemKey)
  return
    (

      self.limits.min == nil or
      self.limits.min <= itemKey.itemLevel
    ) and (

      self.limits.max == nil or
      self.limits.max >= itemKey.itemLevel
    )
end
