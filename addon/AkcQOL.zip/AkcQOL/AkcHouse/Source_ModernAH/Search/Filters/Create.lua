local MAPPING = {
  itemLevel = AkcHouse.Search.Filters.ItemLevelMixin,
  exactSearch = AkcHouse.Search.Filters.ExactMixin,
  craftedLevel = AkcHouse.Search.Filters.CraftedLevelMixin,
  price = AkcHouse.Search.Filters.PriceMixin,
  tier = AkcHouse.Search.Filters.TierMixin,
  expansion = AkcHouse.Search.Filters.ExpansionMixin,
}

function AkcHouse.Search.Filters.Create(browseResult, allFilters, filterTracker)
  local result = {}
  local key, filter
  for key, filter in pairs(allFilters) do
    if MAPPING[key] ~= nil then
      table.insert(result, CreateAndInitFromMixin(MAPPING[key], filterTracker, browseResult, filter))
    end
  end
  if #result == 0 then
    table.insert(result, CreateAndInitFromMixin(
        AkcHouse.Search.Filters.BlankFilterMixin,
        filterTracker,
        browseResult
      )
    )
  end
  return result
end
