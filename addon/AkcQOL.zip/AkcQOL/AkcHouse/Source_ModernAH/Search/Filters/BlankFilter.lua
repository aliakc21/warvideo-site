AkcHouse.Search.Filters.BlankFilterMixin = {}

function AkcHouse.Search.Filters.BlankFilterMixin:Init(filterTracker, browseResult)
  filterTracker:ReportFilterComplete(true)
end
