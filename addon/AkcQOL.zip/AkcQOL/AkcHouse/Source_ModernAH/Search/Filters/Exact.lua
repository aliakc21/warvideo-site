
AkcHouse.Search.Filters.ExactMixin = {}

function AkcHouse.Search.Filters.ExactMixin:Init(filterTracker, browseResult, match)
  self.match = match

  AkcHouse.AH.GetItemKeyInfo(browseResult.itemKey, function(itemKeyInfo)
    filterTracker:ReportFilterComplete(self:ExactMatchCheck(itemKeyInfo))
  end)
end

function AkcHouse.Search.Filters.ExactMixin:ExactMatchCheck(itemKeyInfo)
  return string.lower(itemKeyInfo.itemName) == string.lower(self.match)
end
