AkcHouse.Search.Filters.PriceMixin = {}

function AkcHouse.Search.Filters.PriceMixin:Init(filterTracker, browseResult, limits)
  self.limits = limits
  filterTracker:ReportFilterComplete(self:PriceCheck(browseResult.minPrice))
end

function AkcHouse.Search.Filters.PriceMixin:PriceCheck(price)
  return
    (

      self.limits.min == nil or
      self.limits.min <= price
    ) and (

      self.limits.max == nil or
      self.limits.max >= price
    )
end
