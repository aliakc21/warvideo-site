AkcHouse.Search.Filters.FilterTrackerMixin = {}

function AkcHouse.Search.Filters.FilterTrackerMixin:Init(browseResult)
  self.result = true
  self.browseResult = browseResult

  self.waitingSet = false

  self.waiting = 0
end

function AkcHouse.Search.Filters.FilterTrackerMixin:SetWaiting(numNeededFilters)
  if self.waitingSet then
    error("waiting state already set")
  end
  self.waitingSet = true
  self.waiting = self.waiting + numNeededFilters
  self:CompleteCheck()
end

function AkcHouse.Search.Filters.FilterTrackerMixin:CompleteCheck()
  if self.waitingSet and self.waiting <= 0 then
    AkcHouse.EventBus:RegisterSource(self, "Search Filter Tracker")
    if self.result then
      AkcHouse.EventBus:Fire(self, AkcHouse.Search.Events.SearchResultsReady, {self.browseResult})
    else
      AkcHouse.EventBus:Fire(self, AkcHouse.Search.Events.SearchResultsReady, {})
    end
    AkcHouse.EventBus:UnregisterSource(self)
  end
end

function AkcHouse.Search.Filters.FilterTrackerMixin:ReportFilterComplete(
  result
)
  self.waiting = self.waiting - 1
  self.result = self.result and result
  self:CompleteCheck()
end
