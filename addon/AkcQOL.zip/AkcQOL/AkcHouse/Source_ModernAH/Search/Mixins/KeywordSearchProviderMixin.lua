AkcHouseKeywordSearchProviderMixin = CreateFromMixins(AkcHouseMultiSearchMixin, AkcHouseSearchProviderMixin)

local KEYWORD_SEARCH_EVENTS = {
  "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED",
  "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
  "AUCTION_HOUSE_BROWSE_FAILURE"
}

function AkcHouseKeywordSearchProviderMixin:CreateSearchTerm(term)
  AkcHouse.Debug.Message("AkcHouseKeywordSearchProviderMixin:CreateSearchTerm()", term)

  return  {
    searchString = term,
    filters = {},
    itemClassFilters = {},
    sorts = {}
  }
end

function AkcHouseKeywordSearchProviderMixin:GetSearchProvider()
  AkcHouse.Debug.Message("AkcHouseKeywordSearchProviderMixin:GetSearchProvider()")

  return C_AuctionHouse.SendBrowseQuery
end

function AkcHouseKeywordSearchProviderMixin:HasCompleteTermResults()
  AkcHouse.Debug.Message("AkcHouseKeywordSearchProviderMixin:HasCompleteTermResults()")
  return C_AuctionHouse.HasFullBrowseResults()
end

function AkcHouseKeywordSearchProviderMixin:OnSearchEventReceived(eventName, ...)
  AkcHouse.Debug.Message("AkcHouseKeywordSearchProviderMixin:OnSearchEventReceived()", eventName, ...)

  if eventName == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then
    self:ProcessSearchResults(C_AuctionHouse.GetBrowseResults())
  elseif eventName == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
    self:ProcessSearchResults(...)
  elseif eventName == "AUCTION_HOUSE_BROWSE_FAILURE" then
    AuctionHouseFrame.BrowseResultsFrame.ItemList:SetCustomError(
      RED_FONT_COLOR:WrapTextInColorCode(ERR_AUCTION_DATABASE_ERROR)
    )
  end
end

function AkcHouseKeywordSearchProviderMixin:ProcessSearchResults(addedResults)
  AkcHouse.Debug.Message("AkcHouseKeywordSearchProviderMixin:ProcessSearchResults()")

  self:AddResults(addedResults)
end

function AkcHouseKeywordSearchProviderMixin:RegisterProviderEvents()
  self:RegisterEvents(KEYWORD_SEARCH_EVENTS)
end

function AkcHouseKeywordSearchProviderMixin:UnregisterProviderEvents()
  self:UnregisterEvents(KEYWORD_SEARCH_EVENTS)
end
