AkcHouseDirectSearchProviderMixin = CreateFromMixins(AkcHouseMultiSearchMixin, AkcHouseSearchProviderMixin)

local ADVANCED_SEARCH_EVENTS = {
  "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED",
  "AUCTION_HOUSE_BROWSE_RESULTS_ADDED",
  "AUCTION_HOUSE_BROWSE_FAILURE",
  "GET_ITEM_INFO_RECEIVED",
  "EXTRA_BROWSE_INFO_RECEIVED",
}

local INTERNAL_SEARCH_EVENTS = {
  AkcHouse.Search.Events.SearchResultsReady
}

local QUALITY_TO_FILTER = {
  [0] = Enum.AuctionHouseFilter.PoorQuality,
  [1] = Enum.AuctionHouseFilter.CommonQuality,
  [2] = Enum.AuctionHouseFilter.UncommonQuality,
  [3] = Enum.AuctionHouseFilter.RareQuality,
  [4] = Enum.AuctionHouseFilter.EpicQuality,
  [5] = Enum.AuctionHouseFilter.LegendaryQuality,
  [6] = Enum.AuctionHouseFilter.ArtifactQuality,
}

local function GetQualityFilters(quality)
  if QUALITY_TO_FILTER[quality] ~= nil then
    return { QUALITY_TO_FILTER[quality] }
  else
    return {}
  end
end

function AkcHouseDirectSearchProviderMixin:CreateSearchTerm(term)
  AkcHouse.Debug.Message("AkcHouseDirectSearchProviderMixin:CreateSearchTerm()", term)

  local parsed = AkcHouse.Search.SplitAdvancedSearch(term)

  return {
    query = {
      searchString = parsed.searchString,
      minLevel = parsed.minLevel,
      maxLevel = parsed.maxLevel,
      filters = GetQualityFilters(parsed.quality),
      itemClassFilters = AkcHouse.Search.GetItemClassCategories(parsed.categoryKey),
      sorts = AkcHouse.Constants.ShoppingSorts,
    },
    extraFilters = {
      itemLevel = {
        min = parsed.minItemLevel,
        max = parsed.maxItemLevel,
      },
      craftedLevel = {
        min = parsed.minCraftedLevel,
        max = parsed.maxCraftedLevel,
      },
      price = {
        min = parsed.minPrice,
        max = parsed.maxPrice,
      },
      exactSearch = (parsed.isExact and parsed.searchString) or nil,
      expansion = parsed.expansion,
      tier = parsed.tier,
    },
    resultMetadata = {
      quantity = parsed.quantity,
    }
  }
end

function AkcHouseDirectSearchProviderMixin:GetSearchProvider()
  AkcHouse.Debug.Message("AkcHouseDirectSearchProviderMixin:GetSearchProvider()")

  return function(searchTerm)
    AkcHouse.AH.SendBrowseQuery(searchTerm.query)
    self.currentFilter = searchTerm.extraFilters
    self.resultMetadata = searchTerm.resultMetadata
    self.waiting = 0
  end
end

function AkcHouseDirectSearchProviderMixin:HasCompleteTermResults()
  AkcHouse.Debug.Message("AkcHouseDirectSearchProviderMixin:HasCompleteTermResults()")

  return AkcHouse.AH.HasFullBrowseResults() and self.waiting == 0
end

function AkcHouseDirectSearchProviderMixin:GetCurrentEmptyResult()
  return AkcHouse.Search.GetEmptyResult(self:GetCurrentSearchParameter(), self:GetCurrentSearchIndex())
end

function AkcHouseDirectSearchProviderMixin:OnSearchEventReceived(eventName, ...)
  AkcHouse.Debug.Message("AkcHouseDirectSearchProviderMixin:OnSearchEventReceived()", eventName, ...)

  if eventName == "AUCTION_HOUSE_BROWSE_RESULTS_UPDATED" then
    self:ProcessSearchResults(C_AuctionHouse.GetBrowseResults())
  elseif eventName == "AUCTION_HOUSE_BROWSE_RESULTS_ADDED" then
    self:ProcessSearchResults(...)
  elseif eventName == "AUCTION_HOUSE_BROWSE_FAILURE" then
    AuctionHouseFrame.BrowseResultsFrame.ItemList:SetCustomError(
      RED_FONT_COLOR:WrapTextInColorCode(ERR_AUCTION_DATABASE_ERROR)
    )
  else
    AkcHouse.EventBus
      :RegisterSource(self, "AkcHouseDirectSearchProviderMixin")
      :Fire(self, AkcHouse.Search.Events.BlizzardInfo, eventName, ...)
      :UnregisterSource(self)
  end
end

function AkcHouseDirectSearchProviderMixin:ProcessSearchResults(addedResults)
  AkcHouse.Debug.Message("AkcHouseDirectSearchProviderMixin:ProcessSearchResults()")

  if not self.registeredForEvents then
    self.registeredForEvents = true
    AkcHouse.EventBus:Register(self, INTERNAL_SEARCH_EVENTS)
  end

  if not AkcHouse.AH.HasFullBrowseResults() then
    AkcHouse.AH.RequestMoreBrowseResults()
  end

  self.waiting = self.waiting + #addedResults
  for index = 1, #addedResults do
    local filterTracker = CreateAndInitFromMixin(
      AkcHouse.Search.Filters.FilterTrackerMixin,
      addedResults[index]
    )
    addedResults[index].purchaseQuantity = self.resultMetadata.quantity
    local filters = AkcHouse.Search.Filters.Create(addedResults[index], self.currentFilter, filterTracker)

    filterTracker:SetWaiting(#filters)
  end

  if #addedResults == 0 then
    self:AddResults({})
  end
end

function AkcHouseDirectSearchProviderMixin:ReceiveEvent(eventName, results)
  if eventName == AkcHouse.Search.Events.SearchResultsReady then
    self.waiting = self.waiting - 1
    if self:HasCompleteTermResults() then
      self.registeredForEvents = false
      AkcHouse.EventBus:Unregister(self, INTERNAL_SEARCH_EVENTS)
    end
    self:AddResults(results)
  end
end

function AkcHouseDirectSearchProviderMixin:RegisterProviderEvents()
  self:RegisterEvents(ADVANCED_SEARCH_EVENTS)
end

function AkcHouseDirectSearchProviderMixin:UnregisterProviderEvents()
  self:UnregisterEvents(ADVANCED_SEARCH_EVENTS)
  if self.registeredForEvents then
    self.registeredForEvents = false
    AkcHouse.EventBus:Unregister(self, INTERNAL_SEARCH_EVENTS)
  end
end
