local AKCHOUSE_EVENTS = {
  "PLAYER_LOGIN",
  "PLAYER_INTERACTION_MANAGER_FRAME_SHOW",
  "TRADE_SKILL_SHOW",
}

AkcHouseInitializeMainlineMixin = {}

function AkcHouseInitializeMainlineMixin:OnLoad()
  FrameUtil.RegisterFrameForEvents(self, AKCHOUSE_EVENTS)
end

function AkcHouseInitializeMainlineMixin:OnEvent(event, ...)
  if event == "PLAYER_LOGIN" then
    AkcHouse.CraftingInfo.InitializeObjectiveTrackerFrame()
  elseif event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" then
    local showType = ...

    if showType == Enum.PlayerInteractionType.Merchant then

      if not IsOnTournamentRealm() then
        AkcHouse.CraftingInfo.CacheVendorPrices()
      end

    elseif showType == Enum.PlayerInteractionType.Auctioneer then
      self:AuctionHouseShown()
    elseif showType == Enum.PlayerInteractionType.ProfessionsCustomerOrder then
      AkcHouse.CraftingInfo.InitializeCustomerOrdersFrame()
    end
  elseif event == "TRADE_SKILL_SHOW" then
    AkcHouse.CraftingInfo.InitializeProfessionsFrame()
  end
end

function AkcHouseInitializeMainlineMixin:AuctionHouseShown()
  AkcHouse.Debug.Message("AkcHouseInitializeMainlineMixin:AuctionHouseShown()")

  if AuctionHouseFrame == nil then
    return
  end

  AkcHouse.AH.Initialize()

  if AkcHouse.State.AkcHouseFrame == nil then
    AkcHouse.State.AkcHouseFrame = CreateFrame("FRAME", "AkcHouseAHFrame", AuctionHouseFrame, "AkcHouseAHFrameTemplate")
  end
end
