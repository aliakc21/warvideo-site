local function isDisenchantable(itemInfo)
  return
    #itemInfo == 0 or (
      (
        itemInfo[AkcHouse.Constants.ITEM_INFO.CLASS] == Enum.ItemClass.Weapon or
        itemInfo[AkcHouse.Constants.ITEM_INFO.CLASS] == Enum.ItemClass.Armor
      ) and
      itemInfo[AkcHouse.Constants.ITEM_INFO.RARITY] >= Enum.ItemQuality.Uncommon and
      itemInfo[AkcHouse.Constants.ITEM_INFO.RARITY] <= Enum.ItemQuality.Epic
    )
end

function AkcHouse.Enchant.DisenchantStatus(itemInfo)
  return {
    isDisenchantable = isDisenchantable(itemInfo),
    supportedXpac =
      itemInfo[AkcHouse.Constants.ITEM_INFO.XPAC] >=
        LE_EXPANSION_WARLORDS_OF_DRAENOR
  }
end

local function GetDisenchantReagents(itemInfo)
  local xpac = AkcHouse.Enchant.DE_TABLE[
    itemInfo[AkcHouse.Constants.ITEM_INFO.XPAC]
  ]
  if xpac then
    return xpac[itemInfo[AkcHouse.Constants.ITEM_INFO.RARITY]]
  else
    return nil
  end
end

function AkcHouse.Enchant.GetDisenchantAuctionPrice(itemLink, itemInfo)
  if not isDisenchantable(itemInfo) then
    return nil
  end

  local disenchantInfo = GetDisenchantReagents(itemInfo)

  if disenchantInfo == nil then
    return nil
  end

  local price = 0

  for reagentKey, allDrops in pairs(disenchantInfo) do
    local reagentPrice = AkcHouse.Database:GetPrice(reagentKey)

    if reagentPrice == nil then
      return nil
    end

    for index, drop in ipairs(allDrops) do
      price = price + reagentPrice * index * drop
    end
  end

  return price
end
