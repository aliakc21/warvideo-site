
local function GetCostByItemID(itemID, multiplier)
  local vendorPrice = AkcHouse.API.v1.GetVendorPriceByItemID(AKCHOUSE_L_REAGENT_SEARCH, itemID)
  local auctionPrice = AkcHouse.API.v1.GetAuctionPriceByItemID(AKCHOUSE_L_REAGENT_SEARCH, itemID)

  local unitPrice = vendorPrice or auctionPrice

  if unitPrice ~= nil then
    return multiplier * unitPrice
  end
  return 0
end

local function GetByMinCostOption(reagents, multiplier)
  local min = 0
  for _, entry in ipairs(reagents) do
    if entry.itemID ~= nil then
      local newValue = GetCostByItemID(entry.itemID, multiplier)
      if newValue ~= 0 and (min == 0 or newValue < min) then
        min = newValue
      end
    end
  end
  return min
end

local function GetAllocatedCosts(reagentSlotSchematic, slotAllocations)
  local total = 0
  for _, reagent in ipairs(reagentSlotSchematic.reagents) do
    local itemID = reagent.itemID
    if itemID ~= nil then
      local multiplier
      local allocation = slotAllocations:FindAllocationByReagent(reagent)
      if allocation == nil then
        multiplier = 0
      else
        multiplier = allocation:GetQuantity()
      end
      total = total + GetCostByItemID(itemID, multiplier)
    end
  end
  return total
end

function AkcHouse.CraftingInfo.CalculateCraftCost(recipeSchematic, transaction)
  local total = 0

  for slotIndex, reagentSlotSchematic in ipairs(recipeSchematic.reagentSlotSchematics) do
    if #reagentSlotSchematic.reagents > 0 then
      local selected = 0
      local slotAllocations = transaction:GetAllocations(slotIndex)

      if slotAllocations ~= nil then
        selected = slotAllocations:Accumulate()

        total = total + GetAllocatedCosts(reagentSlotSchematic, slotAllocations)
      end

      if reagentSlotSchematic.reagentType == Enum.CraftingReagentType.Basic and selected ~= reagentSlotSchematic.quantityRequired then
        total = total + GetByMinCostOption(reagentSlotSchematic.reagents, reagentSlotSchematic.quantityRequired - selected)
      end
    end
  end

  return total
end
