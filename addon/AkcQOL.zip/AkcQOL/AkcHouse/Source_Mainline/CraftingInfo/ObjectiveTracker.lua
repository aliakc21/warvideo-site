function AkcHouse.CraftingInfo.InitializeObjectiveTrackerFrame()
  local header
  if ObjectiveTrackerBlocksFrame then
    header = ObjectiveTrackerBlocksFrame.ProfessionHeader
  else
    header = ProfessionsRecipeTracker.Header
  end
  local trackedRecipeSearchContainer = CreateFrame(
    "Frame",
    "AkcHouseCraftingInfoObjectiveTrackerFrame",
    header,
    "AkcHouseCraftingInfoObjectiveTrackerFrameTemplate"
  )
end

function AkcHouse.CraftingInfo.DoTrackedRecipesSearch()
  local searchTerms = {}

  local possibleItems = {}
  local continuableContainer = ContinuableContainer:Create()

  local function ProcessRecipe(recipeID, isRecraft)
    local outputData = C_TradeSkillUI.GetRecipeOutputItemData(recipeID, {})
    local outputLink = outputData and outputData.hyperlink
    if outputLink then
      table.insert(possibleItems, {item = outputLink, quantity = 0})
      continuableContainer:AddContinuable(Item:CreateFromItemLink(outputLink))

    elseif AkcHouse.CraftingInfo.EnchantSpellsToItems[recipeID] then
      local itemID = AkcHouse.CraftingInfo.EnchantSpellsToItems[recipeID][1]
      table.insert(possibleItems, {item = itemID, quantity = 0})
      continuableContainer:AddContinuable(Item:CreateFromItemID(itemID))

    else
      local recipeInfo = C_TradeSkillUI.GetRecipeInfo(recipeID)
      table.insert(possibleItems, {itemName = recipeInfo.name, quantity = 0})
    end

    local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, isRecraft)

    for slotIndex, reagentSlotSchematic in ipairs(recipeSchematic.reagentSlotSchematics) do
      if reagentSlotSchematic.reagentType == Enum.CraftingReagentType.Basic and #reagentSlotSchematic.reagents > 0 then
        local itemID = reagentSlotSchematic.reagents[1].itemID
        if itemID ~= nil then
          local existing = nil
          for _, entry in ipairs(possibleItems) do
            if entry.item == itemID then
              existing = entry
              break
            end
          end
          if existing == nil then
            continuableContainer:AddContinuable(Item:CreateFromItemID(itemID))
            table.insert(possibleItems, {item = itemID, quantity = reagentSlotSchematic.quantityRequired})
          else
            existing.quantity = existing.quantity + reagentSlotSchematic.quantityRequired
          end
        end
      end
    end
  end

  local trackedRecipes = C_TradeSkillUI.GetRecipesTracked(true)
  for _, recipeID in ipairs(trackedRecipes) do
    ProcessRecipe(recipeID, true)
  end

  local trackedRecipes = C_TradeSkillUI.GetRecipesTracked(false)
  for _, recipeID in ipairs(trackedRecipes) do
    ProcessRecipe(recipeID, false)
  end

  local function OnItemInfoReady()
    for _, entry in ipairs(possibleItems) do
      if entry.itemName then
        table.insert(searchTerms, {searchString = entry.itemName})
      else
        local itemInfo = {C_Item.GetItemInfo(entry.item)}
        if not AkcHouse.Utilities.IsBound(itemInfo) then
          table.insert(searchTerms, {searchString = itemInfo[1], isExact = true, quantity = entry.quantity})
        end
      end
    end

    AkcHouse.API.v1.MultiSearchAdvanced(AKCHOUSE_L_REAGENT_SEARCH, searchTerms)
  end

  continuableContainer:ContinueOnLoad(OnItemInfoReady)
end
