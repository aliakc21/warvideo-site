local ADDED_LABEL = "Track Shop"
local TOOLTIP_LINE = "Builds a shopping list from this recipe's reagents, so the auction house can find them for you."

local function GetTransaction(form)
  if form.GetTransaction then
    return form:GetTransaction()
  end
  return form.transaction
end

local function GetSchematic(form)
  local transaction = GetTransaction(form)
  if transaction and transaction.GetRecipeSchematic then
    local ok, schematic = pcall(transaction.GetRecipeSchematic, transaction)
    if ok then return schematic end
  end
  if form.GetRecipeInfo then
    local info = form:GetRecipeInfo()
    if info then
      local level = form.GetCurrentRecipeLevel and form:GetCurrentRecipeLevel() or nil
      return C_TradeSkillUI.GetRecipeSchematic(info.recipeID, false, level)
    end
  end
  return nil
end

local function GetRecipeName(form)
  local schematic = GetSchematic(form)
  local name = schematic and schematic.name
  if name and name ~= "" then return name end
  return nil
end

local function ListExistsFor(form)
  local name = GetRecipeName(form)
  return name ~= nil and AkcHouse.Shopping.ListManager:GetIndexForName(name) ~= nil
end

local function CreateListForRecipe(form)
  local schematic = GetSchematic(form)
  local listName = schematic and schematic.name
  if not listName or listName == "" then return end

  local itemIDs = {}
  local quantities = {}
  local continuable = ContinuableContainer:Create()

  for _, slot in ipairs(schematic.reagentSlotSchematics) do
    if slot.reagentType == Enum.CraftingReagentType.Basic and #slot.reagents > 0 then
      local itemID = slot.reagents[1].itemID
      if itemID ~= nil then
        continuable:AddContinuable(Item:CreateFromItemID(itemID))
        table.insert(itemIDs, itemID)
        table.insert(quantities, slot.quantityRequired)
      end
    end
  end

  if #itemIDs == 0 then return end

  continuable:ContinueOnLoad(function()
    local searchStrings = {}
    for index, itemID in ipairs(itemIDs) do
      local itemInfo = { C_Item.GetItemInfo(itemID) }
      if not AkcHouse.Utilities.IsBound(itemInfo) then
        table.insert(searchStrings, AkcHouse.Search.ReconstituteAdvancedSearch({
          searchString = itemInfo[1],
          isExact = true,
          categoryKey = "",
          quantity = quantities[index],
        }))
      end
    end

    if #searchStrings == 0 then return end

    if AkcHouse.Shopping.ListManager:GetIndexForName(listName) ~= nil then
      AkcHouse.Shopping.ListManager:Delete(listName)
    end
    AkcHouse.Shopping.ListManager:Create(listName)
    AkcHouse.Shopping.ListManager:GetByName(listName):AppendItems(searchStrings)

    AkcHouse.EventBus
      :RegisterSource(CreateListForRecipe, "AkcQOL AddToShoppingList")
      :Fire(CreateListForRecipe, AkcHouse.Shopping.Events.ListImportFinished, listName)
      :UnregisterSource(CreateListForRecipe)

    print("|cff8c5cffAkc|r|cffffffffHouse|r: Shopping list created: |cFFF59E0B" .. listName .. "|r")
  end)
end

local function DeleteListForRecipe(form)
  local name = GetRecipeName(form)
  if name and AkcHouse.Shopping.ListManager:GetIndexForName(name) ~= nil then
    AkcHouse.Shopping.ListManager:Delete(name)
    print("|cff8c5cffAkc|r|cffffffffHouse|r: Shopping list removed: |cFFF59E0B" .. name .. "|r")
  end
end

local function FindTrackAnchor(form)
  local direct = form.TrackRecipeCheckbox or form.TrackRecipeCheckBox
  if direct then return direct end

  local wanted = PROFESSIONS_TRACK_RECIPE
  local function scan(frame, depth)
    if depth > 3 then return nil end
    for _, child in ipairs({ frame:GetChildren() }) do
      if child:GetObjectType() == "CheckButton" then
        local fs = child.GetFontString and child:GetFontString()
        local text = (fs and fs:GetText()) or (child.Text and child.Text.GetText and child.Text:GetText())
        if wanted and text == wanted then return child end
      end
      local found = scan(child, depth + 1)
      if found then return found end
    end
    return nil
  end
  return scan(form, 1)
end

-- Same box, same font, same size as Blizzard's Track Recipe checkbox: every
-- visual attribute is copied from the anchor instead of being hardcoded.
local function MatchAnchorStyle(checkbox, anchor)
  local label = checkbox.akcLabel
  if anchor then
    local w, h = anchor:GetSize()
    if w and w > 0 and h and h > 0 then checkbox:SetSize(w, h) end
    local fs = anchor.GetFontString and anchor:GetFontString()
    if fs and label then
      local fontObj = fs.GetFontObject and fs:GetFontObject()
      if fontObj then
        label:SetFontObject(fontObj)
      else
        local font, size, flags = fs:GetFont()
        if font then label:SetFont(font, size, flags) end
      end
      local r, g, b, a = fs:GetTextColor()
      if r then label:SetTextColor(r, g, b, a) end
      local point, rel, relPoint, x, y = fs:GetPoint(1)
      if point == "LEFT" and rel == anchor and type(x) == "number" then
        label:ClearAllPoints()
        label:SetPoint("LEFT", checkbox, relPoint or "RIGHT", x, y or 0)
      end
    end
  end
end

-- The label sits to the RIGHT of the 22px box, and the only thing that makes
-- it clickable is a hit rect stretched over it. Measuring the string before
-- the font has been applied returns 0, which left a one-pixel target and made
-- the whole control look dead -- so this is measured again on every sync,
-- once layout has settled.
local function StretchHitRect(checkbox)
  local label = checkbox.akcLabel
  if not label then return end
  local width = label:GetStringWidth() or 0
  if width < 1 then width = 60 end
  checkbox:SetHitRectInsets(0, -(width + 6), 0, 0)
end

local function PositionCheckbox(checkbox, anchor, placement, form)
  MatchAnchorStyle(checkbox, anchor)
  checkbox:ClearAllPoints()
  if anchor and placement == "right" then
    local fs = anchor.GetFontString and anchor:GetFontString()
    if fs and fs:GetText() then
      checkbox:SetPoint("LEFT", fs, "RIGHT", 24, 0)
    else
      checkbox:SetPoint("LEFT", anchor, "RIGHT", 120, 0)
    end
  elseif anchor then
    checkbox:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 2)
  else
    checkbox:SetPoint("TOPLEFT", form, "TOPLEFT", 8, -50)
  end
end

local function UpdateCheckbox(checkbox)
  local form = checkbox.akcForm
  -- The box rides on Blizzard's own Track Recipe checkbox: where the game
  -- offers no tracking (salvage/recraft forms), no shopping-list box either.
  local anchor = checkbox.akcAnchor
  if not anchor then
    anchor = FindTrackAnchor(form)
    if anchor then
      checkbox.akcAnchor = anchor
      PositionCheckbox(checkbox, anchor, checkbox.akcPlacement, form)
    end
  end
  local shown = anchor ~= nil and anchor:IsShown() and GetRecipeName(form) ~= nil
  checkbox:SetShown(shown)
  if not shown then return end
  checkbox:SetChecked(ListExistsFor(form))
  StretchHitRect(checkbox)
  -- The label is longer than "Track Recipe"; keep it inside the frame.
  local label = checkbox.akcLabel
  local formRight, labelLeft = form:GetRight(), label:GetLeft()
  if formRight and labelLeft then
    local avail = math.floor(formRight - labelLeft - 10)
    if avail > 30 and label:GetStringWidth() > avail then
      label:SetWidth(avail)
    end
  end
end

local function SetupForm(form, placement)
  if not form or form.AkcAddToShoppingList then return end

  local checkbox = CreateFrame("CheckButton", nil, form, "UICheckButtonTemplate")
  form.AkcAddToShoppingList = checkbox
  checkbox.akcForm = form
  checkbox.akcPlacement = placement
  checkbox:SetSize(22, 22)
  checkbox:SetFrameLevel(form:GetFrameLevel() + 10)

  local label = checkbox:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  label:SetPoint("LEFT", checkbox, "RIGHT", 2, 0)
  label:SetJustifyH("LEFT")
  label:SetMaxLines(1)
  label:SetText(ADDED_LABEL)
  checkbox.akcLabel = label

  -- Drawn explicitly rather than trusting the template: on the crafting-order
  -- form the templated textures never appeared, so the player saw a bare
  -- label with no box to tick.
  if not checkbox:GetNormalTexture() then
    checkbox:SetNormalTexture("Interface\\Buttons\\UI-CheckBox-Up")
    checkbox:SetPushedTexture("Interface\\Buttons\\UI-CheckBox-Down")
    checkbox:SetHighlightTexture("Interface\\Buttons\\UI-CheckBox-Highlight", "ADD")
    checkbox:SetCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check")
    checkbox:SetDisabledCheckedTexture("Interface\\Buttons\\UI-CheckBox-Check-Disabled")
  end
  StretchHitRect(checkbox)

  local anchor = FindTrackAnchor(form)
  checkbox.akcAnchor = anchor
  PositionCheckbox(checkbox, anchor, placement, form)

  checkbox:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(ADDED_LABEL)
    GameTooltip:AddLine(TOOLTIP_LINE, 1, 1, 1, true)
    GameTooltip:Show()
  end)
  checkbox:SetScript("OnLeave", GameTooltip_Hide)

  checkbox:SetScript("OnClick", function(self)
    if self:GetChecked() then
      CreateListForRecipe(form)
    else
      DeleteListForRecipe(form)
    end
  end)

  local function Sync()
    UpdateCheckbox(checkbox)
  end

  if type(form.Init) == "function" then
    hooksecurefunc(form, "Init", Sync)
  end
  if type(form.InitSchematic) == "function" then
    hooksecurefunc(form, "InitSchematic", Sync)
  end
  form:HookScript("OnShow", Sync)

  Sync()
end

local function SetupAll()
  if ProfessionsFrame then
    local craftingPage = ProfessionsFrame.CraftingPage
    SetupForm(craftingPage and craftingPage.SchematicForm, "below")

    local orderView = ProfessionsFrame.OrdersPage and ProfessionsFrame.OrdersPage.OrderView
    local orderDetails = orderView and orderView.OrderDetails
    SetupForm(orderDetails and orderDetails.SchematicForm, "below")
  end

  if ProfessionsCustomerOrdersFrame then
    SetupForm(ProfessionsCustomerOrdersFrame.Form, "right")
  end
end

if EventUtil and EventUtil.ContinueOnAddOnLoaded then
  EventUtil.ContinueOnAddOnLoaded("Blizzard_Professions", SetupAll)
  EventUtil.ContinueOnAddOnLoaded("Blizzard_ProfessionsCustomerOrders", SetupAll)
end

if AkcHouse.CraftingInfo then
  if AkcHouse.CraftingInfo.InitializeProfessionsFrame then
    hooksecurefunc(AkcHouse.CraftingInfo, "InitializeProfessionsFrame", SetupAll)
  end
  if AkcHouse.CraftingInfo.InitializeCustomerOrdersFrame then
    hooksecurefunc(AkcHouse.CraftingInfo, "InitializeCustomerOrdersFrame", SetupAll)
  end
end
