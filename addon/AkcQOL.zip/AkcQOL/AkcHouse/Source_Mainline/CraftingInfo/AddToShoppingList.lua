local ADDED_LABEL = "Added to Shopping List"

local function GetTransaction(form)
  if form.GetTransaction then
    return form:GetTransaction()
  end
  return form.transaction
end

local function GetSchematic(form)
  local transaction = GetTransaction(form)
  if transaction and transaction.GetRecipeSchematic then
    local ok, schematic = pcall(transaction.GetRecipeSchematic, transaction)
    if ok then return schematic end
  end
  if form.GetRecipeInfo then
    local info = form:GetRecipeInfo()
    if info then
      local level = form.GetCurrentRecipeLevel and form:GetCurrentRecipeLevel() or nil
      return C_TradeSkillUI.GetRecipeSchematic(info.recipeID, false, level)
    end
  end
  return nil
end

local function GetRecipeName(form)
  local schematic = GetSchematic(form)
  local name = schematic and schematic.name
  if name and name ~= "" then return name end
  return nil
end

local function ListExistsFor(form)
  local name = GetRecipeName(form)
  return name ~= nil and AkcHouse.Shopping.ListManager:GetIndexForName(name) ~= nil
end

local function CreateListForRecipe(form)
  local schematic = GetSchematic(form)
  local listName = schematic and schematic.name
  if not listName or listName == "" then return end

  local itemIDs = {}
  local quantities = {}
  local continuable = ContinuableContainer:Create()

  for _, slot in ipairs(schematic.reagentSlotSchematics) do
    if slot.reagentType == Enum.CraftingReagentType.Basic and #slot.reagents > 0 then
      local itemID = slot.reagents[1].itemID
      if itemID ~= nil then
        continuable:AddContinuable(Item:CreateFromItemID(itemID))
        table.insert(itemIDs, itemID)
        table.insert(quantities, slot.quantityRequired)
      end
    end
  end

  if #itemIDs == 0 then return end

  continuable:ContinueOnLoad(function()
    local searchStrings = {}
    for index, itemID in ipairs(itemIDs) do
      local itemInfo = { C_Item.GetItemInfo(itemID) }
      if not AkcHouse.Utilities.IsBound(itemInfo) then
        table.insert(searchStrings, AkcHouse.Search.ReconstituteAdvancedSearch({
          searchString = itemInfo[1],
          isExact = true,
          categoryKey = "",
          quantity = quantities[index],
        }))
      end
    end

    if #searchStrings == 0 then return end

    if AkcHouse.Shopping.ListManager:GetIndexForName(listName) ~= nil then
      AkcHouse.Shopping.ListManager:Delete(listName)
    end
    AkcHouse.Shopping.ListManager:Create(listName)
    AkcHouse.Shopping.ListManager:GetByName(listName):AppendItems(searchStrings)

    AkcHouse.EventBus
      :RegisterSource(CreateListForRecipe, "AkcQOL AddToShoppingList")
      :Fire(CreateListForRecipe, AkcHouse.Shopping.Events.ListImportFinished, listName)
      :UnregisterSource(CreateListForRecipe)

    print("|cff8c5cffAkc|r|cffffffffHouse|r: Shopping list created: |cFFF59E0B" .. listName .. "|r")
  end)
end

local function DeleteListForRecipe(form)
  local name = GetRecipeName(form)
  if name and AkcHouse.Shopping.ListManager:GetIndexForName(name) ~= nil then
    AkcHouse.Shopping.ListManager:Delete(name)
    print("|cff8c5cffAkc|r|cffffffffHouse|r: Shopping list removed: |cFFF59E0B" .. name .. "|r")
  end
end

local function FindTrackAnchor(form)
  local direct = form.TrackRecipeCheckbox or form.TrackRecipeCheckBox
  if direct then return direct end

  local wanted = PROFESSIONS_TRACK_RECIPE
  local function scan(frame, depth)
    if depth > 3 then return nil end
    for _, child in ipairs({ frame:GetChildren() }) do
      if child:GetObjectType() == "CheckButton" then
        local fs = child.GetFontString and child:GetFontString()
        local text = (fs and fs:GetText()) or (child.Text and child.Text.GetText and child.Text:GetText())
        if wanted and text == wanted then return child end
      end
      local found = scan(child, depth + 1)
      if found then return found end
    end
    return nil
  end
  return scan(form, 1)
end

local function UpdateCheckbox(checkbox)
  local form = checkbox.akcForm
  local hasRecipe = GetRecipeName(form) ~= nil
  checkbox:SetShown(hasRecipe)
  if hasRecipe then
    checkbox:SetChecked(ListExistsFor(form))
  end
end

local function SetupForm(form, placement)
  if not form or form.AkcAddToShoppingList then return end

  local checkbox = CreateFrame("CheckButton", nil, form, "UICheckButtonTemplate")
  form.AkcAddToShoppingList = checkbox
  checkbox.akcForm = form
  checkbox:SetSize(22, 22)
  checkbox:SetFrameLevel(form:GetFrameLevel() + 10)

  local label = checkbox:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  label:SetPoint("LEFT", checkbox, "RIGHT", 2, 0)
  label:SetText(ADDED_LABEL)
  checkbox:SetHitRectInsets(0, -math.max(1, label:GetStringWidth()), 0, 0)

  local anchor = FindTrackAnchor(form)
  if anchor and placement == "right" then
    local fs = anchor.GetFontString and anchor:GetFontString()
    if fs and fs:GetText() then
      checkbox:SetPoint("LEFT", fs, "RIGHT", 24, 0)
    else
      checkbox:SetPoint("LEFT", anchor, "RIGHT", 120, 0)
    end
  elseif anchor then
    checkbox:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, 2)
  else
    checkbox:SetPoint("TOPLEFT", form, "TOPLEFT", 8, -50)
  end

  checkbox:SetScript("OnClick", function(self)
    if self:GetChecked() then
      CreateListForRecipe(form)
    else
      DeleteListForRecipe(form)
    end
  end)

  local function Sync()
    UpdateCheckbox(checkbox)
  end

  if type(form.Init) == "function" then
    hooksecurefunc(form, "Init", Sync)
  end
  if type(form.InitSchematic) == "function" then
    hooksecurefunc(form, "InitSchematic", Sync)
  end
  form:HookScript("OnShow", Sync)

  Sync()
end

local function SetupAll()
  if ProfessionsFrame then
    local craftingPage = ProfessionsFrame.CraftingPage
    SetupForm(craftingPage and craftingPage.SchematicForm, "below")

    local orderView = ProfessionsFrame.OrdersPage and ProfessionsFrame.OrdersPage.OrderView
    local orderDetails = orderView and orderView.OrderDetails
    SetupForm(orderDetails and orderDetails.SchematicForm, "below")
  end

  if ProfessionsCustomerOrdersFrame then
    SetupForm(ProfessionsCustomerOrdersFrame.Form, "right")
  end
end

if EventUtil and EventUtil.ContinueOnAddOnLoaded then
  EventUtil.ContinueOnAddOnLoaded("Blizzard_Professions", SetupAll)
  EventUtil.ContinueOnAddOnLoaded("Blizzard_ProfessionsCustomerOrders", SetupAll)
end

if AkcHouse.CraftingInfo then
  if AkcHouse.CraftingInfo.InitializeProfessionsFrame then
    hooksecurefunc(AkcHouse.CraftingInfo, "InitializeProfessionsFrame", SetupAll)
  end
  if AkcHouse.CraftingInfo.InitializeCustomerOrdersFrame then
    hooksecurefunc(AkcHouse.CraftingInfo, "InitializeCustomerOrdersFrame", SetupAll)
  end
end
