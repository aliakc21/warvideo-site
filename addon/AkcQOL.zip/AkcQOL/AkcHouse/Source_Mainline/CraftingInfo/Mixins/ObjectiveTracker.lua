AkcHouseCraftingInfoObjectiveTrackerFrameMixin = {}

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:OnLoad()
  FrameUtil.RegisterFrameForEvents(self, {
    "PLAYER_INTERACTION_MANAGER_FRAME_SHOW",
    "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
    "TRACKED_RECIPE_UPDATE",
  })
  self:UpdateSearchButton()

  local function Update()
    self:ShowIfRelevant()
    if self:IsVisible() then
      self:UpdateTotal()
    end
  end
end

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:SetDoNotShowProfit()
  self.doNotShowProfit = true
end

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:ShowIfRelevant()
  self:SetShown(AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW) and self:IsAnythingTracked())
  if self:IsShown() then
    self:UpdateSearchButton()
  end
end

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:UpdateSearchButton()
  self.SearchButton:SetShown(AuctionHouseFrame and AuctionHouseFrame:IsShown())
end

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:IsAnythingTracked()
  return #C_TradeSkillUI.GetRecipesTracked(true) > 0 or #C_TradeSkillUI.GetRecipesTracked(false) > 0
end

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:SearchButtonClicked()
  AkcHouse.CraftingInfo.DoTrackedRecipesSearch()
end

function AkcHouseCraftingInfoObjectiveTrackerFrameMixin:OnEvent(eventName, eventData)
  if eventName == "TRACKED_RECIPE_UPDATE" then
    self:ShowIfRelevant()
  elseif eventData == Enum.PlayerInteractionType.Auctioneer then
    self:UpdateSearchButton()
  end
end
