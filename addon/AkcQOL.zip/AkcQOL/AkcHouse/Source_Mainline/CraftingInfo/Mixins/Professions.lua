AkcHouseCraftingInfoProfessionsFrameMixin = {}

function AkcHouseCraftingInfoProfessionsFrameMixin:OnLoad()
  FrameUtil.RegisterFrameForEvents(self, {
    "PLAYER_INTERACTION_MANAGER_FRAME_SHOW",
    "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
  })
  self:UpdateSearchButton()

  self:SetupCustomQuantitySearch()

  local function Update()
    self:ShowIfRelevant()
    if self:IsVisible() then
      self:UpdateTotal()
    end
  end

  hooksecurefunc(self:GetParent(), "Init", Update)

  self:GetParent():RegisterCallback(ProfessionsRecipeSchematicFormMixin.Event.AllocationsModified, Update)
  self:GetParent():RegisterCallback(ProfessionsRecipeSchematicFormMixin.Event.UseBestQualityModified, Update)
  hooksecurefunc(self:GetParent(), "statsChangedHandler", Update)

  AkcHouse.API.v1.RegisterForDBUpdate(AKCHOUSE_L_REAGENT_SEARCH, function()
    if self:IsVisible() then
      self:UpdateTotal()
    end
  end)
end

function AkcHouseCraftingInfoProfessionsFrameMixin:SetupCustomQuantitySearch()
  ButtonFrameTemplate_HidePortrait(self.CustomQuantity)
  ButtonFrameTemplate_HideButtonBar(self.CustomQuantity)
  self.CustomQuantity.Inset:Hide()

  self.CustomQuantity:SetTitle(AKCHOUSE_L_SEARCH_FOR_QUANTITY)

  self.CustomQuantity:SetScript("OnShow", function()
    self.CustomQuantity.Quantity:SetFocus()
    AkcHouse.EventBus:Register(self.CustomQuantity, {AkcHouse.Components.Events.EnterPressed})
  end)
  self.CustomQuantity:SetScript("OnHide", function()
    AkcHouse.EventBus:Unregister(self.CustomQuantity, {AkcHouse.Components.Events.EnterPressed})
  end)

  self.CustomQuantity.ReceiveEvent = function(_, eventName, ...)
    self.CustomQuantity.SearchButton:Click()
  end
end

function AkcHouseCraftingInfoProfessionsFrameMixin:SetDoNotShowProfit()
  self.doNotShowProfit = true
end

function AkcHouseCraftingInfoProfessionsFrameMixin:ShowIfRelevant()
  self:SetShown(AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW) and self:GetParent():GetRecipeInfo() ~= nil and self:IsAnyReagents())

  if self:IsVisible() then
    self:ClearAllPoints()

    local reagents = self:GetParent().Reagents
    local framesToBeBelow = {
      self:GetParent().OptionalReagents,
    }
    for _, f in ipairs(self:GetParent().extraSlotFrames) do
      table.insert(framesToBeBelow, f)
    end
    local min = reagents
    for _, f in ipairs(framesToBeBelow) do
      if f:IsShown() and f:GetBottom() < min:GetBottom() then
        min = f
      end
    end

    self:SetPoint("LEFT", reagents, "LEFT", 0, -10)

    self:SetPoint("TOP", min, "BOTTOM", 0, -5)

    self:UpdateSearchButton()
  end
end

function AkcHouseCraftingInfoProfessionsFrameMixin:UpdateSearchButton()
  self.SearchButton:SetShown(AuctionHouseFrame and AuctionHouseFrame:IsShown())
  self.CustomQuantity:Hide()
end

function AkcHouseCraftingInfoProfessionsFrameMixin:IsAnyReagents()
  local schematicForm = self:GetParent()
  local recipeInfo = schematicForm:GetRecipeInfo()
  local recipeID = recipeInfo.recipeID
  local recipeLevel = schematicForm:GetCurrentRecipeLevel()
  local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)
  return #recipeSchematic.reagentSlotSchematics > 0
end

function AkcHouseCraftingInfoProfessionsFrameMixin:UpdateTotal()
  local text, lines = AkcHouse.CraftingInfo.GetInfoText(self:GetParent(), not self.doNotShowProfit)
  self.Total:SetText(text)
  if lines == 0 then
    self:SetHeight(16)
  else
    self:SetHeight(16 * lines)
  end
end

function AkcHouseCraftingInfoProfessionsFrameMixin:SearchButtonClicked(button)
  if AuctionHouseFrame and AuctionHouseFrame:IsShown() then
    if button == "RightButton" then
      self.CustomQuantity:Show()
    else
      AkcHouse.CraftingInfo.DoTradeSkillReagentsSearch(self:GetParent(), 1)
    end
  end
end

function AkcHouseCraftingInfoProfessionsFrameMixin:QuantitySearchButtonClicked(quantity)
  if AuctionHouseFrame and AuctionHouseFrame:IsShown() then
    AkcHouse.CraftingInfo.DoTradeSkillReagentsSearch(self:GetParent(), math.max(quantity, 1))
  end
  self.CustomQuantity:Hide()
end

function AkcHouseCraftingInfoProfessionsFrameMixin:OnEvent(...)
  local eventName, paneType = ...
  if paneType == Enum.PlayerInteractionType.Auctioneer then
    self:UpdateSearchButton()
  end
end
