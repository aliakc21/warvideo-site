
local addedFunctionality = false
function AkcHouse.CraftingInfo.InitializeProfessionsFrame()
  if addedFunctionality then
    return
  end

  if ProfessionsFrame then
    addedFunctionality = true

    local craftingPageContainer = CreateFrame("Frame", "AkcHouseCraftingInfoProfessionsFrame", ProfessionsFrame.CraftingPage.SchematicForm, "AkcHouseCraftingInfoProfessionsFrameTemplate");
    local ordersPageContainer = CreateFrame("Frame", "AkcHouseCraftingInfoProfessionsOrderFrame", ProfessionsFrame.OrdersPage.OrderView.OrderDetails.SchematicForm, "AkcHouseCraftingInfoProfessionsFrameTemplate");
    ordersPageContainer:SetDoNotShowProfit()
  end
end

function AkcHouse.CraftingInfo.DoTradeSkillReagentsSearch(schematicForm, quantity)
  local recipeInfo = schematicForm:GetRecipeInfo()
  local recipeID = recipeInfo.recipeID
  local recipeLevel = schematicForm:GetCurrentRecipeLevel()

  local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)

  local transaction = schematicForm:GetTransaction()

  local searchTerms = {}

  local possibleItems = {}
  local quantities = {}

  local continuableContainer = ContinuableContainer:Create()

  local outputLink = C_TradeSkillUI.GetRecipeOutputItemData(recipeID, transaction:CreateOptionalCraftingReagentInfoTbl(), transaction:GetAllocationItemGUID()).hyperlink

  table.insert(quantities, 0)
  if outputLink then
    table.insert(possibleItems, outputLink)
    continuableContainer:AddContinuable(Item:CreateFromItemLink(outputLink))

  elseif AkcHouse.CraftingInfo.EnchantSpellsToItems[recipeID] then
    local itemID = AkcHouse.CraftingInfo.EnchantSpellsToItems[recipeID][1]
    table.insert(possibleItems, itemID)
    continuableContainer:AddContinuable(Item:CreateFromItemID(itemID))

  else
    table.insert(searchTerms, {searchString = recipeInfo.name})
  end

  for slotIndex, reagentSlotSchematic in ipairs(recipeSchematic.reagentSlotSchematics) do
    if reagentSlotSchematic.reagentType == Enum.CraftingReagentType.Basic and #reagentSlotSchematic.reagents > 0 then
      local itemID = reagentSlotSchematic.reagents[1].itemID
      if itemID ~= nil then
        continuableContainer:AddContinuable(Item:CreateFromItemID(itemID))

        table.insert(possibleItems, itemID)
        table.insert(quantities, reagentSlotSchematic.quantityRequired)
      end
    end
  end

  local function OnItemInfoReady()
    for index, itemInfo in ipairs(possibleItems) do
      local itemInfo = {C_Item.GetItemInfo(itemInfo)}
      if not AkcHouse.Utilities.IsBound(itemInfo) then
        table.insert(searchTerms, {searchString = itemInfo[1], isExact = true, quantity = quantities[index] * quantity})
      end
    end

    AkcHouse.API.v1.MultiSearchAdvanced(AKCHOUSE_L_REAGENT_SEARCH, searchTerms)
  end

  continuableContainer:ContinueOnLoad(OnItemInfoReady)
end

local function GetSkillReagentsTotal(schematicForm)
  local recipeInfo = schematicForm:GetRecipeInfo()
  local recipeID = recipeInfo.recipeID
  local recipeLevel = schematicForm:GetCurrentRecipeLevel()
  local transaction = schematicForm:GetTransaction()
  local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)

  return AkcHouse.CraftingInfo.CalculateCraftCost(recipeSchematic, transaction)
end

local function GetCheapestQualityTotal(schematicForm)
  local recipeInfo = schematicForm:GetRecipeInfo()
  local recipeID = recipeInfo.recipeID
  local recipeLevel = schematicForm:GetCurrentRecipeLevel()
  local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)
  local transaction = CreateProfessionsRecipeTransaction(recipeSchematic)

  return AkcHouse.CraftingInfo.CalculateCraftCost(recipeSchematic, transaction)
end

local function CalculateProfitFromCosts(currentAH, toCraft, count)
  return math.floor(math.floor(currentAH * count * AkcHouse.Constants.AfterAHCut - toCraft) / 100) * 100
end

local function GetItemIDByReagentQuality(possibleItemIDs, wantedQuality, allQualities)
  if #possibleItemIDs == 1 then
    return possibleItemIDs[1]
  end

  for _, itemID in ipairs(possibleItemIDs) do
    local quality = C_TradeSkillUI.GetItemReagentQualityByItemInfo(itemID)
    if allQualities[quality] == wantedQuality then
      return itemID
    end
  end
end

local function GetEnchantProfit(schematicForm)
  local recipeID = schematicForm.recipeSchematic.recipeID
  local reagents = schematicForm:GetTransaction():CreateCraftingReagentInfoTbl()
  local allocationGUID = schematicForm:GetTransaction():GetAllocationItemGUID()
  local applyConcentration = schematicForm:GetTransaction():IsApplyingConcentration()

  local recipeLevel = schematicForm:GetCurrentRecipeLevel()

  local possibleOutputItemIDs = AkcHouse.CraftingInfo.EnchantSpellsToItems[recipeID] or {}
  local itemID

  local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)
  if recipeSchematic ~= nil and recipeSchematic.hasCraftingOperationInfo then
    local operationInfo = C_TradeSkillUI.GetCraftingOperationInfo(recipeID, reagents, allocationGUID, applyConcentration)
    if operationInfo ~= nil then
      itemID = GetItemIDByReagentQuality(possibleOutputItemIDs, operationInfo.guaranteedCraftingQualityID, C_TradeSkillUI.GetQualitiesForRecipe(recipeID))
    end
  end

  if itemID == nil then
    itemID = possibleOutputItemIDs[1]
  end

  if itemID ~= nil then
    local currentAH = AkcHouse.API.v1.GetAuctionPriceByItemID(AKCHOUSE_L_REAGENT_SEARCH, itemID) or 0
    local age = AkcHouse.API.v1.GetAuctionAgeByItemID(AKCHOUSE_L_REAGENT_SEARCH, itemID)
    local exact = AkcHouse.API.v1.IsAuctionDataExactByItemID(AKCHOUSE_L_REAGENT_SEARCH, itemID)

    local vellumCost = AkcHouse.API.v1.GetVendorPriceByItemID(AKCHOUSE_L_REAGENT_SEARCH, AkcHouse.Constants.EnchantingVellumID) or 0
    local toCraft = GetSkillReagentsTotal(schematicForm) + vellumCost

    local count = schematicForm.recipeSchematic.quantityMin

    return CalculateProfitFromCosts(currentAH, toCraft, count), age, currentAH ~= 0, exact
  else
    return nil
  end
end

local function GetAHProfit(schematicForm)
  local recipeInfo = schematicForm:GetRecipeInfo()

  if recipeInfo.isEnchantingRecipe then
    return GetEnchantProfit(schematicForm)

  else
    local operationInfo = C_TradeSkillUI.GetCraftingOperationInfo(
      recipeInfo.recipeID,
      schematicForm:GetTransaction():CreateCraftingReagentInfoTbl(),
      schematicForm:GetTransaction():GetAllocationItemGUID(),
      schematicForm:GetTransaction():IsApplyingConcentration()
    )
    local qualityOverride = operationInfo and recipeInfo.qualityIDs and recipeInfo.qualityIDs[operationInfo.craftingQuality]
    local qualitiesItemIDs = C_TradeSkillUI.GetRecipeQualityItemIDs(recipeInfo.recipeID)
    local recipeLink
    if not qualitiesItemIDs or #qualitiesItemIDs == 1 then
      local outputData = C_TradeSkillUI.GetRecipeOutputItemData(
        recipeInfo.recipeID,
        schematicForm:GetTransaction():CreateCraftingReagentInfoTbl(),
        schematicForm:GetTransaction():GetAllocationItemGUID(),
        qualityOverride
      )
      recipeLink = outputData and outputData.hyperlink
    else
      local qualityIDs = C_TradeSkillUI.GetQualitiesForRecipe(recipeInfo.recipeID)
      local _
      _, recipeLink = C_Item.GetItemInfo(qualitiesItemIDs[tIndexOf(qualityIDs, qualityOverride)])
    end

    if recipeLink ~= nil then
      local currentAH = AkcHouse.API.v1.GetAuctionPriceByItemLink(AKCHOUSE_L_REAGENT_SEARCH, recipeLink) or 0
      local age = AkcHouse.API.v1.GetAuctionAgeByItemLink(AKCHOUSE_L_REAGENT_SEARCH, recipeLink)
      local exact = AkcHouse.API.v1.IsAuctionDataExactByItemLink(AKCHOUSE_L_REAGENT_SEARCH, recipeLink)

      local toCraft = GetSkillReagentsTotal(schematicForm)

      local count = schematicForm.recipeSchematic.quantityMin

      return CalculateProfitFromCosts(currentAH, toCraft, count), age, currentAH ~= 0, exact
    else
      return nil
    end
  end
end

local function CraftCostString(schematicForm)
  local price = WHITE_FONT_COLOR:WrapTextInColorCode(GetMoneyString(GetSkillReagentsTotal(schematicForm), true))

  return AKCHOUSE_L_TO_CRAFT_COLON .. " " .. price
end

local function CheapestQualityCostString(schematicForm)
  local price = WHITE_FONT_COLOR:WrapTextInColorCode(GetMoneyString(GetCheapestQualityTotal(schematicForm), true))

  return AKCHOUSE_L_CHEAPEST_QUALITY_COST_COLON .. " " .. price
end

local function ProfitString(profit)
  local price
  if profit >= 0 then
    price = WHITE_FONT_COLOR:WrapTextInColorCode(GetMoneyString(profit, true))
  else
    price = RED_FONT_COLOR:WrapTextInColorCode("-" .. GetMoneyString(-profit, true))
  end

  return AKCHOUSE_L_PROFIT_COLON .. " " .. price

end

function AkcHouse.CraftingInfo.GetInfoText(schematicForm, showProfit)
  local result = ""
  local lines = 0
  if AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_COST) then
    if lines > 0 then
      result = result .. "\n"
    end
    result = result .. CraftCostString(schematicForm)
    lines = lines + 1
  end

  if showProfit and AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_PROFIT) then
    local profit, age, anyPrice, exact = GetAHProfit(schematicForm)

    if profit ~= nil then
      if lines > 0 then
        result = result .. "\n"
      end
      result = result .. ProfitString(profit) .. AkcHouse.CraftingInfo.GetProfitWarning(profit, age, anyPrice, exact)
      lines = lines + 1
    end
  end

  if AkcHouse.Config.Get(AkcHouse.Config.Options.CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST) then
    if lines > 0 then
      result = result .. "\n"
    end
    result = result .. CheapestQualityCostString(schematicForm)
    lines = lines + 1
  end

  return result, lines
end
