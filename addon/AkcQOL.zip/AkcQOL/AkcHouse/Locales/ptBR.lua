AKCHOUSE_LOCALES.ptBR = function()
  local L = {}

  L["ADD_FAVOURITE"] = "Adicionar Favorito"
L["ADD_ITEM"] = "Adicionar Item"
L["ADD_TERM_TO_LIST_DIALOG"] = "Escreva o termo de busca a ser adicionado:"
L["ADD_TO_LIST"] = "Adicionar à lista"
L["ADD_TO_X"] = "Adicionar à %s"
L["ALREADY_PURCHASED_X"] = "Já comprou %s"
L["ALT_LEFT_CLICK"] = "ALT + Clique Esquerdo"
L["ALT_RIGHT_CLICK"] = "ALT + Clique Direito"
L["ANY_LOWER"] = "qualquer"
L["ANY_UPPER"] = "Qualquer"
L["AUCTION"] = "Leilão"
L["AUCTION_AGE"] = "Idade de leilão."
L["AUCTION_DURATION_12"] = "12 Horas"
L["AUCTION_DURATION_24"] = "24 Horas"
L["AUCTION_DURATION_48"] = "48 Horas"
L["AUCTION_MEAN"] = "Média de leilão"
L["AKCHOUSE"] = "AkcHouse"
L["AUTHOR_HEADER"] = "Autor"
L["BID_EXISTING_ON_OWNED_AUCTION"] = "Alguém deu um lance neste leilão, portanto, cancelar custará seu depósito e:"
L["BID_ONLY_AVAILABLE"] = "apenas lance disponível"
L["BID_PRICE"] = "Lance atual"
L["BIDDER"] = "Licitante"
L["BIDDING_AUCTION_INFO"] = "%s com um lance inicial de %s"
L["BRACKETS_X_EACH"] = "(%s cada)"
L["BUG_REPORT"] = ""
L["BUG_TOOLTIP_HEADER"] = ""
L["BUG_TOOLTIP_TEXT"] = ""
L["BUY"] = "Comprar"
L["BUY_NOW"] = "Comprar agora"
L["BUY_STACK"] = "Comprar pilha"
L["BUYING"] = "Comprando"
L["BUYING_X_FOR_X"] = [=[Comprando %s por %s
]=]
L["BUYOUT_AUCTION_INFO"] = "%s compra de %s"
L["BUYOUT_PRICE"] = "Preço de Compra"
L["CANCEL"] = "Cancelar"
L["CANCEL_UNDERCUT"] = "Cancelar"
L["CANCELLING_TAB"] = "Cancelar"
L["CANCELLING_TAB_HEADER"] = "AkcHouse - Cancelar"
L["CANNOT_AUCTION"] = "Não é possível leiloar"
L["CAREFUL_CAPS"] = "CUIDADOSO"
L["CHAIN_BUY"] = [=[Compra em cadeia
]=]
L["CHAIN_BUY_TOOLTIP_HEADER"] = [=[Múltiplas compras em cadeia
]=]
L["CHAIN_BUY_TOOLTIP_TEXT"] = "Ao finalizar a compra pelo preço atual e tamanho da pilha, selecione o próximo preço e tamanho da pilha."
L["CHEAPEST_QUALITY_COST_COLON"] = "Custo de qualidade mais barato:"
L["CLOSE"] = "Fechar"
L["CONFIG_ADVANCED_CATEGORY"] = "Avançado"
L["CONFIG_ADVANCED_TEXT"] = "Vasculhe aqui apenas se souber o que está fazendo."
L["CONFIG_ALTERNATE_SCAN"] = "Use o modo de verificação mais lento alternativo por padrão"
L["CONFIG_ALTERNATE_SCAN_HEADER"] = "Modo de Verificação Alternativo"
L["CONFIG_ALTERNATE_SCAN_TEXT"] = "O modo de verificação rápida pode causar desconexões em servidores lotados. Essa opção usa um método de verificação mais lento e com menor probabilidade de desconexão."
L["CONFIG_AUCTION_AGE_TOOLTIP"] = "Mostrar o número de dias desde que um preço foi visto na casa de leilão (até 21 dias)"
L["CONFIG_AUCTION_TOOLTIP"] = "Mostrar o valor dos itens na casa de leilões nas dicas de ferramentas"
L["CONFIG_AUTO_LIST_SEARCH"] = "Verificar automaticamente itens da lista de compras."
L["CONFIG_AUTO_LIST_SEARCH_TOOLTIP_HEADER"] = "Procura de lista automática"
L["CONFIG_AUTO_LIST_SEARCH_TOOLTIP_TEXT"] = "Quando uma lista é selecionada, verifica automaticamente a casa de leilões em procura dos itens da lista. Quando esta opção está desativada, você pode verificar a lista inteira ao selecionar o botão 'Procurar' na barra lateral da Lista de Compras."
L["CONFIG_AUTOSCAN"] = "Executar verificação automática quando a Casa de Leilões for aberta."
L["CONFIG_AUTOSCAN_INTERVAL"] = "Defina quantos minutos entre cada verificação automática"
L["CONFIG_AUTOSCAN_INTERVAL_HEADER"] = "Intervalo entre verificações automáticas"
L["CONFIG_AUTOSCAN_INTERVAL_TOOLTIP_HEADER"] = "Intevalo entre verificações automáticas"
L["CONFIG_AUTOSCAN_INTERVAL_TOOLTIP_TEXT"] = "Por padrão, não serão realizadas verificações sempre que a Casa de Leilão for aberta. Haverá um intervalo predefinido entre cada verificação."
L["CONFIG_AUTOSCAN_TOOLTIP_HEADER"] = "Verificação automática"
L["CONFIG_AUTOSCAN_TOOLTIP_TEXT"] = "Executa uma verificação completa ao abrir a Casa de Leilões. Se desmarcado, você poderá executar uma verificação completa clicando em 'Verificação Completa' na Casa de Leilões."
L["CONFIG_BAG"] = "Bolsa"
L["CONFIG_BAG_COLLAPSED"] = "As seções da bolsa começam fechadas (necessário recarregar)"
L["CONFIG_BAG_COLLAPSED_TOOLTIP_HEADER"] = "Bolsa começa fechada"
L["CONFIG_BAG_COLLAPSED_TOOLTIP_TEXT"] = "As seções da lista de itens da bolsa começarão fechadas, ao invés de aberta."
L["CONFIG_BAG_SHOW_SELLING_BAG"] = "Mostra a lista de itens da bolsa (necessário recarregar)"
L["CONFIG_BAG_SHOW_SELLING_BAG_TOOLTIP_HEADER"] = "Listagem de Itens da Bolsa"
L["CONFIG_BAG_SHOW_SELLING_BAG_TOOLTIP_TEXT"] = "Se desmarcado, o painel de itens da bolsa ficará oculto."
L["CONFIG_BASIC_OPTIONS_CATEGORY"] = "Opções Básicas"
L["CONFIG_BASIC_OPTIONS_TEXT"] = "Opções básicas para ativar recursos no AkcHouse."
L["CONFIG_CANCEL_UNDERCUT_SHORTCUT"] = "Atalho para cancelar a próxima desvalorização:"
L["CONFIG_CANCEL_UNDERCUT_SHORTCUT_TOOLTIP_TEXT"] = "Clique e atribua uma tecla para o atalho. Esse atalho do teclado só estará ativo na aba 'Cancelar' e não afetará nenhum outro atalho vinculado nas mesmas teclas."
L["CONFIG_CANCELLING_CATEGORY"] = "Cancelando"
L["CONFIG_CANCELLING_TEXT"] = "Opções para configurar o funcionamento da aba de Cancelamento"
L["CONFIG_CHAT_LOG"] = "Mostra novos leilões no chat"
L["CONFIG_CHAT_LOG_TOOLTIP_HEADER"] = "Registro do Chat de Leilão"
L["CONFIG_CHAT_LOG_TOOLTIP_TEXT"] = "Se esta opção estiver desabilitada seus leilões não serão escaneados para achar novos leilões."
L["CONFIG_CRAFTING_INFO_SHOW"] = "Mostrar custos de fabricação na visualização de fabricação."
L["CONFIG_CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST"] = "Mostrar custos de reagentes usando a qualidade mais barata disponível na casa de leilões."
L["CONFIG_CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST_TOOLTIP_HEADER"] = "Informações de fabricação: mostrar custo das qualidades mais baratas"
L["CONFIG_CRAFTING_INFO_SHOW_CHEAPEST_QUALITIES_COST_TOOLTIP_TEXT"] = "Ative esta opção para ver o custo de fabricação de uma receita específica usando reagentes de qualidade mais barata ao visualizá-la. Por padrão, o AkcHouse prioriza os reagentes em sua bolsa, mas este valor os ignorará."
L["CONFIG_CRAFTING_INFO_SHOW_COST"] = "Mostrar custos de reagentes da casa de leilões e de vendedores."
L["CONFIG_CRAFTING_INFO_SHOW_COST_TOOLTIP_HEADER"] = "Informações de fabricação: mostrar custo"
L["CONFIG_CRAFTING_INFO_SHOW_COST_TOOLTIP_TEXT"] = "Ative esta opção para ver o custo de fabricação de uma receita específica ao visualizá-la."
L["CONFIG_CRAFTING_INFO_SHOW_PROFIT"] = "Mostrar lucro da fabricação com reagentes da casa de leilões e de vendedores."
L["CONFIG_CRAFTING_INFO_SHOW_PROFIT_TOOLTIP_HEADER"] = "Informações de fabricação: mostrar lucro"
L["CONFIG_CRAFTING_INFO_SHOW_PROFIT_TOOLTIP_TEXT"] = "Ative esta opção para ver o lucro ao fabricar uma receita específica ao visualizá-la."
L["CONFIG_CRAFTING_INFO_SHOW_TOOLTIP_HEADER"] = "Informações adicionais na tela de fabricação."
L["CONFIG_CRAFTING_INFO_SHOW_TOOLTIP_TEXT"] = "A tela de fabricação mostrará o custo de fabricar um item. Desative esta opção para não exibir os custos de fabricação."
L["CONFIG_DEBUG"] = "Ativar/desativar mostrar mensagens de debug."
L["CONFIG_DEBUG_TOOLTIP_HEADER"] = "Debug do AkcHouse"
L["CONFIG_DEBUG_TOOLTIP_TEXT"] = "Isto é utilizado pelos mantenedores para mostrar mensagens de debug no chat."
L["CONFIG_DEVELOPER"] = "Configurações de Desenvolvedor (a)"
L["CONFIG_ENCHANT_GENERIC_TOOLTIP"] = "Mostrar valor estimado de desencantamento de itens nas dicas de ferramentas"
L["CONFIG_ENCHANT_TOOLTIP"] = "Mostrar o valor estimado do item de desencantamento nas dicas de ferramentas (somente WoD, Legion, BfA e Shadowlands)."
L["CONFIG_MAIL_TOOLTIP"] = "Mostrar o valor na casa de leilões do correio nas dicas de ferramentas."
L["CONFIG_MATCHING"] = "Escolha como o preço do item é selecionado automaticamente"
L["CONFIG_MATCHING_ITEM_ID"] = "Mesmo ID de item/ajudante"
L["CONFIG_MATCHING_ITEM_ID_AND_LEVEL"] = "Mesmo nível de item/ajudante com o mesmo ID de item/ajudante"
L["CONFIG_MATCHING_ITEM_NAME"] = "Mesmo ID de item/ajudante e título (ignorando nível)."
L["CONFIG_MATCHING_ITEM_NAME_AND_LEVEL"] = "Mesmo ID de item/ajudante, título e nível."
L["CONFIG_MILL_TOOLTIP"] = "Mostrar o valor estimado de moagem para ervas com caligrafia nas dicas de ferramentas de itens."
L["CONFIG_PET_TOOLTIP"] = "Mostrar o valor na casa de leilões de ajudantes enjaulados nas dicas de ferramentas."
L["CONFIG_PROFILE_CATEGORY"] = "Perfil"
L["CONFIG_PROFILE_TEXT"] = "Definir definições para cada personagem."
L["CONFIG_PROFILE_TOGGLE"] = "Aplicar definições apenas para este personagem."
L["CONFIG_PROSPECT_TOOLTIP"] = "Mostrar o valor estimado de prospecção para minérios com joalheria nas dicas de ferramentas de itens"
L["CONFIG_QUANTITIES_CATEGORY"] = [=[Vendendo: Quantidades
]=]
L["CONFIG_QUANTITIES_TEXT"] = [=[Escolha a quantidade padrão usada para as diferentes categorias de itens.
]=]
L["CONFIG_RESET_STACK_SIZE_MEMORY"] = [=[Resetar a memória do tamanho da pilha
]=]
L["CONFIG_SAVE_LAST_DURATION_AS_DEFAULT"] = [=[Salve a última duração do leilão usada como padrão
]=]
L["CONFIG_SAVE_LAST_DURATION_AS_DEFAULT_TOOLTIP_HEADER"] = [=[Substituir a duração padrão pelo último usado
]=]
L["CONFIG_SAVE_LAST_DURATION_AS_DEFAULT_TOOLTIP_TEXT"] = [=[Substituir a duração padrão pelo último usado
]=]
L["CONFIG_SCAN_SETTINGS"] = "Configurações de Varredura"
L["CONFIG_SCANNING"] = "Opções de Varredura Completa"
L["CONFIG_SELLING_ALL_ITEMS_CATEGORY"] = [=[Vendendo: Todos os itens
]=]
L["CONFIG_SELLING_AUTO_SELECT_NEXT"] = "Selecione automaticamente o próximo item da sua bolsa"
L["CONFIG_SELLING_AUTO_SELECT_NEXT_TOOLTIP_HEADER"] = "Seleção automática de itens"
L["CONFIG_SELLING_AUTO_SELECT_NEXT_TOOLTIP_TEXT"] = "Ao postar, selecione automaticamente o próximo item da bolsa."
L["CONFIG_SELLING_AUTO_SELECT_STACK_REMAINDER"] = "Selecione qualquer pilha parcial que exista após a postagem de todas as pilhas completas."
L["CONFIG_SELLING_AUTO_SELECT_STACK_REMAINDER_TOOLTIP_HEADER"] = "Seleção automática de pilha parcial"
L["CONFIG_SELLING_AUTO_SELECT_STACK_REMAINDER_TOOLTIP_TEXT"] = "Ao postar, adicione a pilha parcial como o próximo item a ser postado, se existir. Isso não causará mais pesquisas."
L["CONFIG_SELLING_BAG_SELECT_SHORTCUT"] = "em um item no seu inventório coloca o mesmo na aba de venda."
L["CONFIG_SELLING_BUY_SHORTCUT"] = "em um leilão de outra pessoa compra o mesmo"
L["CONFIG_SELLING_CANCEL_SHORTCUT"] = "em um leilão seu cancela o mesmo"
L["CONFIG_SELLING_CATEGORY"] = "Venda"
L["CONFIG_SELLING_CONFIRM_LOW_PRICE"] = [=[Confirme o lançamento de itens a um preço excepcionalmente baixo
]=]
L["CONFIG_SELLING_CONFIRM_LOW_PRICE_TOOLTIP_HEADER"] = [=[Confirmar lançamento de preço baixo
]=]
L["CONFIG_SELLING_CONFIRM_LOW_PRICE_TOOLTIP_TEXT_2"] = "Adiciona um diálogo de confirmação que aparece ao postar um item a um preço incomumente baixo."
L["CONFIG_SELLING_DEFAULT_QUANTITY_SUFFIX"] = "Coloque 0 para a quantidade máxima"
L["CONFIG_SELLING_DEFAULT_QUANTITY_TOOLTIP_HEADER"] = "Quantidade Padrão de Postagem"
L["CONFIG_SELLING_DEFAULT_QUANTITY_TOOLTIP_TEXT"] = "Isto permite você alterar a quantidade padrão quando posta um item. Coloque 0 para usar a quantidade máxima."
L["CONFIG_SELLING_GEAR_VENDOR_PRICE_MULTIPLIER_SUFFIX"] = "Marque 0 para não definir um preço."
L["CONFIG_SELLING_GEAR_VENDOR_PRICE_MULTIPLIER_TOOLTIP_HEADER"] = "Preço do Vendedor de Equipamento como Padrão"
L["CONFIG_SELLING_GEAR_VENDOR_PRICE_MULTIPLIER_TOOLTIP_TEXT"] = "Isso permite definir um preço padrão para o equipamento como um múltiplo do preço do vendedor. Isso é usado para qualquer equipamento para o qual o AkcHouse não tenha um preço. Marque 0 para não definir um preço."
L["CONFIG_SELLING_GREY_POST_BUTTON"] = "Cinza (desativar) o botão de postagem quando uma postagem pode falhar"
L["CONFIG_SELLING_GREY_POST_BUTTON_TOOLTIP_HEADER"] = "Botão de postagem cinza"
L["CONFIG_SELLING_GREY_POST_BUTTON_TOOLTIP_TEXT"] = "Quando uma postagem pode falhar, o botão de postagem ficará acinzentado (desativado). Desative essa opção para evitar esperar que o botão seja ativado para que você possa tentar postar mais cedo."
L["CONFIG_SELLING_ICON_SIZE"] = "Tamanho do ícone da bolsa (necessário recarregar)"
L["CONFIG_SELLING_ICON_SIZE_TOOLTIP_HEADER"] = "Tamanho dos ícones"
L["CONFIG_SELLING_ICON_SIZE_TOOLTIP_TEXT"] = "Isso permite aumentar os ícones dos itens da bolsa na aba de vendas (até 50) ou menores (até 10). O tamanho padrão é 42."
L["CONFIG_SELLING_IGNORE_ITEM_LEVEL"] = "Ignore o nível do item ao pesquisar leilões correspondentes"
L["CONFIG_SELLING_IGNORE_ITEM_SUFFIX"] = "Ignorar o sufixo/título do item ao procurar leilões correspondentes."
L["CONFIG_SELLING_MISSING_FAVOURITES"] = "Sempre mostrar os itens favoritos/grupo personalizado, mesmo se não houver nenhum na sua bolsa."
L["CONFIG_SELLING_MISSING_FAVOURITES_TOOLTIP_HEADER"] = "Favoritos/grupo personalizado não disponíveis ainda visíveis"
L["CONFIG_SELLING_MISSING_FAVOURITES_TOOLTIP_TEXT"] = "Mostrar os itens favoritos/grupo personalizado na amostra da bolsa mesmo quando eles não estão na sua bolsa."
L["CONFIG_SELLING_POSSESSED_FAVOURITES_FIRST"] = "Nos favoritos/grupos personalizados, coloque os itens que você tem na sua bolsa primeiro"
L["CONFIG_SELLING_POSSESSED_FAVOURITES_FIRST_TOOLTIP_HEADER"] = "Mostrar itens possuídos primeiro nos favoritos/grupo personalizado"
L["CONFIG_SELLING_POSSESSED_FAVOURITES_FIRST_TOOLTIP_TEXT"] = "Defina a ordem dos favoritos/grupo personalizado para forçar que quaisquer itens em sua bolsa estejam no início da lista."
L["CONFIG_SELLING_POST_SHORTCUT"] = "O atalho de teclado/mouse para postar o item selecionado é"
L["CONFIG_SELLING_POST_SHORTCUT_TOOLTIP_TEXT"] = "Clique e depois pressione o botão (ou tecla) que você gostaria de usar para o atalho. Esse atalho vai apenas funcionar na aba de vendas e não vai afetar outros atalhos para a mesma tecla."
L["CONFIG_SELLING_PREV_SHORTCUT"] = "Um atalho para voltar ao item selecionado anteriormente"
L["CONFIG_SELLING_RESELECT_ITEM"] = "Selecione o último item selecionado para postagem ao abrir a aba Vendas"
L["CONFIG_SELLING_RESELECT_ITEM_TOOLTIP_HEADER"] = "Selecionar novamente o item anterior"
L["CONFIG_SELLING_RESELECT_ITEM_TOOLTIP_TEXT"] = "Após fechar a guia de Venda e reabrí-la durante a sessão atual ou em uma posterior (incluindo fazer desconectar e conectar novamente), restaure o item selecionado para postagem."
L["CONFIG_SELLING_SHORTCUTS_CATEGORY"] = "Vendas: Atalhos"
L["CONFIG_SELLING_SHORTCUTS_TEXT"] = "Opções para atalhos de teclado e mouse para a aba de vendas"
L["CONFIG_SELLING_SHOW_BID_PRICE"] = "Mostrar a opção de oferta quando estiver listando um item (necessita um /reload)"
L["CONFIG_SELLING_SHOW_BID_PRICE_TOOLTIP_HEADER"] = "Opções de Oferta"
L["CONFIG_SELLING_SHOW_BID_PRICE_TOOLTIP_TEXT"] = "Controla se opção de oferta aparece quando estiver postando um item."
L["CONFIG_SELLING_SKIP_SHORTCUT"] = "Atalho para pular o item selecionado é"
L["CONFIG_SELLING_SPLIT_PANELS"] = "Mostrar exibição de painel dividido entre preços atuais e preços históricos"
L["CONFIG_SELLING_SPLIT_PANELS_TOOLTIP_HEADER"] = "Visualização de Painéis Divididos"
L["CONFIG_SELLING_SPLIT_PANELS_TOOLTIP_TEXT"] = "Normalmente, os preços históricos estão em uma guia dentro da guia Vendas, em vez disso, isso torna os preços atuais sempre visíveis, mas os preços históricos são exibidos como um painel abaixo deles."
L["CONFIG_SELLING_TBC_ALL_ITEMS"] = [=[Opções para definir as configurações de lançamento padrão para todos os itens.
]=]
L["CONFIG_SELLING_TEXT"] = "Opções para alterar o comportamento da guia Venda"
L["CONFIG_SHOPPING_ALWAYS_CONFIRM_QUANTITY"] = "Sempre digite a quantidade duas vezes ao comprar mercadorias na guia de compras"
L["CONFIG_SHOPPING_ALWAYS_CONFIRM_QUANTITY_TOOLTIP_HEADER"] = "Confirme a quantidade sempre"
L["CONFIG_SHOPPING_ALWAYS_CONFIRM_QUANTITY_TOOLTIP_TEXT"] = "Por padrão a quantidade é confirmada apenas uma vez, por isso é necessário digitá-la uma segunda vez para confirmar a compra."
L["CONFIG_SHOPPING_ALWAYS_LOAD_MORE"] = [=[Sempre carregue todos os resultados disponíveis.
]=]
L["CONFIG_SHOPPING_ALWAYS_LOAD_MORE_TOOLTIP_HEADER"] = [=[Sempre carregue mais
]=]
L["CONFIG_SHOPPING_ALWAYS_LOAD_MORE_TOOLTIP_TEXT"] = [=[Enquanto ainda obtém um preço mínimo preciso, algumas páginas são ignoradas para acelerar a pesquisa de compras. Isso evita que qualquer página seja ignorada e garante a exibição de todos os resultados possíveis.
]=]
L["CONFIG_SHOPPING_CATEGORY"] = "Compras"
L["CONFIG_SHOPPING_LIST_MISSING_TERMS"] = [=[Mostrar termos de uma lista de compras que não tenham resultados nos resultados.
]=]
L["CONFIG_SHOPPING_LIST_MISSING_TERMS_TOOLTIP_HEADER"] = [=[Pesquisas sem resultados
]=]
L["CONFIG_SHOPPING_LIST_MISSING_TERMS_TOOLTIP_TEXT"] = [=[Quando um termo de pesquisa não tiver resultados, uma entrada com zero disponível será adicionada aos resultados para mostrar isso.
]=]
L["CONFIG_SHOPPING_TEXT"] = "Opções para configurar o funcionamento da aba de Compras"
L["CONFIG_SMALL_TABS"] = "Usar abas pequenas para Casa de Leilões (reabra a Casa de Leilões para ver essa mudança)"
L["CONFIG_SMALL_TABS_TOOLTIP_HEADER"] = "Abas Pequenas"
L["CONFIG_SMALL_TABS_TOOLTIP_TEXT"] = "Quando há muitos addons adicionando abas à Casa de Leilões, elas podem passar do limite da janela. Essa opção faz a abas ficarem menores, assim elas cabem melhor."
L["CONFIG_STACK_TOOLTIP"] = "Mostrar o valor da pilha apenas ao pressionar a tecla Shift."
L["CONFIG_TOOLTIPS_CATEGORY"] = "Caixas de Texto"
L["CONFIG_TOOLTIPS_TEXT"] = "Opções para exibir informações relacionadas a leilões de itens em dicas, em seu inventário e em outros lugares."
L["CONFIG_UNDERCUT_ITEMS_AHEAD"] = "Quantos itens podem estar à frente de suas listagens antes de serem considerados um subcotização"
L["CONFIG_UNDERCUT_ITEMS_AHEAD_CLASSIC"] = "Quantos itens podem estar à frente de suas listagens antes de serem considerados subcotizações (máximo de 50)"
L["CONFIG_UNDERCUT_SCAN_NOT_LIFO"] = "Incluir equipamento e bichos de estimação nas varreduras de subcotação"
L["CONFIG_UNDERCUT_SCAN_NOT_LIFO_TOOLTIP_HEADER"] = "Varreduras de Subcotação para Equipamento/Bichos de Estimação"
L["CONFIG_UNDERCUT_SCAN_NOT_LIFO_TOOLTIP_TEXT"] = "Deixe isso ativado para incluir leilões de bichos de estimação e equipamentos quando utilizar a varredura de subcotação. Desative para excluir os mesmos."
L["CONFIG_VENDOR_TOOLTIP"] = "Mostrar preços de venda do comerciante nas dicas de itens"
L["CONFIRM_POST_BELOW_VENDOR"] = [=[Você pode ganhar mais ouro vendendo isso para um fornecedor. Tem certeza de que deseja postar a esse preço?
]=]
L["CONFIRM_POST_LOW_PRICE"] = [=[O preço de %s parece um pouco baixo. Tem certeza de que deseja postar a esse preço?
]=]
L["CONFIRM_POST_PRICE_DROP"] = "O preço unitário de %s é uma grande queda de preço. Tem certeza de que deseja postar a esse preço?"
L["CONFIRM_PURCHASE_OF_X_FOR_X"] = "Confirmar compra de %s por %s?"
L["CONFIRM_UNHIDE_ALL"] = "Tem certeza de que deseja desocultar todos os itens ocultos?"
L["CONFIRM_X_TOTAL_PRICE_X"] = "Confirmar %s, preço total %s."
L["CONTINUE"] = "Continuar"
L["CONTRIBUTE_HEADER"] = ""
L["CONTRIBUTE_TOOLTIP_HEADER"] = ""
L["CONTRIBUTE_TOOLTIP_TEXT"] = ""
L["COPY_ITEM_ADDED"] = [=[Copiou %s para %s
]=]
L["COPY_NO_LIST_SELECTED"] = [=[Não é possível copiar o item. Nenhuma lista de compras selecionada
]=]
L["COPY_TEXT_HEADER"] = "Copia o Texto"
L["COPY_TO_LIST"] = [=[Copiar item para lista de compras ativa
]=]
L["CRAFTED_LEVEL"] = "Nível para Criação"
L["CRAFTING_INFO"] = "Informações de fabricação"
L["CREATE"] = "Criar"
L["CREATE_LIST_DIALOG"] = "Insira o nome para a nova lista de compras:"
L["CURRENT"] = "Atual"
L["CURRENT_PRICES"] = [=[Preços atuais
]=]
L["CUSTOM_KEYBOARD_SHORTCUTS"] = "Atalhos de teclado"
L["DATE"] = "Data"
L["DAY_1"] = "Domingo"
L["DAY_2"] = "Segunda-feira"
L["DAY_3"] = "Terça-feira"
L["DAY_4"] = "Quarta-feira"
L["DAY_5"] = "Quinta-feira"
L["DAY_6"] = "Sexta-feira"
L["DAY_7"] = "Sábado"
L["DEFAULT_AUCTION_DURATION"] = "Duração Padrão de Leilão"
L["DEFAULT_LIST_HEADER"] = "Lista de Compras Padrão"
L["DEFAULT_STACK_SIZES"] = [=[Tamanhos de pilha padrão
]=]
L["DEFAULT_TAB"] = "Aba Padrão"
L["DEFAULT_TAB_TEXT"] = "mosta a aba padrão"
L["DELETE"] = "Deletar"
L["DELETE_LIST_CONFIRM"] = "Você tem certeza de que quer deletar '%s'?"
L["DELETE_LIST_NONE_SELECTED"] = "Você precisa selecionar uma lista para deletar."
L["DEPOSIT"] = "Depósito:"
L["DISABLED"] = "Desativado"
L["DISCORD"] = ""
L["DISCORD_TOOLTIP_HEADER"] = ""
L["DISCORD_TOOLTIP_TEXT"] = ""
L["DISENCHANT"] = "Desencantar"
L["DONATE"] = ""
L["DURATION"] = "Duração"
L["EDIT_ITEM"] = "Editar Item"
L["ENGAGE_HEADER"] = ""
L["ENTER_QUANTITY_TO_CONFIRM_PURCHASE"] = "Digite a quantidade de %s para confirmar a compra:"
L["ERROR_REOPEN_AUCTION_HOUSE"] = [=[Não foi possível concluir a ação, feche e reabra a casa de leilões.
]=]
L["EXACT_SEARCH"] = "Procura exata"
L["EXPANSION"] = "Expansão"
L["EXPORT"] = "Exportar"
L["EXPORT_AS"] = "Exportar como"
L["EXPORT_RESULTS"] = "Exportar os Resultados"
L["EXPORT_STRING"] = "String compartilhável"
L["EXPORT_WHISPER"] = "Sussurrar para"
L["EXTENDED_SEARCH_ACTIVE_TEXT"] = "%Procura avançada ativa%"
L["FAVOURITES"] = "Favoritos"
L["FAVOURITES_GROUP"] = "Grupo de favoritos"
L["FETCHING_ITEM_INFO"] = "Obtendo informações sobre o item..."
L["FINISHED_PROCESSING"] = "Terminado de processar %s itens."
L["FULL_SCAN_BUTTON"] = "Varredura Completa"
L["FULL_SCAN_FAILED"] = "Não foi possível completar a varredura completa."
L["FULL_SCAN_FAILED_REPLICATE"] = [=[Falha na verificação completa (modo de replicação).
]=]
L["FULL_SCAN_FAILED_SUMMARY"] = "A verificação completa (modo de resumo) não foi concluída."
L["FULL_SCAN_IN_PROGRESS"] = "Varredura completa em progresso."
L["GEAR_VENDOR_PRICE_MULTIPLIER"] = "Multiplicador de preço de venda de equipamentos"
L["HIDE"] = "Esconder"
L["HISTORY"] = "História"
L["IMPORT"] = "Importar"
L["IMPORTED"] = "Importado"
L["INFO_TAB_HEADER"] = "AkcHouse - Informações"
L["IS_TOP_COLUMN"] = "Topo?"
L["IS_UNDERCUT"] = "Subcotado?"
L["ITEM_CLASS"] = "Classe de Item"
L["ITEM_LEVEL"] = "Nível do Item"
L["ITEM_LEVEL_COLUMN"] = "Nível do Item"
L["ITEM_NAME_X_ITEM_LEVEL_X"] = "%s (%s)"
L["ITEMS_AHEAD"] = "Itens à frente"
L["LEFT_CLICK"] = "Clique Esquerdo"
L["LEVEL"] = "Nível"
L["LIST_ADD_ERROR"] = "Ocorreu um erro ao tentar adicionar um iten na lista."
L["LIST_ADD_ITEM_HEADER"] = "Adicionar Item à Lista de Compras"
L["LIST_DELETE_ERROR"] = "Ocorreu um erro ao tentar deletar a lista."
L["LIST_EDIT_ITEM_HEADER"] = "Editar Item da Lista de Compras"
L["LIST_EXPORT_HEADER"] = "Exportar Listas de Compras"
L["LIST_EXTENDED_SEARCH_HEADER"] = [=[Opções de pesquisa estendidas
]=]
L["LIST_IMPORT_HEADER"] = "Importar Listas de Compras"
L["LIST_SEARCH_START"] = "Procurando por itens em %s..."
L["LIST_SEARCH_STATUS"] = "Procurar por iten %s/%s em %s"
L["LOAD_HIGHER_PRICES"] = [=[Carregar preços mais altos
]=]
L["LOAD_MORE_RESULTS"] = [=[Carregar mais resultados
]=]
L["MAKE_PERMANENT"] = "Tornar permanente"
L["MAKE_PERMANENT_CONFIRM"] = "Para tornar '%s' permanente, escolha um novo nome para ele:"
L["MAX"] = "Máximo"
L["MAX_COLON_X"] = [=[Máx.: %s
]=]
L["MILL"] = "Moer"
L["MIN"] = "Mínimo"
L["MONTH_1"] = "Janeiro"
L["MONTH_10"] = "Outubro"
L["MONTH_11"] = "Novembro"
L["MONTH_12"] = "Dezembro"
L["MONTH_2"] = "Fevereiro"
L["MONTH_3"] = "Março"
L["MONTH_4"] = "Abril"
L["MONTH_5"] = "Maio"
L["MONTH_6"] = "Junho"
L["MONTH_7"] = "Julho"
L["MONTH_8"] = "Agosto"
L["MONTH_9"] = "Setembro"
L["MULTIPLE_STACKS_AUCTION_INFO"] = [=[%s %s, totalizando %s
]=]
L["NAME"] = "Nome"
L["NEW_LIST"] = "Nova lista"
L["NEXT_SCAN_MESSAGE"] = "Próxima varredura completa pode ser começada em %s minutos e %s segundos."
L["NO_ITEM_INFO_SPECIFIED"] = [=[Nenhuma informação do item foi especificada.
]=]
L["NO_LIST"] = [=[sem lista
]=]
L["NO_LONGER_AVAILABLE"] = "Não está mais disponível"
L["NO_RESULTS"] = "Nenhum resultado encontrado."
L["NONE"] = "Nenhum"
L["NONE_LEFT"] = [=[Nenhum restante
]=]
L["NUMBER_SEPARATOR"] = "."
L["OPEN_ADDON_OPTIONS"] = "Abrir Opções do Addon"
L["OPEN_IN_SHOPPING_TAB"] = [=[Abrir na guia Compras
]=]
L["OWNED_COLUMN"] = "Próprio?"
L["PAYING_X"] = "Pagando %s por um item"
L["PERCENTAGE"] = "Porcentagem"
L["PERCENTAGE_SUFFIX"] = "% Desconto"
L["PERCENTAGE_TOOLTIP_HEADER"] = "Porcentagem de subcotação"
L["PERCENTAGE_TOOLTIP_TEXT"] = "A porcentagem de subcotação que será usada para calcular o preço. Por exemplo, um valor de 5 significa que seu item será postado com um desconto de 5% comparado ao menor preço atual."
L["POST"] = "Postar"
L["POST_ATTEMPT_FAILED"] = "Sua última tentativa de postagem não funcionou. Tente novamente."
L["POSTING_SETTINGS_COLON"] = "Configurações de publicação:"
L["PREVIOUS"] = "Anterior"
L["PRICE"] = "Preço"
L["PRICE_HISTORY"] = "Histórico de Preços"
L["PRICE_INCREASE_WARNING_2"] = "Preço aumentado em %s. Deseja continuar?"
L["PRICE_INCREASED"] = "O preço aumentou!"
L["PRICE_VARIES_WARNING"] = "Os preços variam muito entre os itens."
L["PROFILE_TOGGLE_TOOLTIP_HEADER"] = "Ativar definições específicas para cada personagem"
L["PROFILE_TOGGLE_TOOLTIP_TEXT"] = "Faz mudanças para as configurações do AkcHouse afetar apenas este personagem."
L["PROFIT_COLON"] = "Lucro:"
L["PROFIT_WARNING_AGE"] = "(dados de preços com pelo menos 10 dias)"
L["PROFIT_WARNING_MISSING"] = "(sem dados de preço)"
L["PROFIT_WARNING_NOT_EXACT_ITEM"] = "(dados de preço não correspondem exatamente ao item)"
L["PROSPECT"] = "Perspectiva"
L["PURCHASED_X_XX"] = [=[Comprado %s x%s
]=]
L["QUANTITY"] = "Quantidade"
L["REAGENT_SEARCH"] = "Procura de Reagente"
L["REAGENTS_VALUE_COLON"] = "Valor dos Reagentes:"
L["REALM_HISTORY"] = "Histórico do Servidor"
L["RECENT_SEARCHES"] = "Procuras Recentes"
L["REFRESH"] = "Atualizar"
L["REMOVE_FAVOURITE"] = "Remover Favorito"
L["REMOVE_FROM_X"] = "Remover de %s"
L["RENAME"] = "Renomear"
L["RENAME_LIST_CONFIRM"] = [=[Digite o novo nome para '%s':
]=]
L["RESET_ALL"] = "Resetar Tudo"
L["RESULTS_AVAILABLE_COLUMN"] = "Disponível"
L["RESULTS_NAME_COLUMN"] = "Nome"
L["RESULTS_PRICE_COLUMN"] = "Preço"
L["RESULTS_STACK_PRICE_COLUMN"] = [=[Preço por pilha
]=]
L["RESULTS_STACK_SIZE_COLUMN"] = [=[Tamanho da pilha
]=]
L["RIGHT_CLICK"] = "Clique Direito"
L["ROADMAP"] = ""
L["ROADMAP_TOOLTIP_TEXT"] = ""
L["SAVE_AS"] = "Salvar Como"
L["SAVE_THIS_LIST_AS"] = [=[Salvar esta lista como...
]=]
L["SCANNING_PAGE_X"] = [=[Digitalizando página %s...
]=]
L["SEARCH"] = "Procurar"
L["SEARCH_ALL"] = [=[Procurar tudo
]=]
L["SEARCH_FOR_QUANTITY"] = "Procurar por quantidade"
L["SEARCH_OPTIONS"] = "Opções de procura"
L["SEARCH_TERM"] = "Procurar termo"
L["SEARCH_TERM_COLON"] = "Termo de procura:"
L["SELECT_ALL"] = "Selecionar Todos"
L["SELECT_SHOPPING_LIST"] = [=[Selecionar lista de compras...
]=]
L["SELLERS_COLUMN"] = "Vendedor(es)"
L["SELLERS_OVERFLOW_TEXT"] = [=[%s, e %s mais
]=]
L["SELLING_TAB"] = "Vendas"
L["SELLING_TAB_HEADER"] = "AkcHouse - Vendas"
L["SERVER_TOOK_TOO_LONG"] = [=[O servidor demorou muito para responder. Sua ação pode não ter surtido efeito.
]=]
L["SET_VALUE"] = "Estabelecer Valor"
L["SET_VALUE_SUFFIX"] = "Desconto"
L["SHIFT_LEFT_CLICK"] = "Shift Clique Esquerdo"
L["SHIFT_RIGHT_CLICK"] = "Shift Clique Direito"
L["SHOPPING_LIST"] = [=[Lista de compras
]=]
L["SHOPPING_LISTS"] = "Listas de compras"
L["SHOPPING_TAB"] = "Comprar"
L["SHOPPING_TAB_HEADER_2"] = "AkcHouse - Compras"
L["SKIP"] = "Pular"
L["SORT"] = "Ordenar"
L["STACK_AUCTION_INFO"] = "%s por %s (%s cada)"
L["STACK_BID_PRICE"] = [=[Preço de lance de pilha
]=]
L["STACK_OF"] = [=[Pilha de
]=]
L["STACK_PRICE"] = [=[Preço da pilha
]=]
L["STACK_TOOLTIP_TOOLTIP_HEADER"] = "Preços das Pilhas"
L["STACK_TOOLTIP_TOOLTIP_TEXT"] = "Quando selecionado, a tecla SHIFT tem que ser pressionada para ver o preço da pilha. Quando não selecionada, o preço da pilha inteira é mostrado sempre."
L["STARTING_FULL_SCAN"] = "Começando varredura completa."
L["STARTING_FULL_SCAN_REPLICATE"] = [=[Iniciando uma verificação completa (modo de replicação).
]=]
L["STARTING_FULL_SCAN_SUMMARY"] = [=[Iniciando uma varredura completa (modo de resumo).
]=]
L["STARTING_PRICE_PERCENTAGE"] = [=[Preço inicial
]=]
L["STARTING_PRICE_PERCENTAGE_SUFFIX"] = [=[% do preço da pilha
]=]
L["STARTING_PRICE_PERCENTAGE_TOOLTIP_HEADER"] = [=[Preço inicial do lance
]=]
L["STARTING_PRICE_PERCENTAGE_TOOLTIP_TEXT"] = [=[A porcentagem do preço inicial será usada para definir o valor do lance padrão usado para quaisquer leilões publicados. Por exemplo, definir isso para 95, para um preço de pilha de 10 segundos, definirá o preço de oferta para 9s50c.
]=]
L["STOP"] = "Parar"
L["STOP_LOADING_NOW"] = "Pare de carregar agora"
L["TEMPORARY_LOWER_CASE"] = "temporário"
L["TIER"] = "Qualidade"
L["TIME_LEFT"] = "Tempo Restante"
L["TO_CRAFT_COLON"] = "Para Criar:"
L["TODAY"] = "Hoje"
L["TOO_BIG_PERCENTAGE"] = "%% tem que ser <= 100 (considerando %s)"
L["TOO_MANY_SEARCH_RESULTS"] = "Esta procura teve resultados demais. Limitando o número de resultados mostrados."
L["TOO_SMALL_PERCENTAGE"] = "%% tem que ser >= 0 (considerando %s)"
L["TOTAL_ITEMS_COLORED"] = "Todal de |cFFAAAAFF %s itens|r"
L["TOTAL_OF_X_FOR_UNIT_PRICE_OF_X"] = "Total de %s por preço unitário de %s"
L["TOTAL_ON_SALE"] = "Total vendendo: %s"
L["TOTAL_PENDING"] = [=[(%s pendente)
]=]
L["TOTAL_PRICE"] = "Preço total:"
L["TOTAL_PRICE_PLAIN"] = "Preço total"
L["TRANSLATORS_BRAZIL_PORTUGUEUSE"] = "Português Brasileiro"
L["TRANSLATORS_FRENCH"] = "Francês"
L["TRANSLATORS_GERMAN"] = "Alemão"
L["TRANSLATORS_HEADER"] = ""
L["TRANSLATORS_HELP"] = ""
L["TRANSLATORS_ITALIAN"] = "Italiano"
L["TRANSLATORS_KOREAN"] = "Coreano"
L["TRANSLATORS_LATIN_SPANISH"] = "Espanhol Latino Americano"
L["TRANSLATORS_ROMANIAN_INFO"] = "Romeno (disponível separadamente)"
L["TRANSLATORS_RUSSIAN"] = "Russo"
L["TRANSLATORS_SIMPLIFIED_CHINESE"] = "Chinês Simplificado"
L["TRANSLATORS_SPANISH"] = "Espanhol"
L["TRANSLATORS_TRADITIONAL_CHINESE"] = "Chinês Tradicional"
L["TRANSLATORS_TURKISH_INFO"] = "Turco (disponível separadamente)"
L["UNDERCUT_BID"] = "Oferta"
L["UNDERCUT_NO"] = "Não"
L["UNDERCUT_PREFERENCE"] = [=[Preferência de sub-corte
]=]
L["UNDERCUT_PRICE"] = "Preço de subcotização"
L["UNDERCUT_SCAN"] = "Varredura de Subcotação"
L["UNDERCUT_TOOLTIP_HEADER"] = "Valor de Subcotação"
L["UNDERCUT_TOOLTIP_TEXT"] = "O valor do desconto será utilizado para calcular o preço de venda."
L["UNDERCUT_UNKNOWN"] = "?"
L["UNDERCUT_YES"] = "Sim"
L["UNHIDE"] = "Revelar"
L["UNHIDE_ALL"] = "Revelar Todos"
L["UNHIDE_ALL_HIDDEN_ITEMS"] = "Revelar todos os itens ocultos"
L["UNIT_PRICE"] = "Preço por unidade"
L["UNIT_PRICE_RANGE"] = "Preço unitário: %s - %s"
L["UNKNOWN"] = "desconhecido"
L["UNSELECT_ALL"] = "Desmarcar todos"
L["UPPER_UNIT_PRICE"] = "Preço unitário mais alto"
L["VENDOR"] = "Preço de venda"
L["VERSION_HEADER"] = "Versão"
L["WAITING_AT_MOST_X_LONGER"] = [=[Aguardando no máximo %ss mais...
]=]
L["X_DAYS"] = "%s dias"
L["X_PRICE_HISTORY"] = [=[%s Histórico de preços
]=]
L["X_STACK_OF_X"] = [=[%s pilha de %s
]=]
L["X_STACKS_OF_X"] = [=[%s pilhas de %s
]=]
L["YOU"] = "Você"
L["YOU_COLUMN"] = "Você?"
L["YOUR_HISTORY"] = "Seu Histórico"

  return L
end
