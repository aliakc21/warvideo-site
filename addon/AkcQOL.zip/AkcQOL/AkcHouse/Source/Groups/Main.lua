AkcHouse.Groups.CallbackRegistry = CreateFromMixins(CallbackRegistryMixin)
AkcHouse.Groups.CallbackRegistry:OnLoad()
AkcHouse.Groups.CallbackRegistry:GenerateCallbackEvents(AkcHouse.Groups.Constants.Events)

function AkcHouse.Groups.Initialize()
  if AKCHOUSE_SELLING_GROUPS == nil then
    AKCHOUSE_SELLING_GROUPS = {
      Version = 1,
      CustomGroups = {},
      HiddenItems = {},
    }

    AkcHouse.Groups.AddGroup("FAVOURITES")
    local list = AkcHouse.Groups.GetGroupList("FAVOURITES")

    for _, data in pairs(AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_FAVOURITE_KEYS)) do
      table.insert(list, data.itemLink)
    end
  end
  if AKCHOUSE_SELLING_GROUPS.CustomSections then
    AKCHOUSE_SELLING_GROUPS.CustomGroups = AKCHOUSE_SELLING_GROUPS.CustomSections
    AKCHOUSE_SELLING_GROUPS.CustomSections = nil
  end

  local group1 = AKCHOUSE_SELLING_GROUPS.CustomGroups[1]
  if group1.name ~= "FAVOURITES_GROUP" and group1.name ~= "FAVOURITES" then
    for index, group in ipairs(AKCHOUSE_SELLING_GROUPS.CustomGroups) do
      if group.name == "FAVOURITES_GROUP" or group.name == "FAVOURITES" then
        AKCHOUSE_SELLING_GROUPS.CustomGroups[index] = group1
        AKCHOUSE_SELLING_GROUPS.CustomGroups[1] = group
        group1 = group
      end
    end
  end

  if group1.name == "FAVOURITES_GROUP" then
    AKCHOUSE_SELLING_GROUPS.CustomGroups[1].name = "FAVOURITES"
  end
end
local function AutoCreateCache()
  if not AkcHouseBagCacheFrame then
    CreateFrame("Frame", "AkcHouseBagCacheFrame", UIParent, "AkcHouseBagCacheTemplate")
  end
end

function AkcHouse.Groups.OnAHOpen()
  AutoCreateCache()
end
