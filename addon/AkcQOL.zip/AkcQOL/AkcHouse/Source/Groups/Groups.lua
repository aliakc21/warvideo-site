function AkcHouse.Groups.DoesGroupExist(name)
  return AkcHouse.Groups.Utilities.IsContainedPredicate(AKCHOUSE_SELLING_GROUPS.CustomGroups, function(item) return item.name == name end)
end
function AkcHouse.Groups.AddGroup(name)
  assert(not AkcHouse.Groups.DoesGroupExist(name), "Group already exists")

  table.insert(AKCHOUSE_SELLING_GROUPS.CustomGroups, {
    name = name,
    type = AkcHouse.Groups.Constants.GroupType.List,
    list = {},
    hidden = false,
  })
end

function AkcHouse.Groups.GetGroupIndex(name)
  for index, s in ipairs(AKCHOUSE_SELLING_GROUPS.CustomGroups) do
    if s.name == name then
      return index
    end
  end
  return nil
end

function AkcHouse.Groups.GetGroupNameByIndex(index)
  return AKCHOUSE_SELLING_GROUPS.CustomGroups[index] and AKCHOUSE_SELLING_GROUPS.CustomGroups[index].name
end

function AkcHouse.Groups.GetGroupList(name)
  return AKCHOUSE_SELLING_GROUPS.CustomGroups[AkcHouse.Groups.GetGroupIndex(name)].list
end

function AkcHouse.Groups.HideItemLink(itemLink)
  table.insert(AKCHOUSE_SELLING_GROUPS.HiddenItems, itemLink)
end

function AkcHouse.Groups.UnhideItemLink(itemLink)
  local index = tIndexOf(AKCHOUSE_SELLING_GROUPS.HiddenItems, itemLink)
  if index ~= nil then
    table.remove(AKCHOUSE_SELLING_GROUPS.HiddenItems, index)
  end
end

function AkcHouse.Groups.UnhideAll()
  AKCHOUSE_SELLING_GROUPS.HiddenItems = {}
end

function AkcHouse.Groups.GetHiddenItemLinks()
  return AKCHOUSE_SELLING_GROUPS.HiddenItems
end
