local VERSION_8_3 = 6
local VERSION_SERIALIZED = 7
local VERSION_KEY_SERIALIZED = 8
local POSTING_HISTORY_DB_VERSION = 1
local VENDOR_PRICE_CACHE_DB_VERSION = 1

function AkcHouse.Variables.Initialize()
  AkcHouse.Variables.InitializeSavedState()

  AkcHouse.Config.InitializeData()
  AkcHouse.Config.InitializeFrames()

  local GetAddOnMetadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
  AkcHouse.State.CurrentVersion = GetAddOnMetadata("AkcQOL", "X-AkcHouse-Version")

  AkcHouse.Variables.InitializeShoppingLists()
  AkcHouse.Variables.InitializePostingHistory()
  AkcHouse.Variables.InitializeVendorPriceCache()

  AkcHouse.Groups.Initialize()
end

function AkcHouse.Variables.InitializeLate()
  AkcHouse.Variables.InitializeDatabase()

  AkcHouse.State.Loaded = true
end

function AkcHouse.Variables.Commit()
  AkcHouse.Variables.CommitDatabase()
end

function AkcHouse.Variables.InitializeSavedState()
  if AKCHOUSE_SAVEDVARS == nil then
    AKCHOUSE_SAVEDVARS = {}
  end
  AkcHouse.SavedState = AKCHOUSE_SAVEDVARS
end

local function ImportFromConnectedRealm(rootRealm)
  local connections = GetAutoCompleteRealms()

  if #connections == 0 then
    return false
  end

  for _, altRealm in ipairs(connections) do

    if AKCHOUSE_PRICE_DATABASE[altRealm] ~= nil then

      AKCHOUSE_PRICE_DATABASE[rootRealm] = AKCHOUSE_PRICE_DATABASE[altRealm]

      AKCHOUSE_PRICE_DATABASE[altRealm] = nil
      return true
    end
  end

  return false
end

local function ImportFromNotNormalizedName(target)
  local unwantedName = GetRealmName()

  if AKCHOUSE_PRICE_DATABASE[unwantedName] ~= nil then

    AKCHOUSE_PRICE_DATABASE[target] = AKCHOUSE_PRICE_DATABASE[unwantedName]

    AKCHOUSE_PRICE_DATABASE[unwantedName] = nil
    return true
  end

  return false
end

function AkcHouse.Variables.InitializeDatabase()
  AkcHouse.Debug.Message("AkcHouse.Database.Initialize()")

  if AKCHOUSE_PRICE_DATABASE == nil then
    AKCHOUSE_PRICE_DATABASE = {
      ["__dbversion"] = VERSION_8_3
    }
  end

  local LibCBOR = LibStub("LibCBOR-1.0")

  if AKCHOUSE_PRICE_DATABASE["__dbversion"] == VERSION_8_3 then
    AKCHOUSE_PRICE_DATABASE["__dbversion"] = VERSION_SERIALIZED
  end
  if AKCHOUSE_PRICE_DATABASE["__dbversion"] == VERSION_SERIALIZED then
    AKCHOUSE_PRICE_DATABASE["__dbversion"] = VERSION_KEY_SERIALIZED
  end

  if AKCHOUSE_PRICE_DATABASE["__dbversion"] ~= VERSION_KEY_SERIALIZED then
    AKCHOUSE_PRICE_DATABASE = {
      ["__dbversion"] = VERSION_KEY_SERIALIZED
    }
  end

  local realm = AkcHouse.Variables.GetConnectedRealmRoot()
  AkcHouse.State.CurrentRealm = realm

  if C_EncodingUtil then
    local frame = CreateFrame("Frame")
    frame:RegisterEvent("PLAYER_LOGOUT")
    frame:SetScript("OnEvent", function()
      local raw = AKCHOUSE_PRICE_DATABASE[realm]
      AKCHOUSE_PRICE_DATABASE[realm] = C_EncodingUtil.SerializeCBOR(raw)
    end)
  end

  if AKCHOUSE_PRICE_DATABASE[realm] == nil then
    if not ImportFromNotNormalizedName(realm) and not ImportFromConnectedRealm(realm) then
      AKCHOUSE_PRICE_DATABASE[realm] = {}
    end
  end

  C_Timer.After(0, function()

    for key, data in pairs(AKCHOUSE_PRICE_DATABASE) do

      if key ~= "__dbversion" and key ~= realm and type(data) == "table" then
        if C_EncodingUtil then
          AKCHOUSE_PRICE_DATABASE[key] = C_EncodingUtil.SerializeCBOR(data)
        else
          AKCHOUSE_PRICE_DATABASE[key] = LibCBOR:Serialize(data)
        end
        break
      end
    end
  end)

  local raw = AKCHOUSE_PRICE_DATABASE[realm]
  if type(raw) == "string" then
    local success, data
    if C_EncodingUtil then
      success, data = pcall(C_EncodingUtil.DeserializeCBOR, raw)
    else
      success, data = pcall(LibCBOR.Deserialize, LibCBOR, raw)
    end
    if not success then
      AKCHOUSE_PRICE_DATABASE[realm] = {}
    else
      AKCHOUSE_PRICE_DATABASE[realm] = data
    end
  end

  if type(AKCHOUSE_PRICE_DATABASE[realm]) ~= "table" then
    AKCHOUSE_PRICE_DATABASE[realm] = {}
  end

  assert(AKCHOUSE_PRICE_DATABASE[realm], "Realm data missing somehow")

  for realm, realmData in pairs(AKCHOUSE_PRICE_DATABASE) do
    if type(realmData) == "table" and realmData.version ~= 2 then
      for key, itemData in pairs(realmData) do
        if type(itemData) == "table" and itemData.pending then
          for _, field in ipairs({"a", "h", "l"}) do
            local new = {}

            for day, data in pairs(itemData[field] or {}) do
              new[tostring(day)] = data
            end
            itemData[field] = new
          end
        elseif type(itemData) == "table" and itemData.pending then
          itemData = itemData.old
        end

        if type(itemData) == "string" then
          if C_EncodingUtil then
            realmData[key] = C_EncodingUtil.DeserializeCBOR(itemData)
          else
            realmData[key] = LibCBOR:Deserialize(itemData)
          end
        end
      end
      realmData.version = 2
    end
  end

  if AkcHouse.Config.Get(AkcHouse.Config.Options.NO_PRICE_DATABASE) then
    AkcHouse.Database = CreateAndInitFromMixin(AkcHouse.DatabaseMixin, {})
  else
    AkcHouse.Database = CreateAndInitFromMixin(AkcHouse.DatabaseMixin, AKCHOUSE_PRICE_DATABASE[realm])
  end
end

function AkcHouse.Variables.InitializePostingHistory()
  AkcHouse.Debug.Message("AkcHouse.Variables.InitializePostingHistory()")

  if AKCHOUSE_POSTING_HISTORY == nil  or
     AKCHOUSE_POSTING_HISTORY["__dbversion"] ~= POSTING_HISTORY_DB_VERSION then
    AKCHOUSE_POSTING_HISTORY = {
      ["__dbversion"] = POSTING_HISTORY_DB_VERSION
    }
  end

  AkcHouse.PostingHistory = CreateAndInitFromMixin(AkcHouse.PostingHistoryMixin, AKCHOUSE_POSTING_HISTORY)
end

function AkcHouse.Variables.InitializeShoppingLists()
  AkcHouse.Shopping.ListManager = CreateAndInitFromMixin(
    AkcHouseShoppingListManagerMixin,
    function() return AKCHOUSE_SHOPPING_LISTS end,
    function(newVal) AKCHOUSE_SHOPPING_LISTS = newVal end
  )

  AKCHOUSE_RECENT_SEARCHES = AKCHOUSE_RECENT_SEARCHES or {}
end

function AkcHouse.Variables.InitializeVendorPriceCache()
  AkcHouse.Debug.Message("AkcHouse.Variables.InitializeVendorPriceCache()")

  if AKCHOUSE_VENDOR_PRICE_CACHE == nil  or
     AKCHOUSE_VENDOR_PRICE_CACHE["__dbversion"] ~= VENDOR_PRICE_CACHE_DB_VERSION then
    AKCHOUSE_VENDOR_PRICE_CACHE = {
      ["__dbversion"] = VENDOR_PRICE_CACHE_DB_VERSION
    }
  end
end
