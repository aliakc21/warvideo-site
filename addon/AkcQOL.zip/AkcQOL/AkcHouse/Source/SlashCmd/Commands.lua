local SLASH_COMMAND_DESCRIPTIONS = {
  {commands = "p, post", message = "Posts the chosen item from the \"Selling\" tab." },
  {commands = "cu, cancelundercut", message = "Cancels the next undercut auction in the \"Cancelling\" tab." },
  {commands = "ra, resetall", message = "Reset database and full scan timer." },
  {commands = "rdb, resetdatabase", message = "Reset AkcHouse database."},
  {commands = "rt, resettimer", message = "Reset full scan timer."},
  {commands = "rc, resetconfig", message = "Reset configuration to defaults."},
  {commands = "npd, nopricedb", message = "Disable recording auction prices."},
  {commands = "d, debug", message = "Toggle debug mode."},
  {commands = "c, config", message = "Show current configuration values."},
  {commands = "c [toggle-name], config [toggle-name]", message = "Toggle the value of the configuration value [toggle-name]."},
  {commands = "v, version", message = "Show current version."},
  {commands = "h, help", message = "Show this help message."},
}

function AkcHouse.SlashCmd.Post()
  AkcHouse.EventBus
    :RegisterSource(AkcHouse.SlashCmd.Post, "AkcHouse.SlashCmd.Post")
    :Fire(AkcHouse.SlashCmd.Post, AkcHouse.Selling.Events.RequestPost)
    :UnregisterSource(AkcHouse.SlashCmd.Post)
end

function AkcHouse.SlashCmd.CancelUndercut()
  AkcHouse.EventBus
    :RegisterSource(AkcHouse.SlashCmd.CancelUndercut, "AkcHouse.SlashCmd.CancelUndercut")
    :Fire(AkcHouse.SlashCmd.CancelUndercut, AkcHouse.Cancelling.Events.RequestCancelUndercut)
    :UnregisterSource(AkcHouse.SlashCmd.CancelUndercut)
end

function AkcHouse.SlashCmd.ToggleDebug()
  AkcHouse.Debug.Toggle()
  if AkcHouse.Debug.IsOn() then
    AkcHouse.Utilities.Message("Debug mode on")
  else
    AkcHouse.Utilities.Message("Debug mode off")
  end
end

function AkcHouse.SlashCmd.ResetDatabase()
  if AkcHouse.Debug.IsOn() then

    AKCHOUSE_PRICE_DATABASE = nil
    AkcHouse.Utilities.Message("Price database reset")
    AkcHouse.Variables.InitializeDatabase()
  else
    AkcHouse.Utilities.Message("Requires debug mode.")
  end
end

function AkcHouse.SlashCmd.ResetTimer()
  if AkcHouse.Debug.IsOn() then
    AkcHouse.SavedState.TimeOfLastReplicateScan = nil
    AkcHouse.SavedState.TimeOfLastGetAllScan = nil
    AkcHouse.Utilities.Message("Scan timer reset.")
  else
    AkcHouse.Utilities.Message("Requires debug mode.")
  end
end

function AkcHouse.SlashCmd.CleanReset()
  AkcHouse.SlashCmd.ResetTimer()
  AkcHouse.SlashCmd.ResetDatabase()
end

function AkcHouse.SlashCmd.NoPriceDB()
  AkcHouse.Config.Set(AkcHouse.Config.Options.NO_PRICE_DATABASE, true)

  AKCHOUSE_PRICE_DATABASE = nil
  AkcHouse.Variables.InitializeDatabase()

  AkcHouse.Utilities.Message("Disabled recording auction prices in the price database.")
end

function AkcHouse.SlashCmd.ResetConfig()
  if AkcHouse.Debug.IsOn() then
    AkcHouse.Config.Reset()
    AkcHouse.Utilities.Message("Config reset.")
  else
    AkcHouse.Utilities.Message("Requires debug mode.")
  end
end

local INVALID_OPTION_VALUE = "Wrong config value type %s (required %s)"
function AkcHouse.SlashCmd.Config(optionName, value1, ...)
  if optionName == nil then
    AkcHouse.Utilities.Message("No config option name supplied")
    for _, name in pairs(AkcHouse.Config.Options) do
      AkcHouse.Utilities.Message(name .. ": " .. tostring(AkcHouse.Config.Get(name)))
    end
    return
  end

  local currentValue = AkcHouse.Config.Get(optionName)
  if currentValue == nil then
    AkcHouse.Utilities.Message("Unknown config: " .. optionName)
    return
  end

  if value1 == nil then
    AkcHouse.Utilities.Message("Config " .. optionName .. ": " .. tostring(currentValue))
    return
  end

  if type(currentValue) == "boolean" then
    if value1 ~= "true" and value1 ~= "false" then
      AkcHouse.Utilities.Message(INVALID_OPTION_VALUE:format(type(value1), type(currentValue)))
      return
    end
    AkcHouse.Config.Set(optionName, value1 == "true")
  elseif type(currentValue) == "number" then
    if tonumber(value1) == nil then
      AkcHouse.Utilities.Message(INVALID_OPTION_VALUE:format(type(value1), type(currentValue)))
      return
    end
    AkcHouse.Config.Set(optionName, tonumber(value1))
  elseif type(currentValue) == "string" then
    AkcHouse.Config.Set(optionName, strjoin(" ", value1, ...))
  else
    AkcHouse.Utilities.Message("Unable to edit option type " .. type(currentValue))
    return
  end
  AkcHouse.Utilities.Message("Now set " .. optionName .. ": " .. tostring(AkcHouse.Config.Get(optionName)))
end

function AkcHouse.SlashCmd.Version()
  AkcHouse.Utilities.Message(
    BLUE_FONT_COLOR:WrapTextInColorCode("Version: ") .. C_AddOns.GetAddOnMetadata("AkcQOL", "X-AkcHouse-Version") ..
    LIGHTGRAY_FONT_COLOR:WrapTextInColorCode(", " .. date() .. ", ") ..
    BLUE_FONT_COLOR:WrapTextInColorCode("WoW: ") .. select(4, GetBuildInfo())
  )
end

function AkcHouse.SlashCmd.Help()
  for index = 1, #SLASH_COMMAND_DESCRIPTIONS do
    local description = SLASH_COMMAND_DESCRIPTIONS[index]
    AkcHouse.Utilities.Message(description.commands .. ": " .. description.message)
  end
end
