function AkcHouse.SlashCmd.Initialize()
  SlashCmdList["AkcHouse"] = AkcHouse.SlashCmd.Handler
  SLASH_AkcHouse1 = "/akchouse"
end

local SLASH_COMMANDS = {
  ["p"] = AkcHouse.SlashCmd.Post,
  ["post"] = AkcHouse.SlashCmd.Post,
  ["cu"] = AkcHouse.SlashCmd.CancelUndercut,
  ["cancelundercut"] = AkcHouse.SlashCmd.CancelUndercut,
  ["ra"] = AkcHouse.SlashCmd.CleanReset,
  ["resetall"] = AkcHouse.SlashCmd.CleanReset,
  ["rt"] = AkcHouse.SlashCmd.ResetTimer,
  ["resettimer"] = AkcHouse.SlashCmd.ResetTimer,
  ["rdb"] = AkcHouse.SlashCmd.ResetDatabase,
  ["resetdatabase"] = AkcHouse.SlashCmd.ResetDatabase,
  ["rc"] = AkcHouse.SlashCmd.ResetConfig,
  ["resetconfig"] = AkcHouse.SlashCmd.ResetConfig,
  ["d"] = AkcHouse.SlashCmd.ToggleDebug,
  ["debug"] = AkcHouse.SlashCmd.ToggleDebug,
  ["config"] = AkcHouse.SlashCmd.Config,
  ["c"] = AkcHouse.SlashCmd.Config,
  ["v"] = AkcHouse.SlashCmd.Version,
  ["version"] = AkcHouse.SlashCmd.Version,
  ["nopricedb"] = AkcHouse.SlashCmd.NoPriceDB,
  ["npd"] = AkcHouse.SlashCmd.NoPriceDB,
  ["h"] = AkcHouse.SlashCmd.Help,
  ["help"] = AkcHouse.SlashCmd.Help,
}

function AkcHouse.SlashCmd.Handler(input)
  AkcHouse.Debug.Message( 'AkcHouse.SlashCmd.Handler', input )

  if #input == 0 then
    AkcHouse.SlashCmd.Help()
  else
    local command = AkcHouse.Utilities.SplitCommand(input);
    local handler = SLASH_COMMANDS[command[1]]
    if handler == nil then
      AkcHouse.Utilities.Message("Unrecognized command '" .. command[1] .. "'")
      AkcHouse.SlashCmd.Help()
    else
      handler(unpack(AkcHouse.Utilities.Slice(command, 2, #command-1)))
    end
  end
end
