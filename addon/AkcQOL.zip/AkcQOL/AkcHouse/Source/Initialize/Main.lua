local AKCHOUSE_EVENTS = {

  "PLAYER_LOGIN",
  "ADDON_LOADED",

}

AkcHouseInitializeMixin = {}

function AkcHouseInitializeMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouse.Events.CoreFrameLoaded")
  C_ChatInfo.RegisterAddonMessagePrefix("AkcHouse")

  FrameUtil.RegisterFrameForEvents(self, AKCHOUSE_EVENTS)
end

function AkcHouseInitializeMixin:OnEvent(event, ...)

  if event == "PLAYER_LOGIN" then
    AkcHouse.Variables.InitializeLate()
  elseif event == "ADDON_LOADED" and (...) == "AkcQOL" then
    AkcHouse.Variables.Initialize()

    AkcHouse.SlashCmd.Initialize()
  elseif event == "CHAT_MSG_ADDON" then

  end
end

function AkcHouseInitializeMixin:AddonDataLoaded(event, ...)
  AkcHouse.Debug.Message("AkcHouseInitializeMixin:VariablesLoaded")
end
