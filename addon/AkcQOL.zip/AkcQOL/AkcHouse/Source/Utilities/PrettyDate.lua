function AkcHouse.Utilities.PrettyDate(when)
  local details = date("*t", when)
  local currentDay = date("*t", time())

  local weekDay = AkcHouse.Locales.Apply("DAY_"..tostring(details.wday))

  if details.year == currentDay.year and details.month == currentDay.month and details.day == currentDay.day then
    return AKCHOUSE_L_TODAY

  elseif GetLocale() == "koKR" then

    return date("%Y.%m.%d", when) .. " [" .. weekDay .. "]"

  else

    return
      weekDay ..  ", " ..
      AkcHouse.Locales.Apply("MONTH_"..tostring(details.month)) ..
      " " .. details.day
    end
end
