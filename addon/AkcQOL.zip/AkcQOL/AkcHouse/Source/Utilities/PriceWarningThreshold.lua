function AkcHouse.Utilities.PriceWarningThreshold(unitPrice)
  if unitPrice == 0 then
    return 0
  end

  local multiplier = 0.3 + 0.4 * math.min(1, 10000 / unitPrice)

  return unitPrice * multiplier
end
