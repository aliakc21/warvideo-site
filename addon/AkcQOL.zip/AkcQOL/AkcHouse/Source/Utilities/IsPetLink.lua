function AkcHouse.Utilities.IsPetLink(itemLink)
  return itemLink:match("battlepet:") ~= nil
end
