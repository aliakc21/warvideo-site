function AkcHouse.Utilities.Message(message)
  print(
    LIGHTBLUE_FONT_COLOR:WrapTextInColorCode("AkcHouse: ")
    .. message
  )
end
