AkcHouseEventBusMixin = {}

function AkcHouseEventBusMixin:Init()
  self.registeredListeners = {}
  self.sources = {}
  self.queue = {}
end

function AkcHouseEventBusMixin:Register(listener, eventNames)
  if listener.ReceiveEvent == nil then
    error("Attempted to register an invalid listener! ReceiveEvent method must be defined.")
    return self
  end

  for _, eventName in ipairs(eventNames) do
    if self.registeredListeners[eventName] == nil then
      self.registeredListeners[eventName] = {}
    end

    table.insert(self.registeredListeners[eventName], listener)
    AkcHouse.Debug.Message("AkcHouseEventBusMixin:Register", eventName)
  end

  return self
end

function AkcHouseEventBusMixin:Unregister(listener, eventNames)
  for _, eventName in ipairs(eventNames) do
    local index = tIndexOf(self.registeredListeners[eventName], listener)
    if index ~= nil then
      table.remove(self.registeredListeners[eventName], index, listener)
    end
    AkcHouse.Debug.Message("AkcHouseEventBusMixin:Unregister", eventName)
  end

  return self
end

function AkcHouseEventBusMixin:IsSourceRegistered(source)
  return self.sources[source] ~= nil
end

function AkcHouseEventBusMixin:RegisterSource(source, name)
  self.sources[source] = name

  return self
end

function AkcHouseEventBusMixin:UnregisterSource(source)
  self.sources[source] = nil

  return self
end

function AkcHouseEventBusMixin:Fire(source, eventName, ...)
  if self.sources[source] == nil then
    error("All sources must be registered (" .. eventName .. ")")
  end

  AkcHouse.Debug.Message(
    "AkcHouseEventBus:Fire()",
    self.sources[source],
    eventName,
    ...
  )

  if self.registeredListeners[eventName] ~= nil then
    AkcHouse.Debug.Message("ReceiveEvent", #self.registeredListeners[eventName], eventName)

    local allListeners = AkcHouse.Utilities.Slice(
      self.registeredListeners[eventName],
      1,
      #self.registeredListeners[eventName]
    )
    for index, listener in ipairs(allListeners) do
      listener:ReceiveEvent(eventName, ...)
    end
  end

  return self
end

AkcHouse.EventBus = CreateAndInitFromMixin(AkcHouseEventBusMixin)
