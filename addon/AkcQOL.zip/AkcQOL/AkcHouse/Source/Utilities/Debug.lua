function AkcHouse.Debug.IsOn()
  return AkcHouse.Config.Get(AkcHouse.Config.Options.DEBUG)
end

function AkcHouse.Debug.Toggle()
  AkcHouse.Config.Set(AkcHouse.Config.Options.DEBUG,
    not AkcHouse.Config.Get(AkcHouse.Config.Options.DEBUG))
end

function AkcHouse.Debug.Message(message, ...)
  if AkcHouse.Debug.IsOn() then
    print(GREEN_FONT_COLOR:WrapTextInColorCode(message), ...)
  end
end
