local L = AkcHouse.Locales.Apply

local waitingForPricing = false

function AkcHouse.Tooltip.ShowTipWithPricing(tooltipFrame, itemLink, itemCount)
  if waitingForPricing or AkcHouse.Database == nil then
    return
  end

  waitingForPricing = true
  AkcHouse.Utilities.DBKeyFromLink(itemLink, function(dbKeys)
    waitingForPricing = false
    AkcHouse.Tooltip.ShowTipWithPricingDBKey(tooltipFrame, dbKeys, itemLink, itemCount)
    if not AkcHouse.Constants.IsRetail then
      tooltipFrame:Show()
    end
  end)
end

function AkcHouse.Tooltip.ShowTipWithPricingDBKey(tooltipFrame, dbKeys, itemLink, itemCount)
  if #dbKeys == 0 or AkcHouse.Utilities.IsPetDBKey(dbKeys[1]) then
    return
  end

  local showStackPrices = IsShiftKeyDown();

  if not AkcHouse.Config.Get(AkcHouse.Config.Options.SHIFT_STACK_TOOLTIPS) then
    showStackPrices = not IsShiftKeyDown();
  end

  local countString = ""
  if itemCount and showStackPrices then
    countString = AkcHouse.Utilities.CreateCountString(itemCount)
  end

  local auctionPrice = AkcHouse.Database:GetFirstPrice(dbKeys)
  local auctionAge, showAgeUnknown = nil, false
  if auctionPrice ~= nil then
    auctionPrice = auctionPrice * (showStackPrices and itemCount or 1)
    auctionAge = AkcHouse.Database:GetPriceAge(dbKeys[1])
    if auctionAge == nil and auctionPrice ~= nil then
      showAgeUnknown = AkcHouse.Database:GetPrice(dbKeys[1]) ~= nil
    end
  end
  local auctionMean
  if AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_MEAN_TOOLTIPS) then
    auctionMean = AkcHouse.Database:GetMeanPrice(dbKeys[1], AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_MEAN_DAYS_LIMIT))
  end
  if auctionMean ~= nil then
    auctionMean = auctionMean * (showStackPrices and itemCount or 1)
  end

  local vendorPrice, disenchantStatus, disenchantPrice
  local cannotAuction = 0;

  local itemInfo = { C_Item.GetItemInfo(itemLink) };
  if (#itemInfo) ~= 0 then
    cannotAuction = AkcHouse.Utilities.IsBound(itemInfo)
    local sellPrice = itemInfo[AkcHouse.Constants.ITEM_INFO.SELL_PRICE]

    if AkcHouse.Utilities.IsVendorable(itemInfo) then
      vendorPrice = sellPrice * (showStackPrices and itemCount or 1);
    end

    disenchantStatus = AkcHouse.Enchant.DisenchantStatus(itemInfo)
    local disenchantPriceForOne = AkcHouse.Enchant.GetDisenchantAuctionPrice(itemLink, itemInfo)
    if disenchantPriceForOne ~= nil then
      disenchantPrice = disenchantPriceForOne * (showStackPrices and itemCount or 1)
    end
  end

  local prospectStatus = false
  local prospectValue
  if AkcHouse.Prospect then
    local itemID = C_Item.GetItemInfoInstant(itemLink)
    prospectStatus = AkcHouse.Prospect.IsProspectable(itemID)
    local prospectForOne = AkcHouse.Prospect.GetProspectAuctionPrice(itemID)
    if prospectForOne ~= nil then
      prospectValue = math.floor(prospectForOne * (showStackPrices and itemCount or 1))
    end
  end

  local millStatus = false
  local millValue
  if AkcHouse.Mill then
    local itemID = C_Item.GetItemInfoInstant(itemLink)
    millStatus = AkcHouse.Mill.IsMillable(itemID)
    local millForOne = AkcHouse.Mill.GetMillAuctionPrice(itemID)
    if millForOne ~= nil then
      millValue = math.floor(millForOne * (showStackPrices and itemCount or 1))
    end
  end

  if AkcHouse.Debug.IsOn() then
    tooltipFrame:AddDoubleLine("DBKey", dbKeys[1])
  end

  if vendorPrice ~= nil then
    AkcHouse.Tooltip.AddVendorTip(tooltipFrame, vendorPrice, countString)
  end
  AkcHouse.Tooltip.AddAuctionTip(tooltipFrame, auctionPrice, countString, cannotAuction)
  AkcHouse.Tooltip.AddAuctionMeanTip(tooltipFrame, auctionMean, countString, cannotAuction)
  AkcHouse.Tooltip.AddAuctionAgeTip(tooltipFrame, auctionAge, auctionPrice, showAgeUnknown)
  if disenchantStatus ~= nil then
    AkcHouse.Tooltip.AddDisenchantTip(tooltipFrame, disenchantPrice, countString, disenchantStatus)

    if not AkcHouse.Constants.IsRetail and IsShiftKeyDown() and AkcHouse.Config.Get(AkcHouse.Config.Options.ENCHANT_TOOLTIPS) then
      for _, line in ipairs(AkcHouse.Enchant.GetDisenchantBreakdown(itemLink, itemInfo)) do
        tooltipFrame:AddLine(line)
      end
    end
  end

  if prospectStatus then
    AkcHouse.Tooltip.AddProspectTip(tooltipFrame, prospectValue, countString)
  end

  if millStatus then
    AkcHouse.Tooltip.AddMillTip(tooltipFrame, millValue, countString)
  end
end

local isMultiplePricesPending = false
function AkcHouse.Tooltip.ShowTipWithMultiplePricing(tooltipFrame, itemEntries)
  if isMultiplePricesPending or AkcHouse.Database == nil then
    return
  end
  isMultiplePricesPending = true

  local total = 0
  local itemCount = 0
  local itemLinks = {}
  for _, itemEntry in ipairs(itemEntries) do
    table.insert(itemLinks, itemEntry.link)
  end

  AkcHouse.Utilities.DBKeysFromMultipleLinks(itemLinks, function(allKeys)
    isMultiplePricesPending = false
    for index, dbKeys in ipairs(allKeys) do
      local itemEntry = itemEntries[index]

      tooltipFrame:AddLine(itemEntry.link)
      AkcHouse.Tooltip.ShowTipWithPricingDBKey(tooltipFrame, dbKeys, itemEntry.link, itemEntry.count)
      local auctionPrice = AkcHouse.Database:GetFirstPrice(dbKeys)
      if auctionPrice ~= nil then
        total = total + (auctionPrice * itemEntry.count)
      end
      itemCount = itemCount + itemEntry.count
    end

    tooltipFrame:AddLine("  ")

    tooltipFrame:AddDoubleLine(
      AkcHouse.Locales.Apply("TOTAL_ITEMS_COLORED", itemCount),
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(total)
      )
    )

    tooltipFrame:Show()
  end)
end

function AkcHouse.Tooltip.AddVendorTip(tooltipFrame, vendorPrice, countString)
  if AkcHouse.Config.Get(AkcHouse.Config.Options.VENDOR_TOOLTIPS) and vendorPrice > 0 then
    if not AkcHouse.Constants.IsRetail then
      GameTooltip_ClearMoney(tooltipFrame)
    end

    tooltipFrame:AddDoubleLine(
      L("VENDOR") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(vendorPrice)
      )
    )
  end
end

function AkcHouse.Tooltip.AddAuctionTip (tooltipFrame, auctionPrice, countString, cannotAuction)
  if cannotAuction then
    return
  end
  if AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_TOOLTIPS) then
    if (auctionPrice ~= nil) then
      tooltipFrame:AddDoubleLine(
        L("AUCTION") .. countString,
        WHITE_FONT_COLOR:WrapTextInColorCode(
          AkcHouse.Utilities.CreatePaddedMoneyString(auctionPrice)
        )
      )
    else
      tooltipFrame:AddDoubleLine(
        L("AUCTION") .. countString,
        WHITE_FONT_COLOR:WrapTextInColorCode(
          L("UNKNOWN") .. "  "
        )
      )
    end
  end
end

function AkcHouse.Tooltip.AddAuctionMeanTip(tooltipFrame, auctionMean, countString, canAuction)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_MEAN_TOOLTIPS) then
    return
  end

  if auctionMean ~= nil then
    tooltipFrame:AddDoubleLine(
      L("AUCTION_MEAN") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(auctionMean)
      )
    )
  end
end

function AkcHouse.Tooltip.AddAuctionAgeTip(tooltipFrame, auctionAge, auctionPrice, showUnknown)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_AGE_TOOLTIPS) then
    return
  end

  if auctionAge ~= nil then
    tooltipFrame:AddDoubleLine(AKCHOUSE_L_AUCTION_AGE, WHITE_FONT_COLOR:WrapTextInColorCode(AKCHOUSE_L_X_DAYS:format(tostring(auctionAge))))
  elseif auctionPrice ~= nil and showUnknown then
    tooltipFrame:AddDoubleLine(AKCHOUSE_L_AUCTION_AGE, AKCHOUSE_L_UNKNOWN)
  end
end

function AkcHouse.Tooltip.AddDisenchantTip (
  tooltipFrame, disenchantPrice, countString, disenchantStatus
)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.ENCHANT_TOOLTIPS) then
    return
  end

  if disenchantPrice ~= nil then
    tooltipFrame:AddDoubleLine(
      L("DISENCHANT") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(disenchantPrice)
      )
    )
  elseif disenchantStatus.isDisenchantable and
         disenchantStatus.supportedXpac then
    tooltipFrame:AddDoubleLine(
      L("DISENCHANT") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        L("UNKNOWN") .. "  "
      )
    )
  end
end

function AkcHouse.Tooltip.AddProspectTip (
  tooltipFrame, prospectValue, countString
)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.PROSPECT_TOOLTIPS) then
    return
  end

  if prospectValue ~= nil then
    tooltipFrame:AddDoubleLine(
      L("PROSPECT") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(prospectValue)
      )
    )
  else
    tooltipFrame:AddDoubleLine(
      L("PROSPECT") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        L("UNKNOWN") .. "  "
      )
    )
  end
end

function AkcHouse.Tooltip.AddMillTip (
  tooltipFrame, millValue, countString
)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.MILL_TOOLTIPS) then
    return
  end

  if millValue ~= nil then
    tooltipFrame:AddDoubleLine(
      L("MILL") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(millValue)
      )
    )
  else
    tooltipFrame:AddDoubleLine(
      L("MILL") .. countString,
      WHITE_FONT_COLOR:WrapTextInColorCode(
        L("UNKNOWN") .. "  "
      )
    )
  end
end

local PET_TOOLTIP_SPACING = " "
function AkcHouse.Tooltip.AddPetTip(
  speciesID
)
  AkcHouse.Debug.Message("AkcHouse.Tooltip.AddPetTip", speciesID)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_TOOLTIPS) or
     not AkcHouse.Config.Get(AkcHouse.Config.Options.PET_TOOLTIPS) then
    return
  end

  local LibBattlePetTooltipLine = LibStub("LibBattlePetTooltipLine-1-0")

  local key = "p:" .. tostring(speciesID)
  local price = AkcHouse.Database:GetPrice(key)
  local auctionAge = AkcHouse.Database:GetPriceAge(key)
  BattlePetTooltip:AddLine(" ")
  if price ~= nil then
    LibBattlePetTooltipLine:AddDoubleLine(BattlePetTooltip,
      L("AUCTION"),
      WHITE_FONT_COLOR:WrapTextInColorCode(
        AkcHouse.Utilities.CreatePaddedMoneyString(price)
      )
    )
    if AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_AGE_TOOLTIPS) then
      if auctionAge ~= nil then
        LibBattlePetTooltipLine:AddDoubleLine(BattlePetTooltip, AKCHOUSE_L_AUCTION_AGE, WHITE_FONT_COLOR:WrapTextInColorCode(AKCHOUSE_L_X_DAYS:format(tostring(auctionAge))))
      elseif price ~= nil then
        LibBattlePetTooltipLine:AddDoubleLine(BattlePetTooltip, AKCHOUSE_L_AUCTION_AGE, AKCHOUSE_L_UNKNOWN)
      end
    end
  else
    LibBattlePetTooltipLine:AddDoubleLine(BattlePetTooltip,
      L("AUCTION"),
      WHITE_FONT_COLOR:WrapTextInColorCode(L("UNKNOWN"))
    )
  end
end

function AkcHouse.Tooltip.AddReagentsAuctionTip(tooltipFrame, allReagents)
  AkcHouse.Debug.Message("AkcHouse.Tooltip.AddReagentsAuctionTip", speciesID)
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_TOOLTIPS) then
    return
  end

  local showStackPrices = IsShiftKeyDown();

  if not AkcHouse.Config.Get(AkcHouse.Config.Options.SHIFT_STACK_TOOLTIPS) then
    showStackPrices = not IsShiftKeyDown();
  end

  for _, reagent in ipairs(allReagents) do
    local itemInfo = { C_Item.GetItemInfo(reagent.itemID) };
    if not AkcHouse.Utilities.IsBound(itemInfo) then
      local key = tostring(reagent.itemID)
      local auctionPrice = AkcHouse.Database:GetPrice(key)
      local auctionAge = AkcHouse.Database:GetPriceAge(key)
      local qualitySuffix = ""
      if reagent.quality then
        qualitySuffix = " " .. CreateAtlasMarkup(C_TradeSkillUI.GetItemReagentQualityInfo(reagent.itemID).iconChat, 17, 17)
      end
      local countString = ""
      if showStackPrices then
        countString = AkcHouse.Utilities.CreateCountString(reagent.itemCount)
      end
      if auctionPrice ~= nil then
        auctionPrice = auctionPrice * (showStackPrices and math.max(1, reagent.itemCount) or 1)
        tooltipFrame:AddDoubleLine(
          L("AUCTION") .. countString .. qualitySuffix,
          WHITE_FONT_COLOR:WrapTextInColorCode(
            AkcHouse.Utilities.CreatePaddedMoneyString(auctionPrice)
          )
        )
      else
        tooltipFrame:AddDoubleLine(
          L("AUCTION") .. countString .. qualitySuffix,
          WHITE_FONT_COLOR:WrapTextInColorCode(L("UNKNOWN"))
        )
      end
    end
  end
end
