if BattlePetToolTip_Show ~= nil then
  hooksecurefunc (_G, "BattlePetToolTip_Show",
    function(speciesID, ...)
      AkcHouse.Tooltip.AddPetTip(speciesID)
    end
  )
end

local TooltipHandlers = {}

TooltipHandlers["SetBagItem"] = function(tip, bag, slot)
  local itemLocation = ItemLocation:CreateFromBagAndSlot(bag, slot)

  if C_Item.DoesItemExist(itemLocation) then
    local itemLink = C_Item.GetItemLink(itemLocation);
    local itemCount = C_Item.GetStackCount(itemLocation)

    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

TooltipHandlers["SetBuybackItem"] = function(tip, slotIndex)
  local itemLink = GetBuybackItemLink(slotIndex)
  local _, _, _, itemCount = GetBuybackItemInfo(slotIndex);

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

local GetMerchantItemInfo = GetMerchantItemInfo or function(index)
  local info = C_MerchantFrame.GetItemInfo(index);
  if info then
    return info.name, info.texture, info.price, info.stackCount, info.numAvailable, info.isPurchasable, info.isUsable, info.hasExtendedCost, info.currencyID, info.spellID;
  end
end

TooltipHandlers["SetMerchantItem"] = function(tip, index)
  local itemLink = GetMerchantItemLink(index)
  local _, _, _, itemCount = GetMerchantItemInfo(index);

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

TooltipHandlers["SetInventoryItem"] = function(tip, unit, slot)
  local itemLink = GetInventoryItemLink(unit, slot)
  local itemCount = GetInventoryItemCount(unit, slot)

  if itemLink then
    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount ~= 0 and itemCount or 1)
  end
end

TooltipHandlers["SetGuildBankItem"] = function(tip, tab, slot)
  local itemLink = GetGuildBankItemLink(tab, slot)
  local _, itemCount = GetGuildBankItemInfo(tab, slot)

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

if GameTooltip.SetRecipeReagentItem then

  TooltipHandlers["SetRecipeReagentItem"] = function( tip, recipeID, slotID )
    local recipeLevel
    if ProfessionsFrame and ProfessionsFrame.CraftingPage:IsVisible() then
      recipeLevel = ProfessionsFrame.CraftingPage.SchematicForm:GetCurrentRecipeLevel()
    elseif ProfessionsFrame and ProfessionsFrame.OrdersPage:IsVisible() then
      recipeLevel =  ProfessionsFrame.OrdersPage.OrderView.OrderDetails.SchematicForm:GetCurrentRecipeLevel()
    end

    local schematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)

    for _, reagentSlotSchematic in ipairs(schematic.reagentSlotSchematics) do
      if reagentSlotSchematic.dataSlotIndex == slotID then
        local itemCount = reagentSlotSchematic.quantityRequired
        local _, itemLink = GetItemInfo(reagentSlotSchematic.reagents[1].itemID)

        AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
        break
      end
    end
  end
end

if GameTooltip.SetRecipeResultItem then
  TooltipHandlers["SetRecipeResultItem"] = function(tip, recipeID, reagents, allocations, recipeLevel, qualityID)
    local outputInfo = C_TradeSkillUI.GetRecipeOutputItemData(recipeID, reagents, allocations, qualityID)
    local outputLink = outputInfo and outputInfo.hyperlink

    if outputLink then
      local recipeSchematic = C_TradeSkillUI.GetRecipeSchematic(recipeID, false, recipeLevel)

      AkcHouse.Tooltip.ShowTipWithPricing(tip, outputLink, recipeSchematic.quantityMin)
    end
  end
end

if GameTooltip.SetItemByGUID then
  TooltipHandlers["SetItemByGUID"] = function(tip, guid)
    local itemLink = C_Item.GetItemLinkByGUID(guid)

    if itemLink then
      AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, 1)
    end
  end
end

if GameTooltip.SetTradeSkillItem then
  TooltipHandlers["SetTradeSkillItem"] = function(tip, recipeIndex, reagentIndex)
    local itemLink, itemCount
    if reagentIndex ~= nil then
      itemLink = GetTradeSkillReagentItemLink(recipeIndex, reagentIndex)
      itemCount = select(3, GetTradeSkillReagentInfo(recipeIndex, reagentIndex))
    else
      itemLink = GetTradeSkillItemLink(recipeIndex);
      itemCount  = GetTradeSkillNumMade(recipeIndex);
    end
    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

if GameTooltip.SetCraftItem then
  TooltipHandlers["SetCraftItem"] = function(tip, recipeIndex, reagentIndex)
    local itemLink, itemCount
    if reagentIndex ~= nil then
      itemLink = GetCraftReagentItemLink(recipeIndex, reagentIndex)
      itemCount = select(3, GetCraftReagentInfo(recipeIndex, reagentIndex))
    else
      itemLink = GetCraftItemLink(recipeIndex);
      itemCount  = GetCraftNumMade(recipeIndex);
    end
    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

TooltipHandlers["SetLootItem"] = function (tip, slot)
  if LootSlotHasItem(slot) then
    local itemLink, _, itemCount = GetLootSlotLink(slot);

    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

TooltipHandlers["SetLootRollItem"] = function (tip, slot)
  local itemLink = GetLootRollItemLink(slot)

  local _, _, itemCount = GetLootRollItemInfo(slot)

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

TooltipHandlers["SetQuestItem"] = function (tip, type, index)
  local itemLink = GetQuestItemLink(type, index)

  local _, _, itemCount = GetQuestItemInfo(type, index);

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

TooltipHandlers["SetQuestLogItem"] = function (tip, type, index)
  local itemLink = GetQuestLogItemLink(type, index)

  local itemCount, _;
  if type == "choice" then
    _, _, itemCount = GetQuestLogChoiceInfo(index);
  else
    _, _, itemCount = GetQuestLogRewardInfo(index)
  end

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

TooltipHandlers["SetSendMailItem"] = function (tip, id)
  local _, _, _, itemCount = GetSendMailItem(id)
  local itemLink = GetSendMailItemLink(id);

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
end

TooltipHandlers["SetInboxItem"] = function(tip, index, attachIndex)
  if AkcHouse.Config.Get(AkcHouse.Config.Options.MAILBOX_TOOLTIPS) then
    local attachmentIndex = attachIndex or 1

    local itemLink = GetInboxItemLink(index, attachmentIndex)

    local _, _, _, itemCount = GetInboxItem(index, attachmentIndex);

    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

hooksecurefunc("InboxFrameItem_OnEnter",
  function(self)
    local itemCount = select(8, GetInboxHeaderInfo(self.index))
    local tooltipEnabled =
      AkcHouse.Config.Get(AkcHouse.Config.Options.MAILBOX_TOOLTIPS) and  (
      AkcHouse.Config.Get(AkcHouse.Config.Options.VENDOR_TOOLTIPS) or
      AkcHouse.Config.Get(AkcHouse.Config.Options.AUCTION_TOOLTIPS) or
      AkcHouse.Config.Get(AkcHouse.Config.Options.ENCHANT_TOOLTIPS)
    )

    if tooltipEnabled and itemCount and itemCount > 1 then
      local itemEntries = {}
      local name, itemCount, itemLink, _

      for attachmentIndex = 1, ATTACHMENTS_MAX_RECEIVE do
        name, _, _, itemCount = GetInboxItem(self.index, attachmentIndex)

        if name then
          itemLink = GetInboxItemLink(self.index, attachmentIndex)

          table.insert(itemEntries, {
            link = itemLink,
            count = itemCount,
            name = name
          })
        end
      end

      AkcHouse.Tooltip.ShowTipWithMultiplePricing(GameTooltip, itemEntries)
    end
  end
);

TooltipHandlers["SetTradePlayerItem"] = function (tip, id)
  local itemLink = GetTradePlayerItemLink(id)
  if itemLink ~= nil then
    local _, _, itemCount = GetTradePlayerItemInfo(id);

    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

TooltipHandlers["SetTradeTargetItem"] = function (tip, id)
  local itemLink = GetTradeTargetItemLink(id)
  if itemLink ~= nil then
    local _, _, itemCount = GetTradeTargetItemInfo(id)

    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

if GameTooltip.SetAuctionItem then
  TooltipHandlers["SetAuctionItem"] = function(tip, viewType, index)
    local itemCount = select(3, GetAuctionItemInfo(viewType, index))
    local itemLink = GetAuctionItemLink(viewType, index)

    AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, itemCount)
  end
end

if GameTooltip.SetItemKey then
  TooltipHandlers["SetItemKey"] = function(tip, itemID, itemLevel, itemSuffix)
    local itemLink
    if C_TooltipInfo then
      local info = C_TooltipInfo and C_TooltipInfo.GetItemKey(itemID, itemLevel, itemSuffix)
      if info == nil then
        return
      end
      itemLink = info.hyperlink
    else
      itemLink = select(2, tip:GetItem())
    end
    if itemLink then

      if C_Item.GetItemInfoInstant(itemLink) ~= itemID then
        itemLink = select(2, C_Item.GetItemInfo(itemID))
      end
      AkcHouse.Tooltip.ShowTipWithPricingDBKey(
        tip,
        AkcHouse.Utilities.DBKeyFromBrowseResult({itemKey = {itemID = itemID, itemLevel = itemLevel, itemSuffix = itemSuffix, battlePetSpeciesID = 0}}),
        itemLink,
        1
      )
    end
  end
end

TooltipHandlers["SetItemByID"] = function (tip, itemID)
  if not itemID then
    return
  end

  local itemLink = select(2, C_Item.GetItemInfo(itemID))

  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, 1)
end

TooltipHandlers["SetHyperlink"] = function (tip, itemLink)
  AkcHouse.Tooltip.ShowTipWithPricing(tip, itemLink, 1)
end

if TooltipDataProcessor and C_TooltipInfo then
  local function ValidateTooltip(tooltip)
    if tooltip == GameTooltip or tooltip == GameTooltipTooltip or tooltip == ItemRefTooltip or tooltip == GarrisonShipyardMapMissionTooltipTooltip then
      return true
    end
    if tooltip:IsForbidden() then
      return false
    end
    local name = tooltip:GetName() or ""
    return name:match("^NotGameTooltip") or name:match("^RSMap")
  end
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
    if ValidateTooltip(tooltip) then
      local info = tooltip.info or tooltip.processingInfo
      if not info or not info.getterName or info.excludeLines then
        return
      end
      local handler = TooltipHandlers[info.getterName:gsub("^Get", "Set")]
      if handler ~= nil then
        handler(tooltip, unpack(info.getterArgs))
      end
    end
  end)
else

  hooksecurefunc(ItemRefTooltip, "SetHyperlink", TooltipHandlers["SetHyperlink"])

  for func, handler in pairs(TooltipHandlers) do
    hooksecurefunc(GameTooltip, func, handler)
  end
end

EventUtil.ContinueOnAddOnLoaded("Blizzard_ProfessionsTemplates", function()
  local function QualityTooltip(slot, transaction, noInstruction)
    local display = {}
    local quantities = Professions.GetQuantitiesAllocated(transaction, slot:GetReagentSlotSchematic())
    for index, reagentDetails in ipairs(slot:GetReagentSlotSchematic().reagents) do
      table.insert(display, {
        itemID = reagentDetails.itemID,
        quality = C_TradeSkillUI.GetItemReagentQualityByItemInfo(reagentDetails.itemID),
        itemCount = quantities[index],
      })
    end
    table.sort(display, function(a, b)
      return a.quality < b.quality
    end)

    AkcHouse.Tooltip.AddReagentsAuctionTip(GameTooltip, display)
  end
  local function OptionalTooltip(item)
  end
  if Professions.SetupQualityReagentTooltip then
    hooksecurefunc(Professions, "SetupQualityReagentTooltip", QualityTooltip)
    hooksecurefunc(Professions, "AddCommonOptionalTooltipInfo", function(item)
      AkcHouse.Tooltip.AddReagentsAuctionTip(GameTooltip, {{itemID = item:GetItemID(), itemCount = 1}})
    end)
  elseif Professions.SetupReagentQualityPickerTooltip then
    hooksecurefunc(Professions, "SetupReagentQualityPickerTooltip", QualityTooltip)
    hooksecurefunc(Professions, "SetupOptionalReagentTooltip", function(slot, transaction)
      local reagent = slot.Button:GetReagent()
      if reagent and reagent.itemID then
        AkcHouse.Tooltip.AddReagentsAuctionTip(GameTooltip, {{itemID = reagent.itemID, itemCount = 1}})
      end
    end)
  end
end)
