local currentLocale = {}

local function FixMissingTranslations(incomplete, locale)
  if locale == "enUS" then
    return
  end

  local enUS = AKCHOUSE_LOCALES["enUS"]()
  for key, val in pairs(enUS) do
    if incomplete[key] == nil then
      incomplete[key] = val
    end
  end
end

local function AddNewLines(full)
  for key, val in pairs(full) do
    full[key] = string.gsub(full[key], "\\n", "\n")
  end
end

if AKCHOUSE_LOCALES_OVERRIDE ~= nil then
  currentLocale = AKCHOUSE_LOCALES_OVERRIDE()

  FixMissingTranslations(currentLocale, "OVERRIDE")
elseif AKCHOUSE_LOCALES[GetLocale()] ~= nil then
  currentLocale = AKCHOUSE_LOCALES[GetLocale()]()

  FixMissingTranslations(currentLocale, GetLocale())
else
  currentLocale = AKCHOUSE_LOCALES["enUS"]()
end

AddNewLines(currentLocale)

for key, value in pairs(currentLocale) do
  _G["AKCHOUSE_L_"..key] = value
end

function AkcHouse.Locales.Apply(s, ...)
  if currentLocale[s] ~= nil then
    return string.format(currentLocale[s], ...)
  else
    error("Unknown/missing locale string '" .. s .. "'")
  end
end
