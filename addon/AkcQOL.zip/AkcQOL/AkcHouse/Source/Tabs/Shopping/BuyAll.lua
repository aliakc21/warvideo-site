local PRICE_TOLERANCE = 1.05
local STEP_TIMEOUT = 10

local PURCHASE_EVENTS = {
  "COMMODITY_PRICE_UPDATED",
  "COMMODITY_PRICE_UNAVAILABLE",
  "COMMODITY_PURCHASE_SUCCEEDED",
  "COMMODITY_PURCHASE_FAILED",
}

local function Msg(text)
  print("|cff8c5cffAkc|r|cffffffffHouse|r: " .. text)
end

local function QualityMarkup(quality)
  if not quality or quality == 0 then return "" end
  local ok, markup = pcall(CreateAtlasMarkup, "Professions-ChatIcon-Quality-Tier" .. quality)
  if ok and markup then return " " .. markup end
  return " (T" .. quality .. ")"
end

local RefreshButton, UpdateDialog

local Engine = CreateFrame("Frame")
Engine.busy = false

function Engine:CurrentLine()
  return self.queue and self.queue[self.index]
end

function Engine:BeginPlan(plan)
  self.busy = true
  self.queue = plan.lines
  self.index = 1
  self.spent = 0
  self.bought = 0
  self.failed = 0
  self.stepActive = false
  self.token = (self.token or 0) + 1
  FrameUtil.RegisterFrameForEvents(self, PURCHASE_EVENTS)
end

function Engine:Advance()
  self.index = self.index + 1
  self.token = self.token + 1
  self.pendingTotal = nil
  self.stepActive = false
  if not self:CurrentLine() then
    self:Finish()
    return
  end
  if RefreshButton then RefreshButton() end
  if UpdateDialog then UpdateDialog() end
end

function Engine:BuyCurrent()
  local line = self:CurrentLine()
  if not self.busy or not line or self.stepActive then return end
  self.stepActive = true
  self.token = self.token + 1
  local token = self.token

  C_AuctionHouse.StartCommoditiesPurchase(line.itemID, line.quantity)
  if RefreshButton then RefreshButton() end
  if UpdateDialog then UpdateDialog() end

  C_Timer.After(STEP_TIMEOUT, function()
    if self.busy and self.token == token and self.stepActive then
      pcall(C_AuctionHouse.CancelCommoditiesPurchase)
      line.status = "fail"
      self.failed = self.failed + 1
      Msg("|cFFF59E0B" .. line.name .. "|r: timed out, skipped.")
      self:Advance()
    end
  end)
end

function Engine:Stop(silent)
  if not self.busy then return end
  FrameUtil.UnregisterFrameForEvents(self, PURCHASE_EVENTS)
  self.busy = false
  self.stepActive = false
  self.token = self.token + 1
  pcall(C_AuctionHouse.CancelCommoditiesPurchase)
  if not silent then
    Msg("Stopped: |cFF59D97Bbought " .. self.bought .. "|r, |cFFF25850skipped " .. self.failed .. "|r. Spent: " .. GetMoneyString(self.spent, true))
  end
  if RefreshButton then RefreshButton() end
  if UpdateDialog then UpdateDialog() end
end

function Engine:Finish()
  FrameUtil.UnregisterFrameForEvents(self, PURCHASE_EVENTS)
  self.busy = false
  self.stepActive = false
  Msg("Done: |cFF59D97Bbought " .. self.bought .. "|r, |cFFF25850skipped " .. self.failed .. "|r. Spent: " .. GetMoneyString(self.spent, true))
  if RefreshButton then RefreshButton() end
  if UpdateDialog then UpdateDialog() end
end

function Engine:OnEvent(eventName, ...)
  if not self.busy or not self.stepActive then return end
  local line = self:CurrentLine()
  if not line then return end

  if eventName == "COMMODITY_PRICE_UPDATED" then
    local unitPrice, totalPrice = ...
    if totalPrice > math.ceil(line.total * PRICE_TOLERANCE) then
      pcall(C_AuctionHouse.CancelCommoditiesPurchase)
      line.status = "fail"
      self.failed = self.failed + 1
      Msg("|cFFF59E0B" .. line.name .. "|r: price rose (" .. GetMoneyString(totalPrice, true) .. " > " .. GetMoneyString(line.total, true) .. "), skipped.")
      self:Advance()
    else
      self.pendingTotal = totalPrice
      C_AuctionHouse.ConfirmCommoditiesPurchase(line.itemID, line.quantity)
    end

  elseif eventName == "COMMODITY_PRICE_UNAVAILABLE" then
    pcall(C_AuctionHouse.CancelCommoditiesPurchase)
    line.status = "fail"
    self.failed = self.failed + 1
    Msg("|cFFF59E0B" .. line.name .. "|r: price unavailable, skipped.")
    self:Advance()

  elseif eventName == "COMMODITY_PURCHASE_SUCCEEDED" then
    line.status = "ok"
    self.bought = self.bought + 1
    self.spent = self.spent + (self.pendingTotal or line.total)
    self:Advance()

  elseif eventName == "COMMODITY_PURCHASE_FAILED" then
    line.status = "fail"
    self.failed = self.failed + 1
    Msg("|cFFF25850" .. line.name .. "|r: purchase failed.")
    self:Advance()
  end
end

Engine:SetScript("OnEvent", Engine.OnEvent)

local function BuildPlan(tab, mode)
  local list = tab.ListsContainer and tab.ListsContainer.GetExpandedList and tab.ListsContainer:GetExpandedList()
  if not list then
    Msg("Open a shopping list first (its search results must be shown).")
    return nil
  end

  local results = tab.DataProvider and tab.DataProvider.results
  if not results or #results == 0 then
    Msg("No search results. Search the list first.")
    return nil
  end

  local wanted = {}
  local order = {}
  for _, itemString in ipairs(list:GetAllItems()) do
    local term = AkcHouse.Search.SplitAdvancedSearch(itemString)
    local key = term and term.searchString and term.searchString:lower()
    if key and key ~= "" then
      if not wanted[key] then
        order[#order + 1] = key
        wanted[key] = { quantity = 0, label = term.searchString }
      end
      wanted[key].quantity = wanted[key].quantity + (term.quantity or 1)
    end
  end

  local best = {}
  for _, entry in ipairs(results) do
    local itemID = entry.itemKey and entry.itemKey.itemID
    local unitPrice = entry.minPrice or 0
    if itemID and unitPrice > 0 then
      local name = C_Item.GetItemInfo(itemID)
      local key = name and name:lower()
      if key and wanted[key] then
        local keyInfo = C_AuctionHouse.GetItemKeyInfo(entry.itemKey)
        local quality = C_TradeSkillUI.GetItemReagentQualityByItemInfo(itemID) or 0
        local candidate = {
          itemID = itemID,
          name = name,
          quality = quality,
          unitPrice = unitPrice,
          available = entry.totalQuantity or 0,
          isCommodity = keyInfo and keyInfo.isCommodity or false,
        }
        local current = best[key]
        local qualityWins
        if mode == "low" then
          qualityWins = current and candidate.quality < current.quality
        else
          qualityWins = current and candidate.quality > current.quality
        end
        if not current
          or qualityWins
          or (candidate.quality == current.quality and candidate.unitPrice < current.unitPrice) then
          best[key] = candidate
        end
      end
    end
  end

  local plan = { lines = {}, skipped = {}, total = 0 }
  for _, key in ipairs(order) do
    local want = wanted[key]
    local pick = best[key]
    if not pick then
      table.insert(plan.skipped, want.label .. " — not in results")
    elseif not pick.isCommodity then
      table.insert(plan.skipped, pick.name .. " — buy manually (not a commodity)")
    elseif pick.available <= 0 then
      table.insert(plan.skipped, pick.name .. " — none available")
    else
      local quantity = math.min(want.quantity, pick.available)
      table.insert(plan.lines, {
        itemID = pick.itemID, name = pick.name, quality = pick.quality,
        quantity = quantity, unitPrice = pick.unitPrice,
        total = pick.unitPrice * quantity, short = quantity < want.quantity,
        status = "pending",
      })
      plan.total = plan.total + pick.unitPrice * quantity
    end
  end

  if #plan.lines == 0 then
    Msg("Nothing buyable found for this list.")
    return nil
  end

  return plan
end

local dialog

local function EnsureDialog()
  if dialog then return dialog end

  dialog = CreateFrame("Frame", "AkcHouseBuyAllDialog", UIParent, "BackdropTemplate")
  dialog:SetFrameStrata("HIGH")
  dialog:SetSize(400, 220)
  dialog:SetClampedToScreen(true)
  dialog:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 },
  })
  dialog:EnableMouse(true)
  dialog:SetMovable(true)
  dialog:RegisterForDrag("LeftButton")
  dialog:SetScript("OnDragStart", dialog.StartMoving)
  dialog:SetScript("OnDragStop", dialog.StopMovingOrSizing)
  dialog:Hide()

  dialog.Title = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  dialog.Title:SetPoint("TOP", 0, -16)

  dialog.Sub = dialog:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  dialog.Sub:SetPoint("TOP", dialog.Title, "BOTTOM", 0, -2)
  dialog.Sub:SetTextColor(0.70, 0.70, 0.75, 1)

  dialog.Body = dialog:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  dialog.Body:SetPoint("TOPLEFT", 26, -58)
  dialog.Body:SetPoint("RIGHT", -26, 0)
  dialog.Body:SetJustifyH("LEFT")
  dialog.Body:SetSpacing(4)

  dialog.Total = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  dialog.Total:SetPoint("BOTTOM", 0, 66)

  dialog.Hint = dialog:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  dialog.Hint:SetPoint("BOTTOM", 0, 52)
  dialog.Hint:SetTextColor(0.55, 0.55, 0.60, 1)

  dialog.Accept = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
  dialog.Accept:SetSize(150, 26)
  dialog.Accept:SetPoint("BOTTOMRIGHT", dialog, "BOTTOM", -6, 18)
  dialog.Accept:SetText(ACCEPT)
  dialog.Accept:SetScript("OnClick", function()
    if not Engine.busy then
      if dialog.started then
        dialog:Hide()
        return
      end
      if not dialog.plan then return end
      dialog.started = true
      Engine:BeginPlan(dialog.plan)
      Engine:BuyCurrent()
    elseif not Engine.stepActive then
      Engine:BuyCurrent()
    end
  end)

  dialog.Cancel = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
  dialog.Cancel:SetSize(150, 26)
  dialog.Cancel:SetPoint("BOTTOMLEFT", dialog, "BOTTOM", 6, 18)
  dialog.Cancel:SetText(CANCEL)
  dialog.Cancel:SetScript("OnClick", function() dialog:Hide() end)

  dialog:SetScript("OnHide", function()
    if Engine.busy then Engine:Stop() end
    dialog.plan = nil
    dialog.started = nil
  end)

  return dialog
end

function UpdateDialog()
  if not dialog or not dialog:IsShown() or not dialog.plan then return end
  local plan = dialog.plan

  local rows = {}
  for i, line in ipairs(plan.lines) do
    local prefix, color
    if line.status == "ok" then
      prefix, color = "|cFF59D97B[ok]|r ", "|cFF59D97B"
    elseif line.status == "fail" then
      prefix, color = "|cFFF25850[x]|r ", "|cFF9AA0A6"
    elseif Engine.busy and i == Engine.index then
      prefix, color = "|cFFFFD100>|r ", "|cFFFFD100"
    else
      prefix, color = "|cFF9AA0A6-|r ", "|cFFE5E7EB"
    end
    local t = prefix .. color .. line.quantity .. "x " .. line.name .. "|r" .. QualityMarkup(line.quality)
      .. "  —  " .. GetMoneyString(line.total, true)
    if line.short and line.status == "pending" then
      t = t .. " |cFFF59E0B(only " .. line.quantity .. " available)|r"
    end
    rows[#rows + 1] = t
  end
  for _, skip in ipairs(plan.skipped) do
    rows[#rows + 1] = "|cFF9AA0A6skip: " .. skip .. "|r"
  end

  dialog.Body:SetText(table.concat(rows, "\n"))
  dialog:SetHeight(150 + #rows * 16)

  if Engine.busy then
    local line = Engine:CurrentLine()
    dialog.Total:SetText("Spent: " .. GetMoneyString(Engine.spent, true) .. "   |cFF9AA0A6/   Total: " .. GetMoneyString(plan.total, true) .. "|r")
    dialog.Cancel:SetText("Stop")
    if Engine.stepActive then
      dialog.Accept:SetText("Buying...")
      dialog.Accept:Disable()
      dialog.Hint:SetText("")
    elseif line then
      dialog.Accept:SetText(("Accept (%d/%d)"):format(Engine.index, #Engine.queue))
      dialog.Hint:SetText("Keep clicking Accept — one click buys one item.")
      if line.total > GetMoney() then
        dialog.Accept:Disable()
        dialog.Hint:SetText("|cFFF25850Not enough gold for this item.|r")
      else
        dialog.Accept:Enable()
      end
    end
  elseif dialog.started then
    dialog.Total:SetText("Spent: " .. GetMoneyString(Engine.spent or 0, true))
    dialog.Hint:SetText("")
    dialog.Accept:SetText(CLOSE)
    dialog.Accept:Enable()
    dialog.Cancel:Hide()
  else
    if plan.total > GetMoney() then
      dialog.Total:SetText("Total: " .. GetMoneyString(plan.total, true) .. "  |cFFF25850(not enough gold)|r")
      dialog.Accept:Disable()
    else
      dialog.Total:SetText("Total: " .. GetMoneyString(plan.total, true))
      dialog.Accept:Enable()
    end
    dialog.Accept:SetText(ACCEPT)
    dialog.Cancel:SetText(CANCEL)
    dialog.Hint:SetText("Accept buys one item per click; bought items turn green.")
  end
end

local function ShowConfirm(plan, listName, modeLabel)
  if _G.AkcHousePostQueueFrame and _G.AkcHousePostQueueFrame:IsShown() then
    _G.AkcHousePostQueueFrame.akcKeepQueue = true
    _G.AkcHousePostQueueFrame:Hide()
  end
  local d = EnsureDialog()
  d.plan = plan
  d.started = nil
  d.Cancel:Show()
  d.Title:SetText("Buy All — " .. (modeLabel or "Best Quality"))
  d.Sub:SetText(listName or "")
  d:ClearAllPoints()
  if AuctionHouseFrame and AuctionHouseFrame:IsShown() then
    d:SetPoint("TOPLEFT", AuctionHouseFrame, "TOPRIGHT", 4, 0)
  else
    d:SetPoint("CENTER", 0, 60)
  end
  d:Show()
  UpdateDialog()
end

local buttons = {}

function RefreshButton()
  for _, b in ipairs(buttons) do
    if Engine.busy then
      b:Disable()
    else
      b:Enable()
    end
  end
end

local function OnButtonClick(self)
  if Engine.busy then return end
  if not (AuctionHouseFrame and AuctionHouseFrame:IsShown()) then return end
  local tab = self.akcTab
  local plan = BuildPlan(tab, self.akcMode)
  if not plan then return end
  local list = tab.ListsContainer:GetExpandedList()
  ShowConfirm(plan, list and list:GetName(), self.akcMode == "low" and "Lowest Quality" or "Best Quality")
end

local function MakeBuyButton(tab, anchorTo, mode, label)
  local button = CreateFrame("Button", nil, tab, "UIPanelDynamicResizeButtonTemplate")
  button.akcTab = tab
  button.akcMode = mode
  button:SetText(label)
  DynamicResizeButton_Resize(button)
  button:SetPoint("RIGHT", anchorTo, "LEFT", -5, 0)
  button:SetScript("OnClick", OnButtonClick)
  table.insert(buttons, button)
  return button
end

local function Setup(tab)
  if tab.AkcBuyAllButton then return end

  local bestBtn = MakeBuyButton(tab, tab.ExportCSV, "best", "Buy All (Best Quality)")
  local lowBtn = MakeBuyButton(tab, bestBtn, "low", "Buy All (Lowest Quality)")
  tab.AkcBuyAllButton = bestBtn
  tab.AkcBuyAllLowButton = lowBtn

  tab.ExportCSV:HookScript("OnShow", function()
    bestBtn:Show(); lowBtn:Show(); RefreshButton()
  end)
  tab.ExportCSV:HookScript("OnHide", function()
    if dialog then dialog:Hide() end
    if Engine.busy then Engine:Stop(true) end
    bestBtn:Hide(); lowBtn:Hide()
  end)
end

hooksecurefunc(AkcHouseShoppingTabFrameMixin, "OnLoad", function(self)
  Setup(self)
end)
