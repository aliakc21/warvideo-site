AkcHouseItemHistoryFrameMixin = CreateFromMixins(AkcHouseEscapeToCloseMixin)

function AkcHouseItemHistoryFrameMixin:Init()
  self.ResultsListing:Init(self.DataProvider)

  AkcHouse.EventBus:Register(self, { AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices })
  self.isDocked = false
end

function AkcHouseItemHistoryFrameMixin:OnShow()
  AkcHouse.Debug.Message("AkcHouseItemHistoryFrameMixin:OnShow()")

  AkcHouse.EventBus
    :RegisterSource(self, "lists item history dialog")
    :Fire(self, AkcHouse.Shopping.Tab.Events.DialogOpened)
    :UnregisterSource(self)
end

function AkcHouseItemHistoryFrameMixin:OnHide()
  self:Hide()

  AkcHouse.EventBus
    :RegisterSource(self, "lists item history 1")
    :Fire(self, AkcHouse.Shopping.Tab.Events.DialogClosed)
    :UnregisterSource(self)
end

function AkcHouseItemHistoryFrameMixin:ReceiveEvent(event, itemInfo)
  if event == AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices then
    self.Title:SetText(AKCHOUSE_L_X_PRICE_HISTORY:format(itemInfo.name))
  end
end

function AkcHouseItemHistoryFrameMixin:OnDockDialogClicked()
  self:ClearAllPoints()
  if self.isDocked then
    self:SetPoint("CENTER", self:GetParent(), "CENTER")

    self.Dock.Arrow:SetTexCoord(0, 1, 0, 1)
  else
    self:SetPoint("LEFT", AuctionHouseFrame or AuctionFrame, "RIGHT")

    self.Dock.Arrow:SetTexCoord(1, 0, 0, 1)
  end

  self.isDocked = not self.isDocked
end

function AkcHouseItemHistoryFrameMixin:OnCloseDialogClicked()
  self:Hide()
end
