AkcHouseShoppingTabFrameMixin = {}

local EVENTBUS_EVENTS = {
  AkcHouse.Shopping.Events.ListImportFinished,
  AkcHouse.Shopping.Tab.Events.ListSearchRequested,
  AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices,
  AkcHouse.Shopping.Tab.Events.UpdateSearchTerm,
  AkcHouse.Shopping.Tab.Events.BuyScreenShown,
}

function AkcHouseShoppingTabFrameMixin:DoSearch(terms, options)
  if #terms == 0 then
    return
  end

  if options == nil and AkcHouse.Constants.IsLegacyAH and IsShiftKeyDown() then
    options = { searchAllPages = true }
  end

  self:StopSearch()

  self.searchRunning = true
  AkcHouse.EventBus:Fire(self, AkcHouse.Shopping.Tab.Events.SearchStart, terms)
  self.SearchProvider:Search(terms, options or {})
  self:StartSpinner()
end

function AkcHouseShoppingTabFrameMixin:StopSearch()
  self.searchRunning = false
  self.SearchProvider:AbortSearch()
end

function AkcHouseShoppingTabFrameMixin:StartSpinner()
  self.ListsContainer.SpinnerAnim:Play()
  self.ListsContainer.LoadingSpinner:Show()
  self.ListsContainer.ResultsText:SetText(AkcHouse.Locales.Apply("LIST_SEARCH_START", self:GetAppropriateListSearchName()))
  self.ListsContainer.ResultsText:Show()
end

function AkcHouseShoppingTabFrameMixin:CloseAnyDialogs()
  for _, d in ipairs(self.dialogs) do
    if d:IsShown() then
      d:Hide()
    end
  end
end

function AkcHouseShoppingTabFrameMixin:OnLoad()
  AkcHouse.EventBus:RegisterSource(self, "AkcHouseShoppingTabFrameMixin")

  self.ResultsListing:Init(self.DataProvider)

  self.dialogs = {}

  self.itemDialog = CreateFrame("Frame", "AkcHouseShoppingTabItemFrame", self, "AkcHouseShoppingItemTemplate")
  self.itemDialog:ClearAllPoints()
  self.itemDialog:SetPoint("CENTER")
  table.insert(self.dialogs, self.itemDialog)

  self.exportDialog = CreateFrame("Frame", "AkcHouseExportListFrame", self, "AkcHouseExportListTemplate")
  self.exportDialog:SetPoint("CENTER")
  table.insert(self.dialogs, self.exportDialog)

  self.importDialog = CreateFrame("Frame", "AkcHouseImportListFrame", self, "AkcHouseImportListTemplate")
  self.importDialog:SetPoint("CENTER")
  table.insert(self.dialogs, self.importDialog)

  self.exportCSVDialog = CreateFrame("Frame", nil, self, "AkcHouseExportTextFrame")
  self.exportCSVDialog:SetPoint("CENTER")
  table.insert(self.dialogs, self.exportCSVDialog)

  self.ExportButton:SetScript("OnClick", function()
    self:CloseAnyDialogs()
    self.exportDialog:Show()
  end)
  self.ImportButton:SetScript("OnClick", function()
    self:CloseAnyDialogs()
    self.importDialog:Show()
  end)

  self.itemHistoryDialog = CreateFrame("Frame", "AkcHouseItemHistoryFrame", self, "AkcHouseItemHistoryTemplate")
  self.itemHistoryDialog:SetPoint("CENTER")
  self.itemHistoryDialog:Init()

  self:SetupSearchProvider()

  self:SetupListsContainer()
  self:SetupRecentsContainer()
  self:SetupTopSearch()

  self.NewListButton:SetScript("OnClick", function()
    AkcHouse.Dialogs.ShowEditBox(AKCHOUSE_L_CREATE_LIST_DIALOG, ACCEPT, CANCEL, function(text)
      local name = AkcHouse.Shopping.ListManager:GetUnusedName(text)
      AkcHouse.Shopping.ListManager:Create(name)
      self.ListsContainer:ExpandList(AkcHouse.Shopping.ListManager:GetByName(name))
    end)
  end)

  self.ContainerTabs:SetView(AkcHouse.Config.Get(AkcHouse.Config.Options.SHOPPING_LAST_CONTAINER_VIEW))

  self.shouldDefaultOpenOnShow = true
  if AkcHouse.Constants.IsVanilla then
    self:RegisterEvent("AUCTION_HOUSE_CLOSED")
  else
    self:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_HIDE")
  end
end

function AkcHouseShoppingTabFrameMixin:SetupSearchProvider()
  self.SearchProvider:InitSearch(
    function(results)
      self.searchRunning = false
      AkcHouse.EventBus:Fire(self, AkcHouse.Shopping.Tab.Events.SearchEnd, results)
      self.ListsContainer.SpinnerAnim:Stop()
      self.ListsContainer.LoadingSpinner:Hide()
      self.ListsContainer.ResultsText:Hide()
    end,
    function(current, total, partialResults)
      AkcHouse.EventBus:Fire(self, AkcHouse.Shopping.Tab.Events.SearchIncrementalUpdate, partialResults, total, current)
      self.ListsContainer.ResultsText:SetText(AkcHouse.Locales.Apply("LIST_SEARCH_STATUS", current, total, self:GetAppropriateListSearchName()))
    end
  )
end

function AkcHouseShoppingTabFrameMixin:SetupListsContainer()
  self.ListsContainer:SetOnListExpanded(function()
    if AkcHouse.Config.Get(AkcHouse.Config.Options.AUTO_LIST_SEARCH) then
      self.singleSearch = false
      self:DoSearch(self.ListsContainer:GetExpandedList():GetAllItems())
    end
    self.SearchOptions:OnListExpanded()
  end)
  self.ListsContainer:SetOnListCollapsed(function()
    self:StopSearch()
    self.SearchOptions:OnListCollapsed()
  end)
  self.ListsContainer:SetOnSearchTermClicked(function(list, searchTerm, index)
    self.singleSearch = true
    self:DoSearch({searchTerm})
    self.SearchOptions:SetSearchTerm(searchTerm)
    self.ListsContainer:TemporarilySelectSearchTerm(index)
  end)
  self.ListsContainer:SetOnSearchTermDelete(function(list, searchTerm, index)
    list:DeleteItem(index)
  end)
  self.ListsContainer:SetOnSearchTermEdit(function(list, searchTerm, index)
    self:CloseAnyDialogs()
    self.itemDialog:Init(AKCHOUSE_L_LIST_EDIT_ITEM_HEADER, AKCHOUSE_L_EDIT_ITEM)
    self.itemDialog:SetOnFinishedClicked(function(newItemString)
      list:AlterItem(index, newItemString)
    end)
    self.itemDialog:Show()
    self.itemDialog:SetItemString(searchTerm)
  end)
  self.ListsContainer:SetOnListSearch(function(list)
    self.singleSearch = false
    self:DoSearch(list:GetAllItems())
  end)
  self.ListsContainer:SetOnListEdit(function(list)
    if list:IsTemporary() then
      AkcHouse.Dialogs.ShowEditBox(AKCHOUSE_L_MAKE_PERMANENT_CONFIRM:format(list:GetName()), ACCEPT, CANCEL, function(text)
        list:Rename(text)
        list:MakePermanent()
        AkcHouse.Shopping.ListManager:Sort()
        self.ListsContainer:ScrollToList(list)
      end)
    else
      AkcHouse.Dialogs.ShowEditBox(AKCHOUSE_L_RENAME_LIST_CONFIRM:format(list:GetName()), ACCEPT, CANCEL, function(text)
        list:Rename(text)
        AkcHouse.Shopping.ListManager:Sort()
        self.ListsContainer:ScrollToList(list)
      end)
    end
  end)
  self.ListsContainer:SetOnListDelete(function(list)
    AkcHouse.Dialogs.ShowConfirm(AKCHOUSE_L_DELETE_LIST_CONFIRM:format(list:GetName()):gsub("%%", "%%%%"), ACCEPT, CANCEL, function()
      if AkcHouse.Shopping.ListManager:GetIndexForName(list:GetName()) ~= nil then
        AkcHouse.Shopping.ListManager:Delete(list:GetName())
      end
    end)
  end)

  self.ListsContainer:SetOnListItemDrag(function(list, oldIndex, newIndex)
    if oldIndex ~= newIndex then
      local old = list:GetItemByIndex(oldIndex)
      list:DeleteItem(oldIndex)
      list:InsertItem(old, newIndex)
    end
  end)
end

function AkcHouseShoppingTabFrameMixin:SetupRecentsContainer()
  self.RecentsContainer:SetOnSearchRecent(function(searchTerm)
    self.singleSearch = true
    self:DoSearch({searchTerm})
    self.SearchOptions:SetSearchTerm(searchTerm)
    self.RecentsContainer:TemporarilySelectSearchTerm(searchTerm)
  end)
  self.RecentsContainer:SetOnDeleteRecent(function(searchTerm)
    AkcHouse.Shopping.Recents.DeleteEntry(searchTerm)
  end)
  self.RecentsContainer:SetOnCopyRecent(function(searchTerm)
    local list = self.ListsContainer:GetExpandedList()
    if list == nil then
      AkcHouse.Utilities.Message(AKCHOUSE_L_COPY_NO_LIST_SELECTED)
    else
      list:InsertItem(searchTerm)
      AkcHouse.Utilities.Message(AKCHOUSE_L_COPY_ITEM_ADDED:format(
        GREEN_FONT_COLOR:WrapTextInColorCode(AkcHouse.Search.PrettifySearchString(searchTerm)),
        GREEN_FONT_COLOR:WrapTextInColorCode(list:GetName())
      ))
    end
  end)
end

function AkcHouseShoppingTabFrameMixin:SetupTopSearch()
  self.SearchOptions:SetOnSearch(function(searchTerm)
    if self.searchRunning then
      self:StopSearch()
    elseif searchTerm == "" and self.ListsContainer:GetExpandedList() ~= nil then
      self:DoSearch(self.ListsContainer:GetExpandedList():GetAllItems())
    else
      self.singleSearch = true
      self:DoSearch({searchTerm})
      AkcHouse.Shopping.Recents.Save(searchTerm)
    end
  end)
  self.SearchOptions:SetOnMore(function(searchTerm)
    self:CloseAnyDialogs()
    self.itemDialog:Init(AKCHOUSE_L_LIST_EXTENDED_SEARCH_HEADER, AKCHOUSE_L_SEARCH)
    self.itemDialog:SetOnFinishedClicked(function(searchTerm)
      self.SearchOptions:SetSearchTerm(searchTerm)
      self.singleSearch = true
      self:DoSearch({searchTerm})
      AkcHouse.Shopping.Recents.Save(searchTerm)
    end)

    self.itemDialog:Show()
    self.itemDialog:SetItemString(searchTerm)
  end)
  self.SearchOptions:SetOnAddToList(function(searchTerm)
    self.ListsContainer:GetExpandedList():InsertItem(searchTerm)
    self.ListsContainer:ScrollToListEnd()
  end)
end

function AkcHouseShoppingTabFrameMixin:GetAppropriateListSearchName()
  if self.singleSearch or not self.ListsContainer:GetExpandedList() then
    return AKCHOUSE_L_NO_LIST
  else
    return self.ListsContainer:GetExpandedList():GetName()
  end
end

function AkcHouseShoppingTabFrameMixin:ReceiveEvent(eventName, eventData)
  if eventName == AkcHouse.Shopping.Events.ListImportFinished then
    self.ListsContainer:ExpandList(AkcHouse.Shopping.ListManager:GetByName(eventData))

  elseif eventName == AkcHouse.Shopping.Tab.Events.ListSearchRequested then
    self.ContainerTabs:SetView(AkcHouse.Constants.ShoppingListViews.Lists)
    self.ListsContainer:ExpandList(eventData)
    if not AkcHouse.Config.Get(AkcHouse.Config.Options.AUTO_LIST_SEARCH) then
      self.singleSearch = false
      self:DoSearch(eventData:GetAllItems())
    end

  elseif eventName == AkcHouse.Shopping.Tab.Events.ShowHistoricalPrices then
    self:CloseAnyDialogs()
    self.itemHistoryDialog:Show()

  elseif eventName == AkcHouse.Shopping.Tab.Events.UpdateSearchTerm then
    self.SearchOptions:SetSearchTerm(eventData)

  elseif eventName == AkcHouse.Shopping.Tab.Events.BuyScreenShown then
    self:StopSearch()
  end
end

function AkcHouseShoppingTabFrameMixin:OnEvent(eventName, ...)
  if eventName == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" then
    local showType = ...
    if showType == Enum.PlayerInteractionType.Auctioneer then
      self.shouldDefaultOpenOnShow = true
    end
  elseif eventName == "AUCTION_HOUSE_CLOSED" then
    self.shouldDefaultOpenOnShow = true
  end
end

function AkcHouseShoppingTabFrameMixin:OnShow()
  self.SearchOptions:FocusSearchBox()
  AkcHouse.EventBus:Register(self, EVENTBUS_EVENTS)

  if self.shouldDefaultOpenOnShow then
    self:OpenDefaultList()
    self.shouldDefaultOpenOnShow = false
  end
end

function AkcHouseShoppingTabFrameMixin:OnHide()
  if self.searchRunning then
    self:StopSearch()
  end
  AkcHouse.EventBus:Unregister(self, EVENTBUS_EVENTS)
end

function AkcHouseShoppingTabFrameMixin:ExportCSVClicked()
  self:CloseAnyDialogs()
  self.DataProvider:GetCSV(function(result)
    self.exportCSVDialog:SetExportString(result)
    self.exportCSVDialog:Show()
  end)
end

function AkcHouseShoppingTabFrameMixin:OpenDefaultList()
  local listName = AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_LIST)

  if listName == AkcHouse.Constants.NO_LIST then
    return
  end

  local listIndex = AkcHouse.Shopping.ListManager:GetIndexForName(listName)

  if listIndex ~= nil then
    self.ListsContainer:CollapseList()
    self.ContainerTabs:SetView(AkcHouse.Constants.ShoppingListViews.Lists)
    self.ListsContainer:ExpandList(AkcHouse.Shopping.ListManager:GetByIndex(listIndex))
  end
end
