AkcHouseListExportFrameMixin = {}

function AkcHouseListExportFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseListExportFrameMixin:OnLoad()")

  local view = CreateScrollBoxLinearView()
  view:SetPadding(5, 5, 0, 0, 0)
  view:SetPanExtent(50)
  ScrollUtil.InitScrollBoxWithScrollBar(self.ScrollBox, self.ScrollBar, view);

  self.ScrollBox.ListListingFrame.OnCleaned = function()
    self.ScrollBox:FullUpdate(ScrollBoxConstants.UpdateImmediately);
  end

  self.copyTextDialog = CreateFrame("Frame", nil, self:GetParent(), "AkcHouseExportTextFrame")
  self.copyTextDialog:SetPoint("CENTER")

  if self:GetParent().dialogs then
    table.insert(self:GetParent().dialogs, self.copyTextDialog)
  end

  self.checkBoxPool = CreateFramePool("Frame", self.ScrollBox.ListListingFrame, "AkcHouseConfigurationCheckbox")
end

function AkcHouseListExportFrameMixin:OnShow()
  AkcHouse.Debug.Message("AkcHouseListExportFrameMixin:OnShow()")

  AkcHouse.EventBus:Register(self, { AkcHouse.Shopping.Events.ListMetaChange })

  self:RefreshLists()

  AkcHouse.EventBus
    :RegisterSource(self, "lists export dialog 1")
    :Fire(self, AkcHouse.Shopping.Tab.Events.DialogOpened)
    :UnregisterSource(self)
end

function AkcHouseListExportFrameMixin:OnHide()
  self:Hide()

  AkcHouse.EventBus:Unregister(self, { AkcHouse.Shopping.Events.ListMetaChange })

  AkcHouse.EventBus
    :RegisterSource(self, "lists export dialog 1")
    :Fire(self, AkcHouse.Shopping.Tab.Events.DialogClosed)
    :UnregisterSource(self)
end

function AkcHouseListExportFrameMixin:ReceiveEvent(eventName, listName)
  if eventName == AkcHouse.Shopping.Events.ListMetaChange then
    if self:IsShown() then
      self:RefreshLists()
    end
  end
end

function AkcHouseListExportFrameMixin:RefreshLists()
  AkcHouse.Debug.Message("AkcHouseListExportFrameMixin:RefreshLists()")
  self.checkBoxPool:ReleaseAll()

  for index = 1, AkcHouse.Shopping.ListManager:GetCount() do
    local list = AkcHouse.Shopping.ListManager:GetByIndex(index)
    local checkBox = self.checkBoxPool:Acquire()
    checkBox:SetText(list:GetName())
    checkBox:SetHeight(25)
    checkBox:SetPoint("TOPRIGHT", self.ScrollBox.ListListingFrame, "TOPRIGHT", 0, -(checkBox:GetHeight()) * (index - 1))
    checkBox:SetPoint("TOPLEFT", self.ScrollBox.ListListingFrame, "TOPLEFT", 0, -(checkBox:GetHeight()) * (index - 1))
    checkBox:Show()
  end

  self.ScrollBox.ListListingFrame:MarkDirty()
end

function AkcHouseListExportFrameMixin:OnCloseDialogClicked()
  self:Hide()
end

function AkcHouseListExportFrameMixin:OnSelectAllClicked()
  for checkbox in self.checkBoxPool:EnumerateActive() do
    checkbox:SetChecked(true)
  end
end

function AkcHouseListExportFrameMixin:OnUnselectAllClicked()
  for checkbox in self.checkBoxPool:EnumerateActive() do
    checkbox:SetChecked(false)
  end
end

function AkcHouseListExportFrameMixin:OnExportClicked()
  local exportString = ""

  for checkbox in self.checkBoxPool:EnumerateActive() do
    if checkbox:GetChecked() then
      exportString = exportString .. AkcHouse.Shopping.Lists.GetBatchExportString(checkbox:GetText()) .. "\n"
    end
  end

    self:Hide()
    self.copyTextDialog:SetExportString(exportString)
    self.copyTextDialog:Show()

end
