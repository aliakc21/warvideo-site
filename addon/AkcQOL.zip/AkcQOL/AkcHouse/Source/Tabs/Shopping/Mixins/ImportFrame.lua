AkcHouseListImportFrameMixin = {}

function AkcHouseListImportFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseListImportFrameMixin:OnLoad()")

  ScrollUtil.RegisterScrollBoxWithScrollBar(self.EditBoxContainer:GetScrollBox(), self.ScrollBar)
  self.EditBoxContainer:GetScrollBox():GetView():SetPanExtent(50)
end

function AkcHouseListImportFrameMixin:OnShow()
  AkcHouse.Debug.Message("AkcHouseListImportFrameMixin:OnShow()")

  self.EditBoxContainer:GetEditBox():SetFocus()

  AkcHouse.EventBus
    :RegisterSource(self, "lists import dialog")
    :Fire(self, AkcHouse.Shopping.Tab.Events.DialogOpened)
    :UnregisterSource(self)
end

function AkcHouseListImportFrameMixin:OnHide()
  self.EditBoxContainer:GetEditBox():SetText("")
  self:Hide()
  AkcHouse.EventBus
    :RegisterSource(self, "lists import dialog")
    :Fire(self, AkcHouse.Shopping.Tab.Events.DialogClosed)
    :UnregisterSource(self)
end

function AkcHouseListImportFrameMixin:ReceiveEvent(eventName, eventData)
  if eventName == AkcHouse.Shopping.Events.ListImportFinished then
    AkcHouse.EventBus:Unregister(self, { AkcHouse.Shopping.Events.ListImportFinished })
    AkcHouse.EventBus
      :RegisterSource(self, "lists import dialog")
      :Fire(self, AkcHouse.Shopping.Tab.Events.ListCreated, AkcHouse.Shopping.ListManager:GetByName(eventData))
      :UnregisterSource(self)
  end
end

function AkcHouseListImportFrameMixin:OnCloseDialogClicked()
  self:Hide()
end

function AkcHouseListImportFrameMixin:OnImportClicked()

  AkcHouse.EventBus:Register(self, { AkcHouse.Shopping.Events.ListImportFinished })

  local importString = self.EditBoxContainer:GetEditBox():GetText()

  local waiting = true
  if string.match(importString, "%^") then
    AkcHouse.Debug.Message("Import shopping list with 8.3+ format")
    AkcHouse.Shopping.Lists.BatchImportFromString(importString)
  elseif string.match(importString, "%*") then
    AkcHouse.Debug.Message("Import shopping list from old format")
    AkcHouse.Shopping.Lists.OldBatchImportFromString(importString)
  elseif string.match(importString, "%,") then
    AkcHouse.Debug.Message("Import shopping list from TSM group")
    AkcHouse.Shopping.Lists.TSMImportFromString(importString)
  else
    waiting = false
  end

  if not waiting then
    AkcHouse.EventBus:Unregister(self, { AkcHouse.Shopping.Events.ListImportFinished })
  end

  self:Hide()
end
