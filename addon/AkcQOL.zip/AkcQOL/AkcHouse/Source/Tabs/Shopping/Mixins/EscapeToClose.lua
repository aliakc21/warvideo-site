AkcHouseEscapeToCloseMixin = {}

function AkcHouseEscapeToCloseMixin:OnKeyDown(key)
  self:SetPropagateKeyboardInput(key ~= "ESCAPE")
end

function AkcHouseEscapeToCloseMixin:OnKeyUp(key)
  AkcHouse.Debug.Message("AkcHouseEscapeToCloseMixin:OnKeyUp()", key)

  if key == "ESCAPE" then
    self:Hide()
  end
end
