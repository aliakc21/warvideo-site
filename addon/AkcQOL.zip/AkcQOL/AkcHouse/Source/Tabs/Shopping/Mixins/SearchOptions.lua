AkcHouseShoppingTabSearchOptionsMixin = {}

function AkcHouseShoppingTabSearchOptionsMixin:OnLoad()
  self.lastSearchTerm = ""

  self.AddToListButton:Disable()

  self.AddToListButton:SetScript("OnClick", function()
    if self.onAddToList then
      self.onAddToList(self:GetSearchTerm())
    end
  end)

  self.SearchButton:SetScript("OnClick", function()
    if self.onSearch then
      self.onSearch(self:GetSearchTerm())
    end
  end)

  self.MoreButton:SetScript("OnClick", function()
    if self.onMore then
      self.onMore(self:GetSearchTerm())
    end
  end)

  AkcHouse.EventBus:Register(self, {
    AkcHouse.Shopping.Tab.Events.SearchStart,
    AkcHouse.Shopping.Tab.Events.SearchEnd,
  })

  self.SearchString:SetScript("OnTextChanged", function(self, isUserInput)
    if isUserInput and not self:IsInIMECompositionMode() then
      local current = self:GetText():lower()
      if current == "" or (self.prevCurrent ~= nil and #self.prevCurrent >= #current) then
        self.prevCurrent = current
        return
      end
      self.prevCurrent = current

      local function CompareSearch(toCompare)
        if toCompare:lower():sub(1, #current) == current then
          local split = AkcHouse.Search.SplitAdvancedSearch(toCompare)
          local searchString = split.searchString
          if split.isExact then
            searchString = "\"" .. searchString .. "\""
          end
          self:SetText(searchString)
          self:SetCursorPosition(#current)
          self:HighlightText(#current, #searchString)
          return true
        else
          return false
        end
      end

      for _, recent in ipairs(AkcHouse.Shopping.Recents.GetAll()) do
        if CompareSearch(recent) then
          return
        end
      end

      for i = 1, AkcHouse.Shopping.ListManager:GetCount() do
        local list = AkcHouse.Shopping.ListManager:GetByIndex(i)
        for j = 1, list:GetItemCount() do
          local search = list:GetItemByIndex(j)
          if CompareSearch(search) then
            return
          end
        end
      end
    end
  end)
end

function AkcHouseShoppingTabSearchOptionsMixin:ReceiveEvent(eventName, ...)

  if eventName == AkcHouse.Shopping.Tab.Events.SearchStart then
    self.SearchButton:SetText(AKCHOUSE_L_CANCEL)
  elseif eventName == AkcHouse.Shopping.Tab.Events.SearchEnd then
    self.SearchButton:SetText(AKCHOUSE_L_SEARCH)
  end
  DynamicResizeButton_Resize(self.SearchButton)
end

function AkcHouseShoppingTabSearchOptionsMixin:OnListExpanded()
  self.AddToListButton:Enable()
end

function AkcHouseShoppingTabSearchOptionsMixin:OnListCollapsed()
  self.AddToListButton:Disable()
end

function AkcHouseShoppingTabSearchOptionsMixin:SetOnAddToList(func)
  self.onAddToList = func
end

function AkcHouseShoppingTabSearchOptionsMixin:SetOnSearch(func)
  self.onSearch = func
end

function AkcHouseShoppingTabSearchOptionsMixin:SetOnMore(func)
  self.onMore = func
end

local function GetAppropriateText(searchTerm)
  local search = AkcHouse.Search.SplitAdvancedSearch(searchTerm)
  local newSearch = search.searchString
  for key, value in pairs(search) do
    if key == "isExact" then
      if value then
        newSearch = "\"" .. newSearch .. "\""
      end
    elseif key == "categoryKey" then
      if value ~= "" then
        return AKCHOUSE_L_EXTENDED_SEARCH_ACTIVE_TEXT
      end
    elseif key ~= "searchString" then
      return AKCHOUSE_L_EXTENDED_SEARCH_ACTIVE_TEXT
    end
  end
  return newSearch
end

function AkcHouseShoppingTabSearchOptionsMixin:SetSearchTerm(searchTerm)
  self.lastSearchTerm = searchTerm
  self.SearchString:SetText(GetAppropriateText(searchTerm))
end

function AkcHouseShoppingTabSearchOptionsMixin:GetSearchTerm()
  local text = self.SearchString:GetText()

  if text == AKCHOUSE_L_EXTENDED_SEARCH_ACTIVE_TEXT then
    return self.lastSearchTerm
  else
    return text
  end
end

function AkcHouseShoppingTabSearchOptionsMixin:FocusSearchBox()
  self.SearchString:SetFocus()
end
