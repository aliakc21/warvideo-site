AkcHouseBagUseMixin = {}
function AkcHouseBagUseMixin:OnLoad()
  self:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_SHOW")

  AkcHouse.EventBus:RegisterSource(self, "AkcHouseBagUseMixin")
  self.View.rowWidth = math.ceil(5 * 42 / AkcHouse.Config.Get(AkcHouse.Config.Options.SELLING_ICON_SIZE))
  self.awaitingCompletion = true

  AkcHouse.EventBus:Register(self, {
    AkcHouse.Selling.Events.BagItemRequest,
    AkcHouse.Selling.Events.BagItemClicked,
  })
end

function AkcHouseBagUseMixin:OnShow()
  AkcHouse.Groups.CallbackRegistry:RegisterCallback("BagUse.BagItemClicked", self.BagItemClicked, self)
  AkcHouse.Groups.CallbackRegistry:RegisterCallback("BagUse.AddToDefaultGroup", self.AddToDefaultGroup, self)

  AkcHouse.Groups.CallbackRegistry:RegisterCallback("ViewComplete", function(_, listsCached)
    self.awaitingCompletion = false
    if self.pendingKey then
      self:ReturnItem(self.pendingKey)
      self.pendingKey = nil
    end
  end, self)
  AkcHouse.Groups.CallbackRegistry:TriggerEvent("BagCacheOn")
end

function AkcHouseBagUseMixin:OnHide()
  self.View:SetSelected(nil)
  AkcHouse.Groups.CallbackRegistry:UnregisterCallback("BagUse.BagItemClicked", self)
  AkcHouse.Groups.CallbackRegistry:UnregisterCallback("BagUse.AddToDefaultGroup", self)
  AkcHouse.Groups.CallbackRegistry:UnregisterCallback("BagUse.RemoveFromDefaultGroup", self)
  AkcHouse.Groups.CallbackRegistry:UnregisterCallback("ViewComplete", self)
  AkcHouse.Groups.CallbackRegistry:TriggerEvent("BagCacheOff")
  self.awaitingCompletion = true
end

function AkcHouseBagUseMixin:ReturnItem(key)
  local button = (self.View.itemMap[key.keyName] and self.View.itemMap[key.keyName][key.sortKey])
  if not button then
    AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.ClearBagItem)
  else
    button:Click()
  end
end

function AkcHouseBagUseMixin:ReceiveEvent(eventName, info, ...)
  if eventName == AkcHouse.Selling.Events.BagItemRequest then
    if self.awaitingCompletion then
      self.pendingKey = info
    else
      self:ReturnItem(info)
    end
  elseif eventName == AkcHouse.Selling.Events.BagItemClicked then
    if self:IsVisible() then
      self.View:SetSelected(info.key)
      self.View:ScrollToSelected()
    end
  elseif eventName == AkcHouse.Selling.Events.BagItemClear then
    self.View:SetSelected(nil)
  end
end

function AkcHouseBagUseMixin:BagItemClicked(button, mouseButton)
  if mouseButton == "LeftButton" then
    local postingInfo = AkcHouse.Groups.Utilities.ToPostingItem(button.itemInfo)
    postingInfo.nextItem = button.nextItem
    postingInfo.prevItem = button.prevItem
    postingInfo.key = button.key
    postingInfo.sortKey = button.itemInfo.sortKey
    AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.BagItemClicked, postingInfo)
  elseif mouseButton == "RightButton" then
    local defaultName = AkcHouse.Groups.GetGroupNameByIndex(1)
    local isInDefaultGroup = self.View.itemMap[defaultName][button.itemInfo.sortKey] ~= nil
    local options = {}
    local defaultPrintName = _G["AKCHOUSE_L_" .. defaultName] or defaultName
    MenuUtil.CreateContextMenu(self, function(_, rootDescription)
      if isInDefaultGroup then
        rootDescription:CreateButton(AKCHOUSE_L_REMOVE_FROM_X:format(defaultPrintName), function() self:RemoveFromDefaultGroup(button) end)
      else
        rootDescription:CreateButton(AKCHOUSE_L_ADD_TO_X:format(defaultPrintName), function() self:AddToDefaultGroup(button) end)
      end
      if not button.itemInfo.isCustom then
        if not self.View.hiddenItems[button.itemInfo.sortKey] then
          rootDescription:CreateButton(AKCHOUSE_L_HIDE, function() self:HideItem(button) end)
        else
          rootDescription:CreateButton(AKCHOUSE_L_UNHIDE, function() self:UnhideItem(button) end)
        end
        if next(self.View.hiddenItems) == nil then
          rootDescription:CreateTitle(GRAY_FONT_COLOR:WrapTextInColorCode(AKCHOUSE_L_UNHIDE_ALL))
        else
          rootDescription:CreateButton(AKCHOUSE_L_UNHIDE_ALL, function() self:UnhideAll() end)
        end
      end
    end)
  end
end

function AkcHouseBagUseMixin:AddToDefaultGroup(button)
  local defaultName = AkcHouse.Groups.GetGroupNameByIndex(1)
  local defaultList = AkcHouse.Groups.GetGroupList(defaultName)
  if self.View.itemMap[defaultName][button.itemInfo.sortKey] == nil then
    table.insert(defaultList, button.itemInfo.itemLink)
    AkcHouse.Groups.CallbackRegistry:TriggerEvent("Customise.EditMade")
  end
end

function AkcHouseBagUseMixin:RemoveFromDefaultGroup(button)
  local defaultName = AkcHouse.Groups.GetGroupNameByIndex(1)
  local defaultList = AkcHouse.Groups.GetGroupList(defaultName)
  local info = self.View.itemMap[defaultName][button.itemInfo.sortKey].itemInfo
  for index, itemLink in ipairs(defaultList) do
    local sortKey = AkcHouseBagCacheFrame:GetByLinkInstant(itemLink, info.auctionable).sortKey
    if sortKey == info.sortKey then
      table.remove(defaultList, index)
      AkcHouse.Groups.CallbackRegistry:TriggerEvent("Customise.EditMade")
      break
    end
  end
end

function AkcHouseBagUseMixin:HideItem(button)
  if not self.View.hiddenItems[button.itemInfo.sortKey] then
    local itemLink = button.itemInfo.itemLink
    AkcHouse.Groups.HideItemLink(itemLink)
    AkcHouse.Groups.CallbackRegistry:TriggerEvent("Customise.EditMade")
  end
end

function AkcHouseBagUseMixin:UnhideItem(button)
  local hiddenLink = self.View.hiddenItems[button.itemInfo.sortKey]
  if hiddenLink then
    AkcHouse.Groups.UnhideItemLink(hiddenLink)
    AkcHouse.Groups.CallbackRegistry:TriggerEvent("Customise.EditMade")
  end
end

function AkcHouseBagUseMixin:UnhideAll()
  AkcHouse.Dialogs.ShowConfirm(AKCHOUSE_L_CONFIRM_UNHIDE_ALL, ACCEPT, CANCEL, function()
    AkcHouse.Groups.UnhideAll()
    AkcHouse.Groups.CallbackRegistry:TriggerEvent("Customise.EditMade")
  end)
end
