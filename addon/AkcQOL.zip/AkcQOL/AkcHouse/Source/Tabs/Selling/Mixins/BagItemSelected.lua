AkcHouseBagItemSelectedMixin = CreateFromMixins(AkcHouseGroupsViewItemMixin)

function AkcHouseBagItemSelectedMixin:SetItemInfo(info, ...)
  AkcHouseGroupsViewItemMixin.SetItemInfo(self, info, ...)
  self.IconSelectedHighlight:Hide()
  self.IconBorder:SetShown(info ~= nil)
  self.Icon:SetAlpha(1)

  self.clickEventName = "BagUse.BagItemClicked"
end

local seenBag, seenSlot

function AkcHouseBagItemSelectedMixin:OnClick(button)
  local wasCursorItem = C_Cursor.GetCursorItem()
  self:ProcessCursor(function(check)
    if not check then
      if button == "LeftButton" and not wasCursorItem and self.itemInfo ~= nil and not IsModifiedClick("DRESSUP") and not IsModifiedClick("CHATLINK") then
        self:SearchInShoppingTab()
      else
        AkcHouseGroupsViewItemMixin.OnClick(self, button)
      end
    end
  end)
end

function AkcHouseBagItemSelectedMixin:SearchInShoppingTab()
  AkcHouse.API.v1.MultiSearchExact(AKCHOUSE_L_SELLING_TAB, { self.itemInfo.itemName })
end

function AkcHouseBagItemSelectedMixin:OnReceiveDrag()
  self:ProcessCursor(function() end)
end

function AkcHouseBagItemSelectedMixin:ProcessCursor(callback)
  local location = C_Cursor.GetCursorItem()
  ClearCursor()

  if not location then
    AkcHouse.Debug.Message("nothing on cursor")
    callback(false)
    return
  end

  if not location:HasAnyLocation() then
    AkcHouse.Debug.Message("AkcHouseBagItemSelected", "recovering")
    location = ItemLocation:CreateFromBagAndSlot(seenBag, seenSlot)
  end

  if not C_Item.DoesItemExist(location) then
    AkcHouse.Debug.Message("AkcHouseBagItemSelected", "not exists")
    callback(false)
    return
  end

  local itemLink = C_Item.GetItemLink(location)

  AkcHouse.EventBus:RegisterSource(self, "BagItemSelected")
  AkcHouse.Groups.CallbackRegistry:RegisterCallback("BagCacheUpdated", function(_, cache)
    AkcHouse.Groups.CallbackRegistry:UnregisterCallback("BagCacheUpdated", self)
    AkcHouse.Groups.CallbackRegistry:TriggerEvent("BagCacheOff")
    cache:CacheLinkInfo(itemLink, function()
      local info = AkcHouse.Groups.Utilities.ToPostingItem(AkcHouseBagCacheFrame:GetByLinkInstant(itemLink, true))
      if info.location then
        callback(true)
        info.location = location
        AkcHouse.EventBus:Fire(self, AkcHouse.Selling.Events.BagItemClicked, info)
      else
        AkcHouse.Selling.ShowCannotSellReason(location)
        callback(false)
      end
    end)
  end, self)
  AkcHouse.Groups.CallbackRegistry:TriggerEvent("BagCacheOn")
end

local function HookForPickup(bag, slot)
  seenBag = bag
  seenSlot = slot
end

if C_Container and C_Container.PickupContainerItem then
  hooksecurefunc(C_Container, "PickupContainerItem", HookForPickup)
end
