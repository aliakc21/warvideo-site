AkcHouseConfigTabMixin = {}

function AkcHouseConfigTabMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigTabMixin:OnLoad()")

  if AkcHouse.Constants.IsLegacyAH then

    self.esES:SetPoint("TOPLEFT", self.deDE, "TOPLEFT", 300, 0)
    self.koKR:SetPoint("TOPLEFT", self.esES, "TOPLEFT", 300, 0)
  else
    self.ruRU:SetPoint("TOPLEFT", self.deDE, "TOPLEFT", 300, 0)
  end
end

function AkcHouseConfigTabMixin:OpenOptions()
  Settings.OpenToCategory(AkcHouse.State.OptionsCategory:GetID())
end
