AkcHouseBagListResultsRowMixin = CreateFromMixins(AkcHouseResultsRowTemplateMixin)

function AkcHouseBagListResultsRowMixin:OnClick(...)
  AkcHouse.Debug.Message("AkcHouseBagListResultsRowMixin:OnClick()")
  AkcHouse.Utilities.TablePrint(self.rowData)

end
