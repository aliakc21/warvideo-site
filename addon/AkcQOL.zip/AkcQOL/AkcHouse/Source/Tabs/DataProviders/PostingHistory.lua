local POSTING_HISTORY_PROVIDER_LAYOUT ={
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_UNIT_PRICE,
    headerParameters = { "price" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "price" }
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_BID_PRICE,
    headerParameters = { "bidPrice" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "bidPrice" },
    defaultHide = AkcHouse.Constants.IsLegacyAH,
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_QUANTITY,
    headerParameters = { "quantity" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "quantity" },
    width = 100
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_DATE,
    headerParameters = { "rawDay" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "date" }
  },
}

AkcHousePostingHistoryProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin)

function AkcHousePostingHistoryProviderMixin:OnLoad()
  AkcHouseDataProviderMixin.OnLoad(self)
end

function AkcHousePostingHistoryProviderMixin:OnShow()
  self:Reset()
end

function AkcHousePostingHistoryProviderMixin:SetItem(dbKey)
  self:Reset()

  self.onSearchStarted()

  local entries = AkcHouse.PostingHistory:GetPriceHistory(dbKey)
  table.sort(entries, function(a, b) return b.rawDay < a.rawDay end)

  self:AppendEntries(entries, true)
end

function AkcHousePostingHistoryProviderMixin:GetTableLayout()
  return POSTING_HISTORY_PROVIDER_LAYOUT
end

function AkcHousePostingHistoryProviderMixin:UniqueKey(entry)
  return tostring(tostring(entry.price) .. tostring(entry.rawDay))
end

local COMPARATORS = {
  price = AkcHouse.Utilities.NumberComparator,
  bidPrice = AkcHouse.Utilities.NumberComparator,
  quantity = AkcHouse.Utilities.NumberComparator,
  rawDay = AkcHouse.Utilities.StringComparator
}

function AkcHousePostingHistoryProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end
