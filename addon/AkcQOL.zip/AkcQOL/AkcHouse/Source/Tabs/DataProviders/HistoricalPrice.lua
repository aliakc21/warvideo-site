local HISTORICAL_PRICE_PROVIDER_LAYOUT ={
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_UNIT_PRICE,
    headerParameters = { "minSeen" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "minSeen" }
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_UPPER_UNIT_PRICE,
    headerParameters = { "maxSeen" },
    cellTemplate = "AkcHousePriceCellTemplate",
    cellParameters = { "maxSeen" },
    defaultHide = true
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_RESULTS_AVAILABLE_COLUMN,
    headerParameters = { "available" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "availableFormatted" },
    width = 100
  },
  {
    headerTemplate = "AkcHouseStringColumnHeaderTemplate",
    headerText = AKCHOUSE_L_DATE,
    headerParameters = { "rawDay" },
    cellTemplate = "AkcHouseStringCellTemplate",
    cellParameters = { "date" }
  },
}

AkcHouseHistoricalPriceProviderMixin = CreateFromMixins(AkcHouseDataProviderMixin)

function AkcHouseHistoricalPriceProviderMixin:OnShow()
  self:Reset()
end

function AkcHouseHistoricalPriceProviderMixin:SetItem(dbKey)
  self:Reset()

  self.onSearchStarted()

  local entries = AkcHouse.Database:GetPriceHistory(dbKey)

  for _, entry in ipairs(entries) do
    if entry.available then
      entry.availableFormatted = FormatLargeNumber(entry.available)
    else
      entry.availableFormatted = ""
    end
  end

  self:AppendEntries(entries, true)
end

function AkcHouseHistoricalPriceProviderMixin:GetTableLayout()
  return HISTORICAL_PRICE_PROVIDER_LAYOUT
end

function AkcHouseHistoricalPriceProviderMixin:UniqueKey(entry)
  return tostring(entry.rawDay)
end

local COMPARATORS = {
  minSeen = AkcHouse.Utilities.NumberComparator,
  maxSeen = AkcHouse.Utilities.NumberComparator,
  available = AkcHouse.Utilities.NumberComparator,
  rawDay = AkcHouse.Utilities.StringComparator
}

function AkcHouseHistoricalPriceProviderMixin:Sort(fieldName, sortDirection)
  local comparator = COMPARATORS[fieldName](sortDirection, fieldName)

  table.sort(self.results, function(left, right)
    return comparator(left, right)
  end)

  self:SetDirty()
end
