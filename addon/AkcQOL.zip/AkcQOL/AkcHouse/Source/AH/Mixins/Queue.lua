AkcHouse.AH.QueueMixin = {}

function AkcHouse.AH.QueueMixin:Init()
  self.queue = {}
  AkcHouse.EventBus:Register(self, {
    AkcHouse.AH.Events.Ready
  })
end

local function Dequeue(self)
  if #self.queue > 0 then
    AkcHouse.AH.Internals.throttling:SearchQueried()
    self.queue[1]()
    table.remove(self.queue, 1)
  end
end

function AkcHouse.AH.QueueMixin:Enqueue(func)
  table.insert(self.queue, func)

  if AkcHouse.AH.Internals.throttling:IsReady() then
    Dequeue(self)
  end
end

function AkcHouse.AH.QueueMixin:Remove(func)
  local index = tIndexOf(self.queue, func)
  if index ~= nil then
    table.remove(self.queue, index)
  end
end

function AkcHouse.AH.QueueMixin:ReceiveEvent(event)
  Dequeue(self)
end
