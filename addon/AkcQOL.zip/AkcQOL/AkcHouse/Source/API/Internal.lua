function AkcHouse.API.ComposeError(callerID, message)
  error(
    "Contact the maintainer of " .. callerID ..
    " to resolve this problem. Details: " .. message
  )
end

function AkcHouse.API.InternalVerifyID(callerID)
  if type(callerID) ~= "string" or callerID == "" then
    error("Invalid callerID. Use the name of your add-on.")
  end
end
