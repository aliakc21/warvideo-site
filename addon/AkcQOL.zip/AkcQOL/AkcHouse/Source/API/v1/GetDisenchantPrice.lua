function AkcHouse.API.v1.GetDisenchantPriceByItemID(callerID, itemID)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemID) ~= "number" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetAuctionPriceByItemID(string, number)"
    )
  end

  local itemInfo = { C_Item.GetItemInfo(itemID) }
  local itemLink = itemInfo[2]

  if itemLink ~= nil then
    return AkcHouse.Enchant.GetDisenchantAuctionPrice(itemLink, itemInfo)
  else
    return nil
  end
end

function AkcHouse.API.v1.GetDisenchantPriceByItemLink(callerID, itemLink)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemLink) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetAuctionPriceByItemLink(string, string)"
    )
  end

  local itemInfo = { C_Item.GetItemInfo(itemLink) }

  if #itemInfo > 0 then
    return AkcHouse.Enchant.GetDisenchantAuctionPrice(itemLink, itemInfo)
  else
    return nil
  end
end
