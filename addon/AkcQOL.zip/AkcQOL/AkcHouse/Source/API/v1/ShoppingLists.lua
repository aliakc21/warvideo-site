
function AkcHouse.API.v1.ConvertToSearchString(callerID, term)
  if not term or not term.searchString or type(term.searchString) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.ConvertToSearchString(table)"
    )
  end
  return AkcHouse.Search.ReconstituteAdvancedSearch(term)
end

function AkcHouse.API.v1.ConvertFromSearchString(callerID, searchString)
  if not searchString or type(searchString) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.ConvertFromSearchString(string)"
    )
  end
  return AkcHouse.Search.SplitAdvancedSearch(searchString)
end

function AkcHouse.API.v1.GetShoppingListItems(callerID, shoppingListName)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(shoppingListName) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetShoppingListItems(string, string)"
    )
  end

  local listIndex = AkcHouse.Shopping.ListManager:GetIndexForName(shoppingListName)

  if not listIndex then
    AkcHouse.API.ComposeError(
      callerID,
      "AkcHouse.API.v1.GetShoppingListItems: List does not exist: " .. tostring(shoppingListName)
    )
  end

  local shoppingList = AkcHouse.Shopping.ListManager:GetByIndex(listIndex)

  return shoppingList:GetAllItems()
end

function AkcHouse.API.v1.CreateShoppingList(callerID, name, searchStrings)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(name) ~= "string" or type(searchStrings) ~= "table" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.CreateShoppingList(string, string, string[])"
    )
  end

  local listExists = AkcHouse.Shopping.ListManager:GetIndexForName(name)
  if listExists then
      AkcHouse.Shopping.ListManager:Delete(name)
  end

  AkcHouse.Shopping.ListManager:Create(name)
  local list = AkcHouse.Shopping.ListManager:GetByName(name)
  list:AppendItems(searchStrings)

  AkcHouse.EventBus
    :RegisterSource(AkcHouse.API.v1.CreateShoppingList, "AkcHouse.API.v1.CreateShoppingList")
    :Fire(AkcHouse.API.v1.CreateShoppingList, AkcHouse.Shopping.Events.ListImportFinished, name)
end

function AkcHouse.API.v1.DeleteShoppingListItem(callerID, shoppingListName, itemSearchString)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(shoppingListName) ~= "string" or type(itemSearchString) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.DeleteShoppingListItem(string, string, string)"
    )
  end

  local listIndex = AkcHouse.Shopping.ListManager:GetIndexForName(shoppingListName)
  if not listIndex then
    AkcHouse.API.ComposeError(
      callerID,
      "AkcHouse.API.v1.DeleteShoppingListItem ShoppingList does not exist: " .. tostring(shoppingListName)
    )
  end

  local shoppingList = AkcHouse.Shopping.ListManager:GetByIndex(listIndex)

  local itemIndex = shoppingList:GetIndexForItem(itemSearchString)
  if itemIndex then
    shoppingList:DeleteItem(itemIndex)
  end
end

function AkcHouse.API.v1.AlterShoppingListItem(callerID, shoppingListName, oldItemSearchString, newItemSearchString)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(shoppingListName) ~= "string" or type(oldItemSearchString) ~= "string" or type(newItemSearchString) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.AlterShoppingListItem(string, string, string, string)"
    )
  end

  local listIndex = AkcHouse.Shopping.ListManager:GetIndexForName(shoppingListName)
  if not listIndex then
    AkcHouse.API.ComposeError(
      callerID,
      "AkcHouse.API.v1.AlterShoppingListItem ShoppingList does not exist: " .. tostring(shoppingListName)
    )
  end

  local shoppingList = AkcHouse.Shopping.ListManager:GetByIndex(listIndex)

  local oldItemIndex = shoppingList:GetIndexForItem(oldItemSearchString)
  if oldItemIndex then
    shoppingList:AlterItem(oldItemIndex, newItemSearchString)
  else
    AkcHouse.API.ComposeError(
        callerID,
        "Error in AkcHouse.API.v1.AlterShoppingListItem: Could not find item in shopping list:\n" .. tostring(oldItemSearchString)
        )
  end
end

function AkcHouse.API.v1.ShoppingListAPITests()
  local callerID = "APITest"
  local shoppingListName = "APITestShoppingList"
  local creationTerms = {
    {
        searchString="Draconium Ore",
        isExact=true,
        categoryKey="",
        tier=2,
        quantity=15,
    },
    {
        searchString="Serevite Ore",
        isExact=true,
        categoryKey="",
        tier=3,
        quantity=10,
    }
  }
  local searchStrings = {}
  for _, term in ipairs(creationTerms) do
    table.insert(searchStrings, AkcHouse.API.v1.ConvertToSearchString(callerID, term))
  end

  local s1, e1 = pcall(AkcHouse.API.v1.CreateShoppingList, callerID, shoppingListName, searchStrings)
  assert(s1, "CreateShoppingList failed: " .. tostring(e1))

  local s2, items = pcall(AkcHouse.API.v1.GetShoppingListItems, callerID, shoppingListName)
  assert(s2, "GetShoppingListItems failed: " .. tostring(items))

  assert(items[1] == '"Draconium Ore";;;;;;;;;;;2;;15', "Shopping List Creation failed")
  assert(items[2] == '"Serevite Ore";;;;;;;;;;;3;;10', "Shopping List Creation failed")

  local s3, e3 = pcall(AkcHouse.API.v1.DeleteShoppingListItem, callerID, shoppingListName, searchStrings[1])

  assert(s3, "DeleteShoppingListItem failed: " .. tostring(e3))

  items = AkcHouse.API.v1.GetShoppingListItems(callerID, shoppingListName)

  assert(items[1] == '"Serevite Ore";;;;;;;;;;;3;;10', "DeleteShoppingListItem failed")
  assert(#items < 2, "DeleteShoppingListItem failed")

  local s4, e4 = pcall(AkcHouse.API.v1.AlterShoppingListItem, callerID, shoppingListName,
  AkcHouse.API.v1.ConvertToSearchString(callerID, {
        searchString="Serevite Ore",
        isExact=true,
        tier=3,
        quantity=10,
  }), AkcHouse.API.v1.ConvertToSearchString(callerID, {
        searchString="Draconium Ore",
        isExact=true,
        tier=2,
        quantity=5,
  }))
  assert(s4, "AlterShoppingListItem failed: " .. tostring(e4))

  items = AkcHouse.API.v1.GetShoppingListItems(callerID, shoppingListName)

  assert(items[1] == '"Draconium Ore";;;;;;;;;;;2;;5', "AlterShoppingListItem failed")
  assert(#items <  2, "AlterShoppingListItem failed")

  print("ShoppingListAPITests Successful")
end
