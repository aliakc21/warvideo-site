function AkcHouse.API.v1.GetAuctionPriceByItemID(callerID, itemID)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemID) ~= "number" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetAuctionPriceByItemID(string, number)"
    )
  end

  if AkcHouse.Database == nil then
    return nil
  end

  return AkcHouse.Database:GetPrice(tostring(itemID))
end

function AkcHouse.API.v1.GetAuctionPriceByItemLink(callerID, itemLink)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemLink) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetAuctionPriceByItemLink(string, string)"
    )
  end

  if AkcHouse.Database == nil then
    return nil
  end

  local dbKeys = nil

  AkcHouse.Utilities.DBKeyFromLink(itemLink, function(dbKeysCallback)
    dbKeys = dbKeysCallback
  end)

  if dbKeys then
    return AkcHouse.Database:GetFirstPrice(dbKeys)
  else
    return AkcHouse.Database:GetPrice(
      AkcHouse.Utilities.BasicDBKeyFromLink(itemLink)
    )
  end
end
