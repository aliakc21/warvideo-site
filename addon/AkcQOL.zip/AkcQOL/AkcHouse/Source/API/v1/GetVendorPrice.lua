function AkcHouse.API.v1.GetVendorPriceByItemID(callerID, itemID)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemID) ~= "number" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetVendorPriceByItemID(string, number)"
    )
  end

  return AKCHOUSE_VENDOR_PRICE_CACHE[tostring(itemID)]
end

function AkcHouse.API.v1.GetVendorPriceByItemLink(callerID, itemLink)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemLink) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetVendorPriceByItemLink(string, string)"
    )
  end

  local dbKeys = nil

  AkcHouse.Utilities.DBKeyFromLink(itemLink, function(dbKeysCallback)
    dbKeys = dbKeysCallback
  end)

  if dbKeys then
    for _, key in ipairs(dbKeys) do
      if AKCHOUSE_VENDOR_PRICE_CACHE[key] then
        return AKCHOUSE_VENDOR_PRICE_CACHE[key]
      end
    end
  else
    return AKCHOUSE_VENDOR_PRICE_CACHE[AkcHouse.Utilities.BasicDBKeyFromLink(itemLink)]
  end
end
