function AkcHouse.API.v1.IsAuctionDataExactByItemID(callerID, itemID)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemID) ~= "number" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.IsAuctionDataExactByItemID(string, number)"
    )
  end

  if AkcHouse.Database == nil then
    return nil
  end

  return AkcHouse.Database:GetPrice(tostring(itemID)) ~= nil
end

function AkcHouse.API.v1.IsAuctionDataExactByItemLink(callerID, itemLink)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemLink) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.IsAuctionDataExactByItemLink(string, string)"
    )
  end

  if AkcHouse.Database == nil then
    return false
  end

  local dbKeys = nil

  AkcHouse.Utilities.DBKeyFromLink(itemLink, function(dbKeysCallback)
    dbKeys = dbKeysCallback
  end)

  if dbKeys then
    if #dbKeys > 2 then
      return AkcHouse.Database:GetPrice(dbKeys[1]) ~= nil or AkcHouse.Database:GetPrice(dbKeys[2]) ~= nil
    else
      return AkcHouse.Database:GetPrice(dbKeys[1]) ~= nil
    end
  else
    return AkcHouse.Database:GetPrice(
      AkcHouse.Utilities.BasicDBKeyFromLink(itemLink)
    ) ~= nil
  end
end
