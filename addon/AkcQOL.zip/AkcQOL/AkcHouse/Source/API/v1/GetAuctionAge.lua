
function AkcHouse.API.v1.GetAuctionAgeByItemID(callerID, itemID)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemID) ~= "number" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetAuctionAgeByItemID(string, number)"
    )
  end

  if AkcHouse.Database == nil then
    return nil
  end

  return AkcHouse.Database:GetPriceAge(tostring(itemID))
end

function AkcHouse.API.v1.GetAuctionAgeByItemLink(callerID, itemLink)
  AkcHouse.API.InternalVerifyID(callerID)

  if type(itemLink) ~= "string" then
    AkcHouse.API.ComposeError(
      callerID,
      "Usage AkcHouse.API.v1.GetAuctionAgeByItemLink(string, string)"
    )
  end

  if AkcHouse.Database == nil then
    return nil
  end

  local dbKeys = nil

  AkcHouse.Utilities.DBKeyFromLink(itemLink, function(dbKeysCallback)
    dbKeys = dbKeysCallback
  end)

  if dbKeys then
    if #dbKeys > 2 then
      return AkcHouse.Database:GetPriceAge(dbKeys[1]) or AkcHouse.Database:GetPriceAge(dbKeys[2])
    else
      return AkcHouse.Database:GetPriceAge(dbKeys[1])
    end
  else
    return AkcHouse.Database:GetPriceAge(
      AkcHouse.Utilities.BasicDBKeyFromLink(itemLink)
    )
  end
end
