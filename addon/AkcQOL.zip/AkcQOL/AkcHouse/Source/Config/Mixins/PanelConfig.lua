AkcHousePanelConfigMixin = {}

function AkcHousePanelConfigMixin:SetupPanel()
  self.cancel = function()
    self:Cancel()
  end

  self.okay = function()
    if self.shownSettings then
      self:Save()
    end
  end

  self.shownSettings =  false

  self.OnCommit = self.okay
  self.OnDefault = function() end
  self.OnRefresh = function() end

  if self.parent == nil then
    local category = Settings.RegisterCanvasLayoutCategory(self, self.name)
    Settings.RegisterAddOnCategory(category)
    AkcHouse.State.OptionsCategory = category
  else
    local subcategory = Settings.RegisterCanvasLayoutSubcategory(AkcHouse.State.OptionsCategory, self, self.name)
    Settings.RegisterAddOnCategory(subcategory)
  end
end

function AkcHousePanelConfigMixin:OnShow()
  self:ShowSettings()
  self.shownSettings = true
end

function AkcHousePanelConfigMixin:Cancel()
  AkcHouse.Debug.Message("AkcHousePanelConfigMixin:Cancel() Unimplemented")
end

function AkcHousePanelConfigMixin:Save()
  AkcHouse.Debug.Message("AkcHousePanelConfigMixin:Save() Unimplemented")
end
