AkcHouseConfigProfileFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigProfileFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigProfileFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_PROFILE_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

function AkcHouseConfigProfileFrameMixin:ShowSettings()
  self.ProfileToggle:SetChecked(AkcHouse.Config.IsCharacterConfig())
end

function AkcHouseConfigProfileFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigProfileFrameMixin:Save()")

  AkcHouse.Config.SetCharacterConfig(self.ProfileToggle:GetChecked())
end

function AkcHouseConfigProfileFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigProfileFrameMixin:Cancel()")
end
