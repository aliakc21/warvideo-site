AkcHouseConfigFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigFrameMixin:OnLoad()")

  self.name = "AkcHouse"
  self:SetParent(SettingsPanel)

  self:SetupPanel()
end

function AkcHouseConfigFrameMixin:Show()

end

function AkcHouseConfigFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigFrameMixin:Save()")
end

function AkcHouseConfigFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigFrameMixin:Cancel()")
end
