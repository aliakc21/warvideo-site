AkcHouseConfigAdvancedFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigAdvancedFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigAdvancedFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_ADVANCED_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

function AkcHouseConfigAdvancedFrameMixin:ShowSettings()
  self.ReplicateScan:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.REPLICATE_SCAN))
  self.Debug:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.DEBUG))
end

function AkcHouseConfigAdvancedFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigAdvancedFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.REPLICATE_SCAN, self.ReplicateScan:GetChecked())
  AkcHouse.Config.Set(AkcHouse.Config.Options.DEBUG, self.Debug:GetChecked())
end

function AkcHouseConfigAdvancedFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigAdvancedFrameMixin:Cancel()")
end
