AkcHouseConfigShoppingFrameMixin = CreateFromMixins(AkcHousePanelConfigMixin)

function AkcHouseConfigShoppingFrameMixin:OnLoad()
  AkcHouse.Debug.Message("AkcHouseConfigShoppingFrameMixin:OnLoad()")

  self.name = AKCHOUSE_L_CONFIG_SHOPPING_CATEGORY
  self.parent = "AkcHouse"

  self:SetupPanel()
end

local function GetShoppingListNames()
  local names = {AKCHOUSE_L_NONE}
  local values = {AkcHouse.Constants.NO_LIST}

  if AkcHouse.Shopping.ListManager == nil then
    return names, values
  end

  for index = 1, AkcHouse.Shopping.ListManager:GetCount() do
    local list = AkcHouse.Shopping.ListManager:GetByIndex(index)
    table.insert(names, list:GetName())
    table.insert(values, list:GetName())
  end
  return names, values
end

function AkcHouseConfigShoppingFrameMixin:ShowSettings()
  self.AutoListSearch:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.AUTO_LIST_SEARCH))

  self.DefaultShoppingList:InitAgain(GetShoppingListNames())

  local currentDefault = AkcHouse.Config.Get(AkcHouse.Config.Options.DEFAULT_LIST)
  if AkcHouse.Shopping.ListManager and AkcHouse.Shopping.ListManager:GetIndexForName(currentDefault) == nil then
    currentDefault = ""
  end

  self.DefaultShoppingList:SetValue(currentDefault)

  self.ListMissingTerms:SetChecked(AkcHouse.Config.Get(AkcHouse.Config.Options.SHOPPING_LIST_MISSING_TERMS))
end

function AkcHouseConfigShoppingFrameMixin:Save()
  AkcHouse.Debug.Message("AkcHouseConfigShoppingFrameMixin:Save()")

  AkcHouse.Config.Set(AkcHouse.Config.Options.AUTO_LIST_SEARCH, self.AutoListSearch:GetChecked())

  AkcHouse.Config.Set(AkcHouse.Config.Options.DEFAULT_LIST, self.DefaultShoppingList:GetValue())

  AkcHouse.Config.Set(AkcHouse.Config.Options.SHOPPING_LIST_MISSING_TERMS, self.ListMissingTerms:GetChecked())
end

function AkcHouseConfigShoppingFrameMixin:Cancel()
  AkcHouse.Debug.Message("AkcHouseConfigShoppingFrameMixin:Cancel()")
end
