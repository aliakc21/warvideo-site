AkcHouse.Config.Options = {
  DEBUG = "debug",
  NO_PRICE_DATABASE = "no_price_database",
  MAILBOX_TOOLTIPS = "mailbox_tooltips",
  VENDOR_TOOLTIPS = "vendor_tooltips",
  AUCTION_TOOLTIPS = "auction_tooltips",
  AUCTION_AGE_TOOLTIPS = "auction_age_tooltips",
  AUCTION_MEAN_TOOLTIPS = "auction_mean_tooltips",
  AUCTION_MEAN_DAYS_LIMIT = "auction_mean_days_limit",
  SHIFT_STACK_TOOLTIPS = "shift_stack_tooltips",
  ENCHANT_TOOLTIPS = "enchant_tooltips",
  REPLICATE_SCAN = "replicate_scan_3",
  AUTO_LIST_SEARCH = "auto_list_search",
  DEFAULT_LIST = "default_list_2",

  DEFAULT_TAB = "default_tab",

  AUCTION_CHAT_LOG = "auction_chat_log",
  SELLING_BAG_COLLAPSED = "selling_bag_collapsed",
  SHOW_SELLING_BAG = "show_selling_bag_2",
  SELLING_BAG_SELECT_SHORTCUT = "selling_bag_select_shortcut",
  SELLING_ICON_SIZE = "selling_icon_size_2",
  SELLING_IGNORED_KEYS = "selling_ignored_keys",
  SELLING_FAVOURITE_KEYS = "selling_favourite_keys_2",
  SELLING_AUTO_SELECT_NEXT = "selling_auto_select_next",
  SELLING_MISSING_FAVOURITES = "selling_missing_favourites",
  SELLING_FAVOURITES_SORT_OWNED = "selling_favourites_sort_owned",
  SELLING_RESELECT_ITEM = "selling_reselect_item_2",
  SELLING_SHOULD_RESELECT_ITEM = "selling_should_reselect_item",
  SELLING_POST_SHORTCUT = "selling_post_shortcut",
  SELLING_SKIP_SHORTCUT = "selling_skip_shortcut",
  SELLING_PREV_SHORTCUT = "selling_prev_shortcut",
  SHOW_SELLING_BID_PRICE = "show_selling_bid_price",
  SELLING_CONFIRM_LOW_PRICE = "selling_confirm_low_price",
  SAVE_LAST_DURATION_AS_DEFAULT = "save_last_duration_as_default",

  GEAR_PRICE_MULTIPLIER = "gear_vendor_price_multiplier",

  PRICE_HISTORY_DAYS = "price_history_days",
  POSTING_HISTORY_LENGTH = "auctions_history_length",

  SPLASH_SCREEN_VERSION = "splash_screen_version",
  HIDE_SPLASH_SCREEN = "hide_splash_screen",

  CANCEL_UNDERCUT_SHORTCUT = "cancel_undercut_shortcut",
  UNDERCUT_ITEMS_AHEAD = "undercut_items_ahead",

  COLUMNS_SHOPPING = "columns_shopping",
  COLUMNS_SHOPPING_HISTORICAL_PRICES = "columns_shopping_historical_prices",
  COLUMNS_SELLING_SEARCH = "columns_selling_search_3",
  COLUMNS_HISTORICAL_PRICES = "historical_prices",
  COLUMNS_POSTING_HISTORY = "columns_posting_history",
  COLUMNS_CANCELLING = "columns_cancelling",

  CRAFTING_INFO_SHOW = "crafting_info_show",
  CRAFTING_INFO_SHOW_PROFIT = "crafting_info_show_profit",
  CRAFTING_INFO_SHOW_COST = "crafting_info_show_cost",

  SHOPPING_LIST_MISSING_TERMS = "shopping_list_missing_terms",
  SHOPPING_LAST_CONTAINER_VIEW = "shopping_last_container_view",
}

AkcHouse.Config.SalesTypes = {
  PERCENTAGE = "percentage",
  STATIC = "static"
}

AkcHouse.Config.Shortcuts = {
  LEFT_CLICK = "left click",
  RIGHT_CLICK = "right click",
  ALT_LEFT_CLICK = "alt left click",
  SHIFT_LEFT_CLICK = "shift left click",
  ALT_RIGHT_CLICK = "alt right click",
  SHIFT_RIGHT_CLICK = "shift right click",
  NONE = "none",
}

AkcHouse.Config.Defaults = {
  [AkcHouse.Config.Options.DEBUG] = false,
  [AkcHouse.Config.Options.NO_PRICE_DATABASE] = false,
  [AkcHouse.Config.Options.MAILBOX_TOOLTIPS] = true,
  [AkcHouse.Config.Options.VENDOR_TOOLTIPS] = true,
  [AkcHouse.Config.Options.AUCTION_TOOLTIPS] = true,
  [AkcHouse.Config.Options.AUCTION_AGE_TOOLTIPS] = false,
  [AkcHouse.Config.Options.AUCTION_MEAN_TOOLTIPS] = false,
  [AkcHouse.Config.Options.AUCTION_MEAN_DAYS_LIMIT] = 21,
  [AkcHouse.Config.Options.SHIFT_STACK_TOOLTIPS] = true,
  [AkcHouse.Config.Options.ENCHANT_TOOLTIPS] = false,
  [AkcHouse.Config.Options.REPLICATE_SCAN] = false,
  [AkcHouse.Config.Options.AUTO_LIST_SEARCH] = true,
  [AkcHouse.Config.Options.DEFAULT_LIST] = AkcHouse.Constants.NO_LIST,
  [AkcHouse.Config.Options.AUCTION_CHAT_LOG] = true,
  [AkcHouse.Config.Options.SELLING_BAG_COLLAPSED] = false,
  [AkcHouse.Config.Options.SHOW_SELLING_BAG] = true,
  [AkcHouse.Config.Options.SELLING_BAG_SELECT_SHORTCUT] = AkcHouse.Config.Shortcuts.ALT_LEFT_CLICK,
  [AkcHouse.Config.Options.SELLING_ICON_SIZE] = 42,
  [AkcHouse.Config.Options.SELLING_IGNORED_KEYS] = {},
  [AkcHouse.Config.Options.SELLING_FAVOURITE_KEYS] = {},
  [AkcHouse.Config.Options.SELLING_AUTO_SELECT_NEXT] = false,
  [AkcHouse.Config.Options.SELLING_MISSING_FAVOURITES] = true,
  [AkcHouse.Config.Options.SELLING_FAVOURITES_SORT_OWNED] = false,
  [AkcHouse.Config.Options.SELLING_POST_SHORTCUT] = "SPACE",
  [AkcHouse.Config.Options.SELLING_SKIP_SHORTCUT] = "SHIFT-SPACE",
  [AkcHouse.Config.Options.SELLING_PREV_SHORTCUT] = "BACKSPACE",
  [AkcHouse.Config.Options.SHOW_SELLING_BID_PRICE] = false,
  [AkcHouse.Config.Options.SELLING_CONFIRM_LOW_PRICE] = true,
  [AkcHouse.Config.Options.SAVE_LAST_DURATION_AS_DEFAULT] = false,

  [AkcHouse.Config.Options.GEAR_PRICE_MULTIPLIER] = 0,

  [AkcHouse.Config.Options.PRICE_HISTORY_DAYS] = 21,
  [AkcHouse.Config.Options.POSTING_HISTORY_LENGTH] = 10,

  [AkcHouse.Config.Options.SPLASH_SCREEN_VERSION] = "anything",
  [AkcHouse.Config.Options.HIDE_SPLASH_SCREEN] = false,

  [AkcHouse.Config.Options.CANCEL_UNDERCUT_SHORTCUT] = "SPACE",
  [AkcHouse.Config.Options.UNDERCUT_ITEMS_AHEAD] = 0,

  [AkcHouse.Config.Options.DEFAULT_TAB] = 0,

  [AkcHouse.Config.Options.COLUMNS_SHOPPING] = {},
  [AkcHouse.Config.Options.COLUMNS_SHOPPING_HISTORICAL_PRICES] = {},
  [AkcHouse.Config.Options.COLUMNS_CANCELLING] = {},
  [AkcHouse.Config.Options.COLUMNS_SELLING_SEARCH] = {},
  [AkcHouse.Config.Options.COLUMNS_HISTORICAL_PRICES] = {},
  [AkcHouse.Config.Options.COLUMNS_POSTING_HISTORY] = {},

  [AkcHouse.Config.Options.CRAFTING_INFO_SHOW] = true,
  [AkcHouse.Config.Options.CRAFTING_INFO_SHOW_PROFIT] = true,
  [AkcHouse.Config.Options.CRAFTING_INFO_SHOW_COST] = true,

  [AkcHouse.Config.Options.SHOPPING_LIST_MISSING_TERMS] = false,
  [AkcHouse.Config.Options.SHOPPING_LAST_CONTAINER_VIEW] = AkcHouse.Constants.ShoppingListViews.Lists,
}

function AkcHouse.Config.IsValidOption(name)
  for _, option in pairs(AkcHouse.Config.Options) do
    if option == name then
      return true
    end
  end
  return false
end

function AkcHouse.Config.Create(constant, name, defaultValue)
  AkcHouse.Config.Options[constant] = name

  AkcHouse.Config.Defaults[AkcHouse.Config.Options[constant]] = defaultValue

  if AKCHOUSE_CONFIG ~= nil and AKCHOUSE_CONFIG[name] == nil then
    AKCHOUSE_CONFIG[name] = defaultValue
  end
  if AKCHOUSE_CHARACTER_CONFIG ~= nil and AKCHOUSE_CHARACTER_CONFIG[name] == nil then
    AKCHOUSE_CHARACTER_CONFIG[name] = defaultValue
  end
end

function AkcHouse.Config.Set(name, value)
  if AKCHOUSE_CONFIG == nil then
    error("AKCHOUSE_CONFIG not initialized")
  elseif not AkcHouse.Config.IsValidOption(name) then
    error("Invalid option '" .. name .. "'")
  elseif AKCHOUSE_CHARACTER_CONFIG ~= nil then
    AKCHOUSE_CHARACTER_CONFIG[name] = value
  else
    AKCHOUSE_CONFIG[name] = value
  end
end

function AkcHouse.Config.SetCharacterConfig(enabled)
  if enabled then
    if AKCHOUSE_CHARACTER_CONFIG == nil then
      AKCHOUSE_CHARACTER_CONFIG = {}
    end

    AkcHouse.Config.InitializeCharacterConfig()
  else
    AKCHOUSE_CHARACTER_CONFIG = nil
  end
end

function AkcHouse.Config.IsCharacterConfig()
  return AKCHOUSE_CHARACTER_CONFIG ~= nil
end

function AkcHouse.Config.Reset()
  AKCHOUSE_CONFIG = {}
  AKCHOUSE_CHARACTER_CONFIG = nil
  for option, value in pairs(AkcHouse.Config.Defaults) do
    AKCHOUSE_CONFIG[option] = value
  end
end

function AkcHouse.Config.InitializeData()
  if AKCHOUSE_CONFIG == nil then
    AkcHouse.Config.Reset()
  else
    for option, value in pairs(AkcHouse.Config.Defaults) do
      if AKCHOUSE_CONFIG[option] == nil then
        AkcHouse.Debug.Message("Setting default config for "..option)
        AKCHOUSE_CONFIG[option] = value
      end
    end
    AkcHouse.Config.InitializeCharacterConfig()
  end
end

function AkcHouse.Config.InitializeCharacterConfig()
  if AkcHouse.Config.IsCharacterConfig() then
    for key, value in pairs(AKCHOUSE_CONFIG) do
      if AKCHOUSE_CHARACTER_CONFIG[key] == nil then
        AKCHOUSE_CHARACTER_CONFIG[key] = value
      end
    end
  end
end

function AkcHouse.Config.Get(name)

  if AKCHOUSE_CONFIG == nil then
    return AkcHouse.Config.Defaults[name]
  elseif AKCHOUSE_CHARACTER_CONFIG ~= nil then
    return AKCHOUSE_CHARACTER_CONFIG[name]
  else
    return AKCHOUSE_CONFIG[name]
  end
end
