function AkcHouse.Config.InternalInitializeFrames(templateNames)
  for _, name in ipairs(templateNames) do
    CreateFrame(
      "FRAME",
      "AkcHouseConfig" .. name .. "Frame",
      SettingsPanel,
      "AkcHouseConfig" .. name .. "FrameTemplate")
  end
end
