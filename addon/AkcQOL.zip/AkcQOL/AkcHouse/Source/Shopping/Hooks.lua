local function SearchItem(text)
  if text == nil or AkcHouseShoppingFrame == nil or not AkcHouseShoppingFrame:IsVisible() then
    return false
  end

  C_Timer.After(0, function()
    StackSplitFrame:Hide()
  end)

  local name;
  if ( strfind(text, "battlepet:") ) then
    local petName = strmatch(text, "%[(.+)%]");
    name = petName;
  elseif ( strfind(text, "item:", 1, true) ) then
    name = C_Item.GetItemInfo(text);
  elseif ( strfind(text, "enchant:", 1, true) ) then
    name = AkcHouse.Utilities.GetNameFromLink(text)
  end

  if name == nil then
    name = text
  end

  local searchTerm

  if text:match("enchant:") then
    searchTerm = name
  else
    searchTerm = "\"" .. name .. "\""
  end
  AkcHouseShoppingFrame:DoSearch({searchTerm}, {})
  AkcHouseShoppingFrame.SearchOptions:SetSearchTerm(searchTerm)
  AkcHouse.Shopping.Recents.Save(searchTerm)

  return true
end

local function Callback(text)

  if GetCurrentKeyBoardFocus() == nil or GetCurrentKeyBoardFocus():GetName() == nil then
    SearchItem(text)
  end
end

if ChatFrameUtil and ChatFrameUtil.InsertLink then
  hooksecurefunc(ChatFrameUtil, "InsertLink", Callback)
else
  hooksecurefunc(_G, "ChatEdit_InsertLink", Callback)
end
