function AkcHouse.Shopping.Lists.GetBatchExportString(listName)
  local items = AkcHouse.Shopping.ListManager:GetByName(listName):GetAllItems()

  local result = listName
  for _, item in ipairs(items) do
    result = result .. "^" .. item
  end

  return result
end

function AkcHouse.Shopping.Lists.BatchImportFromString(importString)

  importString = gsub(importString, "%s+\n", "\n")
  importString = gsub(importString, "\n+", "\n")

  local lists = {strsplit("\n", importString)}

  for index, list in ipairs(lists) do
    local name, items = strsplit("^", list, 2)

    if AkcHouse.Shopping.ListManager:GetIndexForName(name) == nil and name ~= nil and name:len() > 0 then
      AkcHouse.Shopping.ListManager:Create(name)
    end

    AkcHouse.Shopping.Lists.OneImportFromString(name, items)

    if name ~= nil and name:len() > 0 then
      AkcHouse.EventBus
        :RegisterSource(AkcHouse.Shopping.Lists.BatchImportFromString, "BatchImportFromString")
        :Fire(AkcHouse.Shopping.Lists.BatchImportFromString, AkcHouse.Shopping.Events.ListImportFinished, name)
        :UnregisterSource(AkcHouse.Shopping.Lists.BatchImportFromString)
    end
  end
end

function AkcHouse.Shopping.Lists.OneImportFromString(listName, importString)
  AkcHouse.Debug.Message("AkcHouse.Shopping.Lists.OneImportFromString()", listName, importString)

  if importString == nil then

    return
  end

  local list = AkcHouse.Shopping.ListManager:GetByName(listName)

  local items = {}
  for _, item in ipairs({strsplit("^", importString)}) do
    table.insert(items, item)
  end
  list:ClearItems()
  list:AppendItems(items)
end

function AkcHouse.Shopping.Lists.OldBatchImportFromString(importString)

  importString = gsub(importString, "%s+\n", "\n")
  importString = gsub(importString, "\n%s+", "\n")

  importString = gsub(importString, "\n\n", "\n")
  importString = gsub(importString, "^\n", "")

  importString = gsub(importString, "*+%s*", "*")

  importString = gsub(importString, "^*", "")

  local lists = {strsplit("*", importString)}

  for index, list in ipairs(lists) do
    local name, items = strsplit("\n", list, 2)

    if AkcHouse.Shopping.ListManager:GetIndexForName(name) == nil then
      AkcHouse.Shopping.ListManager:Create(name)
    end

    AkcHouse.Shopping.Lists.OldOneImportFromString(name, items)

    AkcHouse.EventBus
      :RegisterSource(AkcHouse.Shopping.Lists.OldBatchImportFromString, "OldBatchImportFromString")
      :Fire(AkcHouse.Shopping.Lists.OldBatchImportFromString, AkcHouse.Shopping.Events.ListImportFinished, name)
      :UnregisterSource(AkcHouse.Shopping.Lists.OldBatchImportFromString)
  end
end

function AkcHouse.Shopping.Lists.OldOneImportFromString(listName, importString)
  local list = AkcHouse.Shopping.ListManager:GetByName(listName)

  importString = gsub(importString, "\n$", "")

  list:ClearItems()
  for _, item in ipairs({strsplit("\n", importString)}) do
    list:InsertItem(item)
  end
end

local TSMImportName = AKCHOUSE_L_IMPORTED .. " (" .. AKCHOUSE_L_TEMPORARY_LOWER_CASE .. ")"
local IMPORT_ERROR = "IMPORT ERROR"

function AkcHouse.Shopping.Lists.TSMImportFromString(importString)

  importString = gsub(importString, "%s", "")

  local items = {}

  local function OnFinish()
    if AkcHouse.Shopping.ListManager:GetIndexForName(TSMImportName) ~= nil then
      AkcHouse.Shopping.ListManager:Delete(TSMImportName)
    end

    AkcHouse.Shopping.ListManager:Create(TSMImportName, true)

    local list = AkcHouse.Shopping.ListManager:GetByName(TSMImportName)

    list:ClearItems()
    for _, i in ipairs(items) do
      list:InsertItem(i)
    end

    AkcHouse.EventBus
      :RegisterSource(AkcHouse.Shopping.Lists.TSMImportFromString, "TSMImportFromString")
      :Fire(AkcHouse.Shopping.Lists.TSMImportFromString, AkcHouse.Shopping.Events.ListImportFinished, list:GetName())
      :UnregisterSource(AkcHouse.Shopping.Lists.TSMImportFromString)
  end

  local entries = {}

  for itemType, stringID in importString:gmatch("([ip]?):?(%d+)") do
    table.insert(entries, {itemType = itemType, stringID = stringID})
  end

  local left = #entries

  local function ImportBatch(start, size)
    if start > #entries then

      C_Timer.After(2, function()
        if left > 0 then
          left = 0
          for i = 1, #entries do
            if items[i] == nil then
              items[i] = IMPORT_ERROR
            end
          end
          OnFinish()
        end
      end)
      return
    end

    for index = start, math.min(start+size, #entries) do
      local entry = entries[index]

      local id = tonumber(entry.stringID)

      local item = Item:CreateFromItemID(id)

      if entry.itemType == "p" or item:IsItemEmpty() then
        item = Item:CreateFromItemID(AkcHouse.Constants.PET_CAGE_ID)
      end
      if item:IsItemEmpty() then
        items[index] = IMPORT_ERROR
        left = left - 1

      elseif item:GetItemID() ~= nil then
        item:ContinueOnItemLoad(function()
          items[index] = C_Item.GetItemInfo(id)
          if entry.itemType == "p" or items[index] == nil then
            items[index] = C_PetJournal.GetPetInfoBySpeciesID(id)
            if type(items[index]) ~= "string" then
              items[index] = nil
            end
          end

          if items[index] == nil then
            items[index] = IMPORT_ERROR
          end

          left = left - 1
          if left == 0 then
            OnFinish()
          end
        end)
      else
        left = left - 1
      end
    end

    C_Timer.After(0, function() ImportBatch(start+size, size) end)
  end

  ImportBatch(1, 250)
end
