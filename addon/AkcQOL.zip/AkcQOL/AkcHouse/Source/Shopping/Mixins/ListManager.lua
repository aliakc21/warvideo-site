AkcHouseShoppingListManagerMixin = {}

function AkcHouseShoppingListManagerMixin:Init(getData, setData)
  assert(type(getData) == "function" and type(setData) == "function")
  self.getData = getData
  self.setData = setData

  if self.getData() == nil then
    self.setData({})
  end

  AkcHouse.EventBus:RegisterSource(self, "shopping list manager")

  self:Prune()
  self:Sort()
end

function AkcHouseShoppingListManagerMixin:Create(listName, isTemporary)
  isTemporary = isTemporary or false

  assert(type(listName) == "string")
  assert(type(isTemporary) == "boolean")

  table.insert(self.getData(), {
    name = listName,
    items = {},
    isTemporary = isTemporary,
  })

  self:Sort()

  self:FireMetaChangeEvent(listName)
end

function AkcHouseShoppingListManagerMixin:Sort()
  table.sort(self.getData(), function(left, right)
    local lowerLeft = string.lower(left.name)
    local lowerRight = string.lower(right.name)

    if lowerLeft == lowerRight then
      return left.name < right.name
    else
      return lowerLeft < lowerRight
    end
  end)

  self:FireMetaChangeEvent()
end

function AkcHouseShoppingListManagerMixin:Prune()
  local lists = {}

  for _, list in ipairs(self.getData()) do
    if not list.isTemporary then
      table.insert(lists, list)
    end
  end

  self.setData(lists)

  self:FireMetaChangeEvent()
end

function AkcHouseShoppingListManagerMixin:GetIndexForName(listName)
  for index, list in ipairs(self.getData()) do
    if list.name == listName then
      return index
    end
  end

  return nil
end

function AkcHouseShoppingListManagerMixin:GetCount()
  return #self.getData()
end

function AkcHouseShoppingListManagerMixin:GetByIndex(listIndex)
  local data =  self.getData()[listIndex]
  assert(data, "List index doesn't exist")

  return CreateAndInitFromMixin(AkcHouseShoppingListMixin, data, self)
end

function AkcHouseShoppingListManagerMixin:GetByName(listName)
  return self:GetByIndex(self:GetIndexForName(listName))
end

function AkcHouseShoppingListManagerMixin:Delete(listName)
  local listIndex = self:GetIndexForName(listName)
  assert(listIndex ~= nil, "List doesn't exist")

  table.remove(self.getData(), listIndex)

  self:FireMetaChangeEvent(listName)
end

function AkcHouseShoppingListManagerMixin:GetUnusedName(prefix)
  local currentIndex = 1
  local newName = prefix

  while self:GetIndexForName(newName) ~= nil do
    currentIndex = currentIndex + 1
    newName = prefix .. " " .. currentIndex
  end

  return newName
end

function AkcHouseShoppingListManagerMixin:FireItemChangeEvent(listName)
  AkcHouse.EventBus:Fire(self, AkcHouse.Shopping.Events.ListItemChange, listName)
end

function AkcHouseShoppingListManagerMixin:FireMetaChangeEvent(listName)
  AkcHouse.EventBus:Fire(self, AkcHouse.Shopping.Events.ListMetaChange, listName)
end
