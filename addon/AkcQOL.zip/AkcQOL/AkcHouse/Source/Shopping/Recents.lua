AkcHouse.Shopping.Recents = {}

function AkcHouse.Shopping.Recents.Save(searchText)
  local prevIndex = tIndexOf(AKCHOUSE_RECENT_SEARCHES, searchText)
  if prevIndex ~= nil then
    table.remove(AKCHOUSE_RECENT_SEARCHES, prevIndex)
  end

  table.insert(AKCHOUSE_RECENT_SEARCHES, 1, searchText)

  while #AKCHOUSE_RECENT_SEARCHES > AkcHouse.Constants.RecentsListLimit do
    table.remove(AKCHOUSE_RECENT_SEARCHES)
  end

  AkcHouse.EventBus
    :RegisterSource(AkcHouse.Shopping.Recents.Save, "save recents entry")
    :Fire(AkcHouse.Shopping.Recents.Save, AkcHouse.Shopping.Events.RecentSearchesUpdate)
    :UnregisterSource(AkcHouse.Shopping.Recents.Save)
end

function AkcHouse.Shopping.Recents.DeleteEntry(searchTerm)
  local index = tIndexOf(AKCHOUSE_RECENT_SEARCHES, searchTerm)

  if index ~= nil then
    table.remove(AKCHOUSE_RECENT_SEARCHES, index)
    AkcHouse.EventBus
      :RegisterSource(AkcHouse.Shopping.Recents.DeleteEntry, "delete recents entry")
      :Fire(AkcHouse.Shopping.Recents.DeleteEntry, AkcHouse.Shopping.Events.RecentSearchesUpdate)
      :UnregisterSource(AkcHouse.Shopping.Recents.DeleteEntry)
  end
end

function AkcHouse.Shopping.Recents.GetAll()
  return AKCHOUSE_RECENT_SEARCHES
end
