AkcHouseSearchProviderMixin = {}

function AkcHouseSearchProviderMixin:OnSearchEventReceived(eventName, ...)
end

function AkcHouseSearchProviderMixin:CreateSearchTerm(term)
end

function AkcHouseSearchProviderMixin:GetSearchProvider()
end

function AkcHouseSearchProviderMixin:RegisterProviderEvents()
end

function AkcHouseSearchProviderMixin:UnregisterProviderEvents()
end

function AkcHouseSearchProviderMixin:HasCompleteTermResults()
end

function AkcHouseSearchProviderMixin:GetCurrentEmptyResult()
end

function AkcHouseSearchProviderMixin:RegisterEvents(events)
  AkcHouse.Debug.Message("AkcHouseSearchProviderMixin:RegisterEvents()", events)

  FrameUtil.RegisterFrameForEvents(self, events)
end

function AkcHouseSearchProviderMixin:UnregisterEvents(events)
  AkcHouse.Debug.Message("AkcHouseSearchProviderMixin:UnregisterEvents()", events)

  FrameUtil.UnregisterFrameForEvents(self, events)
end

function AkcHouseSearchProviderMixin:SetTerms(terms, config)
  AkcHouse.Debug.Message("AkcHouseSearchProviderMixin:SetTerms()", terms, config)

  self.terms = terms
  self.config = config or {}
  self.index = 1
end

function AkcHouseSearchProviderMixin:GetCurrentSearchIndex()
  return self.index
end

function AkcHouseSearchProviderMixin:GetSearchTermCount()
  return #self.terms
end

function AkcHouseSearchProviderMixin:HasMoreTerms()
  AkcHouse.Debug.Message("AkcHouseSearchProviderMixin:HasMoreTerms()")

  return
    self.terms ~= nil and
    #self.terms > 0 and
    self.index ~= nil and
    self.index <= #self.terms
end

function AkcHouseSearchProviderMixin:GetNextSearchParameter()
  AkcHouse.Debug.Message("AkcHouseSearchProviderMixin:GetNextSearchParameter()")

  if self:HasMoreTerms() then
    self.index = self.index + 1

    return self:CreateSearchTerm(self.terms[self.index - 1], self.config)
  else
    error("You requested a term that does not exist: " .. (self.index == nil and "nil" or self.index))
  end
end

function AkcHouseSearchProviderMixin:GetCurrentSearchParameter()
  return self.terms[self.index - 1]
end
