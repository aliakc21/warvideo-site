AkcHouseMultiSearchMixin = {}

function AkcHouseMultiSearchMixin:InitSearch(completionCallback, incrementCallback)
  AkcHouse.Debug.Message("AkcHouseMultiSearchMixin:InitSearch()")

  self.complete = true
  self.onSearchComplete = completionCallback or function()
    AkcHouse.Debug.Message("Search completed.")
  end
  self.onNextSearch = incrementCallback or function()
    AkcHouse.Debug.Message("Next search.")
  end
end

function AkcHouseMultiSearchMixin:OnEvent(event, ...)
  self:OnSearchEventReceived(event, ...)
end

function AkcHouseMultiSearchMixin:Search(terms, config)
  AkcHouse.Debug.Message("AkcHouseMultiSearchMixin:Search()", terms)

  self.complete = false
  self.partialResults = {}
  self.fullResults = {}
  self.anyResultsForThisTerm = false

  self:RegisterProviderEvents()

  self:SetTerms(terms, config)
  self:NextSearch()
end

function AkcHouseMultiSearchMixin:AbortSearch()
  self:UnregisterProviderEvents()
  local isComplete = self.complete
  self.complete = true
  if not isComplete then
    self.onSearchComplete(self.fullResults)
  end
end

function AkcHouseMultiSearchMixin:AddResults(results)
  AkcHouse.Debug.Message("AkcHouseSearchProviderMixin:AddResults()")

  if #results > 0 then
    self.anyResultsForThisTerm = true
  end

  for index = 1, #results do
    table.insert(self.partialResults, results[index])
    table.insert(self.fullResults, results[index])
  end

  if self:HasCompleteTermResults() then
    self:NextSearch()
  end
end

function AkcHouseMultiSearchMixin:NoResultsForTermCheck()
  if not AkcHouse.Config.Get(AkcHouse.Config.Options.SHOPPING_LIST_MISSING_TERMS) then
    return
  end

  if self:GetCurrentSearchParameter() and not self.anyResultsForThisTerm then
    local emptyResult = self:GetCurrentEmptyResult()
    table.insert(self.partialResults, emptyResult)
    table.insert(self.fullResults, emptyResult)
  end
end

function AkcHouseMultiSearchMixin:NextSearch()
  if self:HasMoreTerms() then
    self:NoResultsForTermCheck()
    self.anyResultsForThisTerm = false

    self.onNextSearch(
      self:GetCurrentSearchIndex(),
      self:GetSearchTermCount(),
      self.partialResults
    )
    self.partialResults = {}
    self:GetSearchProvider()(self:GetNextSearchParameter())
  else
    AkcHouse.Debug.Message("AkcHouseMultiSearchMixin:NextSearch Complete")

    self:NoResultsForTermCheck()

    self:UnregisterProviderEvents()

    self.complete = true
    self.onSearchComplete(self.fullResults)
  end
end
