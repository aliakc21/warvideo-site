local CategoryLookup = {}

local function SaveCategory(categories, prefix)
  prefix = prefix or ""

  for _, c in ipairs(categories) do
    local currentName = prefix .. c.name
    CategoryLookup[currentName] = c.filters

    if c.subCategories ~= nil then
      SaveCategory(c.subCategories, currentName .. "/")
    end
  end
end

function AkcHouse.Search.InitializeCategories()
  AkcHouse.Search.InitializeOldCategories()

  SaveCategory(AuctionCategories)
end

function AkcHouse.Search.GetItemClassCategories(categoryKey)
  local lookup = CategoryLookup[categoryKey]
  if lookup ~= nil then
    return lookup
  elseif categoryKey ~= "" then

    return AkcHouse.Search.GetItemClassOldCategories(categoryKey)
  end
end
