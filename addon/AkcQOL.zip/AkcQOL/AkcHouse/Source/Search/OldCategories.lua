
local INVENTORY_TYPE_IDS = AkcHouse.Constants.INVENTORY_TYPE_IDS

local OldCategories = {}
local OldCategoryLookup = {}

AkcHouse.Search.OldCategory = {
  classID = 0,
  name = AkcHouse.Constants.CategoryDefault,
  key = 0,
  parentKey = nil,
  category = {},
  subClasses = {}
}

function AkcHouse.Search.OldCategory:new( options )
  options = options or {}
  setmetatable( options, self )
  self.__index = self

  return options
end

local function GenerateArmorInventorySlots(parentKey, parentCategory)
  local inventorySlots = {}
  for index = 1, #INVENTORY_TYPE_IDS do
    local name = C_Item.GetItemInventorySlotInfo(INVENTORY_TYPE_IDS[index])

    local category = {
      classID = parentCategory.classID,
      subClassID = parentCategory.subClassID,
      inventoryType = INVENTORY_TYPE_IDS[index],
    }
    local subSubClass = AkcHouse.Search.OldCategory:new({
      classID = INVENTORY_TYPE_IDS[index],
      name = name,
      key = parentKey .. [[/]] .. name,
      parentKey = parentKey,
      category = { category }
    })

    table.insert( inventorySlots, subSubClass )
  end
  return inventorySlots
end

local function GenerateSubClasses( classID, parentKey )
  local subClassesTable = AkcHouse.AH.GetAuctionItemSubClasses( classID )
  local subClasses = {}

  for index = 1, #subClassesTable do
    local subClassID = subClassesTable[ index ]
    local name = C_Item.GetItemSubClassInfo( classID, subClassID )

    if name then
      local category = { classID = classID, subClassID = subClassID }
      local subClass = AkcHouse.Search.OldCategory:new({
        classID = subClassID,
        name = name,
        key = parentKey .. [[/]] .. name,
        parentKey = parentKey,
        category = { category }
      })

      table.insert( subClasses, subClass )

      if classID == Enum.ItemClass.Armor then
        local inventorySlots = GenerateArmorInventorySlots(subClass.key, category)
        for _, slot in ipairs(inventorySlots) do
          table.insert(subClasses, slot)
        end
      end
    end
  end

  return subClasses
end

function AkcHouse.Search.InitializeOldCategories()
  for _, classID in ipairs( AkcHouse.Groups.Constants.ValidItemClassIDs ) do
    local key = C_Item.GetItemClassInfo( classID )
    local subClasses = GenerateSubClasses( classID, key )
    local category = {classID = classID}

    local categoryCategory = AkcHouse.Search.OldCategory:new({
      classID = classID,
      name = name,
      key = key,
      category = {category},
      subClasses = subClasses
    })

    table.insert( OldCategories, categoryCategory )
  end

  for _, category in ipairs( OldCategories ) do
    OldCategoryLookup[ category.key ] = category

    for i = 1, #category.subClasses do
      local subCategory = category.subClasses[ i ]

      OldCategoryLookup[ subCategory.key ] = subCategory
    end
  end
end

function AkcHouse.Search.GetItemClassOldCategories(categoryKey)
  local lookup = OldCategoryLookup[categoryKey]
  if lookup ~= nil then
    return lookup.category
  end
end
