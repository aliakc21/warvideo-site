AkcHouseDataProviderMixin = {}

function AkcHouseDataProviderMixin:OnLoad()
  self.results = {}
  self.cachedResults = {}
  self.insertedKeys = {}
  self.entriesToProcess = {}
  self.processCountPerUpdate = 200
  self.presetSort = {key = nil, direction = nil}

  self.searchCompleted = false

  self.onEntryProcessed = function(_)
    self:NotifyCacheUsed()
  end
  self.onUpdate = function() end
  self.onSearchStarted = function() end
  self.onSearchEnded = function() end
  self.onPreserveScroll = function() end
  self.onResetScroll = function() end
end

function AkcHouseDataProviderMixin:OnUpdate(elapsed)
  if elapsed >= 0 then
    self:CheckForEntriesToProcess()
  end
end

function AkcHouseDataProviderMixin:Reset()

  self.cachedResults = self.cachedResults or self.results or {}

  self.results = {}
  self.insertedKeys = {}
  self.entriesToProcess = {}
  self.processingIndex = 0

  self.searchCompleted = false
  self:SetDirty()
end

function AkcHouseDataProviderMixin:UniqueKey(entry)
end

function AkcHouseDataProviderMixin:Sort(fieldName, sortDirection)
end

function AkcHouseDataProviderMixin:SetPresetSort(fieldName, sortDirection)
  self.presetSort.key = fieldName
  self.presetSort.direction = sortDirection
end

function AkcHouseDataProviderMixin:ClearSort()
  self:SetPresetSort(nil, nil)
  table.sort(self.results, function(left, right)
    return left.sortingIndex < right.sortingIndex
  end)
  self:SetDirty()
end

function AkcHouseDataProviderMixin:GetTableLayout()
  return {}
end

function AkcHouseDataProviderMixin:GetColumnHideStates()
  return nil
end

function AkcHouseDataProviderMixin:GetRowTemplate()
  return "AkcHouseResultsRowTemplate"
end

function AkcHouseDataProviderMixin:GetEntryAt(index)

  return self.cachedResults[index]
end

function AkcHouseDataProviderMixin:GetCount()
  return #self.cachedResults
end

function AkcHouseDataProviderMixin:SetOnEntryProcessedCallback(onEntryProcessedCallback)
  self.onEntryProcessed = onEntryProcessedCallback
end

function AkcHouseDataProviderMixin:SetOnUpdateCallback(onUpdateCallback)
  self.onUpdate = onUpdateCallback
end

function AkcHouseDataProviderMixin:SetOnSearchStartedCallback(onSearchStartedCallback)
  self.onSearchStarted = onSearchStartedCallback
end

function AkcHouseDataProviderMixin:SetOnSearchEndedCallback(onSearchEndedCallback)
  self.onSearchEnded = onSearchEndedCallback
end

function AkcHouseDataProviderMixin:NotifyCacheUsed()
  self.cacheUsedCount = self.cacheUsedCount + 1
end

function AkcHouseDataProviderMixin:SetDirty()
  self.isDirty = true
end

function AkcHouseDataProviderMixin:SetOnPreserveScrollCallback(onPreserveScrollCallback)
  self.onPreserveScroll = onPreserveScrollCallback
end

function AkcHouseDataProviderMixin:SetOnResetScrollCallback(onResetScrollCallback)
  self.onResetScroll = onResetScrollCallback
end

function AkcHouseDataProviderMixin:AppendEntries(entries, isLastSetOfResults)
  AkcHouse.Debug.Message("AkcHouseDataProviderMixin:AppendEntries()", #entries)

  self.searchCompleted = isLastSetOfResults
  self.announcedCompletion = false

  for _, entry in ipairs(entries) do
    table.insert(self.entriesToProcess, entry)
  end
end

function AkcHouseDataProviderMixin:CheckForEntriesToProcess()
  if #self.entriesToProcess == 0 then
    if self.isDirty then
      self.cachedResults = self.results
      self.onUpdate(self.results)
      self.isDirty = false
    end

    if not self.announcedCompletion and self.searchCompleted then
      self.announcedCompletion = true
      self.onSearchEnded()
    end
    return
  end

  AkcHouse.Debug.Message("AkcHouseDataProviderMixin:CheckForEntriesToProcess()")

  local processCount = 0
  local entry
  local key

  self.cacheUsedCount = 0

  while processCount < self.processCountPerUpdate + self.cacheUsedCount and self.processingIndex < #self.entriesToProcess do
    self.processingIndex = self.processingIndex + 1
    entry = self.entriesToProcess[self.processingIndex]

    key = self:UniqueKey(entry)
    if self.insertedKeys[key] == nil then
      processCount = processCount + 1
      self.insertedKeys[key] = entry
      table.insert(self.results, entry)

      entry.sortingIndex = #self.results

      self.onEntryProcessed(entry)
    end
  end

  if self.presetSort.key ~= nil and self.presetSort.direction ~= nil then
    self:Sort(self.presetSort.key, self.presetSort.direction)
  end

  local resetQueue = false
  if self.processingIndex == #self.entriesToProcess then
    self.entriesToProcess = {}
    self.processingIndex = 0
    resetQueue = true
  end

  self.cachedResults = self.results
  self.onUpdate(self.results)
  self.isDirty = false

  if resetQueue and self.searchCompleted then
    self.onSearchEnded()
    self.announcedCompletion = true
  end
end

local function WrapCSVParameter(parameter)
  if type(parameter) == "string" then
    return "\"" .. string.gsub(parameter, "\"", "") .. "\""
  else
    return tostring(parameter)
  end
end

function AkcHouseDataProviderMixin:GetCSV(callback)
  if self:GetCount() == 0 then
    callback("")
  end

  local csvResult = ""

  local layout = self:GetTableLayout()

  for index, column in ipairs(layout) do
    csvResult = csvResult .. WrapCSVParameter(column.headerText)

    if index ~= #layout then
      csvResult = csvResult ..  ","
    end
  end
  csvResult = csvResult .. "\n"

  local function DoRows(start, finish)
    finish = math.min(finish, self:GetCount())

    local index = start
    while index <= finish do
      local row = self.results[index]
      for column, cell in ipairs(layout) do
        csvResult = csvResult .. WrapCSVParameter(row[cell.headerParameters[1]])

        if column ~= #layout then
          csvResult = csvResult .. ","
        end
      end

      if index ~= self:GetCount() then
        csvResult = csvResult .. "\n"
      end

      index = index + 1
    end

    if finish < self:GetCount() then
      C_Timer.After(0, function()
        DoRows(finish + 1, (finish - start) + finish + 1)
      end)
    else
      callback(csvResult)
    end
  end

  DoRows(1, 50)
end
