function AkcHouse.Components.ReportEnterPressed()
  AkcHouse.EventBus
    :RegisterSource(AkcHouse.Components.ReportEnterPressed, "ReportEnterPressed")
    :Fire(AkcHouse.Components.ReportEnterPressed, AkcHouse.Components.Events.EnterPressed)
    :UnregisterSource(AkcHouse.Components.ReportEnterPressed)
end
