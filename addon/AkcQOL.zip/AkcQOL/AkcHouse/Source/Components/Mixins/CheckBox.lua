AkcHouseConfigCheckboxMixin = {}

function AkcHouseConfigCheckboxMixin:OnLoad()
  if self.labelText ~= nil then
    self.CheckBox.Label:SetText(self.labelText)
  end
end

function AkcHouseConfigCheckboxMixin:SetText(text)
  self.labelText = text
  self.CheckBox.Label:SetText(self.labelText)
end

function AkcHouseConfigCheckboxMixin:GetText()
  return self.CheckBox.Label:GetText()
end

function AkcHouseConfigCheckboxMixin:SetChecked(value)
  self.CheckBox:SetChecked(value)
end

function AkcHouseConfigCheckboxMixin:OnMouseUp()
  self.CheckBox:Click()
end

function AkcHouseConfigCheckboxMixin:OnEnter()
  self.CheckBox:LockHighlight()

  AkcHouseConfigTooltipMixin.OnEnter(self)
end

function AkcHouseConfigCheckboxMixin:OnLeave()
  self.CheckBox:UnlockHighlight()

  AkcHouseConfigTooltipMixin.OnLeave(self)
end

function AkcHouseConfigCheckboxMixin:GetChecked()
  return self.CheckBox:GetChecked()
end
