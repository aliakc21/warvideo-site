AkcHouseConfigurationSubHeadingMixin = {}

function AkcHouseConfigurationSubHeadingMixin:InitializeSubHeading()
  AkcHouse.Debug.Message("AkcHouseConfigurationSubHeadingMixin:InitializeSubHeading()")

  if self.subHeadingText ~= nil then
    self.HeadingText:SetText(self.subHeadingText)
  end
end

function AkcHouseConfigurationSubHeadingMixin:SetText(newHeading)
  self.subHeadingText = newHeading
  self:OnLoad()
end
