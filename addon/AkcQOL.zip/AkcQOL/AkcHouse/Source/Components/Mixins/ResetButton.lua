AkcHouseResetButtonMixin = {}

function AkcHouseResetButtonMixin:OnLoad()
  self.clickCallback = function() end
end

function AkcHouseResetButtonMixin:OnClick()
  self.clickCallback()
end

function AkcHouseResetButtonMixin:SetClickCallback(callback)
  self.clickCallback = callback
end
