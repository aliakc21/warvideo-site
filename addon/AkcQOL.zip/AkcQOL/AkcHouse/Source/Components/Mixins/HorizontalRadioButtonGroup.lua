AkcHouseConfigHorizontalRadioButtonGroupMixin = CreateFromMixins(AkcHouseConfigRadioButtonGroupMixin)

function AkcHouseConfigHorizontalRadioButtonGroupMixin:SetupRadioButtons()
  local children = { self:GetChildren() }
  local size = 0

  for _, child in ipairs(children) do
    if child.isAkcHouseRadio then
      table.insert(self.radioButtons, child)

      child:SetPoint("TOPLEFT", size, -20)
      child.RadioButton.Label:SetPoint("TOPLEFT", 20, -2)

      child.onSelectedCallback = function()
        self:RadioSelected(child)
      end

      size = size + 50
    end
  end

  self:SetSize(size, 48)
end
