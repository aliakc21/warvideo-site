AkcHouseConfigRadioButtonMixin = {}

function AkcHouseConfigRadioButtonMixin:OnLoad()

  self.isAkcHouseRadio = true

  if self.value == nil then
    error("A value is required for the radio button.")
  end

  if self.labelText ~= nil then
    self.RadioButton.Label:SetText(self.labelText)
  end
end

function AkcHouseConfigRadioButtonMixin:OnMouseUp()
  self.RadioButton:Click()
end

function AkcHouseConfigRadioButtonMixin:OnEnter()
  self.RadioButton:LockHighlight()
end

function AkcHouseConfigRadioButtonMixin:OnLeave()
  self.RadioButton:UnlockHighlight()
end

function AkcHouseConfigRadioButtonMixin:SetChecked(value)
  self.RadioButton:SetChecked(value)
end

function AkcHouseConfigRadioButtonMixin:GetChecked()
  return self.RadioButton:GetChecked()
end

function AkcHouseConfigRadioButtonMixin:GetValue()
  return self.value
end

function AkcHouseConfigRadioButtonMixin:OnClick()
  if self.onSelectedCallback ~= nil then
    self.onSelectedCallback()
  end
end
