AkcHouseConfigTextInputMixin = {}

function AkcHouseConfigTextInputMixin:OnLoad()
  AkcHouse.Debug.Message("HERE HERE HERE HERE HERE HERE HERE")
end

function AkcHouseConfigTextInputMixin:OnMouseUp()
  self.InputBox:SetFocus()
end

function AkcHouseConfigTextInputMixin:SetFocus()
  self.InputBox:SetFocus()
end

function AkcHouseConfigTextInputMixin:SetText(value)
  self.InputBox:SetText(value)
  self.InputBox:SetCursorPosition(0)
end

function AkcHouseConfigTextInputMixin:GetText()
  return self.InputBox:GetText()
end
