AkcHouseConfigRadioButtonGroupMixin = {}

function AkcHouseConfigRadioButtonGroupMixin:InitializeRadioButtonGroup()
  AkcHouse.Debug.Message("AkcHouseConfigRadioButtonGroupMixin:InitializeRadioButtonGroup()")

  if self.groupHeadingText ~= nil then
    self.GroupHeading.subHeadingText = self.groupHeadingText
    self.GroupHeading:InitializeSubHeading()
  end

  self.radioButtons = {}
  self:SetupRadioButtons()
  self.radioButtonGroupOnChangeEvent = function() end
  self:Show()
end

function AkcHouseConfigRadioButtonGroupMixin:SetupRadioButtons()
  local children = { self:GetChildren() }
  local size = 0

  for _, child in ipairs(children) do
    if child.isAkcHouseRadio then
      table.insert(self.radioButtons, child)

      child:SetPoint("TOPLEFT", 0, size * -1)
      child.RadioButton.Label:SetPoint("TOPLEFT", 20, -2)

      child.onSelectedCallback = function()
        self:RadioSelected(child)
      end
    end

    size = size + (child:GetHeight() or 20)
  end

  self:SetHeight(size + 8)
end

function AkcHouseConfigRadioButtonGroupMixin:SetSelectedValue(value)
  self.selectedValue = value
  self:Refresh()
end

function AkcHouseConfigRadioButtonGroupMixin:SetOnChange(callback)
  self.radioButtonGroupOnChangeEvent = callback
end

function AkcHouseConfigRadioButtonGroupMixin:RadioSelected(radio)
  self.selectedValue = radio:GetValue()
  self.radioButtonGroupOnChangeEvent(self.selectedValue)

  self:Refresh()
end

function AkcHouseConfigRadioButtonGroupMixin:Refresh()
  AkcHouse.Debug.Message("AkcHouseConfigRadioButtonGroupMixin:Refresh()", self.selectedValue)

  for _, button in ipairs(self.radioButtons) do
    button:SetChecked(button:GetValue() == self.selectedValue)
  end
end

function AkcHouseConfigRadioButtonGroupMixin:GetValue()
  return self.selectedValue
end
