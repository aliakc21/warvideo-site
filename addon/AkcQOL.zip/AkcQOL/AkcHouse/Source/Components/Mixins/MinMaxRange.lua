AkcHouseConfigMinMaxMixin = {}

function AkcHouseConfigMinMaxMixin:OnLoad()
  self.onTabOut = function() end
  self.onEnter = function() end

  if self.titleText ~= nil then
    self.Title:SetText(self.titleText)
  end

  self.ResetButton:SetClickCallback(function()
    self:Reset()
  end)
end

function AkcHouseConfigMinMaxMixin:SetFocus()
  self.MinBox:SetFocus()
end

function AkcHouseConfigMinMaxMixin:SetCallbacks(callbacks)
  self.onTabOut = callbacks.OnTab or function() end
  self.onEnter = callbacks.OnEnter or function() end
end

function AkcHouseConfigMinMaxMixin:OnEnterPressed()
  self.onEnter()
end

function AkcHouseConfigMinMaxMixin:MinTabPressed()
  self.MaxBox:SetFocus()
end

function AkcHouseConfigMinMaxMixin:MaxTabPressed()
  self.onTabOut()
end

function AkcHouseConfigMinMaxMixin:GetMin()
  return self.MinBox:GetNumber()
end

function AkcHouseConfigMinMaxMixin:GetMax()
  return self.MaxBox:GetNumber()
end

function AkcHouseConfigMinMaxMixin:SetMin(value)
  if value == nil then
    self.MinBox:SetText("")
  else
    self.MinBox:SetNumber(value)
  end
end

function AkcHouseConfigMinMaxMixin:SetMax(value)
  if value == nil then
    self.MaxBox:SetText("")
  else
    self.MaxBox:SetNumber(value)
  end
end

function AkcHouseConfigMinMaxMixin:Reset()
  self.MinBox:SetText("")
  self.MaxBox:SetText("")
end
