AkcHouseConfigNumericInputMixin = {}

function AkcHouseConfigNumericInputMixin:OnLoad()
  if self.labelText ~= nil then
    self.InputBox.Label:SetText(self.labelText)
  end
end

function AkcHouseConfigNumericInputMixin:OnMouseUp()
  self.InputBox:SetFocus()
end

function AkcHouseConfigNumericInputMixin:SetFocus()
  self.InputBox:SetFocus()
end

function AkcHouseConfigNumericInputMixin:SetNumber(value)
  self.InputBox:SetNumber(value)
  self.InputBox:SetCursorPosition(0)
end

function AkcHouseConfigNumericInputMixin:GetNumber(value)
  return self.InputBox:GetNumber(value)
end
