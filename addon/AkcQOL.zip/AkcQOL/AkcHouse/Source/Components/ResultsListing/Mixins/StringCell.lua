AkcHouseStringCellTemplateMixin = CreateFromMixins(AkcHouseCellMixin, AkcHouseRetailImportTableBuilderCellMixin)

function AkcHouseStringCellTemplateMixin:Init(columnName)
  self.columnName = columnName

  self.text:SetJustifyH("LEFT")
end

function AkcHouseStringCellTemplateMixin:Populate(rowData, index)
  AkcHouseCellMixin.Populate(self, rowData, index)

  self.text:SetText(rowData[self.columnName])
end

function AkcHouseStringCellTemplateMixin:OnHide()
  self.text:Hide()
end

function AkcHouseStringCellTemplateMixin:OnShow()
  self.text:Show()
end
