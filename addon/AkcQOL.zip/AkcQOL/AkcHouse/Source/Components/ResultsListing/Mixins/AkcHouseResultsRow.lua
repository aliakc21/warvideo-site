AkcHouseResultsRowTemplateMixin = {}

function AkcHouseResultsRowTemplateMixin:OnClick(...)
  AkcHouse.Debug.Message("AkcHouseResultsRowTemplateMixin:OnClick()", ...)
end

function AkcHouseResultsRowTemplateMixin:OnEnter(...)
  self.HighlightTexture:Show()
end

function AkcHouseResultsRowTemplateMixin:OnLeave(...)
  self.HighlightTexture:Hide()
end

function AkcHouseResultsRowTemplateMixin:Populate(rowData, dataIndex)
  self.rowData = rowData
  self.dataIndex = dataIndex
end
