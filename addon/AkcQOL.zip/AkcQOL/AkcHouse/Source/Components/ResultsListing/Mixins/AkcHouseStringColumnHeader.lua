AkcHouseStringColumnHeaderTemplateMixin = CreateFromMixins(AkcHouseRetailImportTableBuilderElementMixin)

function AkcHouseStringColumnHeaderTemplateMixin:Init(name, customiseFunction, sortFunction, clearSortFunction, sortKey, tooltipText)
  self.tooltipText = tooltipText
  self.sortKey = sortKey
  self.customiseFunction = customiseFunction
  self.clearSortFunction = clearSortFunction
  self.sortFunction = sortFunction
  self.sortDirection = nil

  self:SetText(name)
  local fontString = self:GetFontString()
  fontString:SetPoint("RIGHT")
  fontString:SetJustifyH("LEFT")
  fontString:SetMaxLines(1)
end

function AkcHouseStringColumnHeaderTemplateMixin:DoSort()
  if self.sortKey then
    if self.sortDirection == AkcHouse.Constants.SORT.DESCENDING or self.sortDirection == nil then
      self.sortDirection = AkcHouse.Constants.SORT.ASCENDING
    else
      self.sortDirection = AkcHouse.Constants.SORT.DESCENDING
    end

    self.sortFunction(self.sortKey, self.sortDirection)

    if self.sortDirection == AkcHouse.Constants.SORT.DESCENDING then
      self.Arrow:SetTexCoord(0, 1, 1, 0)
    else
      self.Arrow:SetTexCoord(0, 1, 0, 1)
    end

    self.Arrow:Show()
  end

  PlaySound(SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON)
end

function AkcHouseStringColumnHeaderTemplateMixin:OnClick(button, ...)
  if button == "LeftButton" then
    if IsShiftKeyDown() then
      self.clearSortFunction()
    else
      self:DoSort()
    end
  end
end

function AkcHouseStringColumnHeaderTemplateMixin:OnMouseUp(button, ...)

  if button == "RightButton" then
    self.customiseFunction()
  end
end

function AkcHouseStringColumnHeaderTemplateMixin:OnEnter()
  if self.tooltipText then
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip_AddColoredLine(GameTooltip, self.tooltipText, WHITE_FONT_COLOR, true)
    GameTooltip:Show()
  end
end

function AkcHouseStringColumnHeaderTemplateMixin:OnLeave()
  GameTooltip:Hide()
end
