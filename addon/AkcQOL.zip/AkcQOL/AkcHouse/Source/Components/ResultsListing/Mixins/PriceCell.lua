AkcHousePriceCellTemplateMixin = CreateFromMixins(AkcHouseCellMixin, AkcHouseRetailImportTableBuilderCellMixin)

function AkcHousePriceCellTemplateMixin:Init(columnName)
  self.columnName = columnName
end

function AkcHousePriceCellTemplateMixin:Populate(rowData, index)
  AkcHouseCellMixin.Populate(self, rowData, index)

  if rowData[self.columnName] ~= nil then
    self.MoneyDisplay:SetAmount(rowData[self.columnName])
    self.MoneyDisplay:Show()
  else
    self.MoneyDisplay:Hide()
  end
end
