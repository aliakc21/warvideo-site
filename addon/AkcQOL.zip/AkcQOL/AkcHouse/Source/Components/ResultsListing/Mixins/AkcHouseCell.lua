AkcHouseCellMixin = {}

function AkcHouseCellMixin:Populate(rowData, index)
  self.rowData = rowData
  self.index = index
end

function AkcHouseCellMixin:OnEnter()
  if self:GetParent().OnEnter ~= nil then
    self:GetParent():OnEnter()
  end
end

function AkcHouseCellMixin:OnLeave()
  if self:GetParent().OnLeave ~= nil then
    self:GetParent():OnLeave()
  end
end

function AkcHouseCellMixin:OnClick(...)
  if self:GetParent().OnClick ~= nil then
    self:GetParent():OnClick(...)

    AkcHouse.Debug.Message("index", self.index)

  end
end
