
function AkcHouse_EditBox_OnTextChanged(self, ...)

  if string.match(self:GetText(), "[^1234567890.]") == nil and
     string.match(self:GetText(), "[.].*[.]") == nil then
    return
  end

  self:SetText(self.akchousePrevText or "")
end

function AkcHouse_EditBox_OnKeyDown(self, key)
  self.akchousePrevText = self:GetText()
end
