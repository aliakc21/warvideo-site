AkcHouse.Constants.DialogNames = {
  CreateShoppingList = "AKCHOUSE_CREATE_SHOPPING_LIST",
  DeleteShoppingList = "AKCHOUSE_DELETE_SHOPPING_LIST",
  RenameShoppingList = "AKCHOUSE_RENAME_SHOPPING_LIST",
  MakePermanentShoppingList = "akchouse_make_permanent_shopping_list",

  SellingConfirmPost = "AKCHOUSE_SELLING_CONFIRM_POST",
  SellingConfirmPostSkip = "AKCHOUSE_SELLING_CONFIRM_POST_SKIP",
  SellingConfirmUnhideAll = "AKCHOUSE_SELLING_CONFIRM_UNHIDE_ALL",
}
