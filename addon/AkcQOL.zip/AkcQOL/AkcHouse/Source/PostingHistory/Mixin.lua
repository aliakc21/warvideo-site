AkcHouse.PostingHistoryMixin = {}

function AkcHouse.PostingHistoryMixin:Init(db)
  self.db = db
  AkcHouse.EventBus:Register(self, {
    AkcHouse.Selling.Events.AuctionCreated
  })
end

function AkcHouse.PostingHistoryMixin:AddEntry(key, price, quantity, bidPrice)
  AkcHouse.Debug.Message("AkcHouse.PostingHistoryMixin:AddEntry", key, price, quantity)
  if not self.db[key] then
    self.db[key] = {}
  end

  if AkcHouse.Constants.IsLegacyAH then
    bidPrice = nil
  end

  table.insert(self.db[key], {
    price = price, quantity = quantity, bidPrice = bidPrice, time = time()
  })

  self:PruneKey(key)
end

local function IsSameDay(time1, time2)
  return time1.day == time2.day and time1.month == time2.month and time1.year == time2.year
end

function AkcHouse.PostingHistoryMixin:PruneKey(key)
  local itemInfo = self.db[key]

  local currentTime = date("*t", itemInfo[#itemInfo].time)
  local price = itemInfo[#itemInfo].price

  local index = #itemInfo - 1

  while index > 0 do
    local otherTime = date("*t", itemInfo[index].time)
    if itemInfo[index].price == price and
        IsSameDay(currentTime, otherTime) then

      itemInfo[#itemInfo].quantity = itemInfo[#itemInfo].quantity + itemInfo[index].quantity
      table.remove(itemInfo, index)
    end
    index = index - 1
  end

  while #itemInfo > AkcHouse.Config.Get(AkcHouse.Config.Options.POSTING_HISTORY_LENGTH) do
    table.remove(itemInfo, 1)
  end
end

function AkcHouse.PostingHistoryMixin:ReceiveEvent(eventName, eventData)
  if eventName == AkcHouse.Selling.Events.AuctionCreated then
    AkcHouse.Utilities.DBKeyFromLink(eventData.itemLink, function(keys)
      for _, key in ipairs(keys) do
        self:AddEntry(key, eventData.buyoutAmount, eventData.quantity, eventData.bidAmount)
      end
    end)
  end
end

function AkcHouse.PostingHistoryMixin:GetPriceHistory(dbKey)
  if self.db[dbKey] == nil then
    return {}
  end

  local results = {}

  for _, entry in ipairs(self.db[dbKey]) do
    table.insert(results, {
     date = AkcHouse.Utilities.PrettyDate(entry.time),
     rawDay = entry.time,
     price = entry.price,
     bidPrice = entry.bidPrice,
     quantity = entry.quantity
   })
 end

 return results
end
