
local _, addon = ...

local L = AkcQOL_L

local STANDARD = {
    [394003] = true,
    [388658] = true,
    [391775] = true,
    [394008] = true,
    [394007] = true,
    [394005] = true,
    [394016] = true,
    [394015] = true,
    [394001] = true,
    [394006] = true,
    [394011] = true,
    [391312] = true,
}

local FISHING = { [394009] = true }
local FISHING_CAST = 131476
local FILTER = "HELPFUL|CANCELABLE"

local function IsEnabled()
    return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.hideProfessionOutfit == true
end

local function CanRead(v)
    if canaccessvalue ~= nil then
        local ok, res = pcall(canaccessvalue, v)
        if ok then return res == true end
    end
    if issecretvalue ~= nil then
        local ok, res = pcall(issecretvalue, v)
        if ok then return res ~= true end
    end
    return true
end

local function Sweep(matchTable)
    if InCombatLockdown and InCombatLockdown() then return end
    if not (C_UnitAuras and C_UnitAuras.GetBuffDataByIndex and CancelUnitBuff) then return end

    local hits
    for i = 1, 40 do
        local ok, data = pcall(C_UnitAuras.GetBuffDataByIndex, "player", i, FILTER)
        if not ok then

        elseif data == nil then
            break
        elseif CanRead(data) and CanRead(data.spellId) and matchTable[data.spellId] then
            hits = hits or {}
            hits[#hits + 1] = i
        end
    end

    if hits then
        for j = #hits, 1, -1 do
            pcall(CancelUnitBuff, "player", hits[j], FILTER)
        end
    end
end

local function SweepFishingIfNotChanneling()
    if not UnitChannelInfo then return end
    local ok, name = pcall(UnitChannelInfo, "player")
    if not ok then return end
    if not CanRead(name) then return end
    if name ~= nil then return end
    Sweep(FISHING)
end

local function OnEvent(_, event, a1, a2, a3)
    if not IsEnabled() then return end

    if event == "UNIT_AURA" then
        local info = a2
        if not CanRead(info) or type(info) ~= "table" then
            Sweep(STANDARD)
            return
        end
        if CanRead(info.isFullUpdate) and info.isFullUpdate then
            Sweep(STANDARD)
            return
        end
        local added = info.addedAuras
        if CanRead(added) and type(added) == "table" then
            for _, au in ipairs(added) do
                if CanRead(au) then
                    local sid = au.spellId
                    if CanRead(sid) and sid ~= nil and STANDARD[sid] then
                        Sweep(STANDARD)
                        return
                    end
                end
            end
        end

    elseif event == "PLAYER_REGEN_ENABLED" then

        Sweep(STANDARD)
        Sweep(FISHING)

    elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" then

        if CanRead(a3) and a3 == FISHING_CAST then
            Sweep(FISHING)
        end

    elseif event == "PLAYER_ENTERING_WORLD" then

        if C_Timer and C_Timer.After then
            for i = 1, 5 do
                C_Timer.After(i, function()
                    if IsEnabled() then
                        Sweep(STANDARD)
                        SweepFishingIfNotChanneling()
                    end
                end)
            end
        end
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnEvent", OnEvent)

local function ApplyState()
    if IsEnabled() then
        eventFrame:RegisterUnitEvent("UNIT_AURA", "player")
        eventFrame:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "player")
        eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
        Sweep(STANDARD)
        SweepFishingIfNotChanneling()
    else
        eventFrame:UnregisterAllEvents()
    end
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:SetScript("OnEvent", function()
    boot:UnregisterAllEvents()
    ApplyState()
end)

function _G.AkcQOL_ApplyProfessionAppearance()
    ApplyState()
end
