
local _, addon = ...


local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.autoAcceptInvite) ~= "table" then g.autoAcceptInvite = {} end
    local d = g.autoAcceptInvite
    if d.enabled == nil then d.enabled = false end
    if d.mode ~= "all" and d.mode ~= "friends" then d.mode = "friends" end
    return d
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end

local function SafeStr(v)
    if v == nil or IsSecret(v) or type(v) ~= "string" then return nil end
    return v
end

local function BaseName(name)
    name = SafeStr(name)
    if not name then return nil end
    local base = name:match("^([^%-]+)") or name
    return base:lower()
end

local function IsCharacterFriend(name, guid)
    local ok, res = pcall(function()
        guid = SafeStr(guid)
        if guid and C_FriendList and C_FriendList.IsFriend then
            if C_FriendList.IsFriend(guid) then return true end
        end
        local plain = SafeStr(name)
        if plain and C_FriendList and C_FriendList.GetFriendInfo then
            local info = C_FriendList.GetFriendInfo(plain)
            if info ~= nil then return true end
        end
        return false
    end)
    return ok and res == true
end

local function IsGuildMember(name, guid)
    local ok, res = pcall(function()
        if not IsInGuild or not IsInGuild() then return false end
        local wantGuid = SafeStr(guid)
        local wantName = BaseName(name)
        if not wantGuid and not wantName then return false end
        local total = (GetNumGuildMembers and GetNumGuildMembers()) or 0
        for i = 1, total do

            local rName, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, rGuid = GetGuildRosterInfo(i)
            rGuid = SafeStr(rGuid)
            if wantGuid and rGuid and rGuid == wantGuid then return true end
            if wantName and BaseName(rName) == wantName then return true end
        end
        return false
    end)
    return ok and res == true
end

local function IsBattleNetFriend(name, guid)
    local ok, res = pcall(function()
        if not (C_BattleNet and C_BattleNet.GetFriendAccountInfo) then return false end
        local wantGuid = SafeStr(guid)
        local wantName = BaseName(name)
        if not wantGuid and not wantName then return false end
        local total = (BNGetNumFriends and BNGetNumFriends())
            or (C_BattleNet.GetNumFriends and C_BattleNet.GetNumFriends()) or 0
        for i = 1, total do
            local accountInfo = C_BattleNet.GetFriendAccountInfo(i)
            local ga = accountInfo and accountInfo.gameAccountInfo
            if ga then
                local client = SafeStr(ga.clientProgram)
                if client == "WoW" then
                    local gGuid = SafeStr(ga.playerGuid)
                    if wantGuid and gGuid and gGuid == wantGuid then return true end
                    if wantName and BaseName(ga.characterName) == wantName then return true end
                end
            end
        end
        return false
    end)
    return ok and res == true
end

local function IsEligibleInviter(name, guid)
    if IsCharacterFriend(name, guid) then return true end
    if IsGuildMember(name, guid) then return true end
    if IsBattleNetFriend(name, guid) then return true end
    return false
end

local function DoAccept()
    pcall(AcceptGroup)
    pcall(StaticPopup_Hide, "PARTY_INVITE")
end

local function OnPartyInvite(name, guid)
    local d = DB()
    if d.enabled == false then return end
    if d.mode == "all" then
        DoAccept()
        return
    end

    if IsEligibleInviter(name, guid) then
        DoAccept()
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        DB()
        f:RegisterEvent("PARTY_INVITE_REQUEST")
        return
    end

    local name = select(1, ...)
    local guid = select(7, ...)
    pcall(OnPartyInvite, name, guid)
end)

function _G.AkcQOL_ApplyAutoAcceptInvite()
    DB()
    pcall(function() f:RegisterEvent("PARTY_INVITE_REQUEST") end)
end
