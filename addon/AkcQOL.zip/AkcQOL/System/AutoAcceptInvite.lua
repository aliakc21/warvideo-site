
local _, addon = ...


local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.autoAcceptInvite) ~= "table" then g.autoAcceptInvite = {} end
    local d = g.autoAcceptInvite
    if d.enabled == nil then d.enabled = false end
    if d.mode ~= "all" and d.mode ~= "friends" then d.mode = "friends" end
    return d
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end

local function SafeStr(v)
    if v == nil or IsSecret(v) or type(v) ~= "string" then return nil end
    return v
end

-- Realm spellings differ between APIs ("Twisting Nether" / "TwistingNether",
-- "Azjol-Nerub" / "AzjolNerub"), so both sides drop spaces, dashes and
-- apostrophes before they are compared.
local function NormRealm(realm)
    realm = SafeStr(realm)
    if not realm then return nil end
    realm = realm:gsub("[%s%-']", ""):lower()
    if realm == "" then return nil end
    return realm
end

local function PlayerRealm()
    local ok, realm = pcall(function()
        return SafeStr(GetNormalizedRealmName and GetNormalizedRealmName())
            or SafeStr(GetRealmName and GetRealmName())
    end)
    return ok and realm or nil
end

-- "name-realm" key for the name fallback. The realm has to be part of it: a
-- bare name would let "Bob" from any realm pass for a guildie or friend named
-- Bob. A name without a realm part takes fallbackRealm (the player's own realm
-- for invites and guild rosters); with no realm at all there is no key.
local function FullName(name, fallbackRealm)
    name = SafeStr(name)
    if not name then return nil end
    local base, realm = name:match("^([^%-]+)%-(.+)$")
    if not base then base, realm = name, fallbackRealm end
    realm = NormRealm(realm)
    if not realm or base == "" then return nil end
    return base:lower() .. "-" .. realm
end

local function IsCharacterFriend(name, guid)
    local ok, res = pcall(function()
        guid = SafeStr(guid)
        if guid and C_FriendList and C_FriendList.IsFriend then
            if C_FriendList.IsFriend(guid) then return true end
        end
        local plain = SafeStr(name)
        if plain and C_FriendList and C_FriendList.GetFriendInfo then
            local info = C_FriendList.GetFriendInfo(plain)
            if info ~= nil then return true end
        end
        return false
    end)
    return ok and res == true
end

local function IsGuildMember(name, guid)
    local ok, res = pcall(function()
        if not IsInGuild or not IsInGuild() then return false end
        local myRealm = PlayerRealm()
        local wantGuid = SafeStr(guid)
        local wantName = FullName(name, myRealm)
        if not wantGuid and not wantName then return false end
        local total = (GetNumGuildMembers and GetNumGuildMembers()) or 0
        for i = 1, total do

            local rName, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, rGuid = GetGuildRosterInfo(i)
            rGuid = SafeStr(rGuid)
            if wantGuid and rGuid and rGuid == wantGuid then return true end
            if wantName and FullName(rName, myRealm) == wantName then return true end
        end
        return false
    end)
    return ok and res == true
end

local function IsBattleNetFriend(name, guid)
    local ok, res = pcall(function()
        if not (C_BattleNet and C_BattleNet.GetFriendAccountInfo) then return false end
        local wantGuid = SafeStr(guid)
        local wantName = FullName(name, PlayerRealm())
        if not wantGuid and not wantName then return false end
        local total = (BNGetNumFriends and BNGetNumFriends())
            or (C_BattleNet.GetNumFriends and C_BattleNet.GetNumFriends()) or 0
        for i = 1, total do
            local accountInfo = C_BattleNet.GetFriendAccountInfo(i)
            local ga = accountInfo and accountInfo.gameAccountInfo
            if ga then
                local client = SafeStr(ga.clientProgram)
                if client == "WoW" then
                    local gGuid = SafeStr(ga.playerGuid)
                    if wantGuid and gGuid and gGuid == wantGuid then return true end
                    -- "WoW" also covers Classic: a same-named character there
                    -- is not the one inviting. The realm comes only from the
                    -- account info, never the player's own realm.
                    local project = ga.wowProjectID
                    local sameGame = not (type(project) == "number" and not IsSecret(project)
                        and type(WOW_PROJECT_ID) == "number" and project ~= WOW_PROJECT_ID)
                    if wantName and sameGame
                        and FullName(ga.characterName, SafeStr(ga.realmName) or SafeStr(ga.realmDisplayName)) == wantName then
                        return true
                    end
                end
            end
        end
        return false
    end)
    return ok and res == true
end

local function IsEligibleInviter(name, guid)
    if IsCharacterFriend(name, guid) then return true end
    if IsGuildMember(name, guid) then return true end
    if IsBattleNetFriend(name, guid) then return true end
    return false
end

-- A secret flag counts as set: when in doubt the invite goes to Blizzard.
local function FlagSet(v)
    if IsSecret(v) then return true end
    return v ~= nil and v ~= false
end

-- Accepting an invite drops a solo Dungeon Finder / LFR / PvP queue and
-- cancels pending Premade Group applications. Blizzard's popup warns about
-- that; an auto-accept would skip the warning, so while anything is queued
-- the player gets the normal popup instead.
local function HasActiveQueue()
    if WillAcceptInviteRemoveQueues then
        local ok, willRemove = pcall(WillAcceptInviteRemoveQueues)
        if ok and FlagSet(willRemove) then return true end
    end
    -- The queue eye is shown for every queue type and for an active listing,
    -- including any the call above might not cover.
    local eye = _G.QueueStatusButton
    if eye and eye.IsShown then
        local ok, shown = pcall(eye.IsShown, eye)
        if ok and shown == true then return true end
    end
    if C_LFGList and C_LFGList.GetApplications and C_LFGList.GetApplicationInfo then
        local ok, pending = pcall(function()
            for _, id in ipairs(C_LFGList.GetApplications() or {}) do
                local _, status, pendingStatus = C_LFGList.GetApplicationInfo(id)
                if pendingStatus or status == "applied" or status == "invited" then return true end
            end
            return false
        end)
        if ok and pending then return true end
    end
    return false
end

-- Only plain invites open the "PARTY_INVITE" popup that DoAccept hides. An
-- invite with role flags (a listed Premade Group) opens LFGInvitePopup, where
-- the player picks roles, and a Party Sync invite opens the quest-session
-- confirmation; both are choices the player makes, so they are left alone.
local function IsPlainInvite(isTank, isHealer, isDamage, questSessionActive)
    return not (FlagSet(isTank) or FlagSet(isHealer) or FlagSet(isDamage)
        or FlagSet(questSessionActive))
end

local function DoAccept()
    pcall(AcceptGroup)
    pcall(StaticPopup_Hide, "PARTY_INVITE")
end

local function OnPartyInvite(name, guid, isTank, isHealer, isDamage, questSessionActive)
    local d = DB()
    if d.enabled == false then return end
    if not IsPlainInvite(isTank, isHealer, isDamage, questSessionActive) then return end
    if HasActiveQueue() then return end
    if d.mode == "all" then
        DoAccept()
        return
    end

    if IsEligibleInviter(name, guid) then
        DoAccept()
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        DB()
        f:RegisterEvent("PARTY_INVITE_REQUEST")
        return
    end

    local name, isTank, isHealer, isDamage, _, _, guid, questSessionActive = ...
    pcall(OnPartyInvite, name, guid, isTank, isHealer, isDamage, questSessionActive)
end)

function _G.AkcQOL_ApplyAutoAcceptInvite()
    DB()
    pcall(function() f:RegisterEvent("PARTY_INVITE_REQUEST") end)
end
