
local _, addon = ...

local DEFAULT_PET_MESSAGE = "Pet health is LOW!"

local lastPlay = 0
local fired = false

local petScreenFrame
local petHideToken = 0

local pollTicker

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.petAlert) ~= "table" then g.petAlert = {} end
    local d = g.petAlert
    if d.enabled == nil then d.enabled = false end
    if type(d.threshold) ~= "number" then d.threshold = 50 end
    if type(d.soundStyle) ~= "string" then d.soundStyle = "bosswarn" end
    if type(d.volume) ~= "number" then d.volume = 100 end
    if d.screen == nil then d.screen = false end
    if type(d.message) ~= "string" or d.message == "" then d.message = DEFAULT_PET_MESSAGE end
    return d
end

local function safeNum(v)
    if v == nil then return nil end
    if issecretvalue and issecretvalue(v) then return nil end
    if type(v) ~= "number" then return nil end
    return v
end

local function PlayStyle(style)
    if addon.PlayAlertSoundStyle then addon:PlayAlertSoundStyle(style, DB().volume) end
end

local function EnsurePetScreenFrame()
    if petScreenFrame then return petScreenFrame end
    local frame = CreateFrame("Frame", "AkcQOLPetAlertFrame", UIParent)
    frame:SetSize(420, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 90)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(20)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(1, 0.35, 0.25, 1)

    petScreenFrame = frame
    return petScreenFrame
end

local function ShowPetScreenAlert(message)
    local upper = string.upper(message or DEFAULT_PET_MESSAGE)
    local frame = EnsurePetScreenFrame()
    frame.text:SetText(upper)
    frame:SetAlpha(1)
    frame:Show()

    petHideToken = petHideToken + 1
    local token = petHideToken
    if C_Timer and C_Timer.After then
        C_Timer.After(1.8, function()
            if petHideToken ~= token or not petScreenFrame then return end
            petScreenFrame:Hide()
        end)
    end

    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(upper, 1, 0.35, 0.25, 1)
    end
end

local function CheckPet()
    local d = DB()
    if d.enabled == false then return end
    if not UnitExists("pet") or UnitIsDeadOrGhost("pet") then
        fired = false
        return
    end
    local hp = safeNum(UnitHealth("pet"))
    local mx = safeNum(UnitHealthMax("pet"))
    if not hp or not mx or mx <= 0 then return end

    local pct = (hp / mx) * 100
    local threshold = d.threshold or 50

    if pct <= threshold then
        if not fired then
            local now = GetTime()
            if (now - lastPlay) >= 5 then
                PlayStyle(d.soundStyle)
                if d.screen then ShowPetScreenAlert(d.message) end
                lastPlay = now

                fired = true
            end
        end
    elseif pct >= (threshold + 5) then
        fired = false
    end
end

local function SyncPolling()
    local d = DB()
    if d.enabled ~= false then
        if not pollTicker and C_Timer and C_Timer.NewTicker then
            pollTicker = C_Timer.NewTicker(1, function() pcall(CheckPet) end)
        end
    elseif pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
        if petScreenFrame then petScreenFrame:Hide() end
    end
end

function _G.AkcQOL_TestPetAlert()
    local d = DB()
    PlayStyle(d.soundStyle)
    ShowPetScreenAlert(d.message)
end

function _G.AkcQOL_ApplyPetAlert()
    fired = false
    DB()
    SyncPolling()
    pcall(CheckPet)
end

function _G.AkcQOL_ResetPetAlertDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.petAlert = nil end
    DB()
    fired = false
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()

        f:RegisterUnitEvent("UNIT_HEALTH", "pet")

        f:RegisterUnitEvent("UNIT_PET", "player")
        f:RegisterEvent("PLAYER_ENTERING_WORLD")
        SyncPolling()
        return
    end
    if event == "UNIT_PET" or event == "PLAYER_ENTERING_WORLD" then
        fired = false
        pcall(CheckPet)
        return
    end

    pcall(CheckPet)
end)
