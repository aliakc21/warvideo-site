
local L = AkcQOL_L
local PREFIX = "|cff8c5cffAkc|r|cffffffffQOL|r"

local SQW_MIN, SQW_MAX, SQW_DEFAULT = 0, 400, 400
local REC_MARGIN = 100
local REC_MIN, REC_MAX = 100, 400

local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end
local function ReadCVar(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVar and C_CVar.GetCVar(name)) or (GetCVar and GetCVar(name))
        if v ~= nil and not IsSecret(v) then out = v end
    end)
    return out
end
local function WriteCVar(name, value)
    pcall(function()
        if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar(name, tostring(value))
        elseif SetCVar then SetCVar(name, tostring(value)) end
    end)
end

local function ClampSQW(n)
    n = tonumber(n) or SQW_DEFAULT
    n = math.floor(n + 0.5)
    if n < SQW_MIN then n = SQW_MIN elseif n > SQW_MAX then n = SQW_MAX end
    return n
end

local pendingSQW = nil
local regenFrame

function _G.AkcQOL_GetSpellQueueWindow()
    if pendingSQW ~= nil then return pendingSQW end
    local v = tonumber(ReadCVar("SpellQueueWindow"))
    if not v then return SQW_DEFAULT end
    return math.floor(v + 0.5)
end

function _G.AkcQOL_GetWorldPing()
    if not GetNetStats then return nil end
    local ok, _, _, _, world = pcall(GetNetStats)
    if ok and type(world) == "number" and world > 0 then return math.floor(world + 0.5) end
    return nil
end

function _G.AkcQOL_GetRecommendedSQW()
    local ping = _G.AkcQOL_GetWorldPing() or 0
    local rec = ping + REC_MARGIN
    if rec < REC_MIN then rec = REC_MIN elseif rec > REC_MAX then rec = REC_MAX end
    return rec
end

local function FlushSQW()
    if pendingSQW == nil then return end
    local v = pendingSQW
    pendingSQW = nil
    WriteCVar("SpellQueueWindow", v)
end

function _G.AkcQOL_SetSpellQueueWindow(n)
    n = ClampSQW(n)
    if InCombatLockdown and InCombatLockdown() then
        pendingSQW = n
        if regenFrame then regenFrame:RegisterEvent("PLAYER_REGEN_ENABLED") end
        return
    end
    pendingSQW = nil
    WriteCVar("SpellQueueWindow", n)
end

function _G.AkcQOL_ApplyRecommendedSQW()
    _G.AkcQOL_SetSpellQueueWindow(_G.AkcQOL_GetRecommendedSQW())
end

function _G.AkcQOL_PrintSpellQueueWindow()
    local cur  = _G.AkcQOL_GetSpellQueueWindow()
    local ping = _G.AkcQOL_GetWorldPing()
    local rec  = _G.AkcQOL_GetRecommendedSQW()
    print(PREFIX .. " " .. string.format(
        L["Spell Queue Window is currently |cff8c5cff%s ms|r  (world ping %s ms, recommended %s ms)."],
        tostring(cur), tostring(ping or "?"), tostring(rec)))
end

function _G.AkcQOL_GetNagleOptimize()
    return tonumber(ReadCVar("disableServerNagle")) == 1
end
function _G.AkcQOL_SetNagleOptimize(on)
    WriteCVar("disableServerNagle", on and "1" or "0")
end

function _G.AkcQOL_GetIPv6()
    return tonumber(ReadCVar("useIPv6")) == 1
end
function _G.AkcQOL_SetIPv6(on)
    WriteCVar("useIPv6", on and "1" or "0")
end

regenFrame = CreateFrame("Frame")
regenFrame:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_REGEN_ENABLED" then
        FlushSQW()
        self:UnregisterEvent("PLAYER_REGEN_ENABLED")
        if LibStub then
            local reg = LibStub("AceConfigRegistry-3.0", true)
            if reg then pcall(reg.NotifyChange, reg, "AkcQOLRaidCD") end
        end
    end
end)

SLASH_AKCLATENCY1 = "/akclatency"
SlashCmdList["AKCLATENCY"] = function(msg)
    msg = (msg or ""):gsub("%s+", "")
    local num = tonumber(msg)
    if num then
        _G.AkcQOL_SetSpellQueueWindow(num)
        print(PREFIX .. " " .. string.format(L["Spell Queue Window set to |cff8c5cff%d ms|r."], ClampSQW(num)))
        if LibStub then
            local reg = LibStub("AceConfigRegistry-3.0", true)
            if reg then pcall(reg.NotifyChange, reg, "AkcQOLRaidCD") end
        end
    else
        local cur = _G.AkcQOL_GetSpellQueueWindow()
        local ping = _G.AkcQOL_GetWorldPing()
        local rec = _G.AkcQOL_GetRecommendedSQW()
        print(PREFIX .. " " .. string.format(
            L["Spell Queue Window: |cff8c5cff%s ms|r  (world ping %s ms, recommended %s ms). Use /akclatency <number> or the settings panel."],
            tostring(cur), tostring(ping or "?"), tostring(rec)))
    end
end
