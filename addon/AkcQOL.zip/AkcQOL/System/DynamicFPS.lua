
local _, addon = ...

local L = AkcQOL_L
local PREFIX = "|cff8c5cffAkc|r|cffffffffQOL|r"

local LOW = {
    particleDensity           = "10",
    shadowMode                = "0",
    SSAO                      = "0",
    waterDetail               = "0",
    reflectionMode            = "0",
    reflectionDownscale       = "4",
    sunShafts                 = "0",
    refraction                = "0",
    rippleDetail              = "0",
    physicsLevel              = "0",
    weatherDensity            = "0",
    groundEffectDensity       = "16",
    groundEffectDist          = "40",
    maxLightCount             = "8",
    maxLightDist              = "1000",
    lodObjectCullDist         = "15",
    lodObjectCullSize         = "25",
    lodObjectMinSize          = "30",
    animFrameSkipLOD          = "1",
    spellClutterMinSpellCount = "0",
    unitClutterPlayerThreshold= "8",

    entityLodDist             = "4",
    wmoLodDist                = "150",
    entityShadowFadeScale     = "6",
    volumeFogLevel            = "0",
    bodyQuota                 = "24",
    particleMTDensity         = "10",
}

local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end
local function ReadCVar(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVar and C_CVar.GetCVar(name)) or (GetCVar and GetCVar(name))
        if v ~= nil and not IsSecret(v) then out = v end
    end)
    return out
end
local function WriteCVar(name, value)
    pcall(function()
        if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar(name, tostring(value))
        elseif SetCVar then SetCVar(name, tostring(value)) end
    end)
end
local function DefaultCVar(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVarDefault and C_CVar.GetCVarDefault(name)) or (GetCVarDefault and GetCVarDefault(name))
        if v ~= nil and not IsSecret(v) then out = v end
    end)
    return out
end

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.dynFPS) ~= "table" then g.dynFPS = {} end
    local d = g.dynFPS
    if type(d.mode) ~= "string" then d.mode = "off" end
    if d.lowActive == nil then d.lowActive = false end
    return d
end

local pendingReconcile = false

local function EffectiveLow()
    local eff = {}
    for cv, low in pairs(LOW) do
        eff[cv] = low
        local raid = "RAID" .. cv
        if DefaultCVar(raid) ~= nil then eff[raid] = low end
    end
    return eff
end

local function GoLow()
    local d = DB()
    local eff = EffectiveLow()
    if d.lowActive then
        for name, low in pairs(eff) do WriteCVar(name, low) end
        return
    end
    local saved = {}
    for name, low in pairs(eff) do
        local cur = ReadCVar(name)
        if cur ~= nil then saved[name] = cur end
        WriteCVar(name, low)
    end
    d.saved = saved
    d.lowActive = true
end

local function GoHigh()
    local d = DB()
    if not d.lowActive then return end
    if d.saved then
        for name, v in pairs(d.saved) do WriteCVar(name, v) end
    else
        for name in pairs(EffectiveLow()) do
            local dv = DefaultCVar(name)
            if dv ~= nil then WriteCVar(name, dv) end
        end
    end
    d.lowActive = false
    d.saved = nil
end

local function InLowZone()
    local inInstance, instanceType = IsInInstance()
    if not inInstance then return false end
    return instanceType == "raid" or instanceType == "party"
        or instanceType == "arena" or instanceType == "pvp"
        or instanceType == "scenario"
end

local function Reconcile()
    local d = DB()
    local wantLow
    if d.mode == "off" then wantLow = false
    elseif d.mode == "on" then wantLow = true
    else wantLow = InLowZone() end

    if InCombatLockdown and InCombatLockdown() then
        pendingReconcile = true
        return
    end
    pendingReconcile = false
    if wantLow then GoLow() else GoHigh() end
end

local function ForceRestore()
    local d = DB()
    if d.saved then
        for name, v in pairs(d.saved) do WriteCVar(name, v) end
    end

    for name in pairs(EffectiveLow()) do
        if not (d.saved and d.saved[name] ~= nil) then
            local dv = DefaultCVar(name)
            if dv ~= nil then WriteCVar(name, dv) end
        end
    end
    d.lowActive = false
    d.saved = nil
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("PLAYER_LOGOUT")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGOUT" then

        local d = DB()
        if d.lowActive then GoHigh() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if pendingReconcile then Reconcile() end
    else
        Reconcile()
    end
end)

function _G.AkcQOL_ApplyDynamicFPS()
    Reconcile()
end

local function Status()
    local d = DB()
    if d.mode == "off" then
        print(PREFIX .. " " .. L["Dynamic FPS: |cffff5555disabled|r."])
    elseif d.lowActive then
        print(PREFIX .. " " .. L["Dynamic FPS: |cff00ff00active now|r -- lowering graphics"]
            .. (d.mode == "on" and L[" (always-low)."] or L[" (you're in an instance)."]))
    elseif d.mode == "on" then
        print(PREFIX .. " " .. L["Dynamic FPS: |cff00ff00always low|r -- not applied yet (normal graphics until the next check)."])
    else
        print(PREFIX .. " " .. L["Dynamic FPS: |cff00ff00auto|r -- idle right now (normal graphics; it activates inside instances)."])
    end
    if pendingReconcile then
        print(PREFIX .. " " .. L["Dynamic FPS: |cffffcc00pending|r (waiting for combat to end before changing graphics)."])
    end
end

SLASH_AKCFPS1 = "/fps"
SLASH_AKCFPS2 = "/akcfps"
SlashCmdList["AKCFPS"] = function(msg)
    msg = (msg or ""):lower():gsub("%s+", "")
    local d = DB()
    if msg == "off" then
        d.mode = "off"; Reconcile(); print(PREFIX .. " " .. L["Dynamic FPS: |cffff5555off|r (normal graphics)"])
    elseif msg == "on" then
        d.mode = "on"; Reconcile(); print(PREFIX .. " " .. L["Dynamic FPS: |cff00ff00always low|r"])
    elseif msg == "auto" then
        d.mode = "auto"; Reconcile(); print(PREFIX .. " " .. L["Dynamic FPS: |cff00ff00auto|r (low in instances)"])
    elseif msg == "reset" then
        ForceRestore(); print(PREFIX .. " " .. L["Dynamic FPS: graphics restored."])
    else
        Status()
    end
    if LibStub then
        local reg = LibStub("AceConfigRegistry-3.0", true)
        if reg then pcall(reg.NotifyChange, reg, "AkcQOLRaidCD") end
    end
end
