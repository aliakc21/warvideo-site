local _, addon = ...

local L = AkcQOL_L
local Theme = AkcQOL_Theme

local FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local FONT_FLAGS = "OUTLINE"
local ICON_SIZE = 42
local ICON_SPACING = 8
local DEFAULT_Y_OFFSET = 150
local DEFAULT_FRAME_WIDTH = 520
local FRAME_HEIGHT = ICON_SIZE
local ICON_TOP_INSET = 0
local READY_POPUP_GAP = 4

local ICONS = {
    food = "Interface\\Icons\\INV_Misc_Food_15",
    flask = "Interface\\Icons\\INV_Potion_83",
    augment = "Interface\\Icons\\INV_Misc_Rune_01",
    healthstone = "Interface\\Icons\\INV_Stone_04",
    weaponOil = "Interface\\Icons\\INV_Potion_93",
}

local helperFrame
local eventFrame
local updateQueued = false
local hideQueued = false
local hideToken = 0
local manuallyDismissed = false
local ScheduleUpdate
local RefreshReadyCheckFit
local GetReadyCheckPopup
local SavePosition

local function SafeString(value)
    if value == nil then return nil end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return nil end
    end
    local ok, text = pcall(tostring, value)
    if ok and text and text ~= "" then return text end
    return nil
end

local function Lower(value)
    value = SafeString(value) or ""
    return string.lower(value)
end

local function SafeNumber(value)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        if ok and isSecret then return nil end
    end
    if type(value) == "number" then return value end
    return nil
end

local function TextContainsAny(text, needles)
    text = text or ""
    for _, needle in ipairs(needles) do
        if text:find(needle, 1, true) then
            return true
        end
    end
    return false
end

local function GetDB()
    local profile = addon.AkcQOL and addon.AkcQOL.db and addon.AkcQOL.db.profile
    if not profile then return nil end

    profile.readyCheckHelper = profile.readyCheckHelper or {}
    local db = profile.readyCheckHelper
    if db.enabled == nil then db.enabled = false end
    if db.locked == nil then db.locked = false end
    db.point = db.point or "CENTER"
    db.relPoint = db.relPoint or "CENTER"
    db.xOfs = db.xOfs or 0
    db.yOfs = db.yOfs or DEFAULT_Y_OFFSET
    if db.iconBarMigrationV1 == nil then
        db.iconBarMigrationV1 = true
        if db.point == "CENTER" and db.relPoint == "CENTER" and (db.xOfs or 0) == 0 and (db.yOfs or DEFAULT_Y_OFFSET) == 210 then
            db.yOfs = DEFAULT_Y_OFFSET
        end
    end
    return db
end

local WELL_FED_SPELL_ID = 19705

local FOOD_AURA_IDS = {
    [19705] = true,
}
local FLASK_AURA_IDS = {

    [431971] = true,
    [431972] = true,
    [431973] = true,
    [431974] = true,
    [432021] = true,
    [432473] = true,

    [371172] = true,
    [371339] = true,
    [373257] = true,
}
local AUGMENT_AURA_IDS = {
    [393438] = true,
    [347901] = true,
}

local wellFedNameLower
local function GetWellFedNameLower()
    if wellFedNameLower then return wellFedNameLower end
    if C_Spell and C_Spell.GetSpellName then
        local ok, name = pcall(C_Spell.GetSpellName, WELL_FED_SPELL_ID)
        name = ok and SafeString(name) or nil
        if name then
            wellFedNameLower = string.lower(name)
            return wellFedNameLower
        end
    end
    return nil
end

local function PlayerHasAura(matchFn)
    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 200 do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not aura then break end
            local auraName = SafeString(aura.name) or ""
            local spellID = SafeNumber(aura.spellId) or SafeNumber(aura.spellID)
            if matchFn(Lower(auraName), spellID, aura) then
                return true, auraName, aura.icon
            end
        end
        return false
    end

    local auraFn = UnitAura or UnitBuff
    if auraFn then
        for i = 1, 200 do
            local ok, name, icon, count, dispelType, duration, expirationTime, source, isStealable, nameplateShowPersonal, spellID = pcall(auraFn, "player", i, "HELPFUL")
            if not ok or not name then break end
            local auraName = SafeString(name) or ""
            if matchFn(Lower(auraName), SafeNumber(spellID)) then
                return true, auraName, icon
            end
        end
    end

    return false
end

local function GetItemIconTexture(itemID, fallback)
    if C_Item and C_Item.GetItemIconByID then
        local ok, icon = pcall(C_Item.GetItemIconByID, itemID)
        if ok and icon then return icon end
    end
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, itemInfoID, itemType, itemSubType, itemEquipLoc, icon = pcall(C_Item.GetItemInfoInstant, itemID)
        if ok and icon then return icon end
    end
    if GetItemIcon then
        local ok, icon = pcall(GetItemIcon, itemID)
        if ok and icon then return icon end
    end
    return fallback
end

local function GetBagUpperBound()
    local maxBag = NUM_BAG_SLOTS or 4
    if Enum and Enum.BagIndex and Enum.BagIndex.ReagentBag then
        maxBag = math.max(maxBag, Enum.BagIndex.ReagentBag)
    end
    return maxBag
end

local function RequestItemInfo(itemID)
    if itemID and C_Item and C_Item.RequestLoadItemDataByID then
        pcall(C_Item.RequestLoadItemDataByID, itemID)
    end
end

local function GetNameFromLink(itemLink)
    itemLink = SafeString(itemLink)
    if not itemLink then return nil end
    local name = itemLink:match("%[(.-)%]")
    return name and name ~= "" and name or nil
end

local function GetItemDetails(itemID, itemLink)
    local query = itemLink or itemID
    if not query then return nil end

    local itemName, resolvedLink, itemType, itemSubType, itemTexture, classID, subclassID
    if C_Item and C_Item.GetItemInfo then
        local ok
        ok, itemName, resolvedLink, _, _, _, itemType, itemSubType, _, _, itemTexture, _, classID, subclassID = pcall(C_Item.GetItemInfo, query)
        if not ok then itemName = nil end
    end

    if not itemName and GetItemInfo then
        local ok
        ok, itemName, resolvedLink, _, _, _, itemType, itemSubType, _, _, itemTexture, _, classID, subclassID = pcall(GetItemInfo, query)
        if not ok then itemName = nil end
    end

    if (classID == nil or subclassID == nil) and C_Item and C_Item.GetItemInfoInstant then
        local ok, _, _, _, _, _, instantClassID, instantSubclassID = pcall(C_Item.GetItemInfoInstant, query)
        if ok then
            if classID == nil then classID = instantClassID end
            if subclassID == nil then subclassID = instantSubclassID end
        end
    end

    itemName = SafeString(itemName) or GetNameFromLink(itemLink)
    resolvedLink = SafeString(resolvedLink) or itemLink
    itemType = Lower(itemType)
    itemSubType = Lower(itemSubType)
    if not itemName then RequestItemInfo(itemID) end

    return {
        name = itemName,
        link = resolvedLink,
        itemType = itemType,
        itemSubType = itemSubType,
        icon = itemTexture,
        classID = classID,
        subclassID = subclassID,
    }
end

local function GetBagItem(bag, slot)
    local itemID, itemLink, itemIcon, count

    if C_Container and C_Container.GetContainerItemInfo then
        local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
        if ok and info then
            itemID = info.itemID
            itemLink = info.hyperlink
            itemIcon = info.iconFileID
            count = info.stackCount
        end
    elseif GetContainerItemInfo then
        local ok, icon, stackCount, _, _, _, link, _, _, _, legacyItemID = pcall(GetContainerItemInfo, bag, slot)
        if ok then
            itemID = legacyItemID
            itemLink = link
            itemIcon = icon
            count = stackCount
        end
    end

    itemLink = SafeString(itemLink)
    if not itemID and itemLink then
        itemID = tonumber(itemLink:match("item:(%d+)"))
    end
    if not itemID then return nil end

    local details = GetItemDetails(itemID, itemLink)
    local name = details and details.name
    local link = details and details.link
    local icon = itemIcon or (details and details.icon)

    return {
        bag = bag,
        slot = slot,
        itemID = itemID,
        link = link,
        name = name,
        nameLower = Lower(name),
        icon = icon,
        count = count or 1,
        itemType = details and details.itemType or "",
        itemSubType = details and details.itemSubType or "",
        classID = details and details.classID,
        subclassID = details and details.subclassID,
    }
end

local function GetContainerSlotCount(bag)
    if C_Container and C_Container.GetContainerNumSlots then
        local ok, numSlots = pcall(C_Container.GetContainerNumSlots, bag)
        return ok and numSlots or 0
    elseif GetContainerNumSlots then
        local ok, numSlots = pcall(GetContainerNumSlots, bag)
        return ok and numSlots or 0
    end
    return 0
end

local function GetItemCountSafe(itemID)
    if C_Item and C_Item.GetItemCount then
        local ok, count = pcall(C_Item.GetItemCount, itemID, false, true)
        if ok and count and count > 0 then return count end
    end
    if GetItemCount then
        local ok, count = pcall(GetItemCount, itemID, false, true)
        if ok and count and count > 0 then return count end
    end
    return 0
end

local function IsConsumable(item)
    local consumableClass = (Enum and Enum.ItemClass and Enum.ItemClass.Consumable) or LE_ITEM_CLASS_CONSUMABLE
    return not consumableClass or item.classID == consumableClass
end

local CONSUMABLE_SUBCLASS_ENUM = Enum and Enum.ItemConsumableSubclass
local FOOD_SUBCLASS = (CONSUMABLE_SUBCLASS_ENUM and (CONSUMABLE_SUBCLASS_ENUM.Fooddrink or CONSUMABLE_SUBCLASS_ENUM.FoodAndDrink))
    or LE_ITEM_CONSUMABLE_FOOD_AND_DRINK or 5
local FLASK_SUBCLASS = (CONSUMABLE_SUBCLASS_ENUM and CONSUMABLE_SUBCLASS_ENUM.Flask)
    or LE_ITEM_CONSUMABLE_FLASK or 3

local tooltipVerdictCache = {}

local function GetTooltipVerdicts(itemID)
    if not itemID then return nil end
    local entry = tooltipVerdictCache[itemID]
    if not entry then
        entry = {}
        tooltipVerdictCache[itemID] = entry
    end
    return entry
end

local function GetWellFedInfo(bag, slot)
    if bag == nil or slot == nil then return nil, 0 end
    if not (C_TooltipInfo and C_TooltipInfo.GetBagItem) then return nil, 0 end

    local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
    if not ok or type(data) ~= "table" or type(data.lines) ~= "table" then
        return nil, 0
    end

    local wellFed = GetWellFedNameLower()
    local grants, statValue, sawUnreadable = false, 0, false
    for _, line in ipairs(data.lines) do
        local raw = line and line.leftText
        local text = SafeString(raw)
        if raw ~= nil and text == nil then

            sawUnreadable = true
        end
        if text then
            local lower = string.lower(text)
            if lower:find("well fed", 1, true) or lower:find("well-fed", 1, true)
                or (wellFed and lower:find(wellFed, 1, true)) then
                grants = true

                local cleaned = text:gsub("(%d)[,%s](%d)", "%1%2"):gsub("(%d)[,%s](%d)", "%1%2")

                for num, suffix in cleaned:gmatch("(%d+)%s*(%a*)") do
                    local unit = string.lower(suffix)
                    local isDuration = unit == "sec" or unit == "secs" or unit == "second" or unit == "seconds"
                        or unit == "min" or unit == "mins" or unit == "minute" or unit == "minutes"
                        or unit == "hr" or unit == "hrs" or unit == "hour" or unit == "hours"
                    if not isDuration then
                        local n = tonumber(num)
                        if n and n > statValue then statValue = n end
                    end
                end
            end
        end
    end
    if not grants and sawUnreadable then
        return nil, 0
    end
    return grants, statValue
end

local function IsFoodItem(item)
    if IsConsumable(item) and item.subclassID == FOOD_SUBCLASS then
        return true
    end

    if IsConsumable(item) and TextContainsAny(item.itemSubType, { "food", "drink" }) then
        return true
    end
    return TextContainsAny(item.nameLower, { "feast", "banquet", "hearty", "meal" })
end

local function FoodScore(item)
    local verdicts = GetTooltipVerdicts(item.itemID)
    local grants, statValue
    if verdicts and verdicts.wellFed ~= nil then
        grants, statValue = verdicts.wellFed, verdicts.wellFedStat or 0
    else
        grants, statValue = GetWellFedInfo(item.bag, item.slot)
        if verdicts and grants ~= nil then
            verdicts.wellFed, verdicts.wellFedStat = grants, statValue
        end
    end
    item.wellFedGrants = grants
    local score
    if grants == true then

        score = 1000 + (statValue or 0)
    elseif grants == false then

        score = -1000
    else

        score = 1
    end
    if TextContainsAny(item.nameLower, { "feast", "banquet" }) then score = score + 200 end
    if TextContainsAny(item.nameLower, { "hearty", "meal", "bounty" }) then score = score + 50 end
    if TextContainsAny(item.nameLower, { "tea", "water", "conjured", "refreshment", "sparkling", "soda", "cola", "juice", "coffee", "milk" }) then
        score = score - 30
    end
    return score
end

local function IsFlaskOrPhialItem(item)
    if not IsConsumable(item) then return false end

    if item.subclassID == FLASK_SUBCLASS then return true end
    return TextContainsAny(item.nameLower, { "flask", "phial" })
end

local FLASK_COMBAT_STATS = {
    "strength", "agility", "intellect", "stamina",
    "critical strike", "haste", "mastery", "versatility",
    "primary stat", "main stat",
}
do

    local statGlobals = {
        "SPELL_STAT1_NAME", "SPELL_STAT2_NAME", "SPELL_STAT3_NAME", "SPELL_STAT4_NAME",
        "STAT_CRITICAL_STRIKE", "STAT_HASTE", "STAT_MASTERY", "STAT_VERSATILITY",
    }
    for _, globalName in ipairs(statGlobals) do
        local value = _G[globalName]
        if type(value) == "string" and value ~= "" then
            FLASK_COMBAT_STATS[#FLASK_COMBAT_STATS + 1] = string.lower(value)
        end
    end
end
local function GetFlaskInfo(bag, slot)
    if bag == nil or slot == nil then return nil end
    if not (C_TooltipInfo and C_TooltipInfo.GetBagItem) then return nil end

    local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
    if not ok or type(data) ~= "table" or type(data.lines) ~= "table" then
        return nil
    end

    local sawEffect, grantsCombat, sawUnreadable = false, false, false
    for _, line in ipairs(data.lines) do
        local raw = line and line.leftText
        local text = SafeString(raw)
        if raw ~= nil and text == nil then

            sawUnreadable = true
        end
        if text then
            local lower = string.lower(text)
            if lower:find("use:", 1, true) or lower:find("drink", 1, true) then
                sawEffect = true
            end
            for _, stat in ipairs(FLASK_COMBAT_STATS) do
                if lower:find(stat, 1, true) then grantsCombat = true break end
            end
        end
    end

    if grantsCombat then return true end
    if sawEffect and not sawUnreadable then return false end
    return nil
end

local function FlaskScore(item)
    local verdicts = GetTooltipVerdicts(item.itemID)
    local grantsCombat
    if verdicts and verdicts.flaskCombat ~= nil then
        grantsCombat = verdicts.flaskCombat
    else
        grantsCombat = GetFlaskInfo(item.bag, item.slot)
        if verdicts and grantsCombat ~= nil then
            verdicts.flaskCombat = grantsCombat
        end
    end
    item.flaskGrantsCombat = grantsCombat
    if grantsCombat == true then return 1000 end
    if grantsCombat == false then return -1000 end
    return 1
end

local AUGMENT_RUNE_ITEM_IDS = {
    [259085] = true,
    [246492] = true,
    [224572] = true,
    [201325] = true,
    [211495] = true,
}

local function IsAugmentRuneItem(item)
    if item.itemID and AUGMENT_RUNE_ITEM_IDS[item.itemID] then return true end
    if not IsConsumable(item) then return false end
    return item.nameLower ~= nil and item.nameLower:find("augment rune", 1, true) ~= nil
end

local function IsWeaponOilItem(item)
    if not IsConsumable(item) or IsAugmentRuneItem(item) then return false end
    if item.nameLower:match("^oil ") or item.nameLower:match(" oil ") or item.nameLower:match(" oil$") then
        return true
    end
    return TextContainsAny(item.nameLower, {
        "thalassian phoenix oil",
        "phoenix oil",
        "mana oil",
        "wizard oil",
        "weapon oil",
        "sharpening stone",
        "weightstone",
        "whetstone",
        "buzzing rune",
        "howling rune",
        "hissing rune",
        "chirping rune",
    })
end

local function FindReadyCheckItems()
    local maxBag = GetBagUpperBound()
    local bestFood, bestFoodScore
    local bestFlask, bestFlaskScore
    local bestAugment, bestOil

    for bag = 0, maxBag do
        for slot = 1, GetContainerSlotCount(bag) do
            local item = GetBagItem(bag, slot)
            if item then
                if IsFoodItem(item) then
                    local score = FoodScore(item)
                    if not bestFood or score > bestFoodScore then
                        bestFood, bestFoodScore = item, score
                    end
                end
                if IsFlaskOrPhialItem(item) then
                    local score = FlaskScore(item)
                    if not bestFlask or score > bestFlaskScore then
                        bestFlask, bestFlaskScore = item, score
                    end
                end
                if not bestAugment and IsAugmentRuneItem(item) then
                    bestAugment = item
                end
                if not bestOil and IsWeaponOilItem(item) then
                    bestOil = item
                end
            end
        end
    end

    return bestFood, bestFlask, bestAugment, bestOil
end

local function GetBagSlotItemReference(item)
    if not item then return nil end
    if item.bag ~= nil and item.slot ~= nil then
        return tostring(item.bag) .. " " .. tostring(item.slot)
    end
    return item.name or item.link
end

local function GetBagSlotDisplayText(item)
    if not item then return nil end
    if item.bag ~= nil and item.slot ~= nil then
        return string.format(L["Bag %d, slot %d"], item.bag, item.slot)
    end
    return item.name or item.link
end

local function GetItemDisplayName(item)
    if not item then return nil end
    return item.name or (item.itemID and ("item:" .. tostring(item.itemID))) or L["item"]
end

local function GetEquippedItemEquipLoc(slotID)
    local link = GetInventoryItemLink and GetInventoryItemLink("player", slotID)
    if not link then return nil end

    local equipLoc
    if C_Item and C_Item.GetItemInfoInstant then
        local ok, itemID, itemType, itemSubType, loc = pcall(C_Item.GetItemInfoInstant, link)
        if ok then equipLoc = loc end
    elseif GetItemInfoInstant then
        local ok, itemID, itemType, itemSubType, loc = pcall(GetItemInfoInstant, link)
        if ok then equipLoc = loc end
    end

    return SafeString(equipLoc)
end

local function IsEquippedOffhandWeapon()
    local offHandSlot = INVSLOT_OFFHAND or 17
    local equipLoc = GetEquippedItemEquipLoc(offHandSlot)
    return equipLoc == "INVTYPE_WEAPON" or equipLoc == "INVTYPE_WEAPONOFFHAND"
end

local function GetWeaponEnchantStatus()
    local mainHandSlot = INVSLOT_MAINHAND or 16
    local offHandSlot = INVSLOT_OFFHAND or 17
    local hasMainHandItem = GetInventoryItemLink and GetInventoryItemLink("player", mainHandSlot) ~= nil
    local offhandIsWeapon = IsEquippedOffhandWeapon()
    local hasMainHandEnchant, hasOffHandEnchant = false, false

    if GetWeaponEnchantInfo then
        local ok, mainEnchant, mainExpiration, mainCharges, mainEnchantID, offEnchant = pcall(GetWeaponEnchantInfo)
        if ok then
            hasMainHandEnchant = mainEnchant and true or false
            hasOffHandEnchant = offEnchant and true or false
        end
    end

    return {
        mainHandSlot = mainHandSlot,
        offHandSlot = offHandSlot,
        hasMainHandItem = hasMainHandItem,
        offhandIsWeapon = offhandIsWeapon,
        hasMainHandEnchant = hasMainHandEnchant,
        hasOffHandEnchant = hasOffHandEnchant,
    }
end

local function GetWeaponSlotText(slotID)
    if slotID == (INVSLOT_OFFHAND or 17) then
        return L["off hand"]
    end
    return L["main hand"]
end

local function BuildWeaponOilState(label, slotID, ready, oilItem)
    local actionItem = oilItem
    local slotText = GetWeaponSlotText(slotID)
    local missingDetail = oilItem and string.format(L["No temporary weapon enchant on %s. Click to apply %s."], slotText, GetItemDisplayName(oilItem))
        or string.format(L["No temporary weapon enchant on %s and no weapon oil/rune found in bags."], slotText)
    local actionVerb = ready and L["Reapply"] or L["Apply"]

    return {
        label = label,
        ready = ready,
        detail = ready and string.format(L["Temporary weapon enchant detected on %s."], slotText) or missingDetail,
        icon = (oilItem and oilItem.icon) or ICONS.weaponOil,
        actionExpected = not ready,
        clickWhenReady = true,
        actionItem = GetBagSlotItemReference(actionItem),
        actionBag = actionItem and actionItem.bag or nil,
        actionSlot = actionItem and actionItem.slot or nil,
        actionTargetSlot = actionItem and slotID or nil,
        actionText = actionItem and string.format(L["Click: %s %s to %s"], actionVerb, GetItemDisplayName(actionItem), slotText) or nil,
        actionBinding = actionItem and GetBagSlotDisplayText(actionItem) or nil,
    }
end

local function CanChangeSecureAttributes()
    return not (InCombatLockdown and InCombatLockdown())
end

local function GroupHasWarlock()
    if not ((IsInGroup and IsInGroup()) or (IsInRaid and IsInRaid())) then
        return false
    end

    local function UnitIsWarlock(unit)
        if not (UnitExists and UnitExists(unit) and UnitClass) then return false end
        local ok, localizedClass, classFile = pcall(UnitClass, unit)
        return ok and classFile == "WARLOCK"
    end

    if UnitIsWarlock("player") then return true end

    if IsInRaid and IsInRaid() then
        local count = (GetNumGroupMembers and GetNumGroupMembers()) or 0
        for i = 1, count do
            if UnitIsWarlock("raid" .. i) then return true end
        end
    elseif IsInGroup and IsInGroup() then
        for i = 1, 4 do
            if UnitIsWarlock("party" .. i) then return true end
        end
    end

    return false
end

local function HasFoodBuff()
    local wellFed = GetWellFedNameLower()
    return PlayerHasAura(function(name, spellID)
        if spellID and FOOD_AURA_IDS[spellID] then return true end

        if wellFed and name:find(wellFed, 1, true) then return true end
        return TextContainsAny(name, { "well fed", "well-fed", "hearty meal" })
    end)
end

local function HasFlaskOrPhial()
    return PlayerHasAura(function(name, spellID)
        if spellID and FLASK_AURA_IDS[spellID] then return true end

        return TextContainsAny(name, { "flask", "phial" })
            and not TextContainsAny(name, { "finesse", "deftness" })
    end)
end

local augmentAuraIDsResolved = false

local function EnsureAugmentAuraIDs()
    if augmentAuraIDsResolved then return end
    local getSpell = (C_Item and C_Item.GetItemSpell) or GetItemSpell
    if not getSpell then return end
    local resolvedAny = false
    for itemID in pairs(AUGMENT_RUNE_ITEM_IDS) do
        local ok, _, spellID = pcall(getSpell, itemID)
        spellID = SafeNumber(spellID)
        if ok and spellID then
            AUGMENT_AURA_IDS[spellID] = true
            resolvedAny = true
        end
    end
    if resolvedAny then augmentAuraIDsResolved = true end
end

local function HasAugmentRune()
    EnsureAugmentAuraIDs()
    return PlayerHasAura(function(name, spellID)
        if spellID and AUGMENT_AURA_IDS[spellID] then return true end
        if name == "" then return false end
        if name:find("augment rune", 1, true) then return true end
        return name:find("augment", 1, true) ~= nil and not name:find("orb", 1, true)
    end)
end


local function GetStates()
    local foodReady, foodName, foodIcon = HasFoodBuff()
    local flaskReady, flaskName, flaskIcon = HasFlaskOrPhial()
    local augmentReady, augmentName, augmentIcon = HasAugmentRune()
    local foodItem, flaskItem, augmentItem, oilItem = FindReadyCheckItems()

    if foodItem and foodItem.wellFedGrants == false then
        foodItem = nil
    end

    if flaskItem and flaskItem.flaskGrantsCombat == false then
        flaskItem = nil
    end
    local oilStatus = GetWeaponEnchantStatus()
    local foodActionItem = not foodReady and foodItem or nil
    local flaskActionItem = not flaskReady and flaskItem or nil
    local augmentActionItem = not augmentReady and augmentItem or nil

    local states = {
        {
            label = L["Food Buff"],
            ready = foodReady,
            detail = foodName or (foodItem and string.format(L["No Well Fed buff detected. Click to use %s."], GetItemDisplayName(foodItem)) or L["No Well Fed buff detected and no food found in bags."]),
            icon = foodIcon or (foodItem and foodItem.icon) or ICONS.food,
            actionExpected = not foodReady,
            actionItem = GetBagSlotItemReference(foodActionItem),
            actionBag = foodActionItem and foodActionItem.bag or nil,
            actionSlot = foodActionItem and foodActionItem.slot or nil,
            actionText = foodActionItem and string.format(L["Click: Use %s"], GetItemDisplayName(foodActionItem)) or nil,
            actionBinding = foodActionItem and GetBagSlotDisplayText(foodActionItem) or nil,
        },
        {
            label = L["Flask / Phial"],
            ready = flaskReady,
            detail = flaskName or (flaskItem and string.format(L["No flask or phial aura detected. Click to use %s."], GetItemDisplayName(flaskItem)) or L["No flask or phial aura detected and no flask/phial found in bags."]),
            icon = flaskIcon or (flaskItem and flaskItem.icon) or ICONS.flask,
            actionExpected = not flaskReady,
            actionItem = GetBagSlotItemReference(flaskActionItem),
            actionBag = flaskActionItem and flaskActionItem.bag or nil,
            actionSlot = flaskActionItem and flaskActionItem.slot or nil,
            actionText = flaskActionItem and string.format(L["Click: Use %s"], GetItemDisplayName(flaskActionItem)) or nil,
            actionBinding = flaskActionItem and GetBagSlotDisplayText(flaskActionItem) or nil,
        },
        {
            label = L["Augment Rune"],
            ready = augmentReady,
            detail = augmentName or (augmentItem and string.format(L["No augment rune aura detected. Click to use %s."], GetItemDisplayName(augmentItem)) or L["No augment rune aura detected and no augment rune found in bags."]),
            icon = (augmentItem and augmentItem.icon) or GetItemIconTexture(259085, augmentIcon or ICONS.augment),
            actionExpected = not augmentReady,
            actionItem = GetBagSlotItemReference(augmentActionItem),
            actionBag = augmentActionItem and augmentActionItem.bag or nil,
            actionSlot = augmentActionItem and augmentActionItem.slot or nil,
            actionText = augmentActionItem and string.format(L["Click: Use %s"], GetItemDisplayName(augmentActionItem)) or nil,
            actionBinding = augmentActionItem and GetBagSlotDisplayText(augmentActionItem) or nil,
        },
    }

    if GroupHasWarlock() then
        local count = GetItemCountSafe(5512)
        table.insert(states, {
            label = L["Healthstone"],
            ready = count > 0,
            detail = count > 0 and string.format(L["%d in bags."], count) or L["Warlock in group, no Healthstone found."],
            icon = GetItemIconTexture(5512, ICONS.healthstone),
        })
    end

    if oilStatus.offhandIsWeapon then
        table.insert(states, BuildWeaponOilState(L["Main Hand Oil"], oilStatus.mainHandSlot, (not oilStatus.hasMainHandItem) or oilStatus.hasMainHandEnchant, oilItem))
        table.insert(states, BuildWeaponOilState(L["Off Hand Oil"], oilStatus.offHandSlot, oilStatus.hasOffHandEnchant, oilItem))
    else
        table.insert(states, BuildWeaponOilState(L["Weapon Oil"], oilStatus.mainHandSlot, (not oilStatus.hasMainHandItem) or oilStatus.hasMainHandEnchant, oilItem))
    end

    return states
end

local function CreateRow(index)
    local row = CreateFrame("Button", "AkcQOLReadyCheckItemButton" .. index, helperFrame, "SecureActionButtonTemplate")
    row:SetSize(ICON_SIZE, ICON_SIZE)
    row:SetFrameLevel(helperFrame:GetFrameLevel() + 20)
    row:EnableMouse(true)
    if row.SetMouseClickEnabled then row:SetMouseClickEnabled(true) end
    row:RegisterForClicks("LeftButtonUp")
    row:RegisterForDrag("LeftButton")
    row:SetAttribute("useOnKeyDown", false)
    row:SetHighlightTexture(FLAT_TEX)
    local hl = row:GetHighlightTexture()
    if hl then
        hl:SetVertexColor(1, 1, 1)
        hl:SetAlpha(0.18)
        hl:SetBlendMode("ADD")
    end

    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetAllPoints()
    row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    row.missingShade = row:CreateTexture(nil, "OVERLAY")
    row.missingShade:SetTexture(FLAT_TEX)
    row.missingShade:SetDrawLayer("OVERLAY", 1)
    row.missingShade:SetAllPoints(row.icon)

    row.statusIcon = row:CreateTexture(nil, "OVERLAY")
    row.statusIcon:SetDrawLayer("OVERLAY", 7)
    row.statusIcon:SetSize(22, 22)
    row.statusIcon:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 1, -1)

    row:SetScript("OnEnter", function(self)
        if not self.tooltipTitle then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(self.tooltipTitle, 1.0, 0.82, 0.25)
        if self.tooltipStatus and self.tooltipStatus ~= "" then
            GameTooltip:AddLine(self.tooltipStatus, self.tooltipReady and 0.30 or 1.00, self.tooltipReady and 0.90 or 0.45, self.tooltipReady and 0.50 or 0.35)
        end
        if self.tooltipText and self.tooltipText ~= "" then
            GameTooltip:AddLine(self.tooltipText, 0.86, 0.88, 0.94, true)
        end
        if self.tooltipClick and self.tooltipClick ~= "" then
            GameTooltip:AddLine(self.tooltipClick, 0.35, 0.74, 1.00, true)
            if self.tooltipBinding and self.tooltipBinding ~= "" then
                GameTooltip:AddLine(self.tooltipBinding, 0.55, 0.60, 0.68, true)
            end
        elseif self.tooltipNoItem and self.tooltipNoItem ~= "" then
            GameTooltip:AddLine(self.tooltipNoItem, 1.00, 0.50, 0.36, true)
        end
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    row:SetScript("OnDragStart", function(self)
        local db = GetDB()
        if not db or db.locked or GetReadyCheckPopup() then return end
        self.dragSuppressUntil = GetTime() + 0.25
        GameTooltip:Hide()
        helperFrame:StartMoving()
        helperFrame.akcqolIsMoving = true
    end)
    row:SetScript("OnDragStop", function(self)
        self.dragSuppressUntil = GetTime() + 0.25

        if not helperFrame.akcqolIsMoving then return end
        helperFrame.akcqolIsMoving = nil
        helperFrame:StopMovingOrSizing()
        if SavePosition then SavePosition() end
    end)
    row:SetScript("PostClick", function(self, button)
        if button ~= "LeftButton" then return end
        if not self.tooltipTitle then return end
        if self.dragSuppressUntil and GetTime() < self.dragSuppressUntil then return end
        if not self.secureActionItem then
            if self.tooltipNoItem then
                print("|cff8c5cffAkc|r|cffffffffQOL|r: " .. string.format(L["No usable item found for %s."], self.tooltipTitle))
            end
            return
        end
        if C_Timer and C_Timer.After then
            C_Timer.After(0.2, ScheduleUpdate)
            C_Timer.After(0.8, ScheduleUpdate)
            C_Timer.After(1.5, ScheduleUpdate)
        else
            ScheduleUpdate()
        end
    end)

    helperFrame.rows[index] = row
    return row
end

local function SetRowClickEnabled(row, enabled)
    if not row then return end
    if row.SetMouseMotionEnabled then pcall(row.SetMouseMotionEnabled, row, true) end
    if row.SetMouseClickEnabled then pcall(row.SetMouseClickEnabled, row, true) end
    if row.RegisterForClicks then
        if enabled then
            pcall(row.RegisterForClicks, row, "LeftButtonUp")
        else
            pcall(row.RegisterForClicks, row)
        end
    end
end

local function SetRowAction(row, state)
    row.tooltipClick = state.actionText
    row.tooltipBinding = state.actionBinding
    row.tooltipNoItem = (state.actionExpected and not state.actionItem) and L["No usable item found in bags."] or nil
    row.secureActionItem = state.actionItem
    row.actionBag = state.actionBag
    row.actionSlot = state.actionSlot
    row.actionTargetSlot = state.actionTargetSlot

    if not CanChangeSecureAttributes() then
        return
    end

    row:SetAttribute("type", nil)
    row:SetAttribute("type1", nil)
    row:SetAttribute("*type1", nil)
    row:SetAttribute("item", nil)
    row:SetAttribute("item1", nil)
    row:SetAttribute("*item1", nil)
    row:SetAttribute("unit", nil)
    row:SetAttribute("unit1", nil)
    row:SetAttribute("*unit1", nil)
    row:SetAttribute("target-bag", nil)
    row:SetAttribute("target-slot", nil)
    row:SetAttribute("target-item", nil)
    row:SetAttribute("target-slot1", nil)
    row:SetAttribute("*target-slot1", nil)
    row:SetAttribute("macro", nil)
    row:SetAttribute("macrotext", nil)
    row:SetAttribute("macrotext1", nil)
    row:SetAttribute("*macrotext1", nil)

    if state.actionItem then
        row:SetAttribute("type", "item")
        row:SetAttribute("type1", "item")
        row:SetAttribute("*type1", "item")
        row:SetAttribute("item", state.actionItem)
        row:SetAttribute("item1", state.actionItem)
        row:SetAttribute("*item1", state.actionItem)
        row:SetAttribute("unit", "player")
        row:SetAttribute("unit1", "player")
        row:SetAttribute("*unit1", "player")
        if state.actionTargetSlot then
            row:SetAttribute("target-slot", state.actionTargetSlot)
            row:SetAttribute("target-slot1", state.actionTargetSlot)
            row:SetAttribute("*target-slot1", state.actionTargetSlot)
        end
    end

    SetRowClickEnabled(row, (not state.ready) or (state.clickWhenReady and state.actionItem))
end

local function SetRow(row, state)
    row.icon:SetTexture(state.icon or ICONS.food)
    row.tooltipTitle = state.label
    row.tooltipText = state.detail or ""
    row.tooltipReady = state.ready and true or false
    row.tooltipStatus = state.ready and L["OK"] or L["Missing"]
    SetRowAction(row, state)

    if row.icon.SetDesaturated then row.icon:SetDesaturated(not state.ready) end
    row.statusIcon:SetTexCoord(0, 1, 0, 1)
    row.statusIcon:SetBlendMode("BLEND")
    row.statusIcon:SetVertexColor(1, 1, 1, 1)
    row.statusIcon:SetAlpha(1)
    row.statusIcon:Show()

    if state.ready then
        row.statusIcon:SetTexture("Interface\\RAIDFRAME\\ReadyCheck-Ready")
        row.missingShade:SetVertexColor(0.00, 0.00, 0.00, 0.00)
    else
        row.statusIcon:SetTexture("Interface\\RAIDFRAME\\ReadyCheck-NotReady")
        row.missingShade:SetVertexColor(0.00, 0.00, 0.00, 0.45)
    end
end

local function FrameIsShown(frame)
    if not frame or type(frame.IsShown) ~= "function" then return false end
    local ok, shown = pcall(frame.IsShown, frame)
    return ok and shown == true
end

local function TextLooksLikeReadyCheck(text)
    text = Lower(text)
    return text:find("ready", 1, true) and text:find("check", 1, true)
end

local function IsReadyCheckPopup(frame)
    if not FrameIsShown(frame) then return false end

    local which = SafeString(frame.which)
    if which and TextLooksLikeReadyCheck(which) then return true end

    local textFrame = frame.Text or frame.text
    if not textFrame and frame.GetTextFontString then
        local ok, result = pcall(frame.GetTextFontString, frame)
        if ok then textFrame = result end
    end

    local text
    if textFrame and textFrame.GetText then
        local ok, result = pcall(textFrame.GetText, textFrame)
        if ok then text = SafeString(result) end
    end
    return text and TextLooksLikeReadyCheck(text)
end

function GetReadyCheckPopup()
    if StaticPopup_Visible then
        for _, popupID in ipairs({ "READY_CHECK", "READY_CHECK_CONFIRM", "CONFIRM_READY_CHECK" }) do
            local ok, frame = pcall(StaticPopup_Visible, popupID)
            if ok and IsReadyCheckPopup(frame) then return frame end
        end
    end

    if type(StaticPopup_DisplayedFrames) == "table" then
        for _, frame in ipairs(StaticPopup_DisplayedFrames) do
            if IsReadyCheckPopup(frame) then return frame end
        end
    end

    for i = 1, 4 do
        local frame = _G["StaticPopup" .. i]
        if IsReadyCheckPopup(frame) then return frame end
    end

    return nil
end

local function GetReadyCheckFitWidth(contentWidth)
    local width = math.max(contentWidth, ICON_SIZE)

    local parentWidth
    if UIParent and UIParent.GetWidth then
        local ok, parentW = pcall(UIParent.GetWidth, UIParent)
        if ok then parentWidth = parentW end
    end
    if parentWidth and parentWidth > 80 then
        width = math.min(width, parentWidth - 40)
    end

    return width, GetReadyCheckPopup()
end

local function PositionFrame()
    local db = GetDB()
    if not db or not helperFrame then return end

    helperFrame:ClearAllPoints()
    local popup = GetReadyCheckPopup()
    if popup then
        helperFrame:SetPoint("BOTTOM", popup, "TOP", 0, READY_POPUP_GAP)
        return
    end

    helperFrame:SetPoint(db.point, UIParent, db.relPoint, db.xOfs, db.yOfs)
end

function SavePosition()
    local db = GetDB()
    if not db or not helperFrame then return end

    local point, relativeTo, relPoint, xOfs, yOfs = helperFrame:GetPoint()

    if relativeTo ~= nil and relativeTo ~= UIParent then return end
    db.point = point or "CENTER"
    db.relPoint = relPoint or "CENTER"
    db.xOfs = xOfs or 0
    db.yOfs = yOfs or DEFAULT_Y_OFFSET
end

local function EnsureFrame()
    if helperFrame then return helperFrame end

    local f = CreateFrame("Frame", "AkcQOLReadyCheckHelperFrame", UIParent, "BackdropTemplate")
    f:SetSize(DEFAULT_FRAME_WIDTH, FRAME_HEIGHT)
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(900)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:EnableMouse(false)
    f.rows = {}
    f:Hide()

    local header = f:CreateTexture(nil, "BACKGROUND")
    header:SetTexture(FLAT_TEX)
    header:SetVertexColor(Theme.rgba(Theme.colors.header))
    header:SetPoint("TOPLEFT", 1, -1)
    header:SetPoint("TOPRIGHT", -1, -1)
    header:SetHeight(38)
    header:Hide()

    local accent = f:CreateTexture(nil, "ARTWORK")
    accent:SetTexture(FLAT_TEX)
    accent:SetVertexColor(Theme.rgba(Theme.colors.accent))
    accent:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -39)
    accent:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -39)
    accent:SetHeight(1)
    accent:Hide()

    local title = f:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(title, 14, FONT_FLAGS, true)
    title:SetPoint("TOPLEFT", f, "TOPLEFT", 14, -11)
    title:SetText(Theme.Accent(L["Ready"]) .. " " .. L["Check"])
    Theme.StyleTitle(title)
    title:Hide()
    f.title = title

    local summary = f:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(summary, 12, FONT_FLAGS)
    summary:SetPoint("TOPRIGHT", f, "TOPRIGHT", -44, -12)
    summary:SetTextColor(Theme.rgba(Theme.colors.text))
    summary:Hide()
    f.summary = summary

    local closeButton = CreateFrame("Button", nil, f)
    closeButton:SetSize(18, 18)

    closeButton:SetPoint("LEFT", f, "RIGHT", 6, 0)
    closeButton:SetHitRectInsets(-4, -4, -4, -4)

    closeButton.edge = closeButton:CreateTexture(nil, "BACKGROUND")
    closeButton.edge:SetTexture(FLAT_TEX)
    closeButton.edge:SetAllPoints()
    closeButton.edge:SetVertexColor(Theme.rgba(Theme.colors.border))

    closeButton.bg = closeButton:CreateTexture(nil, "BACKGROUND")
    closeButton.bg:SetDrawLayer("BACKGROUND", 1)
    closeButton.bg:SetTexture(FLAT_TEX)
    closeButton.bg:SetPoint("TOPLEFT", closeButton, "TOPLEFT", 1, -1)
    closeButton.bg:SetPoint("BOTTOMRIGHT", closeButton, "BOTTOMRIGHT", -1, 1)
    closeButton.bg:SetVertexColor(0.075, 0.070, 0.095, 0.92)

    closeButton.text = closeButton:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    Theme.SetFont(closeButton.text, 13, FONT_FLAGS, true)
    closeButton.text:SetAllPoints()
    closeButton.text:SetJustifyH("CENTER")
    closeButton.text:SetJustifyV("MIDDLE")
    closeButton.text:SetTextColor(Theme.rgba(Theme.colors.textMuted))
    closeButton.text:SetText("X")

    closeButton:SetScript("OnClick", function()
        addon:DismissReadyCheckHelper()
    end)
    closeButton:SetScript("OnEnter", function(self)
        self.bg:SetVertexColor(0.230, 0.045, 0.042, 0.94)
        self.edge:SetVertexColor(Theme.rgba(Theme.colors.bad))
        self.text:SetTextColor(1.00, 0.62, 0.58, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(L["Close"], 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    closeButton:SetScript("OnLeave", function(self)
        self.bg:SetVertexColor(0.075, 0.070, 0.095, 0.92)
        self.edge:SetVertexColor(Theme.rgba(Theme.colors.border))
        self.text:SetTextColor(Theme.rgba(Theme.colors.textMuted))
        GameTooltip:Hide()
    end)
    closeButton:Hide()
    f.closeButton = closeButton

    local footer = f:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(footer, 10, FONT_FLAGS)
    footer:SetPoint("BOTTOM", f, "BOTTOM", 0, 9)
    footer:SetTextColor(Theme.rgba(Theme.colors.textMuted))
    footer:Hide()
    f.footer = footer

    helperFrame = f
    addon:UpdateReadyCheckHelperLock()
    PositionFrame()
    return f
end

function addon:UpdateReadyCheckHelperLock()
    if not helperFrame then return end
    helperFrame.footer:SetText("")
end

function addon:UpdateReadyCheckHelper()
    if not CanChangeSecureAttributes() then return end

    local f = EnsureFrame()
    local states = GetStates()
    local readyCount = 0
    local contentWidth = (#states * ICON_SIZE) + (math.max(#states - 1, 0) * ICON_SPACING)
    local frameWidth = GetReadyCheckFitWidth(contentWidth)
    local startX = math.floor((frameWidth - contentWidth) / 2)
    if startX < 0 then startX = 0 end

    f:SetWidth(frameWidth)
    PositionFrame()

    for i, state in ipairs(states) do
        local row = f.rows[i] or CreateRow(i)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", f, "TOPLEFT", startX + ((i - 1) * (ICON_SIZE + ICON_SPACING)), -ICON_TOP_INSET)
        SetRow(row, state)
        row:Show()
        if state.ready then readyCount = readyCount + 1 end
    end

    for i = #states + 1, #f.rows do
        f.rows[i]:Hide()
    end

    f.summary:SetText(string.format("%d/%d", readyCount, #states))
    if readyCount == #states then
        f.summary:SetTextColor(Theme.rgba(Theme.colors.good))
    else
        f.summary:SetTextColor(Theme.rgba(Theme.colors.bad))
    end

    if f.closeButton then
        f.closeButton:Show()
    end

    f:SetHeight(FRAME_HEIGHT)
end

RefreshReadyCheckFit = function()
    if not helperFrame or not helperFrame:IsShown() then return end
    addon:UpdateReadyCheckHelper()
end

local function QueueReadyCheckFitRefresh()
    if not C_Timer or not C_Timer.After then
        RefreshReadyCheckFit()
        return
    end

    C_Timer.After(0.05, RefreshReadyCheckFit)
    C_Timer.After(0.20, RefreshReadyCheckFit)
    C_Timer.After(0.50, RefreshReadyCheckFit)
end

function addon:HideReadyCheckHelper()
    hideToken = hideToken + 1
    if helperFrame then
        if not CanChangeSecureAttributes() then
            hideQueued = true
            return
        end
        hideQueued = false
        helperFrame:Hide()
    end
end

function addon:DismissReadyCheckHelper()
    manuallyDismissed = true
    addon:HideReadyCheckHelper()
end

function addon:ShowReadyCheckHelper(duration, force)
    local db = GetDB()
    if not db or (not force and db.enabled == false) then return end
    if not CanChangeSecureAttributes() then return end

    manuallyDismissed = false
    hideToken = hideToken + 1
    local token = hideToken

    EnsureFrame()
    PositionFrame()
    addon:UpdateReadyCheckHelper()
    helperFrame:Show()
    QueueReadyCheckFitRefresh()

    if duration and duration > 0 and C_Timer and C_Timer.After then
        C_Timer.After(math.min(duration + 1, 45), function()
            if token == hideToken then
                addon:HideReadyCheckHelper()
            end
        end)
    end
end

ScheduleUpdate = function()
    if manuallyDismissed or updateQueued or not (helperFrame and helperFrame:IsShown()) then return end
    updateQueued = true

    if C_Timer and C_Timer.After then
        C_Timer.After(0.12, function()
            updateQueued = false
            if helperFrame and helperFrame:IsShown() then
                addon:UpdateReadyCheckHelper()
            end
        end)
    else
        updateQueued = false
        addon:UpdateReadyCheckHelper()
    end
end

function addon:TestReadyCheckHelper()
    addon:ShowReadyCheckHelper(10, true)
end

function addon:ResetReadyCheckHelperPosition()
    local db = GetDB()
    if not db then return end
    db.point = "CENTER"
    db.relPoint = "CENTER"
    db.xOfs = 0
    db.yOfs = DEFAULT_Y_OFFSET
    if helperFrame then
        PositionFrame()
    end
end

function addon:InitializeReadyCheckHelper()
    EnsureFrame()

    if not eventFrame then
        eventFrame = CreateFrame("Frame", "AkcQOLReadyCheckHelperEventFrame")
        eventFrame:SetScript("OnEvent", function(_, event, arg1, arg2)
            if event == "READY_CHECK" then
                addon:ShowReadyCheckHelper(arg2)
            elseif event == "READY_CHECK_FINISHED" then
                manuallyDismissed = false
                addon:HideReadyCheckHelper()
            elseif event == "UNIT_AURA" then
                if arg1 == "player" then ScheduleUpdate() end
            elseif event == "UNIT_INVENTORY_CHANGED" then
                if arg1 == "player" then ScheduleUpdate() end
            elseif event == "BAG_UPDATE_DELAYED" then
                wipe(tooltipVerdictCache)
                ScheduleUpdate()
            elseif event == "PLAYER_REGEN_ENABLED" then
                if hideQueued then
                    addon:HideReadyCheckHelper()
                else
                    ScheduleUpdate()
                end
            else
                ScheduleUpdate()
            end
        end)
    end

    eventFrame:UnregisterAllEvents()
    eventFrame:RegisterEvent("READY_CHECK")
    eventFrame:RegisterEvent("READY_CHECK_FINISHED")

    if not pcall(eventFrame.RegisterUnitEvent, eventFrame, "UNIT_AURA", "player") then
        eventFrame:RegisterEvent("UNIT_AURA")
    end
    eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
    eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
    eventFrame:RegisterEvent("UNIT_INVENTORY_CHANGED")
    eventFrame:RegisterEvent("GET_ITEM_INFO_RECEIVED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
end

function addon:DisableReadyCheckHelper()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
    end
    addon:HideReadyCheckHelper()
end
