
local L = AkcQOL_L
local Theme = AkcQOL_Theme

local FONT_FACE = GameFontNormal and GameFontNormal:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_FLAGS = "OUTLINE"

local function ApplyHUDFont(fontString, size)
    if Theme and Theme.SetFont and Theme.SetFont(fontString, size, FONT_FLAGS) then return end
    fontString:SetFont(FONT_FACE, size, FONT_FLAGS)
end

local hudFrame, hitOverlay, talentText, buildText, durabilityText, lootSpecIcon, lootSpecText
local hudUpdateTicker

local function GetActiveLoadoutName()
    local name
    pcall(function()
        local specIndex = GetSpecialization()
        if not specIndex then return end
        local specID = GetSpecializationInfo(specIndex)
        if not specID then return end

        local loadoutConfigID = C_ClassTalents.GetLastSelectedSavedConfigID(specID)
        if loadoutConfigID then
            local info = C_Traits.GetConfigInfo(loadoutConfigID)
            if info and info.name and info.name ~= "" then
                name = info.name
            end
        end
    end)
    return name
end

local DURABILITY_SLOTS = { 1, 3, 5, 6, 7, 8, 9, 10, 16, 17 }

local function GetLowestDurability()
    local lowest = 100
    for _, slotID in ipairs(DURABILITY_SLOTS) do
        local cur, mx = GetInventoryItemDurability(slotID)
        if cur and mx and mx > 0 then
            local pct = math.floor((cur / mx) * 100)
            if pct < lowest then lowest = pct end
        end
    end
    return lowest
end

local function GetLootSpecInfo()
    local lootSpecID = GetLootSpecialization()
    if lootSpecID == 0 then

        local specIndex = GetSpecialization()
        if specIndex then
            local _, name, _, icon = GetSpecializationInfo(specIndex)
            return name, icon
        end
        return "?", nil
    else
        local _, name, _, icon = GetSpecializationInfoByID(lootSpecID)
        return name, icon
    end
end

local function CreateHUD()
    if hudFrame then return end

    hudFrame = CreateFrame("Frame", "AkcQOLHUDFrame", UIParent)
    hudFrame:SetSize(220, 48)
    hudFrame:SetFrameStrata("LOW")

    hudFrame:SetClampedToScreen(false)

    local savedScale = AkcQOLDB and AkcQOLDB.global and tonumber(AkcQOLDB.global.hudScale) or 1.0
    if savedScale <= 0 then savedScale = 1.0 end
    hudFrame:SetScale(savedScale)

    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.hudPosX then
        hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT",
            AkcQOLDB.global.hudPosX / savedScale, (AkcQOLDB.global.hudPosY or 0) / savedScale)
    else
        hudFrame:SetPoint("TOP", UIParent, "TOP", 0, -10)
    end

    hudFrame:SetMovable(true)
    hudFrame:EnableMouse(true)
    hudFrame:RegisterForDrag("LeftButton")
    hudFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    local function LockHUDPosition()
        hudFrame:StopMovingOrSizing()
        local left, top = hudFrame:GetLeft(), hudFrame:GetTop()
        if left and top then
            hudFrame:ClearAllPoints()
            hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
            if AkcQOLDB and AkcQOLDB.global then

                local s = hudFrame:GetScale() or 1
                AkcQOLDB.global.hudPosX = left * s
                AkcQOLDB.global.hudPosY = top * s
                AkcQOLDB.global.hudPosScreenSpace = true
            end
        end
    end

    hudFrame:SetScript("OnDragStop", LockHUDPosition)

    hitOverlay = CreateFrame("Frame", nil, hudFrame)
    hitOverlay:SetAllPoints()
    hitOverlay:EnableMouse(true)
    hitOverlay:RegisterForDrag("LeftButton")
    hitOverlay:SetScript("OnDragStart", function() hudFrame:StartMoving() end)
    hitOverlay:SetScript("OnDragStop", LockHUDPosition)

    talentText = hitOverlay:CreateFontString(nil, "OVERLAY")
    ApplyHUDFont(talentText, 12)
    talentText:SetPoint("TOPLEFT", hudFrame, "TOPLEFT", 1, -1)
    talentText:SetJustifyH("LEFT")
    talentText:SetText("|cFF888888?|r")

    buildText = hitOverlay:CreateFontString(nil, "OVERLAY")
    ApplyHUDFont(buildText, 11)
    buildText:SetPoint("TOPLEFT", talentText, "BOTTOMLEFT", 0, -1)
    buildText:SetJustifyH("LEFT")
    buildText:SetText("")

    durabilityText = hitOverlay:CreateFontString(nil, "OVERLAY")
    ApplyHUDFont(durabilityText, 11)
    durabilityText:SetJustifyH("LEFT")
    durabilityText:SetText("|cFFAAAAAA" .. L["Durability:"] .. " 100%|r")

    lootSpecText = hitOverlay:CreateFontString(nil, "OVERLAY")
    ApplyHUDFont(lootSpecText, 11)
    lootSpecText:SetPoint("LEFT", durabilityText, "RIGHT", 8, 0)
    lootSpecText:SetJustifyH("LEFT")
    lootSpecText:SetText("|cFFAAAAAA" .. L["Loot:"] .. "|r")

    lootSpecIcon = hitOverlay:CreateTexture(nil, "OVERLAY")
    lootSpecIcon:SetSize(16, 16)
    lootSpecIcon:SetPoint("LEFT", lootSpecText, "RIGHT", 3, 0)

    _G.AkcQOLHUDFrame = hudFrame

    if _G.AkcQOL_ApplyHUDLock then _G.AkcQOL_ApplyHUDLock() end
end

local function UpdateHUD()
    if not hudFrame or not hudFrame:IsShown() then return end
    if not pcall(function() GetSpecialization() end) then return end

    local specIndex = GetSpecialization()
    local specName = specIndex and select(2, GetSpecializationInfo(specIndex)) or "?"
    local _, className = UnitClass("player")
    local classColor = RAID_CLASS_COLORS and RAID_CLASS_COLORS[className]
    local colorStr = classColor and classColor.colorStr or "FFFFFFFF"

    local loadoutName = GetActiveLoadoutName()
    if loadoutName then
        talentText:SetText("|c" .. colorStr .. specName .. "|r |cFF888888-|r |cFF00FF00" .. loadoutName .. "|r")
    else
        talentText:SetText("|c" .. colorStr .. specName .. "|r")
    end

    local lastBuild = _G.AkcQOL_LastLoadedBuild
    local buildName = nil
    if lastBuild and lastBuild:find("^WCL:") then
        buildName = lastBuild:sub(5)
    end

    durabilityText:ClearAllPoints()
    if buildName then
        buildText:SetText("|cFFFFAA00" .. buildName .. "|r")
        buildText:Show()
        durabilityText:SetPoint("TOPLEFT", buildText, "BOTTOMLEFT", 0, -1)
    else
        buildText:SetText("")
        buildText:Hide()
        durabilityText:SetPoint("TOPLEFT", talentText, "BOTTOMLEFT", 0, -1)
    end

    local dur = GetLowestDurability()
    local durColor = "00FF00"
    if dur <= 25 then durColor = "FF0000"
    elseif dur <= 50 then durColor = "FFAA00" end
    durabilityText:SetText("|cFFAAAAAA" .. L["Durability:"] .. " |r|cFF" .. durColor .. dur .. "%|r")

    local specName, specIcon = GetLootSpecInfo()
    if specIcon then
        lootSpecIcon:SetTexture(specIcon)
        lootSpecIcon:Show()
    else
        lootSpecIcon:Hide()
    end
    lootSpecText:SetText("|cFFAAAAAA" .. L["Loot:"] .. "|r")

    local PAD = 2
    local buildShown = buildText:IsShown()
    local iconShown = lootSpecIcon:IsShown()

    local wTalent = talentText:GetStringWidth() or 0
    local wBuild = buildShown and (buildText:GetStringWidth() or 0) or 0
    local wLootRow = (durabilityText:GetStringWidth() or 0) + 8
        + (lootSpecText:GetStringWidth() or 0) + (iconShown and (3 + 16) or 0)
    local maxW = math.max(wTalent, wBuild, wLootRow, 16)

    local hTalent = talentText:GetStringHeight() or 12
    local hBuildRow = buildShown and ((buildText:GetStringHeight() or 11) + 1) or 0
    local hLootRow = math.max(durabilityText:GetStringHeight() or 11, iconShown and 16 or 0) + 1
    local totalH = hTalent + hBuildRow + hLootRow

    hudFrame:SetSize(math.ceil(maxW) + PAD, math.ceil(totalH) + PAD)
end

local function ShowHUD()
    if not hudFrame then CreateHUD() end
    hudFrame:Show()

    if not hudUpdateTicker then
        hudUpdateTicker = C_Timer.NewTicker(10, UpdateHUD)
    end
    UpdateHUD()
end

local function HideHUD()
    if hudFrame then hudFrame:Hide() end
    if hudUpdateTicker then
        hudUpdateTicker:Cancel()
        hudUpdateTicker = nil
    end
end

local function ApplyHUDVisibility()
    if AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.showHUD ~= false then
        ShowHUD()
    else
        HideHUD()
    end
end
_G.AkcQOL_ApplyHUDVisibility = ApplyHUDVisibility

_G.AkcQOL_ApplyHUDLock = function()
    if not hudFrame then return end
    local locked = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.hudLocked
    local mouse = not locked
    hudFrame:EnableMouse(mouse)
    if hitOverlay then hitOverlay:EnableMouse(mouse) end

    if _G.AkcQOL_RegisterUnlockable then
        local function Lock()
            if not (AkcQOLDB and AkcQOLDB.global) then return end
            if AkcQOLDB.global.hudLocked then return end
            AkcQOLDB.global.hudLocked = true
            _G.AkcQOL_ApplyHUDLock()
        end
        _G.AkcQOL_RegisterUnlockable("hud", hudFrame, Lock)
        if hitOverlay then _G.AkcQOL_RegisterUnlockable("hudOverlay", hitOverlay, Lock) end
    end
end

_G.AkcQOL_SetHUDScale = function(delta)
    if not AkcQOLDB or not AkcQOLDB.global then return end
    local g = AkcQOLDB.global
    local cur = g.hudScale or 1.0
    local newScale = cur + delta
    if newScale < 0.5 then newScale = 0.5 end
    if newScale > 3.0 then newScale = 3.0 end
    g.hudScale = newScale
    if hudFrame then
        hudFrame:SetScale(newScale)

        if g.hudPosX and g.hudPosY then
            hudFrame:ClearAllPoints()
            hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT",
                g.hudPosX / newScale, g.hudPosY / newScale)
        end
    end
end

local function EnsureHUDPreviewHighlight()
    if not hudFrame or hudFrame.previewParts then return end
    local fill = hudFrame:CreateTexture(nil, "BACKGROUND")
    fill:SetAllPoints(hudFrame)
    fill:SetColorTexture(0.10, 0.55, 1.0, 0.16)
    local function edge()
        local t = hudFrame:CreateTexture(nil, "BORDER")
        t:SetColorTexture(0.30, 0.80, 1.0, 0.9)
        return t
    end
    local top, bot, lft, rgt = edge(), edge(), edge(), edge()
    top:SetPoint("TOPLEFT", hudFrame, "TOPLEFT");  top:SetPoint("TOPRIGHT", hudFrame, "TOPRIGHT");  top:SetHeight(1)
    bot:SetPoint("BOTTOMLEFT", hudFrame, "BOTTOMLEFT"); bot:SetPoint("BOTTOMRIGHT", hudFrame, "BOTTOMRIGHT"); bot:SetHeight(1)
    lft:SetPoint("TOPLEFT", hudFrame, "TOPLEFT");  lft:SetPoint("BOTTOMLEFT", hudFrame, "BOTTOMLEFT");  lft:SetWidth(1)
    rgt:SetPoint("TOPRIGHT", hudFrame, "TOPRIGHT"); rgt:SetPoint("BOTTOMRIGHT", hudFrame, "BOTTOMRIGHT"); rgt:SetWidth(1)
    hudFrame.previewParts = { fill, top, bot, lft, rgt }
end

local function SetHUDPreviewHighlight(on)
    if on then EnsureHUDPreviewHighlight() end
    if hudFrame and hudFrame.previewParts then
        for _, t in ipairs(hudFrame.previewParts) do
            if on then t:Show() else t:Hide() end
        end
    end
end

local hudPreviewToken = 0
_G.AkcQOL_PreviewHUD = function()
    if not hudFrame then CreateHUD() end
    hudPreviewToken = hudPreviewToken + 1
    local token = hudPreviewToken
    hudFrame:Show()
    hudFrame:SetFrameStrata("TOOLTIP")
    SetHUDPreviewHighlight(true)
    UpdateHUD()
    if C_Timer and C_Timer.After then
        C_Timer.After(8, function()
            if token ~= hudPreviewToken then return end
            SetHUDPreviewHighlight(false)
            if hudFrame then hudFrame:SetFrameStrata("LOW") end
            ApplyHUDVisibility()
        end)
    end
end

_G.AkcQOL_ResetHUDPosition = function()
    if not hudFrame then CreateHUD() end
    hudFrame:Show()
    UpdateHUD()
    hudFrame:ClearAllPoints()
    hudFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    local left, top = hudFrame:GetLeft(), hudFrame:GetTop()
    if left and top then
        hudFrame:ClearAllPoints()
        hudFrame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
        if AkcQOLDB and AkcQOLDB.global then
            local s = hudFrame:GetScale() or 1
            AkcQOLDB.global.hudPosX = left * s
            AkcQOLDB.global.hudPosY = top * s
            AkcQOLDB.global.hudPosScreenSpace = true
        end
    end
    if _G.AkcQOL_PreviewHUD then _G.AkcQOL_PreviewHUD() end
end

_G.AkcQOL_ResetHUDDefaults = function()
    if not AkcQOLDB or not AkcQOLDB.global then return end
    local g = AkcQOLDB.global
    g.showHUD = false
    g.hudScale = 1.0
    g.hudPosX, g.hudPosY = nil, nil
    if hudFrame then
        hudFrame:SetScale(1.0)
        hudFrame:ClearAllPoints()
        hudFrame:SetPoint("TOP", UIParent, "TOP", 0, -10)
    end
    ApplyHUDVisibility()
end

local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
initFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
initFrame:RegisterEvent("ACTIVE_COMBAT_CONFIG_CHANGED")
initFrame:RegisterEvent("TRAIT_CONFIG_LIST_UPDATED")
initFrame:RegisterEvent("UPDATE_INVENTORY_DURABILITY")
initFrame:RegisterEvent("PLAYER_LOOT_SPEC_UPDATED")
initFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        if not AkcQOLDB then AkcQOLDB = {} end
        if not AkcQOLDB.global then AkcQOLDB.global = {} end
        if AkcQOLDB.global.showHUD == nil then AkcQOLDB.global.showHUD = false end
        if not AkcQOLDB.global.hudScale then AkcQOLDB.global.hudScale = 1.0 end

        if AkcQOLDB.global.hudPosX and not AkcQOLDB.global.hudPosScreenSpace then
            local s = AkcQOLDB.global.hudScale or 1.0
            AkcQOLDB.global.hudPosX = AkcQOLDB.global.hudPosX * s
            AkcQOLDB.global.hudPosY = (AkcQOLDB.global.hudPosY or 0) * s
            AkcQOLDB.global.hudPosScreenSpace = true
        end

        if AkcQOLDB.global.lastLoadedBuild then
            _G.AkcQOL_LastLoadedBuild = AkcQOLDB.global.lastLoadedBuild
        end
        ApplyHUDVisibility()
    elseif event == "UPDATE_INVENTORY_DURABILITY" or event == "PLAYER_LOOT_SPEC_UPDATED" then
        UpdateHUD()
    elseif event == "ACTIVE_COMBAT_CONFIG_CHANGED" then

        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(0.5, UpdateHUD)
        end
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then

        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(1.0, UpdateHUD)
            C_Timer.After(3.0, UpdateHUD)
        end
    elseif event == "TRAIT_CONFIG_UPDATED" or event == "TRAIT_CONFIG_LIST_UPDATED" then
        if hudFrame and hudFrame:IsShown() then
            C_Timer.After(0.5, UpdateHUD)
            C_Timer.After(1.5, UpdateHUD)
        end
    end
end)
