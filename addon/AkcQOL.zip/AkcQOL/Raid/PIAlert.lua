local _, addon = ...

local L = AkcQOL_L

local PI_SPELL_ID = 10060
local PI_SPELL_NAME = "Power Infusion"
local DEFAULT_MESSAGE = "Power Infusion on YOU!"
local Theme = _G.AkcQOL_Theme

local eventFrame
local alertFrame
local pollTicker
local hadPI = false
local lastAlertTime = 0
local hideToken = 0
local checkToken = 0
local combatStartedAt = nil

local PI_SOUND_CANDIDATES
local PI_SOUND_STYLE_ORDER = {}
local PI_SOUND_STYLES = {}
local PI_SOUND_MENU = { { label = L["Alerts"], entries = {} } }
local CDM_CATEGORY_ORDER = { "Instruments", "Animals", "Impacts", "War3", "War2", "Devices" }
local CDM_CATEGORY_LABEL = {}
local cdmSoundsBuilt = false

local function RebuildPISoundLocale()
    PI_SOUND_CANDIDATES = {
        { key = "raidwarning", label = L["Raid Warning"],   kit = "RAID_WARNING", id = 8959 },
        { key = "readycheck",  label = L["Ready Check"],     kit = "READY_CHECK" },
        { key = "alarm",       label = L["Alarm Clock"],     kit = "ALARM_CLOCK_WARNING_3" },
        { key = "bosswarn",    label = L["Boss Warning"],    kit = "UI_RAID_BOSS_WHISPER_WARNING" },
        { key = "questdone",   label = L["Quest Complete"],  kit = "IG_QUEST_LIST_COMPLETE" },
        { key = "ping",        label = L["Map Ping"],        kit = "MAP_PING" },
        { key = "whisper",     label = L["Whisper"],         kit = "TELL_MESSAGE" },
        { key = "queue",       label = L["Queue Pop"],       kit = "PVP_THROUGH_QUEUE" },
        { key = "auction",     label = L["Auction Bell"],    kit = "AUCTION_WINDOW_OPEN" },
        { key = "invite",      label = L["Group Invite"],    kit = "IG_PLAYER_INVITE_A" },
        { key = "levelup",     label = L["Level Up"],        kit = "LEVELUP" },
    }
    wipe(PI_SOUND_STYLES)
    wipe(PI_SOUND_STYLE_ORDER)
    for _, c in ipairs(PI_SOUND_CANDIDATES) do
        local id = (type(SOUNDKIT) == "table" and SOUNDKIT[c.kit]) or c.id
        if type(id) == "number" then
            PI_SOUND_STYLES[c.key] = { label = c.label, soundId = id }
            PI_SOUND_STYLE_ORDER[#PI_SOUND_STYLE_ORDER + 1] = c.key
        end
    end
    PI_SOUND_MENU[1].label = L["Alerts"]
    wipe(PI_SOUND_MENU[1].entries)
    for _, key in ipairs(PI_SOUND_STYLE_ORDER) do
        local e = PI_SOUND_STYLES[key]
        PI_SOUND_MENU[1].entries[#PI_SOUND_MENU[1].entries + 1] = { key = key, name = e.label }
    end
    CDM_CATEGORY_LABEL.Instruments = L["Instruments"]
    CDM_CATEGORY_LABEL.Animals = L["Animals"]
    CDM_CATEGORY_LABEL.Impacts = L["Impacts"]
    CDM_CATEGORY_LABEL.War3 = L["Warcraft 3"]
    CDM_CATEGORY_LABEL.War2 = L["Warcraft 2"]
    CDM_CATEGORY_LABEL.Devices = L["Devices"]
    -- Rebuild the Cooldown Manager sounds in the new language too.
    cdmSoundsBuilt = false
    for i = #PI_SOUND_MENU, 2, -1 do
        table.remove(PI_SOUND_MENU, i)
    end
end
RebuildPISoundLocale()
if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(RebuildPISoundLocale) end
local function EnsureCDMSounds()
    if cdmSoundsBuilt then return end
    if C_AddOns and C_AddOns.LoadAddOn then
        pcall(C_AddOns.LoadAddOn, "Blizzard_CooldownViewer")
    end
    local data = rawget(_G, "CooldownViewerSoundData")
    if type(data) ~= "table" then return end
    cdmSoundsBuilt = true
    for _, cat in ipairs(CDM_CATEGORY_ORDER) do
        local entries = data[cat]
        if type(entries) == "table" then
            local catLabel = CDM_CATEGORY_LABEL[cat] or cat
            local menuCat = { label = catLabel, entries = {} }
            for _, e in ipairs(entries) do
                local id, text = e.soundKitID, e.text
                if type(id) == "number" and type(text) == "string" and text ~= "" then
                    local key = "cdm" .. id
                    if not PI_SOUND_STYLES[key] then
                        PI_SOUND_STYLES[key] = { label = catLabel .. ": " .. text, soundId = id }
                        PI_SOUND_STYLE_ORDER[#PI_SOUND_STYLE_ORDER + 1] = key
                    end
                    menuCat.entries[#menuCat.entries + 1] = { key = key, name = text }
                end
            end
            if #menuCat.entries > 0 then
                PI_SOUND_MENU[#PI_SOUND_MENU + 1] = menuCat
            end
        end
    end
end

local function IsCDMSoundKey(style)
    return type(style) == "string" and style:match("^cdm%d+$") ~= nil
end

local DEFAULT_SOUND_STYLE = "raidwarning"
local DEFAULT_SOUND_VOLUME = 100

local function IsSecret(value)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        if ok and isSecret == true then return true end
    end
    return type(value) == "nil"
end

local function IsSecretStrict(value)
    if type(issecretvalue) == "function" then
        local ok, isSecret = pcall(issecretvalue, value)
        return ok and isSecret == true
    end
    return false
end

local function SafeString(value)
    if IsSecret(value) then return nil end
    local ok, text = pcall(tostring, value)
    if ok and type(text) == "string" and text ~= "" then return text end
    return nil
end

local function SafeNumber(value)
    if IsSecret(value) or type(value) ~= "number" then return nil end
    return value
end

local function NormalizeSoundStyle(style)
    if PI_SOUND_STYLES[style or ""] or IsCDMSoundKey(style) then
        return style
    end
    return DEFAULT_SOUND_STYLE
end

local function NormalizeSoundVolume(volume)
    volume = tonumber(volume) or DEFAULT_SOUND_VOLUME
    if volume < 0 then volume = 0 elseif volume > 100 then volume = 100 end
    return math.floor(volume + 0.5)
end

local function GetPISpellName()
    if C_Spell and C_Spell.GetSpellName then
        local ok, name = pcall(C_Spell.GetSpellName, PI_SPELL_ID)
        if ok then
            name = SafeString(name)
            if name then return name end
        end
    end

    if GetSpellInfo then
        local ok, name = pcall(GetSpellInfo, PI_SPELL_ID)
        if ok then
            name = SafeString(name)
            if name then return name end
        end
    end

    return PI_SPELL_NAME
end

local function AuraIsPowerInfusion(aura)
    if type(aura) ~= "table" then return false end

    local spellID = aura.spellId
    if IsSecret(spellID) then spellID = aura.spellID end
    spellID = SafeNumber(spellID)
    if spellID == PI_SPELL_ID then return true end

    local auraName = SafeString(aura.name)
    if not auraName then return false end

    local localizedName = GetPISpellName()
    return auraName == PI_SPELL_NAME or auraName == localizedName
end

local function GetDB()
    local profile = addon.AkcQOL and addon.AkcQOL.db and addon.AkcQOL.db.profile
    if not profile then return nil end

    profile.piAlert = profile.piAlert or {}
    local db = profile.piAlert
    if db.enabled == nil then db.enabled = false end
    if db.screen == nil then db.screen = false end
    if db.sound == nil then db.sound = false end
    db.soundStyle = NormalizeSoundStyle(db.soundStyle)
    db.soundVolume = NormalizeSoundVolume(db.soundVolume)
    if db.message == nil or db.message == "" then db.message = DEFAULT_MESSAGE end
    if db.throttle == nil then db.throttle = 2 end
    return db
end

local function HasPowerInfusion()
    local piName = GetPISpellName()

    -- While combat restrictions are active every aura API returns nothing at
    -- all (documented precondition, open world included), so there is nothing
    -- to poll for: the engine-played sound covers that window instead.
    local inCombat = InCombatLockdown and InCombatLockdown() or false

    if C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok, aura = pcall(C_UnitAuras.GetPlayerAuraBySpellID, PI_SPELL_ID)
        if ok and not IsSecretStrict(aura) then
            if aura ~= nil then return true end
            -- Out of combat the API answer is final; in combat keep probing.
            if not inCombat then return false end
        elseif ok then
            -- 12.x combat: the aura record may be secret, but a truthiness
            -- test on it is still legal — presence is all we need here.
            local okT, present = pcall(function() return aura and true or false end)
            if okT and present then return true end
        end
    end

    -- Second presence probe by (localized) name, same truthiness rule.
    if C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName then
        for _, n in ipairs({ piName, PI_SPELL_NAME }) do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataBySpellName, "player", n, "HELPFUL")
            if ok then
                local okT, present = pcall(function() return aura and true or false end)
                if okT and present then return true end
            end
        end
    end

    if inCombat then return false end

    if AuraUtil and AuraUtil.FindAuraBySpellID then
        local ok, name = pcall(AuraUtil.FindAuraBySpellID, PI_SPELL_ID, "player", "HELPFUL")
        if ok then
            return not IsSecret(name)
        end
    end

    if AuraUtil and AuraUtil.FindAuraByName then
        local ok, name, _, _, _, _, _, _, _, spellID = pcall(AuraUtil.FindAuraByName, piName, "player", "HELPFUL")
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end

        ok, name, _, _, _, _, _, _, _, spellID = pcall(AuraUtil.FindAuraByName, PI_SPELL_NAME, "player", "HELPFUL")
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end
    end

    if C_UnitAuras and C_UnitAuras.GetBuffDataByIndex then
        for i = 1, 80 do
            local ok, aura = pcall(C_UnitAuras.GetBuffDataByIndex, "player", i)
            if not ok or not aura then break end
            if AuraIsPowerInfusion(aura) then return true end
        end
    end

    if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
        for i = 1, 200 do
            local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
            if not ok or not aura then break end
            if AuraIsPowerInfusion(aura) then return true end
        end
    end

    if UnitBuff then
        local ok, name, _, _, _, _, _, _, _, _, spellID = pcall(UnitBuff, "player", piName)
        if ok and not IsSecret(name) then return true end
        if ok and SafeNumber(spellID) == PI_SPELL_ID then return true end

        for i = 1, 200 do
            ok, name, _, _, _, _, _, _, _, _, spellID = pcall(UnitBuff, "player", i)
            if not ok or IsSecret(name) then break end
            if SafeNumber(spellID) == PI_SPELL_ID then return true end

            local auraName = SafeString(name)
            if auraName == PI_SPELL_NAME or auraName == piName then return true end
        end
    end

    return false
end

-- ── Engine-played alert (works in combat) ──────────────────────────────────
-- Addons cannot read auras while combat restrictions are active: the API
-- returns nothing at all, in the open world too. So the game itself is asked
-- to play a sound the moment Power Infusion lands. AddAuraSound takes a sound
-- FILE (path or fileDataID), never a sound-kit id -- hence this mapping.
local PI_COMBAT_SOUND_FILES = {
    raidwarning = "Sound\\Interface\\RaidWarning.ogg",
    bosswarn    = "Sound\\Interface\\UI_RaidBossWhisperWarning.ogg",
    readycheck  = "Sound\\Interface\\ReadyCheck.ogg",
    alarm       = "Sound\\Interface\\AlarmClockWarning3.ogg",
    questdone   = "Sound\\Interface\\iQuestComplete.ogg",
    ping        = "Sound\\Interface\\MapPing.ogg",
    whisper     = "Sound\\Interface\\iTellMessage.ogg",
    auction     = "Sound\\Interface\\AuctionWindowOpen.ogg",
    levelup     = "Sound\\Interface\\LevelUp.ogg",
}
local PI_COMBAT_SOUND_DEFAULT = "Sound\\Interface\\RaidWarning.ogg"

local auraSoundHandle
local auraSoundPending = false
local restrictionState = {}

local function RestrictionTypes()
    return (Enum and Enum.AddOnRestrictionType) or {}
end

-- The cached event state comes first on purpose: the direct query is
-- documented to answer wrongly while the event is still being dispatched.
local function IsRestricted(rtype)
    if rtype == nil then return false end
    local cached = restrictionState[rtype]
    if cached ~= nil then
        local inactive = (Enum and Enum.AddOnRestrictionState and Enum.AddOnRestrictionState.Inactive) or 0
        return cached ~= inactive
    end
    if not (C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive) then return false end
    local ok, active = pcall(C_RestrictedActions.IsAddOnRestrictionActive, rtype)
    return ok and active == true
end

local function AnyRestriction()
    local types = RestrictionTypes()
    for _, key in ipairs({ "Combat", "Encounter", "ChallengeMode", "PvPMatch" }) do
        if types[key] ~= nil and IsRestricted(types[key]) then return true end
    end
    return InCombatLockdown and InCombatLockdown() or false
end

-- A short note in saved variables about the in-combat path, so it can be
-- checked from the file afterwards: whether the engine-played sound is armed,
-- what the last registration attempt said, whether the game treats Power
-- Infusion as secret, and how often PI was still up after a fight that raised
-- no alert.
local function NotePIState(registration)
    if not (AkcQOLDB and AkcQOLDB.global) then return nil end
    local note = AkcQOLDB.global.piAlertDebug
    if type(note) ~= "table" then
        note = {}
        AkcQOLDB.global.piAlertDebug = note
    end
    note.when = date and date("%Y-%m-%d %H:%M:%S") or "-"
    if registration then note.registration = registration end
    note.soundArmed = auraSoundHandle ~= nil
    if C_Secrets and C_Secrets.ShouldSpellAuraBeSecret then
        local ok, secret = pcall(C_Secrets.ShouldSpellAuraBeSecret, PI_SPELL_ID)
        if ok and not IsSecretStrict(secret) then note.piAuraSecret = secret end
    end
    return note
end

local function RemoveAuraSound()
    if auraSoundHandle and C_UnitAuras and C_UnitAuras.RemoveAuraSound then
        pcall(C_UnitAuras.RemoveAuraSound, auraSoundHandle)
    end
    auraSoundHandle = nil
end

local function RegisterAuraSound()
    if not (C_UnitAuras and C_UnitAuras.AddAuraSound) then return false end

    local db = GetDB()
    if not db or not db.enabled or not db.sound then
        RemoveAuraSound()
        auraSoundPending = false
        return false
    end

    -- Registration is refused while restrictions are up; remember to do it
    -- the moment they lift (between pulls).
    if AnyRestriction() then
        auraSoundPending = true
        return false
    end

    RemoveAuraSound()

    local trigger = 1 -- ApplicationsIncreased
    local enumTrigger = Enum and Enum.UnitAuraSoundTrigger
    if enumTrigger then
        trigger = enumTrigger.Added or enumTrigger.ApplicationsIncreased or trigger
    end

    local ok, handle = pcall(C_UnitAuras.AddAuraSound, trigger, {
        unitToken = "player",
        spellID = PI_SPELL_ID,
        soundFileName = PI_COMBAT_SOUND_FILES[db.soundStyle] or PI_COMBAT_SOUND_DEFAULT,
        -- The documented channel name (PlaySoundFile lists Master, SFX, Music,
        -- Ambience, Dialog); it was sent in lower case.
        outputChannel = "Master",
    })
    if ok and handle then
        auraSoundHandle = handle
        auraSoundPending = false
        NotePIState("armed")
        return true
    end
    auraSoundPending = true
    NotePIState(ok and "refused" or ("error: " .. tostring(handle)))
    return false
end

_G.AkcQOL_RefreshPIAuraSound = RegisterAuraSound

do
    local f = CreateFrame("Frame")
    f:RegisterEvent("PLAYER_ENTERING_WORLD")
    f:RegisterEvent("PLAYER_REGEN_ENABLED")
    f:RegisterEvent("ENCOUNTER_END")
    pcall(f.RegisterEvent, f, "ADDON_RESTRICTION_STATE_CHANGED")
    f:SetScript("OnEvent", function(_, event, arg1, arg2)
        if event == "ADDON_RESTRICTION_STATE_CHANGED" then
            local rtype, state = SafeNumber(arg1), SafeNumber(arg2)
            if rtype then restrictionState[rtype] = state end
            if not AnyRestriction() then pcall(RegisterAuraSound) end
            return
        end
        if auraSoundPending or not auraSoundHandle then pcall(RegisterAuraSound) end
    end)
end

local function EnsureAlertFrame()
    if alertFrame then return alertFrame end

    local frame = CreateFrame("Frame", "AkcQOLPIAlertFrame", UIParent)
    frame:SetSize(420, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 145)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(20)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(0.72, 0.45, 1, 1)
    -- No placeholder text: ShowScreenAlert writes the configured message every
    -- time it fires, and the hardcoded English line only ever showed up as a
    -- flash of the wrong words.

    if _G.AkcQOL_SetupMovableAlert then
        _G.AkcQOL_SetupMovableAlert("piAlert", frame, function()
            local db = GetDB()
            return string.upper((db and db.message) or DEFAULT_MESSAGE)
        end, GetDB)
    end

    if Theme and Theme.ApplyFonts then Theme.ApplyFonts(frame) end

    alertFrame = frame
    return alertFrame
end

local function ShowScreenAlert(message)
    local frame = EnsureAlertFrame()
    frame.text:SetText(string.upper(message or DEFAULT_MESSAGE))
    frame:SetAlpha(1)
    frame:Show()

    hideToken = hideToken + 1
    local token = hideToken
    C_Timer.After(1.8, function()
        if hideToken ~= token or not alertFrame then return end
        alertFrame:Hide()
    end)
end

function addon:GetPIAlertSoundOptions()
    EnsureCDMSounds()
    local values = {}
    for _, key in ipairs(PI_SOUND_STYLE_ORDER) do
        local entry = PI_SOUND_STYLES[key]
        if entry then
            values[key] = entry.label or key
        end
    end
    return values
end

local ALERT_CHANNEL = "Dialog"
local DIALOG_VOL = "Sound_DialogVolume"
local DIALOG_EN = "Sound_EnableDialog"
local DUCK_CVARS = { "Sound_SFXVolume", "Sound_MusicVolume", "Sound_AmbienceVolume" }
local restoreToken = 0
local savedState
local function ReadCVarNumber(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVar and C_CVar.GetCVar(name)) or (GetCVar and GetCVar(name))
        if v ~= nil and not (issecretvalue and issecretvalue(v)) then out = tonumber(v) end
    end)
    return out
end
local function WriteCVarNumber(name, value)
    pcall(function()
        if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar(name, tostring(value))
        elseif SetCVar then SetCVar(name, tostring(value)) end
    end)
end

local function RestoreDuck()
    if not savedState then return end
    for cvar, val in pairs(savedState) do
        WriteCVarNumber(cvar, val)
    end
    savedState = nil
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.volRestorePending = nil end
end

local function PlayAtVolume(soundId, volume)
    if type(soundId) ~= "number" then return end
    -- In combat CVars are left alone (writes there can be blocked); the alert
    -- goes out on the Master channel so it is audible regardless of ducking.
    if InCombatLockdown and InCombatLockdown() then
        local okM, willPlay = pcall(PlaySound, soundId, "Master")
        if not okM or willPlay == false then pcall(PlaySound, soundId) end
        return
    end
    local strength = NormalizeSoundVolume(volume) / 100
    local duckMul = 1 - strength * 0.75

    savedState = savedState or {}

    local en = ReadCVarNumber(DIALOG_EN)
    if en ~= nil and en == 0 and savedState[DIALOG_EN] == nil then
        savedState[DIALOG_EN] = en
        WriteCVarNumber(DIALOG_EN, 1)
    end
    local dv = ReadCVarNumber(DIALOG_VOL)
    if dv ~= nil and dv < 0.999 and savedState[DIALOG_VOL] == nil then
        savedState[DIALOG_VOL] = dv
        WriteCVarNumber(DIALOG_VOL, 1)
    end

    if strength > 0.01 then
        for _, cvar in ipairs(DUCK_CVARS) do
            local baseline = savedState[cvar] or ReadCVarNumber(cvar)
            if baseline ~= nil and baseline > 0 then
                local target = baseline * duckMul
                local cur = ReadCVarNumber(cvar)
                if cur ~= nil and target < cur - 0.001 then
                    if savedState[cvar] == nil then savedState[cvar] = baseline end
                    WriteCVarNumber(cvar, target)
                end
            end
        end
    end

    if next(savedState) == nil then
        savedState = nil
    elseif AkcQOLDB and AkcQOLDB.global then
        AkcQOLDB.global.volRestorePending = savedState
    end

    local ok, willPlay = pcall(PlaySound, soundId, ALERT_CHANNEL)
    if not ok or willPlay == false then
        pcall(PlaySound, soundId)
    end

    if savedState and C_Timer and C_Timer.After then
        restoreToken = restoreToken + 1
        local token = restoreToken
        C_Timer.After(1.5, function()
            if token ~= restoreToken then return end
            RestoreDuck()
        end)
    end
end

do
    local f = CreateFrame and CreateFrame("Frame")
    if f then
        f:RegisterEvent("PLAYER_ENTERING_WORLD")
        f:SetScript("OnEvent", function(self)
            self:UnregisterAllEvents()
            local pend = AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.volRestorePending
            if pend ~= nil then
                AkcQOLDB.global.volRestorePending = nil
                if type(pend) == "table" then
                    for cvar, val in pairs(pend) do
                        if type(cvar) == "string" and cvar:match("^Sound_") then
                            WriteCVarNumber(cvar, val)
                        end
                    end
                end
            end
        end)
    end
end

local function PlayAlertSound(style, volume)
    if not PlaySound then return end
    local key = NormalizeSoundStyle(style)
    local entry = PI_SOUND_STYLES[key]
    local soundId = entry and entry.soundId
    if type(soundId) ~= "number" and type(key) == "string" then

        local id = key:match("^cdm(%d+)$")
        if id then soundId = tonumber(id) end
    end
    if type(soundId) ~= "number" then return end
    PlayAtVolume(soundId, volume)
end

function addon:PlayAlertSoundStyle(style, volume)
    return PlayAlertSound(style, volume)
end

function addon:GetSoundLabel(style)
    EnsureCDMSounds()
    local entry = PI_SOUND_STYLES[NormalizeSoundStyle(style)]
    return (entry and entry.label) or tostring(style)
end

function addon:OpenSoundAlertMenu(getCurrent, onSelect, getVolume)
    EnsureCDMSounds()
    if not (MenuUtil and MenuUtil.CreateContextMenu) then return false end
    local ok = pcall(MenuUtil.CreateContextMenu, UIParent, function(_owner, root)
        root:CreateTitle(L["Alert Sound"])
        for _, cat in ipairs(PI_SOUND_MENU) do
            local sub = root:CreateButton(cat.label)
            for _, item in ipairs(cat.entries) do
                local key = item.key
                sub:CreateRadio(item.name,
                    function() return getCurrent() == key end,
                    function()
                        onSelect(key)
                        PlayAlertSound(key, getVolume and getVolume() or nil)
                        return MenuResponse and MenuResponse.Refresh or nil
                    end)
            end
        end
    end)
    return ok
end

local function FireAlert(force, forceSound)
    local db = GetDB()
    if not db or (not force and not db.enabled) then return end

    local now = GetTime and GetTime() or 0
    if not force and now - lastAlertTime < (db.throttle or 2) then return end
    lastAlertTime = now

    local message = db.message or DEFAULT_MESSAGE

    if not force and db.chatMessage ~= false then
        print("|cff8c5cffAkc|r|cffffffffQOL|r: |cffff66ff" .. string.upper(message) .. "|r")
    end

    -- Out of combat the addon plays the sound itself; when the engine-played
    -- alert is armed it already covers every case, so it is not doubled.
    if (db.sound and not auraSoundHandle) or forceSound then
        PlayAlertSound(db.soundStyle, db.soundVolume)
    end

    if db.screen then
        ShowScreenAlert(message)
        if UIErrorsFrame and UIErrorsFrame.AddMessage then
            UIErrorsFrame:AddMessage(string.upper(message), 0.72, 0.45, 1, 1)
        end
    end

end

local function CheckPIState(silent)
    local hasPI = HasPowerInfusion()
    if hasPI and not hadPI and not silent then
        FireAlert(false)
    end
    hadPI = hasPI
end

local function QueuePIStateCheck(silent)
    checkToken = checkToken + 1
    local token = checkToken

    CheckPIState(silent)
    if not C_Timer or not C_Timer.After then return end

    C_Timer.After(0.05, function()
        if token == checkToken then CheckPIState(silent) end
    end)
    C_Timer.After(0.25, function()
        if token == checkToken then CheckPIState(silent) end
    end)
end

function addon:InitializePIAlert()
    local db = GetDB()
    if not db or not db.enabled then return end

    if not eventFrame then
        eventFrame = CreateFrame("Frame", "AkcQOLPIAlertEventFrame")
        eventFrame:SetScript("OnEvent", function(_, event, unit, _castGUID, spellID)
            if event == "UNIT_AURA" then
                if unit == "player" or unit == nil then QueuePIStateCheck(false) end
            elseif event == "UNIT_SPELLCAST_SUCCEEDED" then

                if unit == "player" and SafeNumber(spellID) == PI_SPELL_ID then
                    FireAlert(false)
                    hadPI = true
                end
            elseif event == "PLAYER_ENTERING_WORLD" then
                C_Timer.After(1, function() QueuePIStateCheck(true) end)
            elseif event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
                if event == "PLAYER_REGEN_DISABLED" then
                    combatStartedAt = GetTime()
                elseif combatStartedAt then
                    local startedAt = combatStartedAt
                    -- Half a second later the aura restriction has lifted. PI still
                    -- up, and no alert raised since the fight began: the in-combat
                    -- path missed this one. Only the screen/chat side is counted;
                    -- the engine sound leaves no trace to check.
                    C_Timer.After(0.5, function()
                        if InCombatLockdown() or lastAlertTime >= startedAt then return end
                        if not HasPowerInfusion() then return end
                        local note = NotePIState()
                        if note then
                            note.missedInCombat = (tonumber(note.missedInCombat) or 0) + 1
                            note.lastMissed = note.when
                        end
                    end)
                end
                QueuePIStateCheck(true)
            end
        end)
    end

    EnsureAlertFrame()
    RegisterAuraSound()

    eventFrame:UnregisterAllEvents()

    if not pcall(eventFrame.RegisterUnitEvent, eventFrame, "UNIT_AURA", "player") then
        eventFrame:RegisterEvent("UNIT_AURA")
    end

    pcall(eventFrame.RegisterUnitEvent, eventFrame, "UNIT_SPELLCAST_SUCCEEDED", "player")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")

    if pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
    end

    pollTicker = C_Timer.NewTicker(0.5, function()
        CheckPIState(false)
    end)

    QueuePIStateCheck(true)
end

function addon:DisablePIAlert()
    RemoveAuraSound()
    if eventFrame then
        eventFrame:UnregisterAllEvents()
    end
    if pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
    end
    if alertFrame then
        alertFrame:Hide()
    end
end

function addon:TestPIAlert()
    FireAlert(true, true)
end

if _G.AkcQOL_RegisterAlertBuilder then
    _G.AkcQOL_RegisterAlertBuilder("piAlert", EnsureAlertFrame)
end
