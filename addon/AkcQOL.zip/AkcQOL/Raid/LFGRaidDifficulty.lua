---------------------------------------------------------------------------
-- AkcQOL - Raid/LFGRaidDifficulty.lua
--
-- Adds Normal / Heroic / Mythic and a minimum Mythic+ rating to the Premade
-- Groups "Filter" menu when searching for raids.
--
-- Blizzard offers both filters for Dungeons only. For every other category
-- the menu holds just the languages, and LFGListSearchPanel_DoSearch drops the
-- advanced filter before it searches, so the server cannot do this for raids.
-- The choice is kept by AkcQOL and applied to the list the search has already
-- returned: groups that do not match are DIMMED where Blizzard draws them,
-- the way its own dungeon filter shows a group that no longer matches.
--
-- NOTHING OF BLIZZARD'S IS WRITTEN. This file used to replace the search
-- panel's result table (the route Premade Groups Filter takes) and to use
-- Blizzard's pooled LevelRangeFrameTemplate for the rating box. Both handed
-- Blizzard addon-written values or callbacks; once secure code runs or reads
-- them its execution is tainted, and in 12.x a tainted execution may not
-- compare the secret values the Group Finder is full of -- the applicant
-- window raised hundreds of errors. Now:
--   * Menu.ModifyMenu("MENU_LFG_FRAME_SEARCH_FILTER") appends a rating box
--     made from AkcQOL's own template (Raid/LFGRaidDifficulty.xml, a pool no
--     other menu draws from) and the difficulty checkboxes, in the order
--     LFGListSearchPanel_SetupAdvancedFilter uses for dungeons. The tag comes
--     from the 12.x source, Blizzard_GroupFinder/Mainline/LFGList.lua.
--   * Post-hooks on LFGListSearchEntry_Update (each row Blizzard draws) and
--     LFGListSearchPanel_UpdateResultList (each new list, read only) set the
--     row's alpha. Alpha lives in the engine, not in a Lua value.
--
-- The rules are Blizzard's dungeon ones (EntryStillSatisfiesFilters): every
-- difficulty starts ticked and a group is dimmed only when its activity HAS a
-- difficulty that is unticked; a leader rated below the minimum is dimmed, one
-- without a rating counts as 0. Groups you applied to are never dimmed.
--
-- DESIGN RULE: this file never raises (see LFRWings.lua). A group whose
-- difficulty or rating cannot be read is kept.
---------------------------------------------------------------------------

local MENU_TAG   = "MENU_LFG_FRAME_SEARCH_FILTER"
local DUNGEONS   = 2     -- GROUP_FINDER_CATEGORY_ID_DUNGEONS: Blizzard filters those itself
local MAX_SCAN   = 400   -- hard cap on the activity loop of a category
local MAX_SAMPLE = 4     -- activities described in the saved diagnostic note
local MAX_RATING = 9999  -- the rating box takes four digits

local DIFFICULTIES = {
    { key = "normal", label = "PLAYER_DIFFICULTY1", fallback = "Normal" },
    { key = "heroic", label = "PLAYER_DIFFICULTY2", fallback = "Heroic" },
    { key = "mythic", label = "PLAYER_DIFFICULTY6", fallback = "Mythic" },
}

local menuInstalled, hookInstalled = false, false
local DIM_ALPHA = 0.3    -- a non-matching row, like Blizzard's "no longer matches"

local activityClass = {}   -- activityID -> "normal" | "heroic" | "mythic" | false
local activityWhy   = {}   -- activityID -> "flag" | "d<difficultyID>" (diagnostic note only)
local categoryClass = {}   -- categoryID -> lists raid difficulties

local function Enabled()
    if not (AkcQOLDB and AkcQOLDB.global) then return true end
    return AkcQOLDB.global.lfgRaidDifficulty ~= false      -- on by default
end

local function IsSecret(value)
    if type(issecretvalue) ~= "function" then return false end
    local ok, secret = pcall(issecretvalue, value)
    return ok and secret == true
end

---------------------------------------------------------------------------
-- Saved state, account-wide like Blizzard's own filters: the difficulties the
-- player UNticked, and the minimum leader rating. Empty means every group is
-- shown, which is also how a fresh install starts.
---------------------------------------------------------------------------
local function HiddenSet()
    local g = AkcQOLDB and AkcQOLDB.global
    local hidden = g and g.lfgRaidDifficultyHidden
    return type(hidden) == "table" and hidden or nil
end

local function HidesAny(hidden)
    if not hidden then return false end
    local count = 0
    for _, d in ipairs(DIFFICULTIES) do
        if hidden[d.key] then count = count + 1 end
    end
    return count > 0 and count < #DIFFICULTIES
end

local function HiddenNames(hidden)
    local names = {}
    for _, d in ipairs(DIFFICULTIES) do
        if hidden and hidden[d.key] then names[#names + 1] = d.key end
    end
    return table.concat(names, ",")
end

-- Minimum leader rating, 0 when not set.
local function MinRating()
    local g = AkcQOLDB and AkcQOLDB.global
    local rating = g and tonumber(g.lfgRaidMinRating)
    if not rating or rating ~= rating or rating <= 0 then return 0 end
    return math.floor(math.min(rating, MAX_RATING))
end

-- The last decision, kept in the saved variables so a report can be checked
-- from the file instead of typing commands in game.
local function Note(fields)
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    local note = g.lfgRaidDifficultyDebug
    if type(note) ~= "table" then
        note = {}
        g.lfgRaidDifficultyDebug = note
    end
    for k, v in pairs(fields) do note[k] = v end
    if type(date) == "function" then note.when = date("%Y-%m-%d %H:%M:%S") end
end

---------------------------------------------------------------------------
-- Data
---------------------------------------------------------------------------
-- "normal" / "heroic" / "mythic" for a raid activity, false for one without
-- any of those (Mythic+, LFR, questing...), nil when it cannot be read now.
local function ClassifyActivity(activityID)
    if type(activityID) ~= "number" or IsSecret(activityID) then return nil end
    local known = activityClass[activityID]
    if known ~= nil then return known end
    if not (C_LFGList and C_LFGList.GetActivityInfoTable) then return nil end

    local why
    local ok, class = pcall(function()
        local info = C_LFGList.GetActivityInfoTable(activityID)
        if type(info) ~= "table" then return nil end
        -- Blizzard's own flags, the ones its dungeon filter checks.
        why = "flag"
        if info.isMythicPlusActivity then return false end
        if info.isMythicActivity then return "mythic" end
        if info.isHeroicActivity then return "heroic" end
        if info.isNormalActivity then return "normal" end
        -- Otherwise the difficulty itself. Raids carry no flags in 12.x
        -- (seen in game: "1956=heroic/d15"), and older ones name 10/25/40-player
        -- difficulties.
        local id = info.difficultyID
        why = "d?"
        if type(id) ~= "number" or IsSecret(id) then return false end
        why = "d" .. id
        if id <= 0 or type(GetDifficultyInfo) ~= "function" then return false end
        local _, groupType, isHeroic, _, displayHeroic, displayMythic, _, isLFR = GetDifficultyInfo(id)
        if groupType ~= "raid" or isLFR then return false end
        if displayMythic then return "mythic" end
        if isHeroic or displayHeroic then return "heroic" end
        return "normal"
    end)
    if not ok or class == nil then return nil end
    activityClass[activityID] = class
    activityWhy[activityID] = why
    return class
end

-- Whether a Group Finder category lists activities with raid difficulties.
-- Read from the category's own activities rather than a fixed ID. Dungeons are
-- left out: Blizzard's menu already filters there.
local function CategoryHasDifficulties(categoryID)
    if type(categoryID) ~= "number" or IsSecret(categoryID) then return false end
    if categoryID == (tonumber(_G.GROUP_FINDER_CATEGORY_ID_DUNGEONS) or DUNGEONS) then return false end
    local known = categoryClass[categoryID]
    if known ~= nil then return known end
    if not (C_LFGList and C_LFGList.GetAvailableActivities) then return false end

    local ok, list = pcall(C_LFGList.GetAvailableActivities, categoryID)
    if not ok or type(list) ~= "table" or IsSecret(list) then return false end
    local found, unread = false, false
    local count = #list
    for i = 1, (count < MAX_SCAN) and count or MAX_SCAN do
        local class = ClassifyActivity(list[i])
        if class then
            found = true
            break
        elseif class == nil then
            unread = true
        end
    end
    -- An empty or partly unreadable list is asked again next time.
    if found or (count > 0 and not unread) then categoryClass[categoryID] = found end
    return found
end

-- The leader's overall Mythic+ rating: a number, nil when the listing carries
-- none, false when it is secret.
local function LeaderScore(info)
    local score = info.leaderOverallDungeonScore
    if IsSecret(score) then return false end
    return type(score) == "number" and score or nil
end

-- Blizzard's rules for its dungeon filter (EntryStillSatisfiesFilters):
--   * a group is hidden by difficulty only when its activity HAS a difficulty
--     and that difficulty is unticked; a group listing several activities
--     stays while any of them is ticked;
--   * a leader rated below the minimum is hidden; one without a rating
--     counts as 0.
-- rules = { hidden = set or nil, minRating = number, 0 when off }
-- Returns keep, unreadable, why ("difficulty" | "rating").
local function Keep(resultID, rules)
    if type(resultID) ~= "number" or IsSecret(resultID) then return true, true end
    if not (C_LFGList and C_LFGList.GetSearchResultInfo) then return true, true end
    local ok, info = pcall(C_LFGList.GetSearchResultInfo, resultID)
    if not ok or type(info) ~= "table" or IsSecret(info) then return true, true end

    local unreadable = false
    if rules.hidden then
        local ids = info.activityIDs
        if IsSecret(ids) then
            ids = nil
        elseif type(ids) ~= "table" then
            ids = type(info.activityID) == "number" and { info.activityID } or nil
        end
        if not ids then
            unreadable = true
        else
            local ticked, unticked = false, false
            for i = 1, #ids do
                local class = ClassifyActivity(ids[i])
                if class == nil then
                    unreadable = true
                elseif class then
                    if rules.hidden[class] then unticked = true else ticked = true end
                end
            end
            if unticked and not ticked and not unreadable then
                return false, false, "difficulty"
            end
        end
    end

    if rules.minRating > 0 then
        local score = LeaderScore(info)
        if score == false then return true, true end
        if (score or 0) < rules.minRating then return false, unreadable, "rating" end
    end
    return true, unreadable
end

local function Sample(list)
    local parts, seen = {}, {}
    for i = 1, #list do
        if #parts >= MAX_SAMPLE then break end
        local ok, info = pcall(C_LFGList.GetSearchResultInfo, list[i])
        local ids = ok and type(info) == "table" and info.activityIDs
        local id = type(ids) == "table" and not IsSecret(ids) and ids[1]
        if type(id) == "number" and not IsSecret(id) and not seen[id] then
            seen[id] = true
            parts[#parts + 1] = ("%d=%s/%s"):format(id, tostring(activityClass[id]), tostring(activityWhy[id]))
        end
    end
    return table.concat(parts, " ")
end

---------------------------------------------------------------------------
-- The result list (read only)
---------------------------------------------------------------------------
-- Whether any listing carries a leader rating. When none does, the server did
-- not send ratings for this search and every group would read as 0, so the
-- rating is left out rather than dimming the whole list.
local function AnyLeaderScore(list)
    for i = 1, #list do
        local ok, info = pcall(C_LFGList.GetSearchResultInfo, list[i])
        if ok and type(info) == "table" and not IsSecret(info) then
            local okScore, score = pcall(LeaderScore, info)
            if okScore and type(score) == "number" then return true end
        end
    end
    return false
end

-- What the rows are judged by; rebuilt when a list arrives or a choice changes.
local current = { active = false, rules = { hidden = nil, minRating = 0 }, ratingData = "off" }

local function SearchPanel()
    local frame = _G.LFGListFrame
    return frame and frame.SearchPanel
end

-- Blizzard's current list, or an empty one. Only ever read.
local function CurrentList(panel)
    local list = panel and panel.results
    if type(list) ~= "table" or IsSecret(list) then return {} end
    return list
end

local function Rebuild(panel)
    local hidden = HiddenSet()
    local byDifficulty = HidesAny(hidden)
    local minRating = MinRating()
    local categoryID = panel and panel.categoryID
    current.active = Enabled() and (byDifficulty or minRating > 0) and CategoryHasDifficulties(categoryID) or false
    current.rules = { hidden = byDifficulty and hidden or nil, minRating = 0 }
    current.ratingData = "off"
    if current.active and minRating > 0 then
        current.ratingData = AnyLeaderScore(CurrentList(panel)) and "seen" or "none"
        if current.ratingData == "seen" then current.rules.minRating = minRating end
    end
    current.hidden = hidden
    current.minRating = minRating
    current.categoryID = categoryID
end

-- An application of the player's is shown as Blizzard draws it, never dimmed.
local function IsApplication(resultID)
    if not (C_LFGList and C_LFGList.GetApplicationInfo) then return false end
    local ok, _, appStatus, pendingStatus = pcall(C_LFGList.GetApplicationInfo, resultID)
    if not ok then return false end
    if IsSecret(appStatus) or IsSecret(pendingStatus) then return true end
    return (type(appStatus) == "string" and appStatus ~= "none") or pendingStatus ~= nil
end

-- true when the row should be dimmed, and why ("difficulty" | "rating").
local function ShouldDim(resultID)
    if not current.active or type(resultID) ~= "number" or IsSecret(resultID) then return false end
    if IsApplication(resultID) then return false end
    local ok, keep, _, why = pcall(Keep, resultID, current.rules)
    if not ok then return false end
    return keep == false, why
end

local function DimRow(entry)
    if type(entry) ~= "table" or type(entry.SetAlpha) ~= "function" then return end
    local dim = false
    local okDim, d = pcall(ShouldDim, entry.resultID)
    if okDim then dim = d and true or false end
    pcall(entry.SetAlpha, entry, dim and DIM_ALPHA or 1)
end

local function DimVisibleRows(panel)
    local box = panel and panel.ScrollBox
    if box and type(box.ForEachFrame) == "function" then
        pcall(box.ForEachFrame, box, DimRow)
    end
end

-- The diagnostic note: what was listed, what got dimmed and why.
local function NoteList(panel)
    local list = CurrentList(panel)
    local dimmed, unreadable = { difficulty = 0, rating = 0 }, 0
    if current.active then
        for i = 1, #list do
            local okK, keep, unread, why = pcall(Keep, list[i], current.rules)
            if not okK or unread then unreadable = unreadable + 1 end
            if okK and keep == false and not IsApplication(list[i]) then
                why = (why == "rating") and "rating" or "difficulty"
                dimmed[why] = dimmed[why] + 1
            end
        end
    end
    local okSample, sample = pcall(Sample, list)
    Note({
        category = current.categoryID or "none", hiddenDifficulties = HiddenNames(current.hidden),
        minRating = current.minRating or 0, ratingData = current.ratingData,
        listed = #list, dimmed = dimmed.difficulty + dimmed.rating,
        dimmedByDifficulty = dimmed.difficulty, dimmedByRating = dimmed.rating,
        unreadable = unreadable, sample = okSample and sample or "unreadable",
        mode = "dim",
    })
end

-- Blizzard has just rebuilt the list. Nothing here writes to the panel.
local function OnUpdateResultList(panel)
    pcall(function()
        if type(panel) ~= "table" or panel.searching then return end
        Rebuild(panel)
        NoteList(panel)
        DimVisibleRows(panel)
    end)
end

-- Each row Blizzard (re)draws; rows are recycled, so every one is set.
local function OnEntryUpdate(entry)
    pcall(DimRow, entry)
end

-- After a checkbox, the rating or the option changes: judge the rows on
-- screen again without a new search.
local function Refresh()
    pcall(function()
        local panel = SearchPanel()
        if not panel then return end
        Rebuild(panel)
        NoteList(panel)
        DimVisibleRows(panel)
    end)
end

_G.AkcQOL_RefreshLFGRaidDifficulty = Refresh   -- live refresh from the options panel

---------------------------------------------------------------------------
-- Menu
---------------------------------------------------------------------------
local function IsTicked(key)
    local hidden = HiddenSet()
    return not (hidden and hidden[key])
end

local function Toggle(key)
    pcall(function()
        local g = AkcQOLDB and AkcQOLDB.global
        if not g then return end
        if type(g.lfgRaidDifficultyHidden) ~= "table" then g.lfgRaidDifficultyHidden = {} end
        local hidden = g.lfgRaidDifficultyHidden
        hidden[key] = (not hidden[key]) or nil
        -- Unticking the last one would dim every raid group. Blizzard treats
        -- "none" as "all" for dungeons; here the menu snaps back to all ticked
        -- so it always says what the list shows.
        local all = true
        for _, d in ipairs(DIFFICULTIES) do
            if not hidden[d.key] then
                all = false
                break
            end
        end
        if all then
            for k in pairs(hidden) do hidden[k] = nil end
        end
    end)
    Refresh()
    return _G.MenuResponse and _G.MenuResponse.Refresh or nil
end

local function SetMinRating(value)
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    local rating = tonumber(value) or 0
    if rating ~= rating or rating < 0 then rating = 0 end
    rating = math.floor(math.min(rating, MAX_RATING))
    if rating == MinRating() then return end
    g.lfgRaidMinRating = (rating > 0) and rating or nil
    Refresh()
end

-- The rating box from AkcQOL's own template. Only what the player types
-- counts: setting the box's text from the saved value is not user input.
local function OnRatingTyped(box, userInput)
    if not userInput then return end
    pcall(SetMinRating, box:GetNumber())
end

local function InitRatingBox(frame)
    pcall(function()
        local box = frame and frame.Box
        if not box then return end
        if not box.akcHooked then
            box.akcHooked = true
            box:HookScript("OnTextChanged", OnRatingTyped)
            box:HookScript("OnEnterPressed", function(self) self:ClearFocus() end)
        end
        box:SetMaxLetters(4)
        local rating = MinRating()
        box:SetText(rating > 0 and tostring(rating) or "")
    end)
end

local function OnMenuGenerated(_ownerRegion, rootDescription, _contextData)
    if not Enabled() then return end
    pcall(function()
        if not rootDescription or type(rootDescription.CreateCheckbox) ~= "function" then return end
        local selection = _G.LFGListFrame and _G.LFGListFrame.CategorySelection
        local categoryID = selection and selection.selectedCategory
        local offered = CategoryHasDifficulties(categoryID)
        Note({ menuCategory = categoryID or "none", menuShown = offered })
        if not offered then return end

        local hasSpacer = type(rootDescription.CreateSpacer) == "function"
        local hasTitle = type(rootDescription.CreateTitle) == "function"

        -- Blizzard's dungeon order: the rating box, then the difficulties.
        if type(rootDescription.CreateTemplate) == "function" then
            if hasSpacer then rootDescription:CreateSpacer() end
            if hasTitle then
                rootDescription:CreateTitle(_G.LFG_LIST_MINIMUM_RATING or "Minimum Mythic+ Rating")
            end
            local box = rootDescription:CreateTemplate("AkcQOLRaidRatingBoxTemplate")
            if box and type(box.AddInitializer) == "function" then
                box:AddInitializer(InitRatingBox)
            end
        end

        if hasSpacer then rootDescription:CreateSpacer() end
        if hasTitle then
            rootDescription:CreateTitle(_G.LFG_LIST_DIFFICULTY or "Difficulty")
        end
        for _, d in ipairs(DIFFICULTIES) do
            rootDescription:CreateCheckbox(_G[d.label] or d.fallback, IsTicked, Toggle, d.key)
        end
    end)
end

---------------------------------------------------------------------------
-- Install
---------------------------------------------------------------------------
local function Install()
    if not menuInstalled and type(_G.Menu) == "table" and type(_G.Menu.ModifyMenu) == "function" then
        if pcall(_G.Menu.ModifyMenu, MENU_TAG, OnMenuGenerated) then menuInstalled = true end
    end
    if not hookInstalled and type(_G.LFGListSearchPanel_UpdateResultList) == "function"
        and type(_G.LFGListSearchEntry_Update) == "function" then
        if pcall(hooksecurefunc, "LFGListSearchPanel_UpdateResultList", OnUpdateResultList)
            and pcall(hooksecurefunc, "LFGListSearchEntry_Update", OnEntryUpdate) then
            hookInstalled = true
        end
    end
    return menuInstalled and hookInstalled
end

local ev = CreateFrame("Frame", "AkcQOLLFGRaidDifficulty")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("ADDON_LOADED")
ev:SetScript("OnEvent", function(self, event, name)
    -- Blizzard_GroupFinder loads with the game, so login normally finds both
    -- hooks; ADDON_LOADED only covers a client that loads it later.
    if event == "ADDON_LOADED" and name ~= "Blizzard_GroupFinder" then return end
    if Install() then self:UnregisterAllEvents() end
end)
