---------------------------------------------------------------------------
-- AkcQOL - Raid/LFRWings.lua
--
-- Shows, to the RIGHT of every wing in the Raid Finder's "Raid" dropdown, how
-- many of its bosses you have killed this week:  The Soulcoilers      2/3
--
-- Driven from Blizzard's own extension point (Menu.ModifyMenu), so the menu is
-- never taken over and no taint is produced. The menu tag comes from the 12.1
-- source: Blizzard_GroupFinder/Shared/RaidFinder.lua calls
--   rootDescription:SetTag("MENU_RAID_FINDER_QUEUE_FRAME")
--
-- DESIGN RULE: this file never raises. Every Blizzard symbol is checked for
-- existence before use and every call is wrapped, so if something does not
-- hold the counter simply does not appear -- the player's menu still works.
---------------------------------------------------------------------------

local MENU_TAG   = "MENU_RAID_FINDER_QUEUE_FRAME"
local RIGHT_PAD  = 4     -- inset from the right edge
local ICON_GAP   = 4     -- gap from Blizzard's "Fated" icon
local MAX_SCAN   = 40    -- hard cap on the boss loop

-- All that is left of the old diagnostic state: install this hook once.
local installed = false

local function Enabled()
    if not (AkcQOLDB and AkcQOLDB.global) then return true end
    return AkcQOLDB.global.lfrWings ~= false      -- on by default
end

---------------------------------------------------------------------------
-- Data: how many bosses in this wing are already killed?
---------------------------------------------------------------------------
-- NOTE on what the lock means: this is a LOOT lock. Blizzard uses the same
-- numbers in ERR_LOOT_GONE = "Already looted (%d/%d)" and paints killed
-- bosses red. So it reads as "if I queue for this wing, this many bosses will
-- not drop loot for me" -- which is exactly what the player wants to know.
-- It resets weekly and is per character.
local function WingProgress(dungeonID)
    if type(dungeonID) ~= "number" then return nil end
    if type(_G.GetLFGDungeonNumEncounters) ~= "function" then return nil end

    local ok, total, completed = pcall(_G.GetLFGDungeonNumEncounters, dungeonID)
    if not ok or type(total) ~= "number" or total <= 0 then return nil end

    -- Blizzard's own second return. Ignored if it comes back nonsensical.
    if type(completed) ~= "number" or completed < 0 or completed > total then
        completed = nil
    end

    -- An independent count: both a fallback and a cross-check.
    local loop
    if type(_G.GetLFGDungeonEncounterInfo) == "function" then
        local n = 0
        local scan = (total < MAX_SCAN) and total or MAX_SCAN
        for i = 1, scan do
            local ok2, _name, _tex, isKilled = pcall(_G.GetLFGDungeonEncounterInfo, dungeonID, i)
            if ok2 and isKilled then n = n + 1 end
        end
        loop = n
    end

    local shown = completed or loop
    if type(shown) ~= "number" then return nil end
    return shown, total
end

---------------------------------------------------------------------------
-- Layout helpers
---------------------------------------------------------------------------
-- Blizzard hangs a 16x16 "modified dungeon" icon (Fated/Timewalking) on some
-- wings with SetPoint("RIGHT"). The icon is a local variable and is not stored
-- on the button, so the regions anchored to the RIGHT are scanned instead and
-- room is reserved for them. Our initializer runs LAST, so by this point that
-- icon already exists.
local function ReservedRight(button)
    local reserved = 0
    local ok = pcall(function()
        if type(button.GetRegions) ~= "function" then return end
        local regions = { button:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and type(r.IsObjectType) == "function" and r:IsObjectType("Texture")
               and type(r.GetPoint) == "function" then
                local shown = (type(r.IsShown) ~= "function") or r:IsShown()
                if shown then
                    local n = (type(r.GetNumPoints) == "function") and r:GetNumPoints() or 1
                    for p = 1, n do
                        local point, _rel, _relPoint, xOfs = r:GetPoint(p)
                        if point == "RIGHT" then
                            local w = (type(r.GetWidth) == "function" and r:GetWidth()) or 0
                            local need = w - (xOfs or 0)   -- xOfs is negative when inset
                            if need > reserved then reserved = need end
                        end
                    end
                end
            end
        end
    end)
    if not ok then return 0 end
    return reserved
end

local function PickColor(shown, total)
    if shown >= total then return _G.GREEN_FONT_COLOR end
    if shown > 0     then return _G.HIGHLIGHT_FONT_COLOR end
    return _G.DISABLED_FONT_COLOR
end

---------------------------------------------------------------------------
-- Decorate one wing row
---------------------------------------------------------------------------
local function DecorateWing(desc, dungeonID)
    desc:AddInitializer(function(button, _description, _menu)
        local ok = pcall(function()
            -- The compositor FORBIDS button:CreateFontString(). The only
            -- legitimate route here is AttachFontString, which also handles
            -- returning the string to the pool.
            if type(button.AttachFontString) ~= "function" then
                return
            end

            local shown, total = WingProgress(dungeonID)
            if not shown or not total then return end

            local fs = button:AttachFontString()
            if not fs then return end

            -- On a disabled row Blizzard greys every child region and drops
            -- its saturation, using the same flag for its own icon. This is a
            -- COLOUR flag, not a size one.
            fs.noRecurseHierarchy = true

            -- SetFont is forbidden on compositor font strings; SetFontObject is not.
            if type(fs.SetFontObject) == "function" then
                fs:SetFontObject("GameFontHighlightSmall")
            end
            if type(fs.SetJustifyH) == "function" then fs:SetJustifyH("RIGHT") end
            if type(fs.SetHeight)   == "function" then fs:SetHeight(20) end

            local text = ("%d/%d"):format(shown, total)

            -- CRITICAL: AttachFontString applies SetWidth(150) by default.
            -- Without shrinking the region to its text, the measured box grows
            -- by ~150px and the ENTIRE dropdown inflates. SetTextToFit is the
            -- cure; the branch below is the fallback.
            if type(fs.SetTextToFit) == "function" then
                fs:SetTextToFit(text)
            else
                if type(fs.SetText) == "function" then fs:SetText(text) end
                if type(fs.SetWidth) == "function"
                   and type(fs.GetUnboundedStringWidth) == "function" then
                    fs:SetWidth(fs:GetUnboundedStringWidth())
                end
            end

            local color = PickColor(shown, total)
            if color and type(color.GetRGB) == "function"
               and type(fs.SetTextColor) == "function" then
                fs:SetTextColor(color:GetRGB())
            end

            local reserved = ReservedRight(button)
            local offset = -(RIGHT_PAD + ((reserved > 0) and (reserved + ICON_GAP) or 0))
            if type(fs.SetPoint) == "function" then
                fs:SetPoint("RIGHT", offset, 0)
            end
        end)
        -- Deliberately silent: a wing that cannot be decorated just shows no
        -- counter, and the player's menu keeps working.
        -- Nothing is returned, on purpose. Returning (w,h) would override the
        -- compositor's own measurement and put Blizzard's icon arithmetic on
        -- our shoulders, where a mistake produces REAL clipping. Left to the
        -- measurement, the counter stays inside the button by definition.
    end)
end

---------------------------------------------------------------------------
-- Menu hook
---------------------------------------------------------------------------
local function OnMenuGenerated(_ownerRegion, rootDescription, _contextData)
    if not Enabled() then return end
    local ok = pcall(function()
        if not rootDescription
           or type(rootDescription.EnumerateElementDescriptions) ~= "function" then
            return
        end

        for _i, desc in rootDescription:EnumerateElementDescriptions() do
            if desc and type(desc.GetData) == "function"
                    and type(desc.AddInitializer) == "function" then
                local okData, data = pcall(desc.GetData, desc)
                if okData and type(data) == "number" then
                    -- Headers ("The Venomous Abyss") come from CreateTitle:
                    -- they carry no data and are not radio entries. The numeric
                    -- data test already excludes them on its own; IsRadio is a
                    -- second, independent discriminator.
                    local isRadio = true
                    if type(desc.IsRadio) == "function" then
                        local okR, r = pcall(desc.IsRadio, desc)
                        if okR then isRadio = (r and true or false) end
                    end
                    if isRadio then
                        DecorateWing(desc, data)
                    end
                end
            end
        end
    end)
    if not ok then return end
end

local function Install()
    if installed then return end
    if type(_G.Menu) ~= "table" or type(_G.Menu.ModifyMenu) ~= "function" then
        return
    end
    if pcall(_G.Menu.ModifyMenu, MENU_TAG, OnMenuGenerated) then
        installed = true
    end
end

---------------------------------------------------------------------------
-- Refresh
---------------------------------------------------------------------------
-- Kill information comes from the server's lock data. Before
-- LFG_LOCK_INFO_RECEIVED arrives the counters RIGHTLY read 0/N. Blizzard's own
-- refresh route is GenerateMenu().
local function Refresh()
    pcall(function()
        local frame = _G.RaidFinderQueueFrame
        if not frame or type(frame.IsShown) ~= "function" or not frame:IsShown() then
            return
        end
        local dd = frame.SelectionDropdown or _G.RaidFinderQueueFrameSelectionDropdown
        if not dd then return end
        if type(dd.GenerateMenu) == "function" then
            dd:GenerateMenu()
        elseif type(dd.SignalUpdate) == "function" then
            dd:SignalUpdate()
        end
    end)
end

_G.AkcQOL_RefreshLFRWings = Refresh   -- live refresh from the options panel

local ev = CreateFrame("Frame", "AkcQOLLFRWings")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("LFG_LOCK_INFO_RECEIVED")
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        -- Registering at login makes DOUBLE decoration impossible, which is
        -- a live definition of Menu.ModifyMenu's "run immediately if this tag
        -- was already generated this session" path: the LFR menu cannot have
        -- been generated yet at this point.
        Install()
    else
        Refresh()
    end
end)
