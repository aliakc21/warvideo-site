---------------------------------------------------------------------------
-- AkcQOL - Raid/LFRWings.lua
--
-- Raid Finder'daki "Raid" acilir listesinde, her wing'in SAGINDA o hafta kac
-- boss'unu kestigini gosterir:  The Soulcoilers            2/3
--
-- Blizzard'in kendi uzatma noktasindan calisir (Menu.ModifyMenu), yani menuyu
-- ele gecirmez, taint uretmez. Menu tag'i 12.1 kaynagindan dogrulandi:
--   Blizzard_GroupFinder/Shared/RaidFinder.lua -> rootDescription:SetTag(
--       "MENU_RAID_FINDER_QUEUE_FRAME")
--
-- TASARIM KURALI: bu dosya ASLA hata firlatmaz. Her Blizzard sembolu once
-- varliga bakilarak kullanilir, her cagri pcall'lidir. Bir sey tutmazsa sayac
-- gorunmez -- oyuncunun menusu bozulmaz. Sebep /lfrwing ile okunur.
---------------------------------------------------------------------------

local ADDON_NAME, addon = ...
local L = AkcQOL_L

local MENU_TAG   = "MENU_RAID_FINDER_QUEUE_FRAME"
local RIGHT_PAD  = 4     -- sayacin sag kenardan icerisi
local ICON_GAP   = 4     -- Blizzard'in "Fated" ikonuyla arasindaki bosluk
local MAX_SCAN   = 40    -- boss dongusune sert tavan

-- Teshis durumu (/lfrwing)
local D = {
    installed = false, menuApi = false, cbFired = 0,
    lastElements = 0, lastWings = 0, lastDecorated = 0,
    attachFontString = nil,
    errInstall = nil, errCb = nil, errInit = nil,
}

local function Enabled()
    if not (AkcQOLDB and AkcQOLDB.global) then return true end
    return AkcQOLDB.global.lfrWings ~= false      -- varsayilan ACIK
end

---------------------------------------------------------------------------
-- Veri: bu wing'de kac boss kesildi?
---------------------------------------------------------------------------
-- NOT (kilit anlami): bu bir LOOT kilididir. Blizzard ayni sayilari
-- ERR_LOOT_GONE = "Already looted (%d/%d)" icinde kullaniyor ve kesilmis
-- bosslari kirmiziya boyuyor. Yani "bu wing'e girersem su kadar boss bana
-- loot vermez" demek -- oyuncunun bilmek istedigi tam olarak bu.
-- Haftalik sifirlanir ve karakter basinadir.
local function WingProgress(dungeonID)
    if type(dungeonID) ~= "number" then return nil end
    if type(_G.GetLFGDungeonNumEncounters) ~= "function" then return nil end

    local ok, total, completed = pcall(_G.GetLFGDungeonNumEncounters, dungeonID)
    if not ok or type(total) ~= "number" or total <= 0 then return nil end

    -- Blizzard'in kendi ikinci donusu. Sacma bir deger gelirse yok say.
    if type(completed) ~= "number" or completed < 0 or completed > total then
        completed = nil
    end

    -- Bagimsiz sayim: hem yedek hem capraz kontrol.
    local loop
    if type(_G.GetLFGDungeonEncounterInfo) == "function" then
        local n = 0
        local scan = (total < MAX_SCAN) and total or MAX_SCAN
        for i = 1, scan do
            local ok2, _name, _tex, isKilled = pcall(_G.GetLFGDungeonEncounterInfo, dungeonID, i)
            if ok2 and isKilled then n = n + 1 end
        end
        loop = n
    end

    local shown = completed or loop
    if type(shown) ~= "number" then return nil end
    return shown, total
end

---------------------------------------------------------------------------
-- Yerlesim yardimcilari
---------------------------------------------------------------------------
-- Blizzard bazi wing'lere 16x16'lik "degistirilmis zindan" (Fated/Timewalking)
-- ikonunu SetPoint("RIGHT") ile takiyor. Ikon yerel bir degisken, butonda
-- saklanmiyor -- o yuzden SAGA capalanmis bolgeleri tarayip yer ayiriyoruz.
-- Bizim initializer EN SON kostugu icin o ikon bu noktada zaten var.
local function ReservedRight(button)
    local reserved = 0
    local ok = pcall(function()
        if type(button.GetRegions) ~= "function" then return end
        local regions = { button:GetRegions() }
        for i = 1, #regions do
            local r = regions[i]
            if r and type(r.IsObjectType) == "function" and r:IsObjectType("Texture")
               and type(r.GetPoint) == "function" then
                local shown = (type(r.IsShown) ~= "function") or r:IsShown()
                if shown then
                    local n = (type(r.GetNumPoints) == "function") and r:GetNumPoints() or 1
                    for p = 1, n do
                        local point, _rel, _relPoint, xOfs = r:GetPoint(p)
                        if point == "RIGHT" then
                            local w = (type(r.GetWidth) == "function" and r:GetWidth()) or 0
                            local need = w - (xOfs or 0)   -- icerideyken xOfs negatif
                            if need > reserved then reserved = need end
                        end
                    end
                end
            end
        end
    end)
    if not ok then return 0 end
    return reserved
end

local function PickColor(shown, total)
    if shown >= total then return _G.GREEN_FONT_COLOR end
    if shown > 0     then return _G.HIGHLIGHT_FONT_COLOR end
    return _G.DISABLED_FONT_COLOR
end

---------------------------------------------------------------------------
-- Bir wing satirini susle
---------------------------------------------------------------------------
local function DecorateWing(desc, dungeonID)
    desc:AddInitializer(function(button, _description, _menu)
        local ok, err = pcall(function()
            -- Compositor button:CreateFontString()'i YASAKLIYOR. Buradaki tek
            -- mesru yol AttachFontString; havuz temizligini de o yapiyor.
            if type(button.AttachFontString) ~= "function" then
                D.attachFontString = false
                return
            end
            D.attachFontString = true

            local shown, total = WingProgress(dungeonID)
            if not shown or not total then return end

            local fs = button:AttachFontString()
            if not fs then return end

            -- Satir devre disiyken Blizzard butun alt bolgeleri gri yapip
            -- doygunlugunu dusuruyor; kendi ikonu icin de ayni bayragi
            -- kullaniyor. Bu bir BOYUT bayragi DEGIL, sadece renk.
            fs.noRecurseHierarchy = true

            -- Compositor fontstring'lerinde SetFont yasak, SetFontObject serbest.
            if type(fs.SetFontObject) == "function" then
                fs:SetFontObject("GameFontHighlightSmall")
            end
            if type(fs.SetJustifyH) == "function" then fs:SetJustifyH("RIGHT") end
            if type(fs.SetHeight)   == "function" then fs:SetHeight(20) end

            local text = ("%d/%d"):format(shown, total)

            -- KRITIK: AttachFontString varsayilan olarak SetWidth(150) yapiyor.
            -- Bolgeyi metnine oturtmazsan olculen kutu ~150px buyuyor ve TUM
            -- acilir liste sisiyor. SetTextToFit bunun cozumu; alt dal yedek.
            if type(fs.SetTextToFit) == "function" then
                fs:SetTextToFit(text)
            else
                if type(fs.SetText) == "function" then fs:SetText(text) end
                if type(fs.SetWidth) == "function"
                   and type(fs.GetUnboundedStringWidth) == "function" then
                    fs:SetWidth(fs:GetUnboundedStringWidth())
                end
            end

            local color = PickColor(shown, total)
            if color and type(color.GetRGB) == "function"
               and type(fs.SetTextColor) == "function" then
                fs:SetTextColor(color:GetRGB())
            end

            local reserved = ReservedRight(button)
            local offset = -(RIGHT_PAD + ((reserved > 0) and (reserved + ICON_GAP) or 0))
            if type(fs.SetPoint) == "function" then
                fs:SetPoint("RIGHT", offset, 0)
            end

            D.lastDecorated = D.lastDecorated + 1
        end)
        if not ok then D.errInit = tostring(err) end
        -- BILEREK hicbir sey dondurmuyoruz. (w,h) dondurmek compositor'un
        -- birlesik olcumunu ezer ve Blizzard'in ikon aritmetigini de bizim
        -- sorumlulugumuza sokar -- orada bir hata GERCEK kirpilma uretir.
        -- Olcume birakinca sayac tanim geregi kutunun icinde kalir.
    end)
end

---------------------------------------------------------------------------
-- Menu kancasi
---------------------------------------------------------------------------
local function OnMenuGenerated(_ownerRegion, rootDescription, _contextData)
    if not Enabled() then return end
    local ok, err = pcall(function()
        D.cbFired = D.cbFired + 1
        D.lastDecorated = 0
        if not rootDescription
           or type(rootDescription.EnumerateElementDescriptions) ~= "function" then
            return
        end

        local elements, wings = 0, 0
        for _i, desc in rootDescription:EnumerateElementDescriptions() do
            elements = elements + 1
            if desc and type(desc.GetData) == "function"
                    and type(desc.AddInitializer) == "function" then
                local okData, data = pcall(desc.GetData, desc)
                if okData and type(data) == "number" then
                    -- Basliklar ("The Venomous Abyss") CreateTitle ile geliyor:
                    -- veri tasimiyorlar ve radio degiller. Sayisal veri testi
                    -- tek basina onlari zaten eliyor; IsRadio ikinci, bagimsiz
                    -- ayirici.
                    local isRadio = true
                    if type(desc.IsRadio) == "function" then
                        local okR, r = pcall(desc.IsRadio, desc)
                        if okR then isRadio = (r and true or false) end
                    end
                    if isRadio then
                        wings = wings + 1
                        DecorateWing(desc, data)
                    end
                end
            end
        end
        D.lastElements = elements
        D.lastWings = wings
    end)
    if not ok then D.errCb = tostring(err) end
end

local function Install()
    if D.installed then return end
    if type(_G.Menu) ~= "table" or type(_G.Menu.ModifyMenu) ~= "function" then
        D.menuApi = false
        return
    end
    D.menuApi = true
    local ok, err = pcall(_G.Menu.ModifyMenu, MENU_TAG, OnMenuGenerated)
    if ok then
        D.installed = true
    else
        D.errInstall = tostring(err)
    end
end

---------------------------------------------------------------------------
-- Tazeleme
---------------------------------------------------------------------------
-- Kesim bilgisi sunucudan gelen kilit verisi. LFG_LOCK_INFO_RECEIVED gelmeden
-- once sayaclar HAKLI OLARAK 0/N okur. Blizzard'in kendi tazeleme yolu
-- GenerateMenu().
local function Refresh()
    pcall(function()
        local frame = _G.RaidFinderQueueFrame
        if not frame or type(frame.IsShown) ~= "function" or not frame:IsShown() then
            return
        end
        local dd = frame.SelectionDropdown or _G.RaidFinderQueueFrameSelectionDropdown
        if not dd then return end
        if type(dd.GenerateMenu) == "function" then
            dd:GenerateMenu()
        elseif type(dd.SignalUpdate) == "function" then
            dd:SignalUpdate()
        end
    end)
end

_G.AkcQOL_RefreshLFRWings = Refresh   -- ayar panelinden aninda tazeleme

local ev = CreateFrame("Frame", "AkcQOLLFRWings")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("LFG_LOCK_INFO_RECEIVED")
ev:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        -- Girise kaydetmek, Menu.ModifyMenu'nun "bu tag bu oturumda zaten
        -- uretildiyse hemen calis" yolunun canli bir tanimi CIFT suslemesini
        -- imkansiz kilar: LFR menusu bu noktada henuz uretilmis olamaz.
        Install()
    else
        Refresh()
    end
end)

---------------------------------------------------------------------------
-- /lfrwing -- neyin tutmadigini SOYLER, tahmin ettirmez
---------------------------------------------------------------------------
local function Print(msg)
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage("|cFF8C5CFFAkcQOL|r: " .. tostring(msg))
    end
end

SLASH_AKCLFRWING1 = "/lfrwing"
SlashCmdList["AKCLFRWING"] = function(msg)
    msg = (msg or ""):lower():match("^%s*(%S*)")
    if msg == "wings" then
        Print("=== wing verisi ===")
        local dd = _G.RaidFinderQueueFrame
            and (_G.RaidFinderQueueFrame.SelectionDropdown
                 or _G.RaidFinderQueueFrameSelectionDropdown)
        if not dd then
            Print("  Raid Finder acilir listesi bulunamadi -- pencereyi ac.")
            return
        end
        local n = 0
        for i = 1, 2000 do
            local ok, name = pcall(_G.GetLFGDungeonInfo, i)
            if ok and type(name) == "string" then
                local shown, total = WingProgress(i)
                if shown and total and total > 0 then
                    n = n + 1
                    if n <= 25 then
                        Print(("  [%d] %s -> %d/%d"):format(i, name, shown, total))
                    end
                end
            end
        end
        Print(("  toplam %d wing bulundu"):format(n))
        return
    end

    Print("=== LFR wing sayaci ===")
    Print("  ayar ACIK mi: " .. tostring(Enabled()))
    Print("  Menu API var mi: " .. tostring(D.menuApi)
        .. "  |  kanca kuruldu: " .. tostring(D.installed))
    Print(("  menu uretimi: %d kez  |  son: %d eleman, %d wing, %d suslendi")
        :format(D.cbFired, D.lastElements, D.lastWings, D.lastDecorated))
    Print("  AttachFontString: " .. (D.attachFontString == nil and "HENUZ CALISMADI"
        or tostring(D.attachFontString)))
    if D.errInstall then Print("  |cFFFF5555kurulum hatasi:|r " .. D.errInstall) end
    if D.errCb      then Print("  |cFFFF5555menu hatasi:|r " .. D.errCb) end
    if D.errInit    then Print("  |cFFFF5555cizim hatasi:|r " .. D.errInit) end
    if D.cbFired == 0 then
        Print("  ipucu: Dungeons & Raids -> Raid Finder -> Raid listesini bir kez ac.")
    end
    Print("  /lfrwing wings  -> her wing'in ham sayilari")
end

addon.LFRWings = { Progress = WingProgress, Debug = D }
