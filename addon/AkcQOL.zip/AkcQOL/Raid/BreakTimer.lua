
local _, addon = ...

local L = AkcQOL_L
local Theme = AkcQOL_Theme

local PREFIX_TEXT = "|cff8c5cffAkc|r|cffffffffQOL|r: "
local MAX_SECONDS = 3600
local MIN_SECONDS = 1
local BREAK_TIMER_TOP_OFFSET = -105
local ACCEPTED_CHANNELS = {
    RAID = true,
    PARTY = true,
    INSTANCE_CHAT = true,
}

local breakFrame
local ticker
local activeEndTime
local activeDuration
local activeSender
local activeSource
local manuallyHiddenEndTime

local function Now()
    if GetServerTime then
        local ok, value = pcall(GetServerTime)
        if ok and tonumber(value) then return tonumber(value) end
    end
    return time()
end

local function Trim(text)
    text = tostring(text or "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    return text
end

local function StripRealm(name)
    name = Trim(name)
    name = name:gsub("|K.-|k", "")
    name = name:gsub("%s+", "")
    name = Ambiguate and Ambiguate(name, "none") or name
    name = name:match("^([^%-]+)") or name
    return string.lower(name)
end

local function EnsureDB()
    local profile = addon.AkcQOL and addon.AkcQOL.db and addon.AkcQOL.db.profile
    if profile then
        if type(profile.breakTimer) ~= "table" then profile.breakTimer = {} end
        local db = profile.breakTimer
        local legacy = type(AkcQOLRaidCDDB) == "table" and AkcQOLRaidCDDB.breakTimer
        if type(legacy) == "table" then
            if db.endTime == nil then db.endTime = legacy.endTime end
            if db.duration == nil then db.duration = legacy.duration end
            if db.sender == nil then db.sender = legacy.sender end
            if db.source == nil then db.source = legacy.source end
            if db.hiddenEndTime == nil then db.hiddenEndTime = legacy.hiddenEndTime end
            AkcQOLRaidCDDB.breakTimer = nil
        end
        return db
    end

    if type(AkcQOLRaidCDDB) ~= "table" then AkcQOLRaidCDDB = {} end
    if type(AkcQOLRaidCDDB.breakTimer) ~= "table" then
        AkcQOLRaidCDDB.breakTimer = {}
    end
    return AkcQOLRaidCDDB.breakTimer
end

local function IsEnabled()

    return EnsureDB().enabled ~= false
end

local function ClearSaved()
    local db = EnsureDB()
    db.endTime = nil
    db.duration = nil
    db.sender = nil
    db.source = nil
    db.hiddenEndTime = nil
end

local function IsAddOnLoadedSafe(name)
    if not name or name == "" then return false end
    if C_AddOns and C_AddOns.IsAddOnLoaded then
        local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, name)
        if ok and loaded then return true end
    end
    if IsAddOnLoaded then
        local ok, loaded = pcall(IsAddOnLoaded, name)
        if ok and loaded then return true end
    end
    return false
end

local function HasBossModTimer()
    if _G.DBM or _G.BigWigs then return true end
    return IsAddOnLoadedSafe("DBM-Core") or IsAddOnLoadedSafe("BigWigs")
end

local function IsSenderSelf(sender)
    local player = UnitName and UnitName("player") or nil
    if not player then return false end
    return StripRealm(sender) == StripRealm(player)
end

local function IsSenderTrusted(sender)
    if IsSenderSelf(sender) then return true end
    if not IsInGroup or not IsInGroup() then return false end

    local wanted = StripRealm(sender)
    if wanted == "" then return false end

    if IsInRaid and IsInRaid() then
        local count = GetNumGroupMembers and GetNumGroupMembers() or 0
        for i = 1, count do
            local name, rank = GetRaidRosterInfo(i)
            if name and StripRealm(name) == wanted then
                return (tonumber(rank) or 0) > 0
            end
        end
        return false
    end

    for i = 1, 4 do
        local unit = "party" .. i
        if UnitExists and UnitExists(unit) then
            local name = UnitName(unit)
            if name and StripRealm(name) == wanted then
                if UnitIsGroupLeader and UnitIsGroupLeader(unit) then return true end
                if UnitIsGroupAssistant and UnitIsGroupAssistant(unit) then return true end
                return false
            end
        end
    end

    return false
end

local function StopTicker()
    if ticker then
        ticker:Cancel()
        ticker = nil
    end
end

local function FormatRemaining(seconds)
    seconds = math.max(0, math.ceil(tonumber(seconds) or 0))
    local minutes = math.floor(seconds / 60)
    local remain = seconds % 60
    return string.format("%d:%02d", minutes, remain)
end

local function ApplyFrameSettings()
    if not breakFrame then return end
    local db = EnsureDB()
    breakFrame:ClearAllPoints()
    if db.point then
        breakFrame:SetPoint(db.point, UIParent, db.relPoint or db.point, db.xOfs or 0, db.yOfs or 0)
    else
        breakFrame:SetPoint("TOP", UIParent, "TOP", 0, BREAK_TIMER_TOP_OFFSET)
    end
    breakFrame:EnableMouse(db.locked == false)
end

local FRAME_W, FRAME_H = 250, 96
local BAR_PAD, BAR_H = 10, 7
local BAR_MAX_W = FRAME_W - (BAR_PAD * 2)

local PHASE_COLORS = {
    normal = { 0.549, 0.361, 1.000 },
    warn   = { 0.960, 0.620, 0.040 },
    urgent = { 0.950, 0.350, 0.310 },
    done   = { 0.350, 0.850, 0.450 },
}

local function SpacedUpper(text)
    return (tostring(text):upper():gsub("(.)", "%1 "):gsub(" $", ""))
end

local function EnsureFrame()
    if breakFrame then return breakFrame end

    breakFrame = CreateFrame("Frame", "AkcQOLBreakTimerFrame", UIParent, "BackdropTemplate")
    breakFrame:SetSize(FRAME_W, FRAME_H)
    breakFrame:SetFrameStrata("DIALOG")
    breakFrame:SetFrameLevel(900)
    breakFrame:SetClampedToScreen(true)
    breakFrame:EnableMouse(false)
    breakFrame:SetMovable(true)
    Theme.ApplyWindow(breakFrame)
    breakFrame:RegisterForDrag("LeftButton")
    breakFrame:SetScript("OnDragStart", function(self)
        if EnsureDB().locked ~= false then return end
        self:StartMoving()
        self.akcMoving = true
    end)
    breakFrame:SetScript("OnDragStop", function(self)
        if not self.akcMoving then return end
        self.akcMoving = nil
        self:StopMovingOrSizing()
        local point, relativeTo, relPoint, xOfs, yOfs = self:GetPoint()

        if relativeTo == nil or relativeTo == UIParent then
            local db = EnsureDB()
            db.point = point
            db.relPoint = relPoint
            db.xOfs = xOfs
            db.yOfs = yOfs
        end
    end)
    ApplyFrameSettings()

    local header = breakFrame:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(header, 12, "", true)
    header:SetPoint("TOPLEFT", 12, -10)
    header:SetTextColor(Theme.rgba(Theme.colors.accent))
    header:SetText(SpacedUpper(L["Break"]))
    breakFrame.header = header

    local sub = breakFrame:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(sub, 10, "")
    sub:SetPoint("TOPRIGHT", -24, -12)
    sub:SetTextColor(Theme.rgba(Theme.colors.textMuted))
    sub:SetText("")
    breakFrame.sub = sub

    local timeText = breakFrame:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(timeText, 42, "", true)
    timeText:SetPoint("CENTER", 0, -4)
    timeText:SetTextColor(0.92, 0.92, 0.95, 1)
    timeText:SetText("0:00")
    breakFrame.timeText = timeText

    local pulse = timeText:CreateAnimationGroup()
    local pulseAlpha = pulse:CreateAnimation("Alpha")
    pulseAlpha:SetFromAlpha(1)
    pulseAlpha:SetToAlpha(0.4)
    pulseAlpha:SetDuration(0.4)
    pulse:SetLooping("BOUNCE")
    breakFrame.pulse = pulse

    local barBG = breakFrame:CreateTexture(nil, "ARTWORK", nil, 1)
    barBG:SetColorTexture(Theme.rgba(Theme.colors.insetBg))
    barBG:SetPoint("BOTTOMLEFT", BAR_PAD, BAR_PAD)
    barBG:SetSize(BAR_MAX_W, BAR_H)
    breakFrame.barBG = barBG

    local barFill = breakFrame:CreateTexture(nil, "ARTWORK", nil, 2)
    barFill:SetPoint("BOTTOMLEFT", barBG, "BOTTOMLEFT", 0, 0)
    barFill:SetSize(BAR_MAX_W, BAR_H)
    barFill:SetColorTexture(unpack(PHASE_COLORS.normal))
    breakFrame.barFill = barFill

    local barCap = breakFrame:CreateTexture(nil, "ARTWORK", nil, 3)
    barCap:SetColorTexture(1, 1, 1, 0.85)
    barCap:SetSize(2, BAR_H)
    barCap:SetPoint("LEFT", barFill, "RIGHT", -1, 0)
    breakFrame.barCap = barCap

    local flash = breakFrame:CreateTexture(nil, "OVERLAY", nil, 7)
    flash:SetAllPoints()
    flash:SetColorTexture(0.35, 0.85, 0.45, 1)
    flash:SetAlpha(0)
    local flashAnim = flash:CreateAnimationGroup()
    local flashAlpha = flashAnim:CreateAnimation("Alpha")
    flashAlpha:SetFromAlpha(0.5)
    flashAlpha:SetToAlpha(0)
    flashAlpha:SetDuration(0.7)
    flashAnim:SetScript("OnFinished", function() flash:SetAlpha(0) end)
    breakFrame.flashAnim = flashAnim

    function breakFrame:SetPhase(key)
        local c = PHASE_COLORS[key] or PHASE_COLORS.normal
        self.barFill:SetColorTexture(c[1], c[2], c[3], 0.92)
        if key == "normal" then
            self.timeText:SetTextColor(0.92, 0.92, 0.95, 1)
        else
            self.timeText:SetTextColor(c[1], c[2], c[3], 1)
        end
        if key == "urgent" then
            if not self.pulsing then
                self.pulsing = true
                self.pulse:Play()
            end
        elseif self.pulsing then
            self.pulsing = nil
            self.pulse:Stop()
            self.timeText:SetAlpha(1)
        end
    end

    function breakFrame:SetBar(frac)
        frac = math.max(0, math.min(1, tonumber(frac) or 0))
        self.barFill:SetWidth(math.max(0.001, frac * BAR_MAX_W))
        self.barCap:SetShown(frac > 0.01 and frac < 1)
    end

    local close = CreateFrame("Button", nil, breakFrame)
    close:SetSize(18, 18)
    close:SetPoint("TOPRIGHT", breakFrame, "TOPRIGHT", -4, -4)
    close:EnableMouse(true)
    close:SetHitRectInsets(-4, -4, -4, -4)
    close.text = close:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(close.text, 13, "")
    close.text:SetAllPoints()
    close.text:SetJustifyH("CENTER")
    close.text:SetJustifyV("MIDDLE")
    close.text:SetTextColor(0.62, 0.62, 0.70, 0.8)
    close.text:SetText("×")
    close:SetScript("OnEnter", function(self)
        self.text:SetTextColor(0.95, 0.35, 0.31, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(L["Close break timer"], 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    close:SetScript("OnLeave", function(self)
        self.text:SetTextColor(0.62, 0.62, 0.70, 0.8)
        GameTooltip:Hide()
    end)
    close:SetScript("OnClick", function()
        if activeEndTime then
            manuallyHiddenEndTime = activeEndTime
            local db = EnsureDB()
            db.hiddenEndTime = activeEndTime
        end
        breakFrame:Hide()
    end)
    breakFrame.close = close

    breakFrame:SetScript("OnHide", function(self)
        if self.pulsing then
            self.pulsing = nil
            self.pulse:Stop()
            self.timeText:SetAlpha(1)
        end
    end)

    breakFrame:Hide()
    return breakFrame
end

local function SenderLabel()
    if activeSource == "Test" then
        return L["test"]
    end
    if activeSender and not IsSenderSelf(activeSender) then
        local name = Ambiguate and Ambiguate(activeSender, "none") or tostring(activeSender)
        name = name:match("^([^%-]+)") or name
        if name ~= "" then return name end
    end
    return ""
end

local function PaintRemaining()
    if not activeEndTime then return end

    local remaining = activeEndTime - Now()
    if remaining <= 0 then

        local wasHidden = manuallyHiddenEndTime ~= nil and activeEndTime == manuallyHiddenEndTime
        StopTicker()
        ClearSaved()
        activeEndTime = nil
        activeDuration = nil
        activeSender = nil
        activeSource = nil
        manuallyHiddenEndTime = nil

        if wasHidden or not IsEnabled() then
            if breakFrame then breakFrame:Hide() end
            return
        end

        if EnsureDB().sound ~= false and PlaySound then
            local kit = type(SOUNDKIT) == "table" and (SOUNDKIT.RAID_WARNING or SOUNDKIT.READY_CHECK)
            if kit then pcall(PlaySound, kit, "Master") end
        end

        local f = EnsureFrame()
        f.header:SetText(SpacedUpper(L["Break over"]))
        f.sub:SetText("")
        f.timeText:SetText(L["GO!"])
        f:SetPhase("done")
        f:SetBar(0)
        f.flashAnim:Play()
        f:Show()
        C_Timer.After(2.5, function()
            if not activeEndTime and breakFrame then
                breakFrame:Hide()
                breakFrame.header:SetText(SpacedUpper(L["Break"]))
                breakFrame.timeText:SetText("0:00")
                breakFrame:SetPhase("normal")
                breakFrame:SetBar(1)
            end
        end)
        return
    end

    if not IsEnabled() or (manuallyHiddenEndTime and activeEndTime == manuallyHiddenEndTime) then
        if breakFrame then breakFrame:Hide() end
        return
    end

    local f = EnsureFrame()
    local frac = 1
    if activeDuration and activeDuration > 0 then
        frac = remaining / activeDuration
    end

    f.header:SetText(SpacedUpper(L["Break"]))
    f.sub:SetText(SenderLabel())
    f.timeText:SetText(FormatRemaining(remaining))
    if remaining <= 10 then
        f:SetPhase("urgent")
    elseif frac <= 0.5 then
        f:SetPhase("warn")
    else
        f:SetPhase("normal")
    end
    f:SetBar(frac)
    f:Show()
end

local function SaveActive()
    local db = EnsureDB()
    db.endTime = activeEndTime
    db.duration = activeDuration
    db.sender = activeSender
    db.source = activeSource
    db.hiddenEndTime = manuallyHiddenEndTime
end

local function StartBreak(seconds, sender, source)
    if not IsEnabled() then return end
    seconds = math.floor(tonumber(seconds) or 0)
    if seconds < MIN_SECONDS then return end
    if seconds > MAX_SECONDS then seconds = MAX_SECONDS end
    if IsEncounterInProgress and IsEncounterInProgress() then return end

    activeDuration = seconds
    activeEndTime = Now() + seconds
    activeSender = sender
    activeSource = source
    manuallyHiddenEndTime = nil

    SaveActive()
    StopTicker()
    PaintRemaining()
    ticker = C_Timer.NewTicker(0.1, PaintRemaining)
end

local function CancelBreak()
    StopTicker()
    ClearSaved()
    activeEndTime = nil
    activeDuration = nil
    activeSender = nil
    activeSource = nil
    manuallyHiddenEndTime = nil
    if breakFrame then breakFrame:Hide() end
end

local function RestoreSaved()
    if not IsEnabled() then return end
    local db = EnsureDB()
    local endTime = tonumber(db.endTime)
    local duration = tonumber(db.duration)
    if not endTime or endTime <= Now() then
        ClearSaved()
        return
    end

    activeEndTime = endTime
    activeDuration = duration or math.max(MIN_SECONDS, endTime - Now())
    activeSender = db.sender
    activeSource = db.source or "Restored"
    manuallyHiddenEndTime = tonumber(db.hiddenEndTime) == endTime and endTime or nil
    StopTicker()
    PaintRemaining()
    ticker = C_Timer.NewTicker(0.1, PaintRemaining)
end

local function HandleBreakMessage(seconds, sender, source)
    seconds = tonumber(seconds)
    if not seconds then return end
    if seconds <= 0 then
        if IsSenderTrusted(sender) then
            CancelBreak()
        end
        return
    end
    if seconds > MAX_SECONDS then return end
    if not IsSenderTrusted(sender) then return end
    StartBreak(seconds, sender, source)
end

local function ParseD5(message, sender)
    local ok, _, _, subPrefix, seconds = pcall(strsplit, "\t", tostring(message or ""))
    if not ok or subPrefix ~= "BT" then return end
    HandleBreakMessage(seconds, sender, "DBM/BigWigs")
end

local function ParseBigWigs(message, sender)
    local ok, prefix, msg, seconds = pcall(strsplit, "^", tostring(message or ""))
    if not ok then return end
    if prefix == "P" and msg == "Break" then
        HandleBreakMessage(seconds, sender, "BigWigs")
    end
end

local function ParseBigBreak(message, sender)
    local ok, cmd, value = pcall(strsplit, "\t", tostring(message or ""))
    if not ok or not cmd then return end

    if cmd == "BREAK" then
        HandleBreakMessage(value, sender, "BigBreak")
    elseif cmd == "CANCEL" then
        if IsSenderTrusted(sender) then
            CancelBreak()
        end
    end
end

local function RegisterPrefixes()
    if not C_ChatInfo or not C_ChatInfo.RegisterAddonMessagePrefix then return end
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, "D5")
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, "BigWigs")
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, "BigBreak")
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("ENCOUNTER_START")
events:RegisterEvent("GROUP_LEFT")
events:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        if event == "PLAYER_LOGIN" then RegisterPrefixes() end

        if HasBossModTimer() then
            self:UnregisterEvent("CHAT_MSG_ADDON")
        end
        RestoreSaved()
        return
    end

    if event == "ENCOUNTER_START" or event == "GROUP_LEFT" then
        if activeEndTime then CancelBreak() end
        return
    end

    if event ~= "CHAT_MSG_ADDON" then return end
    local prefix, message, channel, sender = ...
    if not ACCEPTED_CHANNELS[channel] then return end

    if prefix == "D5" then
        ParseD5(message, sender)
    elseif prefix == "BigWigs" then
        ParseBigWigs(message, sender)
    elseif prefix == "BigBreak" then
        ParseBigBreak(message, sender)
    end
end)

SLASH_AKCQOLBREAK1 = "/akcbreak"
SlashCmdList.AKCQOLBREAK = function(msg)
    msg = string.lower(Trim(msg or ""))
    if msg == "off" or msg == "cancel" or msg == "0" then
        CancelBreak()
        return
    end

    if not IsEnabled() then
        print(PREFIX_TEXT .. L["The break timer is disabled in the AkcQOL options."])
        return
    end

    local seconds = tonumber(msg)
    if msg == "" or msg == "test" then seconds = 30 end
    if not seconds or seconds < MIN_SECONDS then
        print(PREFIX_TEXT .. L["Usage: /akcbreak 30, /akcbreak test, or /akcbreak off"])
        return
    end

    StartBreak(seconds, UnitName and UnitName("player") or "player", "Test")
end

function addon.BreakTimer_ApplySettings()
    local db = EnsureDB()
    EnsureFrame()
    ApplyFrameSettings()

    if db.enabled == false then
        StopTicker()
        breakFrame:Hide()
        return
    end

    if not activeEndTime then RestoreSaved() end
    if activeEndTime then
        if not ticker then ticker = C_Timer.NewTicker(0.1, PaintRemaining) end
        PaintRemaining()
    end

    if db.locked == false then
        if not activeEndTime then
            breakFrame.header:SetText(SpacedUpper(L["Break"]))
            breakFrame.sub:SetText(L["drag to move"])
            breakFrame.timeText:SetText("5:00")
            breakFrame:SetPhase("normal")
            breakFrame:SetBar(0.72)
            breakFrame:Show()
        end
    elseif not activeEndTime then
        breakFrame:Hide()
    end
end

addon.StartBreakTimer = StartBreak
addon.CancelBreakTimer = CancelBreak
