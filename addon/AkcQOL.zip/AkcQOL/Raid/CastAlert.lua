local _, addon = ...

local DEFAULT_MESSAGE = "CASTING ON YOU!"

local lastPlay = 0
local screenFrame
local hideToken = 0
local watchers = {}
local nameplatesHooked = false

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.castAlert) ~= "table" then g.castAlert = {} end
    local d = g.castAlert
    if d.enabled == nil then d.enabled = false end
    if d.onlyInstances == nil then d.onlyInstances = true end
    if d.screen == nil then d.screen = true end
    if type(d.soundStyle) ~= "string" then d.soundStyle = "bosswarn" end
    if type(d.volume) ~= "number" then d.volume = 100 end
    if type(d.throttle) ~= "number" then d.throttle = 2 end
    if type(d.message) ~= "string" or d.message == "" then d.message = DEFAULT_MESSAGE end
    return d
end

local function PlayStyle(style)
    if addon.PlayAlertSoundStyle then addon:PlayAlertSoundStyle(style, DB().volume) end
end

local function EnsureScreenFrame()
    if screenFrame then return screenFrame end
    local frame = CreateFrame("Frame", "AkcQOLCastAlertFrame", UIParent)
    frame:SetSize(520, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 170)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(22)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(1, 0.30, 0.25, 1)

    screenFrame = frame
    return screenFrame
end

local function ShowScreenAlert(text)
    local frame = EnsureScreenFrame()
    frame.text:SetText(text)
    frame:SetAlpha(1)
    frame:Show()

    hideToken = hideToken + 1
    local token = hideToken
    if C_Timer and C_Timer.After then
        C_Timer.After(1.6, function()
            if hideToken ~= token or not screenFrame then return end
            screenFrame:Hide()
        end)
    end

    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(text, 1, 0.30, 0.25, 1)
    end
end

local function SafeIsUnit(a, b)
    local ok, v = pcall(UnitIsUnit, a, b)
    return ok and v == true
end

local function SafeSpellName(unit)
    local ok, name = pcall(UnitCastingInfo, unit)
    if ok and issecretvalue and issecretvalue(name) then name = nil end
    if not ok or type(name) ~= "string" or name == "" then
        ok, name = pcall(UnitChannelInfo, unit)
        if ok and issecretvalue and issecretvalue(name) then name = nil end
    end
    if ok and type(name) == "string" and name ~= "" then return name end
    return nil
end

local function OnCastStart(unit)
    local d = DB()
    if d.enabled == false then return end
    if d.onlyInstances and not IsInInstance() then return end
    if not UnitExists(unit) then return end

    local okAttack, canAttack = pcall(UnitCanAttack, "player", unit)
    if not okAttack or canAttack ~= true then return end

    local okPlayer, isPlayer = pcall(UnitIsPlayer, unit)
    if okPlayer and isPlayer then return end

    if not SafeIsUnit(unit .. "target", "player") then return end

    local now = GetTime()
    if (now - lastPlay) < (d.throttle or 2) then return end
    lastPlay = now

    PlayStyle(d.soundStyle)

    if d.screen ~= false then
        local msg = string.upper(d.message or DEFAULT_MESSAGE)
        local spell = SafeSpellName(unit)
        if spell then
            msg = string.upper(spell) .. "  \226\128\162  " .. msg
        end
        ShowScreenAlert(msg)
    end
end

local function AttachWatcher(unit)
    local w = watchers[unit]
    if not w then
        w = CreateFrame("Frame")
        w:SetScript("OnEvent", function(_, _, castUnit)
            pcall(OnCastStart, castUnit)
        end)
        watchers[unit] = w
    end
    w:RegisterUnitEvent("UNIT_SPELLCAST_START", unit)
    w:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", unit)
end

local function DetachWatcher(unit)
    local w = watchers[unit]
    if w then w:UnregisterAllEvents() end
end

local eventFrame = CreateFrame("Frame")

local function Sync()
    local d = DB()
    if d.enabled ~= false then
        if not nameplatesHooked then
            eventFrame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
            eventFrame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
            nameplatesHooked = true
        end
        if C_NamePlate and C_NamePlate.GetNamePlates then
            local ok, plates = pcall(C_NamePlate.GetNamePlates)
            if ok and type(plates) == "table" then
                for _, plate in ipairs(plates) do
                    if plate.namePlateUnitToken then
                        AttachWatcher(plate.namePlateUnitToken)
                    end
                end
            end
        end
    else
        if nameplatesHooked then
            eventFrame:UnregisterEvent("NAME_PLATE_UNIT_ADDED")
            eventFrame:UnregisterEvent("NAME_PLATE_UNIT_REMOVED")
            nameplatesHooked = false
        end
        for unit in pairs(watchers) do DetachWatcher(unit) end
        if screenFrame then screenFrame:Hide() end
    end
end

function _G.AkcQOL_TestCastAlert()
    local d = DB()
    PlayStyle(d.soundStyle)
    ShowScreenAlert("SHADOW BOLT  \226\128\162  " .. string.upper(d.message or DEFAULT_MESSAGE))
end

function _G.AkcQOL_ApplyCastAlert()
    DB()
    Sync()
end

function _G.AkcQOL_ResetCastAlertDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.castAlert = nil end
    DB()
    Sync()
end

eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function(_, event, unit)
    if event == "PLAYER_LOGIN" then
        DB()
        Sync()
        return
    end
    if event == "NAME_PLATE_UNIT_ADDED" then
        AttachWatcher(unit)
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        DetachWatcher(unit)
    end
end)
