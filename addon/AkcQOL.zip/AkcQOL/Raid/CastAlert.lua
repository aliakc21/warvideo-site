local _, addon = ...

local DEFAULT_MESSAGE = "CASTING ON YOU!"

local lastPlay = 0
local screenFrame
local hideToken = 0
local watchers = {}
local nameplatesHooked = false

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.castAlert) ~= "table" then g.castAlert = {} end
    local d = g.castAlert
    if d.enabled == nil then d.enabled = false end
    if d.onlyInstances == nil then d.onlyInstances = true end
    if d.screen == nil then d.screen = true end
    if type(d.soundStyle) ~= "string" then d.soundStyle = "bosswarn" end
    if type(d.volume) ~= "number" then d.volume = 100 end
    if type(d.throttle) ~= "number" then d.throttle = 2 end
    if type(d.message) ~= "string" or d.message == "" then d.message = DEFAULT_MESSAGE end
    return d
end

local function PlayStyle(style)
    if addon.PlayAlertSoundStyle then addon:PlayAlertSoundStyle(style, DB().volume) end
end

local function EnsureScreenFrame()
    if screenFrame then return screenFrame end
    local frame = CreateFrame("Frame", "AkcQOLCastAlertFrame", UIParent)
    frame:SetSize(520, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 170)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(22)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(1, 0.30, 0.25, 1)

    if _G.AkcQOL_SetupMovableAlert then
        _G.AkcQOL_SetupMovableAlert("castAlert", frame, function()
            return string.upper(DB().message or DEFAULT_MESSAGE)
        end)
    end

    screenFrame = frame
    return screenFrame
end

-- The engine is allowed to turn a secret boolean into visibility, so the
-- warning can light up exactly when the cast really is aimed at the player
-- while the addon never learns whether it was.
local function ShowScreenAlertForSecret(text, secretBool, secretSpellName)
    local frame = EnsureScreenFrame()
    if not frame.SetAlphaFromBoolean then return false end

    -- A secret string may be printed but not read: SetFormattedText accepts
    -- it, so the spell name shows up even in restricted content.
    local wrote = false
    if secretSpellName ~= nil and frame.text.SetFormattedText then
        wrote = pcall(frame.text.SetFormattedText, frame.text, "%s  \226\128\162  %s", secretSpellName, text)
    end
    if not wrote then frame.text:SetText(text) end

    local ok = pcall(frame.SetAlphaFromBoolean, frame, secretBool, 1, 0)
    if not ok then
        ok = pcall(frame.SetAlphaFromBoolean, frame, secretBool)
    end
    if not ok then return false end
    frame:Show()

    hideToken = hideToken + 1
    local token = hideToken
    if C_Timer and C_Timer.After then
        C_Timer.After(1.6, function()
            if hideToken ~= token or not screenFrame then return end
            pcall(screenFrame.SetAlpha, screenFrame, 0)
            screenFrame:Hide()
        end)
    end
    return true
end

local function ShowScreenAlert(text)
    local frame = EnsureScreenFrame()
    frame.text:SetText(text)
    frame:SetAlpha(1)
    frame:Show()

    hideToken = hideToken + 1
    local token = hideToken
    if C_Timer and C_Timer.After then
        C_Timer.After(1.6, function()
            if hideToken ~= token or not screenFrame then return end
            screenFrame:Hide()
        end)
    end

    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(text, 1, 0.30, 0.25, 1)
    end
end

-- Returns: true / false when the answer is plain, or nil plus the raw value
-- when the game hands back a secret (comparing a secret is forbidden and
-- raises an error -- that error, swallowed by the caller's pcall, is exactly
-- why this alert never fired in combat).
local function SafeIsUnit(a, b)
    local ok, v = pcall(UnitIsUnit, a, b)
    if not ok then return false end
    if issecretvalue then
        local okS, isSecret = pcall(issecretvalue, v)
        if okS and isSecret then return nil, v end
    end
    return v == true
end

local function SafeSpellName(unit)
    local ok, name = pcall(UnitCastingInfo, unit)
    if ok and issecretvalue and issecretvalue(name) then name = nil end
    if not ok or type(name) ~= "string" or name == "" then
        ok, name = pcall(UnitChannelInfo, unit)
        if ok and issecretvalue and issecretvalue(name) then name = nil end
    end
    if ok and type(name) == "string" and name ~= "" then return name end
    return nil
end

-- TEMP DIAG (remove before release)
local castDiag = false
local function DiagStep(fmt, ...)
    if not castDiag then return end
    print("|cff8c5cffAkc|r|cffffffffQOL|r cast: " .. string.format(fmt, ...))
end

-- Shared with the cast bars (this file loads first). A raid boss casting is
-- something the raid already calls out, so both displays can skip it.
-- Both tests can come back secret in restricted content; a secret answer counts
-- as "not a boss", because showing one cast too many beats hiding a real one.
function _G.AkcQOL_IsBossNameplate(unit)
    local function Plain(v)
        if issecretvalue then
            local okS, secret = pcall(issecretvalue, v)
            if okS and secret then return nil end
        end
        return v
    end

    for i = 1, 8 do
        local ok, same = pcall(UnitIsUnit, unit, "boss" .. i)
        if ok and Plain(same) == true then return true end
    end

    local okC, classification = pcall(UnitClassification, unit)
    if okC and Plain(classification) == "worldboss" then return true end

    return false
end

local function OnCastStart(unit)
    local d = DB()
    DiagStep("olay: %s (enabled=%s onlyInst=%s inInstance=%s)", tostring(unit),
        tostring(d.enabled), tostring(d.onlyInstances), tostring(IsInInstance()))
    if d.enabled == false then return end
    if d.onlyInstances and not IsInInstance() then DiagStep("  -> instance disi, cikildi") return end
    if not UnitExists(unit) then DiagStep("  -> unit yok") return end

    local okAttack, canAttack = pcall(UnitCanAttack, "player", unit)
    DiagStep("  canAttack ok=%s deger=%s", tostring(okAttack), tostring(canAttack))
    if not okAttack or canAttack ~= true then return end

    local okPlayer, isPlayer = pcall(UnitIsPlayer, unit)
    DiagStep("  isPlayer ok=%s deger=%s", tostring(okPlayer), tostring(isPlayer))
    if okPlayer and isPlayer then return end

    if d.skipBosses ~= false and _G.AkcQOL_IsBossNameplate(unit) then
        DiagStep("  -> raid boss, atlandi")
        return
    end

    -- Is the cast kickable, and can we even read that? (the real intent of
    -- this feature is an interrupt helper, not "targeting me")
    local okC, cName, _, _, _, _, _, cNotInterruptible = pcall(UnitCastingInfo, unit)
    if not okC or cName == nil then
        okC, cName, _, _, _, _, _, cNotInterruptible = pcall(UnitChannelInfo, unit)
    end
    local function Show(v)
        if issecretvalue and pcall(issecretvalue, v) and issecretvalue(v) then return "GIZLI" end
        return tostring(v)
    end
    DiagStep("  cast: ok=%s ad=%s kesilemez=%s", tostring(okC), Show(cName), Show(cNotInterruptible))

    local tokenExists = UnitExists(unit .. "target")
    local okU, isMe = pcall(UnitIsUnit, unit .. "target", "player")
    local okName, tname = pcall(UnitName, unit .. "target")
    DiagStep("  hedef: token=%s UnitIsUnit ok=%s deger=%s adi=%s", tostring(tokenExists),
        tostring(okU), tostring(isMe), tostring(okName and tname))

    local isMe, secretValue = SafeIsUnit(unit .. "target", "player")

    local now = GetTime()
    if (now - lastPlay) < (d.throttle or 2) then DiagStep("  -> throttle") return end

    local msg = string.upper(d.message or DEFAULT_MESSAGE)
    local spell = SafeSpellName(unit)
    if spell then
        msg = string.upper(spell) .. "  \226\128\162  " .. msg
    end

    if isMe == nil then
        -- Restricted combat: the answer exists but may not be read, so it is
        -- handed straight to the display. A sound cannot depend on it --
        -- playing one would mean acting on the hidden value.
        DiagStep("  -> gizli deger, goruntuye baglaniyor")
        local rawName
        do
            local okN, n = pcall(UnitCastingInfo, unit)
            if not okN or n == nil then okN, n = pcall(UnitChannelInfo, unit) end
            if okN then rawName = n end
        end
        local shown = d.screen ~= false and ShowScreenAlertForSecret(msg, secretValue, rawName)

        -- What IS readable: whether the caster is the unit the player has
        -- targeted. That is the player's own choice, not hidden information,
        -- and it is exactly the cue an interrupt needs.
        local okT, isMyTarget = pcall(UnitIsUnit, unit, "target")
        if okT and issecretvalue then
            local okS, secret = pcall(issecretvalue, isMyTarget)
            if okS and secret then okT = false end
        end
        DiagStep("  hedefim mi: ok=%s deger=%s", tostring(okT), tostring(isMyTarget))
        if okT and isMyTarget == true then
            PlayStyle(d.soundStyle)
            shown = true
        end

        if shown then lastPlay = now end
        return
    end

    if not isMe then DiagStep("  -> hedef ben degilim, cikildi") return end
    DiagStep("  -> UYARI VERILIYOR")
    lastPlay = now

    PlayStyle(d.soundStyle)
    if d.screen ~= false then
        ShowScreenAlert(msg)
    end
end

local function AttachWatcher(unit)
    local w = watchers[unit]
    if not w then
        w = CreateFrame("Frame")
        -- The event payload's unit is a secret value in 12.x and passing it
        -- to UnitExists/UnitCanAttack is rejected outright for addons, so the
        -- literal token this watcher was registered for is used instead.
        w:SetScript("OnEvent", function(self)
            pcall(OnCastStart, self.akcUnit)
        end)
        watchers[unit] = w
    end
    w.akcUnit = unit
    w:RegisterUnitEvent("UNIT_SPELLCAST_START", unit)
    w:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", unit)
end

local function DetachWatcher(unit)
    local w = watchers[unit]
    if w then w:UnregisterAllEvents() end
end

-- TEMP DIAG (remove before release): /akccast
SLASH_AKCCASTDIAG1 = "/akccast"
SlashCmdList["AKCCASTDIAG"] = function()
    castDiag = not castDiag
    local n = 0
    for _ in pairs(watchers) do n = n + 1 end
    local d = DB()
    print("|cff8c5cffAkc|r|cffffffffQOL|r cast teshis: " .. (castDiag and "ACIK" or "KAPALI")
        .. " | izleyici=" .. n .. " | enabled=" .. tostring(d.enabled)
        .. " | sadeceInstance=" .. tostring(d.onlyInstances)
        .. " | nameplate=" .. tostring(GetCVar and GetCVar("nameplateShowEnemies")))
end

local eventFrame = CreateFrame("Frame")

local function Sync()
    local d = DB()
    if d.enabled ~= false then
        if not nameplatesHooked then
            eventFrame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
            eventFrame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
            nameplatesHooked = true
        end
        if C_NamePlate and C_NamePlate.GetNamePlates then
            local ok, plates = pcall(C_NamePlate.GetNamePlates)
            if ok and type(plates) == "table" then
                for _, plate in ipairs(plates) do
                    if plate.namePlateUnitToken then
                        AttachWatcher(plate.namePlateUnitToken)
                    end
                end
            end
        end
    else
        if nameplatesHooked then
            eventFrame:UnregisterEvent("NAME_PLATE_UNIT_ADDED")
            eventFrame:UnregisterEvent("NAME_PLATE_UNIT_REMOVED")
            nameplatesHooked = false
        end
        for unit in pairs(watchers) do DetachWatcher(unit) end
        if screenFrame then screenFrame:Hide() end
    end
end

function _G.AkcQOL_TestCastAlert()
    local d = DB()
    PlayStyle(d.soundStyle)
    ShowScreenAlert("SHADOW BOLT  \226\128\162  " .. string.upper(d.message or DEFAULT_MESSAGE))
end

function _G.AkcQOL_ApplyCastAlert()
    DB()
    Sync()
end

function _G.AkcQOL_ResetCastAlertDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.castAlert = nil end
    DB()
    Sync()
    if _G.AkcQOL_ResetCastBarsPosition then _G.AkcQOL_ResetCastBarsPosition() end
    if _G.AkcQOL_ApplyCastBars then _G.AkcQOL_ApplyCastBars() end
    if _G.AkcQOL_ResetAlertPosition then
        _G.AkcQOL_ResetAlertPosition("castAlert", "CENTER", "CENTER", 0, 170)
    end
end

eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function(_, event, unit)
    if event == "PLAYER_LOGIN" then
        DB()
        Sync()
        return
    end
    if event == "NAME_PLATE_UNIT_ADDED" then
        AttachWatcher(unit)
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        DetachWatcher(unit)
    end
end)

if _G.AkcQOL_RegisterAlertBuilder then
    _G.AkcQOL_RegisterAlertBuilder("castAlert", EnsureScreenFrame)
end
