
local _, addon = ...

local L = AkcQOL_L
local Theme = AkcQOL_Theme

local REBIRTH = 20484
local RAID_DIFFS = { [14] = true, [15] = true, [16] = true, [17] = true, [33] = true, [233] = true }

local DIFF_MYTHIC_DUNGEON, DIFF_KEYSTONE_ACTIVE = 23, 8

local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.combatRez) ~= "table" then g.combatRez = {} end
    local d = g.combatRez
    if d.enabled == nil then d.enabled = false end
    if d.deathWarn == nil then d.deathWarn = true end
    if d.unlock == nil then d.unlock = false end
    return d
end

local trackerFrame
local function EnsureTracker()
    if trackerFrame then return trackerFrame end
    local f = CreateFrame("Frame", "AkcQOLCombatRezFrame", UIParent, "BackdropTemplate")
    f:SetSize(96, 34)
    local pos = DB().pos
    if pos and pos.p then
        f:SetPoint(pos.p, UIParent, pos.rp or pos.p, pos.x or 0, pos.y or 0)
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 260)
    end
    f:SetFrameStrata("MEDIUM")
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(false)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        DB().pos = { p = p, rp = rp, x = x, y = y }
    end)

    f.unlockBG = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    f.unlockBG:SetPoint("TOPLEFT", -3, 3)
    f.unlockBG:SetPoint("BOTTOMRIGHT", 3, -3)
    f.unlockBG:SetColorTexture(Theme.rgba(Theme.colors.rowHover))
    f.unlockBG:Hide()

    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(32, 32)
    f.icon:SetPoint("LEFT", 0, 0)
    local tex
    if C_Spell and C_Spell.GetSpellTexture then
        local ok, t = pcall(C_Spell.GetSpellTexture, REBIRTH)
        if ok and t and not IsSecret(t) then tex = t end
    end
    f.icon:SetTexture(tex or 136080)
    f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    f.charges = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.charges:SetPoint("LEFT", f.icon, "RIGHT", 7, 8)
    f.charges:SetTextColor(0.3, 1, 0.3, 1)
    f.charges:SetText("0")
    Theme.SetFont(f.charges, 20, "OUTLINE", true)

    f.timer = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.timer:SetPoint("TOPLEFT", f.charges, "BOTTOMLEFT", 0, -2)
    f.timer:SetTextColor(1, 0.82, 0, 1)
    f.timer:SetText("0:00")
    Theme.SetFont(f.timer, 13, "OUTLINE")

    f:Hide()
    trackerFrame = f
    return f
end

local deathFrame
local deathHideToken = 0
local function EnsureDeathText()
    if deathFrame then return deathFrame end
    local f = CreateFrame("Frame", "AkcQOLCombatRezDeathFrame", UIParent)
    f:SetSize(420, 40)
    f:SetPoint("TOP", UIParent, "TOP", 0, -190)
    f:SetFrameStrata("HIGH")
    f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.text:SetPoint("CENTER")
    f.text:SetTextColor(1, 0.25, 0.2, 1)
    f:Hide()
    deathFrame = f
    return f
end

local function ShowDeathWarning(name)
    local f = EnsureDeathText()
    f.text:SetText(string.format(L["%s died!"], name))
    f:Show()
    deathHideToken = deathHideToken + 1
    local token = deathHideToken
    C_Timer.After(4, function()
        if deathHideToken == token and deathFrame then deathFrame:Hide() end
    end)
end

local fb = { on = false, charges = 0, cap = 0, interval = 0, nextAt = 0 }
local function ArmFallback(mode)
    fb.on = true
    if mode == "mplus" then
        fb.charges, fb.cap, fb.interval = 1, 5, 600
    else
        local n = math.max((GetNumGroupMembers and GetNumGroupMembers()) or 1, 1)
        fb.charges, fb.cap, fb.interval = 1, math.huge, 5400 / n
    end
    fb.nextAt = GetTime() + fb.interval
end

local ticker
local runningMode

local function SetDisplay(c, remaining, approx)
    local f = EnsureTracker()
    f.charges:SetText(approx and ("~" .. c) or tostring(c))
    if remaining and remaining > 0 then
        f.timer:SetFormattedText("%d:%02d", math.floor(remaining / 60), math.floor(remaining % 60))
    else
        f.timer:SetText("0:00")
    end
end

local function OnTick()

    if C_Spell and C_Spell.GetSpellCharges then
        local ok, info = pcall(C_Spell.GetSpellCharges, REBIRTH)
        if ok then
            if info == nil then

                SetDisplay(0, 0)
                return
            end
            if type(info) == "table" and not IsSecret(info) then
                local c, st, dur = info.currentCharges, info.cooldownStartTime, info.cooldownDuration
                if type(c) == "number" and type(st) == "number" and type(dur) == "number"
                    and not (IsSecret(c) or IsSecret(st) or IsSecret(dur)) then
                    fb.on = false
                    local remaining = dur - (GetTime() - st)
                    SetDisplay(c, math.max(remaining, 0))
                    return
                end
            end
        end
    end

    if fb.on then
        local now = GetTime()
        while now >= fb.nextAt and fb.charges < fb.cap do
            fb.charges = fb.charges + 1
            fb.nextAt = fb.nextAt + fb.interval
        end
        SetDisplay(fb.charges, fb.charges < fb.cap and (fb.nextAt - now) or 0, true)
    else
        SetDisplay(0, 0)
    end
end

local function StartUpdater(mode)
    runningMode = mode
    ArmFallback(mode)
    EnsureTracker():Show()
    if not ticker then ticker = C_Timer.NewTicker(1, OnTick) end
    OnTick()
end

local function StopUpdater()
    runningMode = nil
    if ticker then ticker:Cancel(); ticker = nil end
    fb.on = false
    if trackerFrame then SetDisplay(0, 0) end
end

local function UpdateUnlockState()
    local d = DB()
    local f = EnsureTracker()
    local unlocked = d.enabled and d.unlock and not (InCombatLockdown and InCombatLockdown())
    f:EnableMouse(unlocked)
    if f.unlockBG then f.unlockBG:SetShown(unlocked and true or false) end
    if unlocked and not f:IsShown() then

        f.charges:SetText("2")
        f.timer:SetText("4:30")
        f:Show()
    elseif not unlocked and not ticker and f:IsShown() then

        local _, _, diffID = GetInstanceInfo()
        if not (diffID and RAID_DIFFS[diffID]) then f:Hide() end
    end
end

local reportedDead = {}
local function OnUnitHealth(unit)
    local d = DB()
    if not d.enabled or not d.deathWarn then return end
    if not unit then return end
    if not (UnitIsUnit(unit, "player") or (UnitInParty and UnitInParty(unit)) or (UnitInRaid and UnitInRaid(unit))) then
        return
    end
    local guid = UnitGUID and UnitGUID(unit)
    if guid == nil or IsSecret(guid) then return end
    local dead = UnitIsDeadOrGhost(unit) and not (UnitIsFeignDeath and UnitIsFeignDeath(unit))
    if dead then
        if not reportedDead[guid] then
            reportedDead[guid] = true
            local name = UnitName(unit)
            if name == nil or IsSecret(name) then name = unit end
            ShowDeathWarning(name)
        end
    else
        reportedDead[guid] = nil
    end
end

local ev = CreateFrame("Frame")

local function SetTrackingEvents(on)
    if on then
        ev:RegisterEvent("ENCOUNTER_START")
        ev:RegisterEvent("ENCOUNTER_END")
    else
        ev:UnregisterEvent("ENCOUNTER_START")
        ev:UnregisterEvent("ENCOUNTER_END")
    end
end

local function ApplyZone(zoneChanged)
    local d = DB()
    if zoneChanged then
        wipe(reportedDead)
        if deathFrame then deathFrame:Hide() end
    end

    SetTrackingEvents(false)
    ev:UnregisterEvent("CHALLENGE_MODE_START")
    ev:UnregisterEvent("CHALLENGE_MODE_COMPLETED")
    ev:UnregisterEvent("UNIT_HEALTH")
    ev:UnregisterEvent("PLAYER_REGEN_DISABLED")
    ev:UnregisterEvent("PLAYER_REGEN_ENABLED")

    if not d.enabled then
        StopUpdater()
        if trackerFrame then trackerFrame:Hide() end
        if deathFrame then deathFrame:Hide() end
        return
    end

    local _, _, diffID = GetInstanceInfo()
    local wantMode, showIdle = nil, false
    if diffID and RAID_DIFFS[diffID] then
        SetTrackingEvents(true)
        showIdle = true
        if IsEncounterInProgress and IsEncounterInProgress() then wantMode = "raid" end
        if d.deathWarn then ev:RegisterEvent("UNIT_HEALTH") end
    elseif diffID == DIFF_MYTHIC_DUNGEON then
        ev:RegisterEvent("CHALLENGE_MODE_START")
        if d.deathWarn then ev:RegisterEvent("UNIT_HEALTH") end
    elseif diffID == DIFF_KEYSTONE_ACTIVE then
        wantMode = "mplus"
        ev:RegisterEvent("CHALLENGE_MODE_COMPLETED")
        if d.deathWarn then ev:RegisterEvent("UNIT_HEALTH") end
    end
    ev:RegisterEvent("PLAYER_REGEN_DISABLED")
    ev:RegisterEvent("PLAYER_REGEN_ENABLED")

    if wantMode then
        if runningMode ~= wantMode then StartUpdater(wantMode) end
    else
        StopUpdater()
        if showIdle then
            EnsureTracker():Show()
            SetDisplay(0, 0)
        elseif trackerFrame then
            trackerFrame:Hide()
        end
    end
    UpdateUnlockState()
end

ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_ENTERING_WORLD" then

        C_Timer.After(0, function() ApplyZone(true) end)
    elseif event == "ENCOUNTER_START" then
        StartUpdater("raid")
    elseif event == "ENCOUNTER_END" then
        StopUpdater()
    elseif event == "CHALLENGE_MODE_COMPLETED" then
        StopUpdater()

        C_Timer.After(5, function()
            if not ticker and trackerFrame and not DB().unlock then
                trackerFrame:Hide()
            end
        end)
    elseif event == "CHALLENGE_MODE_START" then
        ev:RegisterEvent("CHALLENGE_MODE_COMPLETED")
        StartUpdater("mplus")
    elseif event == "UNIT_HEALTH" then
        pcall(OnUnitHealth, arg1)
    elseif event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
        UpdateUnlockState()
    end
end)

function _G.AkcQOL_ApplyCombatRez()
    ApplyZone()
end

function _G.AkcQOL_ResetCombatRezPosition()
    DB().pos = nil
    if trackerFrame then
        trackerFrame:ClearAllPoints()
        trackerFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 260)
    end
end

function _G.AkcQOL_TestCombatRezDeathWarning()
    local name = UnitName and UnitName("player") or L["Player"]
    if IsSecret(name) then name = L["Player"] end
    ShowDeathWarning(name)
end
