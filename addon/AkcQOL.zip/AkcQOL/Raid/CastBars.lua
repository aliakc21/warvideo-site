-- CastBars: the game's own cast bar look for enemy casts aimed at you.
--
-- Under 12.x restrictions an addon may not READ whether a cast is aimed at the
-- player, how long it runs, or whether it can be interrupted -- but it may
-- hand those hidden values straight to a widget and let the engine draw them.
-- Every secret here goes into a setter and is never compared:
--
--   visibility  <- PlayerIsSpellTarget(unit)   -> Frame:SetAlphaFromBoolean
--   fill        <- secret start/end times      -> StatusBar:SetMinMaxValues
--                                                 + SetValue(GetTime()*1000)
--   art         <- secret notInterruptible     -> SetAlphaFromBoolean on two
--                                                 fills (Blizzard's kickable and
--                                                 uninterruptible art) + shield
--   name/icon   <- secret displayName/texture  -> SetText / SetTexture
--
-- Bar i follows nameplate i and never moves: which bars are visible is secret,
-- so a layout that closed the gaps would leak the answer. Every nameplate slot
-- is watched; "Maximum Bars" only sets how many rows they share, bar i sitting
-- on row (i - 1) % rows. Capping by slot index instead meant a mob on
-- nameplate 6 or higher never got a bar, even with none showing.

local L = AkcQOL_L
local Theme = _G.AkcQOL_Theme

local MAX_BARS = 8          -- rows; the "Maximum Bars" option stops here
local NAMEPLATE_SLOTS = 40  -- nameplate1 .. nameplate40
local BAR_W, BAR_H, BAR_GAP, ICON = 260, 20, 4, 20
-- Blizzard's own cast bar art (Blizzard_UIPanels_Game, SmallCastingBarFrameTemplate
-- and CastingBarFrame.lua), so these read exactly like the game's bars: gold
-- while it can be kicked, grey with a shield when it cannot, green for a channel.
local ATLAS_CAST    = "ui-castingbar-filling-standard"
local ATLAS_CHANNEL = "ui-castingbar-filling-channel"
local ATLAS_LOCKED  = "ui-castingbar-uninterruptable"
local ATLAS_BG      = "ui-castingbar-background"
local ATLAS_BORDER  = "ui-castingbar-frame"
local ATLAS_SPARK   = "ui-castingbar-pip"
local ATLAS_SHIELD  = "ui-castingbar-shield"

local bars = {}
local root
local ticking = {}
local tickCount = 0
local tickFrame
local moving = false     -- placement mode: sample bars shown, live casts paused

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.castAlert) ~= "table" then g.castAlert = {} end
    local d = g.castAlert
    if d.bars == nil then d.bars = true end
    if d.onlyInstances == nil then d.onlyInstances = true end
    if d.barsOnlyInterruptible == nil then d.barsOnlyInterruptible = true end
    if d.skipBosses == nil then d.skipBosses = true end
    if type(d.barCount) ~= "number" then d.barCount = 5 end
    if type(d.barScale) ~= "number" then d.barScale = 1 end
    return d
end

-- A value may be secret, and testing a secret raises an error -- so ask the
-- game whether it is one before comparing anything.
local function Present(v)
    if issecretvalue then
        local ok, secret = pcall(issecretvalue, v)
        if ok and secret then return true end
    end
    return v ~= nil
end

local function PlainValue(v)
    if issecretvalue then
        local ok, secret = pcall(issecretvalue, v)
        if ok and secret then return nil end
    end
    return v
end

-- ── frames ──────────────────────────────────────────────────────────────────
local function EnsureRoot()
    if root then return root end
    root = CreateFrame("Frame", "AkcQOLCastBarsFrame", UIParent)
    root:SetSize(BAR_W, MAX_BARS * (BAR_H + BAR_GAP))
    local pos = DB().pos
    if pos and pos.p then
        root:SetPoint(pos.p, UIParent, pos.rp or pos.p, pos.x or 0, pos.y or 0)
    else
        root:SetPoint("CENTER", UIParent, "CENTER", 0, 140)
    end
    root:SetFrameStrata("HIGH")
    root:SetMovable(true)
    root:SetClampedToScreen(true)
    root:EnableMouse(false)
    root:RegisterForDrag("LeftButton")
    root:SetScript("OnDragStart", function(self) self:StartMoving() end)
    root:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        DB().pos = { p = p, rp = rp, x = x, y = y }
    end)

    -- No click handler here, and no mouse-propagation calls either: those
    -- are protected functions (IsProtectedFunction = true), and an addon
    -- calling them is what put "Interface actions failed because of this
    -- AddOn" on the addon list. They were never needed: outside placement
    -- mode the mouse is off, so the frame sees no click to swallow, and
    -- placement mode locks itself after 30 seconds and on entering combat.

    local hint = root:CreateTexture(nil, "BACKGROUND", nil, -8)
    hint:SetPoint("TOPLEFT", -4, 4)
    hint:SetPoint("BOTTOMRIGHT", 4, -4)
    hint:SetColorTexture(0.55, 0.36, 1, 0.18)
    hint:Hide()
    root.hint = hint

    local label = root:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("TOP", root, "BOTTOM", 0, -2)
    label:SetText((L and L["Drag to place. Locks itself in combat."]) or "Drag to place. Locks itself in combat.")
    -- The game font has no Turkish s-cedilla or g-breve; drawn with it, this
    -- line came out with empty boxes in the middle of words.
    if Theme and Theme.SetFont then pcall(Theme.SetFont, label, 12, "OUTLINE") end
    label:Hide()
    root.moveLabel = label
    return root
end

local function RowCount()
    local rows = math.floor(tonumber(DB().barCount) or 5)
    if rows < 1 then rows = 1 elseif rows > MAX_BARS then rows = MAX_BARS end
    return rows
end

-- Fixed by slot number and row count only, never by what is showing.
local function PlaceBar(bar, rows)
    bar:ClearAllPoints()
    bar:SetPoint("TOPLEFT", EnsureRoot(), "TOPLEFT", 0, -((bar.index - 1) % rows) * (BAR_H + BAR_GAP))
end

local function CreateBar(index)
    local parent = EnsureRoot()
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(BAR_W, BAR_H)
    f.unit = "nameplate" .. index
    f.index = index
    PlaceBar(f, RowCount())
    f:SetAlpha(0)
    f:Hide()

    -- Second gate, holding every visual. Rendered alpha multiplies down the
    -- parent chain, so an outer alpha of "is it aimed at me" times an inner
    -- alpha of "can I interrupt it" is a logical AND that the engine computes
    -- and the addon never sees.
    local gate = CreateFrame("Frame", nil, f)
    gate:SetAllPoints(f)
    f.gate = gate

    local bg = gate:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(gate)
    bg:SetAtlas(ATLAS_BG)

    -- The fill grows from the left as the cast elapses, like the game's bar.
    -- Two fills share one range and one clock -- one in Blizzard's kickable
    -- art, one in its uninterruptible art -- and the secret "cannot be
    -- interrupted" flag decides which of the two is visible.
    local function NewFill(atlas)
        local fill = CreateFrame("StatusBar", nil, gate)
        fill:SetAllPoints(gate)
        fill:SetStatusBarTexture(atlas)
        fill:SetMinMaxValues(0, 1)
        fill:SetValue(0)
        fill:SetFrameLevel(gate:GetFrameLevel() + 1)
        return fill
    end
    f.kick = NewFill(ATLAS_CAST)
    f.lock = NewFill(ATLAS_LOCKED)
    f.lock:SetAlpha(0)

    -- A channel empties towards the left, as in the game. Its time left is
    -- secret, so the fill stays full and a background-coloured cover grows in
    -- from the right; the engine sizes the cover, the addon never sees a time.
    local cover = CreateFrame("StatusBar", nil, gate)
    cover:SetAllPoints(gate)
    cover:SetStatusBarTexture(ATLAS_BG)
    cover:SetReverseFill(true)
    cover:SetMinMaxValues(0, 1)
    cover:SetValue(0)
    cover:SetFrameLevel(gate:GetFrameLevel() + 2)
    -- The background art may be partly see-through; an opaque layer that
    -- follows the cover's own fill keeps the emptied part empty. The engine
    -- sizes it with the bar, so no secret is read.
    local solid = cover:CreateTexture(nil, "BACKGROUND")
    solid:SetAllPoints(cover:GetStatusBarTexture())
    solid:SetColorTexture(0.05, 0.05, 0.07, 1)
    f.cover = cover

    -- Border, spark and text sit above every fill.
    local overlay = CreateFrame("Frame", nil, gate)
    overlay:SetAllPoints(gate)
    overlay:SetFrameLevel(gate:GetFrameLevel() + 3)

    local border = overlay:CreateTexture(nil, "OVERLAY")
    border:SetPoint("TOPLEFT", -1, 2)
    border:SetPoint("BOTTOMRIGHT", 1, -2)
    border:SetAtlas(ATLAS_BORDER)

    -- The spark rides the edge of the fill. It is anchored to the fill texture
    -- itself, so the engine moves it and no secret time is ever read.
    local spark = overlay:CreateTexture(nil, "OVERLAY", nil, 1)
    spark:SetAtlas(ATLAS_SPARK)
    spark:SetSize(6, BAR_H - 4)
    f.spark = spark

    local icon = gate:CreateTexture(nil, "OVERLAY")
    icon:SetSize(ICON, ICON)
    icon:SetPoint("RIGHT", f, "LEFT", -4, 0)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    f.icon = icon

    -- Blizzard's shield around the icon on casts that cannot be interrupted;
    -- behind the icon, as in the game.
    local shield = gate:CreateTexture(nil, "BACKGROUND", nil, 1)
    shield:SetAtlas(ATLAS_SHIELD)
    shield:SetSize(29, 33)
    shield:SetPoint("CENTER", icon, "CENTER", 0, -6)
    shield:SetAlpha(0)
    f.shield = shield

    local label = overlay:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("LEFT", f, "LEFT", 6, 0)
    label:SetPoint("RIGHT", f, "RIGHT", -6, 0)
    label:SetJustifyH("LEFT")
    -- Theme.SetFont registers the string so it follows the addon-wide Text
    -- Scale setting; it returns false rather than raising on a bad path.
    local styled = false
    if Theme and Theme.SetFont then
        local ok, applied = pcall(Theme.SetFont, label, 12, "OUTLINE")
        styled = ok and applied ~= false
    end
    if not styled then
        label:SetFontObject("GameFontHighlightSmall")
    end
    f.label = label

    return f
end

-- ── fill ────────────────────────────────────────────────────────────────────
local ClearBar  -- defined below; the ticker needs it to drop a stuck bar

local function StopTicking(bar)
    if ticking[bar] then
        ticking[bar] = nil
        tickCount = tickCount - 1
        if tickCount <= 0 then
            tickCount = 0
            if tickFrame then tickFrame:SetScript("OnUpdate", nil) end
        end
    end
end

local function Tick()
    local now = GetTime()
    local nowMs = now * 1000
    for bar in pairs(ticking) do
        -- A bar that refuses its value, or one whose stop event never arrived,
        -- is dropped instead of erroring every frame until reload.
        if bar.tickStart and (now - bar.tickStart) > 60 then
            ClearBar(bar)
        elseif bar.channel then
            if not pcall(bar.cover.SetValue, bar.cover, nowMs) then ClearBar(bar) end
        elseif not (pcall(bar.kick.SetValue, bar.kick, nowMs) and pcall(bar.lock.SetValue, bar.lock, nowMs)) then
            -- Dropping only the tick would leave the previous cast's icon and
            -- name sitting on screen with a frozen bar.
            ClearBar(bar)
        end
    end
end

-- Cast or channel is a plain fact (which API answered), so it may steer the
-- art and which edge the spark follows.
local function SetMode(bar, channel)
    bar.channel = channel and true or false
    bar.kick:SetStatusBarTexture(channel and ATLAS_CHANNEL or ATLAS_CAST)
    bar.spark:ClearAllPoints()
    if channel then
        bar.spark:SetPoint("CENTER", bar.cover:GetStatusBarTexture(), "LEFT", 0, 0)
    else
        bar.spark:SetPoint("CENTER", bar.kick:GetStatusBarTexture(), "RIGHT", 0, 0)
    end
end

-- The secret start/end go in as the RANGE and a plain clock goes in as the
-- VALUE, so the engine does the division and no secret is ever inspected.
-- Both setters are allowed for tainted callers. A cast fills both fills; a
-- channel keeps them full and lets the cover eat them from the right.
local function ApplyFill(bar, startTimeMs, endTimeMs)
    local nowMs = GetTime() * 1000
    if bar.channel then
        bar.kick:SetMinMaxValues(0, 1)
        bar.kick:SetValue(1)
        bar.lock:SetMinMaxValues(0, 1)
        bar.lock:SetValue(1)
        bar.cover:SetMinMaxValues(startTimeMs, endTimeMs)
        bar.cover:SetValue(nowMs)
    else
        bar.cover:SetMinMaxValues(0, 1)
        bar.cover:SetValue(0)
        bar.kick:SetMinMaxValues(startTimeMs, endTimeMs)
        bar.kick:SetValue(nowMs)
        bar.lock:SetMinMaxValues(startTimeMs, endTimeMs)
        bar.lock:SetValue(nowMs)
    end

    if not ticking[bar] then
        ticking[bar] = true
        bar.tickStart = GetTime()
        tickCount = tickCount + 1
        if not tickFrame then tickFrame = CreateFrame("Frame") end
        tickFrame:SetScript("OnUpdate", Tick)
    end
end

function ClearBar(bar)
    StopTicking(bar)
    bar.gate:SetAlpha(1)
    bar.kick:SetMinMaxValues(0, 1)
    bar.kick:SetValue(0)
    bar.lock:SetMinMaxValues(0, 1)
    bar.lock:SetValue(0)
    bar.cover:SetMinMaxValues(0, 1)
    bar.cover:SetValue(0)
    bar.label:SetText("")
    bar.icon:SetTexture(nil)
    bar:SetAlpha(0)
    bar:Hide()
end

-- ── cast state ──────────────────────────────────────────────────────────────
-- Only the returned `present` flag -- built here -- is safe to branch on.
-- Everything after it may be secret and is only ever passed to a setter.
local function FetchCast(unit)
    -- name, displayName, texture, startMs, endMs, isTradeskill, castID,
    -- notInterruptible, spellID, ...
    local _, displayName, textureID, startTimeMs, endTimeMs, isTradeskill, _2, notInterruptible =
        UnitCastingInfo(unit)
    if Present(isTradeskill) then
        return true, displayName, textureID, startTimeMs, endTimeMs, notInterruptible, false
    end

    -- name, displayName, texture, startMs, endMs, isTradeskill,
    -- notInterruptible, spellID, ...
    local _3, cDisplay, cTexture, cStart, cEnd, cTrade, cNotInt = UnitChannelInfo(unit)
    if Present(cTrade) then
        return true, cDisplay, cTexture, cStart, cEnd, cNotInt, true
    end

    return false
end

local function StartCast(bar)
    if moving then return end
    local d = DB()
    if d.enabled == false or d.bars == false then ClearBar(bar) return end
    if d.onlyInstances and not IsInInstance() then ClearBar(bar) return end

    local unit = bar.unit
    if not UnitExists(unit) then ClearBar(bar) return end

    -- Hostility can itself come back secret in restricted content; when it
    -- does, let the cast through and leave the targeting check to do the work.
    local okAttack, canAttack = pcall(UnitCanAttack, "player", unit)
    if okAttack and PlainValue(canAttack) == false then ClearBar(bar) return end

    if d.skipBosses ~= false and _G.AkcQOL_IsBossNameplate
        and _G.AkcQOL_IsBossNameplate(unit) then
        ClearBar(bar)
        return
    end

    local present, displayName, textureID, startTimeMs, endTimeMs, notInterruptible, isChannel = FetchCast(unit)
    if not present then ClearBar(bar) return end

    -- An empowered spell answers through UnitChannelInfo, but the game's bar
    -- fills it like a cast. Which event started it is plain information.
    SetMode(bar, isChannel and not bar.empower)

    -- Gold (green for a channel) when it can be kicked, grey with a shield
    -- when it cannot -- picked by the engine from a value this addon is not
    -- allowed to look at.
    local picked = pcall(bar.lock.SetAlphaFromBoolean, bar.lock, notInterruptible, 1, 0)
        and pcall(bar.kick.SetAlphaFromBoolean, bar.kick, notInterruptible, 0, 1)
        and pcall(bar.shield.SetAlphaFromBoolean, bar.shield, notInterruptible, 1, 0)
    if not picked then
        -- Unrestricted content hands back a plain value; nil means the game
        -- did not say, and a cast we cannot judge is shown as kickable.
        local locked = PlainValue(notInterruptible) == true
        bar.lock:SetAlpha(locked and 1 or 0)
        bar.kick:SetAlpha(locked and 0 or 1)
        bar.shield:SetAlpha(locked and 1 or 0)
    end

    -- Interruptible-only filter. The same secret flag that picked the colour
    -- now drives the inner alpha, so uninterruptible casts fade out without
    -- the addon ever branching on them.
    if d.barsOnlyInterruptible ~= false then
        local gated = pcall(bar.gate.SetAlphaFromBoolean, bar.gate, notInterruptible, 0, 1)
        if not gated then
            -- Unrestricted content hands back a plain value; nil means the
            -- game did not say, and a cast we cannot judge is worth showing.
            bar.gate:SetAlpha(PlainValue(notInterruptible) == true and 0 or 1)
        end
    else
        bar.gate:SetAlpha(1)
    end

    -- Cleared first, so a refused setter leaves an empty widget rather than
    -- the previous mob's spell on a recycled nameplate slot.
    bar.icon:SetTexture(nil)
    bar.label:SetText("")
    pcall(bar.icon.SetTexture, bar.icon, textureID)
    pcall(bar.label.SetText, bar.label, displayName)

    StopTicking(bar)
    if not pcall(ApplyFill, bar, startTimeMs, endTimeMs) then ClearBar(bar) return end

    -- Whether this cast is aimed at the player is secret; handing it to the
    -- alpha makes the bar appear only when the answer is yes, and the addon
    -- never learns which it was.
    -- Blank first: if anything below fails, the bar must not inherit the
    -- previous cast's visibility and show a spell that is not aimed at us.
    bar:SetAlpha(0)
    bar:Show()
    local shown = false
    if _G.PlayerIsSpellTarget and bar.SetAlphaFromBoolean then
        -- The call itself is protected too; as a pcall ARGUMENT it would run
        -- unguarded and its error would escape.
        local okTarget, isTarget = pcall(_G.PlayerIsSpellTarget, unit)
        if okTarget then
            shown = pcall(bar.SetAlphaFromBoolean, bar, isTarget, 1, 0)
        end
    end
    if not shown then
        -- Still strictly "aimed at me", just read the plain way: on a client
        -- without PlayerIsSpellTarget the caster's own target is readable, and
        -- that is the same question. Without this the whole feature would be
        -- silently dead rather than merely less precise.
        local okUnit, isMine = pcall(UnitIsUnit, unit .. "target", "player")
        if okUnit and PlainValue(isMine) == true then
            bar:SetAlpha(1)
        else
            ClearBar(bar)
        end
    end
end

-- ── events ──────────────────────────────────────────────────────────────────
-- Payload arguments are deliberately ignored: unitTarget, castGUID and spellID
-- are secret on these events. RegisterUnitEvent lets the engine route per unit,
-- so slot i always follows whoever occupies nameplate i.
local CAST_EVENTS = {
    UNIT_SPELLCAST_START             = "start",
    UNIT_SPELLCAST_DELAYED           = "start",
    UNIT_SPELLCAST_INTERRUPTIBLE     = "start",
    UNIT_SPELLCAST_NOT_INTERRUPTIBLE = "start",
    UNIT_SPELLCAST_CHANNEL_START     = "start",
    UNIT_SPELLCAST_CHANNEL_UPDATE    = "start",
    UNIT_SPELLCAST_EMPOWER_START     = "start",
    UNIT_SPELLCAST_EMPOWER_UPDATE    = "start",
    UNIT_SPELLCAST_STOP              = "stop",
    UNIT_SPELLCAST_CHANNEL_STOP      = "stop",
    UNIT_SPELLCAST_EMPOWER_STOP      = "stop",
    UNIT_SPELLCAST_INTERRUPTED       = "stop",
    UNIT_SPELLCAST_FAILED            = "stop",
}

-- Every event re-reads the unit instead of trusting what the event means.
-- UNIT_SPELLCAST_FAILED can arrive for a cast the mob just abandoned while a
-- channel is still running on the same unit, and its payload may not be read,
-- so clearing on "stop" would blank a live channel. StartCast already clears
-- when the unit turns out not to be casting.
local function OnCastEvent(self, event)
    if moving then return end
    if event == "UNIT_SPELLCAST_EMPOWER_START" or event == "UNIT_SPELLCAST_EMPOWER_UPDATE" then
        self.empower = true
    elseif event == "UNIT_SPELLCAST_EMPOWER_STOP" or event == "UNIT_SPELLCAST_START"
        or event == "UNIT_SPELLCAST_CHANNEL_START" then
        self.empower = false
    end
    pcall(StartCast, self)
end

local function EnsureBars()
    if bars[1] then return end
    for i = 1, NAMEPLATE_SLOTS do
        local bar = CreateBar(i)
        for event in pairs(CAST_EVENTS) do
            pcall(bar.RegisterUnitEvent, bar, event, bar.unit)
        end
        bar:SetScript("OnEvent", OnCastEvent)
        bars[i] = bar
    end
end

local function ClearAll()
    for _, bar in ipairs(bars) do ClearBar(bar) end
end

-- ── public ──────────────────────────────────────────────────────────────────
local moverTimeout = 0

function _G.AkcQOL_ToggleCastBarsMover()
    EnsureBars()
    local frame = EnsureRoot()
    moving = not moving
    frame:EnableMouse(moving)

    -- Placement mode closes itself: nothing of ours should stay mouse-enabled
    -- because a settings button was left unpressed.
    moverTimeout = moverTimeout + 1
    if moving and C_Timer and C_Timer.After then
        local token = moverTimeout
        C_Timer.After(30, function()
            if moving and token == moverTimeout then _G.AkcQOL_ToggleCastBarsMover() end
        end)
    end
    frame.hint:SetShown(moving)
    if frame.moveLabel then frame.moveLabel:SetShown(moving) end
    frame:SetScale(DB().barScale or 1)

    local count = RowCount()
    for i, bar in ipairs(bars) do
        if moving and i <= count then
            StopTicking(bar)
            SetMode(bar, false)
            local onlyKickable = DB().barsOnlyInterruptible ~= false
            local locked = not onlyKickable and i % 2 == 0
            for _, fill in ipairs({ bar.kick, bar.lock }) do
                fill:SetMinMaxValues(0, 1)
                fill:SetValue(i / (count + 1))
            end
            bar.cover:SetMinMaxValues(0, 1)
            bar.cover:SetValue(0)
            bar.kick:SetAlpha(locked and 0 or 1)
            bar.lock:SetAlpha(locked and 1 or 0)
            bar.shield:SetAlpha(locked and 1 or 0)
            bar.gate:SetAlpha(1)
            bar.icon:SetTexture(136230)
            bar.label:SetText((L and L["Cast Bars"]) or "Cast Bars")
            bar:SetAlpha(1)
            bar:Show()
        else
            ClearBar(bar)
        end
    end
end

function _G.AkcQOL_ResetCastBarsPosition()
    DB().pos = nil
    if root then
        root:ClearAllPoints()
        root:SetPoint("CENTER", UIParent, "CENTER", 0, 140)
    end
end

function _G.AkcQOL_ApplyCastBars()
    if moving then _G.AkcQOL_ToggleCastBarsMover() end

    -- Built regardless of the toggles: StartCast re-checks them on every event
    -- and clears, so registering costs nothing while disabled. Gating this on
    -- `enabled` meant a fresh profile -- where the shared cast-alert toggle
    -- starts off -- never created a single bar or event registration, and no
    -- bar appeared until the next reload.
    EnsureBars()

    -- The row count may have changed ("Maximum Bars").
    local rows = RowCount()
    for _, bar in ipairs(bars) do PlaceBar(bar, rows) end

    local d = DB()
    if d.enabled == false or d.bars == false then
        ClearAll()
        return
    end
    EnsureRoot():SetScale(d.barScale or 1)
    ClearAll()
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
-- Placement mode must not survive into a pull: a mouse-enabled slab across the
-- middle of the screen kills right-click camera turning exactly when it matters.
boot:RegisterEvent("PLAYER_REGEN_DISABLED")
boot:RegisterEvent("NAME_PLATE_UNIT_ADDED")
boot:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
boot:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        _G.AkcQOL_ApplyCastBars()
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        if moving then _G.AkcQOL_ToggleCastBarsMover() end
        return
    end
    if moving then return end
    -- Nameplate slots get recycled; drop any bar whose unit is gone. Bars that
    -- are hidden and idle are already clear: with a bar for every slot, most
    -- are, and these events come in bursts.
    for _, bar in ipairs(bars) do
        if (bar:IsShown() or ticking[bar]) and not UnitExists(bar.unit) then ClearBar(bar) end
    end
end)
