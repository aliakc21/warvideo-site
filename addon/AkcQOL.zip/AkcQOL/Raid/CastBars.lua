-- CastBars: draining bars for enemy casts aimed at you.
--
-- Under 12.x restrictions an addon may not READ whether a cast is aimed at the
-- player, how long it runs, or whether it can be interrupted -- but it may
-- hand those hidden values straight to a widget and let the engine draw them.
-- Every secret here goes into a setter and is never compared:
--
--   visibility  <- PlayerIsSpellTarget(unit)   -> Frame:SetAlphaFromBoolean
--   fill        <- secret start/end times      -> StatusBar:SetMinMaxValues
--                                                 + SetValue(GetTime()*1000)
--   colour      <- secret notInterruptible     -> SetVertexColorFromBoolean
--   name/icon   <- secret displayName/texture  -> SetText / SetTexture
--
-- Bar i follows nameplate i and never moves: which bars are visible is secret,
-- so a layout that closed the gaps would leak the answer.

local L = AkcQOL_L
local Theme = _G.AkcQOL_Theme

local MAX_BARS = 8
local BAR_W, BAR_H, BAR_GAP, ICON = 260, 20, 4, 20
-- SetVertexColorFromBoolean wants ColorMixin objects, not plain {r,g,b,a}
-- tables; a plain table makes the call fail and every bar stays green.
local COLOR_KICKABLE = CreateColor(0.35, 0.85, 0.44, 1)   -- interruptible
local COLOR_LOCKED   = CreateColor(0.85, 0.25, 0.25, 1)   -- not interruptible

local bars = {}
local root
local ticking = {}
local tickCount = 0
local tickFrame
local moving = false     -- placement mode: sample bars shown, live casts paused

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.castAlert) ~= "table" then g.castAlert = {} end
    local d = g.castAlert
    if d.bars == nil then d.bars = true end
    if d.onlyInstances == nil then d.onlyInstances = true end
    if d.barsOnlyInterruptible == nil then d.barsOnlyInterruptible = true end
    if d.skipBosses == nil then d.skipBosses = true end
    if type(d.barCount) ~= "number" then d.barCount = 5 end
    if type(d.barScale) ~= "number" then d.barScale = 1 end
    return d
end

-- A value may be secret, and testing a secret raises an error -- so ask the
-- game whether it is one before comparing anything.
local function Present(v)
    if issecretvalue then
        local ok, secret = pcall(issecretvalue, v)
        if ok and secret then return true end
    end
    return v ~= nil
end

local function PlainValue(v)
    if issecretvalue then
        local ok, secret = pcall(issecretvalue, v)
        if ok and secret then return nil end
    end
    return v
end

-- ── frames ──────────────────────────────────────────────────────────────────
local function EnsureRoot()
    if root then return root end
    root = CreateFrame("Frame", "AkcQOLCastBarsFrame", UIParent)
    root:SetSize(BAR_W, MAX_BARS * (BAR_H + BAR_GAP))
    local pos = DB().pos
    if pos and pos.p then
        root:SetPoint(pos.p, UIParent, pos.rp or pos.p, pos.x or 0, pos.y or 0)
    else
        root:SetPoint("CENTER", UIParent, "CENTER", 0, 140)
    end
    root:SetFrameStrata("HIGH")
    root:SetMovable(true)
    root:SetClampedToScreen(true)
    root:EnableMouse(false)
    root:RegisterForDrag("LeftButton")
    root:SetScript("OnDragStart", function(self) self:StartMoving() end)
    root:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        DB().pos = { p = p, rp = rp, x = x, y = y }
    end)

    -- Clicks are passed straight through to whatever is under the bars. The
    -- bars must never answer a click -- right-click is how the camera turns,
    -- and swallowing it even for a moment is unacceptable. Dragging still
    -- works because that runs off RegisterForDrag, not off a click handler.
    if root.SetPropagateMouseClicks then root:SetPropagateMouseClicks(true) end
    if root.SetPropagateMouseMotion then root:SetPropagateMouseMotion(true) end

    local hint = root:CreateTexture(nil, "BACKGROUND", nil, -8)
    hint:SetPoint("TOPLEFT", -4, 4)
    hint:SetPoint("BOTTOMRIGHT", 4, -4)
    hint:SetColorTexture(0.55, 0.36, 1, 0.18)
    hint:Hide()
    root.hint = hint

    local label = root:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("TOP", root, "BOTTOM", 0, -2)
    label:SetText((L and L["Drag to place. Locks itself in combat."]) or "Drag to place. Locks itself in combat.")
    -- The game font has no Turkish s-cedilla or g-breve; drawn with it, this
    -- line came out with empty boxes in the middle of words.
    if Theme and Theme.SetFont then pcall(Theme.SetFont, label, 12, "OUTLINE") end
    label:Hide()
    root.moveLabel = label
    return root
end

local function CreateBar(index)
    local parent = EnsureRoot()
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(BAR_W, BAR_H)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -(index - 1) * (BAR_H + BAR_GAP))
    f.unit = "nameplate" .. index
    f.index = index
    f:SetAlpha(0)
    f:Hide()

    -- Second gate, holding every visual. Rendered alpha multiplies down the
    -- parent chain, so an outer alpha of "is it aimed at me" times an inner
    -- alpha of "can I interrupt it" is a logical AND that the engine computes
    -- and the addon never sees.
    local gate = CreateFrame("Frame", nil, f)
    gate:SetAllPoints(f)
    f.gate = gate

    local bg = gate:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(gate)
    bg:SetColorTexture(0, 0, 0, 0.6)

    -- The time-left layer. Its colour comes from the secret "cannot be
    -- interrupted" flag: green = kick it, red = don't bother.
    local remaining = gate:CreateTexture(nil, "ARTWORK")
    remaining:SetPoint("TOPLEFT", 1, -1)
    remaining:SetPoint("BOTTOMRIGHT", -1, 1)
    remaining:SetColorTexture(1, 1, 1, 1)
    remaining:SetVertexColor(COLOR_KICKABLE:GetRGBA())
    f.remaining = remaining

    -- An opaque bar that grows over it as the cast elapses, eating in from the
    -- right, so what is left drains away like a normal cast bar.
    local cover = CreateFrame("StatusBar", nil, gate)
    cover:SetPoint("TOPLEFT", 1, -1)
    cover:SetPoint("BOTTOMRIGHT", -1, 1)
    cover:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
    cover:SetStatusBarColor(0.04, 0.04, 0.06, 0.93)
    cover:SetReverseFill(true)
    cover:SetMinMaxValues(0, 1)
    cover:SetValue(0)
    cover:SetFrameLevel(gate:GetFrameLevel() + 1)
    f.cover = cover

    local icon = gate:CreateTexture(nil, "OVERLAY")
    icon:SetSize(ICON, ICON)
    icon:SetPoint("RIGHT", f, "LEFT", -4, 0)
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    f.icon = icon

    local label = cover:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("LEFT", f, "LEFT", 6, 0)
    label:SetPoint("RIGHT", f, "RIGHT", -6, 0)
    label:SetJustifyH("LEFT")
    -- Theme.SetFont registers the string so it follows the addon-wide Text
    -- Scale setting; it returns false rather than raising on a bad path.
    local styled = false
    if Theme and Theme.SetFont then
        local ok, applied = pcall(Theme.SetFont, label, 12, "OUTLINE")
        styled = ok and applied ~= false
    end
    if not styled then
        label:SetFontObject("GameFontHighlightSmall")
    end
    f.label = label

    return f
end

-- ── fill ────────────────────────────────────────────────────────────────────
local ClearBar  -- defined below; the ticker needs it to drop a stuck bar

local function StopTicking(bar)
    if ticking[bar] then
        ticking[bar] = nil
        tickCount = tickCount - 1
        if tickCount <= 0 then
            tickCount = 0
            if tickFrame then tickFrame:SetScript("OnUpdate", nil) end
        end
    end
end

local function Tick()
    local now = GetTime()
    local nowMs = now * 1000
    for bar in pairs(ticking) do
        -- A bar that refuses its value, or one whose stop event never arrived,
        -- is dropped instead of erroring every frame until reload.
        if bar.tickStart and (now - bar.tickStart) > 60 then
            ClearBar(bar)
        elseif not pcall(bar.cover.SetValue, bar.cover, nowMs) then
            -- Dropping only the tick would leave the previous cast's icon and
            -- name sitting on screen with a frozen bar.
            ClearBar(bar)
        end
    end
end

-- The secret start/end go in as the RANGE and a plain clock goes in as the
-- VALUE, so the engine does the division and no secret is ever inspected.
-- Both setters are allowed for tainted callers.
local function ApplyFill(bar, startTimeMs, endTimeMs)
    bar.cover:SetMinMaxValues(startTimeMs, endTimeMs)
    bar.cover:SetValue(GetTime() * 1000)

    if not ticking[bar] then
        ticking[bar] = true
        bar.tickStart = GetTime()
        tickCount = tickCount + 1
        if not tickFrame then tickFrame = CreateFrame("Frame") end
        tickFrame:SetScript("OnUpdate", Tick)
    end
end

function ClearBar(bar)
    StopTicking(bar)
    bar.gate:SetAlpha(1)
    bar.cover:SetMinMaxValues(0, 1)
    bar.cover:SetValue(0)
    bar.label:SetText("")
    bar.icon:SetTexture(nil)
    bar:SetAlpha(0)
    bar:Hide()
end

-- ── cast state ──────────────────────────────────────────────────────────────
-- Only the returned `present` flag -- built here -- is safe to branch on.
-- Everything after it may be secret and is only ever passed to a setter.
local function FetchCast(unit)
    -- name, displayName, texture, startMs, endMs, isTradeskill, castID,
    -- notInterruptible, spellID, ...
    local _, displayName, textureID, startTimeMs, endTimeMs, isTradeskill, _2, notInterruptible =
        UnitCastingInfo(unit)
    if Present(isTradeskill) then
        return true, displayName, textureID, startTimeMs, endTimeMs, notInterruptible
    end

    -- name, displayName, texture, startMs, endMs, isTradeskill,
    -- notInterruptible, spellID, ...
    local _3, cDisplay, cTexture, cStart, cEnd, cTrade, cNotInt = UnitChannelInfo(unit)
    if Present(cTrade) then
        return true, cDisplay, cTexture, cStart, cEnd, cNotInt
    end

    return false
end

local function StartCast(bar)
    if moving then return end
    local d = DB()
    if d.enabled == false or d.bars == false then ClearBar(bar) return end
    if d.onlyInstances and not IsInInstance() then ClearBar(bar) return end
    if bar.index > (d.barCount or 5) then ClearBar(bar) return end

    local unit = bar.unit
    if not UnitExists(unit) then ClearBar(bar) return end

    -- Hostility can itself come back secret in restricted content; when it
    -- does, let the cast through and leave the targeting check to do the work.
    local okAttack, canAttack = pcall(UnitCanAttack, "player", unit)
    if okAttack and PlainValue(canAttack) == false then ClearBar(bar) return end

    if d.skipBosses ~= false and _G.AkcQOL_IsBossNameplate
        and _G.AkcQOL_IsBossNameplate(unit) then
        ClearBar(bar)
        return
    end

    local present, displayName, textureID, startTimeMs, endTimeMs, notInterruptible = FetchCast(unit)
    if not present then ClearBar(bar) return end

    -- Green when it can be kicked, red when it cannot -- decided by the engine
    -- from a value this addon is not allowed to look at.
    local coloured = pcall(bar.remaining.SetVertexColorFromBoolean, bar.remaining,
        notInterruptible, COLOR_LOCKED, COLOR_KICKABLE)
    if not coloured then
        bar.remaining:SetVertexColor(COLOR_KICKABLE:GetRGBA())
    end

    -- Interruptible-only filter. The same secret flag that picked the colour
    -- now drives the inner alpha, so uninterruptible casts fade out without
    -- the addon ever branching on them.
    if d.barsOnlyInterruptible ~= false then
        local gated = pcall(bar.gate.SetAlphaFromBoolean, bar.gate, notInterruptible, 0, 1)
        if not gated then
            -- Unrestricted content hands back a plain value; nil means the
            -- game did not say, and a cast we cannot judge is worth showing.
            bar.gate:SetAlpha(PlainValue(notInterruptible) == true and 0 or 1)
        end
    else
        bar.gate:SetAlpha(1)
    end

    -- Cleared first, so a refused setter leaves an empty widget rather than
    -- the previous mob's spell on a recycled nameplate slot.
    bar.icon:SetTexture(nil)
    bar.label:SetText("")
    pcall(bar.icon.SetTexture, bar.icon, textureID)
    pcall(bar.label.SetText, bar.label, displayName)

    StopTicking(bar)
    if not pcall(ApplyFill, bar, startTimeMs, endTimeMs) then ClearBar(bar) return end

    -- Whether this cast is aimed at the player is secret; handing it to the
    -- alpha makes the bar appear only when the answer is yes, and the addon
    -- never learns which it was.
    -- Blank first: if anything below fails, the bar must not inherit the
    -- previous cast's visibility and show a spell that is not aimed at us.
    bar:SetAlpha(0)
    bar:Show()
    local shown = false
    if _G.PlayerIsSpellTarget and bar.SetAlphaFromBoolean then
        -- The call itself is protected too; as a pcall ARGUMENT it would run
        -- unguarded and its error would escape.
        local okTarget, isTarget = pcall(_G.PlayerIsSpellTarget, unit)
        if okTarget then
            shown = pcall(bar.SetAlphaFromBoolean, bar, isTarget, 1, 0)
        end
    end
    if not shown then
        -- Still strictly "aimed at me", just read the plain way: on a client
        -- without PlayerIsSpellTarget the caster's own target is readable, and
        -- that is the same question. Without this the whole feature would be
        -- silently dead rather than merely less precise.
        local okUnit, isMine = pcall(UnitIsUnit, unit .. "target", "player")
        if okUnit and PlainValue(isMine) == true then
            bar:SetAlpha(1)
        else
            ClearBar(bar)
        end
    end
end

-- ── events ──────────────────────────────────────────────────────────────────
-- Payload arguments are deliberately ignored: unitTarget, castGUID and spellID
-- are secret on these events. RegisterUnitEvent lets the engine route per unit,
-- so slot i always follows whoever occupies nameplate i.
local CAST_EVENTS = {
    UNIT_SPELLCAST_START             = "start",
    UNIT_SPELLCAST_DELAYED           = "start",
    UNIT_SPELLCAST_INTERRUPTIBLE     = "start",
    UNIT_SPELLCAST_NOT_INTERRUPTIBLE = "start",
    UNIT_SPELLCAST_CHANNEL_START     = "start",
    UNIT_SPELLCAST_CHANNEL_UPDATE    = "start",
    UNIT_SPELLCAST_EMPOWER_START     = "start",
    UNIT_SPELLCAST_EMPOWER_UPDATE    = "start",
    UNIT_SPELLCAST_STOP              = "stop",
    UNIT_SPELLCAST_CHANNEL_STOP      = "stop",
    UNIT_SPELLCAST_EMPOWER_STOP      = "stop",
    UNIT_SPELLCAST_INTERRUPTED       = "stop",
    UNIT_SPELLCAST_FAILED            = "stop",
}

-- Every event re-reads the unit instead of trusting what the event means.
-- UNIT_SPELLCAST_FAILED can arrive for a cast the mob just abandoned while a
-- channel is still running on the same unit, and its payload may not be read,
-- so clearing on "stop" would blank a live channel. StartCast already clears
-- when the unit turns out not to be casting.
local function OnCastEvent(self)
    if moving then return end
    pcall(StartCast, self)
end

local function EnsureBars()
    if bars[1] then return end
    for i = 1, MAX_BARS do
        local bar = CreateBar(i)
        for event in pairs(CAST_EVENTS) do
            pcall(bar.RegisterUnitEvent, bar, event, bar.unit)
        end
        bar:SetScript("OnEvent", OnCastEvent)
        bars[i] = bar
    end
end

local function ClearAll()
    for _, bar in ipairs(bars) do ClearBar(bar) end
end

-- ── public ──────────────────────────────────────────────────────────────────
local moverTimeout = 0

function _G.AkcQOL_ToggleCastBarsMover()
    EnsureBars()
    local frame = EnsureRoot()
    moving = not moving
    frame:EnableMouse(moving)

    -- Placement mode closes itself: nothing of ours should stay mouse-enabled
    -- because a settings button was left unpressed.
    moverTimeout = moverTimeout + 1
    if moving and C_Timer and C_Timer.After then
        local token = moverTimeout
        C_Timer.After(30, function()
            if moving and token == moverTimeout then _G.AkcQOL_ToggleCastBarsMover() end
        end)
    end
    frame.hint:SetShown(moving)
    if frame.moveLabel then frame.moveLabel:SetShown(moving) end
    frame:SetScale(DB().barScale or 1)

    local count = DB().barCount or 5
    for i, bar in ipairs(bars) do
        if moving and i <= count then
            StopTicking(bar)
            bar.cover:SetMinMaxValues(0, 1)
            bar.cover:SetValue(i / (count + 1))
            bar.gate:SetAlpha(1)
            local onlyKickable = DB().barsOnlyInterruptible ~= false
            local sample = (onlyKickable or i % 2 == 1) and COLOR_KICKABLE or COLOR_LOCKED
            bar.remaining:SetVertexColor(sample:GetRGBA())
            bar.icon:SetTexture(136230)
            bar.label:SetText((L and L["Cast Bars"]) or "Cast Bars")
            bar:SetAlpha(1)
            bar:Show()
        else
            ClearBar(bar)
        end
    end
end

function _G.AkcQOL_ResetCastBarsPosition()
    DB().pos = nil
    if root then
        root:ClearAllPoints()
        root:SetPoint("CENTER", UIParent, "CENTER", 0, 140)
    end
end

function _G.AkcQOL_ApplyCastBars()
    if moving then _G.AkcQOL_ToggleCastBarsMover() end

    -- Built regardless of the toggles: StartCast re-checks them on every event
    -- and clears, so registering costs nothing while disabled. Gating this on
    -- `enabled` meant a fresh profile -- where the shared cast-alert toggle
    -- starts off -- never created a single bar or event registration, and no
    -- bar appeared until the next reload.
    EnsureBars()

    local d = DB()
    if d.enabled == false or d.bars == false then
        ClearAll()
        return
    end
    EnsureRoot():SetScale(d.barScale or 1)
    ClearAll()
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
-- Placement mode must not survive into a pull: a mouse-enabled slab across the
-- middle of the screen kills right-click camera turning exactly when it matters.
boot:RegisterEvent("PLAYER_REGEN_DISABLED")
boot:RegisterEvent("NAME_PLATE_UNIT_ADDED")
boot:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
boot:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        _G.AkcQOL_ApplyCastBars()
        return
    end
    if event == "PLAYER_REGEN_DISABLED" then
        if moving then _G.AkcQOL_ToggleCastBarsMover() end
        return
    end
    if moving then return end
    -- Nameplate slots get recycled; drop any bar whose unit is gone.
    for _, bar in ipairs(bars) do
        if not UnitExists(bar.unit) then ClearBar(bar) end
    end
end)
