local _, addon = ...

local BUTTON_GROUPS = {
    { prefix = "ActionButton", binding = "ACTIONBUTTON", start = 1 },
    { prefix = "MultiBarBottomLeftButton", binding = "MULTIACTIONBAR1BUTTON", start = 61 },
    { prefix = "MultiBarBottomRightButton", binding = "MULTIACTIONBAR2BUTTON", start = 49 },
    { prefix = "MultiBarRightButton", binding = "MULTIACTIONBAR3BUTTON", start = 25 },
    { prefix = "MultiBarLeftButton", binding = "MULTIACTIONBAR4BUTTON", start = 37 },
    { prefix = "MultiBar5Button", binding = "MULTIACTIONBAR5BUTTON", start = 145 },
    { prefix = "MultiBar6Button", binding = "MULTIACTIONBAR6BUTTON", start = 157 },
    { prefix = "MultiBar7Button", binding = "MULTIACTIONBAR7BUTTON", start = 169 },
}

local FONT_FACE = NumberFontNormalSmall and NumberFontNormalSmall:GetFont() or "Fonts\\FRIZQT__.TTF"
local FONT_SIZE = 16
local FONT_FLAGS = "THICKOUTLINE"
local REFRESH_DELAY = 0.05
local HIDDEN_REGION_KEYS = {
    "FlyoutArrow",
    "FlyoutBorder",
    "FlyoutBorderShadow",
    "SpellHighlightTexture",
    "SpellHighlightAnim",
    "NewActionTexture",
}
local ASSISTED_ROTATION_REGION_KEYS = {
    "InactiveTexture",
    "ActiveFrame",
}
local SLOT_BINDING_MAP = {
    { start = 1, finish = 24, binding = "ACTIONBUTTON" },
    { start = 25, finish = 36, binding = "MULTIACTIONBAR3BUTTON" },
    { start = 37, finish = 48, binding = "MULTIACTIONBAR4BUTTON" },
    { start = 49, finish = 60, binding = "MULTIACTIONBAR2BUTTON" },
    { start = 61, finish = 72, binding = "MULTIACTIONBAR1BUTTON" },
    { start = 73, finish = 132, binding = "ACTIONBUTTON" },
    { start = 145, finish = 156, binding = "MULTIACTIONBAR5BUTTON" },
    { start = 157, finish = 168, binding = "MULTIACTIONBAR6BUTTON" },
    { start = 169, finish = 180, binding = "MULTIACTIONBAR7BUTTON" },
}
local DEFAULT_BUTTON_TEXT = {
    [1] = "1",
    [2] = "2",
    [3] = "3",
    [4] = "4",
    [5] = "5",
    [6] = "6",
    [7] = "7",
    [8] = "8",
    [9] = "9",
    [10] = "0",
    [11] = "-",
    [12] = "=",
}
local KEY_SCAN_BASES = {
    "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
    "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
    "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12",
    "SPACE", "TAB", "CAPSLOCK", "BACKSPACE", "INSERT", "DELETE", "HOME", "END",
    "PAGEUP", "PAGEDOWN", "UP", "DOWN", "LEFT", "RIGHT",
    "NUMPAD0", "NUMPAD1", "NUMPAD2", "NUMPAD3", "NUMPAD4", "NUMPAD5",
    "NUMPAD6", "NUMPAD7", "NUMPAD8", "NUMPAD9",
    "NUMPADPLUS", "NUMPADMINUS", "NUMPADMULTIPLY", "NUMPADDIVIDE", "NUMPADDECIMAL",
    "BUTTON3", "BUTTON4", "BUTTON5", "BUTTON6", "BUTTON7", "BUTTON8", "BUTTON9",
    "MOUSEWHEELUP", "MOUSEWHEELDOWN",
}
local KEY_SCAN_MODIFIERS = {
    "",
    "SHIFT-",
    "CTRL-",
    "ALT-",
    "CTRL-SHIFT-",
    "ALT-SHIFT-",
    "ALT-CTRL-",
    "ALT-CTRL-SHIFT-",
}

local eventFrame = CreateFrame("Frame")
local touchedButtons = {}
local refreshQueued = false
local hooksInstalled = false
local scanKeys
local updateTicker
local assistedSlotsCache
local spellActionSlotsCache = {}
local bindingTextCache = {}
local lastPolledSpellID = false

local function GetAssistantDB()
    local db = addon.AkcQOL and addon.AkcQOL.db and addon.AkcQOL.db.profile
    if not db then return nil end
    db.singleButtonAssistantKeybind = db.singleButtonAssistantKeybind or {}
    local d = db.singleButtonAssistantKeybind
    if d.hideArrow == nil and d.showKeybind == nil and d.enabled ~= nil then
        d.hideArrow = d.enabled
        d.showKeybind = d.enabled
    end
    if d.hideArrow == nil then d.hideArrow = false end
    if d.showKeybind == nil then d.showKeybind = false end
    return d
end

local function ShouldHideArrow()
    local d = GetAssistantDB()
    return d ~= nil and d.hideArrow == true
end

local function ShouldShowKeybind()
    local d = GetAssistantDB()
    return d ~= nil and d.showKeybind == true
end

local function IsFeatureEnabled()
    return ShouldHideArrow() or ShouldShowKeybind()
end

local function IsSecret(value)
    if type(issecretvalue) ~= "function" then return false end

    local ok, secret = pcall(issecretvalue, value)
    return ok and secret == true
end

local function SafeLower(value)
    if not value or IsSecret(value) then return "" end

    local ok, text = pcall(tostring, value)
    if not ok or not text then return "" end

    return text:lower()
end

local function NormalizeSlot(slot)
    if not slot or IsSecret(slot) then return nil end

    local numberSlot = tonumber(slot)
    if numberSlot then return numberSlot end

    return nil
end

local function GetButtonActionSlot(button)
    if not button then return nil end
    if button.action and not IsSecret(button.action) then return NormalizeSlot(button.action) end

    if button.GetAttribute then
        local ok, action = pcall(button.GetAttribute, button, "action")
        if ok and action and not IsSecret(action) then return NormalizeSlot(action) end
    end

    if type(ActionButton_CalculateAction) == "function" then
        local ok, action = pcall(ActionButton_CalculateAction, button)
        if ok and action and not IsSecret(action) then return NormalizeSlot(action) end
    end

    return nil
end

local function IsAssistantAction(slot)
    if not slot or IsSecret(slot) then return false end
    if type(GetActionInfo) ~= "function" then return false end

    local ok, actionType, _, subType = pcall(GetActionInfo, slot)
    if not ok then return false end

    return SafeLower(subType) == "assistedcombat" or SafeLower(actionType) == "assistedcombat"
end

local function GetBaseSpellID(spellID)
    spellID = tonumber(spellID)
    if not spellID then return nil end

    if C_SpellBook and type(C_SpellBook.FindBaseSpellByID) == "function" then
        local ok, baseSpellID = pcall(C_SpellBook.FindBaseSpellByID, spellID)
        if ok and baseSpellID and not IsSecret(baseSpellID) then
            return tonumber(baseSpellID) or spellID
        end
    end

    return spellID
end

local function IsSameSpell(spellID, otherSpellID)
    local baseSpellID = GetBaseSpellID(spellID)
    local otherBaseSpellID = GetBaseSpellID(otherSpellID)

    return baseSpellID and otherBaseSpellID and baseSpellID == otherBaseSpellID
end

local function GetCurrentAssistedSpellID()
    local manager = _G.AssistedCombatManager
    if manager and type(manager.IsAssistedHighlightActive) == "function" then
        local ok, active = pcall(manager.IsAssistedHighlightActive, manager)
        if ok and active then
            return tonumber(manager.lastNextCastSpellID)
        end
    end

    if not C_AssistedCombat or type(C_AssistedCombat.GetNextCastSpell) ~= "function" then
        return nil
    end

    local ok, spellID = pcall(C_AssistedCombat.GetNextCastSpell, true)
    if ok then return tonumber(spellID) end
    return nil
end

local function GetAssistedActionSlots()
    if assistedSlotsCache then return assistedSlotsCache end

    local slots = {}

    if C_ActionBar and type(C_ActionBar.FindAssistedCombatActionButtons) == "function" then
        local results = { pcall(C_ActionBar.FindAssistedCombatActionButtons) }
        if results[1] then
            if type(results[2]) == "table" then
                for _, slot in ipairs(results[2]) do
                    slot = NormalizeSlot(slot)
                    if slot then
                        slots[slot] = true
                    end
                end
            else
                for i = 2, #results do
                    local slot = results[i]
                    slot = NormalizeSlot(slot)
                    if slot then
                        slots[slot] = true
                    end
                end
            end
        end
    end

    for slot = 1, 180 do
        if IsAssistantAction(slot) then
            slots[slot] = true
        end
    end

    assistedSlotsCache = slots
    return assistedSlotsCache
end

local function AddCandidate(candidates, seen, action)
    if action and action ~= "" and not seen[action] then
        seen[action] = true
        candidates[#candidates + 1] = action
    end
end

local function BuildScanKeys()
    if scanKeys then return scanKeys end

    scanKeys = {}
    for _, modifier in ipairs(KEY_SCAN_MODIFIERS) do
        for _, key in ipairs(KEY_SCAN_BASES) do
            scanKeys[#scanKeys + 1] = modifier .. key
        end
    end

    return scanKeys
end

local function GetButtonName(button)
    if not button or not button.GetName then return nil end

    local ok, name = pcall(button.GetName, button)
    if ok and name and name ~= "" and not IsSecret(name) then
        return name
    end

    return nil
end

local function GetButtonAttribute(button, attribute)
    if not button or not button.GetAttribute then return nil end

    local ok, value = pcall(button.GetAttribute, button, attribute)
    if ok and value and value ~= "" and not IsSecret(value) then
        return value
    end

    return nil
end

local function AddSlotBindingCandidate(candidates, seen, slot)
    slot = NormalizeSlot(slot)
    if not slot then return end

    for _, info in ipairs(SLOT_BINDING_MAP) do
        if slot >= info.start and slot <= info.finish then
            local index = ((slot - info.start) % 12) + 1
            AddCandidate(candidates, seen, info.binding .. index)
            return
        end
    end
end

local function GetSlotBindingInfo(slot)
    slot = NormalizeSlot(slot)
    if not slot then return nil, nil end

    for _, info in ipairs(SLOT_BINDING_MAP) do
        if slot >= info.start and slot <= info.finish then
            local index = ((slot - info.start) % 12) + 1
            return info.binding, index
        end
    end

    return nil, nil
end

local function GetBindingCandidates(button, bindingPrefix, index, slot)
    local candidates = {}
    local seen = {}
    local id = button and button.GetID and button:GetID() or index
    local buttonName = GetButtonName(button)

    if button and button.buttonType then
        AddCandidate(candidates, seen, button.buttonType .. id)
    end

    if button and button.commandName then
        AddCandidate(candidates, seen, button.commandName)
    end

    AddCandidate(candidates, seen, GetButtonAttribute(button, "commandName"))
    AddCandidate(candidates, seen, GetButtonAttribute(button, "binding"))
    AddCandidate(candidates, seen, GetButtonAttribute(button, "bindingAction"))
    AddCandidate(candidates, seen, GetButtonAttribute(button, "binding-action"))

    AddCandidate(candidates, seen, bindingPrefix .. id)
    AddCandidate(candidates, seen, bindingPrefix .. index)

    if type(ActionButton_GetPagedID) == "function" then
        local ok, pagedID = pcall(ActionButton_GetPagedID, button)
        if ok and pagedID and not IsSecret(pagedID) then
            AddCandidate(candidates, seen, bindingPrefix .. pagedID)
        end
    end

    AddSlotBindingCandidate(candidates, seen, slot)

    if buttonName then
        AddCandidate(candidates, seen, buttonName)
        AddCandidate(candidates, seen, "CLICK " .. buttonName .. ":LeftButton")
        AddCandidate(candidates, seen, "CLICK " .. buttonName .. ":HotKey")
        AddCandidate(candidates, seen, "CLICK " .. buttonName .. ":HOTKEY")
        AddCandidate(candidates, seen, "CLICK " .. buttonName .. ":Keybind")
    end

    return candidates
end

local function BuildCandidateSet(candidates)
    local set = {}
    for _, candidate in ipairs(candidates) do
        set[candidate] = true
        set[SafeLower(candidate)] = true
    end
    return set
end

local function CandidateMatches(set, action)
    if not action or action == "" or IsSecret(action) then return false end
    return set[action] or set[SafeLower(action)] or false
end

local function ShortKey(key)
    if not key or key == "" then return "" end

    local text = key
    if type(GetBindingText) == "function" then
        local ok, bindingText = pcall(GetBindingText, key, "KEY_")
        if ok and bindingText and bindingText ~= "" and not IsSecret(bindingText) then
            text = bindingText
        end
    end

    text = text:gsub("CTRL%-", "Ctrl-")
    text = text:gsub("SHIFT%-", "Shift-")
    text = text:gsub("ALT%-", "Alt-")
    text = text:gsub("META%-", "Cmd-")
    text = text:gsub("NUMPAD", "Num")
    text = text:gsub("MOUSEWHEELUP", "WheelUp")
    text = text:gsub("MOUSEWHEELDOWN", "WheelDown")
    text = text:gsub("BUTTON", "M")
    text = text:gsub("SPACE", "Space")
    text = text:gsub("PLUS", "+")
    text = text:gsub("MINUS", "-")

    return text
end

local function PickPreferredKey(results, index)
    local defaultText = DEFAULT_BUTTON_TEXT[index]
    local firstKey

    for i = 2, #results do
        local key = results[i]
        if key and key ~= "" and not IsSecret(key) then
            firstKey = firstKey or key

            local short = ShortKey(key)
            if short ~= "" and short ~= defaultText then
                return key
            end
        end
    end

    return firstKey
end

local function GetButtonBindingText(button, bindingPrefix, index, slot)
    if type(GetBindingKey) ~= "function" then return "" end

    local candidates = GetBindingCandidates(button, bindingPrefix, index, slot)
    for _, bindingAction in ipairs(candidates) do
        local results = { pcall(GetBindingKey, bindingAction) }
        if results[1] then
            local key = PickPreferredKey(results, index)
            if key and key ~= "" and not IsSecret(key) then
                return ShortKey(key)
            end
        end
    end

    return ""
end

local function GetBindingActionScanText(button, bindingPrefix, index, slot)
    if type(GetBindingAction) ~= "function" then return "" end

    local candidates = GetBindingCandidates(button, bindingPrefix, index, slot)
    local candidateSet = BuildCandidateSet(candidates)
    local defaultText = DEFAULT_BUTTON_TEXT[index]
    local firstText = ""

    for _, key in ipairs(BuildScanKeys()) do
        local ok, action = pcall(GetBindingAction, key, true)
        if ok and CandidateMatches(candidateSet, action) then
            local text = ShortKey(key)
            if text ~= "" then
                if text ~= defaultText then return text end
                firstText = firstText ~= "" and firstText or text
            end
        end

        ok, action = pcall(GetBindingAction, key, false)
        if ok and CandidateMatches(candidateSet, action) then
            local text = ShortKey(key)
            if text ~= "" then
                if text ~= defaultText then return text end
                firstText = firstText ~= "" and firstText or text
            end
        end
    end

    return firstText
end

local function GetOverrideBindingText(button, index)
    if not button or type(GetOverrideBindingKey) ~= "function" then return "" end

    local buttonName = GetButtonName(button)
    if not buttonName then return "" end

    local actions = {
        "CLICK " .. buttonName .. ":LeftButton",
        "CLICK " .. buttonName .. ":HotKey",
        "CLICK " .. buttonName .. ":HOTKEY",
        "CLICK " .. buttonName .. ":Keybind",
    }

    local owners = { button, UIParent }
    for _, owner in ipairs(owners) do
        for _, action in ipairs(actions) do
            local results = { pcall(GetOverrideBindingKey, owner, action) }
            if results[1] then
                local key = PickPreferredKey(results, index)
                if key and key ~= "" and not IsSecret(key) then
                    return ShortKey(key)
                end
            end
        end
    end

    return ""
end

local function GetAnyBindingText(button, bindingPrefix, index, slot)

    local cacheKey = table.concat({
        button and (GetButtonName(button) or tostring(button)) or "",
        tostring(bindingPrefix or ""),
        tostring(index or ""),
        tostring(slot or ""),
    }, ":")
    if bindingTextCache[cacheKey] ~= nil then
        return bindingTextCache[cacheKey]
    end

    local text = GetOverrideBindingText(button, index)
    if text ~= "" then
        bindingTextCache[cacheKey] = text
        return text
    end

    text = GetButtonBindingText(button, bindingPrefix, index, slot)
    if text ~= "" and text ~= DEFAULT_BUTTON_TEXT[index] then

        bindingTextCache[cacheKey] = text
        return text
    end

    local scannedText = GetBindingActionScanText(button, bindingPrefix, index, slot)
    if scannedText ~= "" and scannedText ~= DEFAULT_BUTTON_TEXT[index] then
        bindingTextCache[cacheKey] = scannedText
        return scannedText
    end

    if text ~= "" then
        bindingTextCache[cacheKey] = text
        return text
    end
    if scannedText ~= "" then
        bindingTextCache[cacheKey] = scannedText
        return scannedText
    end

    bindingTextCache[cacheKey] = ""
    return ""
end

local function AddSpellActionSlot(slots, seen, slot)
    slot = NormalizeSlot(slot)
    if not slot or seen[slot] then return end

    seen[slot] = true
    slots[#slots + 1] = slot
end

local function GetSpellIDFromActionSlot(slot)
    if not slot or type(GetActionInfo) ~= "function" then return nil end

    local ok, actionType, id, subType = pcall(GetActionInfo, slot)
    if not ok or not id or IsSecret(id) then return nil end

    if actionType == "spell" and subType ~= "assistedcombat" then
        return tonumber(id)
    elseif actionType == "macro" and subType == "spell" then
        return tonumber(id)
    end

    return nil
end

local function FindSpellActionSlots(spellID)
    local cacheID = GetBaseSpellID(spellID) or spellID
    if spellActionSlotsCache[cacheID] then
        return spellActionSlotsCache[cacheID]
    end

    local slots = {}
    local seen = {}

    if C_ActionBar and type(C_ActionBar.FindSpellActionButtons) == "function" then
        local results = { pcall(C_ActionBar.FindSpellActionButtons, spellID) }
        if results[1] then
            if type(results[2]) == "table" then
                for _, slot in ipairs(results[2]) do
                    AddSpellActionSlot(slots, seen, slot)
                end
            else
                for i = 2, #results do
                    AddSpellActionSlot(slots, seen, results[i])
                end
            end
        end
    end

    for slot = 1, 180 do
        local actionSpellID = GetSpellIDFromActionSlot(slot)
        if actionSpellID and IsSameSpell(spellID, actionSpellID) then
            AddSpellActionSlot(slots, seen, slot)
        end
    end

    spellActionSlotsCache[cacheID] = slots
    return slots
end

local function GetBindingTextForActionSlot(slot)
    local bindingPrefix, index = GetSlotBindingInfo(slot)
    if not bindingPrefix or not index then return "" end

    return GetAnyBindingText(nil, bindingPrefix, index, slot)
end

local function GetAssistedSpellBindingText(assistantSlot)
    local spellID = GetCurrentAssistedSpellID()
    if not spellID then return "", nil, {} end

    local slots = FindSpellActionSlots(spellID)
    local firstText = ""

    for _, slot in ipairs(slots) do
        if slot ~= assistantSlot then
            local text = GetBindingTextForActionSlot(slot)
            if text ~= "" then
                return text, spellID, slots
            end
        end
    end

    for _, slot in ipairs(slots) do
        local text = GetBindingTextForActionSlot(slot)
        if text ~= "" then
            firstText = text
            break
        end
    end

    return firstText, spellID, slots
end

local function StyleAssistantKeybindText(text)
    text:SetFont(FONT_FACE, FONT_SIZE, FONT_FLAGS)
    text:SetTextColor(1, 1, 1, 1)
    text:SetShadowColor(0, 0, 0, 1)
    text:SetShadowOffset(1, -1)
    text:SetJustifyH("RIGHT")
    text:SetJustifyV("TOP")
    if text.SetDrawLayer then
        text:SetDrawLayer("OVERLAY", 7)
    end
    text:SetSize(26, 20)
end

-- Only the visibility is kept: the HotKey's text is blanked and the region
-- hidden, nothing else is touched, and RefreshBlizzardHotKey re-derives the
-- text afterwards. Re-applying a saved font or anchors would also undo what a
-- skin addon changed in the meantime.
local function SaveHotKeyLayout(button, hotKey)
    if button.__AkcQOLAssistantHotKeyLayout then return end

    button.__AkcQOLAssistantHotKeyLayout = {
        shown = hotKey:IsShown(),
    }
end

local function RestoreHotKeyLayout(button, hotKey)
    local layout = button.__AkcQOLAssistantHotKeyLayout
    if not layout then return end

    if layout.shown then
        hotKey:Show()
    else
        hotKey:Hide()
    end

    button.__AkcQOLAssistantHotKeyLayout = nil
end

-- The art is suppressed with alpha only, never Hide(): Blizzard's own
-- Show()/Hide() calls then keep the true visibility while the button is
-- decorated, and undecorating only has to give the alpha back.
--
-- Keyed by the region itself and taken once per decoration: the rotation
-- frame's InactiveTexture and ActiveFrame come back through GetRegions() and
-- GetChildren() as well, and a second snapshot would record the alpha 0 set
-- here and keep the art invisible after the option is turned off.
local function SaveHiddenRegionState(button, region)
    button.__AkcQOLAssistantHiddenRegions = button.__AkcQOLAssistantHiddenRegions or {}
    if button.__AkcQOLAssistantHiddenRegions[region] then return end

    local state = {}
    if region.GetAlpha then
        local ok, alpha = pcall(region.GetAlpha, region)
        if ok and type(alpha) == "number" and not IsSecret(alpha) then
            state.alpha = alpha
        end
    end

    button.__AkcQOLAssistantHiddenRegions[region] = state
end

local function HideRegion(button, region)
    if not region then return end

    SaveHiddenRegionState(button, region)
    if region.SetAlpha then region:SetAlpha(0) end

    if not region.__AkcQOLAssistantHideHooked and region.HookScript then
        region.__AkcQOLAssistantHideHooked = true
        pcall(region.HookScript, region, "OnShow", function(self)
            -- Only while this region is still suppressed for the button.
            local hiddenRegions = button.__AkcQOLAssistantHiddenRegions
            if hiddenRegions and hiddenRegions[self] and self.SetAlpha then
                self:SetAlpha(0)
            end
        end)
    end
end

-- Safe to call on every refresh: a region already suppressed keeps its first
-- snapshot, and a rotation frame Blizzard creates later is picked up.
local function HideAssistantArt(button)
    -- Our keybind text sits on the rotation frame too; it is never suppressed,
    -- whether or not it is shown right now.
    local keepRegion = button.AkcQOLAssistantKeybindText

    for _, key in ipairs(HIDDEN_REGION_KEYS) do
        HideRegion(button, button[key])
    end

    local rotationFrame = button.AssistedCombatRotationFrame
    if rotationFrame then
        for _, key in ipairs(ASSISTED_ROTATION_REGION_KEYS) do
            HideRegion(button, rotationFrame[key])
        end

        for _, region in ipairs({ rotationFrame:GetRegions() }) do
            if region ~= keepRegion then
                HideRegion(button, region)
            end
        end

        for _, child in ipairs({ rotationFrame:GetChildren() }) do
            if child ~= keepRegion then
                HideRegion(button, child)
            end
        end
    end
end

local function RestoreAssistantArrowRegions(button)
    local hiddenRegions = button.__AkcQOLAssistantHiddenRegions
    if not hiddenRegions then return end

    -- Cleared first so the OnShow hook stops suppressing these regions.
    button.__AkcQOLAssistantHiddenRegions = nil

    for region, state in pairs(hiddenRegions) do
        if region.SetAlpha then
            region:SetAlpha(state.alpha or 1)
        end
    end
end

local suppressHotkeyHook = false

local function RefreshBlizzardHotKey(button)

    if type(button.UpdateHotkeys) == "function" then
        suppressHotkeyHook = true
        local ok = pcall(button.UpdateHotkeys, button, button.buttonType)
        suppressHotkeyHook = false
        if ok then return end
    end

    if type(ActionButton_UpdateHotkeys) == "function" then
        local ok = pcall(ActionButton_UpdateHotkeys, button, button.buttonType)
        if ok then return end
    end

    if button.HotKey then
        local text = GetAnyBindingText(button, button.__AkcQOLAssistantBindingPrefix or "ACTIONBUTTON", button.__AkcQOLAssistantIndex or button:GetID(), button.__AkcQOLAssistantSlot)
        button.HotKey:SetText(text)
        if text ~= "" then
            button.HotKey:Show()
        end
    end
end

local function ClearAssistantText(button, keepBlankedHotKey, keepHiddenArt)
    if not button then return end

    if button.AkcQOLAssistantKeybindText then
        button.AkcQOLAssistantKeybindText:SetText("")
        button.AkcQOLAssistantKeybindText:Hide()
    end

    if button.__AkcQOLAssistantHotKeyTouched and button.HotKey and not keepBlankedHotKey then
        button.__AkcQOLAssistantHotKeyTouched = nil
        RestoreHotKeyLayout(button, button.HotKey)
        RefreshBlizzardHotKey(button)
    end

    if not keepHiddenArt then
        RestoreAssistantArrowRegions(button)
    end
end

local function GetOrCreateFallbackText(button)
    local parent = button.AssistedCombatRotationFrame or button
    if button.AkcQOLAssistantKeybindText and button.AkcQOLAssistantKeybindText:GetParent() == parent then
        StyleAssistantKeybindText(button.AkcQOLAssistantKeybindText)
        return button.AkcQOLAssistantKeybindText
    elseif button.AkcQOLAssistantKeybindText then
        button.AkcQOLAssistantKeybindText:SetParent(parent)
        button.AkcQOLAssistantKeybindText:ClearAllPoints()
        StyleAssistantKeybindText(button.AkcQOLAssistantKeybindText)
        button.AkcQOLAssistantKeybindText:SetPoint("TOPRIGHT", button, "TOPRIGHT", 1, 2)
        return button.AkcQOLAssistantKeybindText
    end

    local text = parent:CreateFontString(nil, "OVERLAY")
    StyleAssistantKeybindText(text)
    text:SetPoint("TOPRIGHT", button, "TOPRIGHT", 1, 2)
    text:Hide()

    button.AkcQOLAssistantKeybindText = text
    return text
end

local function ApplyAssistantText(button, bindingPrefix, index, slot)

    local showKb = ShouldShowKeybind()
    local text = ""
    if showKb then
        text = GetAssistedSpellBindingText(slot)
    end

    -- While the art stays suppressed it is not restored and taken again on
    -- every refresh: that would carry the first snapshot forward and keep
    -- calling Show()/Hide() on Blizzard's regions.
    local hideArrow = ShouldHideArrow()
    ClearAssistantText(button, showKb and text ~= "", hideArrow)

    local overlay = showKb and GetOrCreateFallbackText(button) or nil

    if hideArrow then
        HideAssistantArt(button)
    end

    if showKb and overlay then
        overlay:SetText(text)
        if text ~= "" then
            overlay:Show()
        else
            overlay:Hide()
        end

        if text ~= "" and button.HotKey then
            SaveHotKeyLayout(button, button.HotKey)
            button.__AkcQOLAssistantHotKeyTouched = true
            button.__AkcQOLAssistantBindingPrefix = bindingPrefix
            button.__AkcQOLAssistantIndex = index
            button.__AkcQOLAssistantSlot = slot

            button.HotKey:SetText("")
            button.HotKey:Hide()
        end
    end

    touchedButtons[button] = true
end

local function RefreshAssistantKeybind()
    refreshQueued = false

    if not IsFeatureEnabled() then
        for button in pairs(touchedButtons) do
            ClearAssistantText(button)
        end
        for _, group in ipairs(BUTTON_GROUPS) do
            for index = 1, 12 do
                ClearAssistantText(_G[group.prefix .. index])
            end
        end
        wipe(touchedButtons)
        return
    end

    local assistedSlots = GetAssistedActionSlots()
    local stillTouched = {}

    for _, group in ipairs(BUTTON_GROUPS) do
        for index = 1, 12 do
            local button = _G[group.prefix .. index]
            -- The page-1 slot only stands in when the button's own action
            -- cannot be read: a paged main bar (forms, stealth, manual paging)
            -- shows another ability on this button, whose hotkey and art must
            -- stay untouched.
            local slot = GetButtonActionSlot(button) or (group.start and (group.start + index - 1))
            if button and slot and (assistedSlots[slot] or IsAssistantAction(slot)) then
                ApplyAssistantText(button, group.binding, index, slot)
                stillTouched[button] = true
            elseif button then
                ClearAssistantText(button)
            end
        end
    end

    for button in pairs(touchedButtons) do
        if not stillTouched[button] then
            ClearAssistantText(button)
        end
    end

    wipe(touchedButtons)
    for button in pairs(stillTouched) do
        touchedButtons[button] = true
    end
end

local function QueueRefresh()
    if refreshQueued then return end
    refreshQueued = true

    if C_Timer and C_Timer.After then
        C_Timer.After(REFRESH_DELAY, RefreshAssistantKeybind)
    else
        RefreshAssistantKeybind()
    end
end

local function InvalidateActionCache(clearBindings)
    assistedSlotsCache = nil
    wipe(spellActionSlotsCache)
    lastPolledSpellID = false
    if clearBindings then
        wipe(bindingTextCache)
    end
end

local function PollSuggestedSpell()
    if not IsFeatureEnabled() then return end

    local spellID = GetCurrentAssistedSpellID()
    if spellID ~= lastPolledSpellID then
        lastPolledSpellID = spellID
        QueueRefresh()
    end
end

local highlightCallbackOwner = {}
local highlightCallbackRegistered = false

local function RegisterHighlightCallback()
    if highlightCallbackRegistered then return end
    if EventRegistry and EventRegistry.RegisterCallback then
        local ok = pcall(EventRegistry.RegisterCallback, EventRegistry,
            "AssistedCombatManager.OnAssistedHighlightSpellChange", PollSuggestedSpell, highlightCallbackOwner)
        highlightCallbackRegistered = ok
    end
end

local function GetPollRate()
    local manager = _G.AssistedCombatManager
    if manager and type(manager.GetUpdateRate) == "function" then
        local ok, rate = pcall(manager.GetUpdateRate, manager)
        rate = ok and tonumber(rate) or nil
        if rate and rate > 0 then return rate end
    end
    return 0.1
end

local function SyncTicker()
    if IsFeatureEnabled() then
        RegisterHighlightCallback()
        if not updateTicker and C_Timer and C_Timer.NewTicker then
            updateTicker = C_Timer.NewTicker(GetPollRate(), PollSuggestedSpell)
        end
    elseif updateTicker then
        updateTicker:Cancel()
        updateTicker = nil
    end
end

local function QueueEnabledRefresh()
    if IsFeatureEnabled() then QueueRefresh() end
end

local function OnActionChanged()
    InvalidateActionCache(false)
    QueueEnabledRefresh()
end

local function InstallHooks()
    if hooksInstalled then return end
    hooksInstalled = true

    if type(hooksecurefunc) == "function" then
        if type(ActionButton_UpdateHotkeys) == "function" then

            pcall(hooksecurefunc, "ActionButton_UpdateHotkeys", QueueEnabledRefresh)
        else

            local function OnBlizzardHotkeyUpdate()
                if not suppressHotkeyHook then
                    QueueEnabledRefresh()
                end
            end
            for _, group in ipairs(BUTTON_GROUPS) do
                for index = 1, 12 do
                    local button = _G[group.prefix .. index]
                    if button and type(button.UpdateHotkeys) == "function" then
                        pcall(hooksecurefunc, button, "UpdateHotkeys", OnBlizzardHotkeyUpdate)
                    end
                end
            end
        end
    end

    SyncTicker()
end

local function OnEvent(_, event)
    local clearBindings = event == "UPDATE_BINDINGS"
    if clearBindings
        or event == "ACTIONBAR_SLOT_CHANGED"
        or event == "ACTIONBAR_PAGE_CHANGED"
        or event == "PLAYER_ENTERING_WORLD"
        or event == "PLAYER_LOGIN"
    then
        InvalidateActionCache(clearBindings)
    end

    InstallHooks()
    SyncTicker()
    QueueRefresh()
end

eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("UPDATE_BINDINGS")
eventFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
eventFrame:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
eventFrame:SetScript("OnEvent", OnEvent)

if EventRegistry and EventRegistry.RegisterCallback then
    EventRegistry:RegisterCallback("ActionButton.OnActionChanged", OnActionChanged, eventFrame)
end

addon.RefreshSingleButtonAssistantKeybind = function()
    InvalidateActionCache(true)
    SyncTicker()
    QueueRefresh()
end
