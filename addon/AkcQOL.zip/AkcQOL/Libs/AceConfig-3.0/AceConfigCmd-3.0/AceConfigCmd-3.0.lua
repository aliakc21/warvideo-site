
local cfgreg = LibStub("AceConfigRegistry-3.0")

local MAJOR, MINOR = "AceConfigCmd-3.0", 14
local AceConfigCmd = LibStub:NewLibrary(MAJOR, MINOR)

if not AceConfigCmd then return end

AceConfigCmd.commands = AceConfigCmd.commands or {}
local commands = AceConfigCmd.commands

local AceConsole
local AceConsoleName = "AceConsole-3.0"

local strsub, strsplit, strlower, strmatch, strtrim = string.sub, string.split, string.lower, string.match, string.trim
local format, tonumber, tostring = string.format, tonumber, tostring
local tsort, tinsert = table.sort, table.insert
local select, pairs, next, type = select, pairs, next, type
local error, assert = error, assert

local _G = _G

local L = setmetatable({}, {
	__index = function(self,k) return k end
})

local function print(msg)
	(SELECTED_CHAT_FRAME or DEFAULT_CHAT_FRAME):AddMessage(msg)
end

local handlertypes = {["table"]=true}
local handlermsg = "expected a table"

local functypes = {["function"]=true, ["string"]=true}
local funcmsg = "expected function or member name"

local function pickfirstset(...)
	for i=1,select("#",...) do
		if select(i,...)~=nil then
			return select(i,...)
		end
	end
end

local function err(info,inputpos,msg )
	local cmdstr=" "..strsub(info.input, 1, inputpos-1)
	error(MAJOR..": /" ..info[0] ..cmdstr ..": "..(msg or "malformed options table"), 2)
end

local function usererr(info,inputpos,msg )
	local cmdstr=strsub(info.input, 1, inputpos-1);
	print("/" ..info[0] .. " "..cmdstr ..": "..(msg or "malformed options table"))
end

local function callmethod(info, inputpos, tab, methodtype, ...)
	local method = info[methodtype]
	if not method then
		err(info, inputpos, "'"..methodtype.."': not set")
	end

	info.arg = tab.arg
	info.option = tab
	info.type = tab.type

	if type(method)=="function" then
		return method(info, ...)
	elseif type(method)=="string" then
		if type(info.handler[method])~="function" then
			err(info, inputpos, "'"..methodtype.."': '"..method.."' is not a member function of "..tostring(info.handler))
		end
		return info.handler[method](info.handler, info, ...)
	else
		assert(false)
	end
end

local function callfunction(info, tab, methodtype, ...)
	local method = tab[methodtype]

	info.arg = tab.arg
	info.option = tab
	info.type = tab.type

	if type(method)=="function" then
		return method(info, ...)
	else
		assert(false)
	end
end

local function do_final(info, inputpos, tab, methodtype, ...)
	if info.validate then
		local res = callmethod(info,inputpos,tab,"validate",...)
		if type(res)=="string" then
			usererr(info, inputpos, "'"..strsub(info.input, inputpos).."' - "..res)
			return
		end
	end

	callmethod(info,inputpos,tab,methodtype, ...)
end

local function getparam(info, inputpos, tab, depth, paramname, types, errormsg)
	local old,oldat = info[paramname], info[paramname.."_at"]
	local val=tab[paramname]
	if val~=nil then
		if val==false then
			val=nil
		elseif not types[type(val)] then
			err(info, inputpos, "'" .. paramname.. "' - "..errormsg)
		end
		info[paramname] = val
		info[paramname.."_at"] = depth
	end
	return old,oldat
end

local dummytable={}

local function iterateargs(tab)
	if not tab.plugins then
		return pairs(tab.args)
	end

	local argtabkey,argtab=next(tab.plugins)
	local v

	return function(_, k)
		while argtab do
			k,v = next(argtab, k)
			if k then return k,v end
			if argtab==tab.args then
				argtab=nil
			else
				argtabkey,argtab = next(tab.plugins, argtabkey)
				if not argtabkey then
					argtab=tab.args
				end
			end
		end
	end
end

local function checkhidden(info, inputpos, tab)
	if tab.cmdHidden~=nil then
		return tab.cmdHidden
	end
	local hidden = tab.hidden
	if type(hidden) == "function" or type(hidden) == "string" then
		info.hidden = hidden
		hidden = callmethod(info, inputpos, tab, 'hidden')
		info.hidden = nil
	end
	return hidden
end

local function showhelp(info, inputpos, tab, depth, noHead)
	if not noHead then
		print("|cff33ff99"..info.appName.."|r: Arguments to |cffffff78/"..info[0].."|r "..strsub(info.input,1,inputpos-1)..":")
	end

	local sortTbl = {}
	local refTbl = {}

	for k,v in iterateargs(tab) do
		if not refTbl[k] then
			tinsert(sortTbl, k)
			refTbl[k] = v
		end
	end

	tsort(sortTbl, function(one, two)
		local o1 = refTbl[one].order or 100
		local o2 = refTbl[two].order or 100
		if type(o1) == "function" or type(o1) == "string" then
			info.order = o1
			info[#info+1] = one
			o1 = callmethod(info, inputpos, refTbl[one], "order")
			info[#info] = nil
			info.order = nil
		end
		if type(o2) == "function" or type(o1) == "string" then
			info.order = o2
			info[#info+1] = two
			o2 = callmethod(info, inputpos, refTbl[two], "order")
			info[#info] = nil
			info.order = nil
		end
		if o1<0 and o2<0 then return o1<o2 end
		if o2<0 then return true end
		if o1<0 then return false end
		if o1==o2 then return tostring(one)<tostring(two) end
		return o1<o2
	end)

	for i = 1, #sortTbl do
		local k = sortTbl[i]
		local v = refTbl[k]
		if not checkhidden(info, inputpos, v) then
			if v.type ~= "description" and v.type ~= "header" then

				local name, desc = v.name, v.desc
				if type(name) == "function" then
					name = callfunction(info, v, 'name')
				end
				if type(desc) == "function" then
					desc = callfunction(info, v, 'desc')
				end
				if v.type == "group" and pickfirstset(v.cmdInline, v.inline, false) then
					print("  "..(desc or name)..":")
					local oldhandler,oldhandler_at = getparam(info, inputpos, v, depth, "handler", handlertypes, handlermsg)
					showhelp(info, inputpos, v, depth, true)
					info.handler,info.handler_at = oldhandler,oldhandler_at
				else
					local key = k:gsub(" ", "_")
					print("  |cffffff78"..key.."|r - "..(desc or name or ""))
				end
			end
		end
	end
end

local function keybindingValidateFunc(text)
	if text == nil or text == "NONE" then
		return nil
	end
	text = text:upper()
	local shift, ctrl, alt
	local modifier
	while true do
		if text == "-" then
			break
		end
		modifier, text = strsplit('-', text, 2)
		if text then
			if modifier ~= "SHIFT" and modifier ~= "CTRL" and modifier ~= "ALT" then
				return false
			end
			if modifier == "SHIFT" then
				if shift then
					return false
				end
				shift = true
			end
			if modifier == "CTRL" then
				if ctrl then
					return false
				end
				ctrl = true
			end
			if modifier == "ALT" then
				if alt then
					return false
				end
				alt = true
			end
		else
			text = modifier
			break
		end
	end
	if text == "" then
		return false
	end
	if not text:find("^F%d+$") and text ~= "CAPSLOCK" and text:len() ~= 1 and (text:byte() < 128 or text:len() > 4) and not _G["KEY_" .. text] then
		return false
	end
	local s = text
	if shift then
		s = "SHIFT-" .. s
	end
	if ctrl then
		s = "CTRL-" .. s
	end
	if alt then
		s = "ALT-" .. s
	end
	return s
end

local function handle(info, inputpos, tab, depth, retfalse)

	if not(type(tab)=="table" and type(tab.type)=="string") then err(info,inputpos) end

	local oldhandler,oldhandler_at = getparam(info,inputpos,tab,depth,"handler",handlertypes,handlermsg)
	local oldset,oldset_at = getparam(info,inputpos,tab,depth,"set",functypes,funcmsg)
	local oldget,oldget_at = getparam(info,inputpos,tab,depth,"get",functypes,funcmsg)
	local oldfunc,oldfunc_at = getparam(info,inputpos,tab,depth,"func",functypes,funcmsg)
	local oldvalidate,oldvalidate_at = getparam(info,inputpos,tab,depth,"validate",functypes,funcmsg)

	if tab.type=="group" then

		if type(tab.args)~="table" then err(info, inputpos) end
		if tab.plugins and type(tab.plugins)~="table" then err(info,inputpos) end

		local _,nextpos,arg = (info.input):find(" *([^ ]+) *", inputpos)
		if not arg then
			showhelp(info, inputpos, tab, depth)
			return
		end
		nextpos=nextpos+1

		for k,v in iterateargs(tab) do
			if not(type(k)=="string" and type(v)=="table" and type(v.type)=="string") then err(info,inputpos, "options table child '"..tostring(k).."' is malformed") end

			if v.type=="group" and pickfirstset(v.cmdInline, v.inline, false) then
				info[depth+1] = k
				if handle(info, inputpos, v, depth+1, true)==false then
					info[depth+1] = nil

				else
					return
				end

			elseif strlower(arg)==strlower(k:gsub(" ", "_")) then
				info[depth+1] = k
				return handle(info,nextpos,v,depth+1)
			end
		end

		if retfalse then

			info.handler,info.handler_at = oldhandler,oldhandler_at
			info.set,info.set_at = oldset,oldset_at
			info.get,info.get_at = oldget,oldget_at
			info.func,info.func_at = oldfunc,oldfunc_at
			info.validate,info.validate_at = oldvalidate,oldvalidate_at

			return false
		end

		usererr(info, inputpos, "'"..arg.."' - " .. L["unknown argument"])
		return
	end

	local strInput = strsub(info.input,inputpos);

	if tab.type=="execute" then

		do_final(info, inputpos, tab, "func")

	elseif tab.type=="input" then

		local res = true
		if tab.pattern then
			if type(tab.pattern)~="string" then err(info, inputpos, "'pattern' - expected a string") end
			if not strmatch(strInput, tab.pattern) then
				usererr(info, inputpos, "'"..strInput.."' - " .. L["invalid input"])
				return
			end
		end

		do_final(info, inputpos, tab, "set", strInput)

	elseif tab.type=="toggle" then

		local b
		local str = strtrim(strlower(strInput))
		if str=="" then
			b = callmethod(info, inputpos, tab, "get")

			if tab.tristate then

				if b then
					b = nil
				elseif b == nil then
					b = false
				else
					b = true
				end
			else
				b = not b
			end

		elseif str==L["on"] then
			b = true
		elseif str==L["off"] then
			b = false
		elseif tab.tristate and str==L["default"] then
			b = nil
		else
			if tab.tristate then
				usererr(info, inputpos, format(L["'%s' - expected 'on', 'off' or 'default', or no argument to toggle."], str))
			else
				usererr(info, inputpos, format(L["'%s' - expected 'on' or 'off', or no argument to toggle."], str))
			end
			return
		end

		do_final(info, inputpos, tab, "set", b)

	elseif tab.type=="range" then

		local val = tonumber(strInput)
		if not val then
			usererr(info, inputpos, "'"..strInput.."' - "..L["expected number"])
			return
		end
		if type(info.step)=="number" then
			val = val- (val % info.step)
		end
		if type(info.min)=="number" and val<info.min then
			usererr(info, inputpos, val.." - "..format(L["must be equal to or higher than %s"], tostring(info.min)) )
			return
		end
		if type(info.max)=="number" and val>info.max then
			usererr(info, inputpos, val.." - "..format(L["must be equal to or lower than %s"], tostring(info.max)) )
			return
		end

		do_final(info, inputpos, tab, "set", val)

	elseif tab.type=="select" then

		local str = strtrim(strlower(strInput))

		local values = tab.values
		if type(values) == "function" or type(values) == "string" then
			info.values = values
			values = callmethod(info, inputpos, tab, "values")
			info.values = nil
		end

		if str == "" then
			local b = callmethod(info, inputpos, tab, "get")
			local fmt = "|cffffff78- [%s]|r %s"
			local fmt_sel = "|cffffff78- [%s]|r %s |cffff0000*|r"
			print(L["Options for |cffffff78"..info[#info].."|r:"])
			for k, v in pairs(values) do
				if b == k then
					print(fmt_sel:format(k, v))
				else
					print(fmt:format(k, v))
				end
			end
			return
		end

		local ok
		for k,v in pairs(values) do
			if strlower(k)==str then
				str = k
				ok = true
				break
			end
		end
		if not ok then
			usererr(info, inputpos, "'"..str.."' - "..L["unknown selection"])
			return
		end

		do_final(info, inputpos, tab, "set", str)

	elseif tab.type=="multiselect" then

		local str = strtrim(strlower(strInput))

		local values = tab.values
		if type(values) == "function" or type(values) == "string" then
			info.values = values
			values = callmethod(info, inputpos, tab, "values")
			info.values = nil
		end

		if str == "" then
			local fmt = "|cffffff78- [%s]|r %s"
			local fmt_sel = "|cffffff78- [%s]|r %s |cffff0000*|r"
			print(L["Options for |cffffff78"..info[#info].."|r (multiple possible):"])
			for k, v in pairs(values) do
				if callmethod(info, inputpos, tab, "get", k) then
					print(fmt_sel:format(k, v))
				else
					print(fmt:format(k, v))
				end
			end
			return
		end

		local sels = {}
		for v in str:gmatch("[^ ]+") do

			local opt, val = v:match('(.+)=(.+)')

			if not opt then
				opt = v
			end

			local ok
			for k in pairs(values) do
				if strlower(k)==opt then
					opt = k
					ok = true
					break
				end
			end

			if not ok then
				usererr(info, inputpos, "'"..opt.."' - "..L["unknown selection"])
				return
			end

			if val then
				if val == L["on"] or val == L["off"] or (tab.tristate and val == L["default"]) then

					sels[opt] = val
				else
					if tab.tristate then
						usererr(info, inputpos, format(L["'%s' '%s' - expected 'on', 'off' or 'default', or no argument to toggle."], v, val))
					else
						usererr(info, inputpos, format(L["'%s' '%s' - expected 'on' or 'off', or no argument to toggle."], v, val))
					end
					return
				end
			else

				sels[opt] = true
			end
		end

		for opt, val in pairs(sels) do
			local newval

			if (val == true) then

				local b = callmethod(info, inputpos, tab, "get", opt)

				if tab.tristate then

					if b then
						b = nil
					elseif b == nil then
						b = false
					else
						b = true
					end
				else
					b = not b
				end
				newval = b
			else

				if val==L["on"] then
					newval = true
				elseif val==L["off"] then
					newval = false
				elseif val==L["default"] then
					newval = nil
				end
			end

			do_final(info, inputpos, tab, "set", opt, newval)
		end

	elseif tab.type=="color" then

		local str = strtrim(strlower(strInput))
		if str == "" then

			return
		end

		local r, g, b, a

		local hasAlpha = tab.hasAlpha
		if type(hasAlpha) == "function" or type(hasAlpha) == "string" then
			info.hasAlpha = hasAlpha
			hasAlpha = callmethod(info, inputpos, tab, 'hasAlpha')
			info.hasAlpha = nil
		end

		if hasAlpha then
			if str:len() == 8 and str:find("^%x*$")  then

				r,g,b,a = tonumber(str:sub(1, 2), 16) / 255, tonumber(str:sub(3, 4), 16) / 255, tonumber(str:sub(5, 6), 16) / 255, tonumber(str:sub(7, 8), 16) / 255
			else

				r,g,b,a = str:match("^([%d%.]+) ([%d%.]+) ([%d%.]+) ([%d%.]+)$")
				r,g,b,a = tonumber(r), tonumber(g), tonumber(b), tonumber(a)
			end
			if not (r and g and b and a) then
				usererr(info, inputpos, format(L["'%s' - expected 'RRGGBBAA' or 'r g b a'."], str))
				return
			end

			if r >= 0.0 and r <= 1.0 and g >= 0.0 and g <= 1.0 and b >= 0.0 and b <= 1.0 and a >= 0.0 and a <= 1.0 then

			elseif r >= 0 and r <= 255 and g >= 0 and g <= 255 and b >= 0 and b <= 255 and a >= 0 and a <= 255 then

				r = r / 255
				g = g / 255
				b = b / 255
				a = a / 255
			else

				usererr(info, inputpos, format(L["'%s' - values must all be either in the range 0..1 or 0..255."], str))
			end
		else
			a = 1.0
			if str:len() == 6 and str:find("^%x*$") then

				r,g,b = tonumber(str:sub(1, 2), 16) / 255, tonumber(str:sub(3, 4), 16) / 255, tonumber(str:sub(5, 6), 16) / 255
			else

				r,g,b = str:match("^([%d%.]+) ([%d%.]+) ([%d%.]+)$")
				r,g,b = tonumber(r), tonumber(g), tonumber(b)
			end
			if not (r and g and b) then
				usererr(info, inputpos, format(L["'%s' - expected 'RRGGBB' or 'r g b'."], str))
				return
			end
			if r >= 0.0 and r <= 1.0 and g >= 0.0 and g <= 1.0 and b >= 0.0 and b <= 1.0 then

			elseif r >= 0 and r <= 255 and g >= 0 and g <= 255 and b >= 0 and b <= 255 then

				r = r / 255
				g = g / 255
				b = b / 255
			else

				usererr(info, inputpos, format(L["'%s' - values must all be either in the range 0-1 or 0-255."], str))
			end
		end

		do_final(info, inputpos, tab, "set", r,g,b,a)

	elseif tab.type=="keybinding" then

		local str = strtrim(strlower(strInput))
		if str == "" then

			return
		end
		local value = keybindingValidateFunc(str:upper())
		if value == false then
			usererr(info, inputpos, format(L["'%s' - Invalid Keybinding."], str))
			return
		end

		do_final(info, inputpos, tab, "set", value)

	elseif tab.type=="description" then

	else
		err(info, inputpos, "unknown options table item type '"..tostring(tab.type).."'")
	end
end

function AceConfigCmd:HandleCommand(slashcmd, appName, input)

	local optgetter = cfgreg:GetOptionsTable(appName)
	if not optgetter then
		error([[Usage: HandleCommand("slashcmd", "appName", "input"): 'appName' - no options table "]]..tostring(appName)..[[" has been registered]], 2)
	end
	local options = assert( optgetter("cmd", MAJOR) )

	local info = {
		[0] = slashcmd,
		appName = appName,
		options = options,
		input = input,
		self = self,
		handler = self,
		uiType = "cmd",
		uiName = MAJOR,
	}

	handle(info, 1, options, 0)
end

function AceConfigCmd:CreateChatCommand(slashcmd, appName)
	if not AceConsole then
		AceConsole = LibStub(AceConsoleName)
	end
	if AceConsole.RegisterChatCommand(self, slashcmd, function(input)
				AceConfigCmd.HandleCommand(self, slashcmd, appName, input)
		end,
	true) then
		commands[slashcmd] = appName
	end
end

function AceConfigCmd:GetChatCommandOptions(slashcmd)
	return commands[slashcmd]
end
