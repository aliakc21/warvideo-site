-- =========================================================================
-- ENRAGE: ADDON PROFILE SWITCHER
-- =========================================================================

local ENRAGE_AP_FLAT_TEX = "Interface\\Buttons\\WHITE8X8"
local ENRAGE_AP_PANEL_INSET_X = 12
local ENRAGE_AP_PANEL_ATTACH_Y = 0
local ENRAGE_AP_SELF_ADDONS = {
    enrageplus = true,
}

local PROFILE_ORDER = { "pvp", "dungeon", "raid" }
local PROFILE_INFO = {
    pvp = {
        label = "PvP",
        long = "PvP",
        color = { 0.95, 0.28, 0.24 },
        targetText = "PvP content",
    },
    dungeon = {
        label = "Dungeon",
        long = "Dungeon",
        color = { 0.36, 0.66, 1.00 },
        targetText = "dungeon",
    },
    raid = {
        label = "Raid",
        long = "Raid",
        color = { 0.58, 0.88, 0.42 },
        targetText = "raid",
    },
}

local EnrageAddonProfiles = {
    buttons = {},
    addonListReady = false,
    lastAlertKey = nil,
    ignoredAlertKey = nil,
}

_G.EnrageAddonProfiles = EnrageAddonProfiles

local function AP_Print(text)
    print("|cffFFD34D[AkcQOL Profiles]|r " .. tostring(text or ""))
end

local function AP_Trim(text)
    text = tostring(text or "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    return text
end

local function AP_Lower(text)
    return string.lower(AP_Trim(text or ""))
end

local function AP_PlayerName()
    return (UnitName and UnitName("player")) or nil
end

local function AP_GetNumAddOns()
    if C_AddOns and C_AddOns.GetNumAddOns then
        local ok, count = pcall(C_AddOns.GetNumAddOns)
        if ok and tonumber(count) then return tonumber(count) end
    end
    if GetNumAddOns then
        local ok, count = pcall(GetNumAddOns)
        if ok and tonumber(count) then return tonumber(count) end
    end
    return 0
end

local function AP_GetAddOnInfo(indexOrName)
    if C_AddOns and C_AddOns.GetAddOnInfo then
        local ok, name, title, notes, loadable, reason, security, newVersion = pcall(C_AddOns.GetAddOnInfo, indexOrName)
        if ok then return name, title, notes, loadable, reason, security, newVersion end
    end
    if GetAddOnInfo then
        local ok, name, title, notes, loadable, reason, security, newVersion = pcall(GetAddOnInfo, indexOrName)
        if ok then return name, title, notes, loadable, reason, security, newVersion end
    end
    return nil
end

local function AP_ForEachAddOn(callback)
    local count = AP_GetNumAddOns()
    for i = 1, count do
        local name, title, notes, loadable, reason = AP_GetAddOnInfo(i)
        if name and name ~= "" then
            callback(name, title or name, notes, loadable, reason, i)
        end
    end
end

local function AP_IsSelfAddon(name)
    return ENRAGE_AP_SELF_ADDONS[AP_Lower(name)] == true
end

local function AP_GetEnableState(name)
    local player = AP_PlayerName()
    local attempts = {}
    if C_AddOns and C_AddOns.GetAddOnEnableState then
        attempts[#attempts + 1] = { C_AddOns.GetAddOnEnableState, name, player }
        attempts[#attempts + 1] = { C_AddOns.GetAddOnEnableState, name, nil }
        attempts[#attempts + 1] = { C_AddOns.GetAddOnEnableState, nil, name }
        attempts[#attempts + 1] = { C_AddOns.GetAddOnEnableState, name }
    end
    if GetAddOnEnableState then
        attempts[#attempts + 1] = { GetAddOnEnableState, player, name }
        attempts[#attempts + 1] = { GetAddOnEnableState, nil, name }
        attempts[#attempts + 1] = { GetAddOnEnableState, name, player }
        attempts[#attempts + 1] = { GetAddOnEnableState, name }
    end

    for _, attempt in ipairs(attempts) do
        local fn = attempt[1]
        local ok, state = pcall(fn, attempt[2], attempt[3])
        if ok and state ~= nil then
            return tonumber(state) or (state and 2 or 0)
        end
    end
    return 0
end

local function AP_IsAddOnEnabled(name)
    local state = AP_GetEnableState(name)
    return state and state > 0
end

local function AP_SetAddOnEnabled(name, enabled)
    if not name or name == "" then return false end
    if AP_IsSelfAddon(name) then enabled = true end

    local player = AP_PlayerName()
    local attempts = {}
    if C_AddOns then
        local fn = enabled and C_AddOns.EnableAddOn or C_AddOns.DisableAddOn
        if fn then
            attempts[#attempts + 1] = { fn, name, player }
            attempts[#attempts + 1] = { fn, player, name }
            attempts[#attempts + 1] = { fn, name }
        end
    end
    local globalFn = enabled and EnableAddOn or DisableAddOn
    if globalFn then
        attempts[#attempts + 1] = { globalFn, name, player }
        attempts[#attempts + 1] = { globalFn, player, name }
        attempts[#attempts + 1] = { globalFn, name }
    end

    for _, attempt in ipairs(attempts) do
        local ok = pcall(attempt[1], attempt[2], attempt[3])
        if ok then return true end
    end
    return false
end

local function AP_AddOnExists(name)
    if not name or name == "" then return false end
    local addonName = AP_GetAddOnInfo(name)
    if addonName ~= nil then return true end
    local wanted = AP_Lower(name)
    local exists = false
    AP_ForEachAddOn(function(addonNameFromList)
        if AP_Lower(addonNameFromList) == wanted then
            exists = true
        end
    end)
    return exists
end

local function AP_SnapshotCurrent()
    local snapshot = {}
    AP_ForEachAddOn(function(name)
        snapshot[name] = AP_IsAddOnEnabled(name) and true or false
        if AP_IsSelfAddon(name) then
            snapshot[name] = true
        end
    end)
    return snapshot
end

local function AP_SetMatches(addons, enabled, ...)
    local patterns = { ... }
    AP_ForEachAddOn(function(name, title)
        local hay = AP_Lower((name or "") .. " " .. (title or ""))
        for _, pattern in ipairs(patterns) do
            if hay:find(AP_Lower(pattern), 1, true) then
                addons[name] = enabled and true or false
                break
            end
        end
    end)
end

local function AP_RecommendedProfile(profileKey)
    local addons = AP_SnapshotCurrent()

    AP_SetMatches(addons, true, "enrageplus")

    if profileKey == "pvp" then
        AP_SetMatches(addons, false,
            "auctionator",
            "rclootcouncil",
            "raider.io",
            "raiderio",
            "premade groups filter",
            "myu's knowledge",
            "myusknowledge",
            "zygor"
        )
        AP_SetMatches(addons, true,
            "simple assisted combat",
            "simpleassistedcombat",
            "talent tree tweaks",
            "buggrabber",
            "bugsack",
            "enrage - raid cd",
            "enrage"
        )
    elseif profileKey == "dungeon" then
        AP_SetMatches(addons, false,
            "auctionator",
            "myu's knowledge",
            "myusknowledge",
            "zygor"
        )
        AP_SetMatches(addons, true,
            "premade groups filter",
            "raider.io mythic plus",
            "raiderio mythic plus",
            "raiderio_db_eu_m",
            "simple assisted combat",
            "talent tree tweaks",
            "buggrabber",
            "bugsack",
            "enrageplus"
        )
    elseif profileKey == "raid" then
        AP_SetMatches(addons, false,
            "auctionator",
            "premade groups filter",
            "myu's knowledge",
            "myusknowledge",
            "zygor"
        )
        AP_SetMatches(addons, true,
            "rclootcouncil",
            "raider.io raiding",
            "raiderio raiding",
            "raiderio_db_eu_r",
            "simple assisted combat",
            "talent tree tweaks",
            "buggrabber",
            "bugsack",
            "enrage - raid cd",
            "enrage"
        )
    end

    AP_ForEachAddOn(function(name)
        if AP_IsSelfAddon(name) then
            addons[name] = true
        end
    end)

    return addons
end

local function AP_EnsureDB()
    if type(EnrageDB) ~= "table" then EnrageDB = {} end
    if type(EnrageDB.global) ~= "table" then EnrageDB.global = {} end
    if type(EnrageDB.global.addonProfiles) ~= "table" then
        EnrageDB.global.addonProfiles = {}
    end

    local db = EnrageDB.global.addonProfiles
    if type(db.profiles) ~= "table" then db.profiles = {} end
    if type(db.customOrder) ~= "table" then db.customOrder = {} end

    db.profiles.pve = nil
    if db.activeProfile == "pve" then
        db.activeProfile = "raid"
    end

    for _, key in ipairs(PROFILE_ORDER) do
        if type(db.profiles[key]) ~= "table" then db.profiles[key] = {} end
        db.profiles[key].label = PROFILE_INFO[key].label
        db.profiles[key].builtIn = true
        db.profiles[key].custom = nil
        if type(db.profiles[key].addons) ~= "table" then
            db.profiles[key].addons = AP_RecommendedProfile(key)
            db.profiles[key].seeded = true
        end
    end

    local cleanedCustomOrder, seen = {}, {}
    for _, key in ipairs(db.customOrder) do
        local profile = db.profiles[key]
        if type(key) == "string" and type(profile) == "table" and not PROFILE_INFO[key] and not seen[key] then
            profile.custom = true
            profile.builtIn = nil
            if type(profile.label) ~= "string" or profile.label == "" then
                profile.label = key
            end
            if type(profile.addons) ~= "table" then
                profile.addons = AP_SnapshotCurrent()
            end
            cleanedCustomOrder[#cleanedCustomOrder + 1] = key
            seen[key] = true
        end
    end
    db.customOrder = cleanedCustomOrder

    -- A fresh installation starts unselected. Profiles remain available, but
    -- EnragePlus will not assume a mode, change addons, or show mismatch
    -- warnings until the user explicitly applies a profile.
    if db.activeProfile == nil then
        db.activeProfile = false
    end
    return db
end

local function AP_IsBuiltInProfile(profileKey)
    return PROFILE_INFO[profileKey] ~= nil
end

local function AP_GetProfile(profileKey)
    local db = EnrageDB and EnrageDB.global and EnrageDB.global.addonProfiles
    return db and db.profiles and db.profiles[profileKey] or nil
end

local function AP_ProfileExists(profileKey)
    if AP_IsBuiltInProfile(profileKey) then return true end
    return type(AP_GetProfile(profileKey)) == "table"
end

local function AP_ProfileLabel(profileKey)
    local info = PROFILE_INFO[profileKey]
    if info then return info.long end
    local profile = AP_GetProfile(profileKey)
    if type(profile) == "table" and profile.label and profile.label ~= "" then
        return tostring(profile.label)
    end
    return tostring(profileKey or "Unknown")
end

local function AP_ProfileColor(profileKey)
    local info = PROFILE_INFO[profileKey]
    if info then return info.color end
    local profile = AP_GetProfile(profileKey)
    if type(profile) == "table" and type(profile.color) == "table" then
        return profile.color
    end
    return { 0.74, 0.76, 0.82 }
end

local function AP_ColorText(profileKey, text)
    local c = AP_ProfileColor(profileKey)
    return string.format("|cff%02x%02x%02x%s|r", math.floor(c[1] * 255), math.floor(c[2] * 255), math.floor(c[3] * 255), tostring(text or ""))
end

local function AP_SetButtonText(button, text)
    if not button then return end
    if button.enrageText then
        button.enrageText:SetText(tostring(text or ""))
    elseif button.SetText then
        button:SetText(tostring(text or ""))
    elseif button.text then
        button.text:SetText(tostring(text or ""))
    end
end

local function AP_GetButtonFontString(button)
    if not button then return nil end
    return (button.GetFontString and button:GetFontString()) or button.Text or button.text or button.enrageText
end

local function AP_ButtonText(button)
    local fs = AP_GetButtonFontString(button)
    return fs and fs.GetText and tostring(fs:GetText() or "") or ""
end

local function AP_GetNativeAddonButtonMetrics(addonList)
    local defaultFace, defaultSize, defaultFlags = "Fonts\\FRIZQT__.TTF", 14, "OUTLINE"
    if GameFontNormalLarge and GameFontNormalLarge.GetFont then
        local face, size, flags = GameFontNormalLarge:GetFont()
        defaultFace, defaultSize, defaultFlags = face or defaultFace, size or defaultSize, flags or defaultFlags
    end

    local metrics = {
        width = 120,
        height = 24,
        fontFace = defaultFace,
        fontSize = defaultSize,
        fontFlags = defaultFlags,
    }

    local function Capture(button)
        if not button or not button.GetWidth or not button.GetHeight then return false end
        local width = tonumber(button:GetWidth()) or 0
        local height = tonumber(button:GetHeight()) or 0
        if width < 60 or height < 18 then return false end

        metrics.width = math.floor(width + 0.5)
        metrics.height = math.floor(height + 0.5)

        local fs = AP_GetButtonFontString(button)
        if fs and fs.GetFont then
            local face, size, flags = fs:GetFont()
            metrics.fontFace = face or metrics.fontFace
            metrics.fontSize = size or metrics.fontSize
            metrics.fontFlags = flags or metrics.fontFlags
        end
        return true
    end

    if addonList then
        for _, key in ipairs({ "EnableAllButton", "DisableAllButton", "enableAllButton", "disableAllButton", "EnableAll", "DisableAll" }) do
            if Capture(addonList[key]) then return metrics end
        end
    end

    for _, name in ipairs({ "AddonListEnableAllButton", "AddonListDisableAllButton", "AddOnListEnableAllButton", "AddOnListDisableAllButton" }) do
        if Capture(_G[name]) then return metrics end
    end

    if addonList and addonList.GetChildren then
        local children = { addonList:GetChildren() }
        for _, child in ipairs(children) do
            local text = AP_ButtonText(child)
            if text ~= "" and (text == "Enable All" or text == "Disable All" or text == (ENABLE_ALL or "") or text == (DISABLE_ALL or "")) then
                if Capture(child) then return metrics end
            end
        end
    end

    return metrics
end

local function AP_ApplyButtonMetrics(button, metrics)
    if not button or not metrics then return end
    local fs = AP_GetButtonFontString(button)
    if fs and fs.SetFont and metrics.fontFace then
        fs:SetFont(metrics.fontFace, metrics.fontSize or 14, metrics.fontFlags or "")
    end
end

function EnrageAddonProfiles:SaveProfile(profileKey)
    if not AP_ProfileExists(profileKey) then return false end
    local db = AP_EnsureDB()
    if type(db.profiles[profileKey]) ~= "table" then return false end
    db.profiles[profileKey].addons = AP_SnapshotCurrent()
    db.profiles[profileKey].updatedAt = date and date("%Y-%m-%d %H:%M:%S") or nil
    AP_Print(AP_ProfileLabel(profileKey) .. " profile saved from current enabled addons.")
    self:RefreshButtons()
    return true
end

function EnrageAddonProfiles:ApplyProfile(profileKey, reload)
    if not AP_ProfileExists(profileKey) then return false end
    local db = AP_EnsureDB()
    local profile = db.profiles[profileKey]
    if type(profile) ~= "table" or type(profile.addons) ~= "table" then
        if AP_IsBuiltInProfile(profileKey) then
            profile.addons = AP_RecommendedProfile(profileKey)
        else
            return false
        end
    end

    local changed = 0
    for addonName, enabled in pairs(profile.addons) do
        if AP_AddOnExists(addonName) then
            local desired = enabled and true or false
            if AP_IsSelfAddon(addonName) then desired = true end
            if AP_IsAddOnEnabled(addonName) ~= desired then
                if AP_SetAddOnEnabled(addonName, desired) then
                    changed = changed + 1
                end
            else
                AP_SetAddOnEnabled(addonName, desired)
            end
        end
    end

    AP_ForEachAddOn(function(name)
        if AP_IsSelfAddon(name) then
            AP_SetAddOnEnabled(name, true)
        end
    end)

    db.activeProfile = profileKey
    db.lastAppliedAt = date and date("%Y-%m-%d %H:%M:%S") or nil
    self.lastAlertKey = nil
    self.ignoredAlertKey = nil
    self:RefreshButtons()

    if reload then
        if InCombatLockdown and InCombatLockdown() then
            AP_Print(AP_ProfileLabel(profileKey) .. " profile prepared. Reload after combat ends.")
            self:ShowAlert(profileKey, "combat", true)
        else
            ReloadUI()
        end
    else
        AP_Print(AP_ProfileLabel(profileKey) .. " profile applied. Reload UI to activate addon changes.")
    end
    return true, changed
end

function EnrageAddonProfiles:GetActiveProfile()
    local db = AP_EnsureDB()
    if db.activeProfile and not AP_ProfileExists(db.activeProfile) then
        db.activeProfile = false
    end
    return db.activeProfile or nil
end

function EnrageAddonProfiles:GetProfileKeys()
    local db = AP_EnsureDB()
    local keys = {}
    for _, key in ipairs(PROFILE_ORDER) do
        keys[#keys + 1] = key
    end
    for _, key in ipairs(db.customOrder or {}) do
        if type(db.profiles[key]) == "table" then
            keys[#keys + 1] = key
        end
    end
    return keys
end

function EnrageAddonProfiles:FindProfileKey(text)
    text = AP_Lower(text or "")
    if text == "" then return nil end
    local db = AP_EnsureDB()
    if db.profiles[text] then return text end
    for key, profile in pairs(db.profiles) do
        if AP_Lower(key) == text or AP_Lower(profile.label or "") == text then
            return key
        end
    end
    return nil
end

function EnrageAddonProfiles:CreateCustomProfile(label)
    label = AP_Trim(label or "")
    if label == "" then
        AP_Print("Profile name cannot be empty.")
        return nil
    end

    local db = AP_EnsureDB()
    local base = "custom_" .. tostring((time and time()) or 1)
    local key = base
    local index = 1
    while db.profiles[key] do
        index = index + 1
        key = base .. "_" .. index
    end

    db.profiles[key] = {
        label = label,
        custom = true,
        addons = AP_SnapshotCurrent(),
        color = { 0.74, 0.76, 0.82 },
        createdAt = date and date("%Y-%m-%d %H:%M:%S") or nil,
    }
    db.customOrder[#db.customOrder + 1] = key
    db.activeProfile = key
    AP_Print(label .. " profile created from current enabled addons.")
    self:RebuildProfileButtons()
    self:RefreshButtons()
    return key
end

function EnrageAddonProfiles:DeleteProfile(profileKey)
    local db = AP_EnsureDB()
    if AP_IsBuiltInProfile(profileKey) then
        AP_Print(AP_ProfileLabel(profileKey) .. " is trigger-bound and cannot be deleted.")
        return false
    end
    if type(db.profiles[profileKey]) ~= "table" then return false end

    local label = AP_ProfileLabel(profileKey)
    db.profiles[profileKey] = nil
    for i = #db.customOrder, 1, -1 do
        if db.customOrder[i] == profileKey then
            table.remove(db.customOrder, i)
        end
    end
    if db.activeProfile == profileKey then
        db.activeProfile = false
    end
    AP_Print(label .. " profile deleted.")
    self:RebuildProfileButtons()
    self:RefreshButtons()
    return true
end

local function AP_GetPopupEditBox(popup)
    if not popup then return nil end
    return popup.editBox or popup.EditBox or (popup.GetName and _G[(popup:GetName() or "") .. "EditBox"]) or nil
end

StaticPopupDialogs["ENRAGE_ADDON_PROFILE_CREATE"] = {
    text = "New AkcQOL addon profile name:",
    button1 = ACCEPT or OKAY or "Okay",
    button2 = CANCEL or "Cancel",
    hasEditBox = true,
    maxLetters = 24,
    OnShow = function(self)
        local editBox = AP_GetPopupEditBox(self)
        if editBox then
            editBox:SetText("")
            editBox:SetFocus()
        end
    end,
    OnAccept = function(self)
        local editBox = AP_GetPopupEditBox(self)
        local label = editBox and editBox:GetText() or ""
        EnrageAddonProfiles:CreateCustomProfile(label)
    end,
    EditBoxOnEnterPressed = function(self)
        local parent = self:GetParent()
        if parent and parent.button1 then
            parent.button1:Click()
        end
    end,
    EditBoxOnEscapePressed = function(self)
        local parent = self:GetParent()
        if parent then parent:Hide() end
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

StaticPopupDialogs["ENRAGE_ADDON_PROFILE_DELETE"] = {
    text = "Delete custom addon profile '%s'?",
    button1 = DELETE or "Delete",
    button2 = CANCEL or "Cancel",
    OnAccept = function(_, profileKey)
        EnrageAddonProfiles:DeleteProfile(profileKey)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

function EnrageAddonProfiles:ShowCreatePopup()
    StaticPopup_Show("ENRAGE_ADDON_PROFILE_CREATE")
end

function EnrageAddonProfiles:ShowDeletePopup(profileKey)
    if AP_IsBuiltInProfile(profileKey) then
        AP_Print(AP_ProfileLabel(profileKey) .. " is trigger-bound and cannot be deleted.")
        return
    end
    StaticPopup_Show("ENRAGE_ADDON_PROFILE_DELETE", AP_ProfileLabel(profileKey), nil, profileKey)
end

function EnrageAddonProfiles:GetExpectedProfile()
    local inInstance, instanceType = IsInInstance()
    if not inInstance then return nil, instanceType end
    if instanceType == "arena" or instanceType == "pvp" then
        return "pvp", instanceType
    elseif instanceType == "party" then
        return "dungeon", instanceType
    elseif instanceType == "raid" then
        return "raid", instanceType
    end
    return nil, instanceType
end

local function AP_CreateFlatTexture(parent, layer)
    local texture = parent:CreateTexture(nil, layer or "ARTWORK")
    texture:SetTexture(ENRAGE_AP_FLAT_TEX)
    return texture
end

local function AP_CreateButton(parent, text, profileKey)
    local button = CreateFrame("Button", nil, parent, "UIPanelDynamicResizeButtonTemplate")
    button:SetSize(120, 24)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button.text = button.GetFontString and button:GetFontString() or nil
    AP_SetButtonText(button, text)
    button.profileKey = profileKey
    button.enrageBaseText = text
    button.isAddButton = profileKey == "__add"

    local delete = CreateFrame("Button", nil, button)
    delete:SetSize(16, 16)
    delete:SetPoint("RIGHT", button, "RIGHT", -5, 0)
    delete.text = delete:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    delete.text:SetPoint("CENTER", 0, 1)
    delete.text:SetText("|cFFFF5A4Ex|r")
    delete:SetScript("OnClick", function(self)
        local owner = self:GetParent()
        if owner and owner.profileKey then
            EnrageAddonProfiles:ShowDeletePopup(owner.profileKey)
        end
    end)
    delete:Hide()
    button.delete = delete

    button:SetScript("OnClick", function(self, mouseButton)
        if self.isAddButton then
            EnrageAddonProfiles:ShowCreatePopup()
        elseif mouseButton == "RightButton" and IsShiftKeyDown and IsShiftKeyDown() and not AP_IsBuiltInProfile(self.profileKey) then
            EnrageAddonProfiles:ShowDeletePopup(self.profileKey)
        elseif mouseButton == "RightButton" then
            EnrageAddonProfiles:SaveProfile(self.profileKey)
        else
            EnrageAddonProfiles:ApplyProfile(self.profileKey, true)
        end
    end)
    button:SetScript("OnEnter", function(self)
        EnrageAddonProfiles:PaintButton(self, true)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        if self.isAddButton then
            GameTooltip:SetText("Create custom profile", 1, 0.82, 0.2)
            GameTooltip:AddLine("Saves the current enabled addon set.", 0.86, 0.88, 0.94, true)
        else
            GameTooltip:SetText("AkcQOL " .. AP_ProfileLabel(self.profileKey) .. " Profile", 1, 0.82, 0.2)
            GameTooltip:AddLine("Left click: apply this addon set and reload.", 0.86, 0.88, 0.94, true)
            GameTooltip:AddLine("Right click: save current enabled addons into this set.", 0.55, 0.75, 1.0, true)
            if not AP_IsBuiltInProfile(self.profileKey) then
                GameTooltip:AddLine("Red x / Shift-right click: delete this custom profile.", 1.0, 0.45, 0.38, true)
            end
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function(self)
        EnrageAddonProfiles:PaintButton(self, false)
        GameTooltip:Hide()
    end)
    return button
end

function EnrageAddonProfiles:PaintButton(button, hover)
    if not button then return end
    local active = (not button.isAddButton) and self:GetActiveProfile() == button.profileKey

    if button.SetButtonState then
        if active then
            button:SetButtonState("PUSHED", true)
        else
            button:SetButtonState("NORMAL", false)
        end
    end

    local text = button.enrageOverrideText
        or (button.isAddButton and "+")
        or AP_ProfileLabel(button.profileKey)
        or button.enrageBaseText
        or ""
    AP_SetButtonText(button, text)

    local fontString = button.GetFontString and button:GetFontString() or button.text
    if fontString and fontString.SetTextColor then
        if active then
            local c = AP_ProfileColor(button.profileKey)
            fontString:SetTextColor(c[1] or 1, c[2] or 1, c[3] or 1, 1)
        elseif hover then
            fontString:SetTextColor(1.00, 0.90, 0.38, 1)
        else
            fontString:SetTextColor(1.00, 0.82, 0.20, 1)
        end
    end

    if button.delete then
        button.delete:SetShown((not button.isAddButton) and not AP_IsBuiltInProfile(button.profileKey))
    end
end

function EnrageAddonProfiles:LayoutAddonListButtons()
    local addonList = self:FindAddonListFrame()
    if not addonList or not self.container then return end

    self.container:ClearAllPoints()
    self.container:SetFrameLevel((addonList:GetFrameLevel() or 1) + 28)
    self.container:SetPoint("TOPLEFT", addonList, "BOTTOMLEFT", ENRAGE_AP_PANEL_INSET_X, ENRAGE_AP_PANEL_ATTACH_Y)
    self.container:SetPoint("TOPRIGHT", addonList, "BOTTOMRIGHT", -ENRAGE_AP_PANEL_INSET_X, ENRAGE_AP_PANEL_ATTACH_Y)

    local native = AP_GetNativeAddonButtonMetrics(addonList)
    local buttonW = math.max(100, math.min(220, native.width or 120))
    local buttonH = math.max(20, math.min(30, native.height or 24))
    local addButtonSize = math.max(22, math.min(buttonH, 26))
    local footerTopH, spacing = buttonH + 10, 14
    local leftPad = 18
    local rightPad = 18
    local availableW = math.max(260, (addonList:GetWidth() or 900) - (ENRAGE_AP_PANEL_INSET_X * 2))
    local mainW = buttonW
    local mainTotalW = (mainW * 3) + (spacing * 2)
    local reservedRight = addButtonSize + spacing
    if mainTotalW > (availableW - leftPad - rightPad - reservedRight) then
        mainW = math.max(84, math.floor((availableW - leftPad - rightPad - reservedRight - (spacing * 2)) / 3))
        mainTotalW = (mainW * 3) + (spacing * 2)
    end
    local mainX = math.floor(math.max(leftPad, ((availableW - reservedRight) - mainTotalW) / 2))
    local mainY = -math.floor((footerTopH - buttonH) / 2)

    for index, key in ipairs(PROFILE_ORDER) do
        local button = self.buttons[key]
        if button then
            button:ClearAllPoints()
            AP_ApplyButtonMetrics(button, native)
            button:SetSize(mainW, buttonH)
            button:SetPoint("TOPLEFT", self.container, "TOPLEFT", mainX + ((index - 1) * (mainW + spacing)), mainY)
            button:Show()
        end
    end

    if self.addButton then
        self.addButton:ClearAllPoints()
        AP_ApplyButtonMetrics(self.addButton, native)
        self.addButton:SetSize(addButtonSize, addButtonSize)
        self.addButton:SetPoint("TOPRIGHT", self.container, "TOPRIGHT", -rightPad, -math.floor((footerTopH - addButtonSize) / 2))
        self.addButton:Show()
    end

    for key, button in pairs(self.buttons) do
        if not AP_IsBuiltInProfile(key) then
            button:Hide()
        end
    end

    local db = AP_EnsureDB()
    local customKeys = {}
    for _, key in ipairs(db.customOrder or {}) do
        if self.buttons[key] then
            customKeys[#customKeys + 1] = key
        end
    end

    local rowGap = 6
    local customGap = spacing
    local maxX = availableW - leftPad
    local customW = buttonW
    local rowIndex = 0
    local cursorX = leftPad
    local function PlaceLowerButton(button, width)
        if not button then return end
        if cursorX + width > maxX and cursorX > leftPad then
            rowIndex = rowIndex + 1
            cursorX = leftPad
        end
        button:ClearAllPoints()
        AP_ApplyButtonMetrics(button, native)
        button:SetSize(width, buttonH)
        button:SetPoint("TOPLEFT", self.container, "TOPLEFT", cursorX, -(footerTopH + 5 + (rowIndex * (buttonH + rowGap))))
        button:Show()
        cursorX = cursorX + width + customGap
    end

    if #customKeys > 0 then
        for _, key in ipairs(customKeys) do
            PlaceLowerButton(self.buttons[key], customW)
        end
    end

    local lowerRows = #customKeys > 0 and (rowIndex + 1) or 0
    local lowerHeight = lowerRows > 0 and (5 + (lowerRows * buttonH) + ((lowerRows - 1) * rowGap) + 7) or 0
    self.container:SetHeight(footerTopH + lowerHeight)
end

function EnrageAddonProfiles:RefreshButtons()
    if not self.container then return end
    for _, button in pairs(self.buttons) do
        self:PaintButton(button, false)
    end
    if self.addButton then
        self:PaintButton(self.addButton, false)
    end
end

function EnrageAddonProfiles:RebuildProfileButtons()
    if not self.container then return end

    local wanted = {}
    for _, key in ipairs(self:GetProfileKeys()) do
        wanted[key] = true
        if not self.buttons[key] then
            self.buttons[key] = AP_CreateButton(self.container, AP_ProfileLabel(key), key)
        end
        self.buttons[key].profileKey = key
        self.buttons[key].isAddButton = false
        self.buttons[key].enrageOverrideText = nil
        self.buttons[key].enrageBaseText = AP_ProfileLabel(key)
        AP_SetButtonText(self.buttons[key], AP_ProfileLabel(key))
    end

    for key, button in pairs(self.buttons) do
        if not wanted[key] then
            button:Hide()
        end
    end

    if not self.addButton then
        self.addButton = AP_CreateButton(self.container, "+", "__add")
    end
    self.addButton.isAddButton = true
    self.addButton.profileKey = "__add"
    self.addButton.enrageOverrideText = "+"
    AP_SetButtonText(self.addButton, "+")

    self:LayoutAddonListButtons()
    self:RefreshButtons()
end

function EnrageAddonProfiles:FindAddonListFrame()
    return _G.AddonList or _G.AddOnList or _G.AddOnsList or _G.AddOnListFrame
end

function EnrageAddonProfiles:EnsureAddonListButtons()
    local addonList = self:FindAddonListFrame()
    if not addonList then return end

    if self.container and self.container:GetParent() == addonList then
        self.container:SetShown(addonList:IsShown())
        self:RebuildProfileButtons()
        return
    end

    local container = CreateFrame("Frame", nil, addonList, "BackdropTemplate")
    container:SetSize(392, 34)
    container:SetFrameLevel((addonList:GetFrameLevel() or 1) + 20)
    container:SetBackdrop({
        bgFile = ENRAGE_AP_FLAT_TEX,
        edgeFile = ENRAGE_AP_FLAT_TEX,
        edgeSize = 1,
    })
    container:SetBackdropColor(0.155, 0.145, 0.125, 0.96)
    container:SetBackdropBorderColor(0.40, 0.38, 0.34, 0.86)
    container:SetPoint("TOPLEFT", addonList, "BOTTOMLEFT", ENRAGE_AP_PANEL_INSET_X, ENRAGE_AP_PANEL_ATTACH_Y)
    container:SetPoint("TOPRIGHT", addonList, "BOTTOMRIGHT", -ENRAGE_AP_PANEL_INSET_X, ENRAGE_AP_PANEL_ATTACH_Y)

    container.footerTone = AP_CreateFlatTexture(container, "BACKGROUND")
    container.footerTone:SetPoint("TOPLEFT", container, "TOPLEFT", 1, -1)
    container.footerTone:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", -1, 1)
    container.footerTone:SetVertexColor(0.155, 0.145, 0.125, 0.96)

    container.seamCover = AP_CreateFlatTexture(container, "BORDER")
    container.seamCover:SetHeight(1)
    container.seamCover:SetPoint("TOPLEFT", container, "TOPLEFT", 1, 1)
    container.seamCover:SetPoint("TOPRIGHT", container, "TOPRIGHT", -1, 1)
    container.seamCover:SetVertexColor(0.40, 0.38, 0.34, 0.86)

    container.leftBorder = AP_CreateFlatTexture(container, "BORDER")
    container.leftBorder:SetWidth(1)
    container.leftBorder:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 1)
    container.leftBorder:SetPoint("BOTTOMLEFT", container, "BOTTOMLEFT", 0, 0)
    container.leftBorder:SetVertexColor(0.40, 0.38, 0.34, 0.86)

    container.rightBorder = AP_CreateFlatTexture(container, "BORDER")
    container.rightBorder:SetWidth(1)
    container.rightBorder:SetPoint("TOPRIGHT", container, "TOPRIGHT", 0, 1)
    container.rightBorder:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 0)
    container.rightBorder:SetVertexColor(0.40, 0.38, 0.34, 0.86)

    container.bottomBorder = AP_CreateFlatTexture(container, "BORDER")
    container.bottomBorder:SetHeight(1)
    container.bottomBorder:SetPoint("BOTTOMLEFT", container, "BOTTOMLEFT", 0, 0)
    container.bottomBorder:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 0)
    container.bottomBorder:SetVertexColor(0.40, 0.38, 0.34, 0.86)

    self.container = container

    local label = container:CreateFontString(nil, "OVERLAY")
    label:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE")
    label:SetPoint("TOPLEFT", container, "TOPLEFT", 0, -2)
    label:SetText("|cFFFFD34DAkcQOL Profiles|r")
    label:Hide()
    self.label = label

    self:RebuildProfileButtons()
    if addonList.HookScript then
        addonList:HookScript("OnShow", function()
            if EnrageAddonProfiles.container then
                EnrageAddonProfiles.container:Show()
            end
            EnrageAddonProfiles:RebuildProfileButtons()
        end)
        addonList:HookScript("OnHide", function()
            if EnrageAddonProfiles.container then
                EnrageAddonProfiles.container:Hide()
            end
        end)
    end
    self:RefreshButtons()
end

function EnrageAddonProfiles:EnsureAlertFrame()
    if self.alertFrame then return end

    local frame = CreateFrame("Frame", "EnrageAddonProfileAlert", UIParent, "BackdropTemplate")
    frame:SetSize(420, 118)
    frame:SetPoint("TOP", UIParent, "TOP", 0, -170)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:SetBackdrop({
        bgFile = ENRAGE_AP_FLAT_TEX,
        edgeFile = ENRAGE_AP_FLAT_TEX,
        edgeSize = 1,
    })
    frame:SetBackdropColor(0.025, 0.020, 0.016, 0.92)
    frame:SetBackdropBorderColor(1.0, 0.72, 0.18, 0.85)
    frame:Hide()
    self.alertFrame = frame

    local title = frame:CreateFontString(nil, "OVERLAY")
    title:SetFont("Fonts\\FRIZQT__.TTF", 15, "OUTLINE")
    title:SetPoint("TOP", frame, "TOP", 0, -12)
    title:SetText("|cFFFFD34DAddon Profile Warning|r")
    frame.title = title

    local close = CreateFrame("Button", nil, frame)
    close:SetSize(22, 22)
    close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -8)
    close:SetHitRectInsets(-2, -2, -2, -2)
    close.bg = close:CreateTexture(nil, "BACKGROUND")
    close.bg:SetTexture(ENRAGE_AP_FLAT_TEX)
    close.bg:SetAllPoints()
    close.bg:SetVertexColor(0.22, 0.05, 0.05, 0)
    close.text = close:CreateFontString(nil, "OVERLAY")
    close.text:SetFont("Fonts\\FRIZQT__.TTF", 13, "OUTLINE")
    close.text:SetAllPoints()
    close.text:SetJustifyH("CENTER")
    close.text:SetJustifyV("MIDDLE")
    close.text:SetTextColor(0.96, 0.34, 0.32, 1)
    close.text:SetText("X")
    close:SetScript("OnClick", function()
        EnrageAddonProfiles.ignoredAlertKey = EnrageAddonProfiles.lastAlertKey
        frame:Hide()
    end)
    close:SetScript("OnEnter", function(self)
        self.bg:SetVertexColor(0.34, 0.06, 0.06, 0.92)
        self.text:SetTextColor(1.00, 0.52, 0.48, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Close this warning", 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    close:SetScript("OnLeave", function(self)
        self.bg:SetVertexColor(0.22, 0.05, 0.05, 0)
        self.text:SetTextColor(0.96, 0.34, 0.32, 1)
        GameTooltip:Hide()
    end)
    frame.close = close

    local body = frame:CreateFontString(nil, "OVERLAY")
    body:SetFont("Fonts\\ARIALN.TTF", 12, "")
    body:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -40)
    body:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -18, -40)
    body:SetJustifyH("CENTER")
    body:SetTextColor(0.93, 0.94, 0.98, 1)
    frame.body = body

    local apply = AP_CreateButton(frame, "Reload", "raid")
    apply:SetSize(144, 26)
    apply:SetPoint("BOTTOM", frame, "BOTTOM", -74, 14)
    apply:SetScript("OnClick", function(self)
        EnrageAddonProfiles:ApplyProfile(self.targetProfile or "raid", true)
    end)
    apply:SetScript("OnEnter", function(self)
        EnrageAddonProfiles:PaintButton(self, true)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Apply and reload", 1, 0.82, 0.2)
        GameTooltip:Show()
    end)
    apply:SetScript("OnLeave", function(self)
        EnrageAddonProfiles:PaintButton(self, false)
        self.enrageOverrideText = AP_ProfileLabel(self.targetProfile or self.profileKey or "raid") .. " + Reload"
        AP_SetButtonText(self, self.enrageOverrideText)
        GameTooltip:Hide()
    end)
    frame.apply = apply

    local ignore = AP_CreateButton(frame, "Ignore", "raid")
    ignore:SetSize(104, 26)
    ignore:SetPoint("LEFT", apply, "RIGHT", 10, 0)
    ignore:SetScript("OnClick", function()
        EnrageAddonProfiles.ignoredAlertKey = EnrageAddonProfiles.lastAlertKey
        frame:Hide()
    end)
    ignore:SetScript("OnEnter", function(self)
        EnrageAddonProfiles:PaintButton(self, true)
    end)
    ignore:SetScript("OnLeave", function(self)
        self.enrageOverrideText = "Ignore"
        EnrageAddonProfiles:PaintButton(self, false)
    end)
    frame.ignore = ignore
end

function EnrageAddonProfiles:ShowAlert(targetProfile, instanceType, combatReload)
    if not targetProfile or not PROFILE_INFO[targetProfile] then return end
    self:EnsureAlertFrame()

    local active = self:GetActiveProfile()
    local alertKey = tostring(targetProfile) .. ":" .. tostring(instanceType or "") .. ":" .. tostring(active or "")
    self.lastAlertKey = alertKey
    if self.ignoredAlertKey == alertKey and not combatReload then return end

    local frame = self.alertFrame
    local c = AP_ProfileColor(targetProfile)
    frame:SetBackdropBorderColor(c[1], c[2], c[3], 0.92)
    frame.apply.profileKey = targetProfile
    frame.apply.targetProfile = targetProfile
    frame.apply.enrageOverrideText = AP_ProfileLabel(targetProfile) .. " + Reload"
    AP_SetButtonText(frame.apply, frame.apply.enrageOverrideText)
    frame.ignore.profileKey = targetProfile
    frame.ignore.enrageOverrideText = "Ignore"
    AP_SetButtonText(frame.ignore, "Ignore")

    if combatReload then
        frame.body:SetText("Profile prepared, but combat is blocking reload. Click after combat ends.")
    else
        frame.body:SetText(string.format("You are in %s, but addons are currently in %s mode.",
            AP_ColorText(targetProfile, PROFILE_INFO[targetProfile].targetText or AP_ProfileLabel(targetProfile)),
            AP_ColorText(active, AP_ProfileLabel(active))
        ))
    end
    frame:Show()
end

function EnrageAddonProfiles:CheckInstanceProfile(force)
    local target, instanceType = self:GetExpectedProfile()
    if not target then
        if self.alertFrame then self.alertFrame:Hide() end
        return
    end

    local active = self:GetActiveProfile()
    if not active then
        if self.alertFrame then self.alertFrame:Hide() end
        return
    end
    if active == target then
        if self.alertFrame then self.alertFrame:Hide() end
        return
    end

    local key = tostring(target) .. ":" .. tostring(instanceType or "") .. ":" .. tostring(active or "")
    if not force and (self.lastAlertKey == key or self.ignoredAlertKey == key) then return end
    self:ShowAlert(target, instanceType, false)
end

function EnrageAddonProfiles:HandleSlash(msg)
    msg = AP_Lower(msg or "")
    local command, rest = msg:match("^(%S+)%s*(.*)$")
    if command == "save" and rest ~= "" then
        self:SaveProfile(self:FindProfileKey(rest) or rest)
    elseif command == "new" or command == "create" then
        self:CreateCustomProfile(rest)
    elseif command == "delete" and rest ~= "" then
        self:ShowDeletePopup(self:FindProfileKey(rest) or rest)
    elseif AP_ProfileExists(command) then
        self:ApplyProfile(command, true)
    elseif command == "status" then
        local target = self:GetExpectedProfile()
        local active = self:GetActiveProfile()
        AP_Print("Active: " .. (active and AP_ProfileLabel(active) or "None")
            .. (target and (" | Expected: " .. AP_ProfileLabel(target)) or ""))
    else
        AP_Print("/enaddons pvp|dungeon|raid")
        AP_Print("/enaddons create <name>  |  /enaddons delete <name>")
        AP_Print("In AddOn List: left-click applies and reloads, right-click saves, + creates a custom profile.")
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
eventFrame:RegisterEvent("ZONE_CHANGED")
eventFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
eventFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        AP_EnsureDB()
        C_Timer.After(1, function()
            EnrageAddonProfiles:EnsureAddonListButtons()
            EnrageAddonProfiles:CheckInstanceProfile(true)
        end)
    elseif event == "ADDON_LOADED" then
        local loadedName = ...
        if loadedName == "Blizzard_AddOnList" or EnrageAddonProfiles:FindAddonListFrame() then
            C_Timer.After(0.2, function()
                EnrageAddonProfiles:EnsureAddonListButtons()
            end)
        end
    else
        C_Timer.After(2, function()
            EnrageAddonProfiles:CheckInstanceProfile(false)
        end)
    end
end)

SlashCmdList["ENRAGEADDONPROFILES"] = function(msg)
    EnrageAddonProfiles:HandleSlash(msg)
end
