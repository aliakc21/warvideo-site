-- =========================================================================
-- AkcQOL DYNAMIC FPS
-- Lowers a set of graphics-heavy CVars while you are inside an instance
-- (raid / dungeon / arena / battleground / scenario) and restores your normal
-- settings in the open world. Fully reversible and RELOAD-SAFE: the true
-- "high" values are captured once (on the high->low edge) and restored on the
-- low->high edge, and PLAYER_LOGOUT restores highs before WoW flushes CVars to
-- disk. So a /reload always writes your true highs (re-captured cleanly next
-- login), and a hard crash never flushes the low profile either -- you can never
-- be stranded on degraded graphics. The lowActive flag guards against ever
-- re-capturing low values as a baseline; mode/state live in EnrageDB (account-wide).
--
-- Verified against WoW 12.0 "Midnight" CVar data (warcraft.wiki.gg / live client
-- dumps). Only real, non-secure, live-applying raw CVars are touched. Excluded on
-- purpose: addonProfilerEnabled (myth -- forced on since 11.1.7), nameplate CVars
-- (hardcoded + combat-protected), projectedTextures (hides boss telegraphs),
-- graphicsQuality (master preset that stomps the snapshot).
--
-- Modes: "off" (default, does nothing), "auto" (low in instances), "on" (always
-- low). Control from Settings > Automation, or /fps off|on|auto|reset|status.
-- =========================================================================

local _, addon = ...

-- Raw, verified CVars swapped to their low values inside instances. Values that
-- already equal a user's setting are simply re-written (no-op); users on higher
-- presets get the real FPS win. Capture/restore keeps each user's own "high".
local LOW = {
    particleDensity           = "10",  -- 100 -> 10 : top instance lever
    shadowMode                = "0",   -- shadows off : big win
    SSAO                      = "0",   -- ambient occlusion off (uppercase CVar)
    waterDetail               = "0",   -- 3 -> 0
    reflectionMode            = "0",   -- reflections off
    reflectionDownscale       = "4",   -- low-res reflections
    sunShafts                 = "0",   -- 1 -> 0
    refraction                = "0",   -- 1 -> 0
    rippleDetail              = "0",   -- 2 -> 0
    physicsLevel              = "0",   -- cloth physics off
    weatherDensity            = "0",   -- no weather
    groundEffectDensity       = "16",  -- min grass density
    groundEffectDist          = "40",  -- short grass distance
    maxLightCount             = "4",   -- fewer dynamic lights (dense pulls)
    lodObjectCullDist         = "15",
    lodObjectCullSize         = "25",
    lodObjectMinSize          = "30",
    animFrameSkipLOD          = "1",   -- skip distant animation frames
    spellClutterMinSpellCount = "2",
}

-- ---- secret-safe CVar helpers (same shape as PIAlert.lua) ----
local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end
local function ReadCVar(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVar and C_CVar.GetCVar(name)) or (GetCVar and GetCVar(name))
        if v ~= nil and not IsSecret(v) then out = v end
    end)
    return out
end
local function WriteCVar(name, value)
    pcall(function()
        if C_CVar and C_CVar.SetCVar then C_CVar.SetCVar(name, tostring(value))
        elseif SetCVar then SetCVar(name, tostring(value)) end
    end)
end
local function DefaultCVar(name)
    local out
    pcall(function()
        local v = (C_CVar and C_CVar.GetCVarDefault and C_CVar.GetCVarDefault(name)) or (GetCVarDefault and GetCVarDefault(name))
        if v ~= nil and not IsSecret(v) then out = v end
    end)
    return out
end

-- ---- persisted state (survives /reload; account-wide) ----
local function DB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    local g = EnrageDB.global
    if type(g.dynFPS) ~= "table" then g.dynFPS = {} end
    local d = g.dynFPS
    if type(d.mode) ~= "string" then d.mode = "off" end -- fresh install = off (does nothing)
    if d.lowActive == nil then d.lowActive = false end
    return d
end

local pendingReconcile = false

-- Enter the low profile. Captures the true "high" values ONCE (never while a low
-- profile is already active), so a re-run after /reload can't snapshot low values.
local function GoLow()
    local d = DB()
    if d.lowActive then
        for cv, low in pairs(LOW) do WriteCVar(cv, low) end -- re-assert, no re-capture
        return
    end
    local saved = {}
    for cv, low in pairs(LOW) do
        local cur = ReadCVar(cv)
        if cur ~= nil then saved[cv] = cur end
        WriteCVar(cv, low)
    end
    d.saved = saved
    d.lowActive = true
end

-- Leave the low profile, restoring each captured "high" value (falling back to
-- the CVar's Blizzard default only if we somehow never captured it).
local function GoHigh()
    local d = DB()
    if not d.lowActive then return end
    for cv in pairs(LOW) do
        local v = d.saved and d.saved[cv]
        if v == nil then v = DefaultCVar(cv) end
        if v ~= nil then WriteCVar(cv, v) end
    end
    d.lowActive = false
    d.saved = nil
end

local function InLowZone()
    local inInstance, instanceType = IsInInstance()
    if not inInstance then return false end
    return instanceType == "raid" or instanceType == "party"
        or instanceType == "arena" or instanceType == "pvp"
        or instanceType == "scenario"
end

-- Decide the desired profile from mode + zone and apply it. Graphics writes are
-- deferred out of combat to avoid a mid-pull stutter (nothing here is actually
-- combat-protected, this is purely for smoothness).
local function Reconcile()
    local d = DB()
    local wantLow
    if d.mode == "off" then wantLow = false
    elseif d.mode == "on" then wantLow = true
    else wantLow = InLowZone() end

    if InCombatLockdown and InCombatLockdown() then
        pendingReconcile = true
        return
    end
    pendingReconcile = false
    if wantLow then GoLow() else GoHigh() end
end

-- Manual escape hatch: force everything back to the captured high values, or to
-- Blizzard defaults if there is no capture, and forget the low state.
local function ForceRestore()
    local d = DB()
    for cv in pairs(LOW) do
        local v = (d.saved and d.saved[cv]) or DefaultCVar(cv)
        if v ~= nil then WriteCVar(cv, v) end
    end
    d.lowActive = false
    d.saved = nil
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("ZONE_CHANGED_NEW_AREA")
f:RegisterEvent("PLAYER_REGEN_ENABLED")
f:RegisterEvent("PLAYER_LOGOUT")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGOUT" then
        -- Restore highs on the way out (covers /reload and logout) so the values
        -- flushed to disk are always the true highs -> next login re-captures clean.
        local d = DB()
        if d.lowActive then GoHigh() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if pendingReconcile then Reconcile() end
    else -- PLAYER_ENTERING_WORLD / ZONE_CHANGED_NEW_AREA
        Reconcile()
    end
end)

-- Public: called by the settings toggle whenever the mode changes.
function _G.Enrage_ApplyDynamicFPS()
    Reconcile()
end

local function Status()
    local d = DB()
    print("|cff8c5cffAkc|r|cffffffffQOL|r Dynamic FPS: mode=|cffffd100" .. d.mode
        .. "|r, low profile " .. (d.lowActive and "|cff00ff00ON|r" or "|cffff5555off|r"))
end

SLASH_AKCFPS1 = "/fps"
SlashCmdList["AKCFPS"] = function(msg)
    msg = (msg or ""):lower():gsub("%s+", "")
    local d = DB()
    if msg == "off" then
        d.mode = "off"; Reconcile(); print("|cff8c5cffAkcQOL|r Dynamic FPS: |cffff5555off|r (normal graphics)")
    elseif msg == "on" then
        d.mode = "on"; Reconcile(); print("|cff8c5cffAkcQOL|r Dynamic FPS: |cff00ff00always low|r")
    elseif msg == "auto" then
        d.mode = "auto"; Reconcile(); print("|cff8c5cffAkcQOL|r Dynamic FPS: |cff00ff00auto|r (low in instances)")
    elseif msg == "reset" then
        ForceRestore(); print("|cff8c5cffAkcQOL|r Dynamic FPS: graphics restored.")
    else
        Status()
        print("  |cffffd100/fps auto|r  |cffffd100/fps on|r  |cffffd100/fps off|r  |cffffd100/fps reset|r")
    end
    if LibStub then
        local reg = LibStub("AceConfigRegistry-3.0", true)
        if reg then pcall(reg.NotifyChange, reg, "EnrageRaidCD") end
    end
end
