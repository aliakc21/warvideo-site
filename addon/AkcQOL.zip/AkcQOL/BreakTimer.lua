-- =========================================================================
-- ENRAGE: BREAK TIMER SNIFFER
-- Receives DBM/BigWigs-compatible break timers for players without boss mods.
-- =========================================================================

local _, addon = ...

local PREFIX_TEXT = "|cFFFFD34D[Enrage Break]|r "
local MAX_SECONDS = 3600
local MIN_SECONDS = 1
local BREAK_TIMER_TOP_OFFSET = -105
local ACCEPTED_CHANNELS = {
    RAID = true,
    PARTY = true,
    INSTANCE_CHAT = true,
}

local breakFrame
local ticker
local activeEndTime
local activeDuration
local activeSender
local activeSource
local manuallyHiddenEndTime

local function Now()
    if GetServerTime then
        local ok, value = pcall(GetServerTime)
        if ok and tonumber(value) then return tonumber(value) end
    end
    return time()
end

local function Trim(text)
    text = tostring(text or "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    return text
end

local function StripRealm(name)
    name = Trim(name)
    name = name:gsub("|K.-|k", "")
    name = name:gsub("%s+", "")
    name = Ambiguate and Ambiguate(name, "none") or name
    name = name:match("^([^%-]+)") or name
    return string.lower(name)
end

local function EnsureDB()
    if type(EnrageRaidCDDB) ~= "table" then EnrageRaidCDDB = {} end
    if type(EnrageRaidCDDB.breakTimer) ~= "table" then
        EnrageRaidCDDB.breakTimer = {}
    end
    return EnrageRaidCDDB.breakTimer
end

local function ClearSaved()
    local db = EnsureDB()
    db.endTime = nil
    db.duration = nil
    db.sender = nil
    db.source = nil
    db.hiddenEndTime = nil
end

local function IsAddOnLoadedSafe(name)
    if not name or name == "" then return false end
    if C_AddOns and C_AddOns.IsAddOnLoaded then
        local ok, loaded = pcall(C_AddOns.IsAddOnLoaded, name)
        if ok and loaded then return true end
    end
    if IsAddOnLoaded then
        local ok, loaded = pcall(IsAddOnLoaded, name)
        if ok and loaded then return true end
    end
    return false
end

local function HasBossModTimer()
    if _G.DBM or _G.BigWigs then return true end
    return IsAddOnLoadedSafe("DBM-Core") or IsAddOnLoadedSafe("BigWigs")
end

local function IsSenderSelf(sender)
    local player = UnitName and UnitName("player") or nil
    if not player then return false end
    return StripRealm(sender) == StripRealm(player)
end

local function IsSenderTrusted(sender)
    if IsSenderSelf(sender) then return true end
    if not IsInGroup or not IsInGroup() then return false end

    local wanted = StripRealm(sender)
    if wanted == "" then return false end

    if IsInRaid and IsInRaid() then
        local count = GetNumGroupMembers and GetNumGroupMembers() or 0
        for i = 1, count do
            local name, rank = GetRaidRosterInfo(i)
            if name and StripRealm(name) == wanted then
                return (tonumber(rank) or 0) > 0
            end
        end
        return false
    end

    for i = 1, 4 do
        local unit = "party" .. i
        if UnitExists and UnitExists(unit) then
            local name = UnitName(unit)
            if name and StripRealm(name) == wanted then
                if UnitIsGroupLeader and UnitIsGroupLeader(unit) then return true end
                if UnitIsGroupAssistant and UnitIsGroupAssistant(unit) then return true end
                return false
            end
        end
    end

    return false
end

local function StopTicker()
    if ticker then
        ticker:Cancel()
        ticker = nil
    end
end

local function FormatRemaining(seconds)
    seconds = math.max(0, math.ceil(tonumber(seconds) or 0))
    local minutes = math.floor(seconds / 60)
    local remain = seconds % 60
    return string.format("%d:%02d", minutes, remain)
end

local function EnsureFrame()
    if breakFrame then return breakFrame end

    breakFrame = CreateFrame("Frame", "EnrageBreakTimerFrame", UIParent)
    breakFrame:SetSize(180, 44)
    breakFrame:SetPoint("TOP", UIParent, "TOP", 0, BREAK_TIMER_TOP_OFFSET)
    breakFrame:SetFrameStrata("DIALOG")
    breakFrame:SetFrameLevel(900)
    breakFrame:SetClampedToScreen(true)
    breakFrame:EnableMouse(false)

    local title = breakFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    title:SetPoint("TOP", 0, 0)
    title:SetText("|cFFFFD34DBreak|r")
    breakFrame.title = title

    local timeText = breakFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    timeText:SetPoint("TOP", title, "BOTTOM", 0, -1)
    timeText:SetTextColor(1.0, 1.0, 1.0, 1)
    timeText:SetText("0:00")
    breakFrame.timeText = timeText

    local close = CreateFrame("Button", nil, breakFrame)
    close:SetSize(16, 16)
    close:SetPoint("TOPRIGHT", breakFrame, "TOPRIGHT", 2, 2)
    close:EnableMouse(true)
    close:SetHitRectInsets(-4, -4, -4, -4)
    close.text = close:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    close.text:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
    close.text:SetAllPoints()
    close.text:SetJustifyH("CENTER")
    close.text:SetJustifyV("MIDDLE")
    close.text:SetTextColor(1.0, 0.34, 0.30, 0.72)
    close.text:SetText("x")
    close:SetScript("OnEnter", function(self)
        self.text:SetTextColor(1.0, 0.50, 0.45, 1)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Close break timer", 1.0, 0.82, 0.25)
        GameTooltip:Show()
    end)
    close:SetScript("OnLeave", function(self)
        self.text:SetTextColor(1.0, 0.34, 0.30, 0.72)
        GameTooltip:Hide()
    end)
    close:SetScript("OnClick", function()
        if activeEndTime then
            manuallyHiddenEndTime = activeEndTime
            local db = EnsureDB()
            db.hiddenEndTime = activeEndTime
        end
        breakFrame:Hide()
    end)
    breakFrame.close = close

    breakFrame:Hide()
    return breakFrame
end

local function PaintRemaining()
    if not activeEndTime then return end

    local remaining = activeEndTime - Now()
    if remaining <= 0 then
        StopTicker()
        ClearSaved()
        activeEndTime = nil
        activeDuration = nil
        activeSender = nil
        activeSource = nil
        manuallyHiddenEndTime = nil

        local f = EnsureFrame()
        f.title:SetText("|cFF9FFFE0Break over|r")
        f.timeText:SetText("0:00")
        f:Show()
        C_Timer.After(2, function()
            if not activeEndTime and breakFrame then
                breakFrame:Hide()
                breakFrame.title:SetText("|cFFFFD34DBreak|r")
            end
        end)
        return
    end

    if manuallyHiddenEndTime and activeEndTime == manuallyHiddenEndTime then
        if breakFrame then breakFrame:Hide() end
        return
    end

    local f = EnsureFrame()
    f.title:SetText("|cFFFFD34DBreak|r")
    f.timeText:SetText(FormatRemaining(remaining))
    f:Show()
end

local function SaveActive()
    local db = EnsureDB()
    db.endTime = activeEndTime
    db.duration = activeDuration
    db.sender = activeSender
    db.source = activeSource
    db.hiddenEndTime = manuallyHiddenEndTime
end

local function StartBreak(seconds, sender, source)
    seconds = math.floor(tonumber(seconds) or 0)
    if seconds < MIN_SECONDS then return end
    if seconds > MAX_SECONDS then seconds = MAX_SECONDS end
    if IsEncounterInProgress and IsEncounterInProgress() then return end

    activeDuration = seconds
    activeEndTime = Now() + seconds
    activeSender = sender
    activeSource = source
    manuallyHiddenEndTime = nil

    SaveActive()
    StopTicker()
    PaintRemaining()
    ticker = C_Timer.NewTicker(0.25, PaintRemaining)
end

local function CancelBreak()
    StopTicker()
    ClearSaved()
    activeEndTime = nil
    activeDuration = nil
    activeSender = nil
    activeSource = nil
    manuallyHiddenEndTime = nil
    if breakFrame then breakFrame:Hide() end
end

local function RestoreSaved()
    local db = EnsureDB()
    local endTime = tonumber(db.endTime)
    local duration = tonumber(db.duration)
    if not endTime or endTime <= Now() then
        ClearSaved()
        return
    end

    activeEndTime = endTime
    activeDuration = duration or math.max(MIN_SECONDS, endTime - Now())
    activeSender = db.sender
    activeSource = db.source or "Restored"
    manuallyHiddenEndTime = tonumber(db.hiddenEndTime) == endTime and endTime or nil
    StopTicker()
    PaintRemaining()
    ticker = C_Timer.NewTicker(0.25, PaintRemaining)
end

local function HandleBreakMessage(seconds, sender, source)
    seconds = tonumber(seconds)
    if not seconds then return end
    if seconds <= 0 then
        if IsSenderTrusted(sender) then
            CancelBreak()
        end
        return
    end
    if seconds > MAX_SECONDS then return end
    if not IsSenderTrusted(sender) then return end
    StartBreak(seconds, sender, source)
end

local function ParseD5(message, sender)
    local ok, _, _, subPrefix, seconds = pcall(strsplit, "\t", tostring(message or ""))
    if not ok or subPrefix ~= "BT" then return end
    HandleBreakMessage(seconds, sender, "DBM/BigWigs")
end

local function ParseBigWigs(message, sender)
    local ok, prefix, msg, seconds = pcall(strsplit, "^", tostring(message or ""))
    if not ok then return end
    if prefix == "P" and msg == "Break" then
        HandleBreakMessage(seconds, sender, "BigWigs")
    end
end

local function ParseBigBreak(message, sender)
    local ok, cmd, value = pcall(strsplit, "\t", tostring(message or ""))
    if not ok or not cmd then return end

    if cmd == "BREAK" then
        HandleBreakMessage(value, sender, "BigBreak")
    elseif cmd == "CANCEL" then
        if IsSenderTrusted(sender) then
            CancelBreak()
        end
    end
end

local function RegisterPrefixes()
    if not C_ChatInfo or not C_ChatInfo.RegisterAddonMessagePrefix then return end
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, "D5")
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, "BigWigs")
    pcall(C_ChatInfo.RegisterAddonMessagePrefix, "BigBreak")
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("ENCOUNTER_START")
events:RegisterEvent("GROUP_LEFT")
events:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        RegisterPrefixes()
        RestoreSaved()
        return
    end

    if event == "PLAYER_ENTERING_WORLD" then
        RestoreSaved()
        return
    end

    if event == "ENCOUNTER_START" or event == "GROUP_LEFT" then
        if activeEndTime then CancelBreak() end
        return
    end

    if event ~= "CHAT_MSG_ADDON" then return end
    local prefix, message, channel, sender = ...
    if not ACCEPTED_CHANNELS[channel] then return end
    if HasBossModTimer() then return end

    if prefix == "D5" then
        ParseD5(message, sender)
    elseif prefix == "BigWigs" then
        ParseBigWigs(message, sender)
    elseif prefix == "BigBreak" then
        ParseBigBreak(message, sender)
    end
end)

SLASH_ENRAGEBREAK1 = "/enbreak"
SlashCmdList.ENRAGEBREAK = function(msg)
    msg = string.lower(Trim(msg or ""))
    if msg == "off" or msg == "cancel" or msg == "0" then
        CancelBreak()
        return
    end

    local seconds = tonumber(msg)
    if msg == "" or msg == "test" then seconds = 30 end
    if not seconds or seconds < MIN_SECONDS then
        print(PREFIX_TEXT .. "Usage: /enbreak 30, /enbreak test, or /enbreak off")
        return
    end

    StartBreak(seconds, UnitName and UnitName("player") or "player", "Test")
end

addon.StartBreakTimer = StartBreak
addon.CancelBreakTimer = CancelBreak
