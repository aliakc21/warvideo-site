-- =========================================================================
-- ENRAGEPLUS: EMERGENCY BOOT LOGGER
-- Loads before the main addon files so load-time errors still remain visible.
-- =========================================================================
local ADDON_NAME = ...
local BOOT_MAX_ERRORS = 20
local bootButton
local bootFrame
local previousErrorHandler
local handlingError = false

local function BootSafeString(value, fallback)
    if value == nil then return fallback or "Unknown" end
    if type(issecretvalue) == "function" then
        local okSecret, isSecret = pcall(issecretvalue, value)
        if okSecret and isSecret then return fallback or "<secret value>" end
    end
    local ok, text = pcall(tostring, value)
    if ok and text and text ~= "" then return text end
    return fallback or "<unreadable>"
end

local function EnsureBootDB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    if not EnrageDB.global.bootErrors then EnrageDB.global.bootErrors = {} end
    return EnrageDB.global.bootErrors
end

local function GuessAddon(message, stack)
    local text = (message or "") .. "\n" .. (stack or "")
    return text:match("Interface/AddOns/([^/\\]+)") or ADDON_NAME or "Enrageplus"
end

local function BuildBootErrorText()
    local errors = EnsureBootDB()
    if #errors == 0 then
        return "No EnragePlus boot errors captured yet."
    end

    local lines = {}
    for i, err in ipairs(errors) do
        lines[#lines + 1] = "EnragePlus Boot Error"
        lines[#lines + 1] = ""
        lines[#lines + 1] = "ID: " .. tostring(i)
        lines[#lines + 1] = "Type: " .. BootSafeString(err.kind, "Lua Error")
        lines[#lines + 1] = "AddOn: " .. BootSafeString(err.addon, "Unknown")
        lines[#lines + 1] = "Time: " .. BootSafeString(err.timeText, "-")
        lines[#lines + 1] = ""
        lines[#lines + 1] = "Message:"
        lines[#lines + 1] = BootSafeString(err.message, "Unknown error")
        lines[#lines + 1] = ""
        lines[#lines + 1] = "Stack:"
        lines[#lines + 1] = BootSafeString(err.stack, "No stack available")
        lines[#lines + 1] = ""
        lines[#lines + 1] = string.rep("-", 56)
        lines[#lines + 1] = ""
    end
    return table.concat(lines, "\n")
end

function EnrageBoot_RefreshButton()
    if not UIParent then return end
    local errors = EnsureBootDB()
    if #errors == 0 then
        if bootButton then bootButton:Hide() end
        return
    end

    if not bootButton then
        bootButton = CreateFrame("Button", "EnrageBootErrorButton", UIParent)
        bootButton:SetSize(74, 30)
        bootButton:SetPoint("TOP", UIParent, "TOP", 0, -90)
        bootButton:SetFrameStrata("DIALOG")
        bootButton:SetClampedToScreen(true)

        local bg = bootButton:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        bg:SetVertexColor(0.68, 0.12, 0.10, 0.95)
        bootButton.bg = bg

        local border = bootButton:CreateTexture(nil, "BORDER")
        border:SetPoint("TOPLEFT")
        border:SetPoint("BOTTOMRIGHT")
        border:SetTexture("Interface\\Buttons\\WHITE8X8")
        border:SetVertexColor(1.0, 0.56, 0.34, 0.35)
        bootButton.border = border

        local label = bootButton:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        label:SetPoint("CENTER")
        label:SetText("|cFFFFFFFFLua!|r")
        bootButton.label = label

        bootButton:SetScript("OnEnter", function(self)
            self.bg:SetVertexColor(0.85, 0.18, 0.14, 1)
            GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
            GameTooltip:AddLine("EnragePlus boot error", 1, 0.82, 0)
            GameTooltip:AddLine("Click to open the emergency log.", 1, 1, 1)
            GameTooltip:Show()
        end)
        bootButton:SetScript("OnLeave", function(self)
            self.bg:SetVertexColor(0.68, 0.12, 0.10, 0.95)
            GameTooltip:Hide()
        end)
        bootButton:SetScript("OnClick", function()
            if EnrageBoot_ShowViewer then EnrageBoot_ShowViewer() end
        end)
    end

    bootButton:Show()
end

function EnrageBoot_ShowViewer()
    if not UIParent then return end

    if not bootFrame then
        local template = BackdropTemplateMixin and "BackdropTemplate" or nil
        bootFrame = CreateFrame("Frame", "EnrageBootErrorFrame", UIParent, template)
        bootFrame:SetSize(760, 470)
        bootFrame:SetPoint("CENTER")
        bootFrame:SetFrameStrata("FULLSCREEN_DIALOG")
        bootFrame:SetClampedToScreen(true)
        bootFrame:EnableMouse(true)
        bootFrame:SetMovable(true)
        bootFrame:RegisterForDrag("LeftButton")
        bootFrame:SetScript("OnDragStart", bootFrame.StartMoving)
        bootFrame:SetScript("OnDragStop", bootFrame.StopMovingOrSizing)

        if bootFrame.SetBackdrop then
            bootFrame:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8X8",
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            bootFrame:SetBackdropColor(0.02, 0.025, 0.035, 0.94)
            bootFrame:SetBackdropBorderColor(0.95, 0.25, 0.18, 0.9)
        else
            local bg = bootFrame:CreateTexture(nil, "BACKGROUND")
            bg:SetAllPoints()
            bg:SetTexture("Interface\\Buttons\\WHITE8X8")
            bg:SetVertexColor(0.02, 0.025, 0.035, 0.94)
        end

        local title = bootFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -16)
        title:SetText("|cFFFFB347EnragePlus|r Emergency Lua Log")

        local close = CreateFrame("Button", nil, bootFrame)
        close:SetSize(32, 28)
        close:SetPoint("TOPRIGHT", -10, -10)
        close.text = close:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        close.text:SetPoint("CENTER")
        close.text:SetText("|cFFFF5A4EX|r")
        close:SetScript("OnClick", function() bootFrame:Hide() end)

        local clear = CreateFrame("Button", nil, bootFrame)
        clear:SetSize(110, 28)
        clear:SetPoint("BOTTOMLEFT", 18, 14)
        clear.bg = clear:CreateTexture(nil, "BACKGROUND")
        clear.bg:SetAllPoints()
        clear.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        clear.bg:SetVertexColor(0.48, 0.12, 0.10, 0.95)
        clear.text = clear:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        clear.text:SetPoint("CENTER")
        clear.text:SetText("Clear")

        local edit = CreateFrame("EditBox", nil, bootFrame)
        edit:SetPoint("TOPLEFT", 18, -52)
        edit:SetPoint("BOTTOMRIGHT", -18, 54)
        edit:SetMultiLine(true)
        edit:SetAutoFocus(false)
        edit:SetFontObject(ChatFontNormal)
        edit:SetTextInsets(10, 10, 10, 10)
        edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        edit.bg = edit:CreateTexture(nil, "BACKGROUND")
        edit.bg:SetAllPoints()
        edit.bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        edit.bg:SetVertexColor(0, 0, 0, 0.45)
        bootFrame.edit = edit

        clear:SetScript("OnClick", function()
            EnrageDB.global.bootErrors = {}
            edit:SetText(BuildBootErrorText())
            EnrageBoot_RefreshButton()
        end)

        local hint = bootFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hint:SetPoint("BOTTOMRIGHT", -18, 22)
        hint:SetText("|cFFBFC7D5Click inside the box, Cmd/Ctrl+A, Cmd/Ctrl+C to copy.|r")
    end

    for _, err in ipairs(EnsureBootDB()) do
        err.unread = false
    end
    bootFrame.edit:SetText(BuildBootErrorText())
    bootFrame.edit:HighlightText(0, 0)
    bootFrame:Show()
end

function EnrageBoot_RecordError(kind, message, stack, addon)
    local errors = EnsureBootDB()
    table.insert(errors, 1, {
        kind = BootSafeString(kind, "Lua Error"),
        message = BootSafeString(message, "Unknown error"),
        stack = BootSafeString(stack, "No stack available"),
        addon = BootSafeString(addon, ADDON_NAME or "Enrageplus"),
        time = time and time() or 0,
        timeText = date and date("%Y-%m-%d %H:%M:%S") or "-",
        unread = true,
    })
    while #errors > BOOT_MAX_ERRORS do table.remove(errors) end
    EnrageBoot_RefreshButton()
end

function EnrageBoot_CleanupRemovedModules()
    if not EnrageDB or not EnrageDB.global then return end

    EnrageDB.global.ah = nil

    local luaErrors = EnrageDB.global.luaErrors
    local entries = luaErrors and luaErrors.entries
    if type(entries) == "table" then
        local kept = {}
        local unreadCount = 0
        local removedAddonMarker = "Enrage" .. string.char(65, 72)
        for i = 1, #entries do
            local err = entries[i]
            local message = type(err) == "table" and BootSafeString(err.message, "") or ""
            local stack = type(err) == "table" and BootSafeString(err.stack, "") or ""
            if not message:find(removedAddonMarker, 1, true) and not stack:find(removedAddonMarker, 1, true) then
                kept[#kept + 1] = err
                if type(err) == "table" and err.unread then
                    unreadCount = unreadCount + 1
                end
            end
        end
        luaErrors.entries = kept
        luaErrors.unreadCount = unreadCount
    end
end

local function BootErrorHandler(err)
    if handlingError then
        if previousErrorHandler then pcall(previousErrorHandler, err) end
        return
    end

    handlingError = true
    local message = BootSafeString(err, "Unknown Lua error")
    local stack = "No stack available"
    if type(debugstack) == "function" then
        local okStack, stackText = pcall(debugstack, 2)
        if okStack then stack = BootSafeString(stackText, stack) end
    end
    EnrageBoot_RecordError("Lua Error", message, stack, GuessAddon(message, stack))
    handlingError = false

    if previousErrorHandler and previousErrorHandler ~= BootErrorHandler then
        pcall(previousErrorHandler, err)
    end
end

if type(geterrorhandler) == "function" then
    pcall(function() previousErrorHandler = geterrorhandler() end)
end
if type(seterrorhandler) == "function" then
    pcall(seterrorhandler, BootErrorHandler)
end

local ready = CreateFrame("Frame")
ready:RegisterEvent("PLAYER_LOGIN")
ready:SetScript("OnEvent", function()
    EnrageBoot_CleanupRemovedModules()
    EnrageBoot_RefreshButton()
end)

SLASH_ENRAGEBOOT1 = "/enboot"
SLASH_ENRAGEBOOT2 = "/enbootlog"
SlashCmdList["ENRAGEBOOT"] = function()
    EnrageBoot_ShowViewer()
end
