-- =========================================================================
-- AkcQOL SKYRIDING TRACKER
-- A draggable, scalable tracker for skyriding abilities (Surge Forward,
-- Whirling Surge, Second Wind). Visible only while on a skyriding mount.
-- Two layouts (icon row / compact bars), selectable in Settings > Skyriding.
--
-- 12.0 / Midnight secret-safety: raw cooldown/charge values go straight into
-- the WHITELISTED Cooldown:SetCooldown (which accepts secret values, so the
-- swipe always works and never crashes). Only our OWN count/timer text and the
-- desaturate/fill math are issecretvalue-guarded. We never use `secret or x`
-- (the `or` would boolean-test the secret and crash) — values are passed raw.
-- =========================================================================

local FONT_FACE = (GameFontNormal and GameFontNormal:GetFont()) or "Fonts\\FRIZQT__.TTF"
local FLAT = "Interface\\Buttons\\WHITE8x8"

-- ids: first candidate that resolves to a texture wins (Whirling Surge has a
-- castable id 361584 plus an older trait variant 376359 as fallback).
local ABILITIES = {
    { ids = { 372608 },         label = "Surge Forward"  },
    { ids = { 361584, 376359 }, label = "Whirling Surge" },
    { ids = { 425782 },         label = "Second Wind"    },
}

local ICON_SIZE = 44
local ICON_PAD  = 6
local BAR_W, BAR_H, BAR_ICON, ROW_PAD = 150, 18, 22, 4
-- "vigor" style: segmented pips of the shared skyriding charge pool (what the old
-- Vigor bar showed; the resource was folded into Surge Forward's charges in 12.0).
local VIG_PIP_W, VIG_PIP_H, VIG_GAP, VIG_ICON, VIG_MAX_PIPS = 26, 16, 3, 26, 10

local frame, slots, ticker, eventFrame
local vigorRow
local lastVigorMax = 6
local previewToken = 0
local previewActive = false

------------------------------------------------------------
-- DB (lives in EnrageDB.global like the HUD)
------------------------------------------------------------
local function DB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    local g = EnrageDB.global
    if type(g.skyriding) ~= "table" then g.skyriding = {} end
    local d = g.skyriding
    if d.enabled == nil then d.enabled = false end  -- fresh installs opt in from settings
    if d.style ~= "bars" and d.style ~= "icons" and d.style ~= "vigor" then d.style = "icons" end
    if type(d.scale) ~= "number" then d.scale = 1.0 end
    return d
end

------------------------------------------------------------
-- Secret-safe number reader: nil for secret/non-number so callers can branch
------------------------------------------------------------
local function safeNum(v)
    if v == nil then return nil end
    if issecretvalue and issecretvalue(v) then return nil end
    if type(v) ~= "number" then return nil end
    return v
end

local function SpellTex(id)
    return (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(id)) or nil
end

local function ResolveId(entry)
    if entry.id then return entry.id end
    for _, id in ipairs(entry.ids) do
        if SpellTex(id) then entry.id = id; return id end
    end
    entry.id = entry.ids[1]
    return entry.id
end

local function FmtTime(t)
    if t >= 60 then return string.format("%d:%02d", math.floor(t / 60), math.floor(t % 60)) end
    if t >= 10 then return string.format("%d", math.floor(t + 0.5)) end
    return string.format("%.1f", t)
end

------------------------------------------------------------
-- Are we currently on a skyriding mount?
------------------------------------------------------------
local function IsSkyriding()
    -- ride-along passenger has no skyriding abilities
    if UnitInVehicle and UnitInVehicle("player")
        and UnitInVehicleControlSeat and not UnitInVehicleControlSeat("player") then
        return false
    end
    local mounted = (IsMounted and IsMounted())
        or (GetShapeshiftForm and GetShapeshiftForm() == 3) -- Druid Travel/Flight Form
    if not mounted then return false end

    if C_PlayerInfo and C_PlayerInfo.GetGlidingInfo then
        -- Do the truthiness test INSIDE the pcall: in 12.0 canGlide can be a secret, and
        -- a boolean test on a secret crashes the line — keep that crash inside the
        -- protected call so it degrades to the fallback below.
        local ok, canGlide = pcall(function()
            local _isGliding, cg = C_PlayerInfo.GetGlidingInfo()
            return cg and true or false
        end)
        -- canGlide is true ONLY on a dynamic-flight (skyriding) mount; a ground or
        -- steady-flight mount reports false. When the call succeeds it is authoritative,
        -- so trust it directly — returning false here is what stops the icons from
        -- showing on a normal ground mount. Only a secret/crash (ok == false) falls
        -- through to the charge-bar fallback.
        if ok then return canGlide end
    end
    -- Fallback ONLY when GetGlidingInfo is unavailable or returned a secret value. While
    -- skyriding (and only then) the bars are swapped to the Dragonriding bonus bar, which
    -- is bonus-bar offset 5 specifically — distinct from druid/rogue form bars (1-4) and
    -- zero on a ground mount. This distinguishes a skyriding mount from a ground mount,
    -- unlike GetSpellCharges (Surge Forward keeps its charges whenever merely known).
    -- Bonus-bar state is plain UI data, never secret.
    if GetBonusBarOffset and HasBonusActionBar then
        local ok, active = pcall(function()
            return HasBonusActionBar() and GetBonusBarOffset() == 5
        end)
        if ok and active then return true end
    end
    return false
end

------------------------------------------------------------
-- Build
------------------------------------------------------------
local function CreateSlot(parent)
    local s = CreateFrame("Frame", nil, parent)

    s.bg = s:CreateTexture(nil, "BACKGROUND")
    s.bg:SetColorTexture(0, 0, 0, 0.45)

    s.border = s:CreateTexture(nil, "BORDER")
    s.border:SetColorTexture(0.16, 0.17, 0.22, 0.9)

    s.icon = s:CreateTexture(nil, "ARTWORK")
    s.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    s.cd = CreateFrame("Cooldown", nil, s, "CooldownFrameTemplate")
    s.cd:SetDrawEdge(true)
    if s.cd.SetHideCountdownNumbers then s.cd:SetHideCountdownNumbers(true) end

    s.chargeText = s:CreateFontString(nil, "OVERLAY")
    s.chargeText:SetFont(FONT_FACE, 12, "OUTLINE")
    s.chargeText:SetJustifyH("RIGHT")

    s.timeText = s:CreateFontString(nil, "OVERLAY")
    s.timeText:SetFont(FONT_FACE, 14, "OUTLINE")
    s.timeText:SetJustifyH("CENTER")

    s.bar = CreateFrame("StatusBar", nil, s)
    s.bar:SetStatusBarTexture(FLAT)
    s.bar:SetStatusBarColor(0.22, 0.46, 0.76)
    s.barBg = s.bar:CreateTexture(nil, "BACKGROUND")
    s.barBg:SetAllPoints()
    s.barBg:SetColorTexture(0.10, 0.11, 0.15, 0.92)

    s.nameText = s.bar:CreateFontString(nil, "OVERLAY")
    s.nameText:SetFont(FONT_FACE, 11, "OUTLINE")
    s.nameText:SetPoint("LEFT", s.bar, "LEFT", 5, 0)
    s.nameText:SetJustifyH("LEFT")

    s.barValueText = s.bar:CreateFontString(nil, "OVERLAY")
    s.barValueText:SetFont(FONT_FACE, 11, "OUTLINE")
    s.barValueText:SetPoint("RIGHT", s.bar, "RIGHT", -5, 0)
    s.barValueText:SetJustifyH("RIGHT")

    return s
end

------------------------------------------------------------
-- "Vigor bar" style: segmented pips (filled = available charges, the next pip
-- fills with recharge progress) + a small Whirling Surge icon on the right.
------------------------------------------------------------
local function EnsureVigorRow()
    if vigorRow then return vigorRow end
    local r = CreateFrame("Frame", nil, frame)
    r.pips = {}
    for i = 1, VIG_MAX_PIPS do
        local p = CreateFrame("StatusBar", nil, r)
        p:SetStatusBarTexture(FLAT)
        p:SetStatusBarColor(0.27, 0.62, 0.90)      -- the classic vigor blue
        p:SetMinMaxValues(0, 1)
        p:SetValue(0)
        local bg = p:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0.07, 0.08, 0.12, 0.92)
        local edge = p:CreateTexture(nil, "BORDER")
        edge:SetPoint("TOPLEFT", -1, 1)
        edge:SetPoint("BOTTOMRIGHT", 1, -1)
        edge:SetColorTexture(0.16, 0.17, 0.22, 0.9)
        edge:SetDrawLayer("BORDER", -1)
        p:Hide()
        r.pips[i] = p
    end

    r.iconBorder = r:CreateTexture(nil, "BORDER")
    r.iconBorder:SetColorTexture(0.16, 0.17, 0.22, 0.9)
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(VIG_ICON, VIG_ICON)
    r.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    r.cd = CreateFrame("Cooldown", nil, r, "CooldownFrameTemplate")
    r.cd:SetDrawEdge(true)
    if r.cd.SetHideCountdownNumbers then r.cd:SetHideCountdownNumbers(true) end

    r:Hide()
    vigorRow = r
    return r
end

local function LayoutVigor(n)
    local r = EnsureVigorRow()
    if r.shownPips == n then return end
    r.shownPips = n
    for i = 1, VIG_MAX_PIPS do
        local p = r.pips[i]
        if i <= n then
            p:ClearAllPoints()
            p:SetPoint("LEFT", r, "LEFT", (i - 1) * (VIG_PIP_W + VIG_GAP), 0)
            p:SetSize(VIG_PIP_W, VIG_PIP_H)
            p:Show()
        else
            p:Hide()
        end
    end
    local barsW = n * VIG_PIP_W + (n - 1) * VIG_GAP
    r.icon:ClearAllPoints()
    r.icon:SetPoint("LEFT", r, "LEFT", barsW + 6, 0)
    r.iconBorder:ClearAllPoints()
    r.iconBorder:SetPoint("TOPLEFT", r.icon, "TOPLEFT", -1, 1)
    r.iconBorder:SetPoint("BOTTOMRIGHT", r.icon, "BOTTOMRIGHT", 1, -1)
    r.cd:SetAllPoints(r.icon)
    local w, h = barsW + 6 + VIG_ICON, math.max(VIG_PIP_H, VIG_ICON)
    r:SetSize(w, h)
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    frame:SetSize(w, h)
end

local function UpdateVigor()
    if not vigorRow or not slots then return end
    local r = vigorRow

    -- right-side icon: Whirling Surge with its cooldown swipe (raw -> whitelisted)
    local wsId = slots[2] and slots[2].id
    if wsId then
        local tex = SpellTex(wsId)
        if tex then r.icon:SetTexture(tex) end
        local cd = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(wsId)
        if type(cd) == "table" then
            r.cd:SetCooldown(cd.startTime, cd.duration, cd.modRate)
        elseif r.cd.Clear then
            r.cd:Clear()
        end
    end

    local sfId = slots[1] and slots[1].id
    local charges = sfId and C_Spell and C_Spell.GetSpellCharges and C_Spell.GetSpellCharges(sfId)
    if type(charges) ~= "table" then
        -- no charge data (spell not known): during Preview show a full sample bar
        if previewActive then
            LayoutVigor(lastVigorMax or 6)
            for i = 1, r.shownPips or 0 do r.pips[i]:SetValue(1) end
        end
        return
    end
    local cur, mx = safeNum(charges.currentCharges), safeNum(charges.maxCharges)
    if not cur or not mx or mx <= 0 then return end -- secret in combat -> keep last drawn state
    if mx > VIG_MAX_PIPS then mx = VIG_MAX_PIPS end
    if cur > mx then cur = mx end
    lastVigorMax = mx
    LayoutVigor(mx)

    local start, dur = safeNum(charges.cooldownStartTime), safeNum(charges.cooldownDuration)
    for i = 1, mx do
        local p = r.pips[i]
        if i <= cur then
            p:SetValue(1)
        elseif i == cur + 1 and start and dur and dur > 0 then
            local pct = (GetTime() - start) / dur
            if pct < 0 then pct = 0 elseif pct > 1 then pct = 1 end
            p:SetValue(pct)
        else
            p:SetValue(0)
        end
    end
end

local function ApplyStyle()
    if not frame or not slots then return end
    local style = DB().style
    local n = #slots

    if style == "vigor" then
        for _, s in ipairs(slots) do s:Hide() end
        local r = EnsureVigorRow()
        r.shownPips = nil -- force a fresh layout
        LayoutVigor(lastVigorMax or 6)
        r:Show()
        UpdateVigor()
        return
    end
    if vigorRow then vigorRow:Hide() end
    for _, s in ipairs(slots) do s:Show() end

    if style == "bars" then
        local rowH = math.max(BAR_H, BAR_ICON)
        for i, s in ipairs(slots) do
            s:ClearAllPoints()
            s:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -(i - 1) * (rowH + ROW_PAD))
            s:SetSize(BAR_ICON + 5 + BAR_W, rowH)

            s.icon:ClearAllPoints()
            s.icon:SetPoint("LEFT", s, "LEFT", 0, 0)
            s.icon:SetSize(BAR_ICON, BAR_ICON)
            s.bg:ClearAllPoints(); s.bg:SetAllPoints(s.icon)
            s.border:ClearAllPoints()
            s.border:SetPoint("TOPLEFT", s.icon, "TOPLEFT", -1, 1)
            s.border:SetPoint("BOTTOMRIGHT", s.icon, "BOTTOMRIGHT", 1, -1)
            s.cd:SetAllPoints(s.icon)

            s.bar:ClearAllPoints()
            s.bar:SetPoint("LEFT", s.icon, "RIGHT", 5, 0)
            s.bar:SetSize(BAR_W, BAR_H)
            s.bar:Show(); s.nameText:Show(); s.barValueText:Show()
            s.nameText:SetText("|cFFE9C96A" .. s.label .. "|r")

            s.chargeText:Hide(); s.timeText:Hide()
        end
        frame:SetSize(BAR_ICON + 5 + BAR_W, n * rowH + (n - 1) * ROW_PAD)
    else
        for i, s in ipairs(slots) do
            s:ClearAllPoints()
            s:SetPoint("TOPLEFT", frame, "TOPLEFT", (i - 1) * (ICON_SIZE + ICON_PAD), 0)
            s:SetSize(ICON_SIZE, ICON_SIZE)

            s.icon:ClearAllPoints()
            s.icon:SetPoint("TOPLEFT", s, "TOPLEFT", 0, 0)
            s.icon:SetSize(ICON_SIZE, ICON_SIZE)
            s.bg:ClearAllPoints(); s.bg:SetAllPoints(s.icon)
            s.border:ClearAllPoints()
            s.border:SetPoint("TOPLEFT", s.icon, "TOPLEFT", -1, 1)
            s.border:SetPoint("BOTTOMRIGHT", s.icon, "BOTTOMRIGHT", 1, -1)
            s.cd:SetAllPoints(s.icon)

            s.chargeText:ClearAllPoints()
            s.chargeText:SetPoint("BOTTOMRIGHT", s.icon, "BOTTOMRIGHT", -1, 1)
            s.timeText:ClearAllPoints()
            s.timeText:SetPoint("CENTER", s.icon, "CENTER", 0, 0)
            s.chargeText:Show(); s.timeText:Show()

            s.bar:Hide(); s.nameText:Hide(); s.barValueText:Hide()
        end
        frame:SetSize(n * ICON_SIZE + (n - 1) * ICON_PAD, ICON_SIZE)
    end
end

------------------------------------------------------------
-- Per-ability data update (secret-safe)
------------------------------------------------------------
local function UpdateSlot(s)
    local id = s.id
    local tex = SpellTex(id)
    if tex then s.icon:SetTexture(tex) end

    local charges = C_Spell and C_Spell.GetSpellCharges and C_Spell.GetSpellCharges(id)
    if type(charges) == "table" then
        s.isCharge = true
        s._start, s._dur = nil, nil
        -- raw values -> whitelisted SetCooldown (recharge swipe on the filling charge)
        s.cd:SetCooldown(charges.cooldownStartTime, charges.cooldownDuration, charges.chargeModRate)
        local cur, mx = safeNum(charges.currentCharges), safeNum(charges.maxCharges)
        if cur and mx then
            s.chargeText:SetText(cur .. "/" .. mx)
            s.barValueText:SetText(cur .. "/" .. mx)
            s.icon:SetDesaturated(cur <= 0)
            s.bar:SetMinMaxValues(0, mx)
            s.bar:SetValue(cur)
        else
            s.chargeText:SetText("")
            s.barValueText:SetText("")
            s.icon:SetDesaturated(false)
            s.bar:SetMinMaxValues(0, 1)
            s.bar:SetValue(1)
        end
        s.timeText:SetText("")
    else
        s.isCharge = false
        local cd = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(id)
        if type(cd) == "table" then
            s.cd:SetCooldown(cd.startTime, cd.duration, cd.modRate)
            s._start, s._dur = safeNum(cd.startTime), safeNum(cd.duration)
        else
            if s.cd.Clear then s.cd:Clear() end
            s._start, s._dur = nil, nil
        end
        s.chargeText:SetText("")
        local onCD = (s._dur and s._dur > 0) and true or false
        s.icon:SetDesaturated(onCD)
        s.bar:SetMinMaxValues(0, 1)
        if onCD and s._start then
            local frac = ((s._start + s._dur) - GetTime()) / s._dur
            if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
            s.bar:SetValue(frac)
        else
            s.bar:SetValue(onCD and 0 or 1)
            s.barValueText:SetText("")
        end
    end
end

local function UpdateAll()
    if not slots then return end
    if DB().style == "vigor" then
        UpdateVigor()
        return
    end
    for _, s in ipairs(slots) do UpdateSlot(s) end
end

-- Light ticker: animates the cooldown ability's timer/fill between SPELL_UPDATE_* events.
local function Tick()
    if not slots then return end
    if DB().style == "vigor" then
        UpdateVigor() -- animates the filling pip (no event fires for partial progress)
        return
    end
    local now = GetTime()
    for _, s in ipairs(slots) do
        if not s.isCharge and s._start and s._dur and s._dur > 0 then
            local rem = (s._start + s._dur) - now
            if rem > 0 then
                s.timeText:SetText(FmtTime(rem))
                s.barValueText:SetText(FmtTime(rem))
                local frac = rem / s._dur
                if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
                s.bar:SetValue(frac)
            else
                s.timeText:SetText("")
                s.barValueText:SetText("")
                s.icon:SetDesaturated(false)
                s.bar:SetValue(1)
                s._start, s._dur = nil, nil
            end
        end
    end
end

local function StartTicker() if not ticker then ticker = C_Timer.NewTicker(0.2, Tick) end end
local function StopTicker() if ticker then ticker:Cancel(); ticker = nil end end

------------------------------------------------------------
-- Visibility
------------------------------------------------------------
local function UpdateVisibility()
    if not frame then return end
    local show = (DB().enabled ~= false) and (previewActive or IsSkyriding())
    if show then
        frame:Show()
        UpdateAll()
        StartTicker()
    else
        frame:Hide()
        StopTicker()
    end
end

------------------------------------------------------------
-- Interactive (drag) mode — used during Preview/Reset only, so the tracker is
-- click-through during normal flight and never eats mouse-look.
------------------------------------------------------------
local function SetInteractive(on)
    if not frame then return end
    frame:EnableMouse(on and true or false)
    frame:SetFrameStrata(on and "TOOLTIP" or "MEDIUM")
    if on and not frame.previewHL then
        local hl = frame:CreateTexture(nil, "BACKGROUND")
        hl:SetPoint("TOPLEFT", -3, 3)
        hl:SetPoint("BOTTOMRIGHT", 3, -3)
        hl:SetColorTexture(0.10, 0.55, 1.0, 0.15)
        frame.previewHL = hl
    end
    if frame.previewHL then frame.previewHL:SetShown(on and true or false) end
end

local function CreateTracker()
    if frame then return end
    local d = DB()
    frame = CreateFrame("Frame", "EnrageSkyridingFrame", UIParent)
    frame:SetFrameStrata("MEDIUM")
    frame:SetSize(150, 44)
    frame:SetClampedToScreen(false)
    frame:SetMovable(true)
    frame:EnableMouse(false) -- click-through by default; enabled only in Preview
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local l, t = self:GetLeft(), self:GetTop()
        if l and t then
            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l, t)
            local dd = DB()
            dd.posX, dd.posY = l, t
        end
    end)

    if d.posX and d.posY then
        frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", d.posX, d.posY)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
    end
    frame:SetScale(d.scale or 1.0)

    slots = {}
    for i, entry in ipairs(ABILITIES) do
        local s = CreateSlot(frame)
        s.label = entry.label
        s.id = ResolveId(entry)
        slots[i] = s
    end
    ApplyStyle()
    frame:Hide()
end

------------------------------------------------------------
-- Public API (settings + slash)
------------------------------------------------------------
function _G.Enrage_ApplySkyridingVisibility()
    if not frame then CreateTracker() end
    UpdateVisibility()
end

function _G.Enrage_SetSkyridingStyle(style)
    local d = DB()
    d.style = (style == "bars" or style == "vigor") and style or "icons"
    if not frame then CreateTracker() end
    ApplyStyle()
    UpdateAll()
end

function _G.Enrage_SetSkyridingScale(scale)
    local d = DB()
    if type(scale) == "number" then d.scale = scale end
    if frame then frame:SetScale(d.scale or 1.0) end
end

function _G.Enrage_RefreshSkyriding()
    if not frame then CreateTracker() end
    ApplyStyle()
    UpdateAll()
    UpdateVisibility()
end

-- Show the tracker on top for ~12s (even off a mount) so it can be positioned.
function _G.Enrage_PreviewSkyriding()
    if not frame then CreateTracker() end
    previewToken = previewToken + 1
    local token = previewToken
    previewActive = true
    SetInteractive(true)
    frame:Show()
    ApplyStyle()
    UpdateAll()
    if C_Timer and C_Timer.After then
        C_Timer.After(12, function()
            if token ~= previewToken then return end
            previewActive = false
            SetInteractive(false)
            UpdateVisibility()
        end)
    end
end

function _G.Enrage_ResetSkyridingPosition()
    if not frame then CreateTracker() end
    frame:Show()
    ApplyStyle()
    UpdateAll()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
    local l, t = frame:GetLeft(), frame:GetTop()
    if l and t then
        frame:ClearAllPoints()
        frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l, t)
        local d = DB()
        d.posX, d.posY = l, t
    end
    if _G.Enrage_PreviewSkyriding then _G.Enrage_PreviewSkyriding() end
end

-- Restore every Skyriding setting (enabled/style/scale/position) to defaults.
function _G.Enrage_ResetSkyridingDefaults()
    if EnrageDB and EnrageDB.global then EnrageDB.global.skyriding = nil end
    local d = DB() -- re-inits enabled=false, style="icons", scale=1.0, no saved position
    if not frame then CreateTracker() end
    frame:SetScale(d.scale or 1.0)
    ApplyStyle()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
    local l, t = frame:GetLeft(), frame:GetTop()
    if l and t then
        frame:ClearAllPoints()
        frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l, t)
        d.posX, d.posY = l, t
    end
    UpdateAll()
    UpdateVisibility()
end

------------------------------------------------------------
-- Events
------------------------------------------------------------
local SHOW_EVENTS = {
    "PLAYER_MOUNT_DISPLAY_CHANGED", "PLAYER_CAN_GLIDE_CHANGED", "PLAYER_IS_GLIDING_CHANGED",
    "UNIT_ENTERED_VEHICLE", "UNIT_EXITED_VEHICLE", "VEHICLE_UPDATE",
    "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_FORMS", "PLAYER_ENTERING_WORLD",
}
local DATA_EVENTS = { "SPELL_UPDATE_CHARGES", "SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_USABLE" }

eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
for _, e in ipairs(SHOW_EVENTS) do pcall(eventFrame.RegisterEvent, eventFrame, e) end
for _, e in ipairs(DATA_EVENTS) do pcall(eventFrame.RegisterEvent, eventFrame, e) end

eventFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()
        CreateTracker()
        UpdateVisibility()
        return
    end
    if not frame then return end
    if event == "SPELL_UPDATE_CHARGES" or event == "SPELL_UPDATE_COOLDOWN" or event == "SPELL_UPDATE_USABLE" then
        if frame:IsShown() then UpdateAll() end
    else
        UpdateVisibility()
    end
end)
