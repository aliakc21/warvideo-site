-- =========================================================================
-- AkcQOL PET HEALTH ALERT
-- Plays a Blizzard SoundKit sound (reusing the PI Alert sound list) and,
-- optionally, flashes a configurable message in the middle of the screen
-- (mirrors the PI Alert's "Show Screen Text") when the player's pet drops
-- below a health threshold. Works for ANY class with a pet (Hunter, Warlock,
-- Death Knight, Mage water elemental, ...).
--
-- Fires ONCE per dip: re-arms only after the pet climbs back above the
-- threshold (+5% hysteresis) or is re-summoned, and never more than once per 5s.
-- 12.0-safe: health values are issecretvalue-guarded before any math.
-- =========================================================================

local _, addon = ...

local DEFAULT_PET_MESSAGE = "pet low hp"

local lastPlay = 0
local fired = false

-- Screen-text frame: its own frame + hide token, independent of the PI Alert's,
-- so the two never clobber each other's timer and can show at once if needed.
local petScreenFrame
local petHideToken = 0

-- Safety-net poll handle (see SyncPolling). UNIT_HEALTH alone is not enough.
local pollTicker

local function DB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    local g = EnrageDB.global
    if type(g.petAlert) ~= "table" then g.petAlert = {} end
    local d = g.petAlert
    if d.enabled == nil then d.enabled = false end  -- fresh installs opt in from settings
    if type(d.threshold) ~= "number" then d.threshold = 50 end
    if type(d.soundStyle) ~= "string" then d.soundStyle = "bosswarn" end
    if type(d.volume) ~= "number" then d.volume = 100 end
    if d.screen == nil then d.screen = false end  -- on-screen text is opt-in, like PI
    if type(d.message) ~= "string" or d.message == "" then d.message = DEFAULT_PET_MESSAGE end
    return d
end

local function safeNum(v)
    if v == nil then return nil end
    if issecretvalue and issecretvalue(v) then return nil end
    if type(v) ~= "number" then return nil end
    return v
end

local function PlayStyle(style)
    if addon.PlayAlertSoundStyle then addon:PlayAlertSoundStyle(style, DB().volume) end
end

-- On-screen text, built lazily on first use (same shape as the PI Alert's frame, but
-- its own handle/token + a danger red-orange tint and a slightly lower anchor so a pet
-- warning never overlaps a PI warning).
local function EnsurePetScreenFrame()
    if petScreenFrame then return petScreenFrame end
    local frame = CreateFrame("Frame", "EnragePetAlertFrame", UIParent)
    frame:SetSize(420, 70)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 90)
    frame:SetFrameStrata("FULLSCREEN_DIALOG")
    frame:SetFrameLevel(20)
    frame:Hide()

    frame.text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    frame.text:SetPoint("CENTER")
    frame.text:SetTextColor(1, 0.35, 0.25, 1)

    petScreenFrame = frame
    return petScreenFrame
end

local function ShowPetScreenAlert(message)
    local upper = string.upper(message or DEFAULT_PET_MESSAGE)
    local frame = EnsurePetScreenFrame()
    frame.text:SetText(upper)
    frame:SetAlpha(1)
    frame:Show()

    petHideToken = petHideToken + 1
    local token = petHideToken
    if C_Timer and C_Timer.After then
        C_Timer.After(1.8, function()
            if petHideToken ~= token or not petScreenFrame then return end
            petScreenFrame:Hide()
        end)
    end

    if UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(upper, 1, 0.35, 0.25, 1)
    end
end

local function CheckPet()
    local d = DB()
    if d.enabled == false then return end
    if not UnitExists("pet") or UnitIsDeadOrGhost("pet") then
        fired = false
        return
    end
    local hp = safeNum(UnitHealth("pet"))
    local mx = safeNum(UnitHealthMax("pet"))
    if not hp or not mx or mx <= 0 then return end

    local pct = (hp / mx) * 100
    local threshold = d.threshold or 50

    if pct <= threshold then
        if not fired then
            local now = GetTime()
            if (now - lastPlay) >= 5 then
                PlayStyle(d.soundStyle)
                if d.screen then ShowPetScreenAlert(d.message) end
                lastPlay = now
            end
            fired = true
        end
    elseif pct >= (threshold + 5) then
        fired = false  -- re-arm once the pet recovers
    end
end

-- Detection is NOT purely event-driven. UNIT_HEALTH only fires while the pet's health is
-- CHANGING, so a pet already sitting below the threshold (took damage, then stable) would
-- never be re-evaluated and the alert would silently never trigger. A light 1s poll (the
-- same safety-net idea the PI Alert uses) closes that gap, also catches the moment the user
-- enables the feature, and makes threshold changes take effect promptly. It runs ONLY while
-- the feature is enabled, so a disabled addon still does nothing.
local function SyncPolling()
    local d = DB()
    if d.enabled ~= false then
        if not pollTicker and C_Timer and C_Timer.NewTicker then
            pollTicker = C_Timer.NewTicker(1, function() pcall(CheckPet) end)
        end
    elseif pollTicker then
        pollTicker:Cancel()
        pollTicker = nil
        if petScreenFrame then petScreenFrame:Hide() end
    end
end

------------------------------------------------------------
-- Public API (settings + slash)
------------------------------------------------------------
function _G.Enrage_TestPetAlertSound()
    PlayStyle(DB().soundStyle)
end

-- Preview both layers: always plays the sound and shows the screen text (so the user can
-- see the wording/placement even before enabling "Show Screen Text").
function _G.Enrage_TestPetAlert()
    local d = DB()
    PlayStyle(d.soundStyle)
    ShowPetScreenAlert(d.message)
end

function _G.Enrage_ApplyPetAlert()
    fired = false
    DB()
    SyncPolling()      -- start/stop the safety-net poll to match the new enabled state
    pcall(CheckPet)    -- immediate evaluation, so enabling at an already-low pet HP alerts now
end

-- Restore every Pet Alert setting (enabled/threshold/sound) to defaults.
function _G.Enrage_ResetPetAlertDefaults()
    if EnrageDB and EnrageDB.global then EnrageDB.global.petAlert = nil end
    DB() -- re-inits enabled=false, threshold=50, soundStyle="bosswarn"
    fired = false
end

------------------------------------------------------------
-- Events
------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()
        -- UnitEvent filter -> only fires for the pet, not the whole raid.
        f:RegisterUnitEvent("UNIT_HEALTH", "pet")
        f:RegisterEvent("UNIT_PET")
        f:RegisterEvent("PLAYER_ENTERING_WORLD")
        SyncPolling()  -- resume the safety-net poll if the alert was enabled last session
        return
    end
    if event == "UNIT_PET" or event == "PLAYER_ENTERING_WORLD" then
        fired = false  -- new/!no pet -> reset the latch
        pcall(CheckPet)  -- a freshly summoned / zoned-in pet may already be low
        return
    end
    -- UNIT_HEALTH (pet). Backstop pcall in case a health value is secret/tainted.
    pcall(CheckPet)
end)
