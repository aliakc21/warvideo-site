-- =========================================================================
-- AkcQOL PET HEALTH ALERT
-- Plays a Blizzard SoundKit sound (reusing the PI Alert sound list) when the
-- player's pet drops below a health threshold. Works for ANY class with a pet
-- (Hunter, Warlock, Death Knight, Mage water elemental, ...).
--
-- Fires ONCE per dip: re-arms only after the pet climbs back above the
-- threshold (+5% hysteresis) or is re-summoned, and never more than once per 5s.
-- 12.0-safe: health values are issecretvalue-guarded before any math.
-- =========================================================================

local _, addon = ...

local lastPlay = 0
local fired = false

local function DB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    local g = EnrageDB.global
    if type(g.petAlert) ~= "table" then g.petAlert = {} end
    local d = g.petAlert
    if d.enabled == nil then d.enabled = false end  -- fresh installs opt in from settings
    if type(d.threshold) ~= "number" then d.threshold = 50 end
    if type(d.soundStyle) ~= "string" then d.soundStyle = "bosswarn" end
    if type(d.volume) ~= "number" then d.volume = 100 end
    return d
end

local function safeNum(v)
    if v == nil then return nil end
    if issecretvalue and issecretvalue(v) then return nil end
    if type(v) ~= "number" then return nil end
    return v
end

local function PlayStyle(style)
    if addon.PlayAlertSoundStyle then addon:PlayAlertSoundStyle(style, DB().volume) end
end

local function CheckPet()
    local d = DB()
    if d.enabled == false then return end
    if not UnitExists("pet") or UnitIsDeadOrGhost("pet") then
        fired = false
        return
    end
    local hp = safeNum(UnitHealth("pet"))
    local mx = safeNum(UnitHealthMax("pet"))
    if not hp or not mx or mx <= 0 then return end

    local pct = (hp / mx) * 100
    local threshold = d.threshold or 50

    if pct <= threshold then
        if not fired then
            local now = GetTime()
            if (now - lastPlay) >= 5 then
                PlayStyle(d.soundStyle)
                lastPlay = now
            end
            fired = true
        end
    elseif pct >= (threshold + 5) then
        fired = false  -- re-arm once the pet recovers
    end
end

------------------------------------------------------------
-- Public API (settings + slash)
------------------------------------------------------------
function _G.Enrage_TestPetAlertSound()
    PlayStyle(DB().soundStyle)
end

function _G.Enrage_ApplyPetAlert()
    fired = false
    DB()
end

-- Restore every Pet Alert setting (enabled/threshold/sound) to defaults.
function _G.Enrage_ResetPetAlertDefaults()
    if EnrageDB and EnrageDB.global then EnrageDB.global.petAlert = nil end
    DB() -- re-inits enabled=false, threshold=50, soundStyle="bosswarn"
    fired = false
end

------------------------------------------------------------
-- Events
------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()
        -- UnitEvent filter -> only fires for the pet, not the whole raid.
        f:RegisterUnitEvent("UNIT_HEALTH", "pet")
        f:RegisterEvent("UNIT_PET")
        f:RegisterEvent("PLAYER_ENTERING_WORLD")
        return
    end
    if event == "UNIT_PET" or event == "PLAYER_ENTERING_WORLD" then
        fired = false  -- new/!no pet -> reset the latch
        return
    end
    -- UNIT_HEALTH (pet). Backstop pcall in case a health value is secret/tainted.
    pcall(CheckPet)
end)
