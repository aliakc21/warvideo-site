local _, addon = ...

local specNameCache = {}

local PI_SOUND_OPTIONS_FALLBACK = {
    raidwarning = "Raid Warning",
    readycheck = "Ready Check",
    alarm = "Alarm Clock",
    bosswarn = "Boss Warning",
    questdone = "Quest Complete",
    ping = "Map Ping",
    whisper = "Whisper",
    queue = "Queue Pop",
    auction = "Auction Bell",
    invite = "Group Invite",
    levelup = "Level Up",
}

local function NormalizePISoundStyle(style)
    -- Cooldown Manager sounds use "cdm<soundKitID>" keys; accept them by pattern so the
    -- saved selection survives even when the Blizzard sound table isn't loaded yet.
    if type(style) == "string" and style:match("^cdm%d+$") then return style end
    local options = addon.GetPIAlertSoundOptions and addon:GetPIAlertSoundOptions() or PI_SOUND_OPTIONS_FALLBACK
    if options[style or ""] then
        return style
    end
    return "raidwarning"
end

local function NormalizePISoundVolume(volume)
    volume = tonumber(volume) or 100
    if volume < 0 then volume = 0 elseif volume > 100 then volume = 100 end
    return math.floor(volume + 0.5)
end

local ACTION_BAR_MOUSEOVER_BARS = {
    { key = "main", name = "Main Bar" },
    { key = "bottomLeft", name = "Action Bar 2" },
    { key = "bottomRight", name = "Action Bar 3" },
    { key = "right", name = "Action Bar 4" },
    { key = "left", name = "Action Bar 5" },
    { key = "bar5", name = "Action Bar 6" },
    { key = "bar6", name = "Action Bar 7" },
    { key = "bar7", name = "Action Bar 8" },
    { key = "pet", name = "Pet Bar" },
    { key = "stance", name = "Stance Bar" },
}

local function NormalizeAlpha(value, fallback)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value == nil then value = 1 end
    if value < 0 then return 0 end
    if value > 1 then return 1 end
    return value
end

local function NormalizeNumber(value, fallback, minValue, maxValue)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function EnsureActionBarMouseoverDB(db)
    db.actionBarMouseover = db.actionBarMouseover or {}
    local ab = db.actionBarMouseover
    if ab.enabled == nil then ab.enabled = false end
    ab.minAlpha = NormalizeAlpha(ab.minAlpha, 0)
    ab.maxAlpha = NormalizeAlpha(ab.maxAlpha, 1)
    if ab.maxAlpha < ab.minAlpha then ab.maxAlpha = ab.minAlpha end
    ab.hoverDelay = NormalizeNumber(ab.hoverDelay, 0.7, 0, 2)
    if ab.alwaysShowInCombat == nil then ab.alwaysShowInCombat = false end
    if ab.alwaysShowInEditMode == nil then ab.alwaysShowInEditMode = false end
    ab.bars = ab.bars or {}
    for _, def in ipairs(ACTION_BAR_MOUSEOVER_BARS) do
        if ab.bars[def.key] == nil then
            ab.bars[def.key] = false
        end
    end
    return ab
end

local function EnsureLocatorColor(color, defaults)
    if type(color) ~= "table" then color = {} end
    color.r = NormalizeAlpha(color.r, defaults.r)
    color.g = NormalizeAlpha(color.g, defaults.g)
    color.b = NormalizeAlpha(color.b, defaults.b)
    color.a = NormalizeAlpha(color.a, defaults.a)
    return color
end

local function EnsurePersonalLocatorDB(db)
    db.personalLocator = db.personalLocator or {}
    local locator = db.personalLocator

    locator.player = locator.player or {}
    local player = locator.player
    if player.enabled == nil then player.enabled = false end
    if player.combatOnly == nil then player.combatOnly = false end
    if player.style ~= "crosshair" and player.style ~= "brackets"
        and player.style ~= "beacon" and player.style ~= "ring" then
        player.style = "crosshair"
    end
    if player.classColor == nil then player.classColor = false end
    if player.pulse == nil then player.pulse = false end
    if player.spin == nil then player.spin = false end
    player.size = NormalizeNumber(player.size, 52, 20, 160)
    player.thickness = NormalizeNumber(player.thickness, 3, 1, 12)
    player.outline = NormalizeNumber(player.outline, 2, 0, 6)
    player.gap = NormalizeNumber(player.gap, 8, 0, 40)
    player.offsetX = NormalizeNumber(player.offsetX, 0, -500, 500)
    player.offsetY = NormalizeNumber(player.offsetY, -11, -500, 500)
    player.color = EnsureLocatorColor(player.color, { r = 0.20, g = 1.00, b = 0.35, a = 0.95 })

    locator.cursor = locator.cursor or {}
    local cursor = locator.cursor
    if cursor.enabled == nil then cursor.enabled = false end
    if cursor.combatOnly == nil then cursor.combatOnly = false end
    if cursor.dot == nil then cursor.dot = false end
    if cursor.pulse == nil then cursor.pulse = false end
    if cursor.classColor == nil then cursor.classColor = false end
    if cursor.spin == nil then cursor.spin = false end
    if cursor.trail == nil then cursor.trail = false end
    if cursor.crosshair == nil then cursor.crosshair = false end
    cursor.size = NormalizeNumber(cursor.size, 52, 24, 160)
    cursor.thickness = NormalizeNumber(cursor.thickness, 3, 1, 12)
    cursor.outline = NormalizeNumber(cursor.outline, 2, 0, 6)
    cursor.color = EnsureLocatorColor(cursor.color, { r = 1.00, g = 0.82, b = 0.20, a = 0.95 })

    return locator
end

local function RefreshPersonalLocator()
    if addon.RefreshPersonalLocator then addon:RefreshPersonalLocator() end
end

local function RefreshTrackerPanels()
    if addon.MarkPanelsDirty then addon:MarkPanelsDirty() end
    if addon.UpdateAllPanels then addon:UpdateAllPanels() end
end

local function GetSpecName(specID)
    if specNameCache[specID] then return specNameCache[specID] end
    for classID = 1, 13 do
        local numSpecs = GetNumSpecializationsForClassID(classID)
        for specIndex = 1, numSpecs do
            local id, name = GetSpecializationInfoForClassID(classID, specIndex)
            if id then specNameCache[id] = name end
        end
    end
    return specNameCache[specID] or ("Spec " .. specID)
end

-- Return panel IDs in stable numeric order.
local function GetSortedPanelIDs()
    local ids = {}
    for id in pairs(addon.Enrage.db.profile.panels) do
        table.insert(ids, id)
    end
    table.sort(ids, function(a, b) return tonumber(a) < tonumber(b) end)
    return ids
end

-- Build class and spell toggle groups for a panel.
local function BuildSpellToggles(panelID, startOrder)
    local args = {}
    local order = startOrder

    for _, classToken in ipairs(addon.ClassOrder) do
        local classSpells = addon.SpellsByClass[classToken]
        if classSpells and #classSpells > 0 then
            local className = addon.ClassNames[classToken] or classToken
            local classColor = RAID_CLASS_COLORS[classToken]
            local coloredName = classColor
                and ("|c" .. classColor.colorStr .. className .. "|r")
                or className

            local classGroup = {
                name = coloredName,
                type = "group",
                order = order,
                args = {},
            }

            local specGroups = {}
            local specIDs = {}
            for _, spellID in ipairs(classSpells) do
                local info = addon.RaidCDData[spellID]
                local spec = info.spec
                if not specGroups[spec] then
                    specGroups[spec] = {}
                    table.insert(specIDs, spec)
                end
                table.insert(specGroups[spec], spellID)
            end
            table.sort(specIDs, function(a, b)
                if a == 0 then return false end
                if b == 0 then return true end
                return a < b
            end)

            local argOrder = 1
            for _, specID in ipairs(specIDs) do
                local headerName = specID == 0 and "Shared / All Specs" or GetSpecName(specID)
                classGroup.args["header_" .. specID] = {
                    name = headerName,
                    type = "header",
                    order = argOrder,
                }
                argOrder = argOrder + 1

                for _, spellID in ipairs(specGroups[specID]) do
                    local info = addon.RaidCDData[spellID]
                    local spellName = C_Spell.GetSpellName(spellID) or info.name
                    local pid = panelID  -- closure capture

                    classGroup.args["spell_" .. spellID] = {
                        name = spellName .. "  |cff888888(" .. info.baseCD .. "s CD)|r",
                        desc = "SpellID: " .. spellID,
                        type = "toggle",
                        order = argOrder,
                        width = "full",
                        get = function()
                            local p = addon.Enrage.db.profile.panels[pid]
                            return p and p.trackedSpells[spellID]
                        end,
                        set = function(_, val)
                            local p = addon.Enrage.db.profile.panels[pid]
                            if p then
                                p.trackedSpells[spellID] = val
                                RefreshTrackerPanels()
                            end
                        end,
                    }
                    argOrder = argOrder + 1
                end
            end

            args["class_" .. classToken] = classGroup
            order = order + 1
        end
    end

    return args
end

local function BuildOptions()
    local db = addon.Enrage.db.profile
    if db.headerMouseover == nil then db.headerMouseover = false end
    db.readyCheckHelper = db.readyCheckHelper or {}
    if db.readyCheckHelper.enabled == nil then db.readyCheckHelper.enabled = false end
    if db.readyCheckHelper.locked == nil then db.readyCheckHelper.locked = false end
    db.readyCheckHelper.point = db.readyCheckHelper.point or "CENTER"
    db.readyCheckHelper.relPoint = db.readyCheckHelper.relPoint or "CENTER"
    db.readyCheckHelper.xOfs = db.readyCheckHelper.xOfs or 0
    db.readyCheckHelper.yOfs = db.readyCheckHelper.yOfs or 150
    db.piAlert = db.piAlert or {}
    if db.piAlert.enabled == nil then db.piAlert.enabled = false end
    if db.piAlert.screen == nil then db.piAlert.screen = false end
    if db.piAlert.sound == nil then db.piAlert.sound = false end
    db.piAlert.soundStyle = NormalizePISoundStyle(db.piAlert.soundStyle)
    db.piAlert.soundVolume = NormalizePISoundVolume(db.piAlert.soundVolume)
    if db.piAlert.message == nil or db.piAlert.message == "" then db.piAlert.message = "you have pi" end
    if db.piAlert.throttle == nil then db.piAlert.throttle = 2 end
    db.singleButtonAssistantKeybind = db.singleButtonAssistantKeybind or {}
    do
        local sba = db.singleButtonAssistantKeybind
        -- Split the old single 'enabled' (which did BOTH hide-arrow + show-keybind) into two
        -- independent toggles, once. Fresh installs default both off.
        if sba.hideArrow == nil and sba.showKeybind == nil and sba.enabled ~= nil then
            sba.hideArrow = sba.enabled
            sba.showKeybind = sba.enabled
        end
        if sba.hideArrow == nil then sba.hideArrow = false end
        if sba.showKeybind == nil then sba.showKeybind = false end
    end
    local actionBarMouseover = EnsureActionBarMouseoverDB(db)
    local personalLocator = EnsurePersonalLocatorDB(db)

    local options = {
        name = "AkcQOL",
        type = "group",
        childGroups = "tree",
        args = {
            general = {
                name = "General",
                type = "group",
                order = 1,
                args = {
                    enabled = {
                        name = "Enable Tracker",
                        desc = "Toggle only the Raid CD tracker panels on/off. Other AkcQOL features keep their own independent settings.",
                        type = "toggle",
                        order = 1,
                        width = "full",
                        get = function() return db.enabled end,
                        set = function(_, val)
                            db.enabled = val
                            if val then
                                if addon.CreateDisplay then addon:CreateDisplay() end
                                RefreshTrackerPanels()
                            else
                                if addon.HideDisplay then addon:HideDisplay() end
                            end
                        end,
                    },
                    showSpellName = {
                        name = "Show Spell Name",
                        desc = "Show spell name next to player name on bars.",
                        type = "toggle",
                        order = 2,
                        get = function() return db.showSpellName end,
                        set = function(_, val)
                            db.showSpellName = val
                            RefreshTrackerPanels()
                        end,
                    },
                    showSelf = {
                        name = "Show My Cooldowns",
                        desc = "Show your own cooldowns on the tracker.",
                        type = "toggle",
                        order = 3,
                        get = function() return db.showSelf end,
                        set = function(_, val)
                            db.showSelf = val
                            RefreshTrackerPanels()
                        end,
                    },
                    showOutsideRaid = {
                        name = "Show Outside Raid/Party",
                        desc = "Show panels even when not in a group.",
                        type = "toggle",
                        order = 4,
                        get = function() return db.showOutsideRaid end,
                        set = function(_, val)
                            db.showOutsideRaid = val
                            RefreshTrackerPanels()
                        end,
                    },
                    headerMouseover = {
                        name = "Show Headers On Mouseover",
                        desc = "Panel headers stay hidden until you hover over them.",
                        type = "toggle",
                        order = 5,
                        width = "full",
                        get = function() return db.headerMouseover end,
                        set = function(_, val)
                            db.headerMouseover = val
                            if addon.UpdateFrameLock then addon:UpdateFrameLock() end
                        end,
                    },
                    assistantKeybindHeader = {
                        name = "Single-Button Assistant",
                        type = "header",
                        order = 10,
                    },
                    assistantDesc = {
                        name = "WoW's Assisted Combat suggests your next ability. To use it: press |cffffd100P|r to open your spellbook, then drag the Assisted Combat icon (top-right of that window) onto an action bar. This add-on can then tidy up that suggestion:",
                        type = "description",
                        order = 10.5,
                        fontSize = "medium",
                    },
                    assistantHideArrow = {
                        name = "Hide Suggestion Arrow",
                        desc = "Remove the moving arrow / glow that WoW draws over the currently-suggested ability.",
                        type = "toggle",
                        order = 11,
                        width = "full",
                        get = function() return db.singleButtonAssistantKeybind.hideArrow end,
                        set = function(_, val)
                            db.singleButtonAssistantKeybind.hideArrow = val
                            if addon.RefreshSingleButtonAssistantKeybind then
                                addon.RefreshSingleButtonAssistantKeybind()
                            end
                        end,
                    },
                    assistantShowKeybind = {
                        name = "Show Suggested Keybind",
                        desc = "Show the keybind of the currently-suggested ability over its action button (the normal hotkey text is hidden while it is active).",
                        type = "toggle",
                        order = 12,
                        width = "full",
                        get = function() return db.singleButtonAssistantKeybind.showKeybind end,
                        set = function(_, val)
                            db.singleButtonAssistantKeybind.showKeybind = val
                            if addon.RefreshSingleButtonAssistantKeybind then
                                addon.RefreshSingleButtonAssistantKeybind()
                            end
                        end,
                    },
                    addPanel = {
                        name = "Add New Panel",
                        desc = "Create a new panel to track a different set of cooldowns.",
                        type = "execute",
                        order = 6,
                        func = function()
                            addon:CreateNewPanel()
                        end,
                    },
                    readyCheckHeader = {
                        name = "Ready Check Helper",
                        type = "header",
                        order = 20,
                    },
                    readyCheckEnabled = {
                        name = "Enable Ready Check Helper",
                        desc = "Show a checklist while a ready check is active.",
                        type = "toggle",
                        order = 21,
                        width = "full",
                        get = function() return db.readyCheckHelper.enabled end,
                        set = function(_, val)
                            db.readyCheckHelper.enabled = val
                            if val then
                                if addon.InitializeReadyCheckHelper then
                                    addon:InitializeReadyCheckHelper()
                                end
                            elseif addon.DisableReadyCheckHelper then
                                addon:DisableReadyCheckHelper()
                            elseif addon.HideReadyCheckHelper then
                                addon:HideReadyCheckHelper()
                            end
                        end,
                    },
                    readyCheckLocked = {
                        name = "Lock Ready Check Helper",
                        desc = "Prevent the ready check helper from being dragged.",
                        type = "toggle",
                        order = 22,
                        get = function() return db.readyCheckHelper.locked end,
                        set = function(_, val)
                            db.readyCheckHelper.locked = val
                            if addon.UpdateReadyCheckHelperLock then
                                addon:UpdateReadyCheckHelperLock()
                            end
                        end,
                    },
                    readyCheckTest = {
                        name = "Test Ready Check Panel",
                        desc = "Show the helper briefly so you can place it.",
                        type = "execute",
                        order = 23,
                        func = function()
                            if addon.TestReadyCheckHelper then addon:TestReadyCheckHelper() end
                        end,
                    },
                    readyCheckReset = {
                        name = "Reset Ready Check Position",
                        type = "execute",
                        order = 24,
                        func = function()
                            if addon.ResetReadyCheckHelperPosition then addon:ResetReadyCheckHelperPosition() end
                        end,
                    },
                    piAlertHeader = {
                        name = "Power Infusion Alert",
                        type = "header",
                        order = 30,
                    },
                    piAlertEnabled = {
                        name = "Enable PI Alert",
                        desc = "Alert when Power Infusion is applied to you.",
                        type = "toggle",
                        order = 31,
                        width = "full",
                        get = function() return db.piAlert.enabled end,
                        set = function(_, val)
                            db.piAlert.enabled = val
                            if val and addon.InitializePIAlert then addon:InitializePIAlert() end
                            if not val and addon.DisablePIAlert then addon:DisablePIAlert() end
                        end,
                    },
                    piAlertScreen = {
                        name = "Show Screen Text",
                        desc = "Show the configured PI message in the middle of the screen.",
                        type = "toggle",
                        order = 32,
                        get = function() return db.piAlert.screen end,
                        set = function(_, val) db.piAlert.screen = val end,
                    },
                    piAlertSound = {
                        name = "Play PI Sound",
                        desc = "Play a short sound with the PI alert.",
                        type = "toggle",
                        order = 33,
                        get = function() return db.piAlert.sound end,
                        set = function(_, val) db.piAlert.sound = val end,
                    },
                    piAlertSoundStyle = {
                        name = function()
                            local cur = NormalizePISoundStyle(db.piAlert.soundStyle)
                            local label = (addon.GetSoundLabel and addon:GetSoundLabel(cur)) or cur
                            return "PI Sound:  |cffffd100" .. label .. "|r"
                        end,
                        desc = "Click to pick from WoW's full categorized sound menu (Alerts, Instruments, Animals, Impacts, Warcraft 3/2, Devices). Selecting a sound previews it.",
                        type = "execute",
                        order = 34,
                        width = 2.5,
                        func = function()
                            if addon.OpenSoundAlertMenu then
                                addon:OpenSoundAlertMenu(
                                    function() return NormalizePISoundStyle(db.piAlert.soundStyle) end,
                                    function(key)
                                        db.piAlert.soundStyle = NormalizePISoundStyle(key)
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                                    end,
                                    function() return db.piAlert.soundVolume end)
                            end
                        end,
                    },
                    piAlertVolume = {
                        name = "Volume (%)",
                        desc = "How loud the PI alert plays. 100% briefly boosts your Master volume to the maximum for the alert, then restores it. Use \"Test PI Sound + Text\" to preview.",
                        type = "range",
                        order = 35,
                        width = 2.5,
                        min = 0, max = 100, step = 5,
                        get = function() return NormalizePISoundVolume(db.piAlert.soundVolume) end,
                        set = function(_, val) db.piAlert.soundVolume = NormalizePISoundVolume(val) end,
                    },
                    piAlertMessage = {
                        name = "Screen Text",
                        desc = "Text shown by the PI alert.",
                        type = "input",
                        order = 36,
                        width = 2.5,
                        get = function() return db.piAlert.message end,
                        set = function(_, val)
                            db.piAlert.message = (val and val ~= "") and val or "you have pi"
                        end,
                    },
                    piAlertTest = {
                        name = "Test PI Sound + Text",
                        desc = "Play the selected PI sound and show the PI text.",
                        type = "execute",
                        order = 37,
                        func = function()
                            if addon.TestPIAlert then addon:TestPIAlert() end
                        end,
                    },
                },
            },
        },
    }

    local actionBarArgs = {
        enabled = {
            name = "Enable Action Bar Mouseover",
            desc = "Fade selected Blizzard action bars until your mouse is over them.",
            type = "toggle",
            order = 1,
            width = "full",
            get = function() return actionBarMouseover.enabled end,
            set = function(_, val)
                actionBarMouseover.enabled = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        restoreDefaults = {
            name = "Restore Defaults",
            type = "execute",
            order = 100,
            width = "full",
            confirm = true,
            confirmText = "Reset all Action Bar Mouseover settings to defaults?",
            func = function()
                wipe(actionBarMouseover)
                EnsureActionBarMouseoverDB(db)
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
                LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
            end,
        },
        minAlpha = {
            name = "Hidden Alpha",
            desc = "Alpha used when the bar is not hovered.",
            type = "range",
            order = 2,
            min = 0, max = 1, step = 0.05,
            get = function() return NormalizeAlpha(actionBarMouseover.minAlpha, 0) end,
            set = function(_, val)
                actionBarMouseover.minAlpha = NormalizeAlpha(val, 0)
                if actionBarMouseover.maxAlpha < actionBarMouseover.minAlpha then
                    actionBarMouseover.maxAlpha = actionBarMouseover.minAlpha
                end
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        maxAlpha = {
            name = "Visible Alpha",
            desc = "Alpha used when the bar is hovered or forced visible.",
            type = "range",
            order = 3,
            min = 0, max = 1, step = 0.05,
            get = function() return NormalizeAlpha(actionBarMouseover.maxAlpha, 1) end,
            set = function(_, val)
                actionBarMouseover.maxAlpha = NormalizeAlpha(val, 1)
                if actionBarMouseover.maxAlpha < actionBarMouseover.minAlpha then
                    actionBarMouseover.maxAlpha = actionBarMouseover.minAlpha
                end
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        hoverDelay = {
            name = "Mouse Leave Delay",
            desc = "Keeps selected bars visible briefly after the mouse leaves, so flyout menus can be selected.",
            type = "range",
            order = 4,
            min = 0, max = 2, step = 0.05,
            get = function() return NormalizeNumber(actionBarMouseover.hoverDelay, 0.7, 0, 2) end,
            set = function(_, val)
                actionBarMouseover.hoverDelay = NormalizeNumber(val, 0.7, 0, 2)
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        alwaysShowInCombat = {
            name = "Keep Visible In Combat",
            desc = "Selected bars stay fully visible while you are in combat.",
            type = "toggle",
            order = 5,
            width = "full",
            get = function() return actionBarMouseover.alwaysShowInCombat end,
            set = function(_, val)
                actionBarMouseover.alwaysShowInCombat = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        alwaysShowInEditMode = {
            name = "Keep Visible In Edit Mode",
            desc = "Selected bars stay fully visible while Blizzard Edit Mode is open.",
            type = "toggle",
            order = 6,
            width = "full",
            get = function() return actionBarMouseover.alwaysShowInEditMode end,
            set = function(_, val)
                actionBarMouseover.alwaysShowInEditMode = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        },
        barsHeader = {
            name = "Bars",
            type = "header",
            order = 10,
        },
    }

    local barOrder = 11
    for _, def in ipairs(ACTION_BAR_MOUSEOVER_BARS) do
        local key = def.key
        actionBarArgs["bar_" .. key] = {
            name = def.name,
            type = "toggle",
            order = barOrder,
            get = function() return actionBarMouseover.bars[key] end,
            set = function(_, val)
                actionBarMouseover.bars[key] = val
                if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            end,
        }
        barOrder = barOrder + 1
    end

    actionBarArgs.resetAlpha = {
        name = "Reset Bars",
        desc = "Uncheck all selected bars and return bars touched by this feature to full alpha.",
        type = "execute",
        order = 30,
        func = function()
            if addon.DisableActionBarMouseover then addon:DisableActionBarMouseover() end
            for _, def in ipairs(ACTION_BAR_MOUSEOVER_BARS) do
                actionBarMouseover.bars[def.key] = false
            end
            if addon.RefreshActionBarMouseover then addon:RefreshActionBarMouseover() end
            LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
        end,
    }

    -- Addon Users panel
    options.args.addonUsers = {
        name = "Addon Users",
        type = "group",
        order = 2,
        args = {},
    }

    options.args.actionBarMouseover = {
        name = "Action Bar Mouseover",
        type = "group",
        order = 3,
        args = actionBarArgs,
    }

    options.args.personalLocator = {
        name = "Personal Locator",
        type = "group",
        order = 4,
        args = {
            description = {
                name = "A lightweight screen-space character marker and mouse halo. Both are click-through, combat-safe, and independently configurable.",
                type = "description",
                order = 1,
                fontSize = "medium",
            },
            preview = {
                name = "Preview Both (8 Seconds)",
                desc = "Temporarily show the current character marker and mouse circle without changing their enabled settings.",
                type = "execute",
                order = 2,
                width = "full",
                func = function()
                    if addon.PreviewPersonalLocator then addon:PreviewPersonalLocator() end
                end,
            },
            restoreDefaults = {
                name = "Restore Defaults",
                type = "execute",
                order = 100,
                width = "full",
                confirm = true,
                confirmText = "Reset all Personal Locator settings to defaults?",
                func = function()
                    wipe(personalLocator)
                    EnsurePersonalLocatorDB(db)
                    RefreshPersonalLocator()
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                end,
            },
            playerHeader = {
                name = "Where I Am — Character Marker",
                type = "header",
                order = 10,
            },
            playerEnabled = {
                name = "Enable Character Marker",
                desc = "Show an adjustable marker over your character's screen position.",
                type = "toggle",
                order = 11,
                width = "full",
                get = function() return personalLocator.player.enabled end,
                set = function(_, val)
                    personalLocator.player.enabled = val
                    RefreshPersonalLocator()
                end,
            },
            playerCombatOnly = {
                name = "Character Marker: Combat Only",
                type = "toggle",
                order = 12,
                width = "full",
                get = function() return personalLocator.player.combatOnly end,
                set = function(_, val)
                    personalLocator.player.combatOnly = val
                    RefreshPersonalLocator()
                end,
            },
            playerStyle = {
                name = "Marker Style",
                type = "select",
                order = 13,
                values = {
                    crosshair = "Crosshair",
                    brackets = "Target Brackets",
                    beacon = "Downward Beacon",
                    ring = "Ground Ring",
                },
                get = function() return personalLocator.player.style end,
                set = function(_, val)
                    personalLocator.player.style = val
                    RefreshPersonalLocator()
                end,
            },
            playerClassColor = {
                name = "Use Class Color",
                desc = "Color the marker with your class color. Overrides the manual color below (alpha is kept).",
                type = "toggle",
                order = 13.3,
                get = function() return personalLocator.player.classColor end,
                set = function(_, val)
                    personalLocator.player.classColor = val
                    RefreshPersonalLocator()
                end,
            },
            playerColor = {
                name = "Marker Color",
                type = "color",
                order = 14,
                hasAlpha = true,
                disabled = function() return personalLocator.player.classColor end,
                get = function()
                    local c = personalLocator.player.color
                    return c.r, c.g, c.b, c.a
                end,
                set = function(_, r, g, b, a)
                    local c = personalLocator.player.color
                    c.r, c.g, c.b, c.a = r, g, b, a
                    RefreshPersonalLocator()
                end,
            },
            playerPulse = {
                name = "Pulse Animation",
                desc = "Gently breathe the marker in and out so it stays easy to spot.",
                type = "toggle",
                order = 14.3,
                get = function() return personalLocator.player.pulse end,
                set = function(_, val)
                    personalLocator.player.pulse = val
                    RefreshPersonalLocator()
                end,
            },
            playerSpin = {
                name = "Spin Animation",
                desc = "Slowly rotate the marker. Best with the Ground Ring and Target Brackets styles.",
                type = "toggle",
                order = 14.4,
                get = function() return personalLocator.player.spin end,
                set = function(_, val)
                    personalLocator.player.spin = val
                    RefreshPersonalLocator()
                end,
            },
            playerSize = {
                name = "Marker Size",
                type = "range",
                order = 15,
                min = 20, max = 160, step = 2,
                get = function() return personalLocator.player.size end,
                set = function(_, val)
                    personalLocator.player.size = val
                    RefreshPersonalLocator()
                end,
            },
            playerThickness = {
                name = "Line Thickness",
                type = "range",
                order = 16,
                min = 1, max = 12, step = 1,
                get = function() return personalLocator.player.thickness end,
                set = function(_, val)
                    personalLocator.player.thickness = val
                    RefreshPersonalLocator()
                end,
            },
            playerOutline = {
                name = "Black Outline",
                type = "range",
                order = 17,
                min = 0, max = 6, step = 1,
                get = function() return personalLocator.player.outline end,
                set = function(_, val)
                    personalLocator.player.outline = val
                    RefreshPersonalLocator()
                end,
            },
            playerGap = {
                name = "Center Gap",
                desc = "Empty space at the center of Crosshair and Beacon styles.",
                type = "range",
                order = 18,
                min = 0, max = 40, step = 1,
                get = function() return personalLocator.player.gap end,
                set = function(_, val)
                    personalLocator.player.gap = val
                    RefreshPersonalLocator()
                end,
            },
            playerOffsetX = {
                name = "Horizontal Offset",
                desc = "Move the marker left or right from screen center.",
                type = "range",
                order = 19,
                min = -300, max = 300, step = 1,
                get = function() return personalLocator.player.offsetX end,
                set = function(_, val)
                    personalLocator.player.offsetX = val
                    RefreshPersonalLocator()
                end,
            },
            playerOffsetY = {
                name = "Vertical Offset",
                desc = "Move the marker up or down until it matches your camera and character position.",
                type = "range",
                order = 20,
                min = -300, max = 300, step = 1,
                get = function() return personalLocator.player.offsetY end,
                set = function(_, val)
                    personalLocator.player.offsetY = val
                    RefreshPersonalLocator()
                end,
            },
            cursorHeader = {
                name = "Mouse Circle",
                type = "header",
                order = 30,
            },
            cursorEnabled = {
                name = "Enable Mouse Circle",
                desc = "Show a smooth, click-through halo around the hardware cursor.",
                type = "toggle",
                order = 31,
                width = "full",
                get = function() return personalLocator.cursor.enabled end,
                set = function(_, val)
                    personalLocator.cursor.enabled = val
                    RefreshPersonalLocator()
                end,
            },
            cursorCombatOnly = {
                name = "Mouse Circle: Combat Only",
                type = "toggle",
                order = 32,
                width = "full",
                get = function() return personalLocator.cursor.combatOnly end,
                set = function(_, val)
                    personalLocator.cursor.combatOnly = val
                    RefreshPersonalLocator()
                end,
            },
            cursorClassColor = {
                name = "Use Class Color",
                desc = "Color the cursor circle with your class color. Overrides the manual color below (alpha is kept).",
                type = "toggle",
                order = 32.5,
                get = function() return personalLocator.cursor.classColor end,
                set = function(_, val)
                    personalLocator.cursor.classColor = val
                    RefreshPersonalLocator()
                end,
            },
            cursorColor = {
                name = "Circle Color",
                type = "color",
                order = 33,
                hasAlpha = true,
                disabled = function() return personalLocator.cursor.classColor end,
                get = function()
                    local c = personalLocator.cursor.color
                    return c.r, c.g, c.b, c.a
                end,
                set = function(_, r, g, b, a)
                    local c = personalLocator.cursor.color
                    c.r, c.g, c.b, c.a = r, g, b, a
                    RefreshPersonalLocator()
                end,
            },
            cursorSize = {
                name = "Circle Size",
                type = "range",
                order = 34,
                min = 24, max = 160, step = 2,
                get = function() return personalLocator.cursor.size end,
                set = function(_, val)
                    personalLocator.cursor.size = val
                    RefreshPersonalLocator()
                end,
            },
            cursorThickness = {
                name = "Circle Thickness",
                type = "range",
                order = 35,
                min = 1, max = 12, step = 1,
                get = function() return personalLocator.cursor.thickness end,
                set = function(_, val)
                    personalLocator.cursor.thickness = val
                    RefreshPersonalLocator()
                end,
            },
            cursorOutline = {
                name = "Circle Outline",
                type = "range",
                order = 36,
                min = 0, max = 6, step = 1,
                get = function() return personalLocator.cursor.outline end,
                set = function(_, val)
                    personalLocator.cursor.outline = val
                    RefreshPersonalLocator()
                end,
            },
            cursorDot = {
                name = "Show Center Dot",
                type = "toggle",
                order = 37,
                get = function() return personalLocator.cursor.dot end,
                set = function(_, val)
                    personalLocator.cursor.dot = val
                    RefreshPersonalLocator()
                end,
            },
            cursorPulse = {
                name = "Soft Pulse",
                desc = "Apply a subtle alpha pulse to make the cursor easier to recover in visual clutter.",
                type = "toggle",
                order = 38,
                get = function() return personalLocator.cursor.pulse end,
                set = function(_, val)
                    personalLocator.cursor.pulse = val
                    RefreshPersonalLocator()
                end,
            },
            cursorSpin = {
                name = "Spin Animation",
                desc = "Slowly rotate the cursor ring for a lively, easy-to-track halo.",
                type = "toggle",
                order = 39,
                get = function() return personalLocator.cursor.spin end,
                set = function(_, val)
                    personalLocator.cursor.spin = val
                    RefreshPersonalLocator()
                end,
            },
            cursorTrail = {
                name = "Motion Trail",
                desc = "Leave a short fading trail of soft dots behind the cursor as it moves — great for finding the pointer fast.",
                type = "toggle",
                order = 40,
                get = function() return personalLocator.cursor.trail end,
                set = function(_, val)
                    personalLocator.cursor.trail = val
                    RefreshPersonalLocator()
                end,
            },
            cursorCrosshair = {
                name = "Precision Crosshair",
                desc = "Add thin cross lines through the cursor center for precise aiming.",
                type = "toggle",
                order = 41,
                get = function() return personalLocator.cursor.crosshair end,
                set = function(_, val)
                    personalLocator.cursor.crosshair = val
                    RefreshPersonalLocator()
                end,
            },
        },
    }

    local userOrder = 1
    local myName = UnitName("player")
    local _, myClass = UnitClass("player")
    local myColor = RAID_CLASS_COLORS[myClass]
    local myColored = myColor and ("|c" .. myColor.colorStr .. myName .. "|r") or myName
    options.args.addonUsers.args["user_self"] = {
        name = myColored .. "  |cff00ff00(you)|r",
        type = "description",
        order = userOrder,
        fontSize = "medium",
    }
    userOrder = userOrder + 1

    for name, info in pairs(addon.Roster) do
        local color = RAID_CLASS_COLORS[info.class]
        local colored = color and ("|c" .. color.colorStr .. name .. "|r") or name
        options.args.addonUsers.args["user_" .. name] = {
            name = colored,
            type = "description",
            order = userOrder,
            fontSize = "medium",
        }
        userOrder = userOrder + 1
    end

    if userOrder == 2 then
        options.args.addonUsers.args.noUsers = {
            name = "|cff888888No other addon users detected.|r",
            type = "description",
            order = 2,
            fontSize = "medium",
        }
    end

    -- Per-panel groups
    local sortedIDs = GetSortedPanelIDs()
    local panelOrder = 10

    for _, panelID in ipairs(sortedIDs) do
        local panelDB = db.panels[panelID]
        if panelDB then
            if panelDB.headerVisible == nil then panelDB.headerVisible = false end
            local pid = panelID  -- closure capture

            local panelGroup = {
                name = panelDB.name,
                type = "group",
                childGroups = "tree",
                order = panelOrder,
                args = {
                    panelName = {
                        name = "Panel Name",
                        type = "input",
                        order = 1,
                        width = "full",
                        get = function() return db.panels[pid].name end,
                        set = function(_, val)
                            db.panels[pid].name = val
                            addon:RefreshPanelTitle(pid)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                        end,
                    },
                    locked = {
                        name = "Lock Panel",
                        desc = "Lock this panel so it cannot be dragged.",
                        type = "toggle",
                        order = 2,
                        get = function() return db.panels[pid].locked end,
                        set = function(_, val)
                            db.panels[pid].locked = val
                            addon:UpdatePanelFrameLock(pid)
                        end,
                    },
                    headerVisible = {
                        name = "Header Visible",
                        desc = "Keep this panel header visible instead of showing it only on mouseover.",
                        type = "toggle",
                        order = 3,
                        get = function() return db.panels[pid].headerVisible end,
                        set = function(_, val)
                            db.panels[pid].headerVisible = val
                            addon:UpdatePanelFrameLock(pid)
                        end,
                    },
                    barWidth = {
                        name = "Bar Width",
                        type = "range",
                        order = 4,
                        min = 100, max = 400, step = 5,
                        get = function() return db.panels[pid].barWidth end,
                        set = function(_, val)
                            db.panels[pid].barWidth = val
                            RefreshTrackerPanels()
                        end,
                    },
                    barHeight = {
                        name = "Bar Height",
                        type = "range",
                        order = 5,
                        min = 12, max = 40, step = 1,
                        get = function() return db.panels[pid].barHeight end,
                        set = function(_, val)
                            db.panels[pid].barHeight = val
                            RefreshTrackerPanels()
                        end,
                    },
                    resetPosition = {
                        name = "Reset Position",
                        type = "execute",
                        order = 6,
                        func = function() addon:ResetPosition(pid) end,
                    },
                    removePanel = {
                        name = "|cffff4444Remove Panel|r",
                        desc = "Delete this panel permanently.",
                        type = "execute",
                        order = 7,
                        confirm = true,
                        confirmText = "Are you sure you want to delete \"" .. panelDB.name .. "\"?",
                        func = function() addon:RemovePanel(pid) end,
                    },
                },
            }

            -- Spell toggle groups for this panel
            local spellArgs = BuildSpellToggles(pid, 10)
            for k, v in pairs(spellArgs) do
                panelGroup.args[k] = v
            end

            options.args["panel_" .. panelID] = panelGroup
            panelOrder = panelOrder + 1
        end
    end

    -- Unified menu: merge the QoL groups (Automation/Display/HUD) defined in
    -- EnrageBridge.lua into this tree so the whole settings panel is one menu.
    -- Their closures live in EnrageBridge (where the side-effect helpers are in
    -- scope); negative order values sort them above the original groups.
    if _G.EnrageQoLSettingsGroups then
        for k, v in pairs(_G.EnrageQoLSettingsGroups) do
            options.args[k] = v
        end
    end

    -- The old "General" group bundled the Raid CD tracker together with three STILL-ACTIVE
    -- features: Power Infusion Alert, the Ready Check / Food Buff helper, and the
    -- Single-Button Assistant keybind text. Lift those three out into their own top-level
    -- groups so they survive the Raid CD removal — only the tracker's own controls (Enable
    -- Tracker, Add New Panel, Show My Cooldowns, ...) disappear with the group below.
    local gen = options.args.general and options.args.general.args
    if gen then
        options.args.piAlert = {
            name = "Power Infusion Alert", type = "group",
            args = {
                piAlertHeader    = gen.piAlertHeader,
                piAlertEnabled   = gen.piAlertEnabled,
                piAlertScreen    = gen.piAlertScreen,
                piAlertSound     = gen.piAlertSound,
                piAlertSoundStyle = gen.piAlertSoundStyle,
                piAlertVolume    = gen.piAlertVolume,
                piAlertMessage   = gen.piAlertMessage,
                piAlertTest      = gen.piAlertTest,
            },
        }
        options.args.readyCheck = {
            name = "Ready Check Helper", type = "group",
            args = {
                readyCheckHeader  = gen.readyCheckHeader,
                readyCheckEnabled = gen.readyCheckEnabled,
                readyCheckLocked  = gen.readyCheckLocked,
                readyCheckTest    = gen.readyCheckTest,
                readyCheckReset   = gen.readyCheckReset,
            },
        }
        options.args.assistant = {
            name = "Single-Button Assistant", type = "group",
            args = {
                assistantKeybindHeader  = gen.assistantKeybindHeader,
                assistantDesc           = gen.assistantDesc,
                assistantHideArrow      = gen.assistantHideArrow,
                assistantShowKeybind    = gen.assistantShowKeybind,
            },
        }
    end

    -- Raid CD cooldown tracker removed from the UI: drop its "General" settings group
    -- and every per-panel group ("panel_<id>") so they no longer appear in the menu.
    options.args.general = nil
    options.args.raidCooldowns = nil
    for k in pairs(options.args) do
        if type(k) == "string" and k:sub(1, 6) == "panel_" then
            options.args[k] = nil
        end
    end

    -- Landing page: a tidy "Overview" node that opens first and frames the addon.
    options.args.overview = {
        name = "Overview",
        type = "group",
        args = {
            title = {
                name = "|cff8c5cffAkc|r|cffffffffQOL|r  —  Quality of Life",
                type = "header",
                order = 1,
            },
            blurb = {
                name = "A unified quality-of-life toolkit. Everything is configured from this one panel:"
                    .. " automation, display tweaks, the HUD, action-bar mouseover, a personal locator,"
                    .. " and Blizzard damage-meter visibility. Pick a section on the left to begin.",
                type = "description",
                fontSize = "medium",
                order = 2,
            },
            cmdHeader = {
                name = "Slash Commands",
                type = "header",
                order = 10,
            },
            cmds = {
                name = "|cffffd100/akc|r        Open the main matrix window\n"
                    .. "|cffffd100/akctalent|r   Open talent builds\n"
                    .. "|cffffd100/akcsettings|r  Open these settings",
                type = "description",
                fontSize = "medium",
                order = 11,
            },
            -- WV: Warvideo integration status. AkcQOL force-enables combat logging (and the
            -- advancedCombatLogging CVar) so Warvideo's macOS app can auto-capture boss HP /
            -- wipe%. This row reports the live logging state; it refreshes each time the panel
            -- opens. No separate "Warvideo Companion" addon is needed.
            wvHeader = {
                name = "Warvideo",
                type = "header",
                order = 20,
            },
            wvStatus = {
                name = function()
                    local on
                    pcall(function()
                        local v = LoggingCombat and LoggingCombat()
                        if v == nil then return end
                        if issecretvalue and issecretvalue(v) then return end
                        on = v and true or false
                    end)
                    -- Use WoW's built-in indicator textures for the dot: the FRIZQT font has
                    -- no glyph for ● (U+25CF) and renders it as a "missing glyph" box.
                    if on == false then
                        return "|TInterface\\COMMON\\Indicator-Red:14:14|t  Combat logging: |cffff4040KAPALI|r"
                    end
                    -- true, or unreadable (we force it on every world-enter): show AÇIK.
                    return "|TInterface\\COMMON\\Indicator-Green:14:14|t  Combat logging: |cff20ff20AÇIK|r"
                end,
                type = "description",
                fontSize = "medium",
                order = 21,
            },
            wvDesc = {
                name = "Warvideo otomatik kaydı için combat logging açık tutuluyor.",
                type = "description",
                fontSize = "medium",
                order = 22,
            },
            wvSite = {
                name = "Site",
                desc = "Warvideo: combat-log'u otomatik kaydeden macOS uygulaması (bilgi amaçlı; metni seçip kopyalayabilirsin).",
                type = "input",
                order = 23,
                width = "normal",
                get = function() return "warvideo.app" end,
                set = function() end,  -- read-only: shown only so it can be selected and copied
            },
        },
    }

    -- Skyriding ability tracker (Surge Forward / Whirling Surge / Second Wind).
    options.args.skyriding = {
        name = "Skyriding", type = "group",
        args = {
            desc = {
                name = "An on-screen tracker for your skyriding abilities. It appears only while you are on a skyriding mount.",
                type = "description", order = 0.1, fontSize = "medium",
            },
            preview = {
                name = "Preview Tracker (12 Seconds)",
                desc = "Show the tracker on top so you can drag it into place, even while not flying.",
                type = "execute", order = 0.3, width = "full",
                func = function() if _G.Enrage_PreviewSkyriding then _G.Enrage_PreviewSkyriding() end end,
            },
            resetPos = {
                name = "Reset Position (Center)",
                type = "execute", order = 0.4, width = "full",
                func = function() if _G.Enrage_ResetSkyridingPosition then _G.Enrage_ResetSkyridingPosition() end end,
            },
            enabled = {
                name = "Enable Skyriding Tracker", type = "toggle", order = 1, width = "full",
                get = function() local d = EnrageDB and EnrageDB.global and EnrageDB.global.skyriding; return not d or d.enabled ~= false end,
                set = function(_, v)
                    EnrageDB.global.skyriding = EnrageDB.global.skyriding or {}
                    EnrageDB.global.skyriding.enabled = v
                    if _G.Enrage_ApplySkyridingVisibility then _G.Enrage_ApplySkyridingVisibility() end
                end,
            },
            style = {
                name = "Layout", type = "select", order = 2,
                values = { icons = "Icon row", bars = "Compact bars" },
                get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global.skyriding and EnrageDB.global.skyriding.style) or "icons" end,
                set = function(_, v) if _G.Enrage_SetSkyridingStyle then _G.Enrage_SetSkyridingStyle(v) end end,
            },
            scale = {
                name = "Scale", type = "range", order = 3, width = "full",
                min = 0.5, max = 2.0, step = 0.05, isPercent = true,
                get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global.skyriding and EnrageDB.global.skyriding.scale) or 1.0 end,
                set = function(_, v) if _G.Enrage_SetSkyridingScale then _G.Enrage_SetSkyridingScale(v) end end,
            },
            restoreDefaults = {
                name = "Restore Defaults", type = "execute", order = 100, width = "full",
                confirm = true,
                confirmText = "Reset all Skyriding Tracker settings to defaults?",
                func = function()
                    if _G.Enrage_ResetSkyridingDefaults then _G.Enrage_ResetSkyridingDefaults() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                end,
            },
        },
    }

    -- Pet health alert (any class with a pet) — reuses the PI Alert SoundKit list.
    options.args.petAlert = {
        name = "Pet Alert", type = "group",
        args = {
            desc = {
                name = "Plays a sound when your pet's health drops below the threshold. Works for any class with a pet (Hunter, Warlock, Death Knight, ...).",
                type = "description", order = 0.1, fontSize = "medium",
            },
            enabled = {
                name = "Enable Pet Health Alert", type = "toggle", order = 1, width = "full",
                get = function() local d = EnrageDB and EnrageDB.global and EnrageDB.global.petAlert; return not d or d.enabled ~= false end,
                set = function(_, v)
                    EnrageDB.global.petAlert = EnrageDB.global.petAlert or {}
                    EnrageDB.global.petAlert.enabled = v
                    if _G.Enrage_ApplyPetAlert then _G.Enrage_ApplyPetAlert() end
                end,
            },
            threshold = {
                name = "Health Threshold (%)", type = "range", order = 2, width = "full",
                min = 10, max = 95, step = 5,
                get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global.petAlert and EnrageDB.global.petAlert.threshold) or 50 end,
                set = function(_, v)
                    EnrageDB.global.petAlert = EnrageDB.global.petAlert or {}
                    EnrageDB.global.petAlert.threshold = v
                end,
            },
            sound = {
                name = function()
                    local cur = (EnrageDB and EnrageDB.global and EnrageDB.global.petAlert and EnrageDB.global.petAlert.soundStyle) or "bosswarn"
                    local label = (addon.GetSoundLabel and addon:GetSoundLabel(cur)) or cur
                    return "Alert Sound:  |cffffd100" .. label .. "|r"
                end,
                desc = "Click to pick from WoW's full categorized sound menu (Alerts, Instruments, Animals, Impacts, Warcraft 3/2, Devices). Selecting a sound previews it.",
                type = "execute", order = 3, width = 2.5,
                func = function()
                    if addon.OpenSoundAlertMenu then
                        addon:OpenSoundAlertMenu(
                            function() return (EnrageDB and EnrageDB.global and EnrageDB.global.petAlert and EnrageDB.global.petAlert.soundStyle) or "bosswarn" end,
                            function(key)
                                EnrageDB.global.petAlert = EnrageDB.global.petAlert or {}
                                EnrageDB.global.petAlert.soundStyle = key
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                            end,
                            function() return EnrageDB.global.petAlert and EnrageDB.global.petAlert.volume end)
                    end
                end,
            },
            volume = {
                name = "Volume (%)",
                desc = "How loud the pet alert plays. 100% briefly boosts your Master volume to the maximum for the alert, then restores it. Use \"Test Sound\" to preview.",
                type = "range", order = 3.5, width = 2.5,
                min = 0, max = 100, step = 5,
                get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global.petAlert and EnrageDB.global.petAlert.volume) or 100 end,
                set = function(_, v)
                    EnrageDB.global.petAlert = EnrageDB.global.petAlert or {}
                    EnrageDB.global.petAlert.volume = v
                end,
            },
            screen = {
                name = "Show Screen Text",
                desc = "Flash the message below in the middle of the screen when your pet drops low (same as the PI Alert's screen text).",
                type = "toggle", order = 3.6,
                get = function() return EnrageDB and EnrageDB.global and EnrageDB.global.petAlert and EnrageDB.global.petAlert.screen == true end,
                set = function(_, v)
                    EnrageDB.global.petAlert = EnrageDB.global.petAlert or {}
                    EnrageDB.global.petAlert.screen = v
                end,
            },
            message = {
                name = "Screen Text",
                desc = "Text shown in the middle of the screen by the pet alert.",
                type = "input", order = 3.7, width = 2.5,
                get = function() return (EnrageDB and EnrageDB.global and EnrageDB.global.petAlert and EnrageDB.global.petAlert.message) or "pet low hp" end,
                set = function(_, v)
                    EnrageDB.global.petAlert = EnrageDB.global.petAlert or {}
                    EnrageDB.global.petAlert.message = (v and v ~= "") and v or "pet low hp"
                end,
            },
            test = {
                name = "Test Sound + Text", type = "execute", order = 4,
                func = function() if _G.Enrage_TestPetAlert then _G.Enrage_TestPetAlert() end end,
            },
            restoreDefaults = {
                name = "Restore Defaults", type = "execute", order = 100, width = "full",
                confirm = true,
                confirmText = "Reset all Pet Alert settings to defaults?",
                func = function()
                    if _G.Enrage_ResetPetAlertDefaults then _G.Enrage_ResetPetAlertDefaults() end
                    LibStub("AceConfigRegistry-3.0"):NotifyChange("EnrageRaidCD")
                end,
            },
        },
    }

    -- Professional layout: one clean, intentional order + a tree icon for every group,
    -- so the menu reads the same top-to-bottom regardless of where each is defined.
    -- (Groups not listed here keep their own order/icon and are left untouched.)
    local LAYOUT = {
        overview           = { order = 10, icon = "Interface\\Icons\\INV_Misc_Book_09" },
        qolAutomation      = { order = 20, icon = "Interface\\Icons\\Trade_Engineering" },
        qolDisplay         = { order = 30, icon = "Interface\\Icons\\INV_Misc_Spyglass_03" },
        qolHud             = { order = 40, icon = "Interface\\Icons\\INV_Misc_PocketWatch_01" },
        skyriding          = { order = 45, icon = "Interface\\Icons\\Ability_Mount_Drake_Bronze" },
        actionBarMouseover = { order = 50, icon = "Interface\\Icons\\INV_Misc_Gear_08" },
        personalLocator    = { order = 60, icon = "Interface\\Icons\\INV_Misc_Map_01" },
        qolDamageMeter     = { order = 70, icon = "Interface\\Icons\\Ability_Warrior_Trauma" },
        piAlert            = { order = 72, icon = "Interface\\Icons\\Spell_Holy_PowerInfusion" },
        petAlert           = { order = 75, icon = "Interface\\Icons\\Spell_Nature_SpiritWolf" },
        readyCheck         = { order = 77, icon = "Interface\\Icons\\INV_Misc_Food_15" },
        assistant          = { order = 78, icon = "Interface\\Icons\\INV_Misc_Key_03" },
        addonUsers         = { order = 80, icon = "Interface\\Icons\\Achievement_GuildPerk_EverybodysFriend" },
    }
    for key, cfg in pairs(LAYOUT) do
        local g = options.args[key]
        if g then
            g.order = cfg.order
            g.icon = cfg.icon
            g.iconCoords = { 0.08, 0.92, 0.08, 0.92 }  -- trim the default icon border
        end
    end

    return options
end

function addon:SetupConfig()
    local AceConfig = LibStub("AceConfig-3.0")
    AceConfig:RegisterOptionsTable("EnrageRaidCD", BuildOptions)
    -- Registered under the historical "EnrageRaidCD" appName (kept so saved settings and the
    -- in-matrix embed keep working). The panel is shown inside the matrix gear window, not in
    -- ESC > Options > AddOns (AddToBlizOptions is intentionally not used).
end
