-- BankSellFilter: a small coin toggle next to the bank search box. While on,
-- everything that cannot be sold on the Auction House (bound, poor quality)
-- is dimmed so sellable stock pops out. In the 12.x unified bank a single
-- BankPanel serves both the character bank and the Warband bank tabs.
local L = AkcQOL_L

local buttons = {}
local filterOn = {}
local overlays = setmetatable({}, { __mode = "k" })

local function Enabled()
    return AkcQOLDB and AkcQOLDB.global and AkcQOLDB.global.bankSellFilter == true
end

local function IsAuctionable(itemButton)
    local bagID = itemButton.GetBankTabID and itemButton:GetBankTabID()
    local slot = itemButton.GetContainerSlotID and itemButton:GetContainerSlotID()
    if not bagID or not slot then return nil end
    local ok, res = pcall(function()
        local loc = ItemLocation:CreateFromBagAndSlot(bagID, slot)
        if not loc or not C_Item.DoesItemExist(loc) then return nil end
        local q = C_Item.GetItemQuality(loc)
        if q ~= nil and q < 1 then return false end
        -- Warbound-until-equipped reports IsBound=true but IS auctionable.
        if C_Item.IsBoundToAccountUntilEquip and C_Item.IsBoundToAccountUntilEquip(loc) then
            return true
        end
        if C_Item.IsBound(loc) then return false end
        return true
    end)
    if not ok then return nil end
    return res
end

local function HideAllOverlays()
    for _, dim in pairs(overlays) do
        dim:Hide()
    end
end

local function ApplyToButton(itemButton, on)
    local dim = overlays[itemButton]
    if on and IsAuctionable(itemButton) == false then
        if not dim then
            dim = itemButton:CreateTexture(nil, "OVERLAY", nil, 7)
            dim:SetAllPoints()
            dim:SetColorTexture(0, 0, 0, 0.72)
            overlays[itemButton] = dim
        end
        dim:Show()
    elseif dim then
        dim:Hide()
    end
end

local function RefreshPanel(panel)
    if not panel or not panel.EnumerateValidItems then return end
    local on = Enabled() and filterOn[panel] and panel:IsShown()
    -- Pooled buttons get reused across tab switches; start from a clean slate
    -- so no stale dim survives on a button that now shows a different item.
    HideAllOverlays()
    if not on then return end
    pcall(function()
        for itemButton in panel:EnumerateValidItems() do
            ApplyToButton(itemButton, true)
        end
    end)
end

local function FindSearchBox(panel)
    local sb = panel.SearchBox or panel.ItemSearchBox
    if sb then return sb end
    -- 12.x: the search box lives on BankFrame (parentKey BankItemSearchBox),
    -- not on BankPanel itself.
    if panel.GetBankContainerFrame then
        local ok, bf = pcall(panel.GetBankContainerFrame, panel)
        if ok and bf and bf.BankItemSearchBox then return bf.BankItemSearchBox end
    end
    if _G.BankItemSearchBox then return _G.BankItemSearchBox end
    local kids = { panel:GetChildren() }
    for _, k in ipairs(kids) do
        if k.GetObjectType and k:GetObjectType() == "EditBox" then return k end
    end
    return nil
end

-- Anchors left of the search box; if another addon already parked a button
-- there, we slide further left instead of overlapping it.
local function PlaceButton(btn, sb)
    if not sb then return end
    btn:ClearAllPoints()
    local x = -4
    local parent = sb:GetParent()
    local left = sb:GetLeft()
    if parent and left then
        local kids = { parent:GetChildren() }
        for _, k in ipairs(kids) do
            if k ~= btn and k ~= sb and k:IsShown()
               and k.GetObjectType and k:GetObjectType() == "Button" then
                local kl, kr = k:GetLeft(), k:GetRight()
                local kt, kb = k:GetTop(), k:GetBottom()
                local st, sbot = sb:GetTop(), sb:GetBottom()
                if kl and kr and kt and kb and st and sbot
                   and kr <= left + 2 and kr > left - 70
                   and kb < st and kt > sbot then
                    x = x - (kr - kl) - 4
                end
            end
        end
    end
    btn:SetPoint("RIGHT", sb, "LEFT", x, 0)
end

local function UpdateButtonState(panel)
    local btn = buttons[panel]
    if not btn then return end
    if filterOn[panel] then
        btn.icon:SetDesaturated(false)
        btn.icon:SetVertexColor(1, 1, 1)
        btn.ring:Show()
    else
        btn.icon:SetDesaturated(true)
        btn.icon:SetVertexColor(0.65, 0.65, 0.65)
        btn.ring:Hide()
    end
end

local function EnsureButton(panel)
    if buttons[panel] then return buttons[panel] end
    local sb = FindSearchBox(panel)
    if not sb then return nil end
    local btn = CreateFrame("Button", nil, panel)
    btn:SetSize(23, 23)
    btn:SetFrameLevel(panel:GetFrameLevel() + 10)
    btn.akcqolTooltip = true
    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
    icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    btn.icon = icon
    local edge = {}
    for i = 1, 4 do
        edge[i] = btn:CreateTexture(nil, "OVERLAY", nil, 1)
        edge[i]:SetColorTexture(1, 0.82, 0.2, 0.9)
        edge[i]:Hide()
    end
    edge[1]:SetPoint("TOPLEFT", -2, 2);     edge[1]:SetPoint("TOPRIGHT", 2, 2);     edge[1]:SetHeight(1)
    edge[2]:SetPoint("BOTTOMLEFT", -2, -2); edge[2]:SetPoint("BOTTOMRIGHT", 2, -2); edge[2]:SetHeight(1)
    edge[3]:SetPoint("TOPLEFT", -2, 2);     edge[3]:SetPoint("BOTTOMLEFT", -2, -2); edge[3]:SetWidth(1)
    edge[4]:SetPoint("TOPRIGHT", 2, 2);     edge[4]:SetPoint("BOTTOMRIGHT", 2, -2); edge[4]:SetWidth(1)
    btn.ring = {
        Show = function() for _, e in ipairs(edge) do e:Show() end end,
        Hide = function() for _, e in ipairs(edge) do e:Hide() end end,
    }
    btn:SetScript("OnClick", function()
        filterOn[panel] = not filterOn[panel]
        UpdateButtonState(panel)
        RefreshPanel(panel)
    end)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine(L["AH Sell Filter"], 1, 0.82, 0.2)
        GameTooltip:AddLine(L["Dims everything that cannot be sold on the Auction House, so sellable items pop out. Click again to clear."], 0.9, 0.9, 0.9, true)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    PlaceButton(btn, sb)
    buttons[panel] = btn
    return btn
end

local function HookPanel(panel)
    if not panel or panel.__akcSellFilterHooked then return end
    panel.__akcSellFilterHooked = true
    -- 12.x BankPanel refresh paths (same trio Character/ItemLevel.lua hooks):
    for _, method in ipairs({ "GenerateItemSlotsForSelectedTab", "RefreshAllItemsForSelectedTab", "UpdateSearchResults", "UpdateItems" }) do
        if panel[method] then
            hooksecurefunc(panel, method, function(self)
                if Enabled() and filterOn[self] then RefreshPanel(self) end
            end)
        end
    end
    panel:HookScript("OnShow", function(self)
        if not Enabled() then
            if buttons[self] then buttons[self]:Hide() end
            return
        end
        local b = EnsureButton(self)
        if b then
            b:Show()
            PlaceButton(b, FindSearchBox(self))
            UpdateButtonState(self)
        end
        RefreshPanel(self)
    end)
    panel:HookScript("OnHide", function(self)
        filterOn[self] = false
        HideAllOverlays()
        if buttons[self] then UpdateButtonState(self) end
    end)
end

HookPanel(_G.BankPanel)

function _G.AkcQOL_ApplyBankSellFilter()
    local panel = _G.BankPanel
    if not panel or not panel.__akcSellFilterHooked then return end
    if Enabled() and panel:IsShown() then
        local b = EnsureButton(panel)
        if b then
            b:Show()
            UpdateButtonState(panel)
        end
    else
        if buttons[panel] then buttons[panel]:Hide() end
        filterOn[panel] = false
        HideAllOverlays()
    end
    RefreshPanel(panel)
end
