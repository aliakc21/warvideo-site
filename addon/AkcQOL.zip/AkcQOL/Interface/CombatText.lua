local ADDON_NAME = ...
local L = AkcQOL_L

local FONT_FACES = {
    akc      = { order = 1, label = "AkcQOL (PT Sans Narrow)", path = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\PTSansNarrow-Bold.ttf", bundled = true },
    friz     = { order = 2, label = "Friz Quadrata (WoW default)", path = "Fonts\\FRIZQT__.TTF" },
    arial    = { order = 3, label = "Arial Narrow", path = "Fonts\\ARIALN.TTF" },
    skurri   = { order = 4, label = "Skurri (classic damage font)", path = "Fonts\\skurri.ttf" },
    morpheus = { order = 5, label = "Morpheus (fantasy)", path = "Fonts\\MORPHEUS.ttf" },
    arhei    = { order = 6, label = "AR Hei (blocky bold)", path = "Fonts\\ARHei.ttf" },
    arkai    = { order = 7, label = "AR Kai (brush strokes)", path = "Fonts\\ARKai_T.ttf" },
    k2002    = { order = 8, label = "2002 (thin, sharp)", path = "Fonts\\2002.ttf" },
    impact   = { order = 9, label = "Impact (bold, condensed)", path = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\Impact.ttf", bundled = true },
    bahn     = { order = 10, label = "Bahnschrift (bold, condensed)", path = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\Bahnschrift.ttf", bundled = true },
    anton    = { order = 11, label = "Anton (heavy, condensed)", path = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\Anton.ttf", bundled = true },
    oswald   = { order = 12, label = "Oswald (bold, condensed)", path = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\Oswald.ttf", bundled = true },
    bebas    = { order = 13, label = "Bebas Neue (ultra-condensed)", path = "Interface\\AddOns\\AkcQOL\\Media\\Fonts\\BebasNeue.ttf", bundled = true },
}

local ANIM_CVAR_DEFAULTS = {
    ["floatingCombatTextCombatDamageDirectionalScale_v2"] = "1",
    ["floatingCombatTextCombatDamageDirectionalOffset_v2"] = "1",
    ["WorldTextGravity_v2"] = "0.5",
    ["WorldTextStartPosRandomness_v2"] = "1",
    ["WorldTextRandomZMin_v2"] = "0.8",
    ["WorldTextRandomZMax_v2"] = "1.5",
    ["WorldTextRampDuration_v2"] = "1",
    ["WorldTextRampPowCrit_v2"] = "8",
    ["WorldTextCritScreenY_v2"] = "0.0275",
}

local ANIM_STYLES = {
    default = { order = 1, label = "WoW Default — classic scatter", cvars = {} },
    tidy = { order = 2, label = "Tidy — no scatter, rise up", cvars = {
        ["floatingCombatTextCombatDamageDirectionalScale_v2"] = "0",
    } },
    calm = { order = 3, label = "Calm Rise — uniform column", cvars = {
        ["floatingCombatTextCombatDamageDirectionalScale_v2"] = "0",
        ["WorldTextGravity_v2"] = "0",
        ["WorldTextStartPosRandomness_v2"] = "0",
        ["WorldTextRandomZMin_v2"] = "1",
        ["WorldTextRandomZMax_v2"] = "1",
    } },
    drift = { order = 4, label = "Gentle Drift — soft & slow", cvars = {
        ["floatingCombatTextCombatDamageDirectionalScale_v2"] = "0",
        ["WorldTextGravity_v2"] = "0.25",
        ["WorldTextRampDuration_v2"] = "1.5",
    } },
    calmcrit = { order = 5, label = "Tidy + Calm Crits — softer crits", cvars = {
        ["floatingCombatTextCombatDamageDirectionalScale_v2"] = "0",
        ["WorldTextRampPowCrit_v2"] = "2",
        ["WorldTextCritScreenY_v2"] = "0.015",
    } },
}

local function SetCVarSafe(name, value)
    if not (C_CVar and C_CVar.SetCVar and C_CVar.GetCVar) then return end
    if C_CVar.GetCVar(name) == nil then return end
    pcall(C_CVar.SetCVar, name, tostring(value))
end

local RISE_HEIGHT_DEFAULT = 2.5
local RISE_SPEED_DEFAULT = 0.015
local CRIT_SPEED_RATIO = 0.0275 / 0.015

local function ApplyRise()
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end

    local height = tonumber(g.combatRiseHeight)
    if height then
        SetCVarSafe("WorldTextNonRandomZ_v2", height)
    end

    local speed = tonumber(g.combatRiseSpeed)
    if speed then
        SetCVarSafe("WorldTextScreenY_v2", speed)
        SetCVarSafe("WorldTextCritScreenY_v2", speed * CRIT_SPEED_RATIO)
    end
end

local function ApplySelfDirection()
    local g = AkcQOLDB and AkcQOLDB.global
    local mode = g and tonumber(g.combatSelfFloatMode)
    if not mode then return end
    SetCVarSafe("floatingCombatTextFloatMode_v2", mode)
    SetCVarSafe("floatingCombatTextFloatMode", mode)
end

local function ApplyAnim()
    local g = AkcQOLDB and AkcQOLDB.global
    local key = g and g.combatTextAnim
    if key then
        local style = ANIM_STYLES[key] or ANIM_STYLES.default
        for cvar, def in pairs(ANIM_CVAR_DEFAULTS) do
            SetCVarSafe(cvar, style.cvars[cvar] or def)
        end
    end
    ApplyRise()
    ApplySelfDirection()
end

function _G.AkcQOL_SetCombatRise(which, value)
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    if which == "height" then
        g.combatRiseHeight = tonumber(value) or RISE_HEIGHT_DEFAULT
    else
        g.combatRiseSpeed = tonumber(value) or RISE_SPEED_DEFAULT
    end
    ApplyRise()
end

function _G.AkcQOL_GetCombatRise(which)
    local g = AkcQOLDB and AkcQOLDB.global
    if which == "height" then
        return (g and tonumber(g.combatRiseHeight)) or RISE_HEIGHT_DEFAULT
    end
    return (g and tonumber(g.combatRiseSpeed)) or RISE_SPEED_DEFAULT
end

function _G.AkcQOL_SetSelfFloatMode(mode)
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    g.combatSelfFloatMode = tonumber(mode) or 1
    ApplySelfDirection()
end

function _G.AkcQOL_GetSelfFloatMode()
    local g = AkcQOLDB and AkcQOLDB.global
    return (g and tonumber(g.combatSelfFloatMode)) or 1
end

local function ApplyWorldScale()
    local g = AkcQOLDB and AkcQOLDB.global
    local v = g and tonumber(g.combatTextWorldScale)
    if not v then return end
    SetCVarSafe("WorldTextScale_v2", v)
end

function _G.AkcQOL_GetCombatAnimStyles()
    return ANIM_STYLES
end

function _G.AkcQOL_ApplyCombatAnim(key)
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    if key ~= nil then g.combatTextAnim = key end
    ApplyAnim()
end

function _G.AkcQOL_SetCombatNumberScale(v)
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    g.combatTextWorldScale = tonumber(v) or 1
    ApplyWorldScale()
end

local ORIGINAL_WORLD_FONT = DAMAGE_TEXT_FONT or "Fonts\\FRIZQT__.TTF"

local origPath, origSize, origFlags
local probe

local function ValidPath(path)
    if not probe then
        probe = UIParent:CreateFontString(nil, "BACKGROUND")
        probe:Hide()
    end
    local ok, applied = pcall(probe.SetFont, probe, path, 12, "")
    return ok and applied == true
end

local function ChosenFace()
    local g = AkcQOLDB and AkcQOLDB.global
    local key = g and g.combatTextFontFace
    return FONT_FACES[key] or FONT_FACES.akc
end

local function ChosenPath()
    local face = ChosenFace()
    if face.bundled or ValidPath(face.path) then return face.path end
    return FONT_FACES.akc.path
end

local function Enabled()
    local g = AkcQOLDB and AkcQOLDB.global
    return g ~= nil and g.combatTextFont == true
end

DAMAGE_TEXT_FONT = Enabled() and ChosenPath() or ORIGINAL_WORLD_FONT

local function Apply(enabled)
    if enabled then
        DAMAGE_TEXT_FONT = ChosenPath()
    else
        DAMAGE_TEXT_FONT = ORIGINAL_WORLD_FONT
    end

    if CombatTextFont and CombatTextFont.SetFont then
        if not origPath then
            origPath, origSize, origFlags = CombatTextFont:GetFont()
        end
        if enabled then
            CombatTextFont:SetFont(ChosenPath(), origSize or 25, origFlags or "")
        elseif origPath then
            CombatTextFont:SetFont(origPath, origSize, origFlags)
        end
    end
end

local function Reapply()
    local g = AkcQOLDB and AkcQOLDB.global
    if not g then return end
    Apply(g.combatTextFont == true)
    ApplyAnim()
    ApplyWorldScale()
end

function _G.AkcQOL_ApplyCombatTextFont(enabled)
    if enabled == nil then
        Reapply()
        return
    end
    Apply(enabled)
end

function _G.AkcQOL_GetCombatTextFontFaces()
    local out = {}
    for key, face in pairs(FONT_FACES) do
        if face.bundled or ValidPath(face.path) then
            out[key] = face
        end
    end
    return out
end

StaticPopupDialogs["AKCQOL_COMBAT_FONT_RELOG"] = {
    text = "|cff8c5cffAkc|r|cffffffffQOL|r — Combat Number Font\n\n|cFF59D97BNumbers on YOUR character:|r change instantly.\n\n|cFFFFD100Damage numbers over ENEMIES:|r log out to the character-select screen and back in (or fully restart the game).\n\n|cFFF25850/reload is NOT enough|r — WoW only reads this font at login.",
    button1 = OKAY,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    preferredIndex = 3,
}

function _G.AkcQOL_CombatFontRelogPrompt()
    Reapply()
    if StaticPopup_Show then StaticPopup_Show("AKCQOL_COMBAT_FONT_RELOG") end
end

-- ── Combat numbers behind the action bars ───────────────────────────────────
-- Blizzard's CombatText frame (the incoming heal/damage numbers on YOUR
-- character) draws over the action bars in 12.x. When this option is on we
-- park it one strata below the bars — out of combat only, fully reversible.
local layerOrigStrata, layerOrigLevel
local layerPending = false

-- Opt-in: a fresh install must not change Blizzard's own layering.
local function LayerEnabled()
    local g = AkcQOLDB and AkcQOLDB.global
    return (g and g.combatTextBehindBars == true) or false
end

local function ApplyLayer()
    local ct = _G.CombatText
    if not ct or not ct.SetFrameStrata then return end
    if InCombatLockdown() then layerPending = true return end
    layerPending = false
    if LayerEnabled() then
        if not layerOrigStrata then
            layerOrigStrata = ct:GetFrameStrata()
            layerOrigLevel = ct:GetFrameLevel()
        end
        -- Action bars live on MEDIUM: one strata below keeps the numbers over
        -- the world and under the bars, without hiding them behind everything.
        pcall(ct.SetFrameStrata, ct, "LOW")
        pcall(ct.SetFrameLevel, ct, 1)
    elseif layerOrigStrata then
        pcall(ct.SetFrameStrata, ct, layerOrigStrata)
        pcall(ct.SetFrameLevel, ct, layerOrigLevel or 0)
    end
end

function _G.AkcQOL_SetCombatTextBehindBars(on)
    AkcQOLDB = AkcQOLDB or {}
    AkcQOLDB.global = AkcQOLDB.global or {}
    AkcQOLDB.global.combatTextBehindBars = (on ~= false)
    ApplyLayer()
end

local layerFrame = CreateFrame("Frame")
layerFrame:RegisterEvent("PLAYER_LOGIN")
layerFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
layerFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        ApplyLayer()
        if EventUtil and EventUtil.ContinueOnAddOnLoaded then
            EventUtil.ContinueOnAddOnLoaded("Blizzard_CombatText", ApplyLayer)
        end
    elseif event == "PLAYER_REGEN_ENABLED" and layerPending then
        ApplyLayer()
    end
end)

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 ~= ADDON_NAME then return end
    Reapply()
end)

if EventUtil and EventUtil.ContinueOnAddOnLoaded then
    EventUtil.ContinueOnAddOnLoaded("Blizzard_CombatText", Reapply)
end

SLASH_AKCQOLFONT1 = "/akcfont"
SlashCmdList["AKCQOLFONT"] = function()
    local prefix = "|cff8c5cffAkc|r|cffffffffQOL|r: "
    local g = AkcQOLDB and AkcQOLDB.global
    local enabled = g ~= nil and g.combatTextFont == true
    local face = FONT_FACES[(g and g.combatTextFontFace) or "akc"] or FONT_FACES.akc

    if enabled then
        print(prefix .. L["Combat number font:"] .. " |cFF59D97B" .. L["On"] .. "|r — " .. L[face.label])
        if not (face.bundled or ValidPath(face.path)) then
            print(prefix .. "|cFFF25850" .. L["The selected font could not be loaded; the AkcQOL font is used instead."] .. "|r")
        end
        print(prefix .. "|cFF9AA0A6" .. L["Numbers over enemies change after a full logout to character-select (not /reload)."] .. "|r")
    else
        print(prefix .. L["Combat number font:"] .. " |cFFF25850" .. L["Off"] .. "|r — " .. L["using the WoW default."])
    end

    -- The preset's own label, not its internal key -- and no raw CVar dump;
    -- that was developer scaffolding, not something a player can act on.
    local animKey = g and g.combatTextAnim
    local anim = animKey and ANIM_STYLES[animKey]
    print(prefix .. L["Animation preset:"] .. " " .. ((anim and L[anim.label]) or L["(none chosen)"]))
end
