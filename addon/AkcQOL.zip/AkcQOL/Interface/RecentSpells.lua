
local Theme = AkcQOL_Theme

local DEFAULT_COUNT, MIN_COUNT, MAX_COUNT = 5, 1, 12
local DEFAULT_ICON,  MIN_ICON,  MAX_ICON  = 36, 20, 56
local PAD = 4
local PREVIEW_SECONDS = 30
local FALLBACK_TEX = 134400

local SAMPLE_ICONS = {
    135808, 136048, 132242, 135732, 136218, 132152,
    135817, 458234, 135727, 132115, 236291, 132347,
}

local frame, slots, eventFrame, previewTicker
local history = {}
local historyAt = {}
local FADE_TAIL = 0.35
local fadeTicker
local lastSpellID, lastCastTime = nil, 0
local previewToken = 0
local previewActive = false
local previewEndTime = 0

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.recentSpells) ~= "table" then g.recentSpells = {} end
    local d = g.recentSpells
    if d.enabled == nil then d.enabled = false end
    if type(d.count) ~= "number" then d.count = DEFAULT_COUNT end
    if d.count < MIN_COUNT then d.count = MIN_COUNT elseif d.count > MAX_COUNT then d.count = MAX_COUNT end
    if type(d.iconSize) ~= "number" then d.iconSize = DEFAULT_ICON end
    if d.iconSize < MIN_ICON then d.iconSize = MIN_ICON elseif d.iconSize > MAX_ICON then d.iconSize = MAX_ICON end
    if d.newest ~= "left" and d.newest ~= "right" then d.newest = "left" end
    if d.orientation ~= "vertical" then d.orientation = "horizontal" end
    if d.onlySpells == nil then d.onlySpells = true end
    if type(d.lifetime) ~= "number" then d.lifetime = 10 end
    if d.lifetime < 0 then d.lifetime = 0 elseif d.lifetime > 30 then d.lifetime = 30 end
    if d.popAnim == nil then d.popAnim = true end
    if d.tooltipAnchor ~= "default" then d.tooltipAnchor = "icon" end
    if type(d.scale) ~= "number" then d.scale = 1.0 end
    if d.locked == nil then d.locked = true end
    if d.tooltips == nil then d.tooltips = true end
    return d
end

local function SpellTex(id)
    if C_Spell and C_Spell.GetSpellTexture then
        local t = C_Spell.GetSpellTexture(id)
        if t then return t end
    end
    if GetSpellTexture then return (GetSpellTexture(id)) end
    return nil
end

-- Bara girmemesi gereken, buyu olarak gelen ama "yetenek" olmayan seyler.
local NON_SKILL_SPELLS = {
    [8690]   = true,  -- Hearthstone
    [556]    = true,  -- Astral Recall
    [126892] = true,  -- Zen Pilgrimage
    [50977]  = true,  -- Death Gate
    [193753] = true,  -- Dreamwalk
    [265225] = true,  -- Focused Resolve
    [312372] = true,  -- Fleshcraft benzeri kanal (yer tutucu, zararsiz)
}

local mountSpellCache = {}

local function IsMountSpell(id)
    local cached = mountSpellCache[id]
    if cached ~= nil then return cached end
    local isMount = false
    if C_MountJournal and C_MountJournal.GetMountFromSpell then
        local ok, mountID = pcall(C_MountJournal.GetMountFromSpell, id)
        if ok and mountID then isMount = true end
    end
    mountSpellCache[id] = isMount
    return isMount
end

local function IsSkillCast(id)
    if NON_SKILL_SPELLS[id] then return false end
    if IsMountSpell(id) then return false end
    return true
end

local function CreateSlot(parent)
    local s = CreateFrame("Frame", nil, parent)

    s.border = s:CreateTexture(nil, "BACKGROUND", nil, -8)
    s.border:SetColorTexture(Theme.rgba(Theme.colors.border))

    s.bg = s:CreateTexture(nil, "BACKGROUND", nil, -7)
    s.bg:SetColorTexture(Theme.rgba(Theme.colors.insetBg))

    s.icon = s:CreateTexture(nil, "ARTWORK")
    s.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local pop = s:CreateAnimationGroup()
    local up = pop:CreateAnimation("Scale")
    up:SetOrder(1); up:SetDuration(0.10)
    up:SetOrigin("CENTER", 0, 0)
    if up.SetScaleFrom then up:SetScaleFrom(1, 1); up:SetScaleTo(1.35, 1.35)
    elseif up.SetFromScale then up:SetFromScale(1, 1); up:SetToScale(1.35, 1.35) end
    local down = pop:CreateAnimation("Scale")
    down:SetOrder(2); down:SetDuration(0.16)
    down:SetOrigin("CENTER", 0, 0)
    if down.SetScaleFrom then down:SetScaleFrom(1.35, 1.35); down:SetScaleTo(1, 1)
    elseif down.SetFromScale then down:SetFromScale(1.35, 1.35); down:SetToScale(1, 1) end
    s.popAnim = pop

    if s.SetMouseClickEnabled then s:SetMouseClickEnabled(false) end
    if s.SetMouseMotionEnabled then s:SetMouseMotionEnabled(DB().tooltips ~= false) end
    s:SetScript("OnEnter", function(self)
        if DB().tooltips == false or not self.spellID then return end
        local anchored = false
        if DB().tooltipAnchor == "default" and GameTooltip_SetDefaultAnchor then
            anchored = pcall(GameTooltip_SetDefaultAnchor, GameTooltip, UIParent)
        end
        if not anchored then GameTooltip:SetOwner(self, "ANCHOR_RIGHT") end
        local ok = pcall(GameTooltip.SetSpellByID, GameTooltip, self.spellID)
        if ok then GameTooltip:Show() else GameTooltip:Hide() end
    end)
    s:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)

    return s
end

local function PruneExpired()
    local d = DB()
    local life = d.lifetime or 10
    if life <= 0 or previewActive then return false end
    local now = GetTime()
    local changed = false
    for i = #history, 1, -1 do
        local t = historyAt[i]
        if not t or (now - t) >= life then
            table.remove(history, i)
            table.remove(historyAt, i)
            changed = true
        end
    end
    return changed
end

local function EntryAlpha(hi)
    local d = DB()
    local life = d.lifetime or 10
    if life <= 0 or previewActive then return 1 end
    local t = historyAt[hi]
    if not t then return 1 end
    local age = GetTime() - t
    local fadeStart = life * (1 - FADE_TAIL)
    if age <= fadeStart then return 1 end
    local a = 1 - (age - fadeStart) / (life - fadeStart)
    if a < 0 then return 0 elseif a > 1 then return 1 end
    return a
end

local function FadeOnly()
    if not frame or not slots then return end
    local d = DB()
    local n = d.count
    local newestLeft = (d.newest ~= "right")
    for pos = 1, n do
        local s = slots[pos]
        if not s then break end
        if s.shownID then
            s:SetAlpha(EntryAlpha(newestLeft and pos or (n - pos + 1)))
        end
    end
end

local function Refresh()
    if not frame or not slots then return end
    local d = DB()
    local n = d.count
    local newestLeft = (d.newest ~= "right")
    for pos = 1, n do
        local s = slots[pos]
        if not s then break end
        local hi = newestLeft and pos or (n - pos + 1)
        local id = history[hi]
        local tex = id and (SpellTex(id) or FALLBACK_TEX) or nil
        if not tex and previewActive then
            tex = SAMPLE_ICONS[((pos - 1) % #SAMPLE_ICONS) + 1]
        end
        if tex then
            s:SetAlpha(EntryAlpha(hi))
            if d.popAnim ~= false and hi == 1 and not previewActive
                and s.shownID ~= id and s.popAnim then
                s.popAnim:Stop()
                s.popAnim:Play()
            end
            s.shownID = id
            s.icon:SetTexture(tex)
            s.icon:SetAlpha(1)
            s.bg:SetAlpha(0.9)
            s.border:SetColorTexture(Theme.rgba(hi == 1 and Theme.colors.accent or Theme.colors.border))
            s.spellID = id
        else
            s:SetAlpha(0)
            s.shownID = nil
            s.icon:SetTexture(nil)
            s.spellID = nil
        end
    end
end

local function Layout()
    if not frame or not slots then return end
    local d = DB()
    local n, sz = d.count, d.iconSize
    local vertical = (d.orientation == "vertical")
    while #slots < n do slots[#slots + 1] = CreateSlot(frame) end
    for i, s in ipairs(slots) do
        if i <= n then
            s:ClearAllPoints()
            s:SetSize(sz, sz)
            if vertical then
                s:SetPoint("TOP", frame, "TOP", 0, -(i - 1) * (sz + PAD))
            else
                s:SetPoint("LEFT", frame, "LEFT", (i - 1) * (sz + PAD), 0)
            end
            s.icon:ClearAllPoints(); s.icon:SetAllPoints(s)
            s.bg:ClearAllPoints();   s.bg:SetAllPoints(s)
            s.border:ClearAllPoints()
            s.border:SetPoint("TOPLEFT", s, "TOPLEFT", -1, 1)
            s.border:SetPoint("BOTTOMRIGHT", s, "BOTTOMRIGHT", 1, -1)
            s:Show()
        else
            s:Hide()
        end
    end
    local span = n * sz + (n - 1) * PAD
    if vertical then frame:SetSize(sz, span) else frame:SetSize(span, sz) end
    Refresh()
end

local function RecordCast(spellID)
    if spellID == nil then return end
    if issecretvalue and issecretvalue(spellID) then return end
    if type(spellID) ~= "number" then return end
    if not SpellTex(spellID) then return end
    if DB().onlySpells ~= false and not IsSkillCast(spellID) then return end
    local now = GetTime()
    if spellID == lastSpellID and (now - lastCastTime) < 0.25 then return end
    lastSpellID, lastCastTime = spellID, now
    table.insert(history, 1, spellID)
    table.insert(historyAt, 1, now)
    for i = #history, MAX_COUNT + 1, -1 do history[i] = nil; historyAt[i] = nil end
    if frame and frame:IsShown() then Refresh() end
end

-- True between OnDragStart and OnDragStop. If the drag is interrupted (preview
-- expires, the frame is hidden, the mouse is disabled) OnDragStop never fires, so
-- the frame would stay glued to the cursor AND the new spot would never be saved.
local isMoving = false

local function StopMovingAndSave()
    if not frame then return end
    frame:StopMovingOrSizing()
    isMoving = false
    local l, t = frame:GetLeft(), frame:GetTop()
    if l and t then
        -- Saved per screen; the legacy posX/posY is left untouched on purpose so
        -- another machine's spot is not overwritten (see Core/ScreenPos.lua).
        AkcQOL_ScreenPos.Save(DB(), frame)
        -- Re-anchor by CENTRE: changing icon size/count then grows the bar
        -- symmetrically instead of sliding it up or down.
        local w, h = frame:GetWidth(), frame:GetHeight()
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", l + w / 2, t - h / 2)
    end
end

-- Applies the position for the CURRENT screen; falls back to the default spot.
local function ApplyPosition()
    if not frame then return end
    local d = DB()
    local sc = d.scale or 1.0
    if sc <= 0 then sc = 1.0 end
    local cx, cy = AkcQOL_ScreenPos.Get(d, frame)
    frame:ClearAllPoints()
    if cx and cy then
        frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx / sc, cy / sc)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, -220)
    end
end

local function RefreshInteractivity()
    if not frame then return end
    local d = DB()
    local movable = previewActive or (d.locked == false)
    -- About to take the mouse away (preview ended / re-locked) while a drag is in
    -- flight: finish and save it first, otherwise the frame sticks to the cursor.
    if isMoving and not movable then StopMovingAndSave() end
    frame:EnableMouse(movable)
    if frame.dragHandle then
        frame.dragHandle:EnableMouse(movable)
        frame.dragHandle:SetShown(movable)
        frame.dragHandle:SetFrameLevel(frame:GetFrameLevel() + 20)
    end
    frame:SetFrameStrata(previewActive and "TOOLTIP" or "MEDIUM")
    if movable and not frame.previewHL then
        local hl = frame:CreateTexture(nil, "BACKGROUND", nil, -8)
        hl:SetPoint("TOPLEFT", -3, 3)
        hl:SetPoint("BOTTOMRIGHT", 3, -3)
        hl:SetColorTexture(Theme.rgba(Theme.colors.rowHover))
        frame.previewHL = hl
    end
    if frame.previewHL then frame.previewHL:SetShown(movable) end

    if previewActive and not frame.previewCD then
        local fs = frame:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(fs, 10, "OUTLINE")
        fs:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 0, 4)
        fs:SetTextColor(0.55, 0.80, 1.0, 0.95)
        frame.previewCD = fs
    end
    if frame.previewCD then frame.previewCD:SetShown(previewActive) end
end

local function UpdateVisibility()
    if not frame then return end
    local d = DB()
    if (d.enabled == false) and not previewActive then
        frame:Hide()
    else
        frame:Show()
        Refresh()
    end
end

local function CreateBar()
    if frame then return end
    local d = DB()
    frame = CreateFrame("Frame", "AkcQOLRecentSpellsFrame", UIParent, "BackdropTemplate")
    frame:SetFrameStrata("MEDIUM")
    frame:SetSize(200, 40)
    frame:SetClampedToScreen(false)
    frame:SetMovable(true)
    frame:EnableMouse(false)

    local handle = CreateFrame("Frame", nil, frame)
    handle:SetAllPoints(frame)
    handle:SetFrameLevel(frame:GetFrameLevel() + 20)
    handle:EnableMouse(false)
    handle:Hide()
    handle:RegisterForDrag("LeftButton")
    handle:SetScript("OnDragStart", function() frame:StartMoving(); isMoving = true end)
    handle:SetScript("OnDragStop", StopMovingAndSave)
    -- Safety net: if the bar is hidden mid-drag, finish the move instead of
    -- leaving it stuck to the cursor with the new spot unsaved.
    frame:SetScript("OnHide", function() if isMoving then StopMovingAndSave() end end)
    -- No hover tooltip on the drag handle: it covered the bar while positioning it.
    frame.dragHandle = handle

    frame:SetScale(d.scale or 1.0)

    slots = {}
    for i = 1, d.count do slots[i] = CreateSlot(frame) end
    Layout()
    -- After SetScale + Layout: the proportional carry-over measures the frame, so it
    -- must run once the real size and scale are in place (not the constructor stub).
    ApplyPosition()
    RefreshInteractivity()
    frame:Hide()
end

function _G.AkcQOL_ApplyRecentSpells()
    if not frame then CreateBar() end
    UpdateVisibility()
end

function _G.AkcQOL_SetRecentSpellsCount(n)
    local d = DB()
    if type(n) == "number" then
        n = math.floor(n + 0.5)
        if n < MIN_COUNT then n = MIN_COUNT elseif n > MAX_COUNT then n = MAX_COUNT end
        d.count = n
    end
    if not frame then CreateBar() end
    Layout()
end

function _G.AkcQOL_SetRecentSpellsIconSize(sz)
    local d = DB()
    if type(sz) == "number" then
        if sz < MIN_ICON then sz = MIN_ICON elseif sz > MAX_ICON then sz = MAX_ICON end
        d.iconSize = sz
    end
    if not frame then CreateBar() end
    Layout()
end

function _G.AkcQOL_SetRecentSpellsSide(side)
    local d = DB()
    d.newest = (side == "right") and "right" or "left"
    if not frame then CreateBar() end
    Refresh()
end

function _G.AkcQOL_SetRecentSpellsOrientation(o)
    local d = DB()
    d.orientation = (o == "vertical") and "vertical" or "horizontal"
    if not frame then CreateBar() end
    Layout()
end

function _G.AkcQOL_SetRecentSpellsOnlySpells(on)
    local d = DB()
    d.onlySpells = (on ~= false)
    if d.onlySpells then
        for i = #history, 1, -1 do
            if not IsSkillCast(history[i]) then
                table.remove(history, i)
                table.remove(historyAt, i)
            end
        end
    end
    if not frame then CreateBar() end
    Refresh()
end

function _G.AkcQOL_SetRecentSpellsScale(scale)
    local d = DB()
    if type(scale) == "number" then d.scale = scale end
    if not frame then CreateBar() end
    if frame then
        frame:SetScale(d.scale or 1.0)
        ApplyPosition()
    end
end

function _G.AkcQOL_SetRecentSpellsLocked(locked)
    local d = DB()
    d.locked = (locked == true)
    if not frame then CreateBar() end
    RefreshInteractivity()
end

function _G.AkcQOL_SetRecentSpellsTooltips(on)
    local d = DB()
    d.tooltips = (on ~= false)
    if not frame then CreateBar() end
    if slots then
        for _, s in ipairs(slots) do
            if s.SetMouseMotionEnabled then s:SetMouseMotionEnabled(d.tooltips) end
        end
    end
end

function _G.AkcQOL_PreviewRecentSpells()
    if not frame then CreateBar() end
    previewToken = previewToken + 1
    local token = previewToken
    previewActive = true
    previewEndTime = GetTime() + PREVIEW_SECONDS
    RefreshInteractivity()
    frame:Show()
    Layout()
    Refresh()
    if frame.previewCD then frame.previewCD:SetFormattedText("%ds", PREVIEW_SECONDS) end
    if previewTicker then previewTicker:Cancel() end
    previewTicker = C_Timer.NewTicker(0.2, function()
        if not previewActive or not frame or not frame.previewCD then return end
        local rem = previewEndTime - GetTime()
        if rem < 0 then rem = 0 end
        frame.previewCD:SetFormattedText("%ds", math.ceil(rem))
    end)
    if C_Timer and C_Timer.After then
        C_Timer.After(PREVIEW_SECONDS, function()
            if token ~= previewToken then return end
            previewActive = false
            RefreshInteractivity()
            if previewTicker then previewTicker:Cancel(); previewTicker = nil end
            UpdateVisibility()
        end)
    end
end

function _G.AkcQOL_ResetRecentSpellsPosition()
    if not frame then CreateBar() end
    local d = DB()

    -- Reset only THIS screen: drop its entry, recentre, then record the new spot
    -- so it wins over the legacy value. Other displays keep their own layout.
    AkcQOL_ScreenPos.Clear(d)
    frame:Show()
    Layout()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, -220)
    AkcQOL_ScreenPos.Save(d, frame)
    if _G.AkcQOL_PreviewRecentSpells then _G.AkcQOL_PreviewRecentSpells() end
end

function _G.AkcQOL_ResetRecentSpellsDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.recentSpells = nil end
    local d = DB()
    if not frame then CreateBar() end
    frame:SetScale(d.scale or 1.0)
    Layout()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, -220)
    RefreshInteractivity()
    UpdateVisibility()
end

local function StartFadeTicker()
    if fadeTicker or not C_Timer or not C_Timer.NewTicker then return end
    fadeTicker = C_Timer.NewTicker(0.05, function()
        if not frame or not frame:IsShown() then return end
        local d = DB()
        if (d.lifetime or 10) <= 0 or previewActive then return end
        if #history == 0 then return end
        if PruneExpired() then Refresh() else FadeOnly() end
    end)
end

function _G.AkcQOL_SetRecentSpellsLifetime(sec)
    local d = DB()
    if type(sec) == "number" then
        if sec < 0 then sec = 0 elseif sec > 30 then sec = 30 end
        d.lifetime = sec
    end
    if not frame then CreateBar() end
    Refresh()
end

function _G.AkcQOL_SetRecentSpellsTooltipAnchor(mode)
    DB().tooltipAnchor = (mode == "default") and "default" or "icon"
end

function _G.AkcQOL_SetRecentSpellsPop(on)
    DB().popAnim = (on ~= false)
end

eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")

eventFrame:SetScript("OnEvent", function(_, event, unit, castGUID, spellID)
    if event == "PLAYER_LOGIN" then
        DB()
        CreateBar()
        pcall(eventFrame.RegisterUnitEvent, eventFrame, "UNIT_SPELLCAST_SUCCEEDED", "player")
        StartFadeTicker()
        UpdateVisibility()
        return
    end
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        local d = DB()
        if (d.enabled == false) and not previewActive then return end
        RecordCast(spellID)
    end
end)
