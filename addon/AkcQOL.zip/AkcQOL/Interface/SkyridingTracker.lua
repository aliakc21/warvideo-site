
local L = AkcQOL_L
local Theme = AkcQOL_Theme

local FLAT = "Interface\\Buttons\\WHITE8x8"

local ABILITIES
local function RebuildAbilities()
    ABILITIES = {
        { ids = { 372608 },         label = L["Surge Forward"]  },
        { ids = { 361584, 376359 }, label = L["Whirling Surge"] },
        { ids = { 425782 },         label = L["Second Wind"]    },
    }
end
RebuildAbilities()
if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(RebuildAbilities) end

local ICON_SIZE = 44
local ICON_PAD  = 6
local BAR_W, BAR_H, BAR_ICON, ROW_PAD = 150, 18, 22, 4

local VIG_PIP_W, VIG_PIP_H, VIG_GAP, VIG_ICON, VIG_MAX_PIPS = 26, 16, 3, 26, 10
local VIG_ABIL_GAP, VIG_MAX_ABIL = 4, 6

local SPD_H, SPD_GAP, SPD_MAX_PCT, SPD_THRILL_PCT = 9, 3, 1000, 900

local frame, slots, ticker, eventFrame
local vigorRow
local lastVigorMax = 6
local previewToken = 0
local previewActive = false
local previewEndTime = 0

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.skyriding) ~= "table" then g.skyriding = {} end
    local d = g.skyriding
    if d.enabled == nil then d.enabled = false end
    if d.style ~= "bars" and d.style ~= "icons" and d.style ~= "vigor" then d.style = "icons" end
    if d.showSpeed == nil then d.showSpeed = true end
    if type(d.scale) ~= "number" then d.scale = 1.0 end
    return d
end

local function safeNum(v)
    if v == nil then return nil end
    if issecretvalue and issecretvalue(v) then return nil end
    if type(v) ~= "number" then return nil end
    return v
end

local function SpellTex(id)
    return (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(id)) or nil
end

local function ResolveId(entry)
    if entry.id then return entry.id end
    for _, id in ipairs(entry.ids) do
        if SpellTex(id) then entry.id = id; return id end
    end
    entry.id = entry.ids[1]
    return entry.id
end

local function FmtTime(t)
    if t >= 60 then return string.format("%d:%02d", math.floor(t / 60), math.floor(t % 60)) end
    if t >= 10 then return string.format("%d", math.floor(t + 0.5)) end
    return string.format("%.1f", t)
end

local TRAVEL_FORM_SPELL = 783

local function InTravelForm()
    if not (GetShapeshiftForm and GetShapeshiftFormInfo) then return false end
    local idx = GetShapeshiftForm()
    if type(idx) ~= "number" or idx == 0 then return false end
    local _, _, _, spellId = GetShapeshiftFormInfo(idx)
    return spellId == TRAVEL_FORM_SPELL
end

local function ReadCanGlide()

    local _isGliding, cg = C_PlayerInfo.GetGlidingInfo()
    return cg and true or false
end

local function ReadBonusBarSkyriding()
    return HasBonusActionBar() and GetBonusBarOffset() == 5
end

local function IsSkyriding()

    if UnitInVehicle and UnitInVehicle("player")
        and UnitInVehicleControlSeat and not UnitInVehicleControlSeat("player") then
        return false
    end
    local mounted = (IsMounted and IsMounted()) or InTravelForm()
    if not mounted then return false end

    if C_PlayerInfo and C_PlayerInfo.GetGlidingInfo then
        local ok, canGlide = pcall(ReadCanGlide)

        if ok then return canGlide end
    end

    if GetBonusBarOffset and HasBonusActionBar then
        local ok, active = pcall(ReadBonusBarSkyriding)
        if ok and active then return true end
    end
    return false
end

local function CreateSlot(parent)
    local s = CreateFrame("Frame", nil, parent)

    s.bg = s:CreateTexture(nil, "BACKGROUND")
    s.bg:SetColorTexture(Theme.rgba(Theme.colors.insetBg))

    s.border = s:CreateTexture(nil, "BORDER")
    s.border:SetColorTexture(Theme.rgba(Theme.colors.border))

    s.icon = s:CreateTexture(nil, "ARTWORK")
    s.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    s.cd = CreateFrame("Cooldown", nil, s, "CooldownFrameTemplate")
    s.cd:SetDrawEdge(true)
    if s.cd.SetHideCountdownNumbers then s.cd:SetHideCountdownNumbers(true) end

    s.chargeText = s:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(s.chargeText, 12, "OUTLINE")
    s.chargeText:SetJustifyH("RIGHT")

    s.timeText = s:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(s.timeText, 14, "OUTLINE")
    s.timeText:SetJustifyH("CENTER")

    s.bar = CreateFrame("StatusBar", nil, s)
    s.bar:SetStatusBarTexture(FLAT)
    s.bar:SetStatusBarColor(0.22, 0.46, 0.76)
    s.barBg = s.bar:CreateTexture(nil, "BACKGROUND")
    s.barBg:SetAllPoints()
    s.barBg:SetColorTexture(Theme.rgba(Theme.colors.panelBg))

    s.nameText = s.bar:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(s.nameText, 11, "OUTLINE")
    s.nameText:SetPoint("LEFT", s.bar, "LEFT", 5, 0)
    s.nameText:SetJustifyH("LEFT")
    s.nameText:SetTextColor(Theme.rgba(Theme.colors.text))

    s.barValueText = s.bar:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(s.barValueText, 11, "OUTLINE")
    s.barValueText:SetPoint("RIGHT", s.bar, "RIGHT", -5, 0)
    s.barValueText:SetJustifyH("RIGHT")

    return s
end

local function EnsureVigorRow()
    if vigorRow then return vigorRow end
    local r = CreateFrame("Frame", nil, frame)
    r.pips = {}
    for i = 1, VIG_MAX_PIPS do
        local p = CreateFrame("StatusBar", nil, r)
        p:SetStatusBarTexture(FLAT)
        p:SetStatusBarColor(0.27, 0.62, 0.90)
        p:SetMinMaxValues(0, 1)
        p:SetValue(0)
        local bg = p:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(Theme.rgba(Theme.colors.panelBg))
        local edge = p:CreateTexture(nil, "BORDER")
        edge:SetPoint("TOPLEFT", -1, 1)
        edge:SetPoint("BOTTOMRIGHT", 1, -1)
        edge:SetColorTexture(Theme.rgba(Theme.colors.border))
        edge:SetDrawLayer("BORDER", -1)
        p:Hide()
        r.pips[i] = p
    end

    r.abil = {}

    r.speed = CreateFrame("StatusBar", nil, r)
    r.speed:SetStatusBarTexture(FLAT)
    r.speed:SetStatusBarColor(0.27, 0.62, 0.90)
    r.speed:SetMinMaxValues(0, SPD_MAX_PCT)
    r.speed:SetValue(0)
    local sbg = r.speed:CreateTexture(nil, "BACKGROUND")
    sbg:SetAllPoints()
    sbg:SetColorTexture(Theme.rgba(Theme.colors.panelBg))
    local sedge = r.speed:CreateTexture(nil, "BORDER")
    sedge:SetPoint("TOPLEFT", -1, 1)
    sedge:SetPoint("BOTTOMRIGHT", 1, -1)
    sedge:SetColorTexture(Theme.rgba(Theme.colors.border))
    sedge:SetDrawLayer("BORDER", -1)
    r.speedText = r.speed:CreateFontString(nil, "OVERLAY")
    Theme.SetFont(r.speedText, 10, "OUTLINE")
    r.speedText:SetPoint("CENTER", r.speed, "CENTER", 0, 0)
    r.speed:Hide()

    r:Hide()
    vigorRow = r
    return r
end

local function EnsureVigorAbility(r, k)
    local a = r.abil[k]
    if a then return a end
    a = {}
    a.border = r:CreateTexture(nil, "BORDER")
    a.border:SetColorTexture(Theme.rgba(Theme.colors.border))
    a.icon = r:CreateTexture(nil, "ARTWORK")
    a.icon:SetSize(VIG_ICON, VIG_ICON)
    a.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    a.cd = CreateFrame("Cooldown", nil, r, "CooldownFrameTemplate")
    a.cd:SetDrawEdge(true)
    if a.cd.SetHideCountdownNumbers then a.cd:SetHideCountdownNumbers(true) end
    a.charge = a.cd:CreateFontString(nil, "OVERLAY")
    if not Theme.SetFont(a.charge, 13, "OUTLINE", true) then
        a.charge:SetFont(STANDARD_TEXT_FONT, 13, "OUTLINE")
    end
    a.charge:SetDrawLayer("OVERLAY", 7)
    a.charge:SetTextColor(1, 1, 1, 1)
    a.charge:SetText("")
    r.abil[k] = a
    return a
end

local function VigorAbilityCount()
    if not slots then return 0 end
    local n = #slots - 1
    if n < 0 then n = 0 end
    if n > VIG_MAX_ABIL then n = VIG_MAX_ABIL end
    return n
end

local function LayoutVigor(n)
    if not n or n < 1 then n = 1 end
    local r = EnsureVigorRow()
    local wantSpeed = DB().showSpeed ~= false
    local nAbil = VigorAbilityCount()
    if r.shownPips == n and r.speedShown == wantSpeed and r.shownAbil == nAbil then return end
    r.shownPips, r.speedShown, r.shownAbil = n, wantSpeed, nAbil
    local rowH = math.max(VIG_PIP_H, VIG_ICON)
    local topPad = (rowH - VIG_PIP_H) / 2
    for i = 1, VIG_MAX_PIPS do
        local p = r.pips[i]
        if i <= n then
            p:ClearAllPoints()
            p:SetPoint("TOPLEFT", r, "TOPLEFT", (i - 1) * (VIG_PIP_W + VIG_GAP), -topPad)
            p:SetSize(VIG_PIP_W, VIG_PIP_H)
            p:Show()
        else
            p:Hide()
        end
    end
    local barsW = n * VIG_PIP_W + (n - 1) * VIG_GAP

    local x = barsW + 6
    for k = 1, VIG_MAX_ABIL do
        if k <= nAbil then
            local a = EnsureVigorAbility(r, k)
            a.icon:ClearAllPoints()
            a.icon:SetPoint("TOPLEFT", r, "TOPLEFT", x, 0)
            a.icon:SetSize(VIG_ICON, VIG_ICON)
            a.icon:Show()
            a.border:ClearAllPoints()
            a.border:SetPoint("TOPLEFT", a.icon, "TOPLEFT", -1, 1)
            a.border:SetPoint("BOTTOMRIGHT", a.icon, "BOTTOMRIGHT", 1, -1)
            a.border:Show()
            a.cd:ClearAllPoints()
            a.cd:SetAllPoints(a.icon)
            a.cd:Show()
            a.charge:ClearAllPoints()
            a.charge:SetPoint("BOTTOMRIGHT", a.cd, "BOTTOMRIGHT", -1, 2)
            x = x + VIG_ICON + VIG_ABIL_GAP
        else
            local a = r.abil[k]
            if a then
                a.icon:Hide()
                a.border:Hide()
                a.cd:Hide()
            end
        end
    end

    local w = (nAbil > 0) and (x - VIG_ABIL_GAP) or barsW
    local h = rowH
    if wantSpeed then
        r.speed:ClearAllPoints()
        r.speed:SetPoint("TOPLEFT", r, "TOPLEFT", 0, -(rowH + SPD_GAP))
        r.speed:SetSize(barsW, SPD_H)
        r.speed:Show()
        h = h + SPD_GAP + SPD_H
    else
        r.speed:Hide()
    end
    r:SetSize(w, h)
    r:ClearAllPoints()
    r:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    frame:SetSize(w, h)
end

local function ReadSpeedRaw()
    if C_PlayerInfo and C_PlayerInfo.GetGlidingInfo then
        local isGliding, _, fwd = C_PlayerInfo.GetGlidingInfo()
        if isGliding and fwd ~= nil and not (issecretvalue and issecretvalue(fwd))
            and type(fwd) == "number" then
            return fwd / 7 * 100
        end
    end
    if GetUnitSpeed then
        local cur = GetUnitSpeed("player")
        if cur ~= nil and not (issecretvalue and issecretvalue(cur)) and type(cur) == "number" then
            return cur / 7 * 100
        end
    end
end

local function ReadSpeedPct()
    local ok, pct = pcall(ReadSpeedRaw)
    if ok then return pct end
end

local function UpdateSpeed(r)
    if not r.speed or not r.speed:IsShown() then return end
    local pct = ReadSpeedPct()
    if not pct then return end
    if pct < 0 then pct = 0 elseif pct > SPD_MAX_PCT then pct = SPD_MAX_PCT end
    r.speed:SetValue(pct)
    r.speedText:SetFormattedText("%d%%", pct + 0.5)
    if pct >= SPD_THRILL_PCT then
        r.speed:SetStatusBarColor(1.0, 0.82, 0.20)
    else
        r.speed:SetStatusBarColor(0.27, 0.62, 0.90)
    end
end

local function UpdateVigor()
    if not vigorRow or not slots then return end
    local r = vigorRow
    UpdateSpeed(r)

    for k = 1, VigorAbilityCount() do
        local a = r.abil[k]
        local sid = slots[k + 1] and slots[k + 1].id
        if a and sid then
            local tex = SpellTex(sid)
            if tex then a.icon:SetTexture(tex) end

            local ch = C_Spell and C_Spell.GetSpellCharges and C_Spell.GetSpellCharges(sid)
            if type(ch) == "table" then
                local st, du = safeNum(ch.cooldownStartTime), safeNum(ch.cooldownDuration)
                if a._start ~= st or a._dur ~= du then
                    a._start, a._dur = st, du
                    a.cd:SetCooldown(ch.cooldownStartTime, ch.cooldownDuration, ch.chargeModRate)
                end
                local cur, mx = safeNum(ch.currentCharges), safeNum(ch.maxCharges)
                if cur and mx and mx > 1 then
                    a.charge:SetText(tostring(cur))
                else
                    a.charge:SetText("")
                end
                a.icon:SetDesaturated((cur or 1) <= 0)
            else
                a.charge:SetText("")
                local cd = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(sid)
                if type(cd) == "table" then
                    local st, du = safeNum(cd.startTime), safeNum(cd.duration)
                    if a._start ~= st or a._dur ~= du then
                        a._start, a._dur = st, du
                        a.cd:SetCooldown(cd.startTime, cd.duration, cd.modRate)
                    end
                    a.icon:SetDesaturated((du and du > 0) and true or false)
                else
                    if a._start ~= nil or a._dur ~= nil then
                        a._start, a._dur = nil, nil
                        if a.cd.Clear then a.cd:Clear() end
                    end
                    a.icon:SetDesaturated(false)
                end
            end
        end
    end

    local sfId = slots[1] and slots[1].id
    local charges = sfId and C_Spell and C_Spell.GetSpellCharges and C_Spell.GetSpellCharges(sfId)
    if type(charges) ~= "table" then

        if previewActive then
            LayoutVigor(lastVigorMax or 6)
            for i = 1, r.shownPips or 0 do r.pips[i]:SetValue(1) end
        end
        return
    end
    local cur, mx = safeNum(charges.currentCharges), safeNum(charges.maxCharges)
    if not cur or not mx or mx <= 0 then return end
    if mx > VIG_MAX_PIPS then mx = VIG_MAX_PIPS end
    if cur > mx then cur = mx end
    lastVigorMax = mx
    LayoutVigor(mx)

    local start, dur = safeNum(charges.cooldownStartTime), safeNum(charges.cooldownDuration)
    for i = 1, mx do
        local p = r.pips[i]
        if i <= cur then
            p:SetValue(1)
        elseif i == cur + 1 and start and dur and dur > 0 then
            local pct = (GetTime() - start) / dur
            if pct < 0 then pct = 0 elseif pct > 1 then pct = 1 end
            p:SetValue(pct)
        else
            p:SetValue(0)
        end
    end
end

local function ApplyStyle()
    if not frame or not slots then return end
    local style = DB().style
    local n = #slots

    if style == "vigor" then
        for _, s in ipairs(slots) do s:Hide() end
        local r = EnsureVigorRow()
        r.shownPips = nil
        LayoutVigor(lastVigorMax or 6)
        r:Show()
        UpdateVigor()
        return
    end
    if vigorRow then vigorRow:Hide() end
    for _, s in ipairs(slots) do s:Show() end

    if style == "bars" then
        local rowH = math.max(BAR_H, BAR_ICON)
        for i, s in ipairs(slots) do
            s:ClearAllPoints()
            s:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -(i - 1) * (rowH + ROW_PAD))
            s:SetSize(BAR_ICON + 5 + BAR_W, rowH)

            s.icon:ClearAllPoints()
            s.icon:SetPoint("LEFT", s, "LEFT", 0, 0)
            s.icon:SetSize(BAR_ICON, BAR_ICON)
            s.bg:ClearAllPoints(); s.bg:SetAllPoints(s.icon)
            s.border:ClearAllPoints()
            s.border:SetPoint("TOPLEFT", s.icon, "TOPLEFT", -1, 1)
            s.border:SetPoint("BOTTOMRIGHT", s.icon, "BOTTOMRIGHT", 1, -1)
            s.cd:SetAllPoints(s.icon)

            s.bar:ClearAllPoints()
            s.bar:SetPoint("LEFT", s.icon, "RIGHT", 5, 0)
            s.bar:SetSize(BAR_W, BAR_H)
            s.bar:Show(); s.nameText:Show(); s.barValueText:Show()
            s.nameText:SetText(s.label)

            s.chargeText:Hide(); s.timeText:Hide()
        end
        frame:SetSize(BAR_ICON + 5 + BAR_W, n * rowH + (n - 1) * ROW_PAD)
    else
        for i, s in ipairs(slots) do
            s:ClearAllPoints()
            s:SetPoint("TOPLEFT", frame, "TOPLEFT", (i - 1) * (ICON_SIZE + ICON_PAD), 0)
            s:SetSize(ICON_SIZE, ICON_SIZE)

            s.icon:ClearAllPoints()
            s.icon:SetPoint("TOPLEFT", s, "TOPLEFT", 0, 0)
            s.icon:SetSize(ICON_SIZE, ICON_SIZE)
            s.bg:ClearAllPoints(); s.bg:SetAllPoints(s.icon)
            s.border:ClearAllPoints()
            s.border:SetPoint("TOPLEFT", s.icon, "TOPLEFT", -1, 1)
            s.border:SetPoint("BOTTOMRIGHT", s.icon, "BOTTOMRIGHT", 1, -1)
            s.cd:SetAllPoints(s.icon)

            s.chargeText:ClearAllPoints()
            s.chargeText:SetPoint("BOTTOMRIGHT", s.icon, "BOTTOMRIGHT", -1, 1)
            s.timeText:ClearAllPoints()
            s.timeText:SetPoint("CENTER", s.icon, "CENTER", 0, 0)
            s.chargeText:Show(); s.timeText:Show()

            s.bar:Hide(); s.nameText:Hide(); s.barValueText:Hide()
        end
        frame:SetSize(n * ICON_SIZE + (n - 1) * ICON_PAD, ICON_SIZE)
    end
end

local function UpdateSlot(s)
    local id = s.id
    local tex = SpellTex(id)
    if tex then s.icon:SetTexture(tex) end

    local charges = C_Spell and C_Spell.GetSpellCharges and C_Spell.GetSpellCharges(id)
    if type(charges) == "table" then
        s.isCharge = true
        s._start, s._dur = nil, nil

        s.cd:SetCooldown(charges.cooldownStartTime, charges.cooldownDuration, charges.chargeModRate)
        local cur, mx = safeNum(charges.currentCharges), safeNum(charges.maxCharges)
        if cur and mx then
            s.chargeText:SetText(cur .. "/" .. mx)
            s.barValueText:SetText(cur .. "/" .. mx)
            s.icon:SetDesaturated(cur <= 0)
            s.bar:SetMinMaxValues(0, mx)
            s.bar:SetValue(cur)
        else
            s.chargeText:SetText("")
            s.barValueText:SetText("")
            s.icon:SetDesaturated(false)
            s.bar:SetMinMaxValues(0, 1)
            s.bar:SetValue(1)
        end
        s.timeText:SetText("")
    else
        s.isCharge = false
        local cd = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(id)
        if type(cd) == "table" then
            s.cd:SetCooldown(cd.startTime, cd.duration, cd.modRate)
            s._start, s._dur = safeNum(cd.startTime), safeNum(cd.duration)
        else
            if s.cd.Clear then s.cd:Clear() end
            s._start, s._dur = nil, nil
        end
        s.chargeText:SetText("")
        local onCD = (s._dur and s._dur > 0) and true or false
        s.icon:SetDesaturated(onCD)
        s.bar:SetMinMaxValues(0, 1)
        if onCD and s._start then
            local frac = ((s._start + s._dur) - GetTime()) / s._dur
            if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
            s.bar:SetValue(frac)
        else
            s.bar:SetValue(onCD and 0 or 1)
            s.barValueText:SetText("")
        end
    end
end

local function UpdateAll()
    if not slots then return end
    if DB().style == "vigor" then
        UpdateVigor()
        return
    end
    for _, s in ipairs(slots) do UpdateSlot(s) end
end

local function Tick()
    if not slots then return end
    if previewActive and frame and frame.previewCD then
        local rem = previewEndTime - GetTime()
        if rem < 0 then rem = 0 end
        frame.previewCD:SetFormattedText("%ds", math.ceil(rem))
    end
    if DB().style == "vigor" then
        UpdateVigor()
        return
    end
    local now = GetTime()
    for _, s in ipairs(slots) do
        if not s.isCharge and s._start and s._dur and s._dur > 0 then
            local rem = (s._start + s._dur) - now
            if rem > 0 then
                s.timeText:SetText(FmtTime(rem))
                s.barValueText:SetText(FmtTime(rem))
                local frac = rem / s._dur
                if frac < 0 then frac = 0 elseif frac > 1 then frac = 1 end
                s.bar:SetValue(frac)
            else
                s.timeText:SetText("")
                s.barValueText:SetText("")
                s.icon:SetDesaturated(false)
                s.bar:SetValue(1)
                s._start, s._dur = nil, nil
            end
        end
    end
end

local function StartTicker() if not ticker then ticker = C_Timer.NewTicker(0.2, Tick) end end
local function StopTicker() if ticker then ticker:Cancel(); ticker = nil end end

local function UpdateVisibility()
    if not frame then return end
    local show = (DB().enabled ~= false) and (previewActive or IsSkyriding())
    if show then
        frame:Show()
        UpdateAll()
        StartTicker()
    else
        frame:Hide()
        StopTicker()
    end
end

-- True between OnDragStart and OnDragStop. If the drag is interrupted (preview
-- expires, the frame is hidden, the mouse is disabled) OnDragStop never fires, so
-- the frame would stay glued to the cursor AND the new spot would never be saved.
local isMoving = false
local StopMovingAndSave  -- defined with the drag scripts below

local function SetInteractive(on)
    if not frame then return end
    -- About to take the mouse away while a drag is in flight: finish and save it
    -- first, otherwise the tracker sticks to the cursor.
    if isMoving and not on and StopMovingAndSave then StopMovingAndSave() end
    frame:EnableMouse(on and true or false)
    frame:SetFrameStrata(on and "TOOLTIP" or "MEDIUM")
    if on and not frame.previewHL then
        local hl = frame:CreateTexture(nil, "BACKGROUND")
        hl:SetPoint("TOPLEFT", -3, 3)
        hl:SetPoint("BOTTOMRIGHT", 3, -3)
        hl:SetColorTexture(Theme.rgba(Theme.colors.rowHover))
        frame.previewHL = hl
    end
    if frame.previewHL then frame.previewHL:SetShown(on and true or false) end
    if on and not frame.previewCD then

        local fs = frame:CreateFontString(nil, "OVERLAY")
        Theme.SetFont(fs, 10, "OUTLINE")
        fs:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 0, 4)
        fs:SetTextColor(0.55, 0.80, 1.0, 0.95)
        frame.previewCD = fs
    end
    if frame.previewCD then frame.previewCD:SetShown(on and true or false) end
end

-- Applies the position saved for the CURRENT screen; falls back to the default spot.
local function ApplyPosition()
    if not frame then return end
    local d = DB()
    local sc = d.scale or 1.0
    if sc <= 0 then sc = 1.0 end
    local cx, cy = AkcQOL_ScreenPos.Get(d, frame)
    frame:ClearAllPoints()
    if cx and cy then
        frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx / sc, cy / sc)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
    end
end

local function CreateTracker()
    if frame then return end
    local d = DB()
    frame = CreateFrame("Frame", "AkcQOLSkyridingFrame", UIParent, "BackdropTemplate")
    frame:SetFrameStrata("MEDIUM")
    frame:SetSize(150, 44)
    frame:SetClampedToScreen(false)
    frame:SetMovable(true)
    Theme.ApplyBackdrop(frame, "panel", { borderless = true })
    frame:EnableMouse(false)
    frame:RegisterForDrag("LeftButton")
    StopMovingAndSave = function()
        if not frame then return end
        frame:StopMovingOrSizing()
        isMoving = false
        local l, t = frame:GetLeft(), frame:GetTop()
        if l and t then
            -- Saved per screen; legacy posX/posY left untouched so another
            -- machine's spot is not overwritten (see Core/ScreenPos.lua).
            AkcQOL_ScreenPos.Save(DB(), frame)
            -- Re-anchor by CENTRE so switching layout style never slides it.
            local w, h = frame:GetWidth(), frame:GetHeight()
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", l + w / 2, t - h / 2)
        end
    end
    frame:SetScript("OnDragStart", function(self) self:StartMoving(); isMoving = true end)
    frame:SetScript("OnDragStop", StopMovingAndSave)
    -- Safety net: hidden mid-drag (mount dismissed, preview ends) -> finish the move
    -- instead of leaving it stuck to the cursor with the new spot unsaved.
    frame:SetScript("OnHide", function() if isMoving then StopMovingAndSave() end end)

    frame:SetScale(d.scale or 1.0)

    slots = {}
    for i, entry in ipairs(ABILITIES) do
        local s = CreateSlot(frame)
        s.id = ResolveId(entry)

        local name = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(s.id)
        s.label = (type(name) == "string" and name ~= "") and name or entry.label
        slots[i] = s
    end
    ApplyStyle()
    -- After SetScale + ApplyStyle: the proportional carry-over measures the frame, so it
    -- must run once the real size and scale are in place (not the constructor stub).
    ApplyPosition()
    frame:Hide()
end

function _G.AkcQOL_ApplySkyridingVisibility()
    if not frame then CreateTracker() end
    UpdateVisibility()
end

function _G.AkcQOL_SetSkyridingStyle(style)
    local d = DB()
    d.style = (style == "bars" or style == "vigor") and style or "icons"
    if not frame then CreateTracker() end
    ApplyStyle()
    UpdateAll()
end

function _G.AkcQOL_SetSkyridingScale(scale)
    local d = DB()
    if type(scale) == "number" then d.scale = scale end
    if frame then
        frame:SetScale(d.scale or 1.0)
        ApplyPosition()
    end
end

function _G.AkcQOL_RefreshSkyriding()
    if not frame then CreateTracker() end
    ApplyStyle()
    UpdateAll()
    UpdateVisibility()
end

function _G.AkcQOL_PreviewSkyriding()
    if not frame then CreateTracker() end
    previewToken = previewToken + 1
    local token = previewToken
    previewActive = true
    previewEndTime = GetTime() + 12
    SetInteractive(true)
    if frame.previewCD then frame.previewCD:SetFormattedText("%ds", 12) end
    frame:Show()
    ApplyStyle()
    UpdateAll()

    StartTicker()
    if C_Timer and C_Timer.After then
        C_Timer.After(12, function()
            if token ~= previewToken then return end
            previewActive = false
            SetInteractive(false)
            UpdateVisibility()
        end)
    end
end

function _G.AkcQOL_ResetSkyridingPosition()
    if not frame then CreateTracker() end
    frame:Show()
    ApplyStyle()
    UpdateAll()
    -- Reset only THIS screen: drop its entry, recentre, then record the new spot so
    -- it wins over the legacy value. Other displays keep their own layout.
    local d = DB()
    AkcQOL_ScreenPos.Clear(d)
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
    -- stays anchored by CENTRE (set just above) so a later style change cannot slide it
    if frame:GetLeft() then AkcQOL_ScreenPos.Save(d, frame) end
    if _G.AkcQOL_PreviewSkyriding then _G.AkcQOL_PreviewSkyriding() end
end

function _G.AkcQOL_ResetSkyridingDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.skyriding = nil end
    local d = DB()
    if not frame then CreateTracker() end
    frame:SetScale(d.scale or 1.0)
    ApplyStyle()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
    -- stays anchored by CENTRE (set just above) so a later style change cannot slide it
    if frame:GetLeft() then AkcQOL_ScreenPos.Save(d, frame) end
    UpdateAll()
    UpdateVisibility()
end

local SHOW_EVENTS = {
    "PLAYER_MOUNT_DISPLAY_CHANGED", "PLAYER_CAN_GLIDE_CHANGED", "PLAYER_IS_GLIDING_CHANGED",
    "UNIT_ENTERED_VEHICLE", "UNIT_EXITED_VEHICLE", "VEHICLE_UPDATE",
    "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_FORMS", "PLAYER_ENTERING_WORLD",
}
local DATA_EVENTS = { "SPELL_UPDATE_CHARGES", "SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_USABLE" }

eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
for _, e in ipairs(SHOW_EVENTS) do pcall(eventFrame.RegisterEvent, eventFrame, e) end
for _, e in ipairs(DATA_EVENTS) do pcall(eventFrame.RegisterEvent, eventFrame, e) end

eventFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()
        CreateTracker()
        UpdateVisibility()
        return
    end
    if not frame then return end
    if event == "SPELL_UPDATE_CHARGES" or event == "SPELL_UPDATE_COOLDOWN" or event == "SPELL_UPDATE_USABLE" then
        if frame:IsShown() then UpdateAll() end
    else
        UpdateVisibility()
    end
end)
