local queue = {}
local seen = {}
local session = { active = false, index = 0, pendingAdvance = false, runId = 0 }
local win
local bridge = {}
local origBagClick
local setupDone = false
local UpdateWindow, EnsureWindow, PositionWindow, EndSession

local L = AkcQOL_L
local Theme = _G.AkcQOL_Theme

local function Msg(text)
  print("|cff8c5cffAkc|r|cffffffffHouse|r: " .. text)
end

local function QueueName(entry)
  return entry.name or (entry.link and (C_Item.GetItemInfo(entry.link))) or entry.link or "?"
end

local function Events()
  return AkcHouse and AkcHouse.Selling and AkcHouse.Selling.Events
end

local function LoadIndex(i)
  local entry = queue[i]
  if not entry or not entry.key then return end
  local E = Events()
  if AkcHouse and AkcHouse.EventBus and E then
    AkcHouse.EventBus:Fire(bridge, E.BagItemRequest, entry.key)
  end
  local runId = session.runId
  C_Timer.After(6, function()
    if session.active and session.runId == runId and session.index == i
        and entry.status == "pending"
        and not (_G.AkcHousePostButton and _G.AkcHousePostButton:IsEnabled()) then
      entry.status = "fail"
      Msg(string.format(L["|cFFF59E0B%s|r could not be loaded and was skipped."], QueueName(entry)))
      session.index = session.index + 1
      if queue[session.index] then LoadIndex(session.index) else EndSession() end
      if UpdateWindow then UpdateWindow() end
    end
  end)
end

function EndSession(silent)
  session.active = false
  session.pendingAdvance = false

  local ok, fail = 0, 0
  for i = #queue, 1, -1 do
    local e = queue[i]
    if e.status == "ok" then
      ok = ok + 1
      if e.sortKey then seen[e.sortKey] = nil end
      table.remove(queue, i)
    elseif e.status == "fail" then
      fail = fail + 1
    end
  end

  if not silent then
    Msg(string.format(L["Post queue done: |cFF59D97B%d posted|r%s."], ok,
      fail > 0 and string.format(L[", |cFFF25850%d skipped|r"], fail) or ""))
  end
  if UpdateWindow then UpdateWindow() end
end

function bridge:ReceiveEvent(eventName, postedInfo)
  local E = Events()
  if E and eventName == E.AuctionCreated and session.active then
    local entry = queue[session.index]
    if not entry then return end
    if type(postedInfo) == "table" and postedInfo.itemLink and entry.link
        and postedInfo.itemLink ~= entry.link then
      return
    end
    entry.status = "ok"
    if type(postedInfo) == "table" then
      entry.postedTotal = (postedInfo.buyoutAmount or 0) * (postedInfo.quantity or 1)
    end
    session.pendingAdvance = true
  end
end

local function AddToQueue(viewItem)
  local info = viewItem and viewItem.itemInfo
  if not info then return end

  if not session.active then
    for _, e in ipairs(queue) do
      if e.status ~= "pending" then
        wipe(queue)
        wipe(seen)
        break
      end
    end
  end

  local sortKey = info.sortKey
  if sortKey and seen[sortKey] then
    Msg(string.format(L["Already in the post queue: |cFFF59E0B%s|r"], info.itemName or "?"))
    return
  end
  if sortKey then seen[sortKey] = true end
  local entry = {
    key = viewItem.key,
    sortKey = sortKey,
    link = info.itemLink,
    name = info.itemName,
    icon = info.iconTexture,
    count = info.itemCount or 1,
    status = "pending",
  }
  queue[#queue + 1] = entry

  if AkcHouse.Utilities and AkcHouse.Utilities.DBKeyFromLink and AkcHouse.Database and info.itemLink then
    pcall(AkcHouse.Utilities.DBKeyFromLink, info.itemLink, function(dbKeys)
      local price = dbKeys and dbKeys[1] and AkcHouse.Database:GetPrice(dbKeys[1])
      if price then
        entry.estUnit = price
        if UpdateWindow then UpdateWindow() end
      end
    end)
  end

  if _G.AkcHouseBuyAllDialog and _G.AkcHouseBuyAllDialog:IsShown() then
    _G.AkcHouseBuyAllDialog:Hide()
  end
  PositionWindow()
  win:Show()
  UpdateWindow()
end

-- Remove one entry. The bag item becomes addable again, and a running
-- session keeps pointing at the same item it was about to post.
local function RemoveFromQueue(index)
  local entry = queue[index]
  if not entry then return end
  if session.active and index == session.index and entry.status == "pending" then
    Msg(L["The line being posted right now cannot be removed."])
    return
  end

  table.remove(queue, index)
  if entry.sortKey then seen[entry.sortKey] = nil end

  if session.active then
    if index < session.index then
      session.index = session.index - 1
    end
    if #queue == 0 then
      EndSession(true)
    end
  end

  if UpdateWindow then UpdateWindow() end
end

local function ClearQueue()
  if session.active then EndSession(true) end
  wipe(queue)
  wipe(seen)
  if UpdateWindow then UpdateWindow() end
end

local function StartSession()
  if session.active or #queue == 0 then return end
  for _, e in ipairs(queue) do e.status = "pending" end
  session.active = true
  session.pendingAdvance = false
  session.runId = session.runId + 1
  session.index = 1
  LoadIndex(1)
  if UpdateWindow then UpdateWindow() end
end

local MARK = {
  pending = "|cFF9AA0A6-|r ",
  ok      = "|cFF59D97B[ok]|r ",
  fail    = "|cFFF25850[x]|r ",
  current = "|cFFFFD100>|r ",
}

-- UIPanelButtonTemplate moves its label between GameFontNormal,
-- GameFontHighlight and GameFontDisable on hover and on Enable/Disable, and
-- every move dropped the theme font set on the label itself: one hover put
-- the label back in the game font (no Turkish g-breve, s-cedilla or dotted
-- capital I, no text scale) until the next refresh. Theme copies of those
-- three objects keep each state's colour, and Theme.SetFont registers them
-- so a text scale change resizes them too. Built once, shared by both buttons.
local BUTTON_FONTS = {
  { "SetNormalFontObject", "GameFontNormal", "AkcQOLPostQueueFontNormal" },
  { "SetHighlightFontObject", "GameFontHighlight", "AkcQOLPostQueueFontHighlight" },
  { "SetDisabledFontObject", "GameFontDisable", "AkcQOLPostQueueFontDisable" },
}
local buttonFonts

local function ThemeButtonFonts(button)
  if not (button and Theme and Theme.SetFont and CreateFont) then return false end
  if not buttonFonts then
    local fonts = {}
    for i, spec in ipairs(BUTTON_FONTS) do
      local base = _G[spec[2]]
      -- A failed earlier attempt may already have made this global.
      local font = _G[spec[3]]
      if not font then
        local ok, created = pcall(CreateFont, spec[3])
        font = ok and created or nil
      end
      if not (font and base and font.CopyFontObject
          and pcall(font.CopyFontObject, font, base)) then
        return false
      end
      local _, size, flags = font:GetFont()
      if not Theme.SetFont(font, size or 12, flags) then return false end
      fonts[i] = font
    end
    buttonFonts = fonts
  end
  for i, spec in ipairs(BUTTON_FONTS) do
    local setter = button[spec[1]]
    if not (setter and pcall(setter, button, buttonFonts[i])) then return false end
  end
  button.akcThemedFonts = true
  return true
end

function EnsureWindow()
  if win then return win end

  win = CreateFrame("Frame", "AkcHousePostQueueFrame", UIParent, "BackdropTemplate")
  win:SetSize(300, 260)
  win:SetFrameStrata("HIGH")
  win:SetClampedToScreen(true)
  win:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 },
  })
  win:EnableMouse(true)
  win:SetMovable(true)
  win:RegisterForDrag("LeftButton")
  win:SetScript("OnDragStart", win.StartMoving)
  win:SetScript("OnDragStop", win.StopMovingOrSizing)
  win:Hide()

  win.Title = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  win.Title:SetPoint("TOP", 0, -14)
  win.Title:SetText("|cffffd100" .. L["Post Queue"] .. "|r")

  win.Hint = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  win.Hint:SetPoint("TOP", win.Title, "BOTTOM", 0, -2)
  win.Hint:SetTextColor(0.65, 0.65, 0.70, 1)

  -- One button per line so a single entry can be removed; the old single
  -- FontString could not be clicked at all.
  win.rows = {}
  win.Empty = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  win.Empty:SetPoint("TOPLEFT", 18, -50)
  win.Empty:SetPoint("RIGHT", -18, 0)
  win.Empty:SetJustifyH("LEFT")
  win.Empty:SetText("|cFF808080" .. L["Queue is empty."] .. "|r")

  win.Total = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  -- Marked so the theme's tooltip handling recognises this as one of ours.
  win.akcqolTooltip = true
  win.Total:SetPoint("BOTTOM", 0, 46)

  win.PostAll = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
  win.PostAll:SetSize(130, 24)
  win.PostAll:SetPoint("BOTTOMRIGHT", win, "BOTTOM", -4, 14)
  win.PostAll:SetText(L["Post All"])
  win.PostAll:SetScript("OnClick", function()
    if session.active then
      local nb = _G.AkcHousePostButton
      if nb and nb:IsEnabled() then nb:Click() end
    else
      StartSession()
    end
  end)

  win.elapsed = 0
  win:SetScript("OnUpdate", function(self, dt)
    if not session.active then return end
    self.elapsed = self.elapsed + dt
    if self.elapsed >= 0.25 then
      self.elapsed = 0
      UpdateWindow()
    end
  end)

  win.Clear = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
  win.Clear:SetSize(130, 24)
  win.Clear:SetPoint("BOTTOMLEFT", win, "BOTTOM", 4, 14)
  win.Clear:SetText(L["Clear"])
  win.Clear:SetScript("OnClick", ClearQueue)

  win.Close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
  win.Close:SetPoint("TOPRIGHT", 2, 2)

  win:SetScript("OnHide", function()
    if session.active then EndSession(true) end
    if win.akcKeepQueue then
      win.akcKeepQueue = nil
      return
    end
    wipe(queue)
    wipe(seen)
  end)

  -- Once, after every static string exists. Doing this on every refresh
  -- walked the whole window each time an item was added or priced.
  if Theme and Theme.ApplyFonts then Theme.ApplyFonts(win) end
  -- After ApplyFonts: it reads a new label's size as its base, and the
  -- theme objects' size already has the text scale in it.
  ThemeButtonFonts(win.PostAll)
  ThemeButtonFonts(win.Clear)

  return win
end

-- Fallback for a button ThemeButtonFonts could not cover: Enable/Disable
-- swaps a UIPanelButton's font object, which drops the theme font from its
-- label. Re-theme a button only when that state has changed, not on every
-- refresh (the active session refreshes four times a second).
local function RethemeButton(button)
  if not (button and Theme and Theme.ApplyFonts) or button.akcThemedFonts then return end
  local enabled = button:IsEnabled() and true or false
  if button.akcThemedEnabled == enabled then return end
  button.akcThemedEnabled = enabled
  Theme.ApplyFonts(button)
end

function UpdateWindow()
  if not win or not win:IsShown() then return end

  local rows = {}
  local postedSum, estSum = 0, 0
  for i, entry in ipairs(queue) do
    local isCurrent = session.active and i == session.index and entry.status == "pending"
    local mark = isCurrent and MARK.current or (MARK[entry.status] or MARK.pending)

    local color
    if entry.status == "ok" then color = "|cFF59D97B"
    elseif entry.status == "fail" then color = "|cFF9AA0A6"
    elseif isCurrent then color = "|cFFFFD100"
    else color = "|cFFE5E7EB" end

    local qty = (entry.count and entry.count > 1) and (entry.count .. "x ") or ""
    local text = mark .. color .. qty .. QueueName(entry) .. "|r"

    if entry.status == "ok" and entry.postedTotal and entry.postedTotal > 0 then
      postedSum = postedSum + entry.postedTotal
      text = text .. "  |cFFE5E7EB—|r  " .. GetMoneyString(entry.postedTotal, true)
    elseif entry.status ~= "fail" and entry.estUnit then
      local est = entry.estUnit * (entry.count or 1)
      estSum = estSum + est
      text = text .. "  |cFF9AA0A6—  ~" .. GetMoneyString(est, true) .. "|r"
    end
    rows[#rows + 1] = text
  end

  win.Empty:SetShown(#rows == 0)
  for i, text in ipairs(rows) do
    local row = win.rows[i]
    if not row then
      row = CreateFrame("Button", nil, win)
      row:SetHeight(15)
      row:SetPoint("TOPLEFT", win, "TOPLEFT", 18, -50 - (i - 1) * 15)
      row:SetPoint("RIGHT", win, "RIGHT", -18, 0)
      row:RegisterForClicks("RightButtonUp")
      row.Text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      row.Text:SetPoint("LEFT")
      row.Text:SetPoint("RIGHT", row, "RIGHT", -14, 0)
      row.Text:SetJustifyH("LEFT")
      row.Remove = CreateFrame("Button", nil, row)
      row.Remove:SetSize(14, 14)
      row.Remove:SetPoint("RIGHT")
      row.Remove.Icon = row.Remove:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
      row.Remove.Icon:SetPoint("CENTER")
      row.Remove.Icon:SetText("|cFF9AA0A6x|r")
      if Theme and Theme.ApplyFonts then Theme.ApplyFonts(row) end
      row.Remove:SetScript("OnEnter", function(self)
        self.Icon:SetText("|cFFFF6B6Bx|r")
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L["Remove from queue"])
        GameTooltip:Show()
      end)
      row.Remove:SetScript("OnLeave", function(self)
        self.Icon:SetText("|cFF9AA0A6x|r")
        GameTooltip:Hide()
      end)
      row.Remove:SetScript("OnClick", function(self)
        RemoveFromQueue(self:GetParent().index)
      end)
      row:SetScript("OnClick", function(self)
        RemoveFromQueue(self.index)
      end)
      row:SetScript("OnEnter", function(self)
        if not self.link then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetHyperlink(self.link)
        GameTooltip:Show()
      end)
      row:SetScript("OnLeave", function() GameTooltip:Hide() end)
      win.rows[i] = row
    end
    row.index = i
    row.link = queue[i] and queue[i].link
    row.Text:SetText(text)
    row:Show()
  end
  for i = #rows + 1, #win.rows do
    win.rows[i]:Hide()
  end

  win:SetHeight(140 + math.max(1, #rows) * 15)

  local totalBits = {}
  if postedSum > 0 then
    totalBits[#totalBits + 1] = string.format(L["Posted: %s"], GetMoneyString(postedSum, true))
  end
  if estSum > 0 then
    totalBits[#totalBits + 1] = "|cFF9AA0A6" .. string.format(L["Est: ~%s"], GetMoneyString(estSum, true)) .. "|r"
  end
  win.Total:SetText(table.concat(totalBits, "   /   "))

  if session.active then
    local nb = _G.AkcHousePostButton
    local ready = nb and nb:IsEnabled()
    win.PostAll:SetText(string.format(L["Post %d/%d"], session.index, #queue))
    if ready then
      win.PostAll:Enable()
      win.Hint:SetText("|cFFFFD100" .. L["Keep clicking Post - one click posts one item."] .. "|r")
    else
      win.PostAll:Disable()
      win.Hint:SetText("|cFF9AA0A6" .. L["Loading price..."] .. "|r")
    end
    win.Clear:SetText(L["Stop"])
    win.Clear:SetScript("OnClick", function() EndSession() end)
  else
    win.Hint:SetText(L["Right-click bag items to add them here, or a line to remove it."])
    win.PostAll:SetText(string.format(L["Post All (%d)"], #queue))
    if #queue > 0 then win.PostAll:Enable() else win.PostAll:Disable() end
    win.Clear:SetText(L["Clear"])
    win.Clear:SetScript("OnClick", ClearQueue)
  end

  -- The whole window was themed once in EnsureWindow and rows when they are
  -- created; only the two button labels can lose the theme font afterwards,
  -- and only when ThemeButtonFonts could not give them theme font objects.
  RethemeButton(win.PostAll)
  RethemeButton(win.Clear)
end

function PositionWindow()
  local w = EnsureWindow()
  w:ClearAllPoints()
  if AuctionHouseFrame and AuctionHouseFrame:IsShown() then
    w:SetPoint("TOPLEFT", AuctionHouseFrame, "TOPRIGHT", 4, 0)
  else
    w:SetPoint("CENTER")
  end
end

local function Setup()
  if setupDone then return end
  local E = Events()
  if not (AkcHouse and AkcHouse.EventBus and E and AkcHouseBagUseMixin and AkcHouseSaleItemMixin) then
    return false
  end
  setupDone = true

  AkcHouse.EventBus:RegisterSource(bridge, "AkcQOLPostQueue")
  AkcHouse.EventBus:Register(bridge, { E.AuctionCreated })

  hooksecurefunc(AkcHouseSaleItemMixin, "PostItem", function()
    if not session.active or not session.pendingAdvance then return end
    session.pendingAdvance = false
    session.index = session.index + 1
    if queue[session.index] then LoadIndex(session.index) else EndSession() end
    if UpdateWindow then UpdateWindow() end
  end)

  hooksecurefunc(AkcHouseSaleItemMixin, "OnShow", function()
    if #queue > 0 then PositionWindow(); win:Show(); UpdateWindow() end
  end)

  origBagClick = AkcHouseBagUseMixin.BagItemClicked
  AkcHouseBagUseMixin.BagItemClicked = function(self, viewItem, mouseButton)
    if mouseButton == "RightButton" and not IsShiftKeyDown() and viewItem and viewItem.itemInfo then
      AddToQueue(viewItem)
      return
    end
    return origBagClick(self, viewItem, mouseButton)
  end

  if AkcHouseGroupsViewItemMixin then
    local origViewClick = AkcHouseGroupsViewItemMixin.OnClick
    AkcHouseGroupsViewItemMixin.OnClick = function(self, button)
      if button == "RightButton" and not IsShiftKeyDown()
          and self.itemInfo and self.clickEventName == "BagUse.BagItemClicked"
          and not IsModifiedClick("DRESSUP") and not IsModifiedClick("CHATLINK") then
        AddToQueue(self)
        return
      end
      return origViewClick(self, button)
    end
  end

  return true
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:RegisterEvent("PLAYER_ENTERING_WORLD")
boot:RegisterEvent("AUCTION_HOUSE_SHOW")
boot:RegisterEvent("AUCTION_HOUSE_CLOSED")
boot:SetScript("OnEvent", function(_, event)
  if event == "AUCTION_HOUSE_CLOSED" then
    if session.active then EndSession(true) end
    if win then win:Hide() end
    return
  end
  Setup()
end)

pcall(Setup)
