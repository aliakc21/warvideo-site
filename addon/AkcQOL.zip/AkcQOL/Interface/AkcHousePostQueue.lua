local queue = {}
local seen = {}
local session = { active = false, index = 0, pendingAdvance = false, runId = 0 }
local win
local bridge = {}
local origBagClick
local setupDone = false
local UpdateWindow, EnsureWindow, PositionWindow, EndSession

local function Msg(text)
  print("|cff8c5cffAkc|r|cffffffffHouse|r: " .. text)
end

local function QueueName(entry)
  return entry.name or (entry.link and (C_Item.GetItemInfo(entry.link))) or entry.link or "?"
end

local function Events()
  return AkcHouse and AkcHouse.Selling and AkcHouse.Selling.Events
end

local function LoadIndex(i)
  local entry = queue[i]
  if not entry or not entry.key then return end
  local E = Events()
  if AkcHouse and AkcHouse.EventBus and E then
    AkcHouse.EventBus:Fire(bridge, E.BagItemRequest, entry.key)
  end
  local runId = session.runId
  C_Timer.After(6, function()
    if session.active and session.runId == runId and session.index == i
        and entry.status == "pending"
        and not (_G.AkcHousePostButton and _G.AkcHousePostButton:IsEnabled()) then
      entry.status = "fail"
      Msg("|cFFF59E0B" .. QueueName(entry) .. "|r could not be loaded and was skipped.")
      session.index = session.index + 1
      if queue[session.index] then LoadIndex(session.index) else EndSession() end
      if UpdateWindow then UpdateWindow() end
    end
  end)
end

function EndSession(silent)
  session.active = false
  session.pendingAdvance = false

  local ok, fail = 0, 0
  for i = #queue, 1, -1 do
    local e = queue[i]
    if e.status == "ok" then
      ok = ok + 1
      if e.sortKey then seen[e.sortKey] = nil end
      table.remove(queue, i)
    elseif e.status == "fail" then
      fail = fail + 1
    end
  end

  if not silent then
    Msg("Post queue done: |cFF59D97B" .. ok .. " posted|r" .. (fail > 0 and (", |cFFF25850" .. fail .. " skipped|r") or "") .. ".")
  end
  if UpdateWindow then UpdateWindow() end
end

function bridge:ReceiveEvent(eventName, postedInfo)
  local E = Events()
  if E and eventName == E.AuctionCreated and session.active then
    local entry = queue[session.index]
    if not entry then return end
    if type(postedInfo) == "table" and postedInfo.itemLink and entry.link
        and postedInfo.itemLink ~= entry.link then
      return
    end
    entry.status = "ok"
    if type(postedInfo) == "table" then
      entry.postedTotal = (postedInfo.buyoutAmount or 0) * (postedInfo.quantity or 1)
    end
    session.pendingAdvance = true
  end
end

local function AddToQueue(viewItem)
  local info = viewItem and viewItem.itemInfo
  if not info then return end

  if not session.active then
    for _, e in ipairs(queue) do
      if e.status ~= "pending" then
        wipe(queue)
        wipe(seen)
        break
      end
    end
  end

  local sortKey = info.sortKey
  if sortKey and seen[sortKey] then
    Msg("Already in the post queue: |cFFF59E0B" .. (info.itemName or "?") .. "|r")
    return
  end
  if sortKey then seen[sortKey] = true end
  local entry = {
    key = viewItem.key,
    sortKey = sortKey,
    link = info.itemLink,
    name = info.itemName,
    icon = info.iconTexture,
    count = info.itemCount or 1,
    status = "pending",
  }
  queue[#queue + 1] = entry

  if AkcHouse.Utilities and AkcHouse.Utilities.DBKeyFromLink and AkcHouse.Database and info.itemLink then
    pcall(AkcHouse.Utilities.DBKeyFromLink, info.itemLink, function(dbKeys)
      local price = dbKeys and dbKeys[1] and AkcHouse.Database:GetPrice(dbKeys[1])
      if price then
        entry.estUnit = price
        if UpdateWindow then UpdateWindow() end
      end
    end)
  end

  if _G.AkcHouseBuyAllDialog and _G.AkcHouseBuyAllDialog:IsShown() then
    _G.AkcHouseBuyAllDialog:Hide()
  end
  PositionWindow()
  win:Show()
  UpdateWindow()
end

local function ClearQueue()
  if session.active then EndSession(true) end
  wipe(queue)
  wipe(seen)
  if UpdateWindow then UpdateWindow() end
end

local function StartSession()
  if session.active or #queue == 0 then return end
  for _, e in ipairs(queue) do e.status = "pending" end
  session.active = true
  session.pendingAdvance = false
  session.runId = session.runId + 1
  session.index = 1
  LoadIndex(1)
  if UpdateWindow then UpdateWindow() end
end

local MARK = {
  pending = "|cFF9AA0A6-|r ",
  ok      = "|cFF59D97B[ok]|r ",
  fail    = "|cFFF25850[x]|r ",
  current = "|cFFFFD100>|r ",
}

function EnsureWindow()
  if win then return win end

  win = CreateFrame("Frame", "AkcHousePostQueueFrame", UIParent, "BackdropTemplate")
  win:SetSize(300, 260)
  win:SetFrameStrata("HIGH")
  win:SetClampedToScreen(true)
  win:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 8, right = 8, top = 8, bottom = 8 },
  })
  win:EnableMouse(true)
  win:SetMovable(true)
  win:RegisterForDrag("LeftButton")
  win:SetScript("OnDragStart", win.StartMoving)
  win:SetScript("OnDragStop", win.StopMovingOrSizing)
  win:Hide()

  win.Title = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  win.Title:SetPoint("TOP", 0, -14)
  win.Title:SetText("|cffffd100Post Queue|r")

  win.Hint = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  win.Hint:SetPoint("TOP", win.Title, "BOTTOM", 0, -2)
  win.Hint:SetTextColor(0.65, 0.65, 0.70, 1)

  win.Body = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  win.Body:SetPoint("TOPLEFT", 18, -50)
  win.Body:SetPoint("RIGHT", -18, 0)
  win.Body:SetJustifyH("LEFT")
  win.Body:SetJustifyV("TOP")
  win.Body:SetSpacing(3)

  win.Total = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  win.Total:SetPoint("BOTTOM", 0, 46)

  win.PostAll = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
  win.PostAll:SetSize(130, 24)
  win.PostAll:SetPoint("BOTTOMRIGHT", win, "BOTTOM", -4, 14)
  win.PostAll:SetText("Post All")
  win.PostAll:SetScript("OnClick", function()
    if session.active then
      local nb = _G.AkcHousePostButton
      if nb and nb:IsEnabled() then nb:Click() end
    else
      StartSession()
    end
  end)

  win.elapsed = 0
  win:SetScript("OnUpdate", function(self, dt)
    if not session.active then return end
    self.elapsed = self.elapsed + dt
    if self.elapsed >= 0.25 then
      self.elapsed = 0
      UpdateWindow()
    end
  end)

  win.Clear = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
  win.Clear:SetSize(130, 24)
  win.Clear:SetPoint("BOTTOMLEFT", win, "BOTTOM", 4, 14)
  win.Clear:SetText("Clear")
  win.Clear:SetScript("OnClick", ClearQueue)

  win.Close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
  win.Close:SetPoint("TOPRIGHT", 2, 2)

  win:SetScript("OnHide", function()
    if session.active then EndSession(true) end
    if win.akcKeepQueue then
      win.akcKeepQueue = nil
      return
    end
    wipe(queue)
    wipe(seen)
  end)

  return win
end

function UpdateWindow()
  if not win or not win:IsShown() then return end

  local rows = {}
  local postedSum, estSum = 0, 0
  for i, entry in ipairs(queue) do
    local isCurrent = session.active and i == session.index and entry.status == "pending"
    local mark = isCurrent and MARK.current or (MARK[entry.status] or MARK.pending)

    local color
    if entry.status == "ok" then color = "|cFF59D97B"
    elseif entry.status == "fail" then color = "|cFF9AA0A6"
    elseif isCurrent then color = "|cFFFFD100"
    else color = "|cFFE5E7EB" end

    local qty = (entry.count and entry.count > 1) and (entry.count .. "x ") or ""
    local text = mark .. color .. qty .. QueueName(entry) .. "|r"

    if entry.status == "ok" and entry.postedTotal and entry.postedTotal > 0 then
      postedSum = postedSum + entry.postedTotal
      text = text .. "  |cFFE5E7EB—|r  " .. GetMoneyString(entry.postedTotal, true)
    elseif entry.status ~= "fail" and entry.estUnit then
      local est = entry.estUnit * (entry.count or 1)
      estSum = estSum + est
      text = text .. "  |cFF9AA0A6—  ~" .. GetMoneyString(est, true) .. "|r"
    end
    rows[#rows + 1] = text
  end
  if #rows == 0 then
    win.Body:SetText("|cFF808080Queue is empty.|r")
  else
    win.Body:SetText(table.concat(rows, "\n"))
  end
  win:SetHeight(140 + math.max(1, #rows) * 15)

  local totalBits = {}
  if postedSum > 0 then
    totalBits[#totalBits + 1] = "Posted: " .. GetMoneyString(postedSum, true)
  end
  if estSum > 0 then
    totalBits[#totalBits + 1] = "|cFF9AA0A6Est: ~" .. GetMoneyString(estSum, true) .. "|r"
  end
  win.Total:SetText(table.concat(totalBits, "   /   "))

  if session.active then
    local nb = _G.AkcHousePostButton
    local ready = nb and nb:IsEnabled()
    win.PostAll:SetText(("Post %d/%d"):format(session.index, #queue))
    if ready then
      win.PostAll:Enable()
      win.Hint:SetText("|cFFFFD100Keep clicking Post — one click posts one item.|r")
    else
      win.PostAll:Disable()
      win.Hint:SetText("|cFF9AA0A6Loading price...|r")
    end
    win.Clear:SetText("Stop")
    win.Clear:SetScript("OnClick", function() EndSession() end)
  else
    win.Hint:SetText("Right-click bag items to add them here.")
    win.PostAll:SetText("Post All (" .. #queue .. ")")
    if #queue > 0 then win.PostAll:Enable() else win.PostAll:Disable() end
    win.Clear:SetText("Clear")
    win.Clear:SetScript("OnClick", ClearQueue)
  end
end

function PositionWindow()
  local w = EnsureWindow()
  w:ClearAllPoints()
  if AuctionHouseFrame and AuctionHouseFrame:IsShown() then
    w:SetPoint("TOPLEFT", AuctionHouseFrame, "TOPRIGHT", 4, 0)
  else
    w:SetPoint("CENTER")
  end
end

local function Setup()
  if setupDone then return end
  local E = Events()
  if not (AkcHouse and AkcHouse.EventBus and E and AkcHouseBagUseMixin and AkcHouseSaleItemMixin) then
    return false
  end
  setupDone = true

  AkcHouse.EventBus:RegisterSource(bridge, "AkcQOLPostQueue")
  AkcHouse.EventBus:Register(bridge, { E.AuctionCreated })

  hooksecurefunc(AkcHouseSaleItemMixin, "PostItem", function()
    if not session.active or not session.pendingAdvance then return end
    session.pendingAdvance = false
    session.index = session.index + 1
    if queue[session.index] then LoadIndex(session.index) else EndSession() end
    if UpdateWindow then UpdateWindow() end
  end)

  hooksecurefunc(AkcHouseSaleItemMixin, "OnShow", function()
    if #queue > 0 then PositionWindow(); win:Show(); UpdateWindow() end
  end)

  origBagClick = AkcHouseBagUseMixin.BagItemClicked
  AkcHouseBagUseMixin.BagItemClicked = function(self, viewItem, mouseButton)
    if mouseButton == "RightButton" and not IsShiftKeyDown() and viewItem and viewItem.itemInfo then
      AddToQueue(viewItem)
      return
    end
    return origBagClick(self, viewItem, mouseButton)
  end

  if AkcHouseGroupsViewItemMixin then
    local origViewClick = AkcHouseGroupsViewItemMixin.OnClick
    AkcHouseGroupsViewItemMixin.OnClick = function(self, button)
      if button == "RightButton" and not IsShiftKeyDown()
          and self.itemInfo and self.clickEventName == "BagUse.BagItemClicked"
          and not IsModifiedClick("DRESSUP") and not IsModifiedClick("CHATLINK") then
        AddToQueue(self)
        return
      end
      return origViewClick(self, button)
    end
  end

  return true
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:RegisterEvent("PLAYER_ENTERING_WORLD")
boot:RegisterEvent("AUCTION_HOUSE_SHOW")
boot:RegisterEvent("AUCTION_HOUSE_CLOSED")
boot:SetScript("OnEvent", function(_, event)
  if event == "AUCTION_HOUSE_CLOSED" then
    if session.active then EndSession(true) end
    if win then win:Hide() end
    return
  end
  Setup()
end)

pcall(Setup)
