local _, addon = ...

local L = AkcQOL_L

local BAR_DEFS
local function RebuildBarDefs()
    BAR_DEFS = {
    { key = "main", name = L["Main Bar"], frameNames = { "MainMenuBar", "MainMenuBarArtFrame" }, buttonPrefix = "ActionButton", buttonCount = 12 },
    { key = "bottomLeft", name = L["Action Bar 2"], frameNames = { "MultiBarBottomLeft" }, buttonPrefix = "MultiBarBottomLeftButton", buttonCount = 12 },
    { key = "bottomRight", name = L["Action Bar 3"], frameNames = { "MultiBarBottomRight" }, buttonPrefix = "MultiBarBottomRightButton", buttonCount = 12 },
    { key = "right", name = L["Action Bar 4"], frameNames = { "MultiBarRight" }, buttonPrefix = "MultiBarRightButton", buttonCount = 12 },
    { key = "left", name = L["Action Bar 5"], frameNames = { "MultiBarLeft" }, buttonPrefix = "MultiBarLeftButton", buttonCount = 12 },
    { key = "bar5", name = L["Action Bar 6"], frameNames = { "MultiBar5" }, buttonPrefix = "MultiBar5Button", buttonCount = 12 },
    { key = "bar6", name = L["Action Bar 7"], frameNames = { "MultiBar6" }, buttonPrefix = "MultiBar6Button", buttonCount = 12 },
    { key = "bar7", name = L["Action Bar 8"], frameNames = { "MultiBar7" }, buttonPrefix = "MultiBar7Button", buttonCount = 12 },
    { key = "pet", name = L["Pet Bar"], frameNames = { "PetActionBar" }, buttonPrefix = "PetActionButton", buttonCount = 10 },
    { key = "stance", name = L["Stance Bar"], frameNames = { "StanceBar" }, buttonPrefix = "StanceButton", buttonCount = 10 },
    }
end
RebuildBarDefs()
if AkcQOL_RegisterLocaleRebuild then AkcQOL_RegisterLocaleRebuild(RebuildBarDefs) end

local controller = CreateFrame("Frame", "AkcQOLActionBarMouseoverController")
local initialized = false
local updatesRunning = false
local updateElapsed = 0
local touchedFrames = {}
local activeFrames = {}
local visibleUntil = {}
local targetCache = {}

local function ClampAlpha(value, fallback)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value == nil then value = 1 end
    if value < 0 then return 0 end
    if value > 1 then return 1 end
    return value
end

local function ClampNumber(value, fallback, minValue, maxValue)
    value = tonumber(value)
    if value == nil then value = fallback end
    if value < minValue then return minValue end
    if value > maxValue then return maxValue end
    return value
end

local function EnsureDB()
    local profile = addon.AkcQOL and addon.AkcQOL.db and addon.AkcQOL.db.profile
    if not profile then return nil end

    profile.actionBarMouseover = profile.actionBarMouseover or {}
    local db = profile.actionBarMouseover

    if db.enabled == nil then db.enabled = false end
    db.minAlpha = ClampAlpha(db.minAlpha, 0)
    db.maxAlpha = ClampAlpha(db.maxAlpha, 1)
    if db.maxAlpha < db.minAlpha then
        db.maxAlpha = db.minAlpha
    end
    db.hoverDelay = ClampNumber(db.hoverDelay, 0.7, 0, 2)
    if db.alwaysShowInCombat == nil then db.alwaysShowInCombat = false end
    if db.alwaysShowInEditMode == nil then db.alwaysShowInEditMode = false end
    db.bars = db.bars or {}

    for _, def in ipairs(BAR_DEFS) do
        if db.bars[def.key] == nil then
            db.bars[def.key] = false
        end
    end

    return db
end

local function AddFrame(targets, seen, frame)
    if frame and frame.SetAlpha and not seen[frame] then
        seen[frame] = true
        targets[#targets + 1] = frame
    end
end

-- The cache is invalidated wholesale by the controller's events (login, spec
-- change, bar page change), which is the correct trigger. Do NOT require a
-- full expected count here: some listed frames (e.g. MainMenuBarArtFrame) no
-- longer exist on 12.x, so a count-based guard would never validate and the
-- scan would re-run on every 0.1s tick.
local function GetBarTargets(def)
    local cached = targetCache[def.key]
    if cached and #cached > 0 then return cached end

    local targets = {}
    local seen = {}

    for _, frameName in ipairs(def.frameNames or {}) do
        AddFrame(targets, seen, _G[frameName])
    end

    if def.buttonPrefix and def.buttonCount then
        for i = 1, def.buttonCount do
            AddFrame(targets, seen, _G[def.buttonPrefix .. i])
        end
    end

    targetCache[def.key] = targets
    return targets
end

local function SetFrameAlpha(frame, alpha)
    if not frame or not frame.SetAlpha then return end

    alpha = ClampAlpha(alpha, 1)

    if frame.GetAlpha then
        local ok, current = pcall(frame.GetAlpha, frame)
        if ok and current and math.abs(current - alpha) < 0.005 then return end
    end

    pcall(frame.SetAlpha, frame, alpha)
end

-- The old FrameXML global MouseIsOver() is no longer dependable on 12.x, so
-- hover was never detected and faded bars could not come back. The widget
-- method frame:IsMouseOver() is the modern equivalent; MouseIsOver stays as a
-- fallback for older clients.
local function FrameHasMouse(frame)
    if not frame then return false end
    if frame.IsMouseOver then
        local ok, result = pcall(frame.IsMouseOver, frame)
        if ok then return result and true or false end
    end
    if MouseIsOver then
        local ok, result = pcall(MouseIsOver, frame)
        if ok then return result and true or false end
    end
    return false
end

local function IsMouseOverAnyTarget(targets)
    for _, frame in ipairs(targets) do
        if FrameHasMouse(frame) then
            return true
        end
    end
    return false
end

-- A flyout the player is picking from keeps the bars up. Only a flyout that is
-- actually open counts: this runs ten times a second, and the old version also
-- probed the closed flyout and all 30 of its buttons on every tick -- work that
-- could only ever answer for a flyout that was no longer open.
local function IsSpellFlyoutActive()
    local flyout = _G.SpellFlyout
    if not (flyout and flyout.IsShown) then return false end
    local ok, shown = pcall(flyout.IsShown, flyout)
    return ok and shown == true
end

local function IsEditModeActive()
    local frame = _G.EditModeManagerFrame
    if frame and frame.IsShown then
        local ok, shown = pcall(frame.IsShown, frame)
        if ok and shown then return true end
    end

    if frame and frame.IsEditModeActive then
        local ok, active = pcall(frame.IsEditModeActive, frame)
        if ok and active then return true end
    end

    return false
end

local function ShouldForceVisible(db)
    if db.alwaysShowInCombat then
        local inCombat = false
        if InCombatLockdown then
            inCombat = InCombatLockdown()
        end
        if not inCombat and UnitAffectingCombat then
            inCombat = UnitAffectingCombat("player")
        end
        if inCombat then return true end
    end

    if db.alwaysShowInEditMode and IsEditModeActive() then
        return true
    end

    return false
end

local function HasSelectedBars(db)
    if not db or not db.bars then return false end
    for _, def in ipairs(BAR_DEFS) do
        if db.bars[def.key] then
            return true
        end
    end
    return false
end

local function StopUpdates()
    controller:SetScript("OnUpdate", nil)
    updatesRunning = false
    updateElapsed = 0
end

local function StartUpdates()
    if updatesRunning then return end
    updatesRunning = true
    controller:SetScript("OnUpdate", function(_, elapsed)
        updateElapsed = updateElapsed + (elapsed or 0)
        if updateElapsed < 0.1 then return end
        updateElapsed = 0
        addon:RefreshActionBarMouseover(true)
    end)
end

local function ResetTouchedFrames()
    for frame in pairs(touchedFrames) do
        SetFrameAlpha(frame, 1)
    end
    for key in pairs(visibleUntil) do
        visibleUntil[key] = nil
    end
end

local function GetDB()
    local profile = addon.AkcQOL and addon.AkcQOL.db and addon.AkcQOL.db.profile
    return profile and profile.actionBarMouseover
end

function _G.AkcQOL_IsActionBarMouseoverEnabled()
    local db = GetDB()
    return db ~= nil and db.enabled == true
end

function _G.AkcQOL_ToggleActionBarMouseover()
    local db = EnsureDB()
    if not db then return false end
    db.enabled = not db.enabled
    addon:RefreshActionBarMouseover()
    if LibStub then
        local reg = LibStub("AceConfigRegistry-3.0", true)
        if reg then reg:NotifyChange("AkcQOLRaidCD") end
    end
    return db.enabled
end

function addon:RefreshActionBarMouseover(fromPoll)
    local db = fromPoll and GetDB() or EnsureDB()
    if not db or not db.enabled then
        ResetTouchedFrames()
        StopUpdates()
        return
    end

    if not HasSelectedBars(db) then
        ResetTouchedFrames()
        StopUpdates()
        return
    end

    wipe(activeFrames)
    local forceVisible = ShouldForceVisible(db)
    local now = GetTime and GetTime() or 0
    local flyoutActive = IsSpellFlyoutActive()

    for _, def in ipairs(BAR_DEFS) do
        local targets = GetBarTargets(def)
        if #targets > 0 then
            if db.bars[def.key] then
                local alpha = db.minAlpha
                local mouseOverBar = IsMouseOverAnyTarget(targets)
                if mouseOverBar or flyoutActive then
                    visibleUntil[def.key] = now + db.hoverDelay
                end

                if forceVisible or mouseOverBar or flyoutActive or ((visibleUntil[def.key] or 0) > now) then
                    alpha = db.maxAlpha
                end

                for _, frame in ipairs(targets) do
                    touchedFrames[frame] = true
                    activeFrames[frame] = true
                    SetFrameAlpha(frame, alpha)
                end
            else
                for _, frame in ipairs(targets) do
                    if touchedFrames[frame] then
                        SetFrameAlpha(frame, 1)
                    end
                end
            end
        end
    end

    for frame in pairs(touchedFrames) do
        if not activeFrames[frame] then
            SetFrameAlpha(frame, 1)
        end
    end

    StartUpdates()
end

function addon:DisableActionBarMouseover()
    StopUpdates()
    ResetTouchedFrames()
end

function addon:InitializeActionBarMouseover()
    EnsureDB()

    if initialized then
        self:RefreshActionBarMouseover()
        return
    end

    initialized = true
    controller:SetScript("OnEvent", function()
        wipe(targetCache)
        if C_Timer and C_Timer.After then
            C_Timer.After(0.1, function()
                addon:RefreshActionBarMouseover()
            end)
        else
            addon:RefreshActionBarMouseover()
        end
    end)

    controller:RegisterEvent("PLAYER_LOGIN")
    controller:RegisterEvent("PLAYER_ENTERING_WORLD")
    controller:RegisterEvent("PLAYER_REGEN_DISABLED")
    controller:RegisterEvent("PLAYER_REGEN_ENABLED")
    controller:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
    controller:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
    controller:RegisterEvent("UPDATE_OVERRIDE_ACTIONBAR")
    controller:RegisterEvent("PET_BAR_UPDATE")

    self:RefreshActionBarMouseover()
end

-- The initializer wires the controller's events (bar creation, spec change,
-- Edit Mode). It was never called, so the target list was only ever built on
-- the first poll and never refreshed.
do
    local boot = CreateFrame("Frame")
    boot:RegisterEvent("PLAYER_LOGIN")
    boot:SetScript("OnEvent", function(self)
        self:UnregisterAllEvents()
        if addon.InitializeActionBarMouseover then
            pcall(addon.InitializeActionBarMouseover, addon)
        end
    end)
end
