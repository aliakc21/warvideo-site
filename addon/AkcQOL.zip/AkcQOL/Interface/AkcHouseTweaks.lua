
local ALWAYS_HIDDEN = {
  ["Cancelling"] = true,
  ["AkcHouse"] = true,
}

local OPTIONAL_TABS = {
  ["Shopping"] = "akcHouseHideShopping",
  ["Selling"] = "akcHouseHideSelling",
}

local originalTabs

local function RemoveHiddenTabs()
  if not (AkcHouse and AkcHouse.Tabs and AkcHouse.Tabs.State) then
    return
  end

  local known = AkcHouse.Tabs.State.knownTabs
  if type(known) ~= "table" then
    return
  end

  if not originalTabs then
    originalTabs = {}
    for i = 1, #known do originalTabs[i] = known[i] end
  end

  local g = AkcQOLDB and AkcQOLDB.global

  wipe(known)
  for _, details in ipairs(originalTabs) do
    local hide = details and ALWAYS_HIDDEN[details.name] or false
    if not hide and details and g then
      local key = OPTIONAL_TABS[details.name]
      if key and g[key] then hide = true end
    end
    if not hide then
      known[#known + 1] = details
    end
  end
end

_G.AkcQOL_ApplyAkcHouseTabs = RemoveHiddenTabs

RemoveHiddenTabs()

local tabInit = CreateFrame("Frame")
tabInit:RegisterEvent("PLAYER_LOGIN")
tabInit:SetScript("OnEvent", function(self)
  self:UnregisterAllEvents()
  RemoveHiddenTabs()
end)

if AkcHouseShoppingTabContainerTabsMixin then
  local origSetView = AkcHouseShoppingTabContainerTabsMixin.SetView
  AkcHouseShoppingTabContainerTabsMixin.SetView = function(self, viewIndex)
    local views = AkcHouse and AkcHouse.Constants and AkcHouse.Constants.ShoppingListViews
    if views and viewIndex == views.Recents then
      viewIndex = views.Lists
    end
    origSetView(self, viewIndex)
    if self.RecentsTab then self.RecentsTab:Hide() end
  end
  hooksecurefunc(AkcHouseShoppingTabContainerTabsMixin, "OnLoad", function(self)
    if self.RecentsTab then self.RecentsTab:Hide() end
    self.Tabs = { self.ListsTab }
    self.numTabs = 1
  end)
end

