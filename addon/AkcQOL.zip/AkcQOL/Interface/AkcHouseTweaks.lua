
local L = AkcQOL_L

local ALWAYS_HIDDEN = {
  ["Cancelling"] = true,
  ["AkcHouse"] = true,
}

local OPTIONAL_TABS = {
  ["Shopping"] = "akcHouseHideShopping",
  ["Selling"] = "akcHouseHideSelling",
}

local originalTabs

local RELOAD_POPUP = "AKCQOL_AKCHOUSE_TABS_RELOAD"

StaticPopupDialogs[RELOAD_POPUP] = {
  text = "",
  button1 = RELOADUI or L["Reload"],
  button2 = CANCEL or "Cancel",
  OnAccept = function() ReloadUI() end,
  timeout = 0,
  whileDead = true,
  hideOnEscape = true,
  preferredIndex = 3,
}

-- AkcHouse builds its tab buttons once, on the first auction house visit of
-- the session (AkcHouseTabContainerMixin:OnLoad), and never reads knownTabs
-- again: closing and reopening the auction house does not rebuild them. A
-- toggle changed after that visit only lands after a UI reload, so offer one
-- instead of letting the click look ignored. Toggling back to what is
-- already built withdraws the offer.
local function OfferReloadIfBuilt(kept)
  if not _G.AkcHouseAHTabsContainer then return end
  if not (StaticPopupDialogs and StaticPopup_Show) then return end
  local differs = false
  for name in pairs(OPTIONAL_TABS) do
    local built = _G["AkcHouseTabs_" .. name] ~= nil
    if built ~= (kept[name] == true) then differs = true end
  end
  if not differs then
    if StaticPopup_Hide then StaticPopup_Hide(RELOAD_POPUP) end
    return
  end
  -- Set at show time so an in-addon language switch is picked up.
  local dialog = StaticPopupDialogs[RELOAD_POPUP]
  dialog.text = L["The auction house tabs are built once per session, so this change shows up after a UI reload. Reload now?"]
  dialog.button1 = RELOADUI or L["Reload"]
  StaticPopup_Show(RELOAD_POPUP)
end

local function RemoveHiddenTabs()
  if not (AkcHouse and AkcHouse.Tabs and AkcHouse.Tabs.State) then
    return
  end

  local known = AkcHouse.Tabs.State.knownTabs
  if type(known) ~= "table" then
    return
  end

  if not originalTabs then
    originalTabs = {}
    for i = 1, #known do originalTabs[i] = known[i] end
  end

  local g = AkcQOLDB and AkcQOLDB.global

  local kept = {}
  wipe(known)
  for _, details in ipairs(originalTabs) do
    local hide = details and ALWAYS_HIDDEN[details.name] or false
    if not hide and details and g then
      local key = OPTIONAL_TABS[details.name]
      if key and g[key] then hide = true end
    end
    if not hide then
      known[#known + 1] = details
      if details and details.name then kept[details.name] = true end
    end
  end

  OfferReloadIfBuilt(kept)
end

_G.AkcQOL_ApplyAkcHouseTabs = RemoveHiddenTabs

RemoveHiddenTabs()

local tabInit = CreateFrame("Frame")
tabInit:RegisterEvent("PLAYER_LOGIN")
tabInit:SetScript("OnEvent", function(self)
  self:UnregisterAllEvents()
  RemoveHiddenTabs()
end)

-- AkcHouse's Default Tab setting is a fixed number (1 Shopping, 2 Selling,
-- 3 Cancelling, 4 AkcHouse -- the tabs' own tabOrder) that ShowDefaultTab
-- uses to index the container's Tabs list. With hidden tabs left out that
-- list is compacted, so with Shopping hidden "Selling" opened nothing and
-- "Shopping" opened Selling. Re-key the list by tabOrder; a hidden default
-- tab then opens nothing and every other choice keeps its meaning.
if AkcHouseTabContainerMixin then
  hooksecurefunc(AkcHouseTabContainerMixin, "OnLoad", function(self)
    local state = AkcHouse and AkcHouse.Tabs and AkcHouse.Tabs.State
    local known = state and state.knownTabs
    if type(known) ~= "table" then return end
    local byOrder = {}
    for _, details in ipairs(known) do
      local button = details and details.name and _G["AkcHouseTabs_" .. details.name]
      if button and type(details.tabOrder) == "number" then
        byOrder[details.tabOrder] = button
      end
    end
    self.Tabs = byOrder
  end)
end

if AkcHouseShoppingTabContainerTabsMixin then
  local origSetView = AkcHouseShoppingTabContainerTabsMixin.SetView
  AkcHouseShoppingTabContainerTabsMixin.SetView = function(self, viewIndex)
    local views = AkcHouse and AkcHouse.Constants and AkcHouse.Constants.ShoppingListViews
    if views and viewIndex == views.Recents then
      viewIndex = views.Lists
    end
    origSetView(self, viewIndex)
    if self.RecentsTab then self.RecentsTab:Hide() end
  end
  hooksecurefunc(AkcHouseShoppingTabContainerTabsMixin, "OnLoad", function(self)
    if self.RecentsTab then self.RecentsTab:Hide() end
    self.Tabs = { self.ListsTab }
    self.numTabs = 1
  end)
end

