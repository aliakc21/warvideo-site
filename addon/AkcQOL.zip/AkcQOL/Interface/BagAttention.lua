-- BagAttention: glows bag items that are waiting for an action — openable
-- containers, locked lockboxes, weekly-limited use items (treatises, knowledge
-- drops), unlearned collectibles, quest starters, usable housing decor and
-- one-shot "use me" items (curios, bounty maps, combinable fragments, tokens)
-- — plus a counter badge on the backpack icon so closed bags still get noticed.

local BAG_FIRST, BAG_LAST = 0, 5
local SCAN_DELAY, QUEST_SCAN_DELAY = 0.25, 2.0

local CAT_COLORS = {
    openable    = { 1.00, 0.62, 0.10 },
    lockbox     = { 0.25, 0.55, 0.95 },
    weekly      = { 0.55, 0.36, 1.00 },
    collectible = { 0.20, 0.85, 0.40 },
    quest       = { 1.00, 0.92, 0.30 },
    decor       = { 1.00, 0.45, 0.25 },
    usable      = { 0.20, 0.85, 0.90 },
}

-- Tooltip lines that drive the tooltip-based categories. Blizzard global
-- strings, so they match in every client language. Housing decor is asked
-- from the API (C_Item.IsDecorItem, 12.1); the text is only a fallback.
local DECOR_TYPE_TEXT = _G.HOUSING_DECOR_ITEM_TYPE or "Housing Decor"
local USE_PREFIX = _G.ITEM_SPELL_TRIGGER_ONUSE or "Use:"
local KNOWN_TEXT = _G.ITEM_SPELL_KNOWN or "Already known"
local CURIO_DUP_TEXT = _G.SPELL_FAILED_CUSTOM_ERROR_1042 or "You already have this curio in your collection."

-- "N Charges" lines mark multi-use gadgets (holiday wands, toys-to-be), never
-- one-shot "use me" items. Built from the game's own format strings.
local function CountPattern(fmt)
    fmt = fmt:gsub("([%^%$%(%)%.%[%]%*%+%-%?])", "%%%1")
    return "^" .. fmt:gsub("%%%%d", "%%d+") .. "$"
end
local CHARGES_PATTERNS = {
    CountPattern(_G.ITEM_SPELL_CHARGES or "%d Charges"),
    CountPattern(_G.ITEM_SPELL_CHARGES_P1 or "%d Charge"),
}

-- Item classes/subclasses considered for the "usable" category (from
-- Enum.ItemClass / Enum.ItemConsumableSubclass / Enum.ItemMiscellaneousSubclass).
local CLASS_CONSUMABLE, CLASS_MISC, CLASS_HOUSING = 0, 15, 20
local SUB_CONSUMABLE_OTHER, SUB_UTILITY_CURIO, SUB_COMBAT_CURIO = 8, 10, 11
local SUB_MISC_OTHER = 4
local SUB_HOUSING_DECOR = 0 -- 1 = Housing Dye, 2 = Room, 3/4 = Customization, 5 = Service

-- Only current-expansion items qualify as "use me" — leftovers from earlier
-- expansions are not something the player forgot this week.
local CURRENT_EXPANSION = _G.LE_EXPANSION_LEVEL_CURRENT
    or (Enum and Enum.ExpansionLevel and Enum.ExpansionLevel.Midnight)
    or (GetClientDisplayExpansionLevel and GetClientDisplayExpansionLevel())
    or (GetServerExpansionLevel and GetServerExpansionLevel())
    or (GetExpansionLevel and GetExpansionLevel())

-- Reusable gadgets that carry a "Use:" line but are never consumed (they
-- would glow forever). Verified against 12.1 item data.
local USABLE_IGNORE = {
    [276297] = true, -- Rustbolt Jetpack (neighborhood flight)
    [268826] = true, -- Ballast Stone (walk under water)
    [272128] = true, -- Soggy Lynx Toy
    [238494] = true, -- Another's Treasure (show it off)
    [252609] = true, -- Coffer Key Shard item form (count enforced server-side)
}

-- Fallback reagent counts for combine-type items, used only when the recipe
-- schematic of the item's use spell cannot be read.
local COMBINE_COUNTS = {
    [279382] = 2, -- Venom-Cursed Fragment -> Champion Venom-Cursed item
}

-- Treatise-type items -> hidden tracking quest flags that complete ON USE
-- (source: WeeklyKnowledge data files). These glow only while this week's
-- use is still available. IMPORTANT: only flag-on-use items belong here —
-- treasure/gathering knowledge drops flag ON LOOT and go below instead.
local WEEKLY_ITEM_QUESTS = {
    [245755] = { 95127 }, [245763] = { 95128 }, [245759] = { 95129 },
    [245809] = { 95138 }, [245761] = { 95130 }, [245757] = { 95131 },
    [245760] = { 95133 }, [245758] = { 95134 }, [245762] = { 95135 },
    [245828] = { 95136 }, [245756] = { 95137 },
}

-- Always actionable while owned (presence in bag = glow): knowledge drops
-- whose weekly flag gates the DROP (already flagged once looted), uncapped
-- catch-up items, and use-it-or-lose-it weeklies like Saltheril's Favor.
local ALWAYS_USE_ITEMS = {
    -- knowledge treasure drops
    [259188] = true, [259189] = true, [259190] = true, [259191] = true,
    [259192] = true, [259193] = true, [259194] = true, [259195] = true,
    [259196] = true, [259197] = true, [259198] = true, [259199] = true,
    [259200] = true, [259201] = true, [259202] = true, [259203] = true,
    -- gathering knowledge items
    [267654] = true, [267655] = true, [238465] = true, [238466] = true,
    [237496] = true, [237506] = true, [238625] = true, [238626] = true,
    -- profession catch-up knowledge (uncapped)
    [246320] = true, [246322] = true, [267653] = true, [246326] = true,
    [238467] = true, [246328] = true, [246330] = true, [246332] = true,
    [237507] = true, [238627] = true, [246334] = true,
    [238987] = true, -- Saltheril's Favor (expires at weekly reset)
}

local results = {}        -- ["bag:slot"] = category
local actionCount = 0     -- distinct itemIDs waiting
local tooltipCache = {}   -- [itemID] = { openable = bool, locked = bool }
local collectibleCache = {} -- [itemID] = bool (true = unlearned collectible)
local scanQueued, questScanQueued, scanDeferred = false, false, false
local badgeFrame
local eventFrame

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.bagAttention) ~= "table" then g.bagAttention = {} end
    local d = g.bagAttention
    if d.enabled == nil then d.enabled = false end
    if d.catOpenable == nil then d.catOpenable = true end
    if d.catLockbox == nil then d.catLockbox = true end
    if d.catWeekly == nil then d.catWeekly = true end
    if d.catCollectible == nil then d.catCollectible = true end
    if d.catQuest == nil then d.catQuest = true end
    if d.catDecor == nil then d.catDecor = true end
    if d.catUsable == nil then d.catUsable = true end
    if d.badge == nil then d.badge = true end
    if d.pulse == nil then d.pulse = true end
    return d
end

local function IsSecret(v)
    if issecretvalue and issecretvalue(v) then return true end
    if canaccessvalue and not canaccessvalue(v) then return true end
    return false
end

local function QuestDone(questID)
    local done = false
    pcall(function() done = C_QuestLog.IsQuestFlaggedCompleted(questID) == true end)
    return done
end

-- Weekly: usable this week iff any mapped flag is still uncompleted.
local function WeeklyUsesLeft(itemID)
    if ALWAYS_USE_ITEMS[itemID] then return 1 end
    local quests = WEEKLY_ITEM_QUESTS[itemID]
    if not quests then return 0 end
    local left = 0
    for _, q in ipairs(quests) do
        if not QuestDone(q) then left = left + 1 end
    end
    return left
end

local function IsUncollectedCollectible(itemID)
    local cached = collectibleCache[itemID]
    if cached ~= nil then return cached end
    local unlearned = false
    if C_MountJournal and C_MountJournal.GetMountFromItem then
        local ok, mountID = pcall(C_MountJournal.GetMountFromItem, itemID)
        if ok and mountID then
            local ok2, collected = pcall(function()
                return select(11, C_MountJournal.GetMountInfoByID(mountID))
            end)
            unlearned = ok2 and collected == false
        end
    end
    if not unlearned and C_PetJournal and C_PetJournal.GetPetInfoByItemID then
        local ok, name, speciesID = pcall(function()
            local n = C_PetJournal.GetPetInfoByItemID(itemID)
            local s = select(13, C_PetJournal.GetPetInfoByItemID(itemID))
            return n, s
        end)
        if ok and name and type(speciesID) == "number" and C_PetJournal.GetNumCollectedInfo then
            local ok2, num = pcall(C_PetJournal.GetNumCollectedInfo, speciesID)
            unlearned = ok2 and num == 0
        end
    end
    if not unlearned and C_ToyBox and C_ToyBox.GetToyInfo and PlayerHasToy then
        local ok, toyItemID = pcall(C_ToyBox.GetToyInfo, itemID)
        if ok and toyItemID then
            local ok2, has = pcall(PlayerHasToy, itemID)
            unlearned = ok2 and has == false
        end
    end
    collectibleCache[itemID] = unlearned
    return unlearned
end

-- Red tooltip text = the game refusing the item right now ("Already known",
-- "You already have this curio in your collection.", unmet requirements).
local function IsRedLine(line)
    local c = line.leftColor
    if not c or IsSecret(c) or type(c) ~= "table" then return false end
    local r, g, b = c.r, c.g, c.b
    return type(r) == "number" and type(g) == "number" and type(b) == "number"
        and r >= 0.9 and g <= 0.25 and b <= 0.25
end

-- Tooltip facts: openable / locked / decor type / "Use:" line / blocked (red
-- line). Static facts are cached per item; locked boxes are re-read every pass
-- (the glow turns gold the moment a Rogue picks them) and "use me" candidates
-- ask for a fresh read so a curio that just became a duplicate stops glowing.
local function TooltipFacts(bag, slot, itemID, fresh)
    local cached = tooltipCache[itemID]
    if cached and not fresh then return cached end
    local facts = { openable = false, locked = false, usable = false, blocked = false,
                    decorType = false, curioDup = false, charges = false }
    local complete = false
    if C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
        if ok and data and data.lines then
            -- A tooltip with fewer than 2 lines means the item data hasn't
            -- streamed in yet; caching that would freeze "not openable"
            -- for the whole session.
            complete = #data.lines >= 2
            for i, line in ipairs(data.lines) do
                local lt = line.leftText
                if lt and not IsSecret(lt) and type(lt) == "string" then
                    if lt == ITEM_OPENABLE then facts.openable = true
                    elseif lt == LOCKED then facts.locked = true
                    elseif lt == KNOWN_TEXT then facts.blocked = true; facts.curioDup = true
                    elseif lt == CURIO_DUP_TEXT then facts.blocked = true; facts.curioDup = true
                    elseif lt == DECOR_TYPE_TEXT then facts.decorType = true
                    elseif lt:find(USE_PREFIX, 1, true) == 1 then facts.usable = true
                    elseif lt:find(CHARGES_PATTERNS[1]) or lt:find(CHARGES_PATTERNS[2]) then facts.charges = true end
                end
                if i > 1 and IsRedLine(line) then facts.blocked = true end
            end
        end
    end
    if complete and not facts.locked then tooltipCache[itemID] = facts end
    return facts
end

-- Housing decor = item class Housing (20) / subclass Decor (0). Dyes, rooms,
-- customizations and service items are other subclasses and never count.
-- C_Item.IsDecorItem and the tooltip type line are extra positive signals
-- only (the API may answer nil for a bag link).
local function IsDecor(itemID, link, classID, subclassID, facts)
    if classID == CLASS_HOUSING then return subclassID == SUB_HOUSING_DECOR end
    if C_Item and C_Item.IsDecorItem then
        local ok, r = pcall(C_Item.IsDecorItem, link or itemID)
        if ok and r == true then return true end
    end
    return facts.decorType == true
end

-- Strict: only items stamped with the current expansion. Holiday and other
-- "no expansion" items carry 253/254 here and must not glow; an uncached
-- item (nil) is allowed until the next rescan has its data.
local function IsCurrentExpansion(itemID)
    if not CURRENT_EXPANSION then return true end
    local ok, expansionID = pcall(function() return select(15, C_Item.GetItemInfo(itemID)) end)
    if ok and type(expansionID) == "number" then
        return expansionID == CURRENT_EXPANSION
    end
    return true
end

-- Brann's curios: Blizzard's own predicate first, item subclass as backup.
-- Their "Use:" text is drawn by the client, so it is not required here.
local function IsCurio(itemID, link, classID, subclassID)
    if C_Item and C_Item.IsCurioItem then
        local ok, r = pcall(C_Item.IsCurioItem, link or itemID)
        if ok and r == true then return true end
    end
    return classID == CLASS_CONSUMABLE
        and (subclassID == SUB_UTILITY_CURIO or subclassID == SUB_COMBAT_CURIO)
end

-- Combine-type items ("Combine two fragments...") cast a spell that needs N
-- reagents — read that recipe schematic and compare with what the bags hold,
-- so the glow only appears once the second fragment arrives.
local function ReagentsShort(itemID, link)
    local ok, spellID = pcall(function() return select(2, C_Item.GetItemSpell(link or itemID)) end)
    if ok and type(spellID) == "number" and C_TradeSkillUI and C_TradeSkillUI.GetRecipeSchematic then
        local ok2, s = pcall(C_TradeSkillUI.GetRecipeSchematic, spellID, false)
        if ok2 and type(s) == "table" and type(s.reagentSlotSchematics) == "table"
           and #s.reagentSlotSchematics > 0 then
            for _, rs in ipairs(s.reagentSlotSchematics) do
                local need = rs.quantityRequired
                if rs.required ~= false and type(need) == "number" and need > 0
                   and type(rs.reagents) == "table" then
                    -- A slot may accept several qualities of the same reagent;
                    -- any of them satisfies it.
                    local have, counted = 0, false
                    for _, reagent in ipairs(rs.reagents) do
                        if type(reagent.itemID) == "number" then
                            counted = true
                            have = have + (C_Item.GetItemCount(reagent.itemID) or 0)
                        end
                    end
                    if counted and have < need then return true end
                end
            end
            return false
        end
    end
    local need = COMBINE_COUNTS[itemID]
    return need and (C_Item.GetItemCount(itemID) or 0) < need or false
end

-- "Use me": bound one-shot items of the current expansion whose only job is
-- to be clicked — Brann's Curios, bounty maps, combinable fragments, tokens,
-- unlearned ensembles/illusions. Only these classes qualify:
--   Consumable / Utility Curio, Combat Curio, Other (bound only)
--   Miscellaneous / Other
local function IsUsableCandidate(classID, subclassID, info)
    if classID == CLASS_CONSUMABLE then
        return subclassID == SUB_CONSUMABLE_OTHER and info and info.isBound == true
    end
    return classID == CLASS_MISC and subclassID == SUB_MISC_OTHER
end

local function IsQuestStarter(bag, slot, itemID)
    local classID = select(6, C_Item.GetItemInfoInstant(itemID))
    if classID ~= 12 then return false end
    local ok, info = pcall(C_Container.GetContainerItemQuestInfo, bag, slot)
    if not ok or type(info) ~= "table" then return false end
    local qid = info.questID
    if not qid or IsSecret(qid) then return false end
    if info.isActive then return false end
    return not QuestDone(qid)
end

local function ClassifySlot(d, bag, slot, itemID, info)
    -- Weekly-list items and collectibles are owned by their own category: a
    -- spent treatise or a switched-off category must go dark, not fall
    -- through to the "use me" glow.
    if WEEKLY_ITEM_QUESTS[itemID] or ALWAYS_USE_ITEMS[itemID] then
        return (d.catWeekly and WeeklyUsesLeft(itemID) > 0) and "weekly" or nil
    end
    if d.catQuest and IsQuestStarter(bag, slot, itemID) then return "quest" end
    if IsUncollectedCollectible(itemID) then return d.catCollectible and "collectible" or nil end
    if d.catDecor or d.catLockbox or d.catOpenable or d.catUsable then
        -- Tooltip reads are limited to plausible candidates: hasLoot from the
        -- container info, the Miscellaneous class (lockboxes are Junk, tokens
        -- are Other), the Housing class, and — only when the category is on —
        -- curios plus the Consumable subclass that holds maps and ensembles.
        local classID, subclassID = select(6, C_Item.GetItemInfoInstant(itemID))
        local link = info and info.hyperlink
        local curio = d.catUsable and IsCurio(itemID, link, classID, subclassID)
        local usableCandidate = curio or (d.catUsable and IsUsableCandidate(classID, subclassID, info))
        local scan = (info and info.hasLoot) or classID == CLASS_MISC
            or classID == CLASS_HOUSING or usableCandidate
        if scan then
            local facts = TooltipFacts(bag, slot, itemID)
            -- Decor counts only while it can be used right now: a decor item
            -- with a "Use:" line (dyes and already-placed pieces have none).
            if facts.usable and IsDecor(itemID, link, classID, subclassID, facts) then
                return d.catDecor and "decor" or nil
            end
            if facts.locked then return d.catLockbox and "lockbox" or nil end
            if facts.openable or (info and info.hasLoot) then
                return d.catOpenable and "openable" or nil
            end
            if usableCandidate and (facts.usable or curio) and not USABLE_IGNORE[itemID]
               and IsCurrentExpansion(itemID) then
                facts = TooltipFacts(bag, slot, itemID, true)
                -- Curios: only the game's own "already have this curio" /
                -- "Already known" text blocks; other items: any red line, and
                -- multi-charge gadgets (holiday wands etc.) never count.
                local blocked = curio and facts.curioDup or (not curio and (facts.blocked or facts.charges))
                if not blocked and (curio or not ReagentsShort(itemID, link)) then
                    return "usable"
                end
            end
        end
    end
    return nil
end

-- ── Overlay on container item buttons ───────────────────────────────────────
-- Animated style: Blizzard's live proc-glow flipbook (the modern golden
-- shimmer), desaturated and tinted per category — the exact technique
-- LibCustomGlow/WeakAuras ship. Calm style / fallback: the native bag
-- new-item glow atlas tinted per category.
local function EnsureOverlay(button)
    if button.__akcbagAttn then return button.__akcbagAttn end
    local w, h = button:GetSize()
    if not w or w < 1 then w, h = 37, 37 end
    local ov = CreateFrame("Frame", nil, button)
    ov:SetPoint("CENTER")
    ov:SetSize(w * 1.4, h * 1.4)
    ov:SetFrameLevel(button:GetFrameLevel() + 8)
    ov:EnableMouse(false)
    local soft = ov:CreateTexture(nil, "OVERLAY")
    soft:SetPoint("CENTER")
    soft:SetSize(w * 1.12, h * 1.12)
    soft:SetBlendMode("ADD")
    if not pcall(soft.SetAtlas, soft, "bags-glow-white") then
        soft:SetColorTexture(1, 1, 1, 0.4)
    end
    ov.soft = soft
    local loop = ov:CreateTexture(nil, "OVERLAY", nil, 1)
    loop:SetAllPoints(ov)
    loop:SetBlendMode("ADD")
    local okAtlas = pcall(loop.SetAtlas, loop, "UI-HUD-ActionBar-Proc-Loop-Flipbook")
    ov.ProcLoop = loop
    if okAtlas then
        local okAnim = pcall(function()
            local ag = ov:CreateAnimationGroup()
            ag:SetLooping("REPEAT")
            local fb = ag:CreateAnimation("FlipBook")
            fb:SetChildKey("ProcLoop")
            fb:SetDuration(1)
            fb:SetFlipBookRows(6)
            fb:SetFlipBookColumns(5)
            fb:SetFlipBookFrames(30)
            ov.loopAnim = ag
        end)
        if not okAnim then ov.loopAnim = nil end
    end
    if not ov.loopAnim then loop:Hide() end
    button.__akcbagAttn = ov
    return ov
end

local function CleanButton(button)
    local ov = button.__akcbagAttn
    if ov then
        if ov.loopAnim then ov.loopAnim:Stop() end
        ov:Hide()
    end
end

local function UpdateContainerButton(button, bagID, slotIndex)
    local d = DB()
    local cat = d.enabled and bagID and slotIndex and results[bagID .. ":" .. slotIndex] or nil
    if not cat then CleanButton(button) return end
    local ov = EnsureOverlay(button)
    local c = CAT_COLORS[cat]
    if d.pulse and ov.loopAnim then
        ov.soft:Hide()
        ov.ProcLoop:Show()
        ov.ProcLoop:SetDesaturated(true)
        ov.ProcLoop:SetVertexColor(c[1], c[2], c[3], 0.9)
        ov:Show()
        if not ov.loopAnim:IsPlaying() then ov.loopAnim:Play() end
    else
        if ov.loopAnim then ov.loopAnim:Stop() end
        ov.ProcLoop:Hide()
        ov.soft:Show()
        ov.soft:SetVertexColor(c[1], c[2], c[3], 0.85)
        ov:Show()
    end
end

local function RefreshVisibleButtons()
    if ContainerFrameCombinedBags and ContainerFrameCombinedBags:IsShown()
       and ContainerFrameCombinedBags.EnumerateValidItems then
        for _, itemButton in ContainerFrameCombinedBags:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end
    if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
        for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
            if frame:IsShown() and frame.EnumerateValidItems then
                for _, itemButton in frame:EnumerateValidItems() do
                    UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
                end
            end
        end
    end
end

-- ── Backpack badge ──────────────────────────────────────────────────────────
-- Blizzard's own modern red notification bubble (micro-menu style) with a
-- count on top, popping in like the GameMenu/Communities dots do.
local function EnsureBadge()
    if badgeFrame then return badgeFrame end
    local parent = MainMenuBarBackpackButton
    if not parent then return nil end
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(22, 22)
    f:SetPoint("CENTER", parent, "TOPRIGHT", -4, -4)
    f:SetFrameLevel(parent:GetFrameLevel() + 10)
    f:EnableMouse(false)
    local bg = f:CreateTexture(nil, "ARTWORK")
    bg:SetAllPoints()
    if not pcall(bg.SetAtlas, bg, "UI-HUD-MicroMenu-Communities-Icon-Notification") then
        bg:SetColorTexture(0.80, 0.14, 0.14, 0.95)
    end
    local txt = f:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    txt:SetPoint("CENTER", 0, 0)
    f.txt = txt
    local pop = f:CreateAnimationGroup()
    local a = pop:CreateAnimation("Alpha")
    a:SetOrder(1); a:SetFromAlpha(0); a:SetToAlpha(1); a:SetDuration(0.1)
    local s1 = pop:CreateAnimation("Scale")
    s1:SetOrder(1); s1:SetDuration(0.12); s1:SetOrigin("CENTER", 0, 0); s1:SetSmoothing("OUT")
    if s1.SetScaleFrom then s1:SetScaleFrom(0.5, 0.5); s1:SetScaleTo(1.2, 1.2)
    elseif s1.SetFromScale then s1:SetFromScale(0.5, 0.5); s1:SetToScale(1.2, 1.2) end
    local s2 = pop:CreateAnimation("Scale")
    s2:SetOrder(2); s2:SetDuration(0.08); s2:SetOrigin("CENTER", 0, 0); s2:SetSmoothing("IN")
    if s2.SetScaleFrom then s2:SetScaleFrom(1.2, 1.2); s2:SetScaleTo(1, 1)
    elseif s2.SetFromScale then s2:SetFromScale(1.2, 1.2); s2:SetToScale(1, 1) end
    f.pop = pop
    f:Hide()
    badgeFrame = f
    return f
end

local function UpdateBadge()
    local d = DB()
    if not (d.enabled and d.badge and actionCount > 0) then
        if badgeFrame then badgeFrame:Hide() end
        return
    end
    local f = EnsureBadge()
    if not f then return end
    f.txt:SetText(actionCount > 9 and "9+" or actionCount)
    local wasHidden = not f:IsShown()
    f:Show()
    if wasHidden and f.pop then
        f.pop:Stop()
        f.pop:Play()
    end
end

-- ── Scanning ────────────────────────────────────────────────────────────────
local function ScanBags()
    local d = DB()
    if not d.enabled then
        wipe(results)
        actionCount = 0
        UpdateBadge()
        RefreshVisibleButtons()
        return
    end
    -- Combat check must come BEFORE the wipe: otherwise a mid-combat scan
    -- request empties the map and the next Blizzard repaint clears every glow.
    if InCombatLockdown() then
        scanDeferred = true
        return
    end
    wipe(results)
    actionCount = 0
    local seen = {}
    for bag = BAG_FIRST, BAG_LAST do
        local slots = C_Container.GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
            local itemID = ok and info and info.itemID or nil
            if itemID and not IsSecret(itemID) then
                -- One odd item must never blank the rest of the scan.
                local okC, cat = pcall(ClassifySlot, d, bag, slot, itemID, info)
                if not okC then cat = nil end
                if cat then
                    results[bag .. ":" .. slot] = cat
                    if not seen[itemID] then
                        seen[itemID] = true
                        actionCount = actionCount + 1
                    end
                end
            end
        end
    end
    UpdateBadge()
    RefreshVisibleButtons()
end

local function RequestScan()
    if scanQueued then return end
    scanQueued = true
    C_Timer.After(SCAN_DELAY, function()
        scanQueued = false
        ScanBags()
    end)
end

local function RequestQuestScan()
    if questScanQueued then return end
    questScanQueued = true
    C_Timer.After(QUEST_SCAN_DELAY, function()
        questScanQueued = false
        ScanBags()
    end)
end

local function ArmWeeklyResetRescan()
    local ok, secs = pcall(C_DateAndTime.GetSecondsUntilWeeklyReset)
    if ok and type(secs) == "number" and secs > 0 then
        C_Timer.After(secs + 30, function()
            RequestScan()
            ArmWeeklyResetRescan()
        end)
    end
end

-- ── Container frame hooks (same shape as Character/ItemLevel.lua) ───────────
if ContainerFrameCombinedBags and ContainerFrameCombinedBags.UpdateItems then
    hooksecurefunc(ContainerFrameCombinedBags, "UpdateItems", function(self)
        for _, itemButton in self:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end)
end
if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
    for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
        if frame.UpdateItems then
            hooksecurefunc(frame, "UpdateItems", function(self)
                for _, itemButton in self:EnumerateValidItems() do
                    UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
                end
            end)
        end
    end
end
-- ── Settings entry points ───────────────────────────────────────────────────
function _G.AkcQOL_ApplyBagAttention()
    collectibleCache = {}
    tooltipCache = {}
    RequestScan()
end

function _G.AkcQOL_ResetBagAttentionDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.bagAttention = nil end
    DB()
    _G.AkcQOL_ApplyBagAttention()
end

-- ── Events ──────────────────────────────────────────────────────────────────
eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()
        eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
        eventFrame:RegisterEvent("QUEST_LOG_UPDATE")
        eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        eventFrame:RegisterEvent("NEW_MOUNT_ADDED")
        eventFrame:RegisterEvent("NEW_PET_ADDED")
        eventFrame:RegisterEvent("TOYS_UPDATED")
        ArmWeeklyResetRescan()
        C_Timer.After(3, ScanBags)
    elseif event == "BAG_UPDATE_DELAYED" then
        if DB().enabled then RequestScan() end
    elseif event == "QUEST_LOG_UPDATE" then
        if DB().enabled then RequestQuestScan() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if scanDeferred then
            scanDeferred = false
            RequestScan()
        end
    elseif event == "NEW_MOUNT_ADDED" or event == "NEW_PET_ADDED" or event == "TOYS_UPDATED" then
        collectibleCache = {}
        tooltipCache = {}
        if DB().enabled then RequestScan() end
    end
end)
