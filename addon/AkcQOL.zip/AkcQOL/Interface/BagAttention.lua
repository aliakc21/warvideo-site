-- BagAttention: glows bag items that are waiting for an action — openable
-- containers, locked lockboxes, weekly-limited use items (treatises, knowledge
-- drops), unlearned collectibles and quest starters — plus a counter badge on
-- the backpack icon so closed bags still get noticed.

local BAG_FIRST, BAG_LAST = 0, 5
local SCAN_DELAY, QUEST_SCAN_DELAY = 0.25, 2.0

local CAT_COLORS = {
    openable    = { 1.00, 0.62, 0.10 },
    lockbox     = { 0.25, 0.55, 0.95 },
    weekly      = { 0.55, 0.36, 1.00 },
    collectible = { 0.20, 0.85, 0.40 },
    quest       = { 1.00, 0.92, 0.30 },
    decor       = { 1.00, 0.45, 0.25 },
}

-- Housing decor only counts when it can actually be used right now: the item
-- type line must say it is decor AND the tooltip must carry a "Use:" line.
-- Dyes and other housing items without a use action are deliberately skipped.
local DECOR_TYPE_TEXT = _G.HOUSING_DECOR_ITEM_TYPE or "Housing Decor"
local DECOR_USE_PREFIX = _G.ITEM_SPELL_TRIGGER_ONUSE or "Use:"

-- Treatise-type items -> hidden tracking quest flags that complete ON USE
-- (source: WeeklyKnowledge data files). These glow only while this week's
-- use is still available. IMPORTANT: only flag-on-use items belong here —
-- treasure/gathering knowledge drops flag ON LOOT and go below instead.
local WEEKLY_ITEM_QUESTS = {
    [245755] = { 95127 }, [245763] = { 95128 }, [245759] = { 95129 },
    [245809] = { 95138 }, [245761] = { 95130 }, [245757] = { 95131 },
    [245760] = { 95133 }, [245758] = { 95134 }, [245762] = { 95135 },
    [245828] = { 95136 }, [245756] = { 95137 },
}

-- Always actionable while owned (presence in bag = glow): knowledge drops
-- whose weekly flag gates the DROP (already flagged once looted), uncapped
-- catch-up items, and use-it-or-lose-it weeklies like Saltheril's Favor.
local ALWAYS_USE_ITEMS = {
    -- knowledge treasure drops
    [259188] = true, [259189] = true, [259190] = true, [259191] = true,
    [259192] = true, [259193] = true, [259194] = true, [259195] = true,
    [259196] = true, [259197] = true, [259198] = true, [259199] = true,
    [259200] = true, [259201] = true, [259202] = true, [259203] = true,
    -- gathering knowledge items
    [267654] = true, [267655] = true, [238465] = true, [238466] = true,
    [237496] = true, [237506] = true, [238625] = true, [238626] = true,
    -- profession catch-up knowledge (uncapped)
    [246320] = true, [246322] = true, [267653] = true, [246326] = true,
    [238467] = true, [246328] = true, [246330] = true, [246332] = true,
    [237507] = true, [238627] = true, [246334] = true,
    [238987] = true, -- Saltheril's Favor (expires at weekly reset)
    [252415] = true, -- Trovehunter's Bounty
}

local results = {}        -- ["bag:slot"] = category
local actionCount = 0     -- distinct itemIDs waiting
local tooltipCache = {}   -- [itemID] = { openable = bool, locked = bool }
local collectibleCache = {} -- [itemID] = bool (true = unlearned collectible)
local scanQueued, questScanQueued, scanDeferred = false, false, false
local badgeFrame
local eventFrame

local function DB()
    if not AkcQOLDB then AkcQOLDB = {} end
    if not AkcQOLDB.global then AkcQOLDB.global = {} end
    local g = AkcQOLDB.global
    if type(g.bagAttention) ~= "table" then g.bagAttention = {} end
    local d = g.bagAttention
    if d.enabled == nil then d.enabled = false end
    if d.catOpenable == nil then d.catOpenable = true end
    if d.catLockbox == nil then d.catLockbox = true end
    if d.catWeekly == nil then d.catWeekly = true end
    if d.catCollectible == nil then d.catCollectible = true end
    if d.catQuest == nil then d.catQuest = true end
    if d.catDecor == nil then d.catDecor = true end
    if d.badge == nil then d.badge = true end
    if d.pulse == nil then d.pulse = true end
    return d
end

local function IsSecret(v)
    if issecretvalue and issecretvalue(v) then return true end
    if canaccessvalue and not canaccessvalue(v) then return true end
    return false
end

local function QuestDone(questID)
    local done = false
    pcall(function() done = C_QuestLog.IsQuestFlaggedCompleted(questID) == true end)
    return done
end

-- Weekly: usable this week iff any mapped flag is still uncompleted.
local function WeeklyUsesLeft(itemID)
    if ALWAYS_USE_ITEMS[itemID] then return 1 end
    local quests = WEEKLY_ITEM_QUESTS[itemID]
    if not quests then return 0 end
    local left = 0
    for _, q in ipairs(quests) do
        if not QuestDone(q) then left = left + 1 end
    end
    return left
end

local function IsUncollectedCollectible(itemID)
    local cached = collectibleCache[itemID]
    if cached ~= nil then return cached end
    local unlearned = false
    if C_MountJournal and C_MountJournal.GetMountFromItem then
        local ok, mountID = pcall(C_MountJournal.GetMountFromItem, itemID)
        if ok and mountID then
            local ok2, collected = pcall(function()
                return select(11, C_MountJournal.GetMountInfoByID(mountID))
            end)
            unlearned = ok2 and collected == false
        end
    end
    if not unlearned and C_PetJournal and C_PetJournal.GetPetInfoByItemID then
        local ok, name, speciesID = pcall(function()
            local n = C_PetJournal.GetPetInfoByItemID(itemID)
            local s = select(13, C_PetJournal.GetPetInfoByItemID(itemID))
            return n, s
        end)
        if ok and name and type(speciesID) == "number" and C_PetJournal.GetNumCollectedInfo then
            local ok2, num = pcall(C_PetJournal.GetNumCollectedInfo, speciesID)
            unlearned = ok2 and num == 0
        end
    end
    if not unlearned and C_ToyBox and C_ToyBox.GetToyInfo and PlayerHasToy then
        local ok, toyItemID = pcall(C_ToyBox.GetToyInfo, itemID)
        if ok and toyItemID then
            local ok2, has = pcall(PlayerHasToy, itemID)
            unlearned = ok2 and has == false
        end
    end
    collectibleCache[itemID] = unlearned
    return unlearned
end

-- Tooltip facts (openable / locked). Locked boxes are re-scanned every pass so
-- the glow turns gold the moment a Rogue picks them.
local function TooltipFacts(bag, slot, itemID)
    local cached = tooltipCache[itemID]
    if cached and not cached.locked then return cached end
    local facts = { openable = false, locked = false }
    local complete = false
    if C_TooltipInfo and C_TooltipInfo.GetBagItem then
        local ok, data = pcall(C_TooltipInfo.GetBagItem, bag, slot)
        if ok and data and data.lines then
            -- A tooltip with fewer than 2 lines means the item data hasn't
            -- streamed in yet; caching that would freeze "not openable"
            -- for the whole session.
            complete = #data.lines >= 2
            for _, line in ipairs(data.lines) do
                local lt = line.leftText
                if lt and not IsSecret(lt) and type(lt) == "string" then
                    if lt == ITEM_OPENABLE then facts.openable = true
                    elseif lt == LOCKED then facts.locked = true
                    elseif lt == DECOR_TYPE_TEXT then facts.decorType = true
                    elseif lt:find(DECOR_USE_PREFIX, 1, true) == 1 then facts.usable = true end
                end
            end
        end
    end
    facts.decor = (facts.decorType and facts.usable) or false
    if complete then tooltipCache[itemID] = facts end
    return facts
end

local function IsQuestStarter(bag, slot, itemID)
    local classID = select(6, C_Item.GetItemInfoInstant(itemID))
    if classID ~= 12 then return false end
    local ok, info = pcall(C_Container.GetContainerItemQuestInfo, bag, slot)
    if not ok or type(info) ~= "table" then return false end
    local qid = info.questID
    if not qid or IsSecret(qid) then return false end
    if info.isActive then return false end
    return not QuestDone(qid)
end

local function ClassifySlot(d, bag, slot, itemID, info)
    if d.catWeekly and WeeklyUsesLeft(itemID) > 0 then return "weekly" end
    if d.catQuest and IsQuestStarter(bag, slot, itemID) then return "quest" end
    if d.catCollectible and IsUncollectedCollectible(itemID) then return "collectible" end
    if d.catDecor or d.catLockbox or d.catOpenable then
        -- Tooltip scans are limited to plausible containers: hasLoot from the
        -- container info, or the lockbox item class (Miscellaneous/Junk).
        local maybeContainer = info and info.hasLoot
        local classID = select(6, C_Item.GetItemInfoInstant(itemID))
        if not maybeContainer then
            -- Lockboxes are Miscellaneous/Junk; housing decor is Miscellaneous
            -- too (its own subclass), so scan the whole Miscellaneous class.
            maybeContainer = (classID == 15)
        end
        if maybeContainer then
            local facts = TooltipFacts(bag, slot, itemID)
            if facts.decor then return d.catDecor and "decor" or nil end
            if facts.locked then return d.catLockbox and "lockbox" or nil end
            if facts.openable or (info and info.hasLoot) then
                return d.catOpenable and "openable" or nil
            end
        end
    end
    return nil
end

-- ── Overlay on container item buttons ───────────────────────────────────────
-- Animated style: Blizzard's live proc-glow flipbook (the modern golden
-- shimmer), desaturated and tinted per category — the exact technique
-- LibCustomGlow/WeakAuras ship. Calm style / fallback: the native bag
-- new-item glow atlas tinted per category.
local function EnsureOverlay(button)
    if button.__akcbagAttn then return button.__akcbagAttn end
    local w, h = button:GetSize()
    if not w or w < 1 then w, h = 37, 37 end
    local ov = CreateFrame("Frame", nil, button)
    ov:SetPoint("CENTER")
    ov:SetSize(w * 1.4, h * 1.4)
    ov:SetFrameLevel(button:GetFrameLevel() + 8)
    ov:EnableMouse(false)
    local soft = ov:CreateTexture(nil, "OVERLAY")
    soft:SetPoint("CENTER")
    soft:SetSize(w * 1.12, h * 1.12)
    soft:SetBlendMode("ADD")
    if not pcall(soft.SetAtlas, soft, "bags-glow-white") then
        soft:SetColorTexture(1, 1, 1, 0.4)
    end
    ov.soft = soft
    local loop = ov:CreateTexture(nil, "OVERLAY", nil, 1)
    loop:SetAllPoints(ov)
    loop:SetBlendMode("ADD")
    local okAtlas = pcall(loop.SetAtlas, loop, "UI-HUD-ActionBar-Proc-Loop-Flipbook")
    ov.ProcLoop = loop
    if okAtlas then
        local okAnim = pcall(function()
            local ag = ov:CreateAnimationGroup()
            ag:SetLooping("REPEAT")
            local fb = ag:CreateAnimation("FlipBook")
            fb:SetChildKey("ProcLoop")
            fb:SetDuration(1)
            fb:SetFlipBookRows(6)
            fb:SetFlipBookColumns(5)
            fb:SetFlipBookFrames(30)
            ov.loopAnim = ag
        end)
        if not okAnim then ov.loopAnim = nil end
    end
    if not ov.loopAnim then loop:Hide() end
    button.__akcbagAttn = ov
    return ov
end

local function CleanButton(button)
    local ov = button.__akcbagAttn
    if ov then
        if ov.loopAnim then ov.loopAnim:Stop() end
        ov:Hide()
    end
end

local function UpdateContainerButton(button, bagID, slotIndex)
    local d = DB()
    local cat = d.enabled and bagID and slotIndex and results[bagID .. ":" .. slotIndex] or nil
    if not cat then CleanButton(button) return end
    local ov = EnsureOverlay(button)
    local c = CAT_COLORS[cat]
    if d.pulse and ov.loopAnim then
        ov.soft:Hide()
        ov.ProcLoop:Show()
        ov.ProcLoop:SetDesaturated(true)
        ov.ProcLoop:SetVertexColor(c[1], c[2], c[3], 0.9)
        ov:Show()
        if not ov.loopAnim:IsPlaying() then ov.loopAnim:Play() end
    else
        if ov.loopAnim then ov.loopAnim:Stop() end
        ov.ProcLoop:Hide()
        ov.soft:Show()
        ov.soft:SetVertexColor(c[1], c[2], c[3], 0.85)
        ov:Show()
    end
end

local function RefreshVisibleButtons()
    if ContainerFrameCombinedBags and ContainerFrameCombinedBags:IsShown()
       and ContainerFrameCombinedBags.EnumerateValidItems then
        for _, itemButton in ContainerFrameCombinedBags:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end
    if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
        for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
            if frame:IsShown() and frame.EnumerateValidItems then
                for _, itemButton in frame:EnumerateValidItems() do
                    UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
                end
            end
        end
    end
end

-- ── Backpack badge ──────────────────────────────────────────────────────────
-- Blizzard's own modern red notification bubble (micro-menu style) with a
-- count on top, popping in like the GameMenu/Communities dots do.
local function EnsureBadge()
    if badgeFrame then return badgeFrame end
    local parent = MainMenuBarBackpackButton
    if not parent then return nil end
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(22, 22)
    f:SetPoint("CENTER", parent, "TOPRIGHT", -4, -4)
    f:SetFrameLevel(parent:GetFrameLevel() + 10)
    f:EnableMouse(false)
    local bg = f:CreateTexture(nil, "ARTWORK")
    bg:SetAllPoints()
    if not pcall(bg.SetAtlas, bg, "UI-HUD-MicroMenu-Communities-Icon-Notification") then
        bg:SetColorTexture(0.80, 0.14, 0.14, 0.95)
    end
    local txt = f:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
    txt:SetPoint("CENTER", 0, 0)
    f.txt = txt
    local pop = f:CreateAnimationGroup()
    local a = pop:CreateAnimation("Alpha")
    a:SetOrder(1); a:SetFromAlpha(0); a:SetToAlpha(1); a:SetDuration(0.1)
    local s1 = pop:CreateAnimation("Scale")
    s1:SetOrder(1); s1:SetDuration(0.12); s1:SetOrigin("CENTER", 0, 0); s1:SetSmoothing("OUT")
    if s1.SetScaleFrom then s1:SetScaleFrom(0.5, 0.5); s1:SetScaleTo(1.2, 1.2)
    elseif s1.SetFromScale then s1:SetFromScale(0.5, 0.5); s1:SetToScale(1.2, 1.2) end
    local s2 = pop:CreateAnimation("Scale")
    s2:SetOrder(2); s2:SetDuration(0.08); s2:SetOrigin("CENTER", 0, 0); s2:SetSmoothing("IN")
    if s2.SetScaleFrom then s2:SetScaleFrom(1.2, 1.2); s2:SetScaleTo(1, 1)
    elseif s2.SetFromScale then s2:SetFromScale(1.2, 1.2); s2:SetToScale(1, 1) end
    f.pop = pop
    f:Hide()
    badgeFrame = f
    return f
end

local function UpdateBadge()
    local d = DB()
    if not (d.enabled and d.badge and actionCount > 0) then
        if badgeFrame then badgeFrame:Hide() end
        return
    end
    local f = EnsureBadge()
    if not f then return end
    f.txt:SetText(actionCount > 9 and "9+" or actionCount)
    local wasHidden = not f:IsShown()
    f:Show()
    if wasHidden and f.pop then
        f.pop:Stop()
        f.pop:Play()
    end
end

-- ── Scanning ────────────────────────────────────────────────────────────────
local function ScanBags()
    local d = DB()
    if not d.enabled then
        wipe(results)
        actionCount = 0
        UpdateBadge()
        RefreshVisibleButtons()
        return
    end
    -- Combat check must come BEFORE the wipe: otherwise a mid-combat scan
    -- request empties the map and the next Blizzard repaint clears every glow.
    if InCombatLockdown() then
        scanDeferred = true
        return
    end
    wipe(results)
    actionCount = 0
    local seen = {}
    for bag = BAG_FIRST, BAG_LAST do
        local slots = C_Container.GetContainerNumSlots(bag) or 0
        for slot = 1, slots do
            local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
            local itemID = ok and info and info.itemID or nil
            if itemID and not IsSecret(itemID) then
                local cat = ClassifySlot(d, bag, slot, itemID, info)
                if cat then
                    results[bag .. ":" .. slot] = cat
                    if not seen[itemID] then
                        seen[itemID] = true
                        actionCount = actionCount + 1
                    end
                end
            end
        end
    end
    UpdateBadge()
    RefreshVisibleButtons()
end

local function RequestScan()
    if scanQueued then return end
    scanQueued = true
    C_Timer.After(SCAN_DELAY, function()
        scanQueued = false
        ScanBags()
    end)
end

local function RequestQuestScan()
    if questScanQueued then return end
    questScanQueued = true
    C_Timer.After(QUEST_SCAN_DELAY, function()
        questScanQueued = false
        ScanBags()
    end)
end

local function ArmWeeklyResetRescan()
    local ok, secs = pcall(C_DateAndTime.GetSecondsUntilWeeklyReset)
    if ok and type(secs) == "number" and secs > 0 then
        C_Timer.After(secs + 30, function()
            RequestScan()
            ArmWeeklyResetRescan()
        end)
    end
end

-- ── Container frame hooks (same shape as Character/ItemLevel.lua) ───────────
if ContainerFrameCombinedBags and ContainerFrameCombinedBags.UpdateItems then
    hooksecurefunc(ContainerFrameCombinedBags, "UpdateItems", function(self)
        for _, itemButton in self:EnumerateValidItems() do
            UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
        end
    end)
end
if ContainerFrameContainer and ContainerFrameContainer.ContainerFrames then
    for _, frame in ipairs(ContainerFrameContainer.ContainerFrames) do
        if frame.UpdateItems then
            hooksecurefunc(frame, "UpdateItems", function(self)
                for _, itemButton in self:EnumerateValidItems() do
                    UpdateContainerButton(itemButton, itemButton:GetBagID(), itemButton:GetID())
                end
            end)
        end
    end
end
-- ── Settings entry points ───────────────────────────────────────────────────
function _G.AkcQOL_ApplyBagAttention()
    collectibleCache = {}
    tooltipCache = {}
    RequestScan()
end

function _G.AkcQOL_ResetBagAttentionDefaults()
    if AkcQOLDB and AkcQOLDB.global then AkcQOLDB.global.bagAttention = nil end
    DB()
    _G.AkcQOL_ApplyBagAttention()
end

-- ── Events ──────────────────────────────────────────────────────────────────
eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DB()
        eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
        eventFrame:RegisterEvent("QUEST_LOG_UPDATE")
        eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        eventFrame:RegisterEvent("NEW_MOUNT_ADDED")
        eventFrame:RegisterEvent("NEW_PET_ADDED")
        eventFrame:RegisterEvent("TOYS_UPDATED")
        ArmWeeklyResetRescan()
        C_Timer.After(3, ScanBags)
    elseif event == "BAG_UPDATE_DELAYED" then
        if DB().enabled then RequestScan() end
    elseif event == "QUEST_LOG_UPDATE" then
        if DB().enabled then RequestQuestScan() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if scanDeferred then
            scanDeferred = false
            RequestScan()
        end
    elseif event == "NEW_MOUNT_ADDED" or event == "NEW_PET_ADDED" or event == "TOYS_UPDATED" then
        collectibleCache = {}
        if DB().enabled then RequestScan() end
    end
end)
