-- =========================================================================
-- AkcQOL COMBAT REZ TRACKER
-- A small movable frame that tracks the pooled battle-resurrection charges in
-- raid encounters and Mythic+ (charges available + time until the next one),
-- plus an optional big on-screen "X died!" warning when a group member dies.
--
-- Midnight 12.0 technique (proven by shipping addons):
--  * Charges: C_Spell.GetSpellCharges(20484 Rebirth) returns the raid-wide
--    pooled charge info for EVERY player while the pool is active (BigWigs
--    BattleRes does exactly this, class-independent). All fields are secret-
--    guarded anyway; if unreadable, a local accrual timer estimates ("~N").
--  * Deaths: CLEU is removed in 12.0, so deaths are detected via the global
--    UNIT_HEALTH event + UnitIsDeadOrGhost()/UnitIsFeignDeath() (both plain
--    booleans, never secret) with GUID-dedup — the Cell death-report pattern.
--  * Active only in raid difficulties (ENCOUNTER_START/END) and M+ keys
--    (CHALLENGE_MODE_START/COMPLETED, diffID 8 = key resumed after /reload).
--
-- Fresh install: OFF (zero effect until enabled from Settings > Combat Rez).
-- =========================================================================

local _, addon = ...

local REBIRTH = 20484
local RAID_DIFFS = { [14] = true, [15] = true, [16] = true, [17] = true, [33] = true, [233] = true }
-- 23 = Mythic dungeon (key not started yet -> wait for CHALLENGE_MODE_START);
-- 8  = active Mythic Keystone run (what a /reload mid-key resumes into).
local DIFF_MYTHIC_DUNGEON, DIFF_KEYSTONE_ACTIVE = 23, 8

local function IsSecret(v)
    return type(issecretvalue) == "function" and select(2, pcall(issecretvalue, v)) == true
end

local function DB()
    if not EnrageDB then EnrageDB = {} end
    if not EnrageDB.global then EnrageDB.global = {} end
    local g = EnrageDB.global
    if type(g.combatRez) ~= "table" then g.combatRez = {} end
    local d = g.combatRez
    if d.enabled == nil then d.enabled = false end   -- fresh installs opt in from settings
    if d.deathWarn == nil then d.deathWarn = true end -- sub-option; only acts while enabled
    if d.unlock == nil then d.unlock = false end
    return d
end

-- ---------------- tracker frame (lazy) ----------------
local trackerFrame
local function EnsureTracker()
    if trackerFrame then return trackerFrame end
    local f = CreateFrame("Frame", "EnrageCombatRezFrame", UIParent)
    f:SetSize(126, 40)
    local pos = DB().pos
    if pos and pos.p then
        f:SetPoint(pos.p, UIParent, pos.rp or pos.p, pos.x or 0, pos.y or 0)
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 260)
    end
    f:SetFrameStrata("MEDIUM")
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:EnableMouse(false)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) self:StartMoving() end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        DB().pos = { p = p, rp = rp, x = x, y = y }
    end)

    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetAllPoints()
    f.bg:SetColorTexture(0, 0, 0, 0.35)

    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(30, 30)
    f.icon:SetPoint("LEFT", 5, 0)
    local tex
    if C_Spell and C_Spell.GetSpellTexture then
        local ok, t = pcall(C_Spell.GetSpellTexture, REBIRTH)
        if ok and t and not IsSecret(t) then tex = t end
    end
    f.icon:SetTexture(tex or 136080) -- Rebirth icon fallback
    f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    f.charges = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.charges:SetPoint("LEFT", f.icon, "RIGHT", 8, 7)
    f.charges:SetTextColor(0.3, 1, 0.3, 1)
    f.charges:SetText("0")

    f.timer = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.timer:SetPoint("TOPLEFT", f.charges, "BOTTOMLEFT", 0, -1)
    f.timer:SetTextColor(1, 0.82, 0, 1)
    f.timer:SetText("0:00")

    f:Hide()
    trackerFrame = f
    return f
end

-- ---------------- death warning text (lazy) ----------------
local deathFrame
local deathHideToken = 0
local function EnsureDeathText()
    if deathFrame then return deathFrame end
    local f = CreateFrame("Frame", "EnrageCombatRezDeathFrame", UIParent)
    f:SetSize(420, 40)
    f:SetPoint("TOP", UIParent, "TOP", 0, -190)
    f:SetFrameStrata("HIGH")
    f.text = f:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    f.text:SetPoint("CENTER")
    f.text:SetTextColor(1, 0.25, 0.2, 1)
    f:Hide()
    deathFrame = f
    return f
end

local function ShowDeathWarning(name)
    local f = EnsureDeathText()
    f.text:SetText(name .. " died!")
    f:Show()
    deathHideToken = deathHideToken + 1
    local token = deathHideToken
    C_Timer.After(4, function()
        if deathHideToken == token and deathFrame then deathFrame:Hide() end
    end)
end

-- ---------------- fallback accrual (only if the API is unreadable) ----------------
-- Raid: 1 charge at pull, +1 every (90/raidSize) min. M+: 1 at start, +1/10min, cap 5.
local fb = { on = false, charges = 0, cap = 0, interval = 0, nextAt = 0 }
local function ArmFallback(mode)
    fb.on = true
    if mode == "mplus" then
        fb.charges, fb.cap, fb.interval = 1, 5, 600
    else
        local n = math.max((GetNumGroupMembers and GetNumGroupMembers()) or 1, 1)
        fb.charges, fb.cap, fb.interval = 1, math.huge, 5400 / n
    end
    fb.nextAt = GetTime() + fb.interval
end

-- ---------------- 1s updater ----------------
local ticker
local runningMode -- "raid" | "mplus" | nil, so settings toggles never restart a live run

local function SetDisplay(c, remaining, approx)
    local f = EnsureTracker()
    f.charges:SetText(approx and ("~" .. c) or tostring(c))
    if remaining and remaining > 0 then
        f.timer:SetFormattedText("%d:%02d", math.floor(remaining / 60), math.floor(remaining % 60))
    else
        f.timer:SetText("0:00")
    end
end

local function OnTick()
    -- Primary channel: the pooled charge API (works for every class while active).
    if C_Spell and C_Spell.GetSpellCharges then
        local ok, info = pcall(C_Spell.GetSpellCharges, REBIRTH)
        if ok then
            if info == nil then
                -- nil is API TRUTH: the charge pool is not active here (e.g. the key
                -- already ended). Show 0 like BigWigs; never fabricate an estimate.
                SetDisplay(0, 0)
                return
            end
            if type(info) == "table" and not IsSecret(info) then
                local c, st, dur = info.currentCharges, info.cooldownStartTime, info.cooldownDuration
                if type(c) == "number" and type(st) == "number" and type(dur) == "number"
                    and not (IsSecret(c) or IsSecret(st) or IsSecret(dur)) then
                    fb.on = false
                    local remaining = dur - (GetTime() - st)
                    SetDisplay(c, math.max(remaining, 0))
                    return
                end
            end
        end
    end
    -- Alternative channel (only when the API is SECRET/unreadable, never when it
    -- says nil): local accrual estimate, marked "~" so it's visibly approximate.
    if fb.on then
        local now = GetTime()
        while now >= fb.nextAt and fb.charges < fb.cap do
            fb.charges = fb.charges + 1
            fb.nextAt = fb.nextAt + fb.interval
        end
        SetDisplay(fb.charges, fb.charges < fb.cap and (fb.nextAt - now) or 0, true)
    else
        SetDisplay(0, 0)
    end
end

local function StartUpdater(mode)
    runningMode = mode
    ArmFallback(mode) -- used only if the API turns out secret; first clean tick disarms it
    EnsureTracker():Show()
    if not ticker then ticker = C_Timer.NewTicker(1, OnTick) end
    OnTick()
end

local function StopUpdater()
    runningMode = nil
    if ticker then ticker:Cancel(); ticker = nil end
    fb.on = false
    if trackerFrame then SetDisplay(0, 0) end
end

-- ---------------- unlock / drag handling ----------------
local function UpdateUnlockState()
    local d = DB()
    local f = EnsureTracker()
    local unlocked = d.enabled and d.unlock and not (InCombatLockdown and InCombatLockdown())
    f:EnableMouse(unlocked)
    if unlocked and not f:IsShown() then
        -- show a sample readout anywhere so the frame can be dragged into place
        f.charges:SetText("2")
        f.timer:SetText("4:30")
        f:Show()
    elseif not unlocked and not ticker and f:IsShown() then
        -- hide again unless the tracker is genuinely running
        local _, _, diffID = GetInstanceInfo()
        if not (diffID and RAID_DIFFS[diffID]) then f:Hide() end
    end
end

-- ---------------- death detection (Cell pattern, CLEU-free) ----------------
local reportedDead = {}
local function OnUnitHealth(unit)
    local d = DB()
    if not d.enabled or not d.deathWarn then return end
    if not unit then return end
    if not (UnitIsUnit(unit, "player") or (UnitInParty and UnitInParty(unit)) or (UnitInRaid and UnitInRaid(unit))) then
        return
    end
    local guid = UnitGUID and UnitGUID(unit)
    if guid == nil or IsSecret(guid) then return end -- a secret GUID may not be used as a table key
    local dead = UnitIsDeadOrGhost(unit) and not (UnitIsFeignDeath and UnitIsFeignDeath(unit))
    if dead then
        if not reportedDead[guid] then
            reportedDead[guid] = true
            local name = UnitName(unit)
            if name == nil or IsSecret(name) then name = unit end
            ShowDeathWarning(name)
        end
    else
        reportedDead[guid] = nil -- resurrected / released: re-arm for the next death
    end
end

-- ---------------- zone / encounter wiring ----------------
local ev = CreateFrame("Frame")

local function SetTrackingEvents(on)
    if on then
        ev:RegisterEvent("ENCOUNTER_START")
        ev:RegisterEvent("ENCOUNTER_END")
    else
        ev:UnregisterEvent("ENCOUNTER_START")
        ev:UnregisterEvent("ENCOUNTER_END")
    end
end

-- Re-evaluates events + updater for the current zone/settings. Preserves a live
-- run: a settings toggle mid-fight neither restarts the tracker (runningMode
-- check) nor re-announces existing deaths (dedup only clears on a zone change --
-- never on roster churn, which is constant in LFR and would duplicate warnings).
local function ApplyZone(zoneChanged)
    local d = DB()
    if zoneChanged then
        wipe(reportedDead)
        if deathFrame then deathFrame:Hide() end
    end

    SetTrackingEvents(false)
    ev:UnregisterEvent("CHALLENGE_MODE_START")
    ev:UnregisterEvent("CHALLENGE_MODE_COMPLETED")
    ev:UnregisterEvent("UNIT_HEALTH")
    ev:UnregisterEvent("PLAYER_REGEN_DISABLED")
    ev:UnregisterEvent("PLAYER_REGEN_ENABLED")

    if not d.enabled then
        StopUpdater()
        if trackerFrame then trackerFrame:Hide() end
        if deathFrame then deathFrame:Hide() end
        return
    end

    local _, _, diffID = GetInstanceInfo()
    local wantMode, showIdle = nil, false
    if diffID and RAID_DIFFS[diffID] then
        SetTrackingEvents(true)
        showIdle = true
        if IsEncounterInProgress and IsEncounterInProgress() then wantMode = "raid" end
        if d.deathWarn then ev:RegisterEvent("UNIT_HEALTH") end
    elseif diffID == DIFF_MYTHIC_DUNGEON then
        ev:RegisterEvent("CHALLENGE_MODE_START")
        if d.deathWarn then ev:RegisterEvent("UNIT_HEALTH") end
    elseif diffID == DIFF_KEYSTONE_ACTIVE then
        wantMode = "mplus"
        ev:RegisterEvent("CHALLENGE_MODE_COMPLETED")
        if d.deathWarn then ev:RegisterEvent("UNIT_HEALTH") end
    end
    ev:RegisterEvent("PLAYER_REGEN_DISABLED")
    ev:RegisterEvent("PLAYER_REGEN_ENABLED")

    if wantMode then
        if runningMode ~= wantMode then StartUpdater(wantMode) end -- keep a live run untouched
    else
        StopUpdater()
        if showIdle then
            EnsureTracker():Show()
            SetDisplay(0, 0)
        elseif trackerFrame then
            trackerFrame:Hide()
        end
    end
    UpdateUnlockState()
end

ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:SetScript("OnEvent", function(_, event, arg1)
    if event == "PLAYER_ENTERING_WORLD" then
        -- difficulty info is only accurate one frame after PEW (BigWigs pattern)
        C_Timer.After(0, function() ApplyZone(true) end)
    elseif event == "ENCOUNTER_START" then
        StartUpdater("raid")
    elseif event == "ENCOUNTER_END" or event == "CHALLENGE_MODE_COMPLETED" then
        StopUpdater()
    elseif event == "CHALLENGE_MODE_START" then
        ev:RegisterEvent("CHALLENGE_MODE_COMPLETED")
        StartUpdater("mplus")
    elseif event == "UNIT_HEALTH" then
        pcall(OnUnitHealth, arg1)
    elseif event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
        UpdateUnlockState()
    end
end)

-- ---------------- public API (settings) ----------------
function _G.Enrage_ApplyCombatRez()
    ApplyZone()
end

function _G.Enrage_ResetCombatRezPosition()
    DB().pos = nil
    if trackerFrame then
        trackerFrame:ClearAllPoints()
        trackerFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 260)
    end
end

function _G.Enrage_TestCombatRezDeathWarning()
    local name = UnitName and UnitName("player") or "Player"
    if IsSecret(name) then name = "Player" end
    ShowDeathWarning(name)
end
