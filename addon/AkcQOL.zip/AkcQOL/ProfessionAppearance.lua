-- =========================================================================
-- AkcQOL HIDE PROFESSION OUTFIT
-- When enabled, cancels the cosmetic "profession outfit" buff the game applies
-- on login and whenever you start a profession, so you never wear the
-- profession transmog. The appearance is a per-profession HELPFUL, CANCELABLE
-- buff -- there is no single master aura -- so we cancel whichever of the known
-- profession buffs is on the player.
--
-- Spell IDs verified against Leatrix Plus 12.0.25, "Hide Profession Equipment"
-- (hipe) 1.2.8, and the live SpellName DBC (build 12.1.0.68301).
--
-- 12.0-safe: every aura value is secret-guarded before use. Canceling a buff is
-- a protected action blocked in combat, so a buff applied mid-combat is stripped
-- the instant combat ends (PLAYER_REGEN_ENABLED). Fishing is special-cased --
-- canceling its buff mid-cast aborts fishing -- so it is only removed once the
-- Fishing channel stops.
-- =========================================================================

local _, addon = ...

-- Standard profession appearance buffs: safe to cancel on sight (out of combat).
local STANDARD = {
    [394003] = true, -- Alchemy       "Spark of Madness"
    [388658] = true, -- Blacksmithing "Suited For Smithing"
    [391775] = true, -- Cooking       "What's Cookin', Good Lookin'?"
    [394008] = true, -- Enchanting    "A Looker's Charm"
    [394007] = true, -- Engineering   "A Production-Grade Display"
    [394005] = true, -- Herbalism     "A Cultivator's Colors"
    [394016] = true, -- Inscription   "Artist's Duds"
    [394015] = true, -- Jewelcrafting "An Eye For Shine"
    [394001] = true, -- Leatherworking "Sculpting Leather Finery"
    [394006] = true, -- Mining        "Rockin' Mining Gear"
    [394011] = true, -- Skinning      "Dressed To Kill"
    [391312] = true, -- Tailoring     "Wrapped Up In Weaving"
}
-- Fishing outfit: canceling it while fishing aborts the cast, so it is only
-- removed when the channeled Fishing cast stops (or on combat exit).
local FISHING = { [394009] = true } -- "Fishing For Attention"
local FISHING_CAST = 131476          -- the channeled Fishing spell
local FILTER = "HELPFUL|CANCELABLE"

local function IsEnabled()
    return EnrageDB and EnrageDB.global and EnrageDB.global.hideProfessionOutfit == true
end

-- Secret-safe read gate. Midnight ships canaccessvalue (used by Leatrix/hipe);
-- the rest of this addon uses issecretvalue. Support both; default to readable.
local function CanRead(v)
    if canaccessvalue ~= nil then
        local ok, res = pcall(canaccessvalue, v)
        if ok then return res == true end
    end
    if issecretvalue ~= nil then
        local ok, res = pcall(issecretvalue, v)
        if ok then return res ~= true end
    end
    return true
end

-- Cancel, OUT OF COMBAT ONLY, every player buff whose spellId is in matchTable.
-- Indices are collected first, then canceled high->low so a cancel never shifts
-- an index we still have to visit.
local function Sweep(matchTable)
    if InCombatLockdown and InCombatLockdown() then return end
    if not (C_UnitAuras and C_UnitAuras.GetBuffDataByIndex and CancelUnitBuff) then return end

    local hits
    for i = 1, 40 do
        local ok, data = pcall(C_UnitAuras.GetBuffDataByIndex, "player", i, FILTER)
        if not ok then
            -- reading this slot errored; skip it, keep scanning
        elseif data == nil then
            break -- no more buffs (indices are contiguous within the filter)
        elseif CanRead(data) and CanRead(data.spellId) and matchTable[data.spellId] then
            hits = hits or {}
            hits[#hits + 1] = i
        end
    end

    if hits then
        for j = #hits, 1, -1 do
            pcall(CancelUnitBuff, "player", hits[j], FILTER)
        end
    end
end

local function OnEvent(_, event, a1, a2, a3)
    if not IsEnabled() then return end

    if event == "UNIT_AURA" then
        local info = a2 -- updateInfo payload (a1 == "player")
        if not CanRead(info) or type(info) ~= "table" then
            Sweep(STANDARD) -- unreadable / nil payload -> treat as full update
            return
        end
        if CanRead(info.isFullUpdate) and info.isFullUpdate then
            Sweep(STANDARD) -- login / reload / zone-in force-show
            return
        end
        local added = info.addedAuras
        if CanRead(added) and type(added) == "table" then
            for _, au in ipairs(added) do
                if CanRead(au) then
                    local sid = au.spellId
                    if CanRead(sid) and sid ~= nil and STANDARD[sid] then
                        Sweep(STANDARD) -- instant hide the moment a profession buff appears
                        return
                    end
                end
            end
        end

    elseif event == "PLAYER_REGEN_ENABLED" then
        -- Combat blocked any earlier cancel; re-attempt now that we can.
        Sweep(STANDARD)
        Sweep(FISHING)

    elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" then
        -- a1 = unit ("player"), a2 = castGUID, a3 = spellID. Own casts are not
        -- secret in 12.0, but guard anyway.
        if CanRead(a3) and a3 == FISHING_CAST then
            Sweep(FISHING)
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Belt-and-suspenders: the outfit can be re-applied a beat after login.
        if C_Timer and C_Timer.After then
            for i = 1, 5 do
                C_Timer.After(i, function() if IsEnabled() then Sweep(STANDARD) end end)
            end
        end
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:SetScript("OnEvent", OnEvent)

local function ApplyState()
    if IsEnabled() then
        eventFrame:RegisterUnitEvent("UNIT_AURA", "player")
        eventFrame:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "player")
        eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
        eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
        Sweep(STANDARD) -- immediate: remove any outfit buff already on the player
    else
        eventFrame:UnregisterAllEvents()
    end
end

-- Apply the saved state on login (registers events + immediate sweep if enabled).
local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:SetScript("OnEvent", function()
    boot:UnregisterAllEvents()
    ApplyState()
end)

-- Called by the settings toggle whenever it changes.
function _G.Enrage_ApplyProfessionAppearance()
    ApplyState()
end

-- Diagnostic: print the player's current cancelable helpful buffs, so an unlisted
-- profession outfit (e.g. a future profession) can be identified and added.
SLASH_AKCPROFDUMP1 = "/akcprofdump"
SlashCmdList["AKCPROFDUMP"] = function()
    print("|cff8c5cffAkc|r|cffffffffQOL|r  cancelable buffs (index  spellId  name):")
    if not (C_UnitAuras and C_UnitAuras.GetBuffDataByIndex) then return end
    for i = 1, 40 do
        local ok, d = pcall(C_UnitAuras.GetBuffDataByIndex, "player", i, FILTER)
        if not ok then
            -- skip
        elseif d == nil then
            break
        elseif CanRead(d) and CanRead(d.spellId) then
            local nm = (CanRead(d.name) and d.name) or "?"
            print(i, d.spellId, nm)
        end
    end
end
